
import junit.framework.*;

public class RandoopTest4 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test1"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.43514833056151364d, (java.lang.Number)100.0f, true);

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test2"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextUniform(0.723245967437971d, 5.205744238502723d);
//     double var6 = var0.nextWeibull(0.9030899869919435d, 1976.5498837332734d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.12090952255429d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 53.938593900079326d);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test3"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(9.0071987E15f, 2.2737368E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.2737368E-13f);

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test4"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var1.nextBinomial(0, (-1.9416690332135457E-6d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
// 
//   }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test5"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var2 = var1.start();
    double var4 = var1.addElementRolling(4.937302184657956d);
    int var5 = var1.start();
    var1.contract();
    double[] var7 = var1.getInternalValues();
    var1.setExpansionMode(0);
    double[] var10 = var1.getElements();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    double[] var17 = new double[] { 10.0d, 100.0d};
    double var18 = var11.mannWhitneyU(var14, var17);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var20 = var0.mannWhitneyUTest(var10, var14);
      fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
    } catch (org.apache.commons.math3.exception.NoDataException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 32.0d);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test6"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(5.072085481610059d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.682752359367199d);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test7"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getStandardDeviation();
    double var10 = var0.cumulativeProbability((-0.004920366423301847d));
    boolean var11 = var0.isSupportUpperBoundInclusive();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var13 = var0.sample((-15));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.4980370657191222d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test8"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(10.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-10.0f));

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test9"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     double var8 = var1.nextExponential(44.5140274520795d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var10 = var1.nextSecureHexString((-241));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 90.886177975531d);
// 
//   }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test10"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     int var12 = var1.nextZipf(3, 0.949950589504148d);
//     var1.reSeedSecure();
//     double var16 = var1.nextCauchy(0.0d, 0.5637033385775058d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var1.nextBinomial(0, 1.4055443918089456d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 99.64907962995574d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.22889661823358248d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.274203777754323d);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test11"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-22), 15.999999f, 1.0000001f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test12"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)Double.NaN, (java.lang.Number)0.6139648708421599d, true);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var8 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var6, (java.lang.Number)4.158638853279167d, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var8);
    java.lang.Number var12 = var3.getMax();
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 0.6139648708421599d+ "'", var12.equals(0.6139648708421599d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test13"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    int var3 = var0.getNumElements();
    double[] var4 = var0.getElements();
    var0.setExpansionMode(0);
    var0.discardFrontElements(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardMostRecentElements((-1605022207));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test14"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-0.22462663147858472d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0253348204169905d);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test15"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(108.67153323312886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test16"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.11079388629258953d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test17"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getSupportLowerBound();
    double var10 = var0.density(0.004000934888783327d);
    boolean var11 = var0.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.3989390873839266d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test18"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(86.37257067437166d, 7.62939453125E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test19"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(14066561462L, 3617318266L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test20"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-1L), 32718048432L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 32718048432L);

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test21"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var8 = var1.nextCauchy(1.0d, 4.427429051327539d);
//     org.apache.commons.math3.distribution.RealDistribution var9 = null;
//     double var10 = var1.nextInversionDeviate(var9);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test22"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(2.220446049250313E-16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test23"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(44.34227194424954d, 0.17480295424053163d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.8047467059224926d));

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test24"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    int var2 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var4 = var3.getNumElements();
    double[] var5 = var3.getInternalValues();
    int var6 = var3.getNumElements();
    double[] var7 = var3.getElements();
    var0.addElements(var7);
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var12);
    var12.setElement(825, (-0.06991186090907374d));
    var12.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var19 = var12.substituteMostRecentElement((-0.9918946513810528d));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test25"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    java.lang.String var7 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var9.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var14 = var12.addElementRolling(Double.NaN);
    double[] var15 = var12.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var9, var16);
    double[] var18 = var9.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var21 = var19.addElementRolling(Double.NaN);
    double[] var22 = var19.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    var9.addElements(var22);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var25 = var8.rank(var22);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test26"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test27"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Throwable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError();
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var2, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test28"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-0.056273459664487095d), (java.lang.Number)2.2737367544323206E-13d, false);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test29"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.13547561509003855d);

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test30"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     double var12 = var1.nextBeta(98.00138274241472d, 0.9984187364052811d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("", "481952");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 106);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.996849423025437d);
// 
//   }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test31"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     double var12 = var1.nextBeta(98.00138274241472d, 0.9984187364052811d);
//     double var15 = var1.nextUniform(4.61512051684126d, 57.348154628338996d);
//     double var17 = var1.nextExponential(0.9400207386800911d);
//     long var20 = var1.nextLong(3773985329L, 32718048432L);
//     org.apache.commons.math3.distribution.IntegerDistribution var21 = null;
//     int var22 = var1.nextInversionDeviate(var21);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test32"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.374727287185447d, (-15));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.195334738725119E-5d);

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test33"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-1.161278971931107d), 4.190005834626415d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test34"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(9.0071993E15f, (-0.6140289167040057d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.0071987E15f);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test35"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.5186207998179818d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test36"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var1);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException(var3, (java.lang.Number)24.0d, (java.lang.Number)0.723245967437971d, (java.lang.Number)825);
    var2.addSuppressed((java.lang.Throwable)var7);
    java.lang.Number var9 = var7.getArgument();
    java.lang.Number var10 = var7.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 24.0d+ "'", var9.equals(24.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 825+ "'", var10.equals(825));

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test37"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var4 = var1.nextChiSquare(5.464265321962551d);
//     int var8 = var1.nextHypergeometric(1704294704, 5215, 10400);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var1.nextLong((-2L), (-5154125899424117313L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 6.550024521381305d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test38"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(825, 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4);

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test39"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(1.0854629842427983d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test40"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.9567827717396936d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.17602522784537067d);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test41"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     int var13 = var1.nextSecureInt(0, 10);
//     double var15 = var1.nextChiSquare(31.984371183438956d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var1.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 906034271L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 26.04559914826984d);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test42"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-5), 345126018);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 345126018);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test43"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.5587178359296467d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8479354822642708d);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test44"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.99999994f, (-0.9999999f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.99999994f));

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test45"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test46"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var16 = var15.getNumElements();
    double[] var17 = var15.getInternalValues();
    double[] var20 = new double[] { 10.0d, 100.0d};
    double var21 = var14.mannWhitneyU(var17, var20);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var23 = var22.getNumElements();
    double[] var24 = var22.getInternalValues();
    double var25 = var0.mannWhitneyUTest(var17, var24);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var28 = var26.addElementRolling(Double.NaN);
    double[] var29 = var26.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray(var29);
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray(var29);
    double[] var32 = var31.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var33 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var35 = var33.addElementRolling(Double.NaN);
    var33.setNumElements(0);
    var33.contract();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var39 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var40 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var43 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var44 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var45 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var46 = var45.getNumElements();
    double[] var47 = var45.getInternalValues();
    double[] var50 = new double[] { 10.0d, 100.0d};
    double var51 = var44.mannWhitneyU(var47, var50);
    org.apache.commons.math3.util.ResizableDoubleArray var52 = new org.apache.commons.math3.util.ResizableDoubleArray(var47);
    double var53 = var40.mannWhitneyU(var43, var47);
    double[] var57 = new double[] { 100.0d, 1.0d, 100.0d};
    double var58 = var39.mannWhitneyU(var43, var57);
    var33.addElements(var57);
    org.apache.commons.math3.util.ResizableDoubleArray var61 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var33, var61);
    var33.clear();
    double[] var64 = var33.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var65 = var0.mannWhitneyUTest(var32, var64);
      fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
    } catch (org.apache.commons.math3.exception.NoDataException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test47"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(402.7572967449497d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5919185321270688d);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test48"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var17 = var16.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    int var21 = var18.getNumElements();
    double[] var22 = var18.getElements();
    var16.addElements(var22);
    float var24 = var16.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var16);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    var26.addElement(2.0d);
    double var30 = var26.substituteMostRecentElement(0.9802694590384492d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 2.0d);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test49"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var3);
    var1.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var1.substituteMostRecentElement(7.950137129262093E-8d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test50"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(10.567764688902704d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 19430.854264735135d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test51"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(7550, (-1023));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test52"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     int var12 = var1.nextZipf(3, 0.949950589504148d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("org.apache.commons.math3.exception.OutOfRangeException: -0.058 out of [-1, 100] range", "a79a9c");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 100.2553363754539d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.843850979481531d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test53"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(2.0107520380478325d, (-1.6318581766994622d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.6318581766994622d));

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test54"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-2L), 506);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test55"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var13 = var1.nextUniform(0.9999943487368532d, 44.5140274520795d);
//     double var15 = var1.nextChiSquare(51.55677237552102d);
//     double var18 = var1.nextGaussian(100.0d, 0.8939360120238292d);
//     org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var21 = var19.density(100.0d);
//     double var24 = var19.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double var25 = var19.getMean();
//     double var26 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var19);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1376175684L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4.65642978350631d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 64.23076980428634d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 100.4467786738112d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-0.21799941329709718d));
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test56"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.Class var5 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    java.lang.Class var9 = var8.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var10.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    int var16 = var15.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    java.lang.Class var21 = var20.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.TiesStrategy var23 = var22.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var23);
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var23);
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var25.getTiesStrategy();
    java.lang.Class var27 = var26.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var26);
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test57"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-10.567559072274053d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-11.0d));

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test58"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.03971046312691345d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1992748431862724d);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test59"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(1L, 194432926L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 194432926L);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test60"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(572.2646479502633d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5395502634883683d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test61"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-1.9999999999999998d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test62"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var5 = var0.getSupportUpperBound();
    double var6 = var0.getNumericalMean();
    double var7 = var0.getSupportUpperBound();
    var0.reseedRandomGenerator(9935950308L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test63"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(8494943427L, (-8454645887L));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test64"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    java.lang.Class var4 = var3.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var6 = java.lang.Enum.<java.lang.Enum>valueOf(var4, "org.apache.commons.math3.exception.NumberIsTooSmallException: 31.984 is smaller than, or equal to, the minimum (10)");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test65"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    float var4 = var0.getContractionCriteria();
    float var5 = var0.getContractionCriteria();
    float var6 = var0.getContractionCriteria();
    var0.contract();
    double[] var8 = var0.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test66"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGaussian((-0.8887857291489829d), 1.6260590822656884E-6d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var1.nextBinomial((-74), 1.1529248674810905E-9d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 98.93959852155542d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.8887837446204212d));
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test67"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(8770513317L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8770513317L);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test68"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var3);
    var1.contract();
    var1.addElement((-0.8307376748471434d));
    float var8 = var1.getExpansionFactor();
    var1.discardMostRecentElements(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test69"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, (-0.17393496569430167d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test70"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(4.90396171141481d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1904030893025183d);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test71"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test72"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(1.327000036267693d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7522227585083432d);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test73"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(5.960465E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.960465E-8f);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test74"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.6139648708421599d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test75"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(3.4965075614664802d, 9.298415193461524d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.4965075614664802d);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test76"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0, (-347));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test77"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     var1.reSeed(3384732745L);
//     var1.reSeedSecure(2L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextBinomial(50, 2.09995534605947d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test78"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(3.0854555602929743d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0854555602929747d);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test79"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(10.0d, (-0.8564026207044273d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.999999999999998d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test80"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-0.7323676290027762d), 3628800.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.0182088541742898E-7d));

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test81"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-2.9378153224114745d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.2427091761093652d));

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test82"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int var3 = var0.nextPascal(100, 0.0d);
    var0.reSeedSecure(3520920158L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var8 = var0.nextPermutation(300, 1704294704);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2147483647);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test83"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var11 = var10.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    int var15 = var12.getNumElements();
    double[] var16 = var12.getElements();
    var10.addElements(var16);
    var0.addElements(var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionFactor(10.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test84"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(0.9985619410825101d, (-0.6000588730884988d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test85"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.8835772395603834d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7869394579475408d));

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test86"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var13 = var1.nextUniform(0.9999943487368532d, 44.5140274520795d);
//     double var15 = var1.nextChiSquare(51.55677237552102d);
//     double var18 = var1.nextGaussian(100.0d, 0.8939360120238292d);
//     org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var21 = var19.density(100.0d);
//     double var24 = var19.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double var25 = var19.getMean();
//     double var26 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var19);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var30 = var1.nextUniform(3.2188758248682006d, 0.28017358107103757d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1709226943L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 19.472650737690593d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 50.80878730818501d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 100.37222996151611d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.4559852236597446d);
// 
//   }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test87"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-1.4E-45f), 1.0000004f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test88"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextChiSquare(0.6139648708421599d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextGaussian((-1.3407807929942293E154d), (-0.010152952316618155d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.1342712886278703d);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test89"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var4);
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, var4);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var6.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test90"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(3.399216241149525E248d, (-15));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0373584720304946E244d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test91"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)6.040249042294968d, (java.lang.Number)2.7755575615628914E-17d, false);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test92"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.9999999988953956d, 44.34227194424954d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999510193321d);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test93"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(16, 447);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test94"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getStandardDeviation();
    boolean var9 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator(1L);
    boolean var12 = var0.isSupportLowerBoundInclusive();
    double var13 = var0.getNumericalMean();
    double var14 = var0.getSupportLowerBound();
    double var15 = var0.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == Double.POSITIVE_INFINITY);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test95"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.6000588730884988d), (-0.30273833427190305d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.6000588730884987d));

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test96"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(4.6E-44f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.6E-44f);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test97"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(1.6501466433552379d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test98"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var12 = var10.addElementRolling(Double.NaN);
    double[] var13 = var10.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    var0.addElements(var13);
    double var17 = var0.addElementRolling(0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var19 = var0.getElement(101794);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test99"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.17480295424053163d, 4.65642978350631d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9995622214897429d);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test100"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.9135022946042973d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0459608427974982d);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test101"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.0000001f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test102"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(393769108042894612L, 6438299617L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test103"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     int var13 = var1.nextSecureInt(0, 10);
//     double var15 = var1.nextChiSquare(496.2674961884226d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var1.nextCauchy((-0.47554673505167777d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4449156770L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 555.7320024971891d);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test104"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(1.7145135182272309d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.029923905963016993d);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test105"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(78.0922235533153d, 1.4329174706418153d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 78.0922235533153d);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test106"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed();
    var1.reSeed(0L);
    double var7 = var1.nextBeta(1.9865549713026993d, 0.024588566448858762d);
    var1.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var1.nextWeibull(58.54535109520317d, (-1.3670189956165777d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test107"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.6118882710102016E8d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test108"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     int var12 = var1.nextZipf(3, 0.949950589504148d);
//     var1.reSeedSecure();
//     double var16 = var1.nextCauchy(0.0d, 0.5637033385775058d);
//     double var18 = var1.nextExponential(1.9117361753569404d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var21 = var1.nextSecureLong(4572436235037468952L, 3520920158L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 99.71141839967919d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.04503716365050347d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.10578541335054241d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.16904722704604785d);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test109"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    java.lang.Object var3 = null;
    boolean var4 = var0.equals(var3);
    double[] var5 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test110"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0, 251);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test111"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getNumericalMean();
    boolean var2 = var0.isSupportLowerBoundInclusive();
    double var4 = var0.probability((-4.440892098500626E-16d));
    double var5 = var0.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test112"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-0.013030125303900976d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0d));

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test113"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(5769050335L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test114"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.7357609613264131d, 1.327000036267693d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.5912390749412799d));

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test115"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(7.38420064243972d, 99.69065826232949d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0739361189720186d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test116"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(12044041517L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test117"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)10400);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test118"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getMean();
//     double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     boolean var5 = var0.isSupportConnected();
//     double var6 = var0.getNumericalVariance();
//     double var7 = var0.sample();
//     double var8 = var0.getNumericalVariance();
//     double var10 = var0.density(0.949950589504148d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.42960132384540173d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.25407098196369926d);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test119"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-1.1323809315910958d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7126504395271167d);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test120"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.2676505E30f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2676505E30f);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test121"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1.9999999999999998d), (java.lang.Number)1.6501466433552379d, true);
    java.lang.Number var4 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.6501466433552379d+ "'", var4.equals(1.6501466433552379d));

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test122"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(10000000000L, 3628800L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test123"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, (java.lang.Number)30.0d, true);
//     java.lang.Number var5 = var4.getMin();
//     org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test124"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum((-0.04087591190814478d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test125"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(0.999987895021552d, 15.322095332102348d, false);
//     double var8 = var1.nextGamma(1.4713540043352986d, 4.787491742782046d);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var9.getMean();
//     double var13 = var9.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var14 = var9.getNumericalVariance();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     var1.reSeedSecure((-10L));
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("", "org.apache.commons.math3.exception.NumberIsTooLargeException: \uFFFD is larger than the maximum (0.614)");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 4.885356809354229d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 5.428923460814d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.2804484282999289d));
// 
//   }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test126"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    float var4 = var0.getContractionCriteria();
    float var5 = var0.getContractionCriteria();
    var0.setNumElements(50);
    double[] var8 = var0.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test127"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-0.8508150646900634d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test128"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getSupportLowerBound();
    double var10 = var0.density(0.004000934888783327d);
    double var13 = var0.cumulativeProbability((-1.0084760157976542d), (-0.9985753080512595d));
    double var14 = var0.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.3989390873839266d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0023872351676735293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test129"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, 0.7232459674379711d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test130"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(65, (-0.99999994f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test131"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(5306065, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5306065);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test132"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(3617318266L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3617318266L);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test133"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    java.lang.Class var7 = var6.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = var8.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var8.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
    int var14 = var13.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.NaNStrategy var18 = var17.getNanStrategy();
    java.lang.Class var19 = var18.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var21);
    java.lang.String var25 = var21.name();
    java.lang.String var26 = var21.name();
    java.lang.String var27 = var21.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "AVERAGE"+ "'", var25.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "AVERAGE"+ "'", var26.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "AVERAGE"+ "'", var27.equals("AVERAGE"));

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test134"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0010908414609777095d, 2.9686693898115446d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0010908414609777095d);

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test135"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     long var10 = var1.nextLong(0L, 10000000000L);
//     int var13 = var1.nextBinomial(9900, 0.5230558330643571d);
//     double var16 = var1.nextWeibull(1.2588883301765683d, 1.6449342991103786d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 47.77929504193063d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 9229393813L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5120);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.5366351274156775d);
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test136"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    var0.clear();
    var0.setExpansionFactor(2.4999998f);
    var0.clear();
    var0.addElement(0.4980370657191222d);
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test137"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var1.substituteMostRecentElement(37.422148975532345d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test138"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)9741938155L, (java.lang.Number)32.50577543666101d, true);

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test139"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getMean();
//     double var2 = var0.getNumericalVariance();
//     double var3 = var0.sample();
//     double var4 = var0.getSupportLowerBound();
//     double var6 = var0.probability(0.610495167011921d);
//     double var8 = var0.cumulativeProbability(0.008525501001438424d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1.1290749587464477d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5034011416095043d);
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test140"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(2.060417273429006d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test141"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(35241726707532550L, 7172474253L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 35241726707532550L);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test142"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.08788246267614536d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 29.451889752629654d);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test143"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var5 = var1.nextPoisson(0.9720449790817591d);
//     double var7 = var1.nextChiSquare(5.65362408791435d);
//     double var10 = var1.nextCauchy((-0.23573885556858495d), 1.8525291623715519d);
//     java.lang.String var12 = var1.nextSecureHexString(10400);
//     int var15 = var1.nextZipf(100, 0.999987895021552d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 6.452517278579422d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-2.347333589296936d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test144"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(99.81558499485845d, 0.949950589504148d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.011153962456199694d));

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test145"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(731);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 731);

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test146"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var1.nextPoisson((-0.5961722400471147d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 98.05292662298281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 5.338177078577116d);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test147"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    int var8 = var7.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    java.lang.Class var13 = var12.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var14.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7, var15);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var15);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var18.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var23 = var21.addElementRolling(Double.NaN);
    double[] var24 = var21.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var18, var25);
    double[] var27 = var18.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(var27);
    org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var31 = var29.addElementRolling(Double.NaN);
    var29.setNumElements(0);
    double var35 = var29.addElementRolling(0.0d);
    int var36 = var29.start();
    int var37 = var29.start();
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var39 = var38.getNumElements();
    int var40 = var38.start();
    int var41 = var38.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var29, var38);
    double[] var43 = var29.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var44 = var17.mannWhitneyUTest(var27, var43);
      fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
    } catch (org.apache.commons.math3.exception.NoDataException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test148"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.5552592332346065d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.009691101822043007d);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test149"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getNumericalMean();
    double var2 = var0.getStandardDeviation();
    boolean var3 = var0.isSupportLowerBoundInclusive();
    double var4 = var0.getSupportLowerBound();
    double var5 = var0.getSupportLowerBound();
    var0.reseedRandomGenerator(0L);
    double var9 = var0.density(115.65804595436055d);
    var0.reseedRandomGenerator(3617318266L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test150"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     var1.reSeed(3384732745L);
//     var1.reSeedSecure(2L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var1.nextPoisson((-7.520871210725989E-16d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 136);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test151"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(34.812727742759826d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 87.91820670226954d);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test152"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(345126018, (-1078420975));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test153"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(9900, 447);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test154"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getMean();
//     double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     boolean var5 = var0.isSupportConnected();
//     double var6 = var0.getNumericalVariance();
//     double var7 = var0.sample();
//     double var8 = var0.getSupportLowerBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.49674184541592015d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NEGATIVE_INFINITY);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test155"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(1.032816324840946d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2264813687550429d);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test156"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3570, 365);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test157"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(3.4028233E38f, 0.3742437696541317d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.402823E38f);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test158"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(6.38510221163952d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9994647563262273d);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test159"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-15), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-15));

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test160"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(2.742631232643827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 157.1411943912539d);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test161"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(100.49999f, 1.2588883301765683d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.499985f);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test162"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0, 300);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 300);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test163"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(0.999987895021552d, 15.322095332102348d, false);
//     double var8 = var1.nextGamma(1.4713540043352986d, 4.787491742782046d);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var9.getMean();
//     double var13 = var9.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var14 = var9.getNumericalVariance();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     var1.reSeedSecure((-10L));
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var1.nextBinomial(1704294704, 1.4055443918089456d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 13.459042185295512d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.69725944511075d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.2633384678876653d));
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test164"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var4);
    org.apache.commons.math3.random.RandomGenerator var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    int var12 = var11.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = var15.getNanStrategy();
    java.lang.Class var17 = var16.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.TiesStrategy var19 = var18.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var19);
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var19);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var3, var19);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = var23.getNanStrategy();
    boolean var25 = var19.equals((java.lang.Object)var23);
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var23.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test165"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("286c701597194465efbfe1dd78516836fb6a5ab49a89e775804dc0e5f780114233b0059bf6c96c99790bf133da95567415591529168221c1dec3c851112be53731f19c1e1fc39a4cd6d8bf552fb4f9c9543ba02d9980d92d32b90872910be64bde7e6c6c4edfa6d9f03dab4c42a3c8f978aa938d004817e1feafc74982dce60bf3de7293c251519b881cc644baf1fe592437e5d64bf22d8a3af10b7fbdf77024b7d275e6ac749629e648391052bae98feae9eda6913d3510eeb0a3028da209998b5e456643aa1423910a8d93ec7ac9d01e0e87bf27a51266a8fe61df3cc570bec66c51f9aae742325989b470fe19b528cdc7765c4d9f93f5131a");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test166"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-1605022207), 5002023);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5002023);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test167"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    double[] var6 = var5.getElements();
    var5.setContractionCriteria(1.26765045E30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test168"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(9.298415193461524d, 0.024588566448858762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.024588566448858762d);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test169"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var7 = var1.nextExponential(209.99999999999997d);
//     double var10 = var1.nextGaussian(0.6387763808612118d, 9.999999999999996d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var1.nextPascal(60, 210.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9999999978570175d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 84.04958680898774d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-3.7187455971482146d));
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test170"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0f, 2.2737368E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.2737368E-13f);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test171"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(345126018, (-1605022207));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1950148225);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test172"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test173"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test174"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(5002023, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5002023);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test175"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-15), (-0.9999999f), 15.999999f, 365);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test176"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6931471805599453d);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test177"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(101.00463684329249d, 200.94444231998796d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999999999977d);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test178"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0, 50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test179"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-2.9378153224114745d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9944016678464891d));

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test180"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(5212001191L, 3645265866L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test181"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(short)10);
    java.lang.Number var2 = var1.getMax();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + (short)10+ "'", var2.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test182"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(9.0071987E15f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test183"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.9999999862135353d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13.147780393007714d);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test184"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)2.3044102334851835d);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test185"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(19430.854264735135d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test186"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-0.6848736638100912d), 1.5690509993150914d, (-0.7919113044382963d));

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test187"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    int var3 = var0.getNumElements();
    var0.setNumElements(300);
    int var6 = var0.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test188"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var7 = var1.nextExponential(209.99999999999997d);
//     var1.reSeedSecure();
//     var1.reSeed(4448708814L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var13 = var1.nextPermutation((-20), (-127));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9999994642688106d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 13.090201848562764d);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test189"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, (java.lang.Number)(-0.17393496569430167d), true);
    java.lang.Number var5 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.17393496569430167d)+ "'", var5.equals((-0.17393496569430167d)));

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test190"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-11.846621767789712d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.1669665405092338d));

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test191"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.03971046312691345d, (java.lang.Number)(-2L), true);
    boolean var5 = var4.getBoundIsAllowed();
    boolean var6 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test192"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(305.69256826715235d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test193"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, 1.26765045E30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test194"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    var15.addElement(1832.5694791909018d);
    int var18 = var15.getNumElements();
    boolean var20 = var15.equals((java.lang.Object)1.071112867107899d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test195"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.30353390504256844d, 1.6118882710102016E8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.8830951902909365E-9d);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test196"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    boolean var4 = var0.equals((java.lang.Object)1.0854629842427983d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardMostRecentElements(5210);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test197"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(1.082063323071492d, (-0.8860078878357261d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9325064796530801d);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test198"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    java.lang.Class var8 = var7.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    int var12 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    boolean var15 = var2.equals((java.lang.Object)(-3.2830016497499828d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test199"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(101.00463684329249d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5608961146894065d);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test200"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(330, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test201"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.065175436767987d, (java.lang.Number)3628800L, true);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 3628800L+ "'", var5.equals(3628800L));

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test202"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.5966246732509366d, (java.lang.Number)0.9854805897010366d, false);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test203"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var17 = var16.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    int var21 = var18.getNumElements();
    double[] var22 = var18.getElements();
    var16.addElements(var22);
    float var24 = var16.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var16);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = var14.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var27.setExpansionMode(127);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test204"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var16 = var15.getNumElements();
    double[] var17 = var15.getInternalValues();
    double[] var20 = new double[] { 10.0d, 100.0d};
    double var21 = var14.mannWhitneyU(var17, var20);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var23 = var22.getNumElements();
    double[] var24 = var22.getInternalValues();
    double var25 = var0.mannWhitneyUTest(var17, var24);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var27 = var26.getNumElements();
    int var28 = var26.start();
    int var29 = var26.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var30 = var26.copy();
    var30.addElement(1.5690509993150914d);
    var30.contract();
    double[] var34 = var30.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var35 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var36 = var35.start();
    double[] var37 = var35.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var38 = var0.mannWhitneyU(var34, var37);
      fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
    } catch (org.apache.commons.math3.exception.NoDataException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test205"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-1.2676505E30f), 9900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.NEGATIVE_INFINITY);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test206"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(3592007075L, 5212001191L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test207"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var3);
    var1.contract();
    var1.addElement((-0.8307376748471434d));
    double var9 = var1.getElement(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.8307376748471434d));

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test208"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var11 = var10.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    int var15 = var12.getNumElements();
    double[] var16 = var12.getElements();
    var10.addElements(var16);
    var0.addElements(var16);
    boolean var20 = var0.equals((java.lang.Object)' ');
    var0.addElement(0.876407757475359d);
    float var23 = var0.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2.0f);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test209"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(5090545318414900353L, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test210"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 99.86181335178172d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4.255299853532773d);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test211"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.start();
    double var3 = var0.addElementRolling(4.937302184657956d);
    int var4 = var0.start();
    var0.contract();
    double[] var6 = var0.getInternalValues();
    var0.setExpansionMode(0);
    var0.contract();
    int var10 = var0.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test212"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-1.1290749587464477d), (-0.05624544022146599d), 1.7522227585083432d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test213"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-5), (java.lang.Number)1.9865549713026993d, false);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test214"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-1.0084760157976542d), 30.90131202558219d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 30.91776364449456d);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test215"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(5210, 365);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test216"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var7 = var1.nextExponential(209.99999999999997d);
//     double var10 = var1.nextGaussian(0.6387763808612118d, 9.999999999999996d);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var11.getMean();
//     double var15 = var11.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var18 = var11.cumulativeProbability((-19.894922083922054d), 0.7853981633974483d);
//     double var19 = var11.sample();
//     double var20 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var23 = var1.nextPermutation(7, 317);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9999520880953456d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 18.287312474761627d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-4.274786006258981d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.7838899213734127d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.6596472504519486d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-0.6539932557116139d));
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test217"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2.0107520380478325d, (java.lang.Number)29.54554454270477d, false);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test218"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0, 506);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test219"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     double var9 = var1.nextT(1.5855819012757701d);
//     double var12 = var1.nextCauchy((-1.8456016649756868d), 4.9E-324d);
//     double var15 = var1.nextGamma((-0.11018662689453802d), 0.7503963846834529d);
//     java.util.Collection var16 = null;
//     java.lang.Object[] var18 = var1.nextSample(var16, 365);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test220"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.9999999988953956d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999988953957d);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test221"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { (-1.6286532113855836d)};
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var2, var4);
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var1, var4);
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var4);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test222"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.43514833056151364d, 1164691958);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test223"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     java.lang.String var8 = var1.nextHexString(500);
//     double var10 = var1.nextT(0.9584128699015102d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var1.nextHypergeometric(10400, 251, 345126018);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9433897793L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "346bb60198192a99f9a3839f2eee8de089d644b1dd004b0d235192dbc64c22a92453df4a24f04748f42fe658bdd25525a804bfd2af9f69da292473739dc7a1ed29e88386d8ef6312ee47800e6a1503caaea2c4469c0651f25922c245f7d655435534f2130016e29f58b79dc15ddac975928427b30a6bef6adf2ee3327f3283ff82b00d061970fdd6a73ec3f3189c6be427f57c9b59b90ed549427fe8b6c59dc6a5c2f34072083dc35964a4ad9073985809fafcac81a7b18f9a8155398e2aaa95e74d13f3cd4fe389a68166caf16bd77819b2e5aa0b25c9f010b1059b76913bb9336e99bae5b8aefd70854cfb2cd2fd3b02e66706ec701b449d5d"+ "'", var8.equals("346bb60198192a99f9a3839f2eee8de089d644b1dd004b0d235192dbc64c22a92453df4a24f04748f42fe658bdd25525a804bfd2af9f69da292473739dc7a1ed29e88386d8ef6312ee47800e6a1503caaea2c4469c0651f25922c245f7d655435534f2130016e29f58b79dc15ddac975928427b30a6bef6adf2ee3327f3283ff82b00d061970fdd6a73ec3f3189c6be427f57c9b59b90ed549427fe8b6c59dc6a5c2f34072083dc35964a4ad9073985809fafcac81a7b18f9a8155398e2aaa95e74d13f3cd4fe389a68166caf16bd77819b2e5aa0b25c9f010b1059b76913bb9336e99bae5b8aefd70854cfb2cd2fd3b02e66706ec701b449d5d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.267490058077983d);
// 
//   }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test224"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-241), 128);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-241));

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test225"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(343, 7521675590L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 323293105);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test226"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.2676505E30f, 731);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test227"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(343);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1663.1795900889629d);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test228"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.011153962456199694d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-7));

  }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test229"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     double var9 = var1.nextT(1.5855819012757701d);
//     double var12 = var1.nextGaussian((-0.7323676290027762d), 13.753533396481055d);
//     var1.reSeed(4286580654L);
//     org.apache.commons.math3.distribution.IntegerDistribution var15 = null;
//     int var16 = var1.nextInversionDeviate(var15);
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test230"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.17480295424053163d, 0.1657797866605693d, 0.9565001502429822d, 1164691958);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2367949252453998d);

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test231"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     java.lang.String var8 = var1.nextHexString(500);
//     double var10 = var1.nextT(0.9584128699015102d);
//     var1.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextBeta((-0.0019750240854171527d), 1.7126504395271167d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9271200861L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "49fe900e0e7d040f999948b4689709867749729077b45136dc909dac61624680fd99468be60076f3fd2a217f384b47327988ee29e55cfb8315a01106e27cacee970411832365cee25520d3c2734ef855ce86104434a4423deb65c51e6e79ba9cfc942bb61f076076f518dbf9d8a23c7c928f96e213376be6891a3b31add14656e4010a8b738c7d8f0ffd3ff1f36151ea24a007334362292494f1af557725a932b8c5144d336512cf7ff7bc1950a2f165716c5b99ca97bbdd2c073754e403f2f0601f813f1b2ac017f7aa2f9005c7fc95955cbaaef60aa600e3d83ac33862d51df1f2ff530dd976c452402d1e24b96f9be6e0712474ebafd6a97b"+ "'", var8.equals("49fe900e0e7d040f999948b4689709867749729077b45136dc909dac61624680fd99468be60076f3fd2a217f384b47327988ee29e55cfb8315a01106e27cacee970411832365cee25520d3c2734ef855ce86104434a4423deb65c51e6e79ba9cfc942bb61f076076f518dbf9d8a23c7c928f96e213376be6891a3b31add14656e4010a8b738c7d8f0ffd3ff1f36151ea24a007334362292494f1af557725a932b8c5144d336512cf7ff7bc1950a2f165716c5b99ca97bbdd2c073754e403f2f0601f813f1b2ac017f7aa2f9005c7fc95955cbaaef60aa600e3d83ac33862d51df1f2ff530dd976c452402d1e24b96f9be6e0712474ebafd6a97b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.5509134766795896d));
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test232"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0d, 115.65804595436055d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test233"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(short)100);
    java.lang.Number var2 = var1.getMax();
    java.lang.Number var3 = var1.getMax();
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError();
    java.lang.Throwable[] var8 = var7.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var4, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var11.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + (short)100+ "'", var2.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (short)100+ "'", var3.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test234"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(3.402823E38f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 127);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test235"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    java.lang.Class var8 = var7.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("AVERAGE");
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var13);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var16 = var15.getNumElements();
    int var17 = var15.start();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    int var21 = var18.getNumElements();
    double[] var22 = var18.getElements();
    var15.addElements(var22);
    var15.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var15, var27);
    var27.contract();
    org.apache.commons.math3.random.RandomGenerator var30 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30);
    org.apache.commons.math3.stat.ranking.TiesStrategy var32 = var31.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var33 = var31.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var34 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var33, var34);
    org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var37 = var36.start();
    double var39 = var36.addElementRolling(4.937302184657956d);
    int var40 = var36.start();
    var36.contract();
    double[] var42 = var36.getInternalValues();
    double[] var43 = var35.rank(var42);
    boolean var44 = var27.equals((java.lang.Object)var42);
    double[] var45 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var46 = var14.mannWhitneyUTest(var42, var45);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test236"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-5.2969878277335525d), (java.lang.Number)2.0107520380478325d, (java.lang.Number)0.5040503723628342d);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    java.lang.Number var5 = var3.getHi();
    java.lang.Number var6 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.5040503723628342d+ "'", var5.equals(0.5040503723628342d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 2.0107520380478325d+ "'", var6.equals(2.0107520380478325d));

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test237"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(18.462611448278334d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test238"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(16.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 16.000002f);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test239"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var8 = var1.nextGamma(4.937302184657956d, 97.98819663162894d);
//     double var11 = var1.nextCauchy(99.69065826232949d, 5.381455886543763d);
//     org.apache.commons.math3.distribution.IntegerDistribution var12 = null;
//     int var13 = var1.nextInversionDeviate(var12);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test240"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(5120, (-1023));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6143);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test241"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.9846781146117636d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.676950074612442d);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test242"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(6143, (-1037414828));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1037420971);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test243"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test244"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(211);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test245"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(1.0373584720304946E244d, 0.43343553720412786d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0373584720304946E244d);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test246"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.5123030455090722d, (java.lang.Number)2.002865034964586d, false);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test247"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.9135022946042973d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test248"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-20), 66495);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 66475);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test249"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(8.48319645397181d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test250"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getMean();
//     double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     boolean var5 = var0.isSupportConnected();
//     double var6 = var0.getNumericalVariance();
//     double var7 = var0.sample();
//     double var8 = var0.getStandardDeviation();
//     double var9 = var0.getSupportUpperBound();
//     boolean var10 = var0.isSupportUpperBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.8978521387557495d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test251"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.4980370657191222d, 396);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8.037850951474781E118d);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test252"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeedSecure(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var6 = var1.nextPermutation(9900, 323293105);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test253"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    int var10 = var9.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    java.lang.String var20 = var17.name();
    java.lang.Class var21 = var17.getDeclaringClass();
    boolean var23 = var17.equals((java.lang.Object)8770513317L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test254"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.4819216925681265d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 19.50627823942975d);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test255"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(60, 0.0f, 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test256"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(24.79239851287064d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 24.792398512870644d);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test257"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(0, (-1.0f), 7.6293945E-6f, (-17));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test258"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-1023), 0);
//     double var7 = var1.nextGaussian((-0.20637078079078508d), 0.3989422804014327d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextWeibull((-0.5637033385775058d), 1.7126504395271167d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-509));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.6366843784159146d));
// 
//   }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test259"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(5210, 16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 106.2384465452581d);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test260"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var17 = var16.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    int var21 = var18.getNumElements();
    double[] var22 = var18.getElements();
    var16.addElements(var22);
    float var24 = var16.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var16);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = var14.copy();
    var27.setExpansionFactor(2.4999998f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test261"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(5002023, (-3.4028235E38f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test262"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    var0.clear();
    int var4 = var0.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test263"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var7 = var1.nextExponential(209.99999999999997d);
//     var1.reSeedSecure();
//     double var11 = var1.nextUniform(0.0d, 0.9133845507670576d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var1.nextZipf(300, (-0.5063656411097588d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9999997495576406d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 419.3545784821757d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.5280929849226835d);
// 
//   }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test264"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextF(0.4980370657191222d, 1.7100683659172744d);
//     double var7 = var1.nextWeibull(4.440892098500626E-16d, 98.7271041519907d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextF((-0.010213363591270954d), 32.53142185860535d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.5735031453902913d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test265"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(8.405682460246684d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test266"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(371);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test267"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, (-1037414828));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test268"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     double var12 = var1.nextBeta(98.00138274241472d, 0.9984187364052811d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextBeta(0.25407098196369926d, (-0.6932391748384723d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.998222606295657d);
// 
//   }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test269"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.5458066324533807d), (-0.7232395891127782d), 9.140183681189434d, 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test270"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.5607966601082315d);
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var5 = var3.density(100.0d);
//     double var8 = var3.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double[] var10 = var3.sample(100);
//     double var11 = var3.getStandardDeviation();
//     double var13 = var3.cumulativeProbability((-0.004920366423301847d));
//     double var14 = var3.getNumericalVariance();
//     double var15 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var3);
//     double var18 = var0.nextCauchy(1.7100683659172744d, 0.8939360120238291d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var0.nextInt(1164691958, (-15));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.3070946037012865d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.4980370657191222d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1.0315292610479958d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.6828863188205443d);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test271"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(2147483647, (-2124184289));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test272"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-0.9146614843608588d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test273"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var5 = var0.getSupportUpperBound();
    double var6 = var0.getNumericalMean();
    double var7 = var0.getSupportUpperBound();
    double var8 = var0.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test274"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    float var4 = var0.getExpansionFactor();
    int var5 = var0.start();
    var0.setElement(0, (-1.9999999999999998d));
    float var9 = var0.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.0f);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test275"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.018694446191509312d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0188702813552781d);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test276"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.024588566448858762d, (java.lang.Number)(-0.10720322305192957d), (java.lang.Number)4.5E-44f);
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 4.5E-44f+ "'", var5.equals(4.5E-44f));

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test277"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(1.4678542605046391E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0679515313825692E-25d);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test278"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getStandardDeviation();
    boolean var9 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator(1L);
    boolean var12 = var0.isSupportLowerBoundInclusive();
    double var13 = var0.getMean();
    boolean var14 = var0.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test279"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(9259150L, 32L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7565329397184462848L);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test280"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.8061852905228415d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8061852905228414d));

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test281"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var4 = var1.nextChiSquare(5.464265321962551d);
//     int var8 = var1.nextHypergeometric(1704294704, 5215, 10400);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var1.nextHypergeometric(251, (-17), 5210);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 5.517542637067174d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test282"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-47515), 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-47515));

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test283"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh((-1.7429441502075451d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.769568785966569d));

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test284"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(4.90396171141481d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.2144890407077678d);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test285"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(14.766770929226206d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5031799502280012d);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test286"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test287"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    var0.setNumElements(0);
    var0.contract();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var6 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var10 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    double[] var17 = new double[] { 10.0d, 100.0d};
    double var18 = var11.mannWhitneyU(var14, var17);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    double var20 = var7.mannWhitneyU(var10, var14);
    double[] var24 = new double[] { 100.0d, 1.0d, 100.0d};
    double var25 = var6.mannWhitneyU(var10, var24);
    var0.addElements(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var28);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setElement((-1023), 0.8413447226916749d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 4.0d);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test288"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    int var2 = var0.start();
    int var3 = var0.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    var4.addElement(1.5690509993150914d);
    var4.contract();
    float var8 = var4.getContractionCriteria();
    int var9 = var4.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test289"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)9.332621544395286E157d);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test290"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    boolean var5 = var0.isSupportConnected();
    var0.reseedRandomGenerator(0L);
    double var8 = var0.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test291"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 0.0f, 5.960465E-8f, 6143);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test292"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.99999994f, 0.9567827717396936d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999f);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test293"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.9567827717396936d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.418621165340297d);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test294"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.5637033385775058d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.51071998615462d);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test295"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(101794, 365);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 365);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test296"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.4022547067333215d, 7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 179.48860246186516d);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test297"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    int var3 = var0.getNumElements();
    int var4 = var0.start();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var8 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var11 = var10.getNumElements();
    double[] var12 = var10.getInternalValues();
    double[] var15 = new double[] { 10.0d, 100.0d};
    double var16 = var9.mannWhitneyU(var12, var15);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    double var18 = var5.mannWhitneyU(var8, var12);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var22 = var21.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var24 = var23.getNumElements();
    double[] var25 = var23.getInternalValues();
    int var26 = var23.getNumElements();
    double[] var27 = var23.getElements();
    var21.addElements(var27);
    float var29 = var21.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var19, var21);
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    org.apache.commons.math3.distribution.NormalDistribution var32 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var33 = var32.getMean();
    double var36 = var32.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var37 = var32.getSupportUpperBound();
    double[] var39 = var32.sample(371);
    var31.addElements(var39);
    var0.addElements(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test298"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-2L), (-5154125899424117313L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5154125899424117313L));

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test299"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    java.lang.Class var7 = var6.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = var8.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var8.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
    int var14 = var13.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.NaNStrategy var18 = var17.getNanStrategy();
    java.lang.Class var19 = var18.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var21);
    org.apache.commons.math3.stat.ranking.TiesStrategy var25 = var24.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var26 = var24.getNanStrategy();
    java.lang.Class var27 = var26.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test300"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.2182455594777868d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test301"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(98.00138274241472d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 99.0d);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test302"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.014785035766438845d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-7));

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test303"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(394);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test304"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.7522227585083432d, 0.0d, 0.8266429039966963d, 101794);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test305"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed();
    var1.reSeed(0L);
    double var7 = var1.nextBeta(1.9865549713026993d, 0.024588566448858762d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var10 = var1.nextPermutation(0, 295);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test306"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var11 = var10.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    int var15 = var12.getNumElements();
    double[] var16 = var12.getElements();
    var10.addElements(var16);
    var0.addElements(var16);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
    double[] var20 = var19.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var22 = var19.substituteMostRecentElement(0.9999999984381234d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test307"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException(var0);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test308"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(0.999987895021552d, 15.322095332102348d, false);
//     double var8 = var1.nextGamma(1.4713540043352986d, 4.787491742782046d);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var9.getMean();
//     double var13 = var9.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var14 = var9.getNumericalVariance();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     var1.reSeedSecure((-10L));
//     int var20 = var1.nextZipf(89, 17.160827757978193d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.353946613471015d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.39314700860471d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.9983491555909598d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
// 
//   }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test309"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    int var2 = var0.start();
    int var3 = var0.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    double var6 = var4.addElementRolling(0.0d);
    int var7 = var4.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test310"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial((-1037414828));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test311"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(194432926L, 1204204002L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test312"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.82442736154459d, 20988);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test313"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test314"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var4 = var1.nextChiSquare(5.464265321962551d);
//     int var8 = var1.nextHypergeometric(1704294704, 5215, 10400);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution(3.399216241149525E248d, 0.8998354296541002d);
//     double var12 = var11.getMean();
//     boolean var13 = var11.isSupportUpperBoundInclusive();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.902577924053256d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3.399216241149525E248d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test315"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.99999994f, 124952017);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test316"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var4 = null;
    org.apache.commons.math3.exception.MathArithmeticException var5 = new org.apache.commons.math3.exception.MathArithmeticException(var3, var4);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test317"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.008126754594052727d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 15143.014329719106d);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test318"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-0.8887857291489829d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7107934621924091d));

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test319"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(66475, 251);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 907096051);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test320"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.028485400656642273d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test321"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.6219701720597971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test322"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, var8);
    org.apache.commons.math3.exception.MathArithmeticException var12 = new org.apache.commons.math3.exception.MathArithmeticException(var3, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var8);
    org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var1, var8);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var0, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test323"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(109, 9617852648L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1734790817);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test324"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0, 317);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test325"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    int var4 = var2.ordinal();
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var13 = var11.addElementRolling(Double.NaN);
    double[] var14 = var11.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var8, var15);
    double[] var17 = var8.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var21 = var20.getNumElements();
    double[] var22 = var20.getInternalValues();
    double[] var25 = new double[] { 10.0d, 100.0d};
    double var26 = var19.mannWhitneyU(var22, var25);
    var18.addElements(var25);
    boolean var28 = var7.equals((java.lang.Object)var18);
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var7);
    boolean var31 = var7.equals((java.lang.Object)1204204002L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test326"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(13.147780393007714d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6571852329512796d);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test327"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(9.0071993E15f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test328"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.5640658287798841d, 0.8948278522683608d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.057774618901562d);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test329"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.9984187364052811d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0015825151114894772d));

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test330"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1827.7882294099632d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.261925876230186d);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test331"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(Double.POSITIVE_INFINITY, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test332"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.010409007308107676d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.010409007308107674d));

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test333"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-0.42533668233646504d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.551115123125783E-17d);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test334"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(875500725, (-1605022207));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 875500725);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test335"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.48076935803388726d, 1.7126504395271167d, (-0.010409007308107674d), 5);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test336"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var8 = var1.nextUniform(0.0d, 0.1657797866605693d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextUniform(1.5855819012757701d, 0.6219701720597971d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.02082172093131783d);
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test337"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    int var4 = var2.ordinal();
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var13 = var11.addElementRolling(Double.NaN);
    double[] var14 = var11.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var8, var15);
    double[] var17 = var8.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var21 = var20.getNumElements();
    double[] var22 = var20.getInternalValues();
    double[] var25 = new double[] { 10.0d, 100.0d};
    double var26 = var19.mannWhitneyU(var22, var25);
    var18.addElements(var25);
    boolean var28 = var7.equals((java.lang.Object)var18);
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var7);
    java.lang.Class var30 = var2.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var32 = java.lang.Enum.<java.lang.Enum>valueOf(var30, "286c701597194465efbfe1dd78516836fb6a5ab49a89e775804dc0e5f780114233b0059bf6c96c99790bf133da95567415591529168221c1dec3c851112be53731f19c1e1fc39a4cd6d8bf552fb4f9c9543ba02d9980d92d32b90872910be64bde7e6c6c4edfa6d9f03dab4c42a3c8f978aa938d004817e1feafc74982dce60bf3de7293c251519b881cc644baf1fe592437e5d64bf22d8a3af10b7fbdf77024b7d275e6ac749629e648391052bae98feae9eda6913d3510eeb0a3028da209998b5e456643aa1423910a8d93ec7ac9d01e0e87bf27a51266a8fe61df3cc570bec66c51f9aae742325989b470fe19b528cdc7765c4d9f93f5131a");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test338"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     java.lang.String var5 = var1.nextSecureHexString(371);
//     long var8 = var1.nextSecureLong(0L, 8179512108L);
//     var1.reSeed(1L);
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var1.nextSample(var11, 293);
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test339"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.9982044311039222d);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test340"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(0, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-10));

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test341"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(1.065175436767987d, (-0.7294116033586491d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.290984120044901d);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test342"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1164691958, (java.lang.Number)(-0.5912390749412799d), (java.lang.Number)0.06906668840157025d);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test343"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var2 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.MathIllegalStateException var4 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.NotPositiveException var7 = new org.apache.commons.math3.exception.NotPositiveException(var5, (java.lang.Number)(-1.4E-45f));
    var4.addSuppressed((java.lang.Throwable)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test344"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)43.120630495197474d, (java.lang.Number)(short)1, false);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test345"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1734790817, (-347));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test346"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(58.54535109520317d, 0.3989720409944861d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 58.54535109520317d);

  }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test347"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.5607966601082315d);
//     java.lang.String var4 = var0.nextHexString(506);
//     double var7 = var0.nextCauchy(0.3063909472492726d, 1.5607966601082315d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextUniform(2.4978485618289232d, 0.0d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.234670230897223d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "3ddfa0f8526b23a43b3bece1bbabea36701a4634ad4129eaa9006359b7060120001a49b2b9793c848799af3c5387bc85b25fc44584769c4af1dc65f923519cc9aab4bd1b1d945627a248e0581b0aadbc3ebf39b9ccd4df345ac650ba4b95f4c28fa3b972251fb484c7f36ddd6acd77845e6acd787e3fbc5b833297dc591ce617f5bd5b67fa7338801ea125261f4bcdecc84ebba8ecc64e99337035ab8c9b6950999c61d484700f9f36409e192ddf2e9742dc00b99c312a42eb6d438f6535ead8fb5337f659654ea72e707a997258644414427dd0a967f1d62fd010e2020658de7dc9d53ff44f989620403e418716aa04719f43adad93ac5836c770cf7d"+ "'", var4.equals("3ddfa0f8526b23a43b3bece1bbabea36701a4634ad4129eaa9006359b7060120001a49b2b9793c848799af3c5387bc85b25fc44584769c4af1dc65f923519cc9aab4bd1b1d945627a248e0581b0aadbc3ebf39b9ccd4df345ac650ba4b95f4c28fa3b972251fb484c7f36ddd6acd77845e6acd787e3fbc5b833297dc591ce617f5bd5b67fa7338801ea125261f4bcdecc84ebba8ecc64e99337035ab8c9b6950999c61d484700f9f36409e192ddf2e9742dc00b99c312a42eb6d438f6535ead8fb5337f659654ea72e707a997258644414427dd0a967f1d62fd010e2020658de7dc9d53ff44f989620403e418716aa04719f43adad93ac5836c770cf7d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.861859813102019d);
// 
//   }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test348"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(0, 394);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-394));

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test349"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-0.8860078878357261d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-50.76451258828754d));

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test350"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(478);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test351"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0f);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test352"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp((-10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-9.999999f));

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test353"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(1.1125191124373863d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0271437797886374d);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test354"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(496.2674961884226d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test355"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(13.31102056604163d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test356"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(8.037850951474781E118d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999999999971d);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test357"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.8413447455561358d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6664608671166427d);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test358"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)290.6755890122055d, (java.lang.Number)(-0.8508150646900634d), false);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test359"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(365, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test360"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.907349E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9073493E-6f);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test361"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(305.69256826715235d, 1.8171205928321397d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 305.69796895140877d);

  }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test362"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     double var12 = var1.nextBeta(98.00138274241472d, 0.9984187364052811d);
//     double var15 = var1.nextUniform(4.61512051684126d, 57.348154628338996d);
//     int var18 = var1.nextSecureInt(0, 2147483647);
//     double var20 = var1.nextExponential(0.9942029313130951d);
//     long var23 = var1.nextLong(4966278053L, 5090545318414900353L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 448);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.9907234974617702d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 30.26498636310147d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1897811078);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.2168619666845195d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1739863065448450816L);
// 
//   }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test363"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(5, 394);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-389));

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test364"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, 1.088851945553895d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test365"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-0.845510966469498d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7681992604736713d));

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test366"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    var0.contract();
    double var12 = var0.addElementRolling((-0.9793091478686597d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var0.getElement((-47515));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test367"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-15), (-241));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3615);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test368"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.2196240406125857E-104d, 25.982010758645295d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test369"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var2 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.MathArithmeticException var4 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test370"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(14.766770929226206d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.585253074008742E-97d);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test371"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos((-0.05788914687716099d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.628717855095517d);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test372"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.9888097180963166d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1580069074881836d);

  }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test373"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-114.59155902616463d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test374"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     int var12 = var1.nextZipf(3, 0.949950589504148d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var14 = var1.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 97.24618424038464d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.894306250798081d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
// 
//   }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test375"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(1772309183L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1772309183L);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test376"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.9073489E-6f, (-9.999999f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.9073489E-6f));

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test377"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-0.5745141880897972d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test378"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(29.54554454270477d, 6.315930032722342E-37d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 29.54554454270477d);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test379"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(2894332613L, 8770513317L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5876180704L));

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test380"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    int var3 = var2.start();
    var2.addElement(0.0d);
    var2.setElement(394, 100.0d);
    int var9 = var2.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test381"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getNumericalMean();
    double var2 = var0.getStandardDeviation();
    boolean var3 = var0.isSupportLowerBoundInclusive();
    double var4 = var0.getSupportLowerBound();
    double var5 = var0.getSupportLowerBound();
    var0.reseedRandomGenerator(0L);
    var0.reseedRandomGenerator(0L);
    var0.reseedRandomGenerator(4461623939L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.NEGATIVE_INFINITY);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test382"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    int var9 = var6.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    java.lang.String var11 = var6.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "MAXIMAL"+ "'", var11.equals("MAXIMAL"));

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test383"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("MAXIMAL");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test384"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(100.0f, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 800.0f);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test385"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos((-0.35061555081998685d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 58.0833975668622d);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test386"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(1.1580069074881836d, 10.760549867472612d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.10149074529507818d);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test387"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    boolean var9 = var7.equals((java.lang.Object)10.015471524400919d);
    java.lang.Class var10 = var7.getDeclaringClass();
    boolean var12 = var7.equals((java.lang.Object)0.8775199269609161d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test388"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)0.4819216925681265d, (java.lang.Number)(-2.184599888317818d));

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test389"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.8524481817025479d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 14.528828146419674d);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test390"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-0.11095680770623403d), 566.8606652920801d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 566.8606652920801d);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test391"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getStandardDeviation();
    double var10 = var0.cumulativeProbability((-0.004920366423301847d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var0.cumulativeProbability(3.261925876230186d, 0.7970392056484709d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.4980370657191222d);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test392"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.7853981633974483d);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test393"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, 1.0000004f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test394"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.978735975787224d, (java.lang.Number)(-19.894922083922054d), false);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var8 = var6.addElementRolling(Double.NaN);
    double[] var9 = var6.getElements();
    int var10 = var6.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = var6.copy();
    java.lang.Object[] var12 = new java.lang.Object[] { var6};
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, var12);
    org.apache.commons.math3.exception.util.ExceptionContext var14 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test395"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(66475, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test396"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-0.07649303546991829d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.4244963546628366d));

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test397"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32.94631867978169d);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test398"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-1037414828), 447);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test399"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.8153332008031156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test400"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(208);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test401"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(7, (-15));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test402"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(8.958098027649932d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.135705341299635d);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test403"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(2L, (-8507354146L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8507354146L);

  }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test404"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.4980370657191222d, (java.lang.Number)0.2030609190654752d, true);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     java.lang.Object[] var6 = null;
//     org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var6);
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test405"); }


    double var2 = org.apache.commons.math3.special.Erf.erf((-12.844009081315292d), (-0.5885470223243282d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40522203508786114d);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test406"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(5002023);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5002023);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test407"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var14.contract();
    int var16 = var14.getExpansionMode();
    int var17 = var14.start();
    double[] var18 = var14.getElements();
    int var19 = var14.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test408"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(7344187125L, 6269712909L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test409"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)363.7393755555636d);
    java.lang.Number var2 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 363.7393755555636d+ "'", var2.equals(363.7393755555636d));

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test410"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.36792469441508013d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3600921148243623d);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test411"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(3118086304L, 7193097162L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-4075010858L));

  }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test412"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.5607966601082315d);
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var5 = var3.density(100.0d);
//     double var8 = var3.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double[] var10 = var3.sample(100);
//     double var11 = var3.getStandardDeviation();
//     double var13 = var3.cumulativeProbability((-0.004920366423301847d));
//     double var14 = var3.getNumericalVariance();
//     double var15 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var3);
//     double var17 = var3.cumulativeProbability(3.4965075614664802d);
//     double var19 = var3.inverseCumulativeProbability(0.0d);
//     double var21 = var3.density(0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.0947307979004006d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.4980370657191222d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2.393707586260566d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.9997643044330278d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.3989422804014327d);
// 
//   }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test413"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    java.lang.Class var8 = var7.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("AVERAGE");
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var13);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var16 = var15.getNumElements();
    int var17 = var15.start();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    int var21 = var18.getNumElements();
    double[] var22 = var18.getElements();
    var15.addElements(var22);
    var15.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var15, var27);
    var27.setElement(825, (-0.06991186090907374d));
    double[] var32 = var27.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var33 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var35 = var33.addElementRolling(Double.NaN);
    double[] var36 = var33.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var37 = new org.apache.commons.math3.util.ResizableDoubleArray(var36);
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray(var36);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var39 = var14.mannWhitneyU(var32, var36);
      fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
    } catch (org.apache.commons.math3.exception.NoDataException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test414"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.5631720610317434d, (java.lang.Number)0, false);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test415"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)4.937302184657956d);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test416"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var5 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var7 = var2.name();
    java.lang.Class var8 = var2.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var10 = java.lang.Enum.<java.lang.Enum>valueOf(var8, "c9a799ebc5eb133d278b3e8ab7fbad74dc66fc756bcec0a211566f48c835adc108e0b17b1aad782f91fcbb126d5cb0cee0675f2b694c9bbd915e1de1213f856d975fdbb67920c8c940bb9cf24099e34c82737431bbeddb6c8873f91c77a4a5b5c12982866675cceaa1ceae431108fc89c10b56667ee2c60efddfe752cba3980028cd9dbf3e45a7607428a392831be67863a84a99a9b13d5849a4cae436b673d3b73a4e31a9d0aad74f3f9ab5bd38818c61d1a4da76378887ac4");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "MAXIMAL"+ "'", var5.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test417"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.3039372168225922d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948966d);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test418"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var7 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var8 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var10 = var9.getNumElements();
    double[] var11 = var9.getInternalValues();
    double[] var14 = new double[] { 10.0d, 100.0d};
    double var15 = var8.mannWhitneyU(var11, var14);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    double var17 = var4.mannWhitneyU(var7, var11);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var20 = var19.getNumElements();
    double[] var21 = var19.getInternalValues();
    double[] var24 = new double[] { 10.0d, 100.0d};
    double var25 = var18.mannWhitneyU(var21, var24);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var26 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var28 = var27.getNumElements();
    double[] var29 = var27.getInternalValues();
    double[] var32 = new double[] { 10.0d, 100.0d};
    double var33 = var26.mannWhitneyU(var29, var32);
    double var34 = var4.mannWhitneyUTest(var21, var32);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var35 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var37 = var36.getNumElements();
    double[] var38 = var36.getInternalValues();
    double[] var41 = new double[] { 10.0d, 100.0d};
    double var42 = var35.mannWhitneyU(var38, var41);
    org.apache.commons.math3.util.ResizableDoubleArray var43 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var43.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var46 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var48 = var46.addElementRolling(Double.NaN);
    double[] var49 = var46.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var50 = new org.apache.commons.math3.util.ResizableDoubleArray(var49);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var43, var50);
    double[] var52 = var43.getElements();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var53 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var56 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var57 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var58 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var59 = var58.getNumElements();
    double[] var60 = var58.getInternalValues();
    double[] var63 = new double[] { 10.0d, 100.0d};
    double var64 = var57.mannWhitneyU(var60, var63);
    org.apache.commons.math3.util.ResizableDoubleArray var65 = new org.apache.commons.math3.util.ResizableDoubleArray(var60);
    double var66 = var53.mannWhitneyU(var56, var60);
    org.apache.commons.math3.util.ResizableDoubleArray var67 = new org.apache.commons.math3.util.ResizableDoubleArray(var56);
    org.apache.commons.math3.util.ResizableDoubleArray var68 = new org.apache.commons.math3.util.ResizableDoubleArray(var67);
    double var70 = var67.substituteMostRecentElement(0.3742437696541317d);
    org.apache.commons.math3.util.ResizableDoubleArray var71 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var71.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var74 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var76 = var74.addElementRolling(Double.NaN);
    double[] var77 = var74.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var78 = new org.apache.commons.math3.util.ResizableDoubleArray(var77);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var71, var78);
    double[] var80 = var71.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var81 = new org.apache.commons.math3.util.ResizableDoubleArray(var80);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var82 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var83 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var84 = var83.getNumElements();
    double[] var85 = var83.getInternalValues();
    double[] var88 = new double[] { 10.0d, 100.0d};
    double var89 = var82.mannWhitneyU(var85, var88);
    var81.addElements(var88);
    var67.addElements(var88);
    var43.addElements(var88);
    double var93 = var4.mannWhitneyU(var41, var88);
    double[] var94 = var1.rank(var88);
    org.apache.commons.math3.util.ResizableDoubleArray var95 = new org.apache.commons.math3.util.ResizableDoubleArray(var94);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var95.discardFrontElements(1164691958);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.024588566448858762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test419"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(9.0071987E15f, 1.0000004f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.0071987E15f);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test420"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-1.3599284608639345E8d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test421"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-1023), 0);
//     java.lang.String var6 = var1.nextSecureHexString(6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var1.nextZipf((-22), 1836.4208442309248d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-826));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "f9bc1c"+ "'", var6.equals("f9bc1c"));
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test422"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(3.639908707819057E63d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test423"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var13 = var1.nextGamma(0.0d, 98.00138274241472d);
//     double var16 = var1.nextUniform((-1.1364083366959243d), 0.7212254887267799d);
//     int[] var19 = var1.nextPermutation(10400, 208);
//     org.apache.commons.math3.distribution.IntegerDistribution var20 = null;
//     int var21 = var1.nextInversionDeviate(var20);
// 
//   }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test424"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.9400207386800911d, (java.lang.Number)(-0.007854005709676678d), false);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test425"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(7.60268502423026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1326918856648829d);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test426"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(363.7393755555636d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test427"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.9999991703434066d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.718279573219539d);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test428"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.001736111111111111d, 1.4329174706418153d, 0.0d);
    double var4 = var3.getNumericalVariance();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var3.cumulativeProbability(1827.7882294099632d, (-91.54140768425792d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0532524776705374d);

  }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test429"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     int[] var10 = var1.nextPermutation(124952017, 1);
//     int var13 = var1.nextSecureInt(5210, 7550);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 23.23097076460183d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 6347);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test430"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(1.3925240956605238d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.06907778333709402d));

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test431"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var12 = var1.nextChiSquare(0.001736111111111111d);
//     double var15 = var1.nextBeta(0.36792469441508013d, 0.23074612792124255d);
//     var1.reSeed((-6197319789L));
//     int var20 = var1.nextBinomial(5, 0.9738617129853937d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var1.nextUniform(4.726586641918333d, 0.0d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7422083662L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0027695691298619232d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 5);
// 
//   }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test432"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     java.lang.String var8 = var1.nextHexString(447);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4796346930L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "13faf4e843540d97f7135eafd0612303e73a3fedd8587b011d4be6383f79491d232316e5ce52d2a8e77b8329544e32b075518009b417bc5b1b0621da6b747fdcc89644759b75ecce3d47f69d8aed58bf65e1b3da00c1eeb4869ccb2bda412af2f2fbbcd62578a9d786fd4551cfae06fb6731ac0ae25861a3d87a043d162c12cad065b3990a6e638e928bfd628ded4d44765bfd4f29064b4491a5e5d696f1d9dac3901978179c762ed3acca271c55c56fc9e0518a5701b4b7a7bcdc04f80dc656d0313fef815ffe7f98084266bb9924bb3b33a348b2ad037308c3926ad207735"+ "'", var8.equals("13faf4e843540d97f7135eafd0612303e73a3fedd8587b011d4be6383f79491d232316e5ce52d2a8e77b8329544e32b075518009b417bc5b1b0621da6b747fdcc89644759b75ecce3d47f69d8aed58bf65e1b3da00c1eeb4869ccb2bda412af2f2fbbcd62578a9d786fd4551cfae06fb6731ac0ae25861a3d87a043d162c12cad065b3990a6e638e928bfd628ded4d44765bfd4f29064b4491a5e5d696f1d9dac3901978179c762ed3acca271c55c56fc9e0518a5701b4b7a7bcdc04f80dc656d0313fef815ffe7f98084266bb9924bb3b33a348b2ad037308c3926ad207735"));
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test433"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.9630652627338423d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.27263296215929816d);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test434"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed();
    double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
    var1.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSecureAlgorithm("org.apache.commons.math3.exception.NumberIsTooLargeException: -5 is larger than, or equal to, the maximum (1.987)", "bc047f1d52145d6b18f7989e36f7050010919cbdc0842f3d274c0f4de21770d2d21b4e49de45f2302e40da1278ea394acf8411f589012c5aac3d94c9cc286ecac8f06b956f3c26f1103faeb87fe8e3f5b1d0c7f1faa3918056c076249bbbee4b27b045ac4f26ee6d0e0683c1c23f56a418cea360aed581f941e2c622b44a4a99ccc1421cca24169581d81094f2922ec361101812760cda39f20da6d44e617f67335bf5d95e186294673b5512a54122a06a378f6a469a80c381b");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test435"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)5210);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test436"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.34623503969787806d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test437"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1078421185, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1078421185);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test438"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(1.1095904140014483d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1095904140014485d);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test439"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(57.348154628338996d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test440"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-1.119001993201958d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.038190267727028d));

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test441"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.9117361753569404d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9117361753569404d);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test442"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-11.0d), var1, false);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test443"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(97.7168344002981d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.592255493195391d);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test444"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.7100683659172744d, (java.lang.Number)Float.POSITIVE_INFINITY, (java.lang.Number)(byte)0);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    java.lang.Number var5 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)0+ "'", var5.equals((byte)0));

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test445"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(396, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 396);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test446"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.9999999988953957d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13.147780284820104d);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test447"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    double var4 = var0.addElementRolling(100.28868834094156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test448"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var11 = var10.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    int var15 = var12.getNumElements();
    double[] var16 = var12.getElements();
    var10.addElements(var16);
    var0.addElements(var16);
    float var19 = var0.getExpansionFactor();
    var0.clear();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var23 = var22.getNumElements();
    double[] var24 = var22.getInternalValues();
    double[] var27 = new double[] { 10.0d, 100.0d};
    double var28 = var21.mannWhitneyU(var24, var27);
    org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    var0.addElements(var24);
    var0.clear();
    int var32 = var0.getExpansionMode();
    boolean var34 = var0.equals((java.lang.Object)0.30353390504256844d);
    var0.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardFrontElements(128);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test449"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(4.5E-44f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test450"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.start();
    double[] var2 = var0.getElements();
    var0.setContractionCriteria(15.999999f);
    float var5 = var0.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 15.999999f);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test451"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(293, 6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 299);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test452"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Throwable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError();
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var4, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)(short)(-1), (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test453"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    java.lang.String var7 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var10 = var9.getNumElements();
    double[] var11 = var9.getInternalValues();
    int var12 = var9.getNumElements();
    double[] var13 = var9.getInternalValues();
    var9.setContractionCriteria(7.5557864E22f);
    double[] var16 = var9.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var17 = var8.rank(var16);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test454"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    int var10 = var9.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    java.lang.Class var21 = var20.getDeclaringClass();
    org.apache.commons.math3.random.RandomGenerator var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var22);
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test455"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 7.546079582067821d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test456"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(447, (-0.99999994f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test457"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-273));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test458"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getMean();
//     double var2 = var0.getNumericalVariance();
//     double var3 = var0.sample();
//     boolean var4 = var0.isSupportConnected();
//     double var7 = var0.cumulativeProbability((-0.043481143175376734d), 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.7372917518530686d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.017341002062646303d);
// 
//   }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test459"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.5186207998179818d, 0.6139648708421599d, 0.9999991703434066d, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.3346772396068781d);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test460"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-12.844009081315292d), 0.1665864075690343d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.5578270843725532d));

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test461"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, 0.5186207998179818d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.9E-324d);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test462"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(4298531835L, 1164691958);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5151373706911137609L);

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test463"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     double var9 = var1.nextT(1.5855819012757701d);
//     double var12 = var1.nextCauchy((-1.8456016649756868d), 4.9E-324d);
//     double var15 = var1.nextGaussian((-0.014542775949576744d), 42.68079794095493d);
//     var1.reSeedSecure(7193097162L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("d5fc14aa2ed998444ddec040203959cb024aac091c2a54abadd4616d3dc46e3785360e806b57bd4a5d222ee95055e024fadd104b99f1b09738ce4d8450f09171eaf68e4a1fa3de00fd4fbb8330eb15eb0a03d83e4df9b4b2c202db1cdbc53ff708ec302699a43295890658cb0e27da4721b37db8f36e397b284daa98c5c1e68830d44a7f7388785a0bfb77f9886208d093c121d14578e3641efadf355062c309368e3cc2a2c11a6d345633223ad729d257a9f3995aee84d4403460fd88803c32db5421e1023ed22b701885a536a975131f3f828e4ca527bdec2d41493287f414b5e4574fa20ea99c0f9924566f05ccfaa5f38b1a800d57402811", "fc6d925b01828989e392528be7f0dcac1cc2994e3951a299c98dd5659d5e2bc48f777dee87e82e1ba3edb7e91be607d4905d72674237d4cb2bfdc2b40769e2a34e4cdc5ac85fdec5007306b8aaa36b111032ad64d0820acec1b98c0687d363a95050d8d651600d641a13f3e7d6815b708b11f6f7959a4ab48311648163bf18600c897316651b93d6e84731557e553a96b3384c27569ddfcd7b4d971b51963849790cb016487f112d8510ce72f32f8c61c2bda2e406e84ef5ae998abb3f2ff316a32c1a51e48ff40b3f510090607958cacc13c2fe0d07fe987aacc76dba8ab8227076ae615cf1f283f7735fe7cefe2f4915a0dc938a4e3ab2c390");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 18.580177738188755d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.4118705640395386d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1.8456016649756868d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-5.431296727818501d));
// 
//   }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test464"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(4797469069L, 6926386580L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test465"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 506);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test466"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.570446610624454d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test467"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    double[] var2 = var1.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addElement(5.205744238502723d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test468"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.5387285847291196d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5387285847291197d);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test469"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(0, (-22));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test470"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(112, 343);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5488);

  }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test471"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-0.9422952790472405d), (-6.545752664888063d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test472"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    int var10 = var9.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var21);
    int var23 = var20.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test473"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed();
    var1.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var1.nextZipf(10, (-1.5707963267948966d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test474"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var2 = var1.getNumElements();
    double[] var3 = var1.getInternalValues();
    double[] var6 = new double[] { 10.0d, 100.0d};
    double var7 = var0.mannWhitneyU(var3, var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    double var10 = var8.substituteMostRecentElement(2.9690791410915276d);
    var8.setContractionCriteria(15.999999f);
    double var14 = var8.addElementRolling(0.9887895297451168d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test475"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-7), 16938270);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16938263);

  }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test476"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var8 = var1.nextWeibull(0.7853981633974483d, 4.787491742782046d);
//     double var10 = var1.nextExponential(0.3971622936791505d);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var11.getMean();
//     double var15 = var11.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var16 = var11.getSupportUpperBound();
//     double var17 = var11.getNumericalMean();
//     double var18 = var11.getSupportUpperBound();
//     double var19 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 9.386213706252116d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.3244779830220503d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.0879808731407483d);
// 
//   }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test477"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)31.98437118343895d, (java.lang.Number)10L, false);
//     java.lang.String var5 = var4.toString();
//     java.lang.Number var6 = var4.getArgument();
//     java.lang.Throwable[] var7 = var4.getSuppressed();
//     org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var8);
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test478"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.0242563501897255d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.010408665174662695d);

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test479"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var13 = var1.nextUniform(0.9999943487368532d, 44.5140274520795d);
//     double var15 = var1.nextChiSquare(51.55677237552102d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var17 = var1.nextPoisson((-0.016386819051824476d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6096248752L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 34.18103747324713d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 51.384769008260996d);
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test480"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.5888086037254829d, 31.19644594989976d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6.495379117362055d));

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test481"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test482"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(6012983238L, 9617852648L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test483"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-0.22437127068337848d), 0.7172507104665835d, 3.123726322776123E-196d, 102300);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test484"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(2.2775409356853094d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test485"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(2383204267L, 182642376L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 435274089818218392L);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test486"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.9887895297451168d, 5.6843418860808015E-14d, (-0.22437127068337848d), (-20));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test487"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-0.99980507052264d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7615122784225812d));

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test488"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.9985619410825101d, (java.lang.Number)29.54554454270477d, true);
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-57.29577951308232d), (java.lang.Number)0L, true);
    boolean var8 = var7.getBoundIsAllowed();
    java.lang.Number var9 = var7.getMin();
    var3.addSuppressed((java.lang.Throwable)var7);
    org.apache.commons.math3.exception.util.ExceptionContext var11 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 0L+ "'", var9.equals(0L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test489"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(43.120630495197474d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.3339861078542111E18d);

  }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test490"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     var1.reSeed(4448708814L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextUniform(43.26302966078136d, 13.147780393007714d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 273);
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test491"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.5888086037254829d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6678315153102631d);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test492"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.7100683659172744d, (java.lang.Number)307.0027056045166d, false);
    java.lang.Number var5 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 307.0027056045166d+ "'", var5.equals(307.0027056045166d));

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test493"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var11 = var10.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    int var15 = var12.getNumElements();
    double[] var16 = var12.getElements();
    var10.addElements(var16);
    var0.addElements(var16);
    float var19 = var0.getExpansionFactor();
    var0.clear();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var23 = var22.getNumElements();
    double[] var24 = var22.getInternalValues();
    double[] var27 = new double[] { 10.0d, 100.0d};
    double var28 = var21.mannWhitneyU(var24, var27);
    org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    var0.addElements(var24);
    var0.clear();
    var0.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 32.0d);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test494"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(66495);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test495"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 1967051285);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test496"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    int var4 = var0.getNumElements();
    float var5 = var0.getExpansionFactor();
    var0.setElement(371, 6.061237093357864d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.0f);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test497"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(7220072592L, 3773985329L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test498"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(3.40428888768425d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 15.029829123697283d);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test499"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(5210, 5210);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5210);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test500"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(19.591234255406928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

}
