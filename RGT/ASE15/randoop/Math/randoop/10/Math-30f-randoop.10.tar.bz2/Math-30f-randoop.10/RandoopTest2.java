
import junit.framework.*;

public class RandoopTest2 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test1"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.8998354296541002d, 0.9999943487368532d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.10015891908275298d));

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test2"); }


    long var1 = org.apache.commons.math3.util.FastMath.round((-0.5745141880897972d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1L));

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test3"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getMean();
//     double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var7 = var0.cumulativeProbability(4.158638853279167d, 24.0d);
//     double var8 = var0.sample();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var10 = var0.sample(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.600747998428365E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1.707889741874053d));
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test4"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(4.0d, 0.7212254887267799d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.23573885556858495d));

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test5"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-0.6000588730884988d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5688753813335342d));

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test6"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(3.4965075614664802d, (-347));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2196240406125857E-104d);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test7"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(9617852649L, 1772309183L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test8"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getNumericalMean();
    boolean var2 = var0.isSupportLowerBoundInclusive();
    var0.reseedRandomGenerator(14066561462L);
    double[] var6 = var0.sample(50);
    double var8 = var0.probability(5.129537890492898E-16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test9"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(8770513317L, 7969628972L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test10"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     int var12 = var1.nextZipf(3, 0.949950589504148d);
//     org.apache.commons.math3.distribution.IntegerDistribution var13 = null;
//     int var14 = var1.nextInversionDeviate(var13);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test11"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.4251878220010183d, (java.lang.Number)3.3881317890172014E-21d, true);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test12"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(44.5140274520795d, 0.7303807294278502d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0827727942692622d));

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test13"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.03497161846995667d, 1.7100683659172744d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.944965986224098d);

  }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test14"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-0.06991186090907374d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test15"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test16"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test17"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    java.lang.Class var7 = var6.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = var8.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var8.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
    int var14 = var13.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.NaNStrategy var18 = var17.getNanStrategy();
    java.lang.Class var19 = var18.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var21);
    org.apache.commons.math3.stat.ranking.TiesStrategy var25 = var24.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var26 = var24.getNanStrategy();
    java.lang.String var27 = var26.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "MAXIMAL"+ "'", var27.equals("MAXIMAL"));

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test18"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(6.785121971699368E-66d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.785121971699368E-66d);

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test19"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextCauchy(0.8775199269609161d, 0.6387763808612118d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var6 = var1.nextPoisson((-7.2481055478477545d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 3.886621862956244d);
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test20"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.03497161846995667d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.03496449044211574d);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test21"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(10, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test22"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(4.066427732325669d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9994127159589543d);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test23"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-15));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test24"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-17), 210);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3570);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test25"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.9738617129853937d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test26"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)10);
//     java.lang.String var3 = var2.toString();
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test27"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(9900, 9900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test28"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(210.0d, 2.2737367544323206E-13d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test29"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(3.0414093201713884E64d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7439636808636205E32d);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test30"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-1078420975));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test31"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var8 = var1.nextWeibull(0.7853981633974483d, 4.787491742782046d);
//     double var11 = var1.nextWeibull(1.315149049454551d, 1.3973342048086457d);
//     org.apache.commons.math3.distribution.IntegerDistribution var12 = null;
//     int var13 = var1.nextInversionDeviate(var12);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test32"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var1.nextPoisson((-1.763487655683845d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test33"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed();
    double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSecureAlgorithm("29ed70f13bb7ad46f460186017e66097afb29425604f5ce6013aad50de27d1839ff38fefaf3024af2bb9c35db46ea9c1b39661db566c4d93ea5216e953f75608d761042d1d7c9f403ec945d2001667c7a7f1c60a14dfa3dc14b0957c90ba09741079085e8fe6ccff26bdbacc78c5ea6a12ce9921226c8dafc77c6bf83eeb751c6c26b9106d132d65504085de89e5a33d2dd3eb3d94e4d24877cc029b0895942a75b870c541f8bbbfd706029c3eea54aa1c278df2c7ec627a0b8ee3b72226b99fc483c806033dc210779f83cca2ed3a7245136fa3e9feba8009f2f6e62059c4e19dd78f68b4180a5327a52e8415f7dd4e0113efa08ba9649dba06", "4bffd0a0022bc47a4d81261b9c970bff2fa315bf21ff1fc053bd6f5b61ea543c2c195653a0295f802ba711a290a052ffe5dbbd18040ec2cd9563f46f2ab4cb8cba00e625b5014bea2a9a5c63b69d0b3e3e1c373a708349bdd07e6de4860c15071c56e0b56b7a5bf2ce6525d81b3e5fcb721b8f2a4831dba1f3bc51f610d65d54e9f841a7b31c013194fe981a329afb9529a094e5886a3c8b0664be276df2abb6cae438f9e245addaa753394cf0db0cfa22abeabc603a21280a46cc15e7bc4e4cac1d79ab6ea8b1eb79416fd57fe4de243a3efaa6111ca1891103f5e9ea5bdd5f6ed648c92f7d4ae8998061a5cf4bf77aedb7b2b63b5ec4ad8276");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test34"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc((-0.7552433890658253d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7145135182272309d);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test35"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.876407757475359d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test36"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.7212254887267799d, (-0.9097224269009427d), 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test37"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(10.567764688902704d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11L);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test38"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(1.5707312477445605d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5707312477445605d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test39"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(4.61512051684126d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.615120516841259d);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test40"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(2.9690791410915276d, 1.82442736154459d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7172507104665835d);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test41"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     int var8 = var1.nextInt((-347), 300);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextPascal(208, Double.NEGATIVE_INFINITY);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 68);
// 
//   }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test42"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(0.999987895021552d, 15.322095332102348d, false);
//     double var8 = var1.nextGamma(1.4713540043352986d, 4.787491742782046d);
//     double var10 = var1.nextExponential(16.636486299878868d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var1.nextHypergeometric(0, 394, 9900);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.9980012211563225d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 16.095274400076097d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.6482578036660083d);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test43"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.11079388629258953d, 57.348154628338996d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.11079388629258953d);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test44"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     int var12 = var1.nextZipf(3, 0.949950589504148d);
//     var1.reSeedSecure();
//     var1.reSeedSecure(4448708814L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var18 = var1.nextLong((-1L), (-1L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 98.92583732051428d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4.460104044339012d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test45"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    java.lang.String var4 = var2.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "MAXIMAL"+ "'", var4.equals("MAXIMAL"));

  }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test46"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.999987895021552d, (java.lang.Number)0.9999999978823586d, false);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test47"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(2.3104273163924094d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test48"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(19430.854290467407d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 19431.0d);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test49"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.start();
    double var3 = var0.addElementRolling(4.937302184657956d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.substituteMostRecentElement(0.024588566448858762d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test50"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(295, (-1.26765045E30f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test51"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test52"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.05782461145270825d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test53"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getNumericalMean();
    double var2 = var0.getStandardDeviation();
    boolean var3 = var0.isSupportConnected();
    boolean var4 = var0.isSupportLowerBoundInclusive();
    double var5 = var0.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test54"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, 3.7621956910836314d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test55"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextSecureHexString(6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var5 = var1.nextPoisson((-12.575882963917257d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "fad542"+ "'", var3.equals("fad542"));
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test56"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-0.010152952316618155d), 1.7100683659172744d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.010152952316618155d));

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test57"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 825);
// 
//   }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test58"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(0.999987895021552d, 15.322095332102348d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var8 = var1.nextSecureLong((-9L), (-9L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 11.732592426146736d);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test59"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)10);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test60"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(572.9577951308232d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7581226324091723d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test61"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.9135022946042973d, 0.9000039605473131d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.006693634914056834d));

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test62"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs((-3.7625250955428156d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.7625250955428156d);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test63"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.588243686000456d, (-614984.3812522552d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 614984.3812525364d);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test64"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(3.7621956910836314d, 44.5140274520795d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.7621956910836314d);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test65"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.toRadians(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test66"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp((-1.0000001f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1920929E-7f);

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test67"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     var1.reSeed();
//     double var10 = var1.nextBeta(31.984371183438952d, 3.141592653589793d);
//     var1.reSeed();
//     double var14 = var1.nextGaussian(2.148147810647578d, 24.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var16 = var1.nextSecureHexString((-11));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9143803811433965d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-42.34497930947103d));
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test68"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.7303807294278502d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test69"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(11.790640008884495d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4861857760130848d);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test70"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var8 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var11 = var10.getNumElements();
    double[] var12 = var10.getInternalValues();
    double[] var15 = new double[] { 10.0d, 100.0d};
    double var16 = var9.mannWhitneyU(var12, var15);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    double var18 = var5.mannWhitneyU(var8, var12);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    double[] var20 = var4.rank(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test71"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.start();
    double[] var2 = var0.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardFrontElements(825);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test72"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(63.98437118343895d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 63.98437118343895d);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test73"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    double var17 = var14.substituteMostRecentElement(0.3742437696541317d);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var18.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var23 = var21.addElementRolling(Double.NaN);
    double[] var24 = var21.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var18, var25);
    double[] var27 = var18.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(var27);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var31 = var30.getNumElements();
    double[] var32 = var30.getInternalValues();
    double[] var35 = new double[] { 10.0d, 100.0d};
    double var36 = var29.mannWhitneyU(var32, var35);
    var28.addElements(var35);
    var14.addElements(var35);
    var14.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setExpansionMode((-11));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 32.0d);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test74"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.6260590822656884E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-20));

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test75"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(byte)(-1), (java.lang.Number)(short)1, true);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.lang.Object[] var11 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var9, var11);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var8, var11);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var7, var11);
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var6, var11);
    org.apache.commons.math3.exception.NullArgumentException var16 = new org.apache.commons.math3.exception.NullArgumentException(var5, var11);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var11);
    java.lang.Throwable[] var18 = var17.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test76"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-10681828717L), 3123671065L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test77"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    var0.reseedRandomGenerator((-2502316609L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test78"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(31.98437118343895d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test79"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(3.7625250955428156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.440892098500626E-16d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test80"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.1354528887171666d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.13463348377254322d);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test81"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("dcacc6a03b1f1fb215ff82a5fdef47c79d07cae35a5bd7145e7b76189ca8832cc5cd174c70831fe56d18fc82117740dafedc02e5ff7eed6846be354b3a767e08e906b3a8cf0d4d0520eff3d875adf46f1df3b7db5fa6a4fa06e351ce630ab6bde3e4216dd32756280f18989947b2223eea24f3d9fa163897ef2fe2656dcd80a8f056dbf9c538ae187acb931565423433e1290fcfd90ce7ad8689a3c449ee3c9390924eb4522e518e5f7c85bd0040d0921084defd213932397490948330712f3411ea9971080126388b4110cc5189781e2c139b165f9e7945eeba41861136a22e0c7d35d1b5f8bf3adb5594603540c467dc690a6c636a103dfdda451ad6");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test82"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-17));

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test83"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var3 = var2.getNumElements();
    double[] var4 = var2.getInternalValues();
    int var5 = var2.getNumElements();
    double[] var6 = var2.getElements();
    var0.addElements(var6);
    float var8 = var0.getContractionCriteria();
    float var9 = var0.getContractionCriteria();
    float var10 = var0.getExpansionFactor();
    var0.addElement(1.022519701004396d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var0.getElement(506);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test84"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)118.41771345769118d);

  }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test85"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextSecureHexString(6);
//     org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var5 = var4.getNumericalMean();
//     double var6 = var4.getStandardDeviation();
//     boolean var7 = var4.isSupportLowerBoundInclusive();
//     boolean var8 = var4.isSupportUpperBoundInclusive();
//     double var9 = var4.getStandardDeviation();
//     double var10 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var4);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var11.getMean();
//     double var15 = var11.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var16 = var11.getSupportUpperBound();
//     double var17 = var11.getSupportUpperBound();
//     double var18 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var22 = var1.nextUniform(13.31102056604163d, (-0.8508150646900634d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "a80c0e"+ "'", var3.equals("a80c0e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.5434956261939445d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.9451309596642935d));
// 
//   }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test86"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, (java.lang.Number)119.31703692887734d, false);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test87"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3, 3520920158L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1271720519));

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test88"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test89"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(4448708814L, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4448708824L);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test90"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(210);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 210);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test91"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(124952017);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test92"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.999999950276072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.999999950276072d);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test93"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(3.123616354820892d, (-0.0075206657143111755d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0084760157976542d));

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test94"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(2.6498507619080125d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9998213620467383d);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test95"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)3);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test96"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    int var10 = var9.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    java.lang.Class var21 = var20.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var23 = java.lang.Enum.<java.lang.Enum>valueOf(var21, "hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test97"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.13463348377254322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7755575615628914E-17d);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test98"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.006537325533411519d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.00737647685836467d);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test99"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(4448708814L, (-6197319789L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4448708814L);

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test100"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma((-6.553799664953454d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test101"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-614984.3812522552d), 0.001736111111111111d, 1.5395412382954017d, (-5));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test102"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(6.3611093629270335E-15d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test103"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    float var6 = var5.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setExpansionFactor(4.6E-44f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.49999f);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test104"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-2502316609L), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test105"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(290.6755890122055d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.6843418860808015E-14d);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test106"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(7.8492444081989055d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8948278522683608d);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test107"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(1.4713540043352986d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test108"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     double var9 = var1.nextT(1.5855819012757701d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var1.nextHypergeometric((-15), 300, 10400);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 9.251300875101993d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.17881517599325042d);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test109"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var16 = var15.getNumElements();
    double[] var17 = var15.getInternalValues();
    double[] var20 = new double[] { 10.0d, 100.0d};
    double var21 = var14.mannWhitneyU(var17, var20);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var23 = var22.getNumElements();
    double[] var24 = var22.getInternalValues();
    double var25 = var0.mannWhitneyUTest(var17, var24);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var26 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var29 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var30 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var32 = var31.getNumElements();
    double[] var33 = var31.getInternalValues();
    double[] var36 = new double[] { 10.0d, 100.0d};
    double var37 = var30.mannWhitneyU(var33, var36);
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray(var33);
    double var39 = var26.mannWhitneyU(var29, var33);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var40 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var41 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var42 = var41.getNumElements();
    double[] var43 = var41.getInternalValues();
    double[] var46 = new double[] { 10.0d, 100.0d};
    double var47 = var40.mannWhitneyU(var43, var46);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var48 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var49 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var50 = var49.getNumElements();
    double[] var51 = var49.getInternalValues();
    double[] var54 = new double[] { 10.0d, 100.0d};
    double var55 = var48.mannWhitneyU(var51, var54);
    double var56 = var26.mannWhitneyUTest(var43, var54);
    org.apache.commons.math3.stat.ranking.TiesStrategy var57 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var58 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var57);
    org.apache.commons.math3.stat.ranking.NaNStrategy var59 = var58.getNanStrategy();
    int var60 = var59.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var61 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var59);
    org.apache.commons.math3.stat.ranking.TiesStrategy var62 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var63 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var62);
    org.apache.commons.math3.stat.ranking.NaNStrategy var64 = var63.getNanStrategy();
    java.lang.Class var65 = var64.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var66 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var64);
    org.apache.commons.math3.stat.ranking.TiesStrategy var67 = var66.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var68 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var59, var67);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var69 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var70 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var71 = var70.getNumElements();
    double[] var72 = var70.getInternalValues();
    double[] var75 = new double[] { 10.0d, 100.0d};
    double var76 = var69.mannWhitneyU(var72, var75);
    double[] var77 = var68.rank(var75);
    double var78 = var0.mannWhitneyUTest(var43, var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.024588566448858762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0.024588566448858762d);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test110"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-347), (-1271720519));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test111"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum((-1.315149049454551d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test112"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var14.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test113"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    var0.setNumElements(0);
    double var6 = var0.addElementRolling(0.0d);
    int var7 = var0.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionMode(300);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test114"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextChiSquare(0.6139648708421599d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextUniform(14.534682406958717d, 4.082560026975774d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03814314215888091d);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test115"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(5.381455886543763d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 108.67153323312886d);

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test116"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     var1.reSeed(4448708814L);
//     long var13 = var1.nextPoisson(0.30353390504256844d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var1.nextHypergeometric(394, (-347), (-1096480911));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 379);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0L);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test117"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var3 = var2.getNumElements();
    double[] var4 = var2.getInternalValues();
    int var5 = var2.getNumElements();
    double[] var6 = var2.getElements();
    var0.addElements(var6);
    float var8 = var0.getContractionCriteria();
    float var9 = var0.getContractionCriteria();
    float var10 = var0.getExpansionFactor();
    var0.addElement(1.022519701004396d);
    double var14 = var0.getElement(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.022519701004396d);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test118"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(7.8492444081989055d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.8016503008403646d);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test119"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-2L), 3384732745L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6769465490L);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test120"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(6, 3570);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3570);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test121"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(2.562034708930776d, (-0.5063656411097588d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6210214343458166d);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test122"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    double[] var17 = new double[] { 10.0d, 100.0d};
    double var18 = var11.mannWhitneyU(var14, var17);
    var10.addElements(var17);
    var10.setContractionCriteria(2.0f);
    var10.addElement(0.5587178359296467d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 32.0d);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test123"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(200.94444231998796d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.996181835373871d);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test124"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-0.07046473534579971d), 1.600747998428365E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.07046473534579971d);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test125"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var16 = var15.getNumElements();
    double[] var17 = var15.getInternalValues();
    double[] var20 = new double[] { 10.0d, 100.0d};
    double var21 = var14.mannWhitneyU(var17, var20);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var23 = var22.getNumElements();
    double[] var24 = var22.getInternalValues();
    double var25 = var0.mannWhitneyUTest(var17, var24);
    double[] var26 = null;
    org.apache.commons.math3.distribution.NormalDistribution var27 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var29 = var27.density(100.0d);
    double var32 = var27.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var34 = var27.sample(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var35 = var0.mannWhitneyUTest(var26, var34);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test126"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     int var3 = var2.ordinal();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
//     java.lang.Class var7 = var6.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var9 = var8.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var8.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var11 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
//     int var14 = var13.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var16 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var18 = var17.getNanStrategy();
//     java.lang.Class var19 = var18.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var21);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var21);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var21);
//     java.lang.String var25 = var21.name();
//     org.apache.commons.math3.random.RandomGenerator var26 = null;
//     org.apache.commons.math3.random.RandomDataImpl var27 = new org.apache.commons.math3.random.RandomDataImpl(var26);
//     var27.reSeed();
//     double var31 = var27.nextGamma(0.0d, 29.9749466411613d);
//     var27.reSeedSecure();
//     int var35 = var27.nextInt((-15), 500);
//     var27.reSeed(3384732745L);
//     boolean var38 = var21.equals((java.lang.Object)3384732745L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + "AVERAGE"+ "'", var25.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 317);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
// 
//   }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test127"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     double var9 = var1.nextT(1.5855819012757701d);
//     double var12 = var1.nextGaussian((-0.7323676290027762d), 13.753533396481055d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var1.nextLong(6769465490L, 3628800L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 17.905035645704004d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.5468721496941924d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-21.380805694340264d));
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test128"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-0.6321205588285577d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5961722400471147d));

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test129"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var4 = var0.density(4.937302184657956d);
    boolean var5 = var0.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0301213984251357E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test130"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(3628800.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test131"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 7.003858422556992d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test132"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var2 = var0.density(100.0d);
//     double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double var6 = var0.sample();
//     double var7 = var0.getNumericalMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.8456016649756868d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test133"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    var0.setNumElements(0);
    double var6 = var0.addElementRolling(0.0d);
    int var7 = var0.start();
    int var8 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(500);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setContractionCriteria(Float.NEGATIVE_INFINITY);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test134"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.4713540043352986d, (java.lang.Number)99.99999f, true);

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test135"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var8 = var1.nextCauchy(1.0d, 4.427429051327539d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 5.030848588936542d);
// 
//   }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test136"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-0.9985753080512595d), 1.5707312477445605d, 0.5978309394171295d, 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test137"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(1827.7882294099632d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.5114088567829365d);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test138"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(300, 10400);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10400);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test139"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(394, 2.5f, 0.0f, 2147483647);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test140"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(3520920158L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test141"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.99999994f, 16.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16.0f);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test142"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 78.0922235533153d);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test143"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(6.315930032722342E-37d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.3159300327223424E-37d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test144"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.05788914687716099d), (java.lang.Number)100.49999f, false);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 100.49999f+ "'", var4.equals(100.49999f));

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test145"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(0.74492045144808d, (-0.05624376415137876d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test146"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter((-1.0f), 2.322219294733919d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.99999994f));

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test147"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var4 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)4.158638853279167d, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test148"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportLowerBound();
    double var2 = var0.getNumericalMean();
    double var4 = var0.cumulativeProbability(5.205744238502723d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.9999999033896889d);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test149"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    float var4 = var0.getExpansionFactor();
    int var5 = var0.start();
    var0.setElement(0, (-1.9999999999999998d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardMostRecentElements(1078421185);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test150"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-1023), 0);
//     java.lang.String var6 = var1.nextSecureHexString(6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var1.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-450));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "392475"+ "'", var6.equals("392475"));
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test151"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(208, (-6197319789L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test152"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(62472.0d, 307.0027056045166d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5186207998179818d);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test153"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-0.2554932247505838d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.032816324840946d);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test154"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var11 = var9.addElementRolling(Double.NaN);
    double[] var12 = var9.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var6, var13);
    double[] var15 = var6.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    double[] var23 = new double[] { 10.0d, 100.0d};
    double var24 = var17.mannWhitneyU(var20, var23);
    var16.addElements(var23);
    var5.addElements(var23);
    var5.discardFrontElements(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setNumElements((-1096480911));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 32.0d);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test155"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextBeta(0.0d, 4.078793624253461d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 97.72731592638026d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 5.137508920753372d);
// 
//   }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test156"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.lanczos(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test157"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(500);
    var1.setContractionCriteria(3.4028233E38f);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test158"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(9.999999999999998d, 0.3989422804014327d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.999999999999996d);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test159"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(3520920158L, 11L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3520920169L);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test160"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(15.999999f, (-1.2676506E30f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 15.999999f);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test161"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.007825974595901458d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test162"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(5.996181835373871d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.81673506295471d);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test163"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(4.078793624253461d, (-1.9200849871876335d), 1.978735975787224d, 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test164"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var5 = var1.nextPoisson(0.9720449790817591d);
//     double var7 = var1.nextChiSquare(5.65362408791435d);
//     double var10 = var1.nextCauchy((-0.23573885556858495d), 1.8525291623715519d);
//     java.lang.String var12 = var1.nextSecureHexString(10400);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var1.nextLong(5769050335L, (-10L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3.985976332141468d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2.286202986135872d);
// 
//   }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test165"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var5 = var1.nextPoisson(0.9720449790817591d);
//     double var7 = var1.nextChiSquare(5.65362408791435d);
//     double var10 = var1.nextCauchy((-0.23573885556858495d), 1.8525291623715519d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var1.nextUniform(3.986896366226194d, 0.1956370598145772d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 11.663651121090966d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.15633676772318153d);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test166"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5707963267948966d);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test167"); }


    java.math.BigInteger var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, (-17));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test168"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(3628800.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test169"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.6387763808612118d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.564065828779884d);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test170"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1827.7882294099632d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test171"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(3520920158L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3520920158L);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test172"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(9900, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test173"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial((-20));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test174"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.5707312477445605d, (java.lang.Number)45.35870170400007d, true);

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test175"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var8 = var1.nextWeibull(0.7853981633974483d, 4.787491742782046d);
//     double var11 = var1.nextWeibull(1.315149049454551d, 1.3973342048086457d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var1.nextSecureInt(500, (-1078420975));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.6798728324075474d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.23300498817242196d);
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test176"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.034957368513597445d);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test177"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(500, (-15));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7500));

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test178"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(19431.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.288495151773556d);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test179"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test180"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    var0.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setNumElements((-347));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test181"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(3.0d, 0.3063909472492726d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4690188987035586d);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test182"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(1.4251878220010183d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4251878220010183d);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test183"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.5690509993150914d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test184"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (100) exceeded");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test185"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)Double.NaN, (java.lang.Number)0.6139648708421599d, true);
    java.lang.Number var4 = var3.getMax();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.NotPositiveException var9 = new org.apache.commons.math3.exception.NotPositiveException(var7, (java.lang.Number)0);
    java.lang.Object[] var10 = new java.lang.Object[] { 0};
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var6, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, var10);
    java.lang.Number var13 = var3.getMax();
    java.lang.Number var14 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.6139648708421599d+ "'", var4.equals(0.6139648708421599d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 0.6139648708421599d+ "'", var13.equals(0.6139648708421599d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 0.6139648708421599d+ "'", var14.equals(0.6139648708421599d));

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test186"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.3841858E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-22));

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test187"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(10000000000L, (-241));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test188"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(100.0d, 0.03497161846995667d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.570446610624454d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test189"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(11L, (-9L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test190"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(300, (-1023));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 300);

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test191"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     java.lang.String var5 = var1.nextSecureHexString(371);
//     long var8 = var1.nextSecureLong(0L, 8179512108L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextSecureInt(0, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "343586fdecde49906cc67e5032b85bfabf81842e546c9ed6ddc8f509522eea8be70a0c7de7ed782c0b5ad587b29ee2f495870eebcc38532743e03cd15a48d48d9abaa663aa9789711469f161a06dcf51a1f156587ced1533ec28b57108fe220109d930cddc783f3bc79eedbffe4fc47477dbedf24d28d52c4c469c5e655d14c509965d1d88fe05ee5360371cb8bf2a2fa1a77fb60630a51e65c8dac5c959e5945b8dbbd80e9ceb86f7aee999b79f1d29ec1db4688241e9d7156"+ "'", var5.equals("343586fdecde49906cc67e5032b85bfabf81842e546c9ed6ddc8f509522eea8be70a0c7de7ed782c0b5ad587b29ee2f495870eebcc38532743e03cd15a48d48d9abaa663aa9789711469f161a06dcf51a1f156587ced1533ec28b57108fe220109d930cddc783f3bc79eedbffe4fc47477dbedf24d28d52c4c469c5e655d14c509965d1d88fe05ee5360371cb8bf2a2fa1a77fb60630a51e65c8dac5c959e5945b8dbbd80e9ceb86f7aee999b79f1d29ec1db4688241e9d7156"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 6719361157L);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test192"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var2 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)4.158638853279167d, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    java.lang.Number var5 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 4.158638853279167d+ "'", var5.equals(4.158638853279167d));

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test193"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.4819216925681265d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8861058879234063d);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test194"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-6197319789L), 2894332602L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test195"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-9L), 11L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test196"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1920929E-7f);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test197"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test198"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var8 = var1.nextGamma(4.937302184657956d, 97.98819663162894d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextUniform(0.7853981633974483d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9995511268784159d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 280.4901776155166d);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test199"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextSecureInt((-5), (-1271720519));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test200"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(9900, 293);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test201"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)5, (java.lang.Number)Double.NEGATIVE_INFINITY, true);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    java.lang.Number var5 = var3.getMin();
    java.lang.Number var6 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + Double.NEGATIVE_INFINITY+ "'", var5.equals(Double.NEGATIVE_INFINITY));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + Double.NEGATIVE_INFINITY+ "'", var6.equals(Double.NEGATIVE_INFINITY));

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test202"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-0.10720322305192957d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.10165690958607404d));

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test203"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     double var9 = var1.nextT(1.5855819012757701d);
//     double var12 = var1.nextGaussian((-0.7323676290027762d), 13.753533396481055d);
//     org.apache.commons.math3.distribution.IntegerDistribution var13 = null;
//     int var14 = var1.nextInversionDeviate(var13);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test204"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)2.786677745713106d, var2);

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test205"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(0.999987895021552d, 15.322095332102348d, false);
//     double var8 = var1.nextGamma(1.4713540043352986d, 4.787491742782046d);
//     double var10 = var1.nextExponential(16.636486299878868d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var1.nextHypergeometric(3, 89, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 6.878875700427188d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 15.080553978408297d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 71.99845981438989d);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test206"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportLowerBound();
    double var3 = var0.density(2.2737367544323206E-13d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.3989422804014327d);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test207"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var17 = var16.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    int var21 = var18.getNumElements();
    double[] var22 = var18.getElements();
    var16.addElements(var22);
    float var24 = var16.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var16);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    double[] var27 = var26.getElements();
    var26.addElement(100.0d);
    var26.contract();
    var26.discardFrontElements(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test208"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.0407956403497867d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.040818294823711264d);

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test209"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-7.2481055478477545d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test210"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)2.5242623302161973d);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test211"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(100L, 8179512108L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4L);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test212"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(5769050335L, 2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test213"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var16 = var15.getNumElements();
    double[] var17 = var15.getInternalValues();
    double[] var20 = new double[] { 10.0d, 100.0d};
    double var21 = var14.mannWhitneyU(var17, var20);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var23 = var22.getNumElements();
    double[] var24 = var22.getInternalValues();
    double var25 = var0.mannWhitneyUTest(var17, var24);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var27 = var26.getNumElements();
    double[] var28 = var26.getInternalValues();
    int var29 = var26.getNumElements();
    double[] var30 = var26.getInternalValues();
    double[] var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var32 = var0.mannWhitneyUTest(var30, var31);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test214"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.5842345752154947d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test215"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(7.8492444081989055d, 63.98437118343895d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.8492444081989055d);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test216"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(1.5690509993150914d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.026488547631604686d);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test217"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, 0.13035934721721523d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.9E-324d);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test218"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-10.567559072274054d), 0.7303807294278502d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-10.567559072274053d));

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test219"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextUniform(0.03497161846995667d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 16.592268483882908d);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test220"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(9900);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test221"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.6386034556842697d, (-0.7323676290027762d), 108.67153323312886d, (-347));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test222"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(1.5631720610317434d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999709354265791d);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test223"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(3520920169L, 5769050335L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test224"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    int var4 = var0.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    int var6 = var0.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test225"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     double var9 = var1.nextT(1.5855819012757701d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var12 = var1.nextPermutation((-11), (-1078420975));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.0805417118352725d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.10449506028271001d));
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test226"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.968953569826736d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3209627005516584d);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test227"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.876407757475359d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test228"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-65));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 65);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test229"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-15), 3.4028233E38f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test230"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(100L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test231"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)78.0922235533153d);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test232"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(102300, 0.0f, 99.99999f, 50);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test233"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.7303807294278502d);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test234"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(0, (-1.2676505E30f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test235"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    var0.setNumElements(0);
    var0.contract();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var6 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var10 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    double[] var17 = new double[] { 10.0d, 100.0d};
    double var18 = var11.mannWhitneyU(var14, var17);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    double var20 = var7.mannWhitneyU(var10, var14);
    double[] var24 = new double[] { 100.0d, 1.0d, 100.0d};
    double var25 = var6.mannWhitneyU(var10, var24);
    var0.addElements(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var28);
    org.apache.commons.math3.util.ResizableDoubleArray var30 = var28.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test236"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.356435922774216d, 29.569609032695144d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3.2830016497499828d));

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test237"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(3.986896366226194d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3830130751409533d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test238"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(7.546079582067821d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.742631232643827d);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test239"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(4.078793624253461d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 29.54554454270477d);

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test240"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 1.8171205928321397d, 0.004409706426562607d, (-241));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test241"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3, 8179512108L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 268848753);

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test242"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     int[] var10 = var1.nextPermutation(124952017, 1);
//     java.lang.String var12 = var1.nextHexString(295);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextInt(825, (-20));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.6712266489337395d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "5bf3b919ef3cd6d2b6bdfdcc23b3fd0f09aadce84a34e2564bf966f2fbffad4ef6a7d7141bb01271274259e72108f88244223ae63f375a5620f547c477ea8314d2b1eb5b80bd74fc7921484242e79e3a3caf9bd3c637239f79a1da0b717d8914deadb7d52a9b92d8f8df73c0d3f2e52db6e7439bf2201e38e9018eaa5f441bc79283b22e5e9a909a8ebb80b2853ed9feb440624"+ "'", var12.equals("5bf3b919ef3cd6d2b6bdfdcc23b3fd0f09aadce84a34e2564bf966f2fbffad4ef6a7d7141bb01271274259e72108f88244223ae63f375a5620f547c477ea8314d2b1eb5b80bd74fc7921484242e79e3a3caf9bd3c637239f79a1da0b717d8914deadb7d52a9b92d8f8df73c0d3f2e52db6e7439bf2201e38e9018eaa5f441bc79283b22e5e9a909a8ebb80b2853ed9feb440624"));
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test243"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-0.5961722400471147d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8564026207044273d));

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test244"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-20), 2.5f, 2.3841858E-7f, 396);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test245"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     int var13 = var1.nextSecureInt(0, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.nextUniform(19431.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7772285637L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test246"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)31.98437118343895d, (java.lang.Number)10L, false);
    java.lang.Number var4 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 10L+ "'", var4.equals(10L));

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test247"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(5.732333270692692E248d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.732333270692692E248d);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test248"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var3 = var0.probability(Double.NaN);
    double var4 = var0.getStandardDeviation();
    boolean var5 = var0.isSupportUpperBoundInclusive();
    double var6 = var0.getMean();
    double var8 = var0.probability((-0.9376760626269405d));
    var0.reseedRandomGenerator(4448708814L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test249"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getNumericalMean();
//     boolean var2 = var0.isSupportLowerBoundInclusive();
//     double var4 = var0.probability((-4.440892098500626E-16d));
//     double var5 = var0.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.1334305443990387d);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test250"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(7.5557864E22f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.0071993E15f);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test251"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var7 = var5.addElementRolling(Double.NaN);
    double[] var8 = var5.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    double[] var11 = var10.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var12 = var4.rank(var11);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test252"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.2676505E30f, 396);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test253"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.4E-45f, 99.99999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test254"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(7.546079582067821d, 2.562034708930776d, 97.98819663162894d, 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.9939513433989471d);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test255"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(4.584981588187509d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9918946513810528d));

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test256"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.588243686000456d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test257"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.5607966601082315d);
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var5 = var3.density(100.0d);
//     double var8 = var3.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double[] var10 = var3.sample(100);
//     double var11 = var3.getStandardDeviation();
//     double var13 = var3.cumulativeProbability((-0.004920366423301847d));
//     double var14 = var3.getNumericalVariance();
//     double var15 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var3);
//     double var16 = var3.getMean();
//     boolean var17 = var3.isSupportUpperBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.199456005038578d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.4980370657191222d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.6140289167040057d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test258"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(500, 10);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test259"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.3063909472492726d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0473060485928132d);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test260"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.9423730737612133d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.229653923770267d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test261"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-5), 4.6E-44f, 0.0f, (-241));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test262"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(2.3104273163924094d, (-1.3113177943322367d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test263"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getNumericalMean();
    double var2 = var0.getStandardDeviation();
    boolean var3 = var0.isSupportLowerBoundInclusive();
    double var4 = var0.getSupportLowerBound();
    double var6 = var0.cumulativeProbability(0.7838899213734127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7834476479380598d);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test264"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-0.5458066324533807d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test265"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(3.4028233E38f, 2.3841858E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.4028233E38f);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test266"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(3.7625250955428156d, 5.381455886543763d, (-0.05624544022146599d), 268848753);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test267"); }


    float var2 = org.apache.commons.math3.util.FastMath.max((-1.0000001f), (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0f));

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test268"); }


    double var2 = org.apache.commons.math3.special.Erf.erf((-0.001073836545783379d), 29.569609032695144d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0012116943213827d);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test269"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(13.753533396481055d, 0.9346228444644087d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.2658092704850752d));

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test270"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     int var12 = var1.nextZipf(3, 0.949950589504148d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var15 = var1.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 98.27509668239522d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.582762782441911d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3);
// 
//   }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test271"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var4 = var1.nextChiSquare(5.464265321962551d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var1.nextF((-62472.0d), 4.089618308475393d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.913539541880226d);
// 
//   }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test272"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var7 = var1.nextExponential(209.99999999999997d);
//     var1.reSeedSecure();
//     var1.reSeed(4448708814L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("4de6bca8d155a053f373c1d7740431c9040a53e4937b94d87fd6fb166457961c76470789d14c0b8e177f046ed6433494419ef202b7f1abd34a5474652374aa3b597dbfe7f8f6489508b8401b9c58f1058f2116e0ef6a7a084c8c554bd2fed4372d47927cf4a9cae0e6c30973bdd395972c6a510dcdb017584cc158ec879b0edfc0880976ce0f91e51a5f7d87050958c0fb962d8", "e77ab5");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9999999617447859d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 52.89708723490868d);
// 
//   }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test273"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(4.15912713462618d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test274"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-1023), 0);
//     java.lang.String var6 = var1.nextSecureHexString(6);
//     int var9 = var1.nextZipf(208, 13.753533396481055d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var1.nextLong(9741938155L, 3384732745L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-908));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "74e7f5"+ "'", var6.equals("74e7f5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test275"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-17), 124952017);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2124184289));

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test276"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var13 = var1.nextUniform(0.9999943487368532d, 44.5140274520795d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var1.nextUniform(0.9999991703434066d, 0.7834476479380598d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2442392599L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 29.03483241141061d);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test277"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(396, (-5));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test278"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(7.38420064243972d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.881784197001252E-16d);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test279"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(5.205744238502723d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 91.16099711112008d);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test280"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-9617852649L), 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-4685954328653257593L));

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test281"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var4 = var1.nextChiSquare(5.464265321962551d);
//     double var8 = var1.nextUniform((-0.8307376748471434d), 0.006537325533411519d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextUniform(9.999999999999996d, 8.405682460246684d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.7902433216963765d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.20245542646892178d));
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test282"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.0f);
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)100.0d);
    org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(short)100);
    java.lang.Number var7 = var6.getMax();
    java.lang.Throwable[] var8 = var6.getSuppressed();
    var4.addSuppressed((java.lang.Throwable)var6);
    var2.addSuppressed((java.lang.Throwable)var4);
    java.lang.Number var11 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)100+ "'", var7.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 100.0d+ "'", var11.equals(100.0d));

  }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test283"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(9.140183681189434d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test284"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 20.085536923187668d);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test285"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-22));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test286"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test287"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.start();
    double var3 = var0.addElementRolling(4.937302184657956d);
    int var4 = var0.start();
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var0.copy();
    float var7 = var6.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test288"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum((-1.26765045E30f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0f));

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test289"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSecureAlgorithm("4bffd0a0022bc47a4d81261b9c970bff2fa315bf21ff1fc053bd6f5b61ea543c2c195653a0295f802ba711a290a052ffe5dbbd18040ec2cd9563f46f2ab4cb8cba00e625b5014bea2a9a5c63b69d0b3e3e1c373a708349bdd07e6de4860c15071c56e0b56b7a5bf2ce6525d81b3e5fcb721b8f2a4831dba1f3bc51f610d65d54e9f841a7b31c013194fe981a329afb9529a094e5886a3c8b0664be276df2abb6cae438f9e245addaa753394cf0db0cfa22abeabc603a21280a46cc15e7bc4e4cac1d79ab6ea8b1eb79416fd57fe4de243a3efaa6111ca1891103f5e9ea5bdd5f6ed648c92f7d4ae8998061a5cf4bf77aedb7b2b63b5ec4ad8276", "org.apache.commons.math3.exception.NumberIsTooLargeException: \uFFFD is larger than the maximum (0.614)");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test290"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var2 = var1.getNumElements();
    double[] var3 = var1.getInternalValues();
    double[] var6 = new double[] { 10.0d, 100.0d};
    double var7 = var0.mannWhitneyU(var3, var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var9 = var8.getExpansionMode();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var10 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var13 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var16 = var15.getNumElements();
    double[] var17 = var15.getInternalValues();
    double[] var20 = new double[] { 10.0d, 100.0d};
    double var21 = var14.mannWhitneyU(var17, var20);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    double var23 = var10.mannWhitneyU(var13, var17);
    var8.addElements(var13);
    var8.setNumElements(65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 24.0d);

  }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test291"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var13 = var1.nextUniform(0.9999943487368532d, 44.5140274520795d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.nextF(0.9999633474932227d, (-62472.0d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1065667974L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 7.697671857232269d);
// 
//   }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test292"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(1.6481511386764256d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1665864075690343d);

  }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test293"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(0.999987895021552d, 15.322095332102348d, false);
//     double var8 = var1.nextGamma(1.4713540043352986d, 4.787491742782046d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextF((-1.0084760157976542d), (-12.844009081315292d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.920833470775813d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 19.694412139803944d);
// 
//   }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test294"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.9865549713026993d, 496.2674961884226d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.004002970929679791d);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test295"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-19.894922083922054d));

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test296"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(251, 295);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test297"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(58.28250505006778d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5536402027341418d);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test298"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(4.61512051684126d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.61512051684126d);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test299"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1, 6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6);

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test300"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.9503955299889218d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test301"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(32.00000000000001d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.15912713462618d);

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test302"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var8 = var1.nextCauchy(1.0d, 4.427429051327539d);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var1.nextSample(var9, 102300);
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test303"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.0407956403497867d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.04078432536763143d);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test304"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(41.86392792621338d, 1.0016685869732043d, 78.0922235533153d, (-74));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test305"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)63.98437118343895d);
    java.lang.Number var3 = var2.getMin();
    java.lang.Number var4 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 63.98437118343895d+ "'", var4.equals(63.98437118343895d));

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test306"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(2L, 10000000000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test307"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.588243686000456d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6227605565158021d);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test308"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-1.26765045E30f), 4.6E-44f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.26765045E30f);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test309"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.3830130751409533d, (java.lang.Number)(-0.014542775949576744d), true);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test310"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test311"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(102300, 65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 65);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test312"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(1.0473060485928132d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test313"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test314"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     double var12 = var1.nextBeta(1.5855819012757701d, 4.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextWeibull((-0.05388929638978884d), 0.07046473534579971d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 302);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.303772211319993d);
// 
//   }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test315"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextChiSquare(0.6139648708421599d);
//     org.apache.commons.math3.distribution.IntegerDistribution var8 = null;
//     int var9 = var1.nextInversionDeviate(var8);
// 
//   }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test316"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(2.7755575615628914E-17d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.162975822039155E-33d);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test317"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(5, 3.4028233E38f, 1.0000001f, 9900);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test318"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.024588566448858762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test319"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-10L), 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-100000L));

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test320"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(1.286708717828994d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.06880761065880366d);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test321"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(Float.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.4028235E38f));

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test322"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(3.4028235E38f, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test323"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var13 = var1.nextUniform(0.9999943487368532d, 44.5140274520795d);
//     double var15 = var1.nextChiSquare(51.55677237552102d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var1.nextPascal(124952017, (-0.2554932247505838d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1493777781L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 35.92472481249052d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 44.49321052645041d);
// 
//   }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test324"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     var1.reSeed((-2502316609L));
//     double var11 = var1.nextGamma((-0.05788914687716099d), (-0.9918946513810528d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextHypergeometric((-74), 124952017, 10400);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5998884700L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-4.013115666462255d));
// 
//   }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test325"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(86.37257067437166d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test326"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var1.setNumElements(0);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test327"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(2.0d, 0.9999943487368532d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7357609613264131d);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test328"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-2147483648), (-7500));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test329"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(268848753, (-15));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test330"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(3.7625250955428156d, 3.986896366226194d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.22437127068337848d));

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test331"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(4.078793624253461d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.008216985167195E-9d);

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test332"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-0.573312907976816d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test333"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial((-1096480911));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test334"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     long var10 = var1.nextLong(0L, 10000000000L);
//     int var13 = var1.nextBinomial(9900, 0.5230558330643571d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextZipf((-74), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 18.437482684487055d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6722600162L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5122);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test335"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.28145195033435416d));

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test336"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(9.140183681189434d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test337"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)5, (java.lang.Number)Double.NEGATIVE_INFINITY, true);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test338"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(6.162975822039155E-33d, 14.155448481408198d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 14.155448481408198d);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test339"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(6769465490L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test340"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(44.34227194424954d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.484958451919815d);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test341"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(2.3044102334851835d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9802694590384492d);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test342"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(1990489697293914943L, (-2502316609L));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test343"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var17 = var16.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    int var21 = var18.getNumElements();
    double[] var22 = var18.getElements();
    var16.addElements(var22);
    float var24 = var16.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var16);
    double var27 = var16.addElementRolling(3.4965075614664802d);
    org.apache.commons.math3.util.ResizableDoubleArray var28 = var16.copy();
    int var29 = var28.start();
    var28.setElement(9900, (-0.05618453265504479d));
    var28.discardFrontElements(9900);
    var28.setContractionCriteria(99.99999f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var38 = var28.getElement(371);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1);

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test344"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     java.lang.String var5 = var1.nextSecureHexString(371);
//     long var8 = var1.nextSecureLong(0L, 8179512108L);
//     java.lang.String var10 = var1.nextSecureHexString(293);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "5bef577f35ddf8ecdc84f1c9a5c01fd7b876182ec9e497785283677666c7f2d71ddb02d473b817a3e43845521c1dcb72f4651c559cd05c84ecddd4f161a3177255105194d40ab022fcfe502d4ff9a56804b9d2c8eec47592d7fa06b234d7d9dd48c9e10488ffaf3a3a7427992434bb4ef306ee91e5f702e654866fa24aca43cc34bf5124232227ee34524a041e2b406fcd7a9f93269d95ba2a3630dac6aceb4209d09fade406d8a3923b2089388358be2456590ff8515bc2f40"+ "'", var5.equals("5bef577f35ddf8ecdc84f1c9a5c01fd7b876182ec9e497785283677666c7f2d71ddb02d473b817a3e43845521c1dcb72f4651c559cd05c84ecddd4f161a3177255105194d40ab022fcfe502d4ff9a56804b9d2c8eec47592d7fa06b234d7d9dd48c9e10488ffaf3a3a7427992434bb4ef306ee91e5f702e654866fa24aca43cc34bf5124232227ee34524a041e2b406fcd7a9f93269d95ba2a3630dac6aceb4209d09fade406d8a3923b2089388358be2456590ff8515bc2f40"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3118086304L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "4dfc9f810ce37863c27dbfd635ef72d2d9e0ce7e7ed13cfd01ee363964f411d93295fe8b7af2bcb9480a2fdf66038943c8c6600d4d4cefd0657807c7595f5e6795d4dfc00ffe85d770ec3764611ec04cdb3be1524007042dce14baf0f690573d2b906440c75b8acd59a2e63695023a3d4a588272eaac16e2f75e98c81d344ef905485b98931e638810ee996c5ac18df3398db"+ "'", var10.equals("4dfc9f810ce37863c27dbfd635ef72d2d9e0ce7e7ed13cfd01ee363964f411d93295fe8b7af2bcb9480a2fdf66038943c8c6600d4d4cefd0657807c7595f5e6795d4dfc00ffe85d770ec3764611ec04cdb3be1524007042dce14baf0f690573d2b906440c75b8acd59a2e63695023a3d4a588272eaac16e2f75e98c81d344ef905485b98931e638810ee996c5ac18df3398db"));
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test345"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    var0.setNumElements(0);
    var0.contract();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var6 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var10 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    double[] var17 = new double[] { 10.0d, 100.0d};
    double var18 = var11.mannWhitneyU(var14, var17);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    double var20 = var7.mannWhitneyU(var10, var14);
    double[] var24 = new double[] { 100.0d, 1.0d, 100.0d};
    double var25 = var6.mannWhitneyU(var10, var24);
    var0.addElements(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var28);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var28.setContractionCriteria(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 4.0d);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test346"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(393769118724723329L, (-10681828717L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 393769108042894612L);

  }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test347"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getMean();
//     double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     boolean var5 = var0.isSupportConnected();
//     double var6 = var0.getNumericalVariance();
//     double var7 = var0.sample();
//     double var9 = var0.probability(100.99084048753582d);
//     double var10 = var0.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.4127267382373947d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.0d);
// 
//   }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test348"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(65, (-1023));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 66495);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test349"); }


    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)32.53142185860535d, (java.lang.Number)(-1.315149049454551d), var2);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var5 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var5);

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test350"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     java.lang.String var8 = var1.nextHexString(500);
//     double var10 = var1.nextT(0.9584128699015102d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var12 = var1.nextSecureHexString((-20));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2922149248L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "b06b74c075ac13d6c6ef0e00d675a9364d27710175edf42aac868ffa5a352da7167fce4d11cf642175c0bac7f3552e9f389e13336b2733d72ba9a08436d63e51e3bda6044af1331fa06279d828a8bf6751b338a2de7cfe33942290d856cebd1ceee545df40b99484063045e220c89b1addfc67a177a2d299fe40f334a674acc01b84e4e3a3abdffe46deb6177efe4c3532b8faac9ceed1c8cc4c70657c1909029545aa621d63c9ae7daa70d7f04c2cca7eafa278db8f794044350186727afe4d13a6b06e129cf547182ee5eb17b02b1a8b7e12cc57ccc3bc2e1f118e6938b27713426bfb599808c7ecffa9f39299c99b149cb0317653cb2606e8"+ "'", var8.equals("b06b74c075ac13d6c6ef0e00d675a9364d27710175edf42aac868ffa5a352da7167fce4d11cf642175c0bac7f3552e9f389e13336b2733d72ba9a08436d63e51e3bda6044af1331fa06279d828a8bf6751b338a2de7cfe33942290d856cebd1ceee545df40b99484063045e220c89b1addfc67a177a2d299fe40f334a674acc01b84e4e3a3abdffe46deb6177efe4c3532b8faac9ceed1c8cc4c70657c1909029545aa621d63c9ae7daa70d7f04c2cca7eafa278db8f794044350186727afe4d13a6b06e129cf547182ee5eb17b02b1a8b7e12cc57ccc3bc2e1f118e6938b27713426bfb599808c7ecffa9f39299c99b149cb0317653cb2606e8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3.4353966032209504d);
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test351"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(1.4713540043352986d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.03745141146713474d);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test352"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test353"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(89, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 89);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test354"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)2147483647, (java.lang.Number)0.6670149528602685d, false);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var5 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)3);
    var3.addSuppressed((java.lang.Throwable)var5);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test355"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var14.contract();
    int var16 = var14.getExpansionMode();
    float var17 = var14.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = var14.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test356"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed();
    double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
    var1.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var1.nextUniform((-4.013115666462255d), (-1005.1974458748141d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test357"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.6670149528602685d, 1.6386034556842697d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6670149528602686d);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test358"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1000);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1000);

  }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test359"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)29.9749466411613d, (java.lang.Number)2.5f, false);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var9 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.978735975787224d, (java.lang.Number)(-19.894922083922054d), false);
//     java.lang.Throwable[] var10 = var9.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var10);
// 
//   }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test360"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    var0.setNumElements(0);
    var0.contract();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var6 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var10 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    double[] var17 = new double[] { 10.0d, 100.0d};
    double var18 = var11.mannWhitneyU(var14, var17);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    double var20 = var7.mannWhitneyU(var10, var14);
    double[] var24 = new double[] { 100.0d, 1.0d, 100.0d};
    double var25 = var6.mannWhitneyU(var10, var24);
    var0.addElements(var24);
    var0.setContractionCriteria(16.0f);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var32 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var33 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var34 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var35 = var34.getNumElements();
    double[] var36 = var34.getInternalValues();
    double[] var39 = new double[] { 10.0d, 100.0d};
    double var40 = var33.mannWhitneyU(var36, var39);
    org.apache.commons.math3.util.ResizableDoubleArray var41 = new org.apache.commons.math3.util.ResizableDoubleArray(var36);
    double var42 = var29.mannWhitneyU(var32, var36);
    org.apache.commons.math3.util.ResizableDoubleArray var43 = new org.apache.commons.math3.util.ResizableDoubleArray(var32);
    var0.addElements(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 24.0d);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test361"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(1990489697293914943L, 3645265866L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test362"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(5.996181835373871d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4055443918089456d);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test363"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-10.567559072274053d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.5707963267948966d));

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test364"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(44.34227194424954d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.814239752872258d);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test365"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.006537325533411519d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.184599888317818d));

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test366"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1772309183L, 8770513317L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5154125899424117313L));

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test367"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var7 = var1.nextExponential(209.99999999999997d);
//     var1.reSeedSecure();
//     double var11 = var1.nextUniform(0.0d, 0.9133845507670576d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var14 = var1.nextPermutation(6, 396);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9999999981241273d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 74.47034877664905d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.15713600942650435d);
// 
//   }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test368"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var7 = var1.nextExponential(209.99999999999997d);
//     double var10 = var1.nextUniform(1.3648793247295046d, 200.94444231998796d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var1.nextHypergeometric(251, (-347), (-347));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9999222329930779d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 148.22892002011085d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 124.94411875359114d);
// 
//   }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test369"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var8 = var1.nextWeibull(0.7853981633974483d, 4.787491742782046d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var1.nextLong(1990489697293914943L, 3520920158L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.8101404928175255d);
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test370"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.05782461145270825d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.06517543676798719d);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test371"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(6, 0.0f, (-1.26765045E30f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test372"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    int var2 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var4 = var3.getNumElements();
    double[] var5 = var3.getInternalValues();
    int var6 = var3.getNumElements();
    double[] var7 = var3.getElements();
    var0.addElements(var7);
    var0.contract();
    var0.addElement(1.4329174706418153d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var0.getElement((-17));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test373"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var3 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)4.158638853279167d, (java.lang.Object[])var3);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var3);
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     java.lang.Object[] var13 = new java.lang.Object[] { 'a'};
//     org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var11, var13);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var10, var13);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var9, var13);
//     org.apache.commons.math3.exception.MathArithmeticException var17 = new org.apache.commons.math3.exception.MathArithmeticException(var8, var13);
//     org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException(var7, var13);
//     org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, var13);
// 
//   }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test374"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1.6286532113855836d), (java.lang.Number)(-0.9376760626269405d), false);
    org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(short)100);
    java.lang.Number var6 = var5.getMax();
    java.lang.Number var7 = var5.getMax();
    java.lang.Number var8 = var5.getMax();
    var3.addSuppressed((java.lang.Throwable)var5);
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var13 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var12, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var11, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var10, (java.lang.Object[])var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)100+ "'", var6.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)100+ "'", var7.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (short)100+ "'", var8.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test375"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(13.753533396481055d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13.753533396481057d);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test376"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed();
    var1.reSeed(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var1.nextBeta(3.7625250955428156d, (-0.0075206657143111755d));
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test377"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(307.0027056045166d, 0.004000934888783327d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 307.00270563058723d);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test378"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(251);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test379"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.0f, 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test380"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(0, (-2147483648));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test381"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var3 = var0.probability(2.742631232643827d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var5 = var0.sample((-2124184289));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test382"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var1.nextWeibull(0.0d, 1.6260590822656884E-6d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test383"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test384"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(3.4028235E38f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.4028235E38f);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test385"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(1.7456204716704575d, (-0.06991186090907374d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test386"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.7838899213734127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7323919384450054d);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test387"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(9259150L, 7612302794L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 35241726707532550L);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test388"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("ffcf78");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test389"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(7344187125L, 393769118724723329L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test390"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.4447332383957143d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test391"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    var0.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test392"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(4.584981588187509d, 0.004409706426562607d, (-0.10165690958607404d));

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test393"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double var7 = var0.cumulativeProbability(0.6139648708421599d);
    boolean var8 = var0.isSupportLowerBoundInclusive();
    double var10 = var0.probability(9.437944169387807d);
    double var11 = var0.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.7303807294278502d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == Double.NEGATIVE_INFINITY);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test394"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.13547561509003855d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.15193776139271079d);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test395"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-2147483648), (-65));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test396"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.8171205928321397d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test397"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(8.881784197001252E-16d, 210);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4615016373309029E48d);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test398"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(9.0071993E15f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.07374182E9f);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test399"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(2.404927907365227d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5243352690887788d);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test400"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1.088851945553895d);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test401"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError(var0);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test402"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.5842345752154947d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5552592332346065d);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test403"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(100);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test404"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var3 = var0.probability(Double.NaN);
    double var4 = var0.getStandardDeviation();
    boolean var5 = var0.isSupportUpperBoundInclusive();
    double var6 = var0.getMean();
    double var7 = var0.getSupportLowerBound();
    boolean var8 = var0.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test405"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(0, 394);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test406"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    int var9 = var0.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var0.getElement(371);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test407"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.6387763808612118d, (java.lang.Number)(-5.011010127267165E-16d), true);

  }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test408"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma((-0.0010738361330276734d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test409"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.0000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000004f);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test410"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(5.9604645E-8f, 1.26765045E30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.9604645E-8f);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test411"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(9.0071993E15f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 53);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test412"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(124952017, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 124952017);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test413"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(209.99999999999997d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.040249042294968d);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test414"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum((-1.2676505E30f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0f));

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test415"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    var0.contract();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl(var11);
    var12.reSeed();
    double var16 = var12.nextGamma(0.0d, 29.9749466411613d);
    var12.reSeedSecure();
    var12.reSeed();
    boolean var19 = var0.equals((java.lang.Object)var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var23 = var12.nextHypergeometric((-1), 2147483647, 251);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test416"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(4.082560026975774d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 58.29707782564671d);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test417"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(396);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1976.5498837332734d);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test418"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, 8179512108L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test419"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(7.546079582067821d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.0d);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test420"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(3.399216241149525E248d, 0.8998354296541002d);
    double var3 = var2.getMean();
    double var4 = var2.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 3.399216241149525E248d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.8097038004607792d);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test421"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.9998213620467383d, 0.6210214343458166d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9998213620467382d);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test422"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var3.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var8 = var6.addElementRolling(Double.NaN);
    double[] var9 = var6.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var10);
    double[] var12 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var16 = var15.getNumElements();
    double[] var17 = var15.getInternalValues();
    double[] var20 = new double[] { 10.0d, 100.0d};
    double var21 = var14.mannWhitneyU(var17, var20);
    var13.addElements(var20);
    boolean var23 = var2.equals((java.lang.Object)var13);
    java.lang.String var24 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "RANDOM"+ "'", var24.equals("RANDOM"));

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test423"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(7102946208L, 6438299617L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 664646591L);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test424"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, 65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test425"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1.257296821133544d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3083894584059538d);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test426"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(500);
    var1.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var3.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var8 = var6.addElementRolling(Double.NaN);
    double[] var9 = var6.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var10);
    double[] var12 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    var1.addElements(var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setContractionCriteria(1.0000004f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test427"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var8 = var1.nextWeibull(0.7853981633974483d, 4.787491742782046d);
//     double var11 = var1.nextCauchy((-0.8887846934032357d), 0.723245967437971d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var1.nextBinomial((-1078420975), 0.3971622936791505d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 6.569774167779939d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.8966821957956684d));
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test428"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(393769118724723329L, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5090545318414900353L);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test429"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var2 = var1.getNumElements();
    double[] var3 = var1.getInternalValues();
    var1.clear();
    var1.setExpansionFactor(2.4999998f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var1);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test430"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)Double.NaN, (java.lang.Number)0.6139648708421599d, true);
    boolean var4 = var3.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var7 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.OutOfRangeException var13 = new org.apache.commons.math3.exception.OutOfRangeException(var9, (java.lang.Number)24.0d, (java.lang.Number)0.723245967437971d, (java.lang.Number)825);
    var8.addSuppressed((java.lang.Throwable)var13);
    java.lang.Number var15 = var13.getArgument();
    java.lang.Throwable[] var16 = var13.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, (java.lang.Object[])var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + 24.0d+ "'", var15.equals(24.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test431"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.5855819012757701d, 0.004000934888783327d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.58558190127577d);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test432"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(1.0012116943213827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test433"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)66495);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test434"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(0L, (-2L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2L));

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test435"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.8998354296541002d, 2.4978485618289232d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.20276274520392815d);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test436"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getSupportLowerBound();
    double var10 = var0.density(0.004000934888783327d);
    double var13 = var0.cumulativeProbability((-1.0084760157976542d), (-0.9985753080512595d));
    double var16 = var0.cumulativeProbability((-1.7540559170466496d), 1.088851945553895d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.3989390873839266d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0023872351676735293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.8221799467477315d);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test437"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(8494943427L, 9741938155L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8494943427L);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test438"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var1 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var4 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var7 = var6.getNumElements();
    double[] var8 = var6.getInternalValues();
    double[] var11 = new double[] { 10.0d, 100.0d};
    double var12 = var5.mannWhitneyU(var8, var11);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    double var14 = var1.mannWhitneyU(var4, var8);
    double[] var18 = new double[] { 100.0d, 1.0d, 100.0d};
    double var19 = var0.mannWhitneyU(var4, var18);
    double[] var20 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var22 = var21.getNumElements();
    double[] var23 = var21.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var24 = var0.mannWhitneyUTest(var20, var23);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test439"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(6.162975822039155E-33d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.162975822039155E-33d);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test440"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathArithmeticException var2 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var1);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test441"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.0000004f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000004f);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test442"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(13.31102056604163d, 6.3159300327223424E-37d, 1.880541304840417d, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test443"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(2.156657827113264d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test444"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(Float.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 128);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test445"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed();
    var1.reSeed(0L);
    double var6 = var1.nextT(0.9999999984381234d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var1.nextHypergeometric(210, 124952017, (-1023));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.9584128699015102d);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test446"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1000, (-15));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1000);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test447"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(89, (-5));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 445);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test448"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    double[] var14 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var15.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var20 = var18.addElementRolling(Double.NaN);
    double[] var21 = var18.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var21);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var15, var22);
    double[] var24 = var15.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var26 = var25.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var28 = var27.getNumElements();
    double[] var29 = var27.getInternalValues();
    int var30 = var27.getNumElements();
    double[] var31 = var27.getElements();
    var25.addElements(var31);
    var15.addElements(var31);
    float var34 = var15.getExpansionFactor();
    var15.clear();
    double[] var36 = var15.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var37 = var0.mannWhitneyU(var14, var36);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test449"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("0207fc");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test450"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(317, (-1023));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-324291));

  }

//  public void test451() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest2.test451"); }
//
//
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(268848753, 15.999999f, 3.4028235E38f);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//
//  }
//
  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test452"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getStandardDeviation();
    boolean var9 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator(1L);
    boolean var12 = var0.isSupportLowerBoundInclusive();
    double var13 = var0.getNumericalMean();
    double var14 = var0.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test453"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getSupportLowerBound();
    double var10 = var0.density(0.004000934888783327d);
    double var13 = var0.cumulativeProbability((-1.0084760157976542d), (-0.9985753080512595d));
    double var14 = var0.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.3989390873839266d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0023872351676735293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test454"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-2147483648), 0.99999994f, 0.0f, (-347));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test455"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var5 = var0.getMean();
    double var6 = var0.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test456"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-4685954328653257593L), 6769465490L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6769465490L);

  }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test457"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getMean();
//     double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var7 = var0.cumulativeProbability(4.158638853279167d, 24.0d);
//     double var8 = var0.sample();
//     boolean var9 = var0.isSupportLowerBoundInclusive();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.inverseCumulativeProbability(2.1891412261319916d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.600747998428365E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.32803374571033767d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test458"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.9750822343314787d, 0.9999999033896889d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.9750822343314782d);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test459"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(14066561462L, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4572436235037468952L);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test460"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var14.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var19 = var17.addElementRolling(Double.NaN);
    double[] var20 = var17.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var21);
    double[] var23 = var14.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(var23);
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var26 = var25.getNumElements();
    int var27 = var25.start();
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var29 = var28.getNumElements();
    double[] var30 = var28.getInternalValues();
    int var31 = var28.getNumElements();
    double[] var32 = var28.getElements();
    var25.addElements(var32);
    var25.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var37 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var25, var37);
    var37.setElement(825, (-0.06991186090907374d));
    double[] var42 = var37.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var43 = var0.mannWhitneyUTest(var23, var42);
      fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
    } catch (org.apache.commons.math3.exception.NoDataException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test461"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(102300, 7102946208L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test462"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.8939360120238292d, 58.222235321660335d, 0.028485400656642273d, (-17));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test463"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var5 = var1.nextPoisson(0.9720449790817591d);
//     double var7 = var1.nextChiSquare(5.65362408791435d);
//     double var10 = var1.nextCauchy((-0.23573885556858495d), 1.8525291623715519d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("02935e64d8e8dbe57220482402ad1f9b8870dec665010320667d79136f109b2849d6d2b3b14e6f5732f437cd734cf4eb9386cdd1239c60a08317713070b6a615e0bc943b71cea100d53190573967344b66cf576ed68c760382e14c0f9b4d48171c48b5e71be6cdbc840977124e6af02514de5e72772f34c9aafda2940108c8cd517ec08cfe59adb6f875acbd0673075e03cc587159cbc18861ee8c3629040c7c53934f7a58d894caf60b18c7f51fd033b977ac56a9fa5be1107", "ffcf78");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.935763479133571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.7541166575363831d));
// 
//   }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test464"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-241), 3.4028233E38f, 1.1920929E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test465"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(8179512108L, 4L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 32718048432L);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test466"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.0f);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test467"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    int var9 = var6.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    int var11 = var6.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test468"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0d));

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test469"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(293, 1.07374182E9f);

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test470"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getMean();
//     double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     boolean var5 = var0.isSupportConnected();
//     double var6 = var0.getNumericalVariance();
//     double var7 = var0.sample();
//     double var8 = var0.getStandardDeviation();
//     double var9 = var0.getNumericalMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1.4167840343841642d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
// 
//   }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test471"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(4.296262326679068d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9146614843608588d));

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test472"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(5769050335L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5769050335L);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test473"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-0.8061852905228415d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test474"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     int var12 = var1.nextZipf(3, 0.949950589504148d);
//     var1.reSeedSecure();
//     double var16 = var1.nextGamma((-0.7323676290027762d), (-4.440892098500626E-16d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 99.85091339688786d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.40428888768425d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-7.520871210725989E-16d));
// 
//   }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test475"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    java.lang.Class var8 = var7.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var14 = var13.getNumElements();
    double[] var15 = var13.getInternalValues();
    double[] var18 = new double[] { 10.0d, 100.0d};
    double var19 = var12.mannWhitneyU(var15, var18);
    double[] var20 = var11.rank(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    double var23 = var21.addElementRolling(1.3830130751409533d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.setExpansionFactor((-3.4028235E38f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);

  }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test476"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var8 = var1.nextUniform(0.0d, 0.1657797866605693d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var12 = var1.nextPermutation(0, 825);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.008686288412409086d);
// 
//   }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test477"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     int var12 = var1.nextZipf(3, 0.949950589504148d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var1.nextHypergeometric(0, (-1096480911), 53);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 98.21796063868608d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.5482986782613746d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2);
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test478"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.999987895021552d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test479"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var13 = var1.nextUniform(0.9999943487368532d, 44.5140274520795d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextPascal((-17), 1.9865549713026993d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7831095539L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 31.301199330920145d);
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test480"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(3.7625250955428156d, 99.85091339688786d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.474237346416215d);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test481"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(16.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9073486E-6f);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test482"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-0.007854005709676678d), 0.2030609190654752d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.038658806152633805d));

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test483"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(128, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test484"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var4);
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var4);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test485"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5f);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test486"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    int var3 = var0.getNumElements();
    double[] var4 = var0.getElements();
    var0.setExpansionMode(0);
    var0.discardFrontElements(0);
    var0.contract();
    int var10 = var0.getNumElements();
    float var11 = var0.getExpansionFactor();
    int var12 = var0.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test487"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     java.util.Collection var4 = null;
//     java.lang.Object[] var6 = var1.nextSample(var4, 0);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test488"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial((-11));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test489"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0);
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.NotPositiveException var7 = new org.apache.commons.math3.exception.NotPositiveException(var5, (java.lang.Number)0);
    java.lang.Object[] var8 = new java.lang.Object[] { 0};
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var4, var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var2, var8);
    var1.addSuppressed((java.lang.Throwable)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test490"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-22), (-241));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test491"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    int var3 = var0.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.substituteMostRecentElement(2.9690791410915276d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test492"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.1125191124373863d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test493"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(0, (-5));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test494"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-1.4700664288029952d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9846781146117636d);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test495"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(3628800L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3628800L);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test496"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(2.9750822343314787d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 19.591234255406928d);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test497"); }


    java.lang.Number var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-9617852649L), var1, var2);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test498"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-1.9200849871876335d), 0.8504467169183425d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.1538445424312467d));

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test499"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(99.85091339688786d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7427271998994087d);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test500"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    int var10 = var9.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    boolean var21 = var6.equals((java.lang.Object)28.809936981510216d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

}
