
import junit.framework.*;

public class RandoopTest10 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test1"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.3083894584059538d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.551115123125783E-17d);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test2"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(3.4028235E38f, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.4028235E38f);

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test3"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.27586690618718956d), (-0.01278222646112276d), 14.563972653803441d, 1704294704);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test4"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)5.960465E-8f, (java.lang.Number)1.3925240956605238d, true);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.3925240956605238d+ "'", var5.equals(1.3925240956605238d));

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test5"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var3 = var2.getNumElements();
    double[] var4 = var2.getInternalValues();
    int var5 = var2.getNumElements();
    double[] var6 = var2.getElements();
    var0.addElements(var6);
    int var8 = var0.getExpansionMode();
    double var10 = var0.addElementRolling(0.1657797866605693d);
    var0.setElement(506, 0.0d);
    var0.discardFrontElements(0);
    double var17 = var0.addElementRolling(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test6"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    java.lang.Class var4 = var3.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    java.lang.String var7 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var11.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var16 = var14.addElementRolling(Double.NaN);
    double[] var17 = var14.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var11, var18);
    double[] var20 = var11.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var22 = var21.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var24 = var23.getNumElements();
    double[] var25 = var23.getInternalValues();
    int var26 = var23.getNumElements();
    double[] var27 = var23.getElements();
    var21.addElements(var27);
    var11.addElements(var27);
    float var30 = var11.getExpansionFactor();
    var11.clear();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var32 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var33 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var34 = var33.getNumElements();
    double[] var35 = var33.getInternalValues();
    double[] var38 = new double[] { 10.0d, 100.0d};
    double var39 = var32.mannWhitneyU(var35, var38);
    org.apache.commons.math3.util.ResizableDoubleArray var40 = new org.apache.commons.math3.util.ResizableDoubleArray(var35);
    var11.addElements(var35);
    var11.clear();
    boolean var43 = var10.equals((java.lang.Object)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "AVERAGE"+ "'", var7.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test7"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var16 = var15.getNumElements();
    double[] var17 = var15.getInternalValues();
    double[] var20 = new double[] { 10.0d, 100.0d};
    double var21 = var14.mannWhitneyU(var17, var20);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var24 = var23.getNumElements();
    double[] var25 = var23.getInternalValues();
    double[] var28 = new double[] { 10.0d, 100.0d};
    double var29 = var22.mannWhitneyU(var25, var28);
    double var30 = var0.mannWhitneyUTest(var17, var28);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var31 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var32 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var33 = var32.getNumElements();
    double[] var34 = var32.getInternalValues();
    double[] var37 = new double[] { 10.0d, 100.0d};
    double var38 = var31.mannWhitneyU(var34, var37);
    org.apache.commons.math3.util.ResizableDoubleArray var39 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var39.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var42 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var44 = var42.addElementRolling(Double.NaN);
    double[] var45 = var42.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var46 = new org.apache.commons.math3.util.ResizableDoubleArray(var45);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var39, var46);
    double[] var48 = var39.getElements();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var49 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var52 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var53 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var54 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var55 = var54.getNumElements();
    double[] var56 = var54.getInternalValues();
    double[] var59 = new double[] { 10.0d, 100.0d};
    double var60 = var53.mannWhitneyU(var56, var59);
    org.apache.commons.math3.util.ResizableDoubleArray var61 = new org.apache.commons.math3.util.ResizableDoubleArray(var56);
    double var62 = var49.mannWhitneyU(var52, var56);
    org.apache.commons.math3.util.ResizableDoubleArray var63 = new org.apache.commons.math3.util.ResizableDoubleArray(var52);
    org.apache.commons.math3.util.ResizableDoubleArray var64 = new org.apache.commons.math3.util.ResizableDoubleArray(var63);
    double var66 = var63.substituteMostRecentElement(0.3742437696541317d);
    org.apache.commons.math3.util.ResizableDoubleArray var67 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var67.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var70 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var72 = var70.addElementRolling(Double.NaN);
    double[] var73 = var70.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var74 = new org.apache.commons.math3.util.ResizableDoubleArray(var73);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var67, var74);
    double[] var76 = var67.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var77 = new org.apache.commons.math3.util.ResizableDoubleArray(var76);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var78 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var79 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var80 = var79.getNumElements();
    double[] var81 = var79.getInternalValues();
    double[] var84 = new double[] { 10.0d, 100.0d};
    double var85 = var78.mannWhitneyU(var81, var84);
    var77.addElements(var84);
    var63.addElements(var84);
    var39.addElements(var84);
    double var89 = var0.mannWhitneyU(var37, var84);
    org.apache.commons.math3.util.ResizableDoubleArray var90 = new org.apache.commons.math3.util.ResizableDoubleArray(var84);
    org.apache.commons.math3.util.ResizableDoubleArray var91 = var90.copy();
    double[] var92 = var91.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var91.setNumElements((-1523011736));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.024588566448858762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test8"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var8 = var1.nextWeibull(0.7853981633974483d, 4.787491742782046d);
//     double var10 = var1.nextExponential(0.3971622936791505d);
//     int var13 = var1.nextPascal(102300, 0.9999943487368532d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var15 = var1.nextHexString((-1208213503));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.3737817533599352d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5204227150555929d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test9"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    var0.clear();
    var0.setExpansionFactor(2.4999998f);
    var0.clear();
    double[] var7 = var0.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test10"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)13.581326273360407d);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test11"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    var0.setNumElements(0);
    double var6 = var0.addElementRolling(0.0d);
    int var7 = var0.start();
    int var8 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(500);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var10);
    var10.discardMostRecentElements(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test12"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("29ed70f13bb7ad46f460186017e66097afb29425604f5ce6013aad50de27d1839ff38fefaf3024af2bb9c35db46ea9c1b39661db566c4d93ea5216e953f75608d761042d1d7c9f403ec945d2001667c7a7f1c60a14dfa3dc14b0957c90ba09741079085e8fe6ccff26bdbacc78c5ea6a12ce9921226c8dafc77c6bf83eeb751c6c26b9106d132d65504085de89e5a33d2dd3eb3d94e4d24877cc029b0895942a75b870c541f8bbbfd706029c3eea54aa1c278df2c7ec627a0b8ee3b72226b99fc483c806033dc210779f83cca2ed3a7245136fa3e9feba8009f2f6e62059c4e19dd78f68b4180a5327a52e8415f7dd4e0113efa08ba9649dba06");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test13"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    int var2 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var4 = var3.getNumElements();
    double[] var5 = var3.getInternalValues();
    int var6 = var3.getNumElements();
    double[] var7 = var3.getElements();
    var0.addElements(var7);
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var12);
    var0.setElement(89, 44.0d);
    double[] var17 = var0.getInternalValues();
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test14"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(30.90131202558219d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test15"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var13 = var1.nextUniform(0.9999943487368532d, 44.5140274520795d);
//     double var16 = var1.nextGaussian((-0.8887853505857057d), 2.882619330995207E-19d);
//     org.apache.commons.math3.distribution.NormalDistribution var17 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var19 = var17.density(100.0d);
//     double var22 = var17.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double[] var24 = var17.sample(100);
//     double var25 = var17.getStandardDeviation();
//     boolean var26 = var17.isSupportConnected();
//     double var27 = var17.getNumericalMean();
//     double var28 = var17.getSupportLowerBound();
//     double var29 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4620355860L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 40.20433588979746d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-0.8887853505857057d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.2666720360587287d);
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test16"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.5919185321270688d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5579541844064334d);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test17"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(5.83775991482695d, 0.3008208800303043d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.7002111707701477d);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test18"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.978735975787224d, (java.lang.Number)(-19.894922083922054d), false);
    java.lang.Throwable[] var8 = var7.getSuppressed();
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var12 = var10.addElementRolling(Double.NaN);
    double[] var13 = var10.getElements();
    int var14 = var10.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var10.copy();
    java.lang.Object[] var16 = new java.lang.Object[] { var10};
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var9, var16);
    org.apache.commons.math3.exception.MaxCountExceededException var18 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)2.0d, var16);
    org.apache.commons.math3.exception.MathIllegalArgumentException var19 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var16);
    org.apache.commons.math3.exception.MathArithmeticException var20 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test19"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("4de6bca8d155a053f373c1d7740431c9040a53e4937b94d87fd6fb166457961c76470789d14c0b8e177f046ed6433494419ef202b7f1abd34a5474652374aa3b597dbfe7f8f6489508b8401b9c58f1058f2116e0ef6a7a084c8c554bd2fed4372d47927cf4a9cae0e6c30973bdd395972c6a510dcdb017584cc158ec879b0edfc0880976ce0f91e51a5f7d87050958c0fb962d8");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test20"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     int var13 = var1.nextSecureInt(0, 10);
//     int var16 = var1.nextSecureInt((-15), 10230);
//     double var19 = var1.nextUniform(0.6381781975339198d, 17.160827757978193d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6870493915L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 6235);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 4.887853849943768d);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test21"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-1037414828), (java.lang.Number)50, (java.lang.Number)100.49999f);
    java.lang.Number var4 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 100.49999f+ "'", var4.equals(100.49999f));

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test22"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.05782461145270825d), (java.lang.Number)(-1L), (java.lang.Number)100.0d);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getArgument();
    java.lang.Number var6 = var3.getHi();
    java.lang.Number var7 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1L)+ "'", var4.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.05782461145270825d)+ "'", var5.equals((-0.05782461145270825d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 100.0d+ "'", var6.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1L)+ "'", var7.equals((-1L)));

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test23"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var11 = var10.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    int var15 = var12.getNumElements();
    double[] var16 = var12.getElements();
    var10.addElements(var16);
    var0.addElements(var16);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
    double[] var20 = var19.getElements();
    int var21 = var19.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test24"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-1.9200849871876335d));

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test25"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.05782461145270825d), (java.lang.Number)(-1L), (java.lang.Number)100.0d);
    java.lang.Number var8 = var7.getHi();
    java.lang.Number var9 = var7.getHi();
    java.lang.Number var10 = var7.getHi();
    java.lang.Throwable[] var11 = var7.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MaxCountExceededException var13 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)(-0.6480670652339844d), (java.lang.Object[])var11);
    org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.OutOfRangeException var18 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.05782461145270825d), (java.lang.Number)(-1L), (java.lang.Number)100.0d);
    org.apache.commons.math3.exception.util.ExceptionContext var19 = var18.getContext();
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var22 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var23 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var21, (java.lang.Object[])var22);
    org.apache.commons.math3.exception.MathIllegalStateException var24 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var18, var20, (java.lang.Object[])var22);
    java.lang.Number var25 = var18.getLo();
    var14.addSuppressed((java.lang.Throwable)var18);
    org.apache.commons.math3.exception.util.ExceptionContext var27 = var18.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 100.0d+ "'", var8.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 100.0d+ "'", var9.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 100.0d+ "'", var10.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + (-1L)+ "'", var25.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test26"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var1 = null;
    java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 9617852649L);
    java.math.BigInteger var6 = null;
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 9617852649L);
    java.math.BigInteger var11 = null;
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 9617852649L);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, var13);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 2147483647);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 268848753);
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var20);
    java.math.BigInteger var22 = null;
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, 0L);
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 9617852649L);
    java.math.BigInteger var27 = null;
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var27, 0L);
    java.math.BigInteger var31 = org.apache.commons.math3.util.ArithmeticUtils.pow(var29, 9617852649L);
    java.math.BigInteger var32 = null;
    java.math.BigInteger var34 = org.apache.commons.math3.util.ArithmeticUtils.pow(var32, 0L);
    java.math.BigInteger var36 = org.apache.commons.math3.util.ArithmeticUtils.pow(var34, 9617852649L);
    java.math.BigInteger var37 = org.apache.commons.math3.util.ArithmeticUtils.pow(var31, var34);
    java.math.BigInteger var39 = org.apache.commons.math3.util.ArithmeticUtils.pow(var31, 2147483647);
    java.math.BigInteger var41 = org.apache.commons.math3.util.ArithmeticUtils.pow(var39, 268848753);
    java.math.BigInteger var42 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, var41);
    java.math.BigInteger var43 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, var42);
    org.apache.commons.math3.exception.NumberIsTooLargeException var46 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)var20, (java.lang.Number)0.9706840563893051d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test27"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(0.999987895021552d, 15.322095332102348d, false);
//     double var8 = var1.nextGamma(1.4713540043352986d, 4.787491742782046d);
//     double var10 = var1.nextExponential(16.636486299878868d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var1.nextPascal((-347), 1.4127267382373947d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 6.990206223364635d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.2796281999995358d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.3228334010670281d);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test28"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p((-0.8877835989679871d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.1873261198204137d));

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test29"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(6966596131L, 108);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6871917878720261105L);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test30"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-9935950308L), 4174794088L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-9935950308L));

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test31"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.1190480415861142d, 0.10308570065519382d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.01489466562101785d));

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test32"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.8742557239907629d, 7.659187138866464E-7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8742557239907629d);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test33"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(3.6498866246896235d, 0.8860707256739782d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.7559011840016003d);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test34"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-2383204267L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test35"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(1.4601304898599397d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.025484084556813624d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test36"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(99.59410039019672d, 1.1435499697078755d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4207422088363699E-152d);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test37"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)41.86392792621338d, var1, (java.lang.Number)4.937302184657956d);
    java.lang.Number var4 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 4.937302184657956d+ "'", var4.equals(4.937302184657956d));

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test38"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)28.809936981510216d);

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test39"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     double var12 = var1.nextBeta(98.00138274241472d, 0.9984187364052811d);
//     double var15 = var1.nextUniform(4.61512051684126d, 57.348154628338996d);
//     int var18 = var1.nextSecureInt(0, 2147483647);
//     double var20 = var1.nextExponential(0.9942029313130951d);
//     org.apache.commons.math3.random.RandomGenerator var21 = null;
//     org.apache.commons.math3.random.RandomDataImpl var22 = new org.apache.commons.math3.random.RandomDataImpl(var21);
//     var22.reSeed();
//     double var26 = var22.nextGamma(0.0d, 29.9749466411613d);
//     double var29 = var22.nextWeibull(0.7853981633974483d, 4.787491742782046d);
//     double var31 = var22.nextExponential(0.3971622936791505d);
//     org.apache.commons.math3.distribution.NormalDistribution var32 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var33 = var32.getNumericalMean();
//     double var34 = var32.getStandardDeviation();
//     boolean var35 = var32.isSupportLowerBoundInclusive();
//     double var36 = var32.getSupportLowerBound();
//     double var37 = var32.getSupportLowerBound();
//     double var38 = var32.getMean();
//     boolean var39 = var32.isSupportConnected();
//     double var40 = var22.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var32);
//     double var41 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var32);
//     boolean var42 = var32.isSupportUpperBoundInclusive();
//     boolean var43 = var32.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 130);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.9816886725200062d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 10.979258747575432d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1120303560);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 2.8209306558653005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.4327025177403714d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0.7624953051774386d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == (-0.9270708665021296d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0.5790949274682355d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test40"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(1.5536402027341418d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.027116136929062982d);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test41"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, (-91.62775482961813d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test42"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var5 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)4.158638853279167d, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var5);
//     java.lang.String var10 = var9.toString();
// 
//   }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test43"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-5.011010127267165E-16d));
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     java.lang.Object[] var5 = new java.lang.Object[] { 408.119558159939d};
//     org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, var5);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test44"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 317);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test45"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextSecureHexString(6);
//     org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var5 = var4.getNumericalMean();
//     double var6 = var4.getStandardDeviation();
//     boolean var7 = var4.isSupportLowerBoundInclusive();
//     boolean var8 = var4.isSupportUpperBoundInclusive();
//     double var9 = var4.getStandardDeviation();
//     double var10 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var4);
//     var4.reseedRandomGenerator(3659212668L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "be946b"+ "'", var3.equals("be946b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.4498103349239252d));
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test46"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(1.7104468003622868d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.130794469657228d);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test47"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     int var8 = var1.nextInt((-347), 300);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextPascal(1242245, (-1.035776190367566d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-17));
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test48"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum((-62472.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test49"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.27787056710219493d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.30565712340265083d);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test50"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.5855819012757701d, (java.lang.Number)(-0.8877835989679871d), false);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test51"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-6197319789L), 9672270833L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9672270833L);

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test52"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     org.apache.commons.math3.distribution.IntegerDistribution var7 = null;
//     int var8 = var1.nextInversionDeviate(var7);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test53"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.start();
    double[] var2 = var0.getElements();
    var0.setContractionCriteria(15.999999f);
    var0.setNumElements(506);
    double[] var7 = var0.getInternalValues();
    var0.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test54"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    int var8 = var7.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    java.lang.Class var13 = var12.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var14.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7, var15);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    java.lang.Class var21 = var20.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.TiesStrategy var23 = var22.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var23);
    org.apache.commons.math3.random.RandomGenerator var26 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var26);
    int var28 = var2.ordinal();
    org.apache.commons.math3.random.RandomGenerator var29 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test55"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     int var8 = var1.nextInt((-347), 300);
//     int var11 = var1.nextSecureInt(3570, 2147483647);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextHypergeometric(0, (-367399667), 71);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-27));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1095289624);
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test56"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test57"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(0.999987895021552d, 15.322095332102348d, false);
//     double var8 = var1.nextGamma(1.4713540043352986d, 4.787491742782046d);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var9.getMean();
//     double var13 = var9.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var14 = var9.getNumericalVariance();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     var1.reSeedSecure((-10L));
//     var1.reSeedSecure();
//     org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var20 = var19.getNumericalMean();
//     double var21 = var19.getStandardDeviation();
//     boolean var22 = var19.isSupportLowerBoundInclusive();
//     double var23 = var19.getSupportLowerBound();
//     double var24 = var19.getSupportLowerBound();
//     double var25 = var19.getMean();
//     boolean var26 = var19.isSupportConnected();
//     double var28 = var19.probability((-0.05388929638978884d));
//     double var29 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var19);
//     var19.reseedRandomGenerator(2147282030L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.976452739441328d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 9.19883568199759d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.3960339181140022d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == (-1.47454219857117d));
// 
//   }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test58"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     var1.reSeed((-2502316609L));
//     double var11 = var1.nextGamma((-0.05788914687716099d), (-0.9918946513810528d));
//     int var14 = var1.nextBinomial(0, 1.1529248674810905E-9d);
//     double var17 = var1.nextCauchy((-0.057824611452708244d), 0.9997643044330278d);
//     org.apache.commons.math3.distribution.IntegerDistribution var18 = null;
//     int var19 = var1.nextInversionDeviate(var18);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test59"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)108.67153323312886d, (java.lang.Number)0.9997643044330278d, (java.lang.Number)8179512108L);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    java.lang.Number var5 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.9997643044330278d+ "'", var5.equals(0.9997643044330278d));

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test60"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.3841858E-7f, 3.4028233E38f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.4028233E38f);

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test61"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var4 = var1.nextChiSquare(5.464265321962551d);
//     int var8 = var1.nextHypergeometric(1704294704, 5215, 10400);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextWeibull(1.7126504395271167d, (-0.10747463203439028d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4.998561189914695d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
// 
//   }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test62"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextUniform(0.723245967437971d, 5.205744238502723d);
//     org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var5 = var4.getMean();
//     double var8 = var4.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var11 = var4.cumulativeProbability(4.158638853279167d, 24.0d);
//     double var12 = var4.sample();
//     boolean var13 = var4.isSupportLowerBoundInclusive();
//     double var14 = var4.getSupportUpperBound();
//     boolean var15 = var4.isSupportLowerBoundInclusive();
//     double var16 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextPascal(5306065, 4.61512051684126d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.7972916988953334d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.600747998428365E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.6762536365159757d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-1.2311799484485848d));
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test63"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getStandardDeviation();
    double var10 = var0.cumulativeProbability((-0.004920366423301847d));
    double var12 = var0.cumulativeProbability(2.3319900186847273d);
    double var13 = var0.getSupportUpperBound();
    double var14 = var0.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.4980370657191222d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.9901493918730617d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test64"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.9999999984350594d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test65"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-1523011736), 101794);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 101794);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test66"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(1.6481511386764256d, (-0.04087591190814478d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.6486579439334044d);

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test67"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var8 = var1.nextWeibull(0.7853981633974483d, 4.787491742782046d);
//     double var10 = var1.nextExponential(0.3971622936791505d);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var11.getNumericalMean();
//     double var13 = var11.getStandardDeviation();
//     boolean var14 = var11.isSupportLowerBoundInclusive();
//     double var15 = var11.getSupportLowerBound();
//     double var16 = var11.getSupportLowerBound();
//     double var17 = var11.getMean();
//     boolean var18 = var11.isSupportConnected();
//     double var19 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     double var21 = var1.nextExponential(0.784587795077617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 21.91602523726247d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.24497605252155716d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-1.5367994385777366d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.15743470635262477d);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test68"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.9969225457154951d);
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var5, var8);
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)(-0.6602342291255047d), var8);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test69"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var3 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var4 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var3);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test70"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(0.999987895021552d, 15.322095332102348d, false);
//     double var8 = var1.nextGamma(1.4713540043352986d, 4.787491742782046d);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var9.getMean();
//     double var13 = var9.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var14 = var9.getNumericalVariance();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     var1.reSeedSecure((-10L));
//     double var20 = var1.nextUniform(1.661452088092057d, 270.6122171624811d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var1.nextSecureInt(1161, (-721445887));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 9.276673798193313d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.614531278886361d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.3146663602928139d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 151.71601994323964d);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test71"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(3.0337905691391223d, 0.1354528887171666d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.8480695833549033d));

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test72"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    var0.clear();
    var0.contract();
    boolean var6 = var0.equals((java.lang.Object)0.5587178359296467d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test73"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.5607966601082315d);
//     java.lang.String var4 = var0.nextHexString(506);
//     double var7 = var0.nextCauchy(0.3063909472492726d, 1.5607966601082315d);
//     double var10 = var0.nextUniform((-0.6932391748384723d), 0.14049621499892223d);
//     double var13 = var0.nextCauchy((-0.3767776375127554d), 1.663615071967229d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.7451328425985342d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "321c187e8533a6e4d600bbaa7efca3f68d06af2e8a294d0a6b4f531de0f8712cc135752e1f88ba12e0406cce3fde63413e8190e5cba2510e37416f74097b6d659173af10a46c021547adb1865a24e8b74a2fe77b1756ede897f031c2cc19a7de0e2d803bc23cad7700b82a275d799ebbb615c396742661afd6a6672a9478a68eed21d6443775a3995e3a88a1bdaba317100d5ea99b03abcf221fdf17f75be127d6ec07ff51f77cc8a8ed170548b9c380c812a850907123de7976832b6f93ee35ced39bf53f15f13586ac9c9e2244bd7f9b66a34bca4e09093696842525d1e39a2d85dbce240f8a28ed625b9e16fb560235bcfad67c30f21b55f2d57d25"+ "'", var4.equals("321c187e8533a6e4d600bbaa7efca3f68d06af2e8a294d0a6b4f531de0f8712cc135752e1f88ba12e0406cce3fde63413e8190e5cba2510e37416f74097b6d659173af10a46c021547adb1865a24e8b74a2fe77b1756ede897f031c2cc19a7de0e2d803bc23cad7700b82a275d799ebbb615c396742661afd6a6672a9478a68eed21d6443775a3995e3a88a1bdaba317100d5ea99b03abcf221fdf17f75be127d6ec07ff51f77cc8a8ed170548b9c380c812a850907123de7976832b6f93ee35ced39bf53f15f13586ac9c9e2244bd7f9b66a34bca4e09093696842525d1e39a2d85dbce240f8a28ed625b9e16fb560235bcfad67c30f21b55f2d57d25"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3.4905847651889284d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.6004131921785699d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.4332605129528586d);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test74"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)534.0847917014123d, (java.lang.Number)(-0.6321205588285577d), false);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test75"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(2.2872098462983455d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8273326669740025d);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test76"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2.9750822343314782d, (java.lang.Number)0.1326918856648829d, true);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test77"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(466, 287762967);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test78"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var5 = var1.nextPoisson(0.9720449790817591d);
//     double var7 = var1.nextChiSquare(98.87065559519353d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("43c7cbbeb669b78cf9532aa66a8829f3c70ae9e732229f4700ab780e441e17accd5ec28c2f274b8baf6a584dbcc243ac79b99f730fccb090f1e962b326642416782a80dc6eb8236cebc1991725c5a255113a01d54273006da1ab8d38dc1d42c05ac387164f5c7f35ba28524ecfc8a7cc510f251eac8c39fe55ac97b9c723359967595fa38c67acbf8f20125f67729d933931b6e0cdfb27823f6d4f356e52934d05fb44c0c7dd85dba796b72e593ec9f0cb1eb0cda28fbc4ba86581a50f284dda99bfcba539b1f699f37f3775abe97bfd14fcf1c81cd24cd18787a7e080b25301c8d5a29cfb685d9e767c124c70e8b5fdfceab5b16c6e53cff266064578", "c9a799ebc5eb133d278b3e8ab7fbad74dc66fc756bcec0a211566f48c835adc108e0b17b1aad782f91fcbb126d5cb0cee0675f2b694c9bbd915e1de1213f856d975fdbb67920c8c940bb9cf24099e34c82737431bbeddb6c8873f91c77a4a5b5c12982866675cceaa1ceae431108fc89c10b56667ee2c60efddfe752cba3980028cd9dbf3e45a7607428a392831be67863a84a99a9b13d5849a4cae436b673d3b73a4e31a9d0aad74f3f9ab5bd38818c61d1a4da76378887ac4");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 98.24934212859165d);
// 
//   }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test79"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-1023), 0);
//     java.lang.String var6 = var1.nextSecureHexString(6);
//     int var9 = var1.nextZipf(208, 13.753533396481055d);
//     double var12 = var1.nextBeta(0.23463083213982616d, 1.630075354747883d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-320));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "867683"+ "'", var6.equals("867683"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 8.676907332771187E-8d);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test80"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(16938263, (-367399667));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-350461404));

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test81"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(3.7001409843068185d, 0.6664608671166427d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9913993325135647d);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test82"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(127);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test83"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     java.lang.String var8 = var1.nextHexString(500);
//     double var10 = var1.nextT(0.9584128699015102d);
//     var1.reSeed();
//     int var14 = var1.nextZipf(65, 0.841037877334904d);
//     int var17 = var1.nextZipf(396, 1.82442736154459d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var19 = var1.nextSecureHexString((-20));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 105896236L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "cbfff0ce5115f70a0927b83d0191101bd38fde6ac7cbd320a2e24615519e392780687ae4cc1aba2f9f6857d2c464d50ecd60f3ee496b8674666b5ed15a15f634d4f66266b5e9b0aecd0d6c03327338d61e06ca94a32c3207e0ca329973c21f5b033ed969e8f0f707cfe1d06ce5ec5dd67561aa91d6fbd07d839406b27071085f92ac8b29e2786fcb2dcb349e86ee5a09b04abb927a28b31bd2865b6a677c6b663ce4a438653b44575ac882445300ff13f6eabd2b9bea8ac23f276df51a76a0e008f6ae3cf142aa7930fb9e1316bf636e46fa6a0fae27468a897dc469d51945c7ab2eecdbb5ad1c848db2c03ec8629b63d22a2409f4899bcfdcec"+ "'", var8.equals("cbfff0ce5115f70a0927b83d0191101bd38fde6ac7cbd320a2e24615519e392780687ae4cc1aba2f9f6857d2c464d50ecd60f3ee496b8674666b5ed15a15f634d4f66266b5e9b0aecd0d6c03327338d61e06ca94a32c3207e0ca329973c21f5b033ed969e8f0f707cfe1d06ce5ec5dd67561aa91d6fbd07d839406b27071085f92ac8b29e2786fcb2dcb349e86ee5a09b04abb927a28b31bd2865b6a677c6b663ce4a438653b44575ac882445300ff13f6eabd2b9bea8ac23f276df51a76a0e008f6ae3cf142aa7930fb9e1316bf636e46fa6a0fae27468a897dc469d51945c7ab2eecdbb5ad1c848db2c03ec8629b63d22a2409f4899bcfdcec"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.021169682158944936d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 3);
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test84"); }


    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 9617852649L);
    java.math.BigInteger var7 = null;
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 9617852649L);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var9);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 2147483647);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 268848753);
    org.apache.commons.math3.exception.OutOfRangeException var17 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.0d), (java.lang.Number)2325017522L, (java.lang.Number)var14);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 1037420971);
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, 2654386936L);
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 0);
    java.math.BigInteger var26 = null;
    java.math.BigInteger var28 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 0L);
    java.math.BigInteger var30 = org.apache.commons.math3.util.ArithmeticUtils.pow(var28, 9617852649L);
    java.math.BigInteger var31 = null;
    java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var31, 0L);
    java.math.BigInteger var35 = org.apache.commons.math3.util.ArithmeticUtils.pow(var33, 9617852649L);
    java.math.BigInteger var36 = org.apache.commons.math3.util.ArithmeticUtils.pow(var30, var33);
    java.math.BigInteger var38 = org.apache.commons.math3.util.ArithmeticUtils.pow(var30, 2147483647);
    java.math.BigInteger var40 = org.apache.commons.math3.util.ArithmeticUtils.pow(var38, 268848753);
    org.apache.commons.math3.exception.OutOfRangeException var41 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.0d), (java.lang.Number)2325017522L, (java.lang.Number)var38);
    java.math.BigInteger var43 = org.apache.commons.math3.util.ArithmeticUtils.pow(var38, 1037420971);
    java.math.BigInteger var44 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test85"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(28.809936981510216d, 0.8066155499161133d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.06394703969671599d));

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test86"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     var1.reSeed((-2502316609L));
//     double var11 = var1.nextGaussian(1.7427271998994087d, 0.8266429039966963d);
//     double var13 = var1.nextChiSquare(0.5552592332346065d);
//     java.lang.String var15 = var1.nextSecureHexString(287);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1179931452L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0242563501897255d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.3719042446880644E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "8a1fa08a473d34040d80fa62eaaf3a381874b2186a8e5228232d93482bb122c0f9f67243e1e0eeaf876c6b0be726d02d270de1a3c19a91c54dc0b533cfb5c8a4d166dd6b02713c865edadcc89fbdc533e3d830ee654df9685699e4192b6aae3bff2a3ea500f5844ce70430775486647bd54d26e26e0e702df4e1d60acb665da16b11ac46b881f4691cb47238ecac4c3"+ "'", var15.equals("8a1fa08a473d34040d80fa62eaaf3a381874b2186a8e5228232d93482bb122c0f9f67243e1e0eeaf876c6b0be726d02d270de1a3c19a91c54dc0b533cfb5c8a4d166dd6b02713c865edadcc89fbdc533e3d830ee654df9685699e4192b6aae3bff2a3ea500f5844ce70430775486647bd54d26e26e0e702df4e1d60acb665da16b11ac46b881f4691cb47238ecac4c3"));
// 
//   }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test87"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    double var3 = var1.addElementRolling((-0.05782461145270825d));
    org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var6 = var4.density(100.0d);
    double var9 = var4.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double var11 = var4.cumulativeProbability(0.6139648708421599d);
    boolean var12 = var4.isSupportLowerBoundInclusive();
    double var13 = var4.getSupportLowerBound();
    double var14 = var4.getNumericalMean();
    boolean var15 = var1.equals((java.lang.Object)var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.7303807294278502d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test88"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.3989390873839266d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test89"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(4.302510192112992E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.302510192112992E-15d);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test90"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(664646591L, 563664581L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 374637742229093371L);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test91"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 9617852649L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 9617852649L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var9);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 3628800L);
    java.math.BigInteger var13 = null;
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 0L);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 9617852649L);
    java.math.BigInteger var18 = null;
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 0L);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, 9617852649L);
    java.math.BigInteger var23 = null;
    java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, 0L);
    java.math.BigInteger var27 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, 9617852649L);
    java.math.BigInteger var28 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, var25);
    java.math.BigInteger var30 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, 2147483647);
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var30, 268848753);
    java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, var32);
    java.math.BigInteger var34 = null;
    java.math.BigInteger var36 = org.apache.commons.math3.util.ArithmeticUtils.pow(var34, 0L);
    java.math.BigInteger var38 = org.apache.commons.math3.util.ArithmeticUtils.pow(var36, 9617852649L);
    java.math.BigInteger var39 = null;
    java.math.BigInteger var41 = org.apache.commons.math3.util.ArithmeticUtils.pow(var39, 0L);
    java.math.BigInteger var43 = org.apache.commons.math3.util.ArithmeticUtils.pow(var41, 9617852649L);
    java.math.BigInteger var44 = null;
    java.math.BigInteger var46 = org.apache.commons.math3.util.ArithmeticUtils.pow(var44, 0L);
    java.math.BigInteger var48 = org.apache.commons.math3.util.ArithmeticUtils.pow(var46, 9617852649L);
    java.math.BigInteger var49 = org.apache.commons.math3.util.ArithmeticUtils.pow(var43, var46);
    java.math.BigInteger var51 = org.apache.commons.math3.util.ArithmeticUtils.pow(var43, 2147483647);
    java.math.BigInteger var53 = org.apache.commons.math3.util.ArithmeticUtils.pow(var51, 268848753);
    java.math.BigInteger var54 = org.apache.commons.math3.util.ArithmeticUtils.pow(var38, var53);
    java.math.BigInteger var55 = org.apache.commons.math3.util.ArithmeticUtils.pow(var32, var54);
    java.math.BigInteger var56 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, var55);
    java.math.BigInteger var58 = org.apache.commons.math3.util.ArithmeticUtils.pow(var56, 264);
    java.math.BigInteger var59 = null;
    java.math.BigInteger var61 = org.apache.commons.math3.util.ArithmeticUtils.pow(var59, 0L);
    java.math.BigInteger var63 = org.apache.commons.math3.util.ArithmeticUtils.pow(var61, 9617852649L);
    java.math.BigInteger var64 = null;
    java.math.BigInteger var66 = org.apache.commons.math3.util.ArithmeticUtils.pow(var64, 0L);
    java.math.BigInteger var68 = org.apache.commons.math3.util.ArithmeticUtils.pow(var66, 9617852649L);
    java.math.BigInteger var69 = org.apache.commons.math3.util.ArithmeticUtils.pow(var63, var66);
    org.apache.commons.math3.exception.util.Localizable var70 = null;
    java.math.BigInteger var71 = null;
    java.math.BigInteger var73 = org.apache.commons.math3.util.ArithmeticUtils.pow(var71, 0L);
    java.math.BigInteger var75 = org.apache.commons.math3.util.ArithmeticUtils.pow(var73, 9617852649L);
    java.math.BigInteger var76 = null;
    java.math.BigInteger var78 = org.apache.commons.math3.util.ArithmeticUtils.pow(var76, 0L);
    java.math.BigInteger var80 = org.apache.commons.math3.util.ArithmeticUtils.pow(var78, 9617852649L);
    java.math.BigInteger var81 = org.apache.commons.math3.util.ArithmeticUtils.pow(var75, var78);
    java.math.BigInteger var83 = org.apache.commons.math3.util.ArithmeticUtils.pow(var75, 2147483647);
    java.math.BigInteger var85 = org.apache.commons.math3.util.ArithmeticUtils.pow(var83, 6949188755L);
    java.lang.Number var86 = null;
    org.apache.commons.math3.exception.OutOfRangeException var88 = new org.apache.commons.math3.exception.OutOfRangeException(var70, (java.lang.Number)var85, var86, (java.lang.Number)9.332621544395286E157d);
    java.math.BigInteger var90 = org.apache.commons.math3.util.ArithmeticUtils.pow(var85, 0L);
    java.math.BigInteger var92 = org.apache.commons.math3.util.ArithmeticUtils.pow(var85, 208);
    java.math.BigInteger var93 = org.apache.commons.math3.util.ArithmeticUtils.pow(var66, var92);
    java.math.BigInteger var95 = org.apache.commons.math3.util.ArithmeticUtils.pow(var92, 0L);
    java.math.BigInteger var97 = org.apache.commons.math3.util.ArithmeticUtils.pow(var92, 35);
    java.math.BigInteger var98 = org.apache.commons.math3.util.ArithmeticUtils.pow(var56, var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test92"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-5154125899424117313L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5154125899424117313L);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test93"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(111, 445);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test94"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    java.lang.Class var4 = var3.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    java.lang.String var7 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    java.lang.Class var11 = var10.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var13 = java.lang.Enum.<java.lang.Enum>valueOf(var11, "eb20956f83be9dec30f4ed5abc219dd1773165810c68d21fd12e06b3d24158d48478bcb406582defd4ab5ced3894068cebfda6d37a561faf768885fb1019d7d7e82342c5e6aad735a8170a4f2a1a660a89f1cb9f1b0ba2dd4ead8c0267a45b5adfd83ed8eae7ed3787606527361e1a0e819e1f596e2439a373f26b280c67147e2e331ba5ff7aaa474428f0b5b877106ec0a7b9badc6a86ca629e1bc6d8c1edf06c942868ce919c25c913c9912906a857d6796e85b2fbcb0e3e0");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "AVERAGE"+ "'", var7.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test95"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var17 = var16.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    int var21 = var18.getNumElements();
    double[] var22 = var18.getElements();
    var16.addElements(var22);
    float var24 = var16.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var16);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.distribution.NormalDistribution var27 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var28 = var27.getMean();
    double var31 = var27.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var32 = var27.getSupportUpperBound();
    double[] var34 = var27.sample(371);
    var26.addElements(var34);
    float var36 = var26.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0f);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test96"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Throwable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var7, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var6, var9);
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var4, var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var9);
    org.apache.commons.math3.exception.MathArithmeticException var14 = new org.apache.commons.math3.exception.MathArithmeticException(var2, var9);
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var1, var9);
    org.apache.commons.math3.exception.MathInternalError var16 = new org.apache.commons.math3.exception.MathInternalError(var0, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test97"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    int var2 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var4 = var3.getNumElements();
    double[] var5 = var3.getInternalValues();
    int var6 = var3.getNumElements();
    double[] var7 = var3.getElements();
    var0.addElements(var7);
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var12);
    float var14 = var12.getContractionCriteria();
    var12.contract();
    var12.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.5f);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test98"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var11 = var9.addElementRolling(Double.NaN);
    double[] var12 = var9.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var6, var13);
    double[] var15 = var6.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    double[] var23 = new double[] { 10.0d, 100.0d};
    double var24 = var17.mannWhitneyU(var20, var23);
    var16.addElements(var23);
    var5.addElements(var23);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = var5.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test99"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(4.6E-44f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-127));

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test100"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(0, 35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 35);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test101"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getStandardDeviation();
    boolean var9 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator(1L);
    boolean var12 = var0.isSupportLowerBoundInclusive();
    double var13 = var0.getMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var15 = var0.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test102"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)Double.NaN, (java.lang.Number)0.6139648708421599d, true);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var8 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var6, (java.lang.Number)4.158638853279167d, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var8);
    java.lang.String var12 = var3.toString();
    boolean var13 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: \uFFFD is larger than the maximum (0.614)"+ "'", var12.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: \uFFFD is larger than the maximum (0.614)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test103"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.01295210122135538d, 1.2196240406125857E-104d);

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test104"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var7 = var1.nextExponential(209.99999999999997d);
//     double var10 = var1.nextGaussian(0.6387763808612118d, 9.999999999999996d);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var11.getMean();
//     double var15 = var11.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var18 = var11.cumulativeProbability((-19.894922083922054d), 0.7853981633974483d);
//     double var19 = var11.sample();
//     double var20 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     double var23 = var1.nextUniform(34.812727742759826d, 44.34227194424954d);
//     double var25 = var1.nextChiSquare(1.6386034556842697d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var27 = var1.nextSecureHexString((-1865625573));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9999999727757307d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 340.97356045736035d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 12.066836101917083d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.7838899213734127d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-2.2915116364120505d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.8140528291508494d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 39.71356565154663d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 2.1226078158123087d);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test105"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(815135694L, 1000);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test106"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    int var4 = var3.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    org.apache.commons.math3.random.RandomGenerator var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = var7.getTiesStrategy();
    boolean var10 = var8.equals((java.lang.Object)10.015471524400919d);
    java.lang.Class var11 = var8.getDeclaringClass();
    java.lang.String var12 = var8.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var13 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    org.apache.commons.math3.exception.util.Localizable var17 = null;
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    org.apache.commons.math3.exception.util.Localizable var19 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var21 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var22 = new org.apache.commons.math3.exception.MaxCountExceededException(var19, (java.lang.Number)4.158638853279167d, (java.lang.Object[])var21);
    org.apache.commons.math3.exception.MathIllegalArgumentException var23 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var18, (java.lang.Object[])var21);
    org.apache.commons.math3.exception.MathIllegalStateException var24 = new org.apache.commons.math3.exception.MathIllegalStateException(var17, (java.lang.Object[])var21);
    org.apache.commons.math3.exception.MathIllegalArgumentException var25 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var16, (java.lang.Object[])var21);
    org.apache.commons.math3.exception.NullArgumentException var26 = new org.apache.commons.math3.exception.NullArgumentException(var15, (java.lang.Object[])var21);
    boolean var27 = var8.equals((java.lang.Object)var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "RANDOM"+ "'", var12.equals("RANDOM"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test107"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    var0.setNumElements(0);
    double var6 = var0.addElementRolling(0.0d);
    int var7 = var0.start();
    int var8 = var0.start();
    int var9 = var0.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test108"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(2294019310L, (-30));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test109"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var6);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var2, var6);
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)4.923048941477225d, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test110"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     var1.reSeed();
//     double var10 = var1.nextBeta(31.984371183438952d, 3.141592653589793d);
//     var1.reSeed();
//     var1.reSeedSecure(0L);
//     var1.reSeed(194432926L);
//     double var18 = var1.nextGaussian(0.19293462643708276d, 13.753533396481057d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.923940292812144d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-25.849813805895252d));
// 
//   }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test111"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var12 = var1.nextChiSquare(0.001736111111111111d);
//     java.lang.String var14 = var1.nextSecureHexString(50);
//     double var17 = var1.nextGamma(0.8386108841347789d, 0.8856391560282136d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 535146760L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.6979363951613244E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "42be68392c658620f64800f89864e78c6033d9135adfb42982"+ "'", var14.equals("42be68392c658620f64800f89864e78c6033d9135adfb42982"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.09115886804466157d);
// 
//   }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test112"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     long var10 = var1.nextLong(0L, 10000000000L);
//     double var12 = var1.nextT(0.0010774392745906561d);
//     int var15 = var1.nextZipf(1000, 7.561939231007603d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.0642290340042742d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3446511997L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.3407807929942597E154d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test113"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-0.08948812915473234d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.08936911883891363d));

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test114"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var7 = var1.nextExponential(209.99999999999997d);
//     double var10 = var1.nextUniform(1.3648793247295046d, 200.94444231998796d);
//     int var13 = var1.nextInt(65, 211);
//     double var15 = var1.nextChiSquare(3.986896366226194d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var18 = var1.nextSecureLong(2147282030L, (-4685954328653257593L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9999995594361226d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 153.83036343629684d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 52.031799920515766d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 166);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 9.029088343827086d);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test115"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var3.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var8 = var6.addElementRolling(Double.NaN);
    double[] var9 = var6.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var10);
    double[] var12 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var16 = var15.getNumElements();
    double[] var17 = var15.getInternalValues();
    double[] var20 = new double[] { 10.0d, 100.0d};
    double var21 = var14.mannWhitneyU(var17, var20);
    var13.addElements(var20);
    boolean var23 = var2.equals((java.lang.Object)var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var25 = var13.getElement(34548326);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test116"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-17), 210);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-835664351));

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test117"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Throwable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var4, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var7);
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)1.6386034556842697d, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test118"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    java.lang.String var6 = var2.toString();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var10 = var9.getNumElements();
    double[] var11 = var9.getInternalValues();
    java.lang.Object var12 = null;
    boolean var13 = var9.equals(var12);
    var9.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var9.copy();
    double[] var16 = var15.getInternalValues();
    double[] var17 = var8.rank(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "MAXIMAL"+ "'", var6.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test119"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 9617852649L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 9617852649L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var9);
    java.math.BigInteger var11 = null;
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 9617852649L);
    java.math.BigInteger var16 = null;
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 0L);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 9617852649L);
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, var18);
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 5002023);
    java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 0);
    java.math.BigInteger var26 = null;
    java.math.BigInteger var28 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 0L);
    java.math.BigInteger var30 = org.apache.commons.math3.util.ArithmeticUtils.pow(var28, 9617852649L);
    java.math.BigInteger var31 = null;
    java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var31, 0L);
    java.math.BigInteger var35 = org.apache.commons.math3.util.ArithmeticUtils.pow(var33, 9617852649L);
    java.math.BigInteger var36 = org.apache.commons.math3.util.ArithmeticUtils.pow(var30, var33);
    java.math.BigInteger var38 = org.apache.commons.math3.util.ArithmeticUtils.pow(var30, 2147483647);
    java.math.BigInteger var40 = org.apache.commons.math3.util.ArithmeticUtils.pow(var38, 6949188755L);
    java.math.BigInteger var41 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, var38);
    java.math.BigInteger var42 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var41);
    java.math.BigInteger var44 = org.apache.commons.math3.util.ArithmeticUtils.pow(var41, 66495);
    java.math.BigInteger var45 = null;
    java.math.BigInteger var47 = org.apache.commons.math3.util.ArithmeticUtils.pow(var45, 0L);
    java.math.BigInteger var49 = org.apache.commons.math3.util.ArithmeticUtils.pow(var47, 9617852649L);
    java.math.BigInteger var50 = null;
    java.math.BigInteger var52 = org.apache.commons.math3.util.ArithmeticUtils.pow(var50, 0L);
    java.math.BigInteger var54 = org.apache.commons.math3.util.ArithmeticUtils.pow(var52, 9617852649L);
    java.math.BigInteger var55 = org.apache.commons.math3.util.ArithmeticUtils.pow(var49, var54);
    java.math.BigInteger var56 = null;
    java.math.BigInteger var58 = org.apache.commons.math3.util.ArithmeticUtils.pow(var56, 0L);
    java.math.BigInteger var60 = org.apache.commons.math3.util.ArithmeticUtils.pow(var58, 9617852649L);
    java.math.BigInteger var61 = null;
    java.math.BigInteger var63 = org.apache.commons.math3.util.ArithmeticUtils.pow(var61, 0L);
    java.math.BigInteger var65 = org.apache.commons.math3.util.ArithmeticUtils.pow(var63, 9617852649L);
    java.math.BigInteger var66 = org.apache.commons.math3.util.ArithmeticUtils.pow(var60, var63);
    java.math.BigInteger var68 = org.apache.commons.math3.util.ArithmeticUtils.pow(var60, 5002023);
    java.math.BigInteger var70 = org.apache.commons.math3.util.ArithmeticUtils.pow(var60, 0);
    java.math.BigInteger var71 = null;
    java.math.BigInteger var73 = org.apache.commons.math3.util.ArithmeticUtils.pow(var71, 0L);
    java.math.BigInteger var75 = org.apache.commons.math3.util.ArithmeticUtils.pow(var73, 9617852649L);
    java.math.BigInteger var76 = null;
    java.math.BigInteger var78 = org.apache.commons.math3.util.ArithmeticUtils.pow(var76, 0L);
    java.math.BigInteger var80 = org.apache.commons.math3.util.ArithmeticUtils.pow(var78, 9617852649L);
    java.math.BigInteger var81 = org.apache.commons.math3.util.ArithmeticUtils.pow(var75, var78);
    java.math.BigInteger var83 = org.apache.commons.math3.util.ArithmeticUtils.pow(var75, 2147483647);
    java.math.BigInteger var85 = org.apache.commons.math3.util.ArithmeticUtils.pow(var83, 6949188755L);
    java.math.BigInteger var86 = org.apache.commons.math3.util.ArithmeticUtils.pow(var70, var83);
    java.math.BigInteger var87 = org.apache.commons.math3.util.ArithmeticUtils.pow(var49, var86);
    java.math.BigInteger var89 = org.apache.commons.math3.util.ArithmeticUtils.pow(var86, 66495);
    java.math.BigInteger var90 = org.apache.commons.math3.util.ArithmeticUtils.pow(var41, var89);
    org.apache.commons.math3.exception.OutOfRangeException var93 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)var89, (java.lang.Number)0.15793236125453095d, (java.lang.Number)5215);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test120"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(100.49998f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test121"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test122"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(6.796450769705151E-10d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test123"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.026488547631604686d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.02648854763160469d);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test124"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(233.8496495617364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.8421709430404007E-14d);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test125"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(700, 1734790817);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1734790117));

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test126"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.374727287185447d, (-1.0084760157976542d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.2037072370414807d);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test127"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.Class var5 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    java.lang.Class var9 = var8.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var10.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    int var16 = var15.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    java.lang.Class var21 = var20.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.TiesStrategy var23 = var22.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var23);
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var23);
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var25.getTiesStrategy();
    java.lang.Class var27 = var26.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var26);
    java.lang.Class var29 = var2.getDeclaringClass();
    int var30 = var2.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test128"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.13885830152301762d);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test129"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    var0.contract();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl(var11);
    var12.reSeed();
    double var16 = var12.nextGamma(0.0d, 29.9749466411613d);
    var12.reSeedSecure();
    var12.reSeed();
    boolean var19 = var0.equals((java.lang.Object)var12);
    double[] var20 = var0.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test130"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var2 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.OutOfRangeException var8 = new org.apache.commons.math3.exception.OutOfRangeException(var4, (java.lang.Number)24.0d, (java.lang.Number)0.723245967437971d, (java.lang.Number)825);
    var3.addSuppressed((java.lang.Throwable)var8);
    java.lang.Number var10 = var8.getArgument();
    java.lang.Throwable[] var11 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 24.0d+ "'", var10.equals(24.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test131"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(9.857440630569243d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999945176614d);

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test132"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var7 = var1.nextExponential(209.99999999999997d);
//     double var10 = var1.nextUniform(1.3648793247295046d, 200.94444231998796d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var13 = var1.nextSecureLong(1619796881L, (-5116033638L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.999966879488739d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 204.81380265023813d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 116.99683695211516d);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test133"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.5374527069121192d), (java.lang.Number)7.8492444081989055d, (java.lang.Number)371);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getLo();
    java.lang.Number var6 = var3.getLo();
    java.lang.Number var7 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 7.8492444081989055d+ "'", var4.equals(7.8492444081989055d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 7.8492444081989055d+ "'", var5.equals(7.8492444081989055d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 7.8492444081989055d+ "'", var6.equals(7.8492444081989055d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 7.8492444081989055d+ "'", var7.equals(7.8492444081989055d));

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test134"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)37.13351505357305d);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test135"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.3063909472492726d, (java.lang.Number)10.760549867472612d, true);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.760549867472612d+ "'", var5.equals(10.760549867472612d));

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test136"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(15.227362052091127d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 15.227362052091127d);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test137"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getStandardDeviation();
    boolean var9 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator(1L);
    boolean var12 = var0.isSupportLowerBoundInclusive();
    double var13 = var0.getMean();
    var0.reseedRandomGenerator(7172474253L);
    double var16 = var0.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test138"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(3.6498866246896235d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0d);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test139"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.start();
    double[] var2 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    double[] var5 = var4.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var4);
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardMostRecentElements(1000);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test140"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-65), 613865270);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test141"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var0.discardFrontElements(0);
//     org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     double var5 = var3.addElementRolling(Double.NaN);
//     double[] var6 = var3.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
//     double[] var9 = var0.getElements();
//     var0.contract();
//     org.apache.commons.math3.random.RandomGenerator var11 = null;
//     org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl(var11);
//     var12.reSeed();
//     double var16 = var12.nextGamma(0.0d, 29.9749466411613d);
//     var12.reSeedSecure();
//     var12.reSeed();
//     boolean var19 = var0.equals((java.lang.Object)var12);
//     double var21 = var12.nextT(0.9985619410825101d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var12.nextUniform(2.6060472602392943d, 0.23248394861570112d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.2630572171952427d);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test142"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(7728114113L, (-7565329397515920203L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7565329405244034316L);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test143"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(10.639437106367753d, 2.12090952255429d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.002704950260601357d));

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test144"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-47515));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 47515);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test145"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(9900, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9900);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test146"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.Class var5 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    java.lang.Class var9 = var8.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var10.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    int var16 = var15.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    java.lang.Class var21 = var20.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.TiesStrategy var23 = var22.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var23);
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var23);
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var25.getTiesStrategy();
    java.lang.Class var27 = var26.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var26);
    java.lang.Class var29 = var2.getDeclaringClass();
    org.apache.commons.math3.random.RandomGenerator var30 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test147"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.5607966601082315d);
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var5 = var3.density(100.0d);
//     double var8 = var3.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double[] var10 = var3.sample(100);
//     double var11 = var3.getStandardDeviation();
//     double var13 = var3.cumulativeProbability((-0.004920366423301847d));
//     double var14 = var3.getNumericalVariance();
//     double var15 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var18 = var0.nextLong(9351877256L, 140149608L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.076878262719231d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.4980370657191222d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.8272430219098542d));
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test148"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.12241625271016868d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-8.560935067928314d));

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test149"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextPascal(100, 0.0d);
//     long var5 = var0.nextPoisson(0.07637989519631011d);
//     var0.reSeedSecure(9617852649L);
//     double var10 = var0.nextGamma(1.071112867107899d, (-0.010152952316618155d));
//     java.lang.String var12 = var0.nextHexString(317);
//     var0.reSeed(82120112L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-6.864316428553637E-4d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "1e0d7446bb19689d181dab443c2ed39e4b11f0f02b5c99191396726accc3f8b68c7f78704c9f9e47ff6b920c2ef9f17e82c33914512b6119f56eab5be033c75cd7f03061a7ad4f8caa636ef3317ae72312dbc55288f9a361c85ebcd955ed06c111b63b9c1a4b4254ca6176b81d089c76e3dafb3c3ebe783de5d2c4e1c46703cf631bddad74264db610b0d1a44eceb0f311994232285dd1a13882988a3a4a9"+ "'", var12.equals("1e0d7446bb19689d181dab443c2ed39e4b11f0f02b5c99191396726accc3f8b68c7f78704c9f9e47ff6b920c2ef9f17e82c33914512b6119f56eab5be033c75cd7f03061a7ad4f8caa636ef3317ae72312dbc55288f9a361c85ebcd955ed06c111b63b9c1a4b4254ca6176b81d089c76e3dafb3c3ebe783de5d2c4e1c46703cf631bddad74264db610b0d1a44eceb0f311994232285dd1a13882988a3a4a9"));
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test150"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-9.999998f), 3615);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.NEGATIVE_INFINITY);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test151"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    int var4 = var2.ordinal();
    org.apache.commons.math3.exception.OutOfRangeException var8 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.05782461145270825d), (java.lang.Number)(-1L), (java.lang.Number)100.0d);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var14 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)2.5f, (java.lang.Number)0.7172507104665835d, false);
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    org.apache.commons.math3.exception.util.Localizable var17 = null;
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    org.apache.commons.math3.exception.util.Localizable var19 = null;
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.MathIllegalStateException var24 = new org.apache.commons.math3.exception.MathIllegalStateException(var21, var23);
    org.apache.commons.math3.exception.MathIllegalArgumentException var25 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var20, var23);
    org.apache.commons.math3.exception.MathIllegalStateException var26 = new org.apache.commons.math3.exception.MathIllegalStateException(var19, var23);
    org.apache.commons.math3.exception.MathInternalError var27 = new org.apache.commons.math3.exception.MathInternalError(var18, var23);
    org.apache.commons.math3.exception.NullArgumentException var28 = new org.apache.commons.math3.exception.NullArgumentException(var17, var23);
    org.apache.commons.math3.exception.MathIllegalArgumentException var29 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var16, var23);
    org.apache.commons.math3.exception.MathIllegalStateException var30 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var14, var15, var23);
    org.apache.commons.math3.exception.MathIllegalStateException var31 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var10, var23);
    boolean var32 = var2.equals((java.lang.Object)var8);
    int var33 = var2.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test152"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGaussian((-0.8887857291489829d), 1.6260590822656884E-6d);
//     var1.reSeed();
//     int var13 = var1.nextZipf(341, 0.999970864575518d);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 99.90560070606718d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.8887869808354788d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 26);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test153"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(141, 97895992);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 97896133);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test154"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(71.82159921357297d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 72.0d);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test155"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(506);
    float var2 = var1.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test156"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(9.857440630569243d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.857440630569243d);

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test157"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(0.999987895021552d, 15.322095332102348d, false);
//     double var8 = var1.nextGamma(1.4713540043352986d, 4.787491742782046d);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var9.getMean();
//     double var13 = var9.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var14 = var9.getNumericalVariance();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var18 = var1.nextPascal(506, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5.718314512635586d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9634138160098701d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-2.0684960258641785d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2147483647);
// 
//   }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test158"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-0.6140289167040056d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test159"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     var1.reSeed((-2502316609L));
//     double var11 = var1.nextGaussian(1.7427271998994087d, 0.8266429039966963d);
//     java.lang.String var13 = var1.nextHexString(208);
//     org.apache.commons.math3.distribution.IntegerDistribution var14 = null;
//     int var15 = var1.nextInversionDeviate(var14);
// 
//   }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test160"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     java.lang.String var5 = var1.nextSecureHexString(371);
//     long var8 = var1.nextSecureLong(0L, 8179512108L);
//     long var11 = var1.nextSecureLong(3520920158L, 4448708814L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("02935e64d8e8dbe57220482402ad1f9b8870dec665010320667d79136f109b2849d6d2b3b14e6f5732f437cd734cf4eb9386cdd1239c60a08317713070b6a615e0bc943b71cea100d53190573967344b66cf576ed68c760382e14c0f9b4d48171c48b5e71be6cdbc840977124e6af02514de5e72772f34c9aafda2940108c8cd517ec08cfe59adb6f875acbd0673075e03cc587159cbc18861ee8c3629040c7c53934f7a58d894caf60b18c7f51fd033b977ac56a9fa5be1107", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "8422ee0f7d5c59871bbf582ed017dc59549b6c198e120818884f7f3f470348a08c45a004c728de8c6d314d8f06221f7514c2485a560b52a2b03205b61381e817f233a0b0ba5a889f99d00b755de6d5b16dc8ca62eb93dc7bad7def5a760e4ec5a07d424f2e2ca99d61271831ee8ae9322e732f595742ff82f754b2b6fbe4ce11877c7db67a778b6f17763957c340b55c5f2e5c4ff74e47a6e843b3d86431af556b2602352255631f67d4b05f20b92a35cdf2a018a6eaedfdf5f"+ "'", var5.equals("8422ee0f7d5c59871bbf582ed017dc59549b6c198e120818884f7f3f470348a08c45a004c728de8c6d314d8f06221f7514c2485a560b52a2b03205b61381e817f233a0b0ba5a889f99d00b755de6d5b16dc8ca62eb93dc7bad7def5a760e4ec5a07d424f2e2ca99d61271831ee8ae9322e732f595742ff82f754b2b6fbe4ce11877c7db67a778b6f17763957c340b55c5f2e5c4ff74e47a6e843b3d86431af556b2602352255631f67d4b05f20b92a35cdf2a018a6eaedfdf5f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3299433949L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4241588214L);
// 
//   }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test161"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-1023), 0);
//     double var7 = var1.nextGaussian((-0.20637078079078508d), 0.3989422804014327d);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-838));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.2425407191315194d);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test162"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(4731);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test163"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 9617852649L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 9617852649L);
    java.math.BigInteger var10 = null;
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 9617852649L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, var12);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 2147483647);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 6949188755L);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var17);
    java.math.BigInteger var21 = null;
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 0L);
    java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, 9617852649L);
    java.math.BigInteger var27 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, 16938263);
    java.math.BigInteger var28 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, var27);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var30 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, (-350461404));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test164"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(4.190850860146929d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8670538920341193d));

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test165"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(3.425809903423076d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test166"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)4731);

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test167"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     int var8 = var1.nextPascal(2147483647, 0.0d);
//     double var11 = var1.nextUniform(0.3083894584059538d, 4.484958451919815d);
//     double var14 = var1.nextGaussian(0.9994127159589543d, 127.5443652792203d);
//     double var17 = var1.nextF(0.0245092848874585d, 7.2359525151849855d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 101.05896446651792d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.4206122923335283d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-252.8016009893512d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test168"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.5186207998179818d, 0.9503955299889218d, 0.07046473534579971d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var3.inverseCumulativeProbability(572.9577951308354d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test169"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var2 = var1.getNumElements();
    double[] var3 = var1.getInternalValues();
    double[] var6 = new double[] { 10.0d, 100.0d};
    double var7 = var0.mannWhitneyU(var3, var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var9 = var8.getExpansionMode();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var10 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var13 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var16 = var15.getNumElements();
    double[] var17 = var15.getInternalValues();
    double[] var20 = new double[] { 10.0d, 100.0d};
    double var21 = var14.mannWhitneyU(var17, var20);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    double var23 = var10.mannWhitneyU(var13, var17);
    var8.addElements(var13);
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    int var26 = var8.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test170"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-0.8687360941442427d), 1.834942319862084E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test171"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var13 = var1.nextUniform(0.9999943487368532d, 44.5140274520795d);
//     double var15 = var1.nextChiSquare(51.55677237552102d);
//     double var18 = var1.nextGaussian(100.0d, 0.8939360120238292d);
//     org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var21 = var19.density(100.0d);
//     double var24 = var19.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double var25 = var19.getMean();
//     double var26 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var19);
//     double var28 = var19.cumulativeProbability(0.9999999978823586d);
//     var19.reseedRandomGenerator(4448708814L);
//     double[] var32 = var19.sample(22861);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7851412602L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 6.595835377633299d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 36.00640254384757d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 99.22929143071944d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.8681630993635657d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.8413447455561358d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test172"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-6585150930L), 358702506L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6L);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test173"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var1 = null;
    java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 9617852649L);
    java.math.BigInteger var6 = null;
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 9617852649L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var8);
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 2147483647);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 6949188755L);
    java.lang.Number var16 = null;
    org.apache.commons.math3.exception.OutOfRangeException var18 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)var15, var16, (java.lang.Number)9.332621544395286E157d);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 0L);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, 210);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test174"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    var0.reseedRandomGenerator(10L);
    double var4 = var0.density(1832.5694791909018d);
    double var6 = var0.density(0.0d);
    double var7 = var0.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3989422804014327d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test175"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    double[] var2 = var1.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    float var4 = var3.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var3.getElement(4731);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.5f);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test176"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     var1.reSeed();
//     double var10 = var1.nextBeta(31.984371183438952d, 3.141592653589793d);
//     double var13 = var1.nextCauchy(0.9400207386800911d, 1.978735975787224d);
//     int var16 = var1.nextInt((-15), 3);
//     long var18 = var1.nextPoisson(32.53142185860535d);
//     int var21 = var1.nextSecureInt(211, 268848753);
//     int var24 = var1.nextBinomial(396, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9004049657109932d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.3046257457794024d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-9));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 31L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 219669446);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test177"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var5 = var0.getMean();
    double var7 = var0.probability(22.875984232951474d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test178"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)63.57484771045672d);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test179"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(9.140183681189434d, 0.6381781975339198d, 0.24497605252155716d);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test180"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-1.3672085181017381E-11d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.367208518101738E-11d));

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test181"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    int var9 = var8.ordinal();
    int var10 = var8.ordinal();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var14.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var19 = var17.addElementRolling(Double.NaN);
    double[] var20 = var17.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var21);
    double[] var23 = var14.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(var23);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var27 = var26.getNumElements();
    double[] var28 = var26.getInternalValues();
    double[] var31 = new double[] { 10.0d, 100.0d};
    double var32 = var25.mannWhitneyU(var28, var31);
    var24.addElements(var31);
    boolean var34 = var13.equals((java.lang.Object)var24);
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var13);
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5, var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test182"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 9617852649L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 9617852649L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var7);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 2147483647);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 7080423162L);
    java.math.BigInteger var15 = null;
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 0L);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 907096051);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test183"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 9617852649L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 9617852649L);
    java.math.BigInteger var10 = null;
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 9617852649L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, var12);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 2147483647);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 268848753);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var19);
    java.math.BigInteger var23 = null;
    java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, 0L);
    java.math.BigInteger var27 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, 9617852649L);
    java.math.BigInteger var28 = null;
    java.math.BigInteger var30 = org.apache.commons.math3.util.ArithmeticUtils.pow(var28, 0L);
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var30, 9617852649L);
    java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var27, var30);
    java.math.BigInteger var35 = org.apache.commons.math3.util.ArithmeticUtils.pow(var27, 2147483647);
    java.math.BigInteger var37 = org.apache.commons.math3.util.ArithmeticUtils.pow(var35, 268848753);
    org.apache.commons.math3.exception.OutOfRangeException var38 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.0d), (java.lang.Number)2325017522L, (java.lang.Number)var35);
    java.math.BigInteger var40 = org.apache.commons.math3.util.ArithmeticUtils.pow(var35, 1037420971);
    java.math.BigInteger var42 = org.apache.commons.math3.util.ArithmeticUtils.pow(var40, 2654386936L);
    java.math.BigInteger var44 = org.apache.commons.math3.util.ArithmeticUtils.pow(var42, 0);
    java.math.BigInteger var45 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test184"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(4.723833639310527d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test185"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-394), 6398462632L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test186"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.374727287185447d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test187"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(213036.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 213036.0d);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test188"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var14.contract();
    int var16 = var14.getExpansionMode();
    int var17 = var14.start();
    double[] var18 = var14.getElements();
    double var20 = var14.addElementRolling(5.65362408791435d);
    var14.addElement((-0.9918946513810528d));
    int var23 = var14.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test189"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var11 = var10.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    int var15 = var12.getNumElements();
    double[] var16 = var12.getElements();
    var10.addElements(var16);
    var0.addElements(var16);
    float var19 = var0.getExpansionFactor();
    var0.clear();
    var0.discardMostRecentElements(0);
    int var23 = var0.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test190"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.01295210122135538d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000838796356302d);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test191"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.08948812915473234d), true);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-0.08948812915473234d)+ "'", var4.equals((-0.08948812915473234d)));

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test192"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.9681499929411322d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

}
