
import junit.framework.*;

public class RandoopTest3 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test1"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var5 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var7 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.random.RandomGenerator var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var9);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    int var12 = var2.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "MAXIMAL"+ "'", var5.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test2"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, (java.lang.Number)664646591L, true);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test3"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.30353390504256844d, (java.lang.Number)10.17261244973466d, false);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test4"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    double[] var17 = new double[] { 10.0d, 100.0d};
    double var18 = var11.mannWhitneyU(var14, var17);
    var10.addElements(var17);
    var10.setContractionCriteria(2.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var24 = var22.addElementRolling(Double.NaN);
    double[] var25 = var22.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
    var10.addElements(var25);
    var10.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test5"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.20276274520392815d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.20139848231326574d);

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test6"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.7838899213734127d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test7"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-7500), (-74));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7574));

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test8"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    double var3 = var1.addElementRolling((-0.05782461145270825d));
    double var5 = var1.addElementRolling(5.129537890492898E-16d);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    int var9 = var8.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var11);
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
    boolean var15 = var13.equals((java.lang.Object)10.015471524400919d);
    boolean var16 = var1.equals((java.lang.Object)10.015471524400919d);
    double var18 = var1.addElementRolling(Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test9"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(447, 295);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test10"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getStandardDeviation();
    boolean var9 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator(1L);
    boolean var12 = var0.isSupportUpperBoundInclusive();
    boolean var13 = var0.isSupportLowerBoundInclusive();
    double var14 = var0.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test11"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var5);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var5);
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var9.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test12"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(3.40428888768425d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2850859610229688d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test13"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(9.758686158750079d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.9686693898115446d);

  }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test14"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(1832.5694791909018d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test15"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.7303807294278502d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5483414591105643d);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test16"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(0L, 4448708814L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-4448708814L));

  }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test17"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     java.lang.String var8 = var1.nextHexString(500);
//     double var10 = var1.nextT(0.9584128699015102d);
//     double var13 = var1.nextGamma(5.464265321962551d, 1.4861857760130848d);
//     double var15 = var1.nextChiSquare(614984.3812525364d);
//     java.util.Collection var16 = null;
//     java.lang.Object[] var18 = var1.nextSample(var16, 825);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test18"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.9097224269009427d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2856327575962656d);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test19"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(50, (-7500));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7550);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test20"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-0.8508150646900634d), 0.8939360120238292d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test21"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var4 = var1.nextChiSquare(5.464265321962551d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var1.nextExponential((-0.18860675851609787d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4.631292361054984d);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test22"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.9862581785814829d, 307.00270563058723d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9862581785814829d);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test23"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(5, 5210);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5215);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test24"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test25"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.9999999984381234d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999992190617d);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test26"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(50, 1704294704);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test27"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(2.742631232643827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9214649389142134d));

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test28"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     double var9 = var1.nextT(1.5855819012757701d);
//     double var12 = var1.nextCauchy((-1.8456016649756868d), 4.9E-324d);
//     double var15 = var1.nextGaussian((-0.014542775949576744d), 42.68079794095493d);
//     java.util.Collection var16 = null;
//     java.lang.Object[] var18 = var1.nextSample(var16, 50);
// 
//   }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test29"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.9144179195264008d, (java.lang.Number)2.786677745713106d, true);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test30"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p((-0.001073836545783379d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0010744135213355153d));

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test31"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.9999999033896889d, 1.5395412382954015d, (-0.8307376748471434d), 6);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test32"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    int var3 = var0.getNumElements();
    double[] var4 = var0.getElements();
    var0.setExpansionMode(0);
    var0.discardFrontElements(0);
    var0.contract();
    int var10 = var0.getNumElements();
    float var11 = var0.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = var0.copy();
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test33"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var3);
    var1.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var1.copy();
    var6.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test34"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    int var10 = var9.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var19.getNanStrategy();
    boolean var23 = var21.equals((java.lang.Object)2.9686693898115446d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test35"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getMean();
//     double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     boolean var5 = var0.isSupportConnected();
//     double var6 = var0.getNumericalVariance();
//     double var7 = var0.sample();
//     double var8 = var0.getStandardDeviation();
//     double var9 = var0.getSupportUpperBound();
//     var0.reseedRandomGenerator(7612302794L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.1043085576747377d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test36"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(44.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.477465921704087d);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test37"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.6260590822656884E-6d, 0.944965986224098d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.7207593775533681E-6d);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test38"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.7100683659172744d, (java.lang.Number)Float.POSITIVE_INFINITY, (java.lang.Number)(byte)0);
    java.lang.Number var4 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)0+ "'", var4.equals((byte)0));

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test39"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(0, 268848753);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test40"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-0.3981578665457376d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test41"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-1023), 731);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test42"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.9073486E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test43"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.4980370657191222d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.30273833427190305d));

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test44"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(4.6E-44f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.6E-44f);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test45"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(3123671065L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test46"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var5 = var0.getNumericalVariance();
    var0.reseedRandomGenerator(100L);
    double var8 = var0.sample();
    double var10 = var0.probability(1.8525291623715519d);
    double var11 = var0.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.4705756905309871d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == Double.POSITIVE_INFINITY);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test47"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.nextUniform(0.0d, (-0.8061852905228415d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test48"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGaussian((-0.8887857291489829d), 1.6260590822656884E-6d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var12 = var1.nextPermutation(0, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 100.47883936947153d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.8887847316815017d));
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test49"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.8998354296541002d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2597323980082211d);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test50"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getStandardDeviation();
    boolean var9 = var0.isSupportUpperBoundInclusive();
    double var10 = var0.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test51"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.9997643044330278d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test52"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(664646591L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 664646591L);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test53"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    var0.setNumElements(0);
    var0.contract();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var6 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var10 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    double[] var17 = new double[] { 10.0d, 100.0d};
    double var18 = var11.mannWhitneyU(var14, var17);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    double var20 = var7.mannWhitneyU(var10, var14);
    double[] var24 = new double[] { 100.0d, 1.0d, 100.0d};
    double var25 = var6.mannWhitneyU(var10, var24);
    var0.addElements(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var28);
    var0.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var31 = var0.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test54"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var17 = var16.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    int var21 = var18.getNumElements();
    double[] var22 = var18.getElements();
    var16.addElements(var22);
    float var24 = var16.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var16);
    double var27 = var16.addElementRolling(3.4965075614664802d);
    org.apache.commons.math3.util.ResizableDoubleArray var28 = var16.copy();
    int var29 = var28.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 2);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test55"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2.151512277359165d, (java.lang.Number)124952017, false);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test56"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(1.5395412382954015d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9319834498732898d);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test57"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test58"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(102300, 506);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 101794);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test59"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getStandardDeviation();
    double var9 = var0.getSupportLowerBound();
    double var10 = var0.getMean();
    double var12 = var0.inverseCumulativeProbability(0.0d);
    boolean var13 = var0.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test60"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.0000001f, 5.381455886543763d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000002f);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test61"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.9117361753569404d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2L);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test62"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.9939513433989471d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test63"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.26765045E30f, (-3.4028235E38f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.26765045E30f);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test64"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(53, (-2147483648));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test65"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(5.205744238502723d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.881784197001252E-16d);

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test66"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var4 = var1.nextChiSquare(5.464265321962551d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var7 = var1.nextLong(2894332602L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.8357856642915102d);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test67"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc((-0.11095680770623403d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1246894405507097d);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test68"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    float var4 = var0.getContractionCriteria();
    float var5 = var0.getContractionCriteria();
    int var6 = var0.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test69"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.9073486E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9073489E-6f);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test70"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(32.53142185860535d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5123030455090722d);

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test71"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.lang.Object[] var3 = new java.lang.Object[] { 'a'};
//     org.apache.commons.math3.exception.MathIllegalStateException var4 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var3);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var3);
//     org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException();
//     var5.addSuppressed((java.lang.Throwable)var6);
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     java.lang.Number var10 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var12 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var8, (java.lang.Number)100L, var10, true);
//     var6.addSuppressed((java.lang.Throwable)var12);
//     org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var12);
// 
//   }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test72"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-65), 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test73"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(1.0000004f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1920929E-7f);

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test74"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma(0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test75"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 1.0464211895232356d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var4 = var2.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test76"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.9148925374148474d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9565001502429822d);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test77"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.0d, 0.23074612792124255d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.23074612792124255d);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test78"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    int var10 = var9.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var21 = var20.start();
    double var23 = var20.addElementRolling(4.937302184657956d);
    int var24 = var20.start();
    var20.contract();
    double[] var26 = var20.getInternalValues();
    var20.setExpansionMode(0);
    double[] var29 = var20.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var30 = var19.rank(var29);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test79"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(10, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test80"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-7574), 506);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test81"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(53, 396);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 20988);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test82"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3520920158L, (-1271720519));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test83"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.9999999033896889d);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test84"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     var1.reSeed((-2502316609L));
//     double var11 = var1.nextGamma((-0.05788914687716099d), (-0.9918946513810528d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextUniform(1.3209627005516584d, 0.5d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6475105959L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-4.013115666462255d));
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test85"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.8939360120238292d, (java.lang.Number)0.9984187364052811d, (java.lang.Number)58.54535109520317d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test86"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var13 = var11.addElementRolling(Double.NaN);
    double[] var14 = var11.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var8, var15);
    double[] var17 = var8.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var18 = var7.rank(var17);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test87"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-127));

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test88"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     java.lang.String var8 = var1.nextHexString(500);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var1.nextSecureLong(0L, (-4685954328653257593L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9663792246L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "8dfb9098c28756669b045f219fce707f2a2127ff1014b9aa505b5b02b0f07d3c80ac457a4b1558873976caf3a3effcb45dad85cac6b8708aae713dfa509890fe6ef0fe29715aac614c06cb42dbe06ccb6ec24fa10ca98bb31504bb324e93e6161cc0fd077363af8173c09173179d0c04f787898bb391adbfbecdd6c59fea8de93c6218804a8bd382a61895b1a02b563d7e069534973a8c6851dbfc5e1f7ac6bf2a12c8ca1b5371280635769ae54e51f32f01c432131744d5a33050ef13fd7adbd2e19c497c9e8155c7742754c78f58f3e1ca29b2bc93d1ee68cfee9aa8b48cdc0845f6492b0c886bc98ec1419d7c300e6915fc108f048b06fa08"+ "'", var8.equals("8dfb9098c28756669b045f219fce707f2a2127ff1014b9aa505b5b02b0f07d3c80ac457a4b1558873976caf3a3effcb45dad85cac6b8708aae713dfa509890fe6ef0fe29715aac614c06cb42dbe06ccb6ec24fa10ca98bb31504bb324e93e6161cc0fd077363af8173c09173179d0c04f787898bb391adbfbecdd6c59fea8de93c6218804a8bd382a61895b1a02b563d7e069534973a8c6851dbfc5e1f7ac6bf2a12c8ca1b5371280635769ae54e51f32f01c432131744d5a33050ef13fd7adbd2e19c497c9e8155c7742754c78f58f3e1ca29b2bc93d1ee68cfee9aa8b48cdc0845f6492b0c886bc98ec1419d7c300e6915fc108f048b06fa08"));
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test89"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var7 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var8 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var10 = var9.getNumElements();
    double[] var11 = var9.getInternalValues();
    double[] var14 = new double[] { 10.0d, 100.0d};
    double var15 = var8.mannWhitneyU(var11, var14);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    double var17 = var4.mannWhitneyU(var7, var11);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var20 = var19.getNumElements();
    double[] var21 = var19.getInternalValues();
    double[] var24 = new double[] { 10.0d, 100.0d};
    double var25 = var18.mannWhitneyU(var21, var24);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var26 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var28 = var27.getNumElements();
    double[] var29 = var27.getInternalValues();
    double[] var32 = new double[] { 10.0d, 100.0d};
    double var33 = var26.mannWhitneyU(var29, var32);
    double var34 = var4.mannWhitneyUTest(var21, var32);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var35 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var37 = var36.getNumElements();
    double[] var38 = var36.getInternalValues();
    double[] var41 = new double[] { 10.0d, 100.0d};
    double var42 = var35.mannWhitneyU(var38, var41);
    org.apache.commons.math3.util.ResizableDoubleArray var43 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var43.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var46 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var48 = var46.addElementRolling(Double.NaN);
    double[] var49 = var46.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var50 = new org.apache.commons.math3.util.ResizableDoubleArray(var49);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var43, var50);
    double[] var52 = var43.getElements();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var53 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var56 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var57 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var58 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var59 = var58.getNumElements();
    double[] var60 = var58.getInternalValues();
    double[] var63 = new double[] { 10.0d, 100.0d};
    double var64 = var57.mannWhitneyU(var60, var63);
    org.apache.commons.math3.util.ResizableDoubleArray var65 = new org.apache.commons.math3.util.ResizableDoubleArray(var60);
    double var66 = var53.mannWhitneyU(var56, var60);
    org.apache.commons.math3.util.ResizableDoubleArray var67 = new org.apache.commons.math3.util.ResizableDoubleArray(var56);
    org.apache.commons.math3.util.ResizableDoubleArray var68 = new org.apache.commons.math3.util.ResizableDoubleArray(var67);
    double var70 = var67.substituteMostRecentElement(0.3742437696541317d);
    org.apache.commons.math3.util.ResizableDoubleArray var71 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var71.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var74 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var76 = var74.addElementRolling(Double.NaN);
    double[] var77 = var74.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var78 = new org.apache.commons.math3.util.ResizableDoubleArray(var77);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var71, var78);
    double[] var80 = var71.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var81 = new org.apache.commons.math3.util.ResizableDoubleArray(var80);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var82 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var83 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var84 = var83.getNumElements();
    double[] var85 = var83.getInternalValues();
    double[] var88 = new double[] { 10.0d, 100.0d};
    double var89 = var82.mannWhitneyU(var85, var88);
    var81.addElements(var88);
    var67.addElements(var88);
    var43.addElements(var88);
    double var93 = var4.mannWhitneyU(var41, var88);
    double[] var94 = var1.rank(var88);
    org.apache.commons.math3.util.ResizableDoubleArray var95 = new org.apache.commons.math3.util.ResizableDoubleArray(var94);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var95.setNumElements((-15));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.024588566448858762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test90"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     var1.reSeed();
//     double var10 = var1.nextBeta(31.984371183438952d, 3.141592653589793d);
//     var1.reSeed();
//     var1.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextChiSquare((-2.450405938642638d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.8496487262394109d);
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test91"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-15));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test92"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     int var12 = var1.nextZipf(3, 0.949950589504148d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var14 = var1.nextHexString((-241));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 100.18858214976363d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.035284904200693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test93"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(1.0016685869732043d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test94"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    java.lang.Class var4 = var3.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    java.lang.String var7 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    int var11 = var10.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "AVERAGE"+ "'", var7.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 3);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test95"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.9999999992190617d, 99.69065826232949d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999992190617d);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test96"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(99.99999f, Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99.99999f);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test97"); }


    java.math.BigInteger var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, (-10681828717L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test98"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)9.868080801062987d, (java.lang.Number)(-10.567559072274053d), false);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test99"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(1833.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test100"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-2502316609L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2502316609L);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test101"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-0.9097224269009427d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4431345087069416d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test102"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var9 = var8.getNumElements();
    double[] var10 = var8.getInternalValues();
    int var11 = var8.getNumElements();
    double[] var12 = var8.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var13 = var7.rank(var12);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test103"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-0.9985753080512595d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.840700366736723d));

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test104"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(100.49999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test105"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.5559066774286513d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.7113669808553675d));

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test106"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.5707312477445605d, (-1.9999999999999998d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test107"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-0.840700366736723d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4314082735937969d);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test108"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(3570);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3570);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test109"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.022519701004396d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test110"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(10.0f, 445);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test111"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    int var8 = var7.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    java.lang.Class var13 = var12.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var14.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7, var15);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var15);
    double[] var18 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var19.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var24 = var22.addElementRolling(Double.NaN);
    double[] var25 = var22.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var19, var26);
    double[] var28 = var19.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var28);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var30 = var17.mannWhitneyUTest(var18, var28);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test112"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.26765045E30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.26765045E30f);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test113"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(11L, 2894332602L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2894332613L);

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test114"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 5769050335L);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test115"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test116"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.001736111111111111d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.00173611198324139d);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test117"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextPascal(100, 0.0d);
//     long var5 = var0.nextPoisson(0.07637989519631011d);
//     var0.reSeedSecure(9617852649L);
//     double var10 = var0.nextGamma(1.071112867107899d, (-0.010152952316618155d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextSecureInt(53, (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.0030997980011645077d));
// 
//   }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test118"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGaussian((-0.8887857291489829d), 1.6260590822656884E-6d);
//     var1.reSeed();
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var1.nextSample(var11, 1000);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test119"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(3, 20988);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test120"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(3.0337905691391223d, 1.7439636808636205E32d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.0337905691391223d);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test121"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    java.lang.Class var9 = var6.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var11 = java.lang.Enum.<java.lang.Enum>valueOf(var9, "ff5d21");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test122"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(118.41771345769118d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test123"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1.315149049454551d));
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: -1.315 is smaller than, or equal to, the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: -1.315 is smaller than, or equal to, the minimum (0)"));

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test124"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-9223372036854775808L));

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test125"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.024588566448858762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 31.899008269901618d);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test126"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(11L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11L);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test127"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(10.0d, 0.0d, 7.38420064243972d, 371);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test128"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(7.8492444081989055d, 0.8524481817025479d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.7915442060674405d);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test129"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(6, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 60);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test130"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(4.440892098500626E-16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.62939453125E-6d);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test131"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.5395412382954017d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.6624508263893025d);

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test132"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var13 = var1.nextUniform(0.9999943487368532d, 44.5140274520795d);
//     int var16 = var1.nextZipf(1000, 96.04035976807448d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 9935950308L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 6.061237093357864d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test133"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.6227605565158021d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test134"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var5 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var7 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "MAXIMAL"+ "'", var5.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test135"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextPascal(100, 0.0d);
//     long var5 = var0.nextPoisson(0.07637989519631011d);
//     java.util.Collection var6 = null;
//     java.lang.Object[] var8 = var0.nextSample(var6, 3);
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test136"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(251, (-347));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test137"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.05788914687716099d), (java.lang.Number)100.49999f, false);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test138"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter((-1.2676506E30f), 2.1891412261319916d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.2676505E30f));

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test139"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(396, 4.6E-44f, 7.5557864E22f, 317);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test140"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     java.lang.String var5 = var1.nextSecureHexString(371);
//     long var8 = var1.nextSecureLong(0L, 8179512108L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var1.nextLong(4L, (-9223372036854775808L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "3aba0e616043c217655339793f1a6385b3e224bdeb373a2ac969b69b31374320e395b2e1079b0ad9b52fc576d3636d641581a29df3c24a39ca1e4fd57dfbfbc8af5ff2b6d89d430dff6424798dbf51db597b837de3a12a9a4022e50346b5d2d69a217daf6b8690454f73fb38972936ce65f37c36b35aa88248926c4bb243593265577b0845d72696dac363fef09809e7de3e5714803b57727e00a9065188695e6830231ca388ca7592c2821b470b18cbced8e968074b343bae4"+ "'", var5.equals("3aba0e616043c217655339793f1a6385b3e224bdeb373a2ac969b69b31374320e395b2e1079b0ad9b52fc576d3636d641581a29df3c24a39ca1e4fd57dfbfbc8af5ff2b6d89d430dff6424798dbf51db597b837de3a12a9a4022e50346b5d2d69a217daf6b8690454f73fb38972936ce65f37c36b35aa88248926c4bb243593265577b0845d72696dac363fef09809e7de3e5714803b57727e00a9065188695e6830231ca388ca7592c2821b470b18cbced8e968074b343bae4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1691390086L);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test141"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed();
    double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
    var1.reSeedSecure();
    var1.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var1.nextPascal(66495, 6.352555865969627d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test142"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.start();
    double var3 = var0.addElementRolling(4.937302184657956d);
    int var4 = var0.start();
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var0.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setExpansionMode((-1023));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test143"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-0.7323676290027762d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.48076935803388726d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test144"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.26765045E30f, 99.99999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.26765045E30f);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test145"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.8939360120238291d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.945481894075095d);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test146"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)100.0d);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var1.getContext();
    java.lang.Number var4 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 100.0d+ "'", var4.equals(100.0d));

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test147"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(7550, 1000);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test148"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(2.3044102334851835d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test149"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(66495);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 66495);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test150"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.3742437696541317d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test151"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(2.4999998f, 0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.99999994f);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test152"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(4.9E-324d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test153"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    java.lang.Class var8 = var7.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    java.lang.String var14 = var10.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "AVERAGE"+ "'", var14.equals("AVERAGE"));

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test154"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, (-1.1662189259034943d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.4E-45f));

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test155"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextCauchy(0.8775199269609161d, 0.6387763808612118d);
//     org.apache.commons.math3.distribution.IntegerDistribution var5 = null;
//     int var6 = var1.nextInversionDeviate(var5);
// 
//   }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test156"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     var1.reSeed();
//     double var10 = var1.nextBeta(31.984371183438952d, 3.141592653589793d);
//     double var13 = var1.nextCauchy(0.9400207386800911d, 1.978735975787224d);
//     int var16 = var1.nextInt((-15), 3);
//     long var18 = var1.nextPoisson(32.53142185860535d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var1.nextPascal(1, 13.581326273360407d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9776368489236978d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.3742995271571852d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-5));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 27L);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test157"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.20139848231326574d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test158"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(3.6611311949500056d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test159"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(268848753);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 268848753);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test160"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(10.567764688902704d, 4.787491742782046d);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test161"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(16.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 16);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test162"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(31.98437118343895d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.655472675509886d);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test163"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     java.lang.String var5 = var1.nextSecureHexString(371);
//     long var8 = var1.nextSecureLong(0L, 8179512108L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var11 = var1.nextPermutation(396, 2147483647);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "f1bf62d2480643cd1b437e8d63ab6f7f52820482201d024a770ddfd7a2b48fe8fe39f0b0ddb5d4ace34a3ad2625f245cc5d7bceacf302044f9de975371cf69db420e02c1619cedff2b3fa99e7464c017760621d26942bbbee5c8a08c7eae74f33bc52a437a8647c2b6b59d60c5239bc00efc00b0b67a3c5c0acd79e96f50869490b6b588ceb964116270652d4616231d5cfc2ba1335c5ba171910006d5aea062bdf0f82560bf7c5b56dd43a9c5d7203c5fe1a51e9ee9816467a"+ "'", var5.equals("f1bf62d2480643cd1b437e8d63ab6f7f52820482201d024a770ddfd7a2b48fe8fe39f0b0ddb5d4ace34a3ad2625f245cc5d7bceacf302044f9de975371cf69db420e02c1619cedff2b3fa99e7464c017760621d26942bbbee5c8a08c7eae74f33bc52a437a8647c2b6b59d60c5239bc00efc00b0b67a3c5c0acd79e96f50869490b6b588ceb964116270652d4616231d5cfc2ba1335c5ba171910006d5aea062bdf0f82560bf7c5b56dd43a9c5d7203c5fe1a51e9ee9816467a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2961365019L);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test164"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-2L), 3520920158L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3520920158L);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test165"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var13 = var1.nextUniform(0.9999943487368532d, 44.5140274520795d);
//     double var16 = var1.nextGaussian((-0.8887853505857057d), 2.882619330995207E-19d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var1.nextF((-0.010152952316618155d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6132993134L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 34.340741532013446d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-0.8887853505857057d));
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test166"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)99.99999f, var2, false);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test167"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(3.4028235E38f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test168"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    int var2 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var4 = var3.getNumElements();
    double[] var5 = var3.getInternalValues();
    int var6 = var3.getNumElements();
    double[] var7 = var3.getElements();
    var0.addElements(var7);
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var12);
    var12.setNumElements(300);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setNumElements((-17));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test169"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin((-1.4167840343841642d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test170"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(2.0d, 98.48948855608185d, 0.723245967437971d, (-7574));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test171"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(7.950137129262093E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.950137129262085E-8d);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test172"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(9.140183681189434d, 0.4980370657191222d);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test173"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(731, (-65));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-47515));

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test174"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.001736111111111111d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test175"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(1.9073486E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.2737368E-13f);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test176"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(0, 6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test177"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextF((-0.8887886727757299d), 1.082063323071492d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 8.883031255934124d);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test178"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    var15.setNumElements(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setContractionCriteria(1.1920929E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test179"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(5215, (-74));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test180"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)3.474237346416215d, true);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test181"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getSupportLowerBound();
    double var10 = var0.density(0.004000934888783327d);
    double var13 = var0.cumulativeProbability((-1.0084760157976542d), (-0.9985753080512595d));
    double var14 = var0.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.3989390873839266d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0023872351676735293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == Double.POSITIVE_INFINITY);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test182"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(3628800L, 7237275917L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3628800L);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test183"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var8 = var1.nextWeibull(0.7853981633974483d, 4.787491742782046d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("", "6b2bf4");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.14138612717747823d);
// 
//   }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test184"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     int var12 = var1.nextZipf(3, 0.949950589504148d);
//     var1.reSeedSecure();
//     double var16 = var1.nextCauchy(0.0d, 0.5637033385775058d);
//     double var18 = var1.nextExponential(1.9117361753569404d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var21 = var1.nextLong(5769050335L, 2894332602L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 100.35225223809358d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.1212142764461612d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.14014824657551164d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.0129289498846075d);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test185"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)50, (java.lang.Number)5.451930926365849E-198d, false);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test186"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.11125059697946545d, (-4.399025741313411d), 0.999999950276072d, (-17));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test187"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-1023));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test188"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.0d, 7.62939453125E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test189"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp((-1.26765045E30f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.5557864E22f);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test190"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(3.549983059648433d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 34.812727742759826d);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test191"); }


    float var2 = org.apache.commons.math3.util.FastMath.max((-1.4E-45f), (-1.0000001f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.4E-45f));

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test192"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(20988, 89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test193"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-0.9296416727984185d), 66495);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test194"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.5458066324533807d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5458066324533806d));

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test195"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(393769108042894612L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test196"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getMean();
//     double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var7 = var0.cumulativeProbability(4.158638853279167d, 24.0d);
//     double var8 = var0.sample();
//     boolean var9 = var0.isSupportLowerBoundInclusive();
//     var0.reseedRandomGenerator(3617318266L);
//     var0.reseedRandomGenerator(3520920169L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.600747998428365E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.663061121795331d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test197"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)1.6286532113855836d, (java.lang.Number)(-57.29577951308232d));
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-57.29577951308232d)+ "'", var5.equals((-57.29577951308232d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-57.29577951308232d)+ "'", var6.equals((-57.29577951308232d)));

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test198"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test199"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var12 = var10.addElementRolling(Double.NaN);
    double[] var13 = var10.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    var0.addElements(var13);
    int var16 = var0.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setContractionCriteria(1.0000004f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test200"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(4.15912713462618d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2716303697967668d);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test201"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.07374182E9f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.07374182E9f);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test202"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.9567827717396936d, (-4.013115666462255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9567827717396935d);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test203"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    double var17 = var14.substituteMostRecentElement(0.3742437696541317d);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var18.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var23 = var21.addElementRolling(Double.NaN);
    double[] var24 = var21.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var18, var25);
    double[] var27 = var18.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(var27);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var31 = var30.getNumElements();
    double[] var32 = var30.getInternalValues();
    double[] var35 = new double[] { 10.0d, 100.0d};
    double var36 = var29.mannWhitneyU(var32, var35);
    var28.addElements(var35);
    var14.addElements(var35);
    float var39 = var14.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0f);

  }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test204"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     double var9 = var1.nextT(1.5855819012757701d);
//     double var12 = var1.nextCauchy((-1.8456016649756868d), 4.9E-324d);
//     double var15 = var1.nextGamma((-0.11018662689453802d), 0.7503963846834529d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var1.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 30.755374801738036d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.6801194675260922d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1.8456016649756868d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.168455256235215d);
// 
//   }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test205"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getMean();
//     double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     boolean var5 = var0.isSupportConnected();
//     double var6 = var0.getNumericalVariance();
//     double var7 = var0.sample();
//     double var8 = var0.getStandardDeviation();
//     double var9 = var0.getMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1.1294963825265836d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
// 
//   }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test206"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var1);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException(var3, (java.lang.Number)24.0d, (java.lang.Number)0.723245967437971d, (java.lang.Number)825);
//     var2.addSuppressed((java.lang.Throwable)var7);
//     org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test207"); }
// 
// 
//     org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(short)100);
//     java.lang.Number var2 = var1.getMax();
//     java.lang.Number var3 = var1.getMax();
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError();
//     java.lang.Throwable[] var8 = var7.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, (java.lang.Object[])var8);
//     org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
//     org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var4, (java.lang.Object[])var8);
//     java.lang.String var12 = var11.toString();
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test208"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma((-1.9200849871876335d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 159.50662885967768d);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test209"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1.2172413949552126d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.34623503969787806d);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test210"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.0d, 20988);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test211"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.3742437696541317d, 1833.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5966246732509366d);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test212"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.9998213620467383d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test213"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(5306065, 825);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 875500725);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test214"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(5.451930926365849E-198d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.515414525638859E-200d);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test215"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var16 = var15.getNumElements();
    double[] var17 = var15.getInternalValues();
    double[] var20 = new double[] { 10.0d, 100.0d};
    double var21 = var14.mannWhitneyU(var17, var20);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var24 = var23.getNumElements();
    double[] var25 = var23.getInternalValues();
    double[] var28 = new double[] { 10.0d, 100.0d};
    double var29 = var22.mannWhitneyU(var25, var28);
    double var30 = var0.mannWhitneyUTest(var17, var28);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var31 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var32 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var33 = var32.getNumElements();
    double[] var34 = var32.getInternalValues();
    double[] var37 = new double[] { 10.0d, 100.0d};
    double var38 = var31.mannWhitneyU(var34, var37);
    org.apache.commons.math3.util.ResizableDoubleArray var39 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var39.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var42 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var44 = var42.addElementRolling(Double.NaN);
    double[] var45 = var42.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var46 = new org.apache.commons.math3.util.ResizableDoubleArray(var45);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var39, var46);
    double[] var48 = var39.getElements();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var49 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var52 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var53 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var54 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var55 = var54.getNumElements();
    double[] var56 = var54.getInternalValues();
    double[] var59 = new double[] { 10.0d, 100.0d};
    double var60 = var53.mannWhitneyU(var56, var59);
    org.apache.commons.math3.util.ResizableDoubleArray var61 = new org.apache.commons.math3.util.ResizableDoubleArray(var56);
    double var62 = var49.mannWhitneyU(var52, var56);
    org.apache.commons.math3.util.ResizableDoubleArray var63 = new org.apache.commons.math3.util.ResizableDoubleArray(var52);
    org.apache.commons.math3.util.ResizableDoubleArray var64 = new org.apache.commons.math3.util.ResizableDoubleArray(var63);
    double var66 = var63.substituteMostRecentElement(0.3742437696541317d);
    org.apache.commons.math3.util.ResizableDoubleArray var67 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var67.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var70 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var72 = var70.addElementRolling(Double.NaN);
    double[] var73 = var70.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var74 = new org.apache.commons.math3.util.ResizableDoubleArray(var73);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var67, var74);
    double[] var76 = var67.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var77 = new org.apache.commons.math3.util.ResizableDoubleArray(var76);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var78 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var79 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var80 = var79.getNumElements();
    double[] var81 = var79.getInternalValues();
    double[] var84 = new double[] { 10.0d, 100.0d};
    double var85 = var78.mannWhitneyU(var81, var84);
    var77.addElements(var84);
    var63.addElements(var84);
    var39.addElements(var84);
    double var89 = var0.mannWhitneyU(var37, var84);
    org.apache.commons.math3.util.ResizableDoubleArray var90 = new org.apache.commons.math3.util.ResizableDoubleArray(var84);
    float var91 = var90.getContractionCriteria();
    var90.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.024588566448858762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == 2.5f);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test216"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.564065828779884d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5640658287798841d);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test217"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.9999646015047479d, 0.007825974595901458d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.00779688714965288d);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test218"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.9750822343314787d, 2.0d, (-2.0d));
    double var4 = var3.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4.0d);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test219"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.7834476479380598d, (java.lang.Number)2.5f, (java.lang.Number)(-1.0000001f));

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test220"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-0.7323676290027762d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test221"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-2L), (-9223372036854775808L));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test222"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(0.9117262695075353d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0576550898240642d);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test223"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-7), 4.5E-44f, 99.99999f, (-324291));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test224"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.9073489E-6f, 41.86392792621338d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.907349E-6f);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test225"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1.6286532113855836d), (java.lang.Number)(-0.9376760626269405d), false);
    org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(short)100);
    java.lang.Number var6 = var5.getMax();
    java.lang.Number var7 = var5.getMax();
    java.lang.Number var8 = var5.getMax();
    var3.addSuppressed((java.lang.Throwable)var5);
    java.lang.Number var10 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)100+ "'", var6.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)100+ "'", var7.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (short)100+ "'", var8.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (-0.9376760626269405d)+ "'", var10.equals((-0.9376760626269405d)));

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test226"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var5 = var0.getNumericalVariance();
    var0.reseedRandomGenerator(100L);
    double var8 = var0.sample();
    double var10 = var0.probability(1.8525291623715519d);
    double var11 = var0.sample();
    double var13 = var0.inverseCumulativeProbability(0.8939360120238292d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.4705756905309871d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.1991675114038487d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.247735391779353d);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test227"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(65, 128);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1208213503));

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test228"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.5607966601082315d);
//     java.lang.String var4 = var0.nextHexString(506);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextUniform(8.112963841460668E31d, (-0.9793091478686597d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.691942365337582d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "683969295a4c6bb02aa8029257b71a046b461ba8d1c2173b4bee47c810cf3b88cc537c6f9a4723f27bcb558e56a379d853c5ccde65ecc7eaa51df2c694f8b0016ede4ed9db9cbe0290d611d9b1db1053cf785a57c0cfc995d4d9806c7c17a732bbda1d119a0dd666ae1cee19d1763aadfd8d7a5424cdc450d184332c50b43ab649bccf9e87bcc84eb7cc5fff58d37233c94489dbb96c623dc5cd61a49d4332d02ba9f36957d7a5f458f6f56d858e705e9688a3668155a7f3d4c24dcaa663806a81c3de708d3640d1894c7dbc8c55ea29e92f226c2a3e8b11d2402547c3be4a891b5d04ce2fbaf04b7174f53b491c06991a96f292eed0fb0b2247164b4e"+ "'", var4.equals("683969295a4c6bb02aa8029257b71a046b461ba8d1c2173b4bee47c810cf3b88cc537c6f9a4723f27bcb558e56a379d853c5ccde65ecc7eaa51df2c694f8b0016ede4ed9db9cbe0290d611d9b1db1053cf785a57c0cfc995d4d9806c7c17a732bbda1d119a0dd666ae1cee19d1763aadfd8d7a5424cdc450d184332c50b43ab649bccf9e87bcc84eb7cc5fff58d37233c94489dbb96c623dc5cd61a49d4332d02ba9f36957d7a5f458f6f56d858e705e9688a3668155a7f3d4c24dcaa663806a81c3de708d3640d1894c7dbc8c55ea29e92f226c2a3e8b11d2402547c3be4a891b5d04ce2fbaf04b7174f53b491c06991a96f292eed0fb0b2247164b4e"));
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test229"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(3.4028235E38f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 127);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test230"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-2502316609L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2502316609L));

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test231"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(1.600747998428365E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6007479984283653E-5d);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test232"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(300, 4.5E-44f, (-1.26765045E30f), 825);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test233"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-9.32234431456384d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test234"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var5 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var7 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    java.lang.String var12 = var11.name();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var14.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var15);
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    org.apache.commons.math3.exception.NoDataException var19 = new org.apache.commons.math3.exception.NoDataException(var18);
    boolean var20 = var15.equals((java.lang.Object)var18);
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "MAXIMAL"+ "'", var5.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "MAXIMAL"+ "'", var12.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test235"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(2.2737368E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.2737368E-13f);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test236"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(1.6386034556842697d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.6386034556842697d);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test237"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.8524481817025479d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7059136439097909d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test238"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var5 = java.lang.Enum.<java.lang.Enum>valueOf(var3, "4bffd0a0022bc47a4d81261b9c970bff2fa315bf21ff1fc053bd6f5b61ea543c2c195653a0295f802ba711a290a052ffe5dbbd18040ec2cd9563f46f2ab4cb8cba00e625b5014bea2a9a5c63b69d0b3e3e1c373a708349bdd07e6de4860c15071c56e0b56b7a5bf2ce6525d81b3e5fcb721b8f2a4831dba1f3bc51f610d65d54e9f841a7b31c013194fe981a329afb9529a094e5886a3c8b0664be276df2abb6cae438f9e245addaa753394cf0db0cfa22abeabc603a21280a46cc15e7bc4e4cac1d79ab6ea8b1eb79416fd57fe4de243a3efaa6111ca1891103f5e9ea5bdd5f6ed648c92f7d4ae8998061a5cf4bf77aedb7b2b63b5ec4ad8276");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test239"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-241));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test240"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin((-0.05624376415137876d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.056273459664487095d));

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test241"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(127, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1605022207));

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test242"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var7 = var0.sample((-2147483648));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test243"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 32718048432L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 32718048432L);

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test244"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     java.lang.String var8 = var1.nextHexString(500);
//     double var10 = var1.nextT(0.9584128699015102d);
//     double var13 = var1.nextGamma(5.464265321962551d, 1.4861857760130848d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.nextUniform(0.5040503723628342d, (-0.056273459664487095d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1717252391L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "55fd14b1ab969da94dd35d37c3669ec23c9a15d47e9ed8ef4487cde52bdfc2fc069a98d9e3f8bb58ab26311293c1c4e519cd3b6dbcb5b43d9e93c53292ec55cc91e2d1ebbd337e784f185a8df13c5c7ace8677b41beddd459f2c571915e36d7c9bf21db15ab65a83b410992345d436cafca6df47360d83e29cd50fd3a6cbbf3bb416fedc0064fcf8228ca99e42935bdec350607481f04db6067008d5a6ae3aa78670c53dc8e766deaa801b8b241e26f1df91e5ee2e6a9af5e74b28f567cfd9bbe59fd871f79d0da90f66c48e8ae92d578741a7fdaa4d94aaf0e3543b3c3943ea7bfd4ddb94352fe239e630b9a4f91bac0cf056994159bc4fb095"+ "'", var8.equals("55fd14b1ab969da94dd35d37c3669ec23c9a15d47e9ed8ef4487cde52bdfc2fc069a98d9e3f8bb58ab26311293c1c4e519cd3b6dbcb5b43d9e93c53292ec55cc91e2d1ebbd337e784f185a8df13c5c7ace8677b41beddd459f2c571915e36d7c9bf21db15ab65a83b410992345d436cafca6df47360d83e29cd50fd3a6cbbf3bb416fedc0064fcf8228ca99e42935bdec350607481f04db6067008d5a6ae3aa78670c53dc8e766deaa801b8b241e26f1df91e5ee2e6a9af5e74b28f567cfd9bbe59fd871f79d0da90f66c48e8ae92d578741a7fdaa4d94aaf0e3543b3c3943ea7bfd4ddb94352fe239e630b9a4f91bac0cf056994159bc4fb095"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-3.6429753653106807d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 15.414430844768004d);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test245"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9999999f));

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test246"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.5040503723628342d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test247"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin((-0.9793091478686597d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.3670189956165777d));

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test248"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var2 = var1.getNumElements();
    double[] var3 = var1.getInternalValues();
    double[] var6 = new double[] { 10.0d, 100.0d};
    double var7 = var0.mannWhitneyU(var3, var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var9 = var8.getNumElements();
    float var10 = var8.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.5f);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test249"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-0.05788914687716099d), (-0.9422952790472405d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test250"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(4797469069L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test251"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getMean();
//     double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var5 = var0.getSupportUpperBound();
//     double var7 = var0.density(29.9749466411613d);
//     double var8 = var0.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3.123726322776123E-196d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.6464859599850347d);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test252"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1.3113177943322367d));

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test253"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     long var10 = var1.nextLong(0L, 10000000000L);
//     double var12 = var1.nextT(0.0010774392745906561d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextUniform(0.039720900659592454d, 0.004409706426562607d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 55.94589749632354d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 9579878417L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.9203107715728655E78d);
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test254"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.7303807294278502d, (-1.4700664288029952d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7303807294278502d);

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test255"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var4 = var1.nextChiSquare(5.464265321962551d);
//     double var8 = var1.nextUniform((-0.8307376748471434d), 0.006537325533411519d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextPascal(208, (-0.573312907976816d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.8669266320111593d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.66121849482224d));
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test256"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(614200.9371983381d, 22.875984232951474d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 614200.9371983381d);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test257"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    var0.clear();
    var0.setExpansionFactor(2.4999998f);
    var0.clear();
    var0.addElement(0.4980370657191222d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionFactor(4.5E-44f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test258"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed();
    var1.reSeed(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var1.nextChiSquare((-0.5961722400471147d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test259"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(3.049440752525946d, 0.0d, 0.25265756713375326d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test260"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(394, 0.0f, 16.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test261"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    double[] var3 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var6);
    boolean var8 = var2.equals((java.lang.Object)var6);
    org.apache.commons.math3.random.RandomGenerator var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var9);
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test262"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    int var3 = var0.getNumElements();
    double[] var4 = var0.getElements();
    var0.setExpansionMode(0);
    var0.addElement(0.0d);
    int var9 = var0.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test263"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var4 = var1.nextChiSquare(0.9999709354265791d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var1.nextBeta(Double.NEGATIVE_INFINITY, 2.9690791410915276d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.8920842765113313d);
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test264"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-17), (-7));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test265"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var2 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)4.158638853279167d, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test266"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(0, 330);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test267"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var3 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)4.158638853279167d, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathArithmeticException var5 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test268"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    var15.setNumElements(100);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var23 = var21.addElementRolling(Double.NaN);
    double[] var24 = var21.getElements();
    double[] var25 = var21.getInternalValues();
    var20.addElements(var25);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = var20.copy();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var15, var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test269"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(15.075693342371304d, 7.38420064243972d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.019216825697579E8d);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test270"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.9E-324d);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test271"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-0.0827727942692622d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3877787807814457E-17d);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test272"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.5961722400471147d), (-6.545752664888063d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.5961722400471148d));

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test273"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var7 = var1.nextExponential(209.99999999999997d);
//     var1.reSeedSecure();
//     var1.reSeed(4448708814L);
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var1.nextSample(var11, (-7574));
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test274"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var5 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var7 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    int var12 = var11.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    java.lang.Class var16 = var15.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var17.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = var21.getNanStrategy();
    int var23 = var22.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
    org.apache.commons.math3.stat.ranking.TiesStrategy var25 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25);
    org.apache.commons.math3.stat.ranking.NaNStrategy var27 = var26.getNanStrategy();
    java.lang.Class var28 = var27.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var27);
    org.apache.commons.math3.stat.ranking.TiesStrategy var30 = var29.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22, var30);
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19, var30);
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var30);
    org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var30);
    org.apache.commons.math3.stat.ranking.TiesStrategy var35 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var35);
    org.apache.commons.math3.stat.ranking.NaNStrategy var37 = var36.getNanStrategy();
    int var38 = var37.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var39 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var39);
    org.apache.commons.math3.stat.ranking.NaNStrategy var41 = var40.getNanStrategy();
    java.lang.Class var42 = var41.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var43 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var41);
    org.apache.commons.math3.stat.ranking.TiesStrategy var44 = var43.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var45 = var43.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var46 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var47 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var46);
    org.apache.commons.math3.stat.ranking.NaNStrategy var48 = var47.getNanStrategy();
    int var49 = var48.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var50 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var48);
    org.apache.commons.math3.stat.ranking.TiesStrategy var51 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var52 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var51);
    org.apache.commons.math3.stat.ranking.NaNStrategy var53 = var52.getNanStrategy();
    java.lang.Class var54 = var53.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var55 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var53);
    org.apache.commons.math3.stat.ranking.TiesStrategy var56 = var55.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var57 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var48, var56);
    org.apache.commons.math3.stat.ranking.NaturalRanking var58 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var45, var56);
    org.apache.commons.math3.stat.ranking.NaturalRanking var59 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var37, var56);
    java.lang.String var60 = var56.name();
    java.lang.String var61 = var56.name();
    boolean var62 = var30.equals((java.lang.Object)var56);
    boolean var64 = var56.equals((java.lang.Object)(-1.9999999999999998d));
    org.apache.commons.math3.stat.ranking.NaturalRanking var65 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "MAXIMAL"+ "'", var5.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var60 + "' != '" + "AVERAGE"+ "'", var60.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var61 + "' != '" + "AVERAGE"+ "'", var61.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test275"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(1.1161600721843477d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8984208211407446d);

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test276"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var2 = var0.density(100.0d);
//     double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double[] var7 = var0.sample(100);
//     double var8 = var0.getStandardDeviation();
//     double var9 = var0.sample();
//     boolean var10 = var0.isSupportUpperBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.2325948280689585d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test277"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var2 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test278"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    int var3 = var0.getNumElements();
    int var4 = var0.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var0.substituteMostRecentElement((-0.840700366736723d));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test279"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0d, 0.9862581785814829d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test280"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed();
    double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var8 = var1.nextLong(5769050335L, (-9617852649L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test281"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-0.9445775465806109d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test282"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.0d, 0.06517543676798719d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test283"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-0.5688753813335342d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5788982422751958d));

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test284"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.46232935299896244d, 0.7853981633974483d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.24653118885037728d);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test285"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(1.7207593775533681E-6d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.9416690332135457E-6d));

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test286"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(30.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.4339872044851463d);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test287"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var7 = var0.cumulativeProbability(4.158638853279167d, 24.0d);
    boolean var8 = var0.isSupportLowerBoundInclusive();
    double var9 = var0.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.600747998428365E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test288"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(5.6843418860808015E-14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999999999358d);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test289"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(63.98437118343895d, 0.3989422804014327d, 100.89867901620401d, 825);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.6447000666908032E-115d);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test290"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-1.119001993201958d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test291"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-0.0010738361330276734d), var2, true);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test292"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.5483414591105643d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.7429441502075451d));

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test293"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-1.9999999999999998d), 34.812727742759826d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.9999999999999998d));

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test294"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(1L, 4448708814L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4448708814L);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test295"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(2.2737368E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test296"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.0d, 91.16099711112008d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 91.16099711112008d);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test297"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(371, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test298"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.start();
    double var3 = var0.addElementRolling(4.937302184657956d);
    var0.discardMostRecentElements(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test299"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(9.0071993E15f, 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.0071987E15f);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test300"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var17 = var16.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    int var21 = var18.getNumElements();
    double[] var22 = var18.getElements();
    var16.addElements(var22);
    float var24 = var16.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var16);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    double[] var27 = var26.getElements();
    var26.addElement(100.0d);
    double var31 = var26.addElementRolling((-1.3407807929942293E154d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test301"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.9073489E-6f, (-0.0451269669384983d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9073486E-6f);

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test302"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-0.11018662689453802d), 0.0d, 0.0d, 445);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test303"); }


    float var2 = org.apache.commons.math3.util.FastMath.min((-1.0000001f), 2.2737368E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0000001f));

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test304"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(6438299617L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6438299617L);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test305"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test306"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 9617852649L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 9617852649L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var7);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 2147483647);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 6949188755L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, (-2502316609L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test307"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    int var3 = var0.getNumElements();
    double[] var4 = var0.getElements();
    var0.setExpansionMode(0);
    var0.discardFrontElements(0);
    var0.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setNumElements((-17));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test308"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(1.4690188987035586d, 5.129537890492898E-16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-91.54140768425792d));

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test309"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, (-57.29577951308232d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0d));

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test310"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.8097038004607792d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.2110867766358012d));

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test311"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-0.573312907976816d), (-0.28145195033435416d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.010409007308107676d));

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test312"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     java.lang.Object[] var7 = new java.lang.Object[] { 'a'};
//     org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var7);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, var7);
//     org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var7);
//     org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var2, var7);
//     org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var1, var7);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var7);
//     org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var13);
// 
//   }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test313"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    int var10 = var9.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    java.lang.Class var21 = var20.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var23 = java.lang.Enum.<java.lang.Enum>valueOf(var21, "4dfc9f810ce37863c27dbfd635ef72d2d9e0ce7e7ed13cfd01ee363964f411d93295fe8b7af2bcb9480a2fdf66038943c8c6600d4d4cefd0657807c7595f5e6795d4dfc00ffe85d770ec3764611ec04cdb3be1524007042dce14baf0f690573d2b906440c75b8acd59a2e63695023a3d4a588272eaac16e2f75e98c81d344ef905485b98931e638810ee996c5ac18df3398db");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test314"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(1.071112867107899d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.018694446191509312d);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test315"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var4);
    org.apache.commons.math3.random.RandomGenerator var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    java.lang.Class var9 = var8.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test316"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     java.lang.Object[] var5 = new java.lang.Object[] { 'a'};
//     org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var5);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var5);
//     org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var5);
//     org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var5);
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     org.apache.commons.math3.exception.util.Localizable var12 = null;
//     java.lang.Throwable var13 = null;
//     org.apache.commons.math3.exception.util.Localizable var14 = null;
//     org.apache.commons.math3.exception.util.Localizable var15 = null;
//     java.lang.Object[] var17 = new java.lang.Object[] { 'a'};
//     org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException(var15, var17);
//     org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException(var13, var14, var17);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var20 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var12, var17);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var21 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var11, var17);
//     org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var9, var10, var17);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test317"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-0.8887853505857057d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.2315379869782779d));

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test318"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getMean();
//     double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var7 = var0.cumulativeProbability(4.158638853279167d, 24.0d);
//     double var8 = var0.sample();
//     var0.reseedRandomGenerator(3628800L);
//     double var11 = var0.getSupportUpperBound();
//     double var12 = var0.getNumericalMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.600747998428365E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.7053653741701068d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test319"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    int var9 = var8.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    java.lang.Class var13 = var12.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var14.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = var14.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var18.getNanStrategy();
    int var20 = var19.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19);
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = var23.getNanStrategy();
    java.lang.Class var25 = var24.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24);
    org.apache.commons.math3.stat.ranking.TiesStrategy var27 = var26.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19, var27);
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16, var27);
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var27);
    java.lang.String var31 = var27.name();
    java.lang.String var32 = var27.name();
    int var33 = var27.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var27);
    java.lang.String var35 = var27.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var36 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var3, var27);
    java.lang.String var37 = var27.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "AVERAGE"+ "'", var31.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "AVERAGE"+ "'", var32.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "AVERAGE"+ "'", var35.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "AVERAGE"+ "'", var37.equals("AVERAGE"));

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test320"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.8525291623715519d, 211);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.09669035850565E63d);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test321"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    double var17 = var14.substituteMostRecentElement(0.3742437696541317d);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var18.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var23 = var21.addElementRolling(Double.NaN);
    double[] var24 = var21.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var18, var25);
    double[] var27 = var18.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(var27);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var31 = var30.getNumElements();
    double[] var32 = var30.getInternalValues();
    double[] var35 = new double[] { 10.0d, 100.0d};
    double var36 = var29.mannWhitneyU(var32, var35);
    var28.addElements(var35);
    var14.addElements(var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.discardFrontElements(268848753);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 32.0d);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test322"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(1.3648793247295046d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.085331022772145d);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test323"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.876407757475359d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4022547067333215d);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test324"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.14049621499892223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-7.4848193000431875d));

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test325"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(7550, 500);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1836.4208442309248d);

  }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test326"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var8 = var1.nextWeibull(0.7853981633974483d, 4.787491742782046d);
//     double var10 = var1.nextExponential(0.3971622936791505d);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var11.getNumericalMean();
//     double var13 = var11.getStandardDeviation();
//     boolean var14 = var11.isSupportLowerBoundInclusive();
//     double var15 = var11.getSupportLowerBound();
//     double var16 = var11.getSupportLowerBound();
//     double var17 = var11.getMean();
//     boolean var18 = var11.isSupportConnected();
//     double var19 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     double var20 = var11.getNumericalVariance();
//     double var21 = var11.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8712503618849591d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.6219701720597971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-0.18548895660008563d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.0d);
// 
//   }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test327"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(0.999987895021552d, 15.322095332102348d, false);
//     double var8 = var1.nextGamma(1.4713540043352986d, 4.787491742782046d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextPascal(825, (-0.11095680770623403d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 8.228112691469716d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 14.730316866262918d);
// 
//   }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test328"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma((-0.2110867766358012d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 24.79239851287064d);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test329"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(1.2856327575962656d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8266429039966963d);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test330"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-3.06588826647091E-5d), 1.4329174706418153d, 1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var3.inverseCumulativeProbability(5.732333270692692E248d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test331"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.4705756905309871d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4547403147443668d);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test332"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.9567827717396935d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1095904140014483d);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test333"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    int var8 = var7.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    java.lang.Class var13 = var12.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var14.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7, var15);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var15);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var20 = var18.addElementRolling(Double.NaN);
    double[] var21 = var18.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var21);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var26 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var27 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var29 = var28.getNumElements();
    double[] var30 = var28.getInternalValues();
    double[] var33 = new double[] { 10.0d, 100.0d};
    double var34 = var27.mannWhitneyU(var30, var33);
    org.apache.commons.math3.util.ResizableDoubleArray var35 = new org.apache.commons.math3.util.ResizableDoubleArray(var30);
    double var36 = var23.mannWhitneyU(var26, var30);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var37 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var39 = var38.getNumElements();
    double[] var40 = var38.getInternalValues();
    double[] var43 = new double[] { 10.0d, 100.0d};
    double var44 = var37.mannWhitneyU(var40, var43);
    org.apache.commons.math3.util.ResizableDoubleArray var45 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var46 = var45.getNumElements();
    double[] var47 = var45.getInternalValues();
    double var48 = var23.mannWhitneyUTest(var40, var47);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var49 = var17.mannWhitneyUTest(var21, var47);
      fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
    } catch (org.apache.commons.math3.exception.NoDataException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1.0d);

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test334"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     java.lang.String var5 = var1.nextSecureHexString(371);
//     long var8 = var1.nextSecureLong(0L, 8179512108L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextBinomial(317, (-1.5707963267948966d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "0a1aa6cf1152288bae8a357d067d1104bd53c8c86804484add6a73d2ca5a627997af504771f3096c7194d6e6b0175918de52f267a33654abf97103773f0a665a57995cfe36b473dffaad32327fa838493173371dd2e22492933f2fd89edb44e1779cb2f7d30eda8590e716e7d7c5713a5b3108857671a94bf5b001e48a88bd896a10807b7f88c46c7369b1bd6f797991eddfc6e96017f0c00a15c4664e6ff70f217949e8ea83052fcf61372f849f04d3452fdc8250025b513e5"+ "'", var5.equals("0a1aa6cf1152288bae8a357d067d1104bd53c8c86804484add6a73d2ca5a627997af504771f3096c7194d6e6b0175918de52f267a33654abf97103773f0a665a57995cfe36b473dffaad32327fa838493173371dd2e22492933f2fd89edb44e1779cb2f7d30eda8590e716e7d7c5713a5b3108857671a94bf5b001e48a88bd896a10807b7f88c46c7369b1bd6f797991eddfc6e96017f0c00a15c4664e6ff70f217949e8ea83052fcf61372f849f04d3452fdc8250025b513e5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2636398757L);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test335"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.0d, (-65));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test336"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test337"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.String var3 = var2.name();
    org.apache.commons.math3.random.RandomGenerator var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var6);
    java.lang.Class var9 = var6.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test338"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.5607966601082315d);
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var5 = var3.density(100.0d);
//     double var8 = var3.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double[] var10 = var3.sample(100);
//     double var11 = var3.getStandardDeviation();
//     double var13 = var3.cumulativeProbability((-0.004920366423301847d));
//     double var14 = var3.getNumericalVariance();
//     double var15 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var3);
//     var0.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var0.nextBeta(31.984371183438956d, (-2.184599888317818d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.05901220460392908d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.4980370657191222d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.2926543914375358d));
// 
//   }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test339"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 97.98819663162894d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test340"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(139.71834159643043d, 0.9999999989339062d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.2816582543164379d));

  }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test341"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextF(0.4980370657191222d, 1.7100683659172744d);
//     double var7 = var1.nextWeibull(4.440892098500626E-16d, 98.7271041519907d);
//     long var10 = var1.nextSecureLong(11L, 3520920169L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.013335078676722052d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3410095769L);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test342"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var4);
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test343"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    var0.reseedRandomGenerator(10L);
    double var4 = var0.density(1832.5694791909018d);
    double var5 = var0.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.POSITIVE_INFINITY);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test344"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.4329174706418153d, (-0.004920366423301847d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0010908414609777095d);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test345"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-1.0000001f), 1.07374182E9f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000001f);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test346"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.723245967437971d, 302.80582829370354d);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test347"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(19.591234255406928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6118882710102016E8d);

  }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test348"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     int var12 = var1.nextZipf(3, 0.949950589504148d);
//     var1.reSeedSecure();
//     double var16 = var1.nextCauchy(0.0d, 0.5637033385775058d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var1.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 99.51771416772677d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.57887793823871d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-3.2904104293010055d));
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test349"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.0000001f, 2.3841858E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.3841858E-7f);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test350"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var17 = var16.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    int var21 = var18.getNumElements();
    double[] var22 = var18.getElements();
    var16.addElements(var22);
    float var24 = var16.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var16);
    double var27 = var16.addElementRolling(3.4965075614664802d);
    var16.setExpansionMode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);

  }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test351"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     double var2 = var0.addElementRolling(Double.NaN);
//     double[] var3 = var0.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     double[] var6 = var5.getElements();
//     double[] var7 = null;
//     var5.addElements(var7);
// 
//   }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test352"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3628800L, 445);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test353"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.0d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test354"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1078420975), 5210);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 183357089);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test355"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var17 = var16.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    int var21 = var18.getNumElements();
    double[] var22 = var18.getElements();
    var16.addElements(var22);
    float var24 = var16.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var16);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    double[] var27 = var26.getElements();
    var26.addElement(100.0d);
    var26.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var32 = var26.getElement(16);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test356"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var7 = var1.nextExponential(209.99999999999997d);
//     var1.reSeedSecure();
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 13.716774555290991d);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test357"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(50, 445);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test358"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(6, 20988);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test359"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(506, 100);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test360"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    double[] var2 = var1.getElements();
    var1.discardMostRecentElements(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test361"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(31.899008269901618d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 77.74396115591381d);

  }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test362"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.5607966601082315d);
//     java.lang.String var4 = var0.nextHexString(506);
//     java.util.Collection var5 = null;
//     java.lang.Object[] var7 = var0.nextSample(var5, 875500725);
// 
//   }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test363"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     var1.reSeed();
//     double var10 = var1.nextBeta(31.984371183438952d, 3.141592653589793d);
//     var1.reSeed();
//     double var14 = var1.nextGamma(0.8742557239907629d, 9.583817113855682d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var16 = var1.nextSecureHexString((-347));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9066334030570954d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4.677238603001572d);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test364"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(14.155448481408198d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.6143618343498716d);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test365"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(58.29707782564671d, 1.257296821133544d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.4614240535036851d);

  }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test366"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 210);
// 
//   }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test367"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(60, 1.907349E-6f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test368"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    int var3 = var0.getNumElements();
    double[] var4 = var0.getElements();
    var0.setExpansionMode(0);
    var0.discardFrontElements(0);
    int var9 = var0.getExpansionMode();
    double[] var10 = var0.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardFrontElements(89);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test369"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var5 = null;
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var4, var5);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)(-2502316609L), (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test370"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.lang.Object[] var3 = new java.lang.Object[] { 'a'};
//     org.apache.commons.math3.exception.MathIllegalStateException var4 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var3);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var0, var3);
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.NotPositiveException var12 = new org.apache.commons.math3.exception.NotPositiveException(var10, (java.lang.Number)0);
//     java.lang.Object[] var13 = new java.lang.Object[] { 0};
//     org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var9, var13);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var8, var13);
//     org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var7, var13);
//     org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, var13);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test371"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(15.999999f, 0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 15.999999f);

  }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test372"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     double var9 = var1.nextGamma(2.6498507619080125d, (-0.05788914687716099d));
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var10.density(100.0d);
//     double var15 = var10.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double[] var17 = var10.sample(100);
//     double var18 = var10.getStandardDeviation();
//     boolean var19 = var10.isSupportUpperBoundInclusive();
//     var10.reseedRandomGenerator(1L);
//     boolean var22 = var10.isSupportLowerBoundInclusive();
//     double var23 = var10.getMean();
//     double var24 = var10.getSupportUpperBound();
//     double var25 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     double var28 = var1.nextGamma(119.31703692887734d, 0.022957956056843462d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var31 = var1.nextZipf(0, 4.288495151773556d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5524523678L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.1647551201015979d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.8433359681443745d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 2.8632707913896023d);
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test373"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.0f, 1.9073489E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test374"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(5.205744238502723d, 1.7439636808636205E32d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.205744238502723d);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test375"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    int var2 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var4 = var3.getNumElements();
    double[] var5 = var3.getInternalValues();
    int var6 = var3.getNumElements();
    double[] var7 = var3.getElements();
    var0.addElements(var7);
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var12);
    var12.setNumElements(300);
    int var16 = var12.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 300);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test376"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(30.543155519512883d, 2.6060472602392943d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.7294116033586491d));

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test377"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(1.2850859610229688d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.826403643342271d);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test378"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)2, (java.lang.Number)31.984371183438952d, (java.lang.Number)0.004002970929679791d);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test379"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-2124184289), (-1.2676506E30f), 0.0f, (-241));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test380"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(4.5E-44f, (-1.2676506E30f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.5E-44f);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test381"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.8925913538795224d);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test382"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var5 = var0.getNumericalVariance();
    var0.reseedRandomGenerator(100L);
    double var8 = var0.sample();
    boolean var9 = var0.isSupportConnected();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var11 = var0.sample((-1605022207));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.4705756905309871d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test383"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.949950589504148d, (java.lang.Number)(-4.013115666462255d), false);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test384"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var12 = var1.nextChiSquare(0.001736111111111111d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var1.nextLong(182642376L, (-6197319789L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3420563405L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
// 
//   }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test385"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-0.05388929638978884d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05388929638978884d);

  }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test386"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test387"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.9346228444644087d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8172460516973112d);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test388"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    int var10 = var9.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    java.lang.String var20 = var17.name();
    java.lang.Class var21 = var17.getDeclaringClass();
    java.lang.String var22 = var17.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "AVERAGE"+ "'", var22.equals("AVERAGE"));

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test389"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.9309003631188053d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test390"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var10 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var11.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var16 = var14.addElementRolling(Double.NaN);
    double[] var17 = var14.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var11, var18);
    double[] var20 = var11.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var24 = var23.getNumElements();
    double[] var25 = var23.getInternalValues();
    double[] var28 = new double[] { 10.0d, 100.0d};
    double var29 = var22.mannWhitneyU(var25, var28);
    var21.addElements(var28);
    var21.setContractionCriteria(2.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var33 = var21.copy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var34 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var37 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var38 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var39 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var40 = var39.getNumElements();
    double[] var41 = var39.getInternalValues();
    double[] var44 = new double[] { 10.0d, 100.0d};
    double var45 = var38.mannWhitneyU(var41, var44);
    org.apache.commons.math3.util.ResizableDoubleArray var46 = new org.apache.commons.math3.util.ResizableDoubleArray(var41);
    double var47 = var34.mannWhitneyU(var37, var41);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var48 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var49 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var50 = var49.getNumElements();
    double[] var51 = var49.getInternalValues();
    double[] var54 = new double[] { 10.0d, 100.0d};
    double var55 = var48.mannWhitneyU(var51, var54);
    org.apache.commons.math3.util.ResizableDoubleArray var56 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var57 = var56.getNumElements();
    double[] var58 = var56.getInternalValues();
    double var59 = var34.mannWhitneyUTest(var51, var58);
    var33.addElements(var51);
    double[] var61 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var62 = var10.mannWhitneyU(var51, var61);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 1.0d);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test391"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(11.015319454598572d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.99980507052264d));

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test392"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(0.999987895021552d, 15.322095332102348d, false);
//     double var8 = var1.nextGamma(1.4713540043352986d, 4.787491742782046d);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var9.getMean();
//     double var13 = var9.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var14 = var9.getNumericalVariance();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     var1.reSeedSecure((-10L));
//     var1.reSeed(82120112L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var21 = var1.nextSecureHexString((-7574));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5.975861094513841d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 15.99712333447223d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.1417204699366775d);
// 
//   }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test393"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.9584128699015102d, 14.534682406958717d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9584128699015102d);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test394"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(7.5557864E22f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2147483647);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test395"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-1.3113177943322367d), 100.63169380526709d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.013030125303900976d));

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test396"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    int var2 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var4 = var3.getNumElements();
    double[] var5 = var3.getInternalValues();
    int var6 = var3.getNumElements();
    double[] var7 = var3.getElements();
    var0.addElements(var7);
    var0.contract();
    float var10 = var0.getContractionCriteria();
    var0.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardMostRecentElements((-1271720519));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.5f);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test397"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(24.0d, 0.6263485952500932d);
    boolean var3 = var2.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test398"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    int var4 = var0.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardMostRecentElements((-7574));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test399"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed();
    var1.reSeed(0L);
    double var7 = var1.nextBeta(1.9865549713026993d, 0.024588566448858762d);
    var1.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSecureAlgorithm("6b2bf4", "02935e64d8e8dbe57220482402ad1f9b8870dec665010320667d79136f109b2849d6d2b3b14e6f5732f437cd734cf4eb9386cdd1239c60a08317713070b6a615e0bc943b71cea100d53190573967344b66cf576ed68c760382e14c0f9b4d48171c48b5e71be6cdbc840977124e6af02514de5e72772f34c9aafda2940108c8cd517ec08cfe59adb6f875acbd0673075e03cc587159cbc18861ee8c3629040c7c53934f7a58d894caf60b18c7f51fd033b977ac56a9fa5be1107");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test400"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(7.950137129262085E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.950137445285495E-8d);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test401"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(5210, (-47515));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test402"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(10.015471524400919d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.17480295424053163d);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test403"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.332621544395286E157d);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test404"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-0.99980507052264d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test405"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.03745141146713474d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test406"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.05782461145270825d), (java.lang.Number)(-1L), (java.lang.Number)100.0d);
//     java.lang.Number var8 = var7.getHi();
//     java.lang.Number var9 = var7.getHi();
//     java.lang.Number var10 = var7.getHi();
//     java.lang.Throwable[] var11 = var7.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.MaxCountExceededException var13 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)(-0.6480670652339844d), (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var11);
//     java.lang.String var15 = var14.toString();
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test407"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(2.002865034964586d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6945786729679109d);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test408"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-1096480911));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test409"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(0, 251);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test410"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(206);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test411"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 1.907349E-6f, Float.POSITIVE_INFINITY, 1000);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test412"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     double var8 = var1.nextExponential(44.5140274520795d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextCauchy(0.9720449790817591d, (-0.840700366736723d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 57.050375001180235d);
// 
//   }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test413"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(300, (-65));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 365);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test414"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-6197319789L), (java.lang.Number)0.20668320623619973d, (java.lang.Number)(-0.0930249421650573d));

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test415"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var11 = var10.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    int var15 = var12.getNumElements();
    double[] var16 = var12.getElements();
    var10.addElements(var16);
    var0.addElements(var16);
    float var19 = var0.getExpansionFactor();
    var0.clear();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var23 = var22.getNumElements();
    double[] var24 = var22.getInternalValues();
    double[] var27 = new double[] { 10.0d, 100.0d};
    double var28 = var21.mannWhitneyU(var24, var27);
    org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    var0.addElements(var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var32 = var0.getElement(206);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 32.0d);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test416"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 4966278053L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4966278053L);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test417"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(7.8492444081989055d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.0d);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test418"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var17 = var16.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    int var21 = var18.getNumElements();
    double[] var22 = var18.getElements();
    var16.addElements(var22);
    float var24 = var16.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var16);
    double var27 = var16.addElementRolling(3.4965075614664802d);
    org.apache.commons.math3.util.ResizableDoubleArray var28 = var16.copy();
    int var29 = var28.start();
    var28.setElement(9900, (-0.05618453265504479d));
    var28.discardFrontElements(9900);
    org.apache.commons.math3.util.ResizableDoubleArray var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray.copy(var28, var35);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test419"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma((-1.7429441502075451d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 18.462611448278334d);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test420"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(500);
    var8.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var10.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var15 = var13.addElementRolling(Double.NaN);
    double[] var16 = var13.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var10, var17);
    double[] var19 = var10.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    var8.addElements(var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var22 = var6.rank(var19);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test421"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(2.3841858E-7f, 1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test422"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(8.881784197001252E-16d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test423"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(65, (-22));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test424"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(100L, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100L);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test425"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(572.2646479502633d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 572.0d);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test426"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    int var2 = var0.start();
    boolean var4 = var0.equals((java.lang.Object)Double.NEGATIVE_INFINITY);
    double var6 = var0.addElementRolling(1.4713540043352986d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var0.getElement(210);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test427"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(3.123726322776123E-196d, 0.008126754594052727d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.008126754594052727d);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test428"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var12 = var10.addElementRolling(Double.NaN);
    double[] var13 = var10.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    var0.addElements(var13);
    double var17 = var0.addElementRolling(0.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = var0.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setElement((-1023), 1.7427271998994087d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test429"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-0.5458066324533807d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test430"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     double var9 = var1.nextT(1.5855819012757701d);
//     double var12 = var1.nextCauchy((-1.8456016649756868d), 4.9E-324d);
//     double var15 = var1.nextGaussian((-0.014542775949576744d), 42.68079794095493d);
//     java.util.Collection var16 = null;
//     java.lang.Object[] var18 = var1.nextSample(var16, (-15));
// 
//   }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test431"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    int var3 = var0.getNumElements();
    double[] var4 = var0.getElements();
    var0.setExpansionMode(0);
    var0.addElement(0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var0.getElement((-273));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test432"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.9999999033896889d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6449342991103786d);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test433"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var5 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var7 = var2.name();
    java.lang.Class var8 = var2.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var10 = java.lang.Enum.<java.lang.Enum>valueOf(var8, "29ed70f13bb7ad46f460186017e66097afb29425604f5ce6013aad50de27d1839ff38fefaf3024af2bb9c35db46ea9c1b39661db566c4d93ea5216e953f75608d761042d1d7c9f403ec945d2001667c7a7f1c60a14dfa3dc14b0957c90ba09741079085e8fe6ccff26bdbacc78c5ea6a12ce9921226c8dafc77c6bf83eeb751c6c26b9106d132d65504085de89e5a33d2dd3eb3d94e4d24877cc029b0895942a75b870c541f8bbbfd706029c3eea54aa1c278df2c7ec627a0b8ee3b72226b99fc483c806033dc210779f83cca2ed3a7245136fa3e9feba8009f2f6e62059c4e19dd78f68b4180a5327a52e8415f7dd4e0113efa08ba9649dba06");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "MAXIMAL"+ "'", var5.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test434"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    java.lang.Class var7 = var6.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = var8.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var8.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
    int var14 = var13.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.NaNStrategy var18 = var17.getNanStrategy();
    java.lang.Class var19 = var18.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var21);
    java.lang.String var25 = var21.name();
    java.lang.String var26 = var21.name();
    int var27 = var21.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    int var29 = var21.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "AVERAGE"+ "'", var25.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "AVERAGE"+ "'", var26.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 3);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test435"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.36792469441508013d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test436"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(36L, 393769108042894612L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 393769108042894612L);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test437"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.7100683659172744d, (java.lang.Number)Float.POSITIVE_INFINITY, (java.lang.Number)(byte)0);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    java.lang.Number var5 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.7100683659172744d+ "'", var5.equals(1.7100683659172744d));

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test438"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var4);
    java.lang.String var6 = var3.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "MAXIMAL"+ "'", var6.equals("MAXIMAL"));

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test439"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getNumericalMean();
    double var2 = var0.getStandardDeviation();
    boolean var3 = var0.isSupportLowerBoundInclusive();
    double var4 = var0.getSupportLowerBound();
    double var5 = var0.getSupportLowerBound();
    double var6 = var0.getMean();
    boolean var7 = var0.isSupportConnected();
    double var9 = var0.probability((-0.05388929638978884d));
    boolean var10 = var0.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test440"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(402.7572967449497d, 0.0576550898240642d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 402.75729674494966d);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test441"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.065175436767987d, (java.lang.Number)3628800L, true);
    boolean var4 = var3.getBoundIsAllowed();
    boolean var5 = var3.getBoundIsAllowed();
    boolean var6 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test442"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)Double.NaN, (java.lang.Number)0.6139648708421599d, true);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var9 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var7, (java.lang.Number)4.158638853279167d, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var9);
    java.lang.Throwable[] var14 = var13.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test443"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-0.22462663147858472d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.2492647519380979d));

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test444"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "2bf54b");
// 
//   }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test445"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(1.2588883301765683d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2588883301765685d);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test446"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, 0.9346228444644087d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test447"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.023342202012890834d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.6318581766994622d));

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test448"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(4.427429051327539d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2532736335125701d);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test449"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)31.98437118343895d, (java.lang.Number)10L, false);
    java.lang.String var4 = var3.toString();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    java.lang.Number var6 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 31.984 is smaller than, or equal to, the minimum (10)"+ "'", var4.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 31.984 is smaller than, or equal to, the minimum (10)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 31.98437118343895d+ "'", var6.equals(31.98437118343895d));

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test450"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    java.lang.Class var9 = var6.getDeclaringClass();
    java.lang.Enum var11 = java.lang.Enum.<java.lang.Enum>valueOf(var9, "MAXIMAL");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test451"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var0.substituteMostRecentElement(0.6387763808612118d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test452"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(1.5690509993150914d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 572.9577951308354d);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test453"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)Double.NaN, (java.lang.Number)0.6139648708421599d, true);
    java.lang.Number var4 = var3.getMax();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.NotPositiveException var9 = new org.apache.commons.math3.exception.NotPositiveException(var7, (java.lang.Number)0);
    java.lang.Object[] var10 = new java.lang.Object[] { 0};
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var6, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, var10);
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var12.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.6139648708421599d+ "'", var4.equals(0.6139648708421599d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test454"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(2.322219294733919d, (-12.844009081315292d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.9989769647633786d));

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test455"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(4448708814L, 1772309183L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7884487483545238962L);

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test456"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-1023), 0);
//     java.lang.String var6 = var1.nextSecureHexString(6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var1.nextCauchy(0.9359057028076155d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-159));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "b01d3b"+ "'", var6.equals("b01d3b"));
// 
//   }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test457"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(371, 330);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 330);

  }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test458"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var8 = var1.nextGamma(4.937302184657956d, 97.98819663162894d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextF((-0.5788982422751958d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9999998131199184d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 261.3035359442117d);
// 
//   }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test459"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(60, 82120112L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test460"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.9359057028076155d, (java.lang.Number)124952017, false);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test461"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var5 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var7 = var2.name();
    java.lang.Class var8 = var2.getDeclaringClass();
    boolean var10 = var2.equals((java.lang.Object)2.4999998f);
    java.lang.Class var11 = var2.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "MAXIMAL"+ "'", var5.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test462"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)30.0d);

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test463"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     var1.reSeed();
//     double var10 = var1.nextBeta(31.984371183438952d, 3.141592653589793d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var1.nextBinomial((-17), 5.532960982624758d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9087494081231355d);
// 
//   }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test464"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var5 = java.lang.Enum.<java.lang.Enum>valueOf(var3, "af472223a19f55f3564d01f4e260de8820a9f056a1276a246d1f0fe22c35278d5baaaa6028d755d96028d01779d26a3b141aece6ad92ab37a988096f78945e6afb8435cadcbbe4511f5d392d98bf1c44f13cd433f600ad8f46b69ea6658c3bcee869cbba854bf65e80358414961c1c043a870ee88ae28bf8a5ccace2d207d531ba2b48c4d4fb0970ececf5de26e304244e3acb6058f22dd8a51e3cb617baf0fb33b8444ab23e5327362a20e729eb840c1954ce65e48f36d903899b4095c83798efb7ac82d91bca63e3f4e1156bc98ca20e7359b1c25a4cda6f050a0ce1731302171bda35412bc62fffaaf302cb4ec393f90157f0c7103de2c000f4db3e");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test465"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var12 = var1.nextChiSquare(0.001736111111111111d);
//     double var15 = var1.nextBeta(0.36792469441508013d, 0.23074612792124255d);
//     var1.reSeed((-6197319789L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var20 = var1.nextLong(7172474253L, 664646591L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6193093022L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.5368523929001137E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.6121332664505518d);
// 
//   }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test466"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(Double.POSITIVE_INFINITY, 1.1246894405507097d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test467"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("4bffd0a0022bc47a4d81261b9c970bff2fa315bf21ff1fc053bd6f5b61ea543c2c195653a0295f802ba711a290a052ffe5dbbd18040ec2cd9563f46f2ab4cb8cba00e625b5014bea2a9a5c63b69d0b3e3e1c373a708349bdd07e6de4860c15071c56e0b56b7a5bf2ce6525d81b3e5fcb721b8f2a4831dba1f3bc51f610d65d54e9f841a7b31c013194fe981a329afb9529a094e5886a3c8b0664be276df2abb6cae438f9e245addaa753394cf0db0cfa22abeabc603a21280a46cc15e7bc4e4cac1d79ab6ea8b1eb79416fd57fe4de243a3efaa6111ca1891103f5e9ea5bdd5f6ed648c92f7d4ae8998061a5cf4bf77aedb7b2b63b5ec4ad8276");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test468"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(7.60268502423026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9685908209500688d);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test469"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    boolean var4 = var0.equals((java.lang.Object)1.0854629842427983d);
    var0.addElement(1.065175436767987d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test470"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)10, (java.lang.Number)3.7621956910836314d, (java.lang.Number)0.7172507104665835d);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    java.lang.Number var5 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10+ "'", var5.equals(10));

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test471"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test472"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-1037414828), (-7500));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7500));

  }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test473"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, var1);
//     org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test474"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.5607966601082315d);
//     java.lang.String var4 = var0.nextHexString(506);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var8 = var0.nextSecureLong(1772309183L, (-5154125899424117313L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.1273910293885317d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7fe8c2e39cf9d881f3a7ef5719418c3b864c91356c058e945a10ea392388371523a5d68ed0905021ff5c392a6c8d31080db174cd5585b297c76aa221b5e0cd58209898d7daab7bf0d6d0ff94394390ced0eeed01520824140f7b8b3e032ec21901306bfcde1b08c7af17027dede1d612f67432d86ed5aa941717a334bdd9d722c764d01c0938149acfc2700e7ee677e7791fe1ee88c9cdeeb1be89b37a17663826e25c7fa4652d41ed8112e6a341840b0547bd138c36409fcadf0dbacd2d94b6e284c2271537a0363eef5cb41ce09a033d08a9e3ae4bbc6e0dcd08a6b3fbdf4965aa68b7166f3aa557177d894ec1a3f4f90c0a94509c2ac189a9c9d268"+ "'", var4.equals("7fe8c2e39cf9d881f3a7ef5719418c3b864c91356c058e945a10ea392388371523a5d68ed0905021ff5c392a6c8d31080db174cd5585b297c76aa221b5e0cd58209898d7daab7bf0d6d0ff94394390ced0eeed01520824140f7b8b3e032ec21901306bfcde1b08c7af17027dede1d612f67432d86ed5aa941717a334bdd9d722c764d01c0938149acfc2700e7ee677e7791fe1ee88c9cdeeb1be89b37a17663826e25c7fa4652d41ed8112e6a341840b0547bd138c36409fcadf0dbacd2d94b6e284c2271537a0363eef5cb41ce09a033d08a9e3ae4bbc6e0dcd08a6b3fbdf4965aa68b7166f3aa557177d894ec1a3f4f90c0a94509c2ac189a9c9d268"));
// 
//   }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test475"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(9741938155L, 32718048432L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test476"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)5, (java.lang.Number)Double.NEGATIVE_INFINITY, true);
//     java.lang.Throwable[] var5 = var4.getSuppressed();
//     org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var5);
//     java.lang.Throwable var7 = null;
//     var6.addSuppressed(var7);
// 
//   }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test477"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs((-0.5458066324533806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5458066324533806d);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test478"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var11 = var10.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    int var15 = var12.getNumElements();
    double[] var16 = var12.getElements();
    var10.addElements(var16);
    var0.addElements(var16);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
    int var20 = var19.getExpansionMode();
    int var21 = var19.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test479"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.9982044311039222d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test480"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var5 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var7 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = var8.getTiesStrategy();
    int var10 = var9.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "MAXIMAL"+ "'", var5.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 3);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test481"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(159.50662885967768d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.072085481610059d);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test482"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(7.950137129262085E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test483"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.start();
    double[] var2 = var0.getElements();
    var0.setContractionCriteria(15.999999f);
    float var5 = var0.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardMostRecentElements(1078421185);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.0f);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test484"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("org.apache.commons.math3.exception.NumberIsTooLargeException: \uFFFD is larger than the maximum (0.614)");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test485"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-10.567559072274053d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9999742624378867d));

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test486"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9030899869919435d);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test487"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.9999999987432595d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1752011917045495d);

  }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test488"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     double var8 = var1.nextExponential(44.5140274520795d);
//     int var11 = var1.nextSecureInt((-241), 0);
//     java.util.Collection var12 = null;
//     java.lang.Object[] var14 = var1.nextSample(var12, 206);
// 
//   }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test489"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.945481894075095d, var2, false);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test490"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(396);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var3 = var2.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var5 = var4.getNumElements();
    double[] var6 = var4.getInternalValues();
    int var7 = var4.getNumElements();
    double[] var8 = var4.getElements();
    var2.addElements(var8);
    int var10 = var2.getNumElements();
    double[] var11 = var2.getInternalValues();
    var1.addElements(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test491"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var12 = var10.addElementRolling(Double.NaN);
    double[] var13 = var10.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    var0.addElements(var13);
    double var17 = var0.addElementRolling(0.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    int var20 = var18.start();
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var22 = var21.getNumElements();
    double[] var23 = var21.getInternalValues();
    int var24 = var21.getNumElements();
    double[] var25 = var21.getElements();
    var18.addElements(var25);
    var18.contract();
    float var28 = var18.getContractionCriteria();
    var18.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var18);
    int var32 = var0.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);

  }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test492"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextPascal(100, 0.0d);
//     long var5 = var0.nextPoisson(0.07637989519631011d);
//     var0.reSeedSecure(9617852649L);
//     double var10 = var0.nextGamma(1.071112867107899d, (-0.010152952316618155d));
//     var0.reSeed(10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.0019750240854171527d));
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test493"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(330, 128);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 128);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test494"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(4.584981588187509d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test495"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    var10.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test496"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(731, 60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 204.54678671315d);

  }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test497"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.5607966601082315d);
//     double var4 = var0.nextExponential(0.13463348377254322d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextF(0.0d, (-0.37395456110342123d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.3899705971951983d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.1293213308856796d);
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test498"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(2.3841858E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.842171E-14f);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test499"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var12 = var10.addElementRolling(Double.NaN);
    double[] var13 = var10.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    var0.addElements(var13);
    int var16 = var0.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionMode(100);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test500"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    var0.contract();
    double var12 = var0.addElementRolling((-0.9793091478686597d));
    float var13 = var0.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardMostRecentElements(359);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.0f);

  }

}
