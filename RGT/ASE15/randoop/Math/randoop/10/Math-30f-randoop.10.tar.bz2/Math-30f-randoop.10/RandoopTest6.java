
import junit.framework.*;

public class RandoopTest6 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test1"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.26765045E30f, 1.2676505E30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2676505E30f);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test2"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(3.399216241149525E248d, 0.8998354296541002d);
    double var3 = var2.getMean();
    boolean var4 = var2.isSupportUpperBoundInclusive();
    double var5 = var2.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 3.399216241149525E248d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 3.399216241149525E248d);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test3"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(3363459797L, 5863705777L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3363459797L);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test4"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(byte)(-1), (java.lang.Number)(short)1, true);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test5"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(1.6007479984283653E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-11.042454445950384d));

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test6"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(736063294, 396);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test7"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-0.37395456110342123d));

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test8"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     int var12 = var1.nextZipf(3, 0.949950589504148d);
//     var1.reSeedSecure();
//     double var15 = var1.nextChiSquare(0.47014179544311024d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 100.10370351147418d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.2898190268722565d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0041119587560273d);
// 
//   }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test9"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     double var9 = var1.nextGamma(2.6498507619080125d, (-0.05788914687716099d));
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var10.density(100.0d);
//     double var15 = var10.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double[] var17 = var10.sample(100);
//     double var18 = var10.getStandardDeviation();
//     boolean var19 = var10.isSupportUpperBoundInclusive();
//     var10.reseedRandomGenerator(1L);
//     boolean var22 = var10.isSupportLowerBoundInclusive();
//     double var23 = var10.getMean();
//     double var24 = var10.getSupportUpperBound();
//     double var25 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     int var28 = var1.nextInt(500, 5306065);
//     org.apache.commons.math3.distribution.IntegerDistribution var29 = null;
//     int var30 = var1.nextInversionDeviate(var29);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test10"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var5 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = var8.getTiesStrategy();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var10.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var15 = var13.addElementRolling(Double.NaN);
    double[] var16 = var13.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var10, var17);
    double[] var19 = var10.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var23 = var22.getNumElements();
    double[] var24 = var22.getInternalValues();
    double[] var27 = new double[] { 10.0d, 100.0d};
    double var28 = var21.mannWhitneyU(var24, var27);
    var20.addElements(var27);
    boolean var30 = var9.equals((java.lang.Object)var20);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var31 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var9);
    double[] var34 = new double[] { 10.0d, (-1.0d)};
    org.apache.commons.math3.stat.ranking.TiesStrategy var35 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var35);
    org.apache.commons.math3.stat.ranking.NaNStrategy var37 = var36.getNanStrategy();
    int var38 = var37.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var39 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var39);
    org.apache.commons.math3.stat.ranking.NaNStrategy var41 = var40.getNanStrategy();
    java.lang.Class var42 = var41.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var43 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var41);
    org.apache.commons.math3.stat.ranking.TiesStrategy var44 = var43.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var45 = var43.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var46 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var47 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var46);
    org.apache.commons.math3.stat.ranking.NaNStrategy var48 = var47.getNanStrategy();
    int var49 = var48.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var50 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var48);
    org.apache.commons.math3.stat.ranking.TiesStrategy var51 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var52 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var51);
    org.apache.commons.math3.stat.ranking.NaNStrategy var53 = var52.getNanStrategy();
    java.lang.Class var54 = var53.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var55 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var53);
    org.apache.commons.math3.stat.ranking.TiesStrategy var56 = var55.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var57 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var48, var56);
    org.apache.commons.math3.stat.ranking.NaturalRanking var58 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var45, var56);
    org.apache.commons.math3.stat.ranking.NaturalRanking var59 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var37, var56);
    org.apache.commons.math3.util.ResizableDoubleArray var60 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var61 = var60.getNumElements();
    int var62 = var60.start();
    org.apache.commons.math3.util.ResizableDoubleArray var63 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var64 = var63.getNumElements();
    double[] var65 = var63.getInternalValues();
    int var66 = var63.getNumElements();
    double[] var67 = var63.getElements();
    var60.addElements(var67);
    var60.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var72 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var60, var72);
    var72.setElement(825, (-0.06991186090907374d));
    double[] var77 = var72.getElements();
    double[] var78 = var59.rank(var77);
    double var79 = var31.mannWhitneyU(var34, var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "MAXIMAL"+ "'", var5.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 1651.0d);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test11"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, (-2.769568785966569d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-4.9E-324d));

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test12"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5f);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test13"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.024588566448858762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.02458361225088624d);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test14"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)6.785121971699368E-66d, (java.lang.Number)1.1102230246251565E-16d, false);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test15"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var3);
    var3.clear();
    var3.clear();

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test16"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)4748492575L, (java.lang.Number)1.0473060485928132d);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getHi();
    org.apache.commons.math3.exception.NoDataException var7 = new org.apache.commons.math3.exception.NoDataException();
    var4.addSuppressed((java.lang.Throwable)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.0473060485928132d+ "'", var5.equals(1.0473060485928132d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1.0473060485928132d+ "'", var6.equals(1.0473060485928132d));

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test17"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(44.0d, 6.5895866800733485d, 0.5985964988634461d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var3.cumulativeProbability(34.812727742759826d, (-0.6480670652339844d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test18"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.5395502634883683d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8579398203420858d);

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test19"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     java.lang.String var5 = var1.nextSecureHexString(371);
//     long var8 = var1.nextSecureLong(0L, 8179512108L);
//     long var11 = var1.nextSecureLong(3520920158L, 4448708814L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextBeta((-0.2554932247505838d), 0.20668320623619973d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "eb81d2418066f5f5aa0b6c25ddbed3d820ffcd4bbe8daeb833e81eb899c643df42b99062bc1f9a0c1f0988a6fc35f1cb10addb902f5bd51892706a011ca0695950a4112ee2d130a1707bb631b5c5f6f2b415690ac3862935724c6bf7337d297a517e99d9016f188376bb49fc0b87f510f80b0fa482d7b6af9561a5308768685622de1ac80140af2cb332c99706a7dae8368f13eeaecb8b528ffea2f516cfa8840e11a0dced580ee88938454b3a828ace4b113b7fd71452174c2"+ "'", var5.equals("eb81d2418066f5f5aa0b6c25ddbed3d820ffcd4bbe8daeb833e81eb899c643df42b99062bc1f9a0c1f0988a6fc35f1cb10addb902f5bd51892706a011ca0695950a4112ee2d130a1707bb631b5c5f6f2b415690ac3862935724c6bf7337d297a517e99d9016f188376bb49fc0b87f510f80b0fa482d7b6af9561a5308768685622de1ac80140af2cb332c99706a7dae8368f13eeaecb8b528ffea2f516cfa8840e11a0dced580ee88938454b3a828ace4b113b7fd71452174c2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 362451403L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3707775442L);
// 
//   }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test20"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     int var8 = var1.nextPascal(2147483647, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextInt(18, (-343670429));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 99.60980981443367d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2147483647);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test21"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.3063909472492726d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11.779059426281279d);

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test22"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var13 = var1.nextUniform(0.9999943487368532d, 44.5140274520795d);
//     double var15 = var1.nextChiSquare(51.55677237552102d);
//     java.util.Collection var16 = null;
//     java.lang.Object[] var18 = var1.nextSample(var16, (-20));
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test23"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test24"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-0.11744609541833517d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-6.72916558776136d));

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test25"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, 1.07374182E9f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test26"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(1.1435499697078755d, 507.5757515636374d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.705952781032978E29d);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test27"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(2.1991384700657077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9981294524127161d);

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test28"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     int var3 = var2.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
//     java.lang.Class var8 = var7.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
//     double[] var14 = null;
//     double[] var15 = var13.rank(var14);
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test29"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-7.520871210725989E-16d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-7.520871210725989E-16d));

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test30"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getStandardDeviation();
    boolean var9 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator(1L);
    boolean var12 = var0.isSupportUpperBoundInclusive();
    boolean var13 = var0.isSupportLowerBoundInclusive();
    double var14 = var0.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == Double.POSITIVE_INFINITY);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test31"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var17 = var16.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    int var21 = var18.getNumElements();
    double[] var22 = var18.getElements();
    var16.addElements(var22);
    float var24 = var16.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var16);
    double var27 = var16.addElementRolling(3.4965075614664802d);
    float var28 = var16.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.setExpansionMode(16938270);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 2.0f);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test32"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(95455);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test33"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    int var4 = var0.getNumElements();
    float var5 = var0.getExpansionFactor();
    int var6 = var0.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionFactor(100.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test34"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    double var3 = var1.addElementRolling((-0.05782461145270825d));
    boolean var5 = var1.equals((java.lang.Object)0.723245967437971d);
    var1.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setNumElements((-1037414828));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test35"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var3 = var2.getNumElements();
    double[] var4 = var2.getInternalValues();
    int var5 = var2.getNumElements();
    double[] var6 = var2.getElements();
    var0.addElements(var6);
    float var8 = var0.getContractionCriteria();
    float var9 = var0.getContractionCriteria();
    float var10 = var0.getExpansionFactor();
    var0.addElement(1.022519701004396d);
    boolean var14 = var0.equals((java.lang.Object)2.12090952255429d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test36"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(9672270833L, 8770513317L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test37"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(14.528828146419674d, 302.80582829370354d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test38"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.1805961123312282d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1796285576310511d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test39"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(3645265866L, 2502316609L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2502316609L);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test40"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.029923905963016993d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1118.3450186250402d);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test41"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.8742557239907629d, var2, true);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test42"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 9617852649L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 9617852649L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, (-347));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test43"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var7 = var1.nextExponential(209.99999999999997d);
//     var1.reSeedSecure();
//     var1.reSeed(4448708814L);
//     java.lang.String var12 = var1.nextSecureHexString(7550);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 95.56912115511714d);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test44"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    int var4 = var1.nextBinomial(0, 2.0301213984251357E-6d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var1.nextUniform(45.62735494233193d, 0.0d, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test45"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(1.2330506708687499d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.570140134898327d);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test46"); }


    double var2 = org.apache.commons.math3.special.Erf.erf((-2.0d), 100.7787827335538d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9953222650189528d);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test47"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(6.315930032722342E-37d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.315930032722342E-37d);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test48"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.07083995937978713d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.07078084342092326d);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test49"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("167c14c590365aaf7fb27f8dd66b8c93b4b3c93161da6587af2903170f60e66a1956a05934d995317f89f0618252fdb4cdee7f0d593112d505dd082031727da601a22ebe987866f0aac7ac2c5545ac0ef55cc219222d0a67fd4955c3c5ec23c88955603f0e613e768eac73fab8c56ad9124cf8686b5c7d37747deb29b0d41b27a9bb6488bcf40544a4f0485f1bead3ac327172237ecb5a04711e9d9c0b1e3");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test50"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed();
    var1.reSeed(0L);
    double var6 = var1.nextT(0.9999999984381234d);
    var1.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var1.nextHypergeometric(0, (-1135542650), (-273));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.9584128699015102d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test51"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-65), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test52"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var4 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.OutOfRangeException var10 = new org.apache.commons.math3.exception.OutOfRangeException(var6, (java.lang.Number)24.0d, (java.lang.Number)0.723245967437971d, (java.lang.Number)825);
    var5.addSuppressed((java.lang.Throwable)var10);
    java.lang.Throwable[] var12 = var5.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test53"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-0.0019750240854171527d), (java.lang.Number)0.4074878474110412d, false);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test54"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(15.227362052091127d, 0.0d, 0.7970392056484709d, 365);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test55"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    double[] var3 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var6);
    boolean var8 = var2.equals((java.lang.Object)var6);
    java.lang.Class var9 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test56"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(98.75180450337287d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.115592323835657d);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test57"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)24.0d, (java.lang.Number)0.723245967437971d, (java.lang.Number)825);
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.723245967437971d+ "'", var5.equals(0.723245967437971d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.723245967437971d+ "'", var6.equals(0.723245967437971d));

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test58"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)2.148147810647578d);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test59"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(3123671065L, (-5155502182L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5155502182L));

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test60"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-0.08948812915473234d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.08936873827836152d));

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test61"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-5155502182L), (-6275290550L));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test62"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-0.8564026207044273d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test63"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getStandardDeviation();
    boolean var9 = var0.isSupportConnected();
    double var10 = var0.getNumericalMean();
    double var11 = var0.getNumericalMean();
    double var12 = var0.getSupportUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var14 = var0.sample(685776825);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == Double.POSITIVE_INFINITY);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test64"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.9604645E-8f);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test65"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    double[] var14 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.NaNStrategy var17 = var16.getNanStrategy();
    int var18 = var17.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var19 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19);
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var20.getNanStrategy();
    java.lang.Class var22 = var21.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    org.apache.commons.math3.stat.ranking.TiesStrategy var24 = var23.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var25 = var23.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26);
    org.apache.commons.math3.stat.ranking.NaNStrategy var28 = var27.getNanStrategy();
    int var29 = var28.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var28);
    org.apache.commons.math3.stat.ranking.TiesStrategy var31 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var31);
    org.apache.commons.math3.stat.ranking.NaNStrategy var33 = var32.getNanStrategy();
    java.lang.Class var34 = var33.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var33);
    org.apache.commons.math3.stat.ranking.TiesStrategy var36 = var35.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var28, var36);
    org.apache.commons.math3.stat.ranking.NaturalRanking var38 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25, var36);
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var36);
    java.lang.String var40 = var36.name();
    java.lang.String var41 = var36.name();
    java.lang.String var42 = var36.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var43 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var36);
    org.apache.commons.math3.stat.ranking.TiesStrategy var44 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var45 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var44);
    org.apache.commons.math3.stat.ranking.NaNStrategy var46 = var45.getNanStrategy();
    java.lang.String var47 = var46.name();
    org.apache.commons.math3.random.RandomGenerator var48 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var49 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var48);
    org.apache.commons.math3.stat.ranking.TiesStrategy var50 = var49.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var51 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var50);
    org.apache.commons.math3.stat.ranking.NaturalRanking var52 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var46, var50);
    org.apache.commons.math3.stat.ranking.TiesStrategy var53 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var54 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var53);
    org.apache.commons.math3.stat.ranking.NaNStrategy var55 = var54.getNanStrategy();
    int var56 = var55.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var57 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var55);
    org.apache.commons.math3.stat.ranking.TiesStrategy var58 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var59 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var58);
    org.apache.commons.math3.stat.ranking.NaNStrategy var60 = var59.getNanStrategy();
    java.lang.Class var61 = var60.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var62 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var60);
    org.apache.commons.math3.stat.ranking.TiesStrategy var63 = var62.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var64 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var55, var63);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var65 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var66 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var67 = var66.getNumElements();
    double[] var68 = var66.getInternalValues();
    double[] var71 = new double[] { 10.0d, 100.0d};
    double var72 = var65.mannWhitneyU(var68, var71);
    double[] var73 = var64.rank(var71);
    double[] var74 = var52.rank(var73);
    double[] var75 = var43.rank(var73);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var76 = var0.mannWhitneyU(var14, var73);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var40 + "' != '" + "AVERAGE"+ "'", var40.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + "AVERAGE"+ "'", var41.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + "AVERAGE"+ "'", var42.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + "MAXIMAL"+ "'", var47.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test66"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-389), 5120);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4731);

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test67"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var13 = var1.nextUniform(0.9999943487368532d, 44.5140274520795d);
//     double var15 = var1.nextChiSquare(51.55677237552102d);
//     double var18 = var1.nextGaussian(100.0d, 0.8939360120238292d);
//     org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var21 = var19.density(100.0d);
//     double var24 = var19.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double var25 = var19.getMean();
//     double var26 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var19);
//     double var27 = var19.getNumericalMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7208084573L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 25.95005698637282d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 71.32582295398767d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 99.49811583654233d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.0632259194219145d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.0d);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test68"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    int var2 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var4 = var3.getNumElements();
    double[] var5 = var3.getInternalValues();
    int var6 = var3.getNumElements();
    double[] var7 = var3.getElements();
    var0.addElements(var7);
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var12);
    int var14 = var12.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test69"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.1043085576747377d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1172741251349894d);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test70"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(128, 154);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-26));

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test71"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var3);
    var1.contract();
    var1.addElement((-0.8307376748471434d));
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double var10 = var1.substituteMostRecentElement((-2.347333589296936d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-0.8307376748471434d));

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test72"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(3.986896366226194d, 9.999999999999998d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.010179258543542602d);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test73"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(317625249L, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test74"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    double var17 = var14.substituteMostRecentElement(0.3742437696541317d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var21 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var24 = var23.getNumElements();
    double[] var25 = var23.getInternalValues();
    double[] var28 = new double[] { 10.0d, 100.0d};
    double var29 = var22.mannWhitneyU(var25, var28);
    org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
    double var31 = var18.mannWhitneyU(var21, var25);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var32 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var33 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var34 = var33.getNumElements();
    double[] var35 = var33.getInternalValues();
    double[] var38 = new double[] { 10.0d, 100.0d};
    double var39 = var32.mannWhitneyU(var35, var38);
    org.apache.commons.math3.util.ResizableDoubleArray var40 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var41 = var40.getNumElements();
    double[] var42 = var40.getInternalValues();
    double var43 = var18.mannWhitneyUTest(var35, var42);
    var14.addElements(var42);
    var14.addElement(0.0d);
    double var48 = var14.substituteMostRecentElement((-0.8307376748471434d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test75"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(317, (-1023));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test76"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     int var8 = var1.nextInt((-347), 300);
//     int var11 = var1.nextSecureInt(3570, 2147483647);
//     double var14 = var1.nextGamma((-0.8307376748471434d), 1.4251878220010183d);
//     long var17 = var1.nextLong(7080423162L, 7220072592L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-270));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 613865270);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.2289665767933315d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 7130953186L);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test77"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(1966771617, 89);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test78"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     java.lang.String var8 = var1.nextHexString(500);
//     double var11 = var1.nextGamma(0.723245967437971d, 4.089618308475393d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextBeta(0.00779688714965288d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2563492447L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "c87dd0789d5834319dbb0385ef978a1076c6d32de84bdb618b28a2d257e390aaf5f7e2cf0bd96a24fdf1b2382c5c7eca59b6421ddc30d87529c5cfd32c68ebb5599a9c2fad1a862194bbee4a496a0f9d796558636fdc95c10c4377f4000775d4d25f314c26635db22cedd7430b5f0435e5be0dc5075a5dd67d21c393a56ae9293194bc5c2ad29114e55fa5b9ddebbd8f237d517ef13c94083b0596aefad3958390ce3f1d3b92508347f4b47a34e9803642342d47f1f6ac7ab077f39feffb7716d01d13b2f66a972e69700a9400a9fa52ccd4e0e3d7c13b34619c0ef083249c2809909633f80f848cab3b865697ce2f6bf284fcb792ef8aa2b434"+ "'", var8.equals("c87dd0789d5834319dbb0385ef978a1076c6d32de84bdb618b28a2d257e390aaf5f7e2cf0bd96a24fdf1b2382c5c7eca59b6421ddc30d87529c5cfd32c68ebb5599a9c2fad1a862194bbee4a496a0f9d796558636fdc95c10c4377f4000775d4d25f314c26635db22cedd7430b5f0435e5be0dc5075a5dd67d21c393a56ae9293194bc5c2ad29114e55fa5b9ddebbd8f237d517ef13c94083b0596aefad3958390ce3f1d3b92508347f4b47a34e9803642342d47f1f6ac7ab077f39feffb7716d01d13b2f66a972e69700a9400a9fa52ccd4e0e3d7c13b34619c0ef083249c2809909633f80f848cab3b865697ce2f6bf284fcb792ef8aa2b434"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 6.993133343591198d);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test79"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(1.8171205928321397d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.525552754171548d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test80"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.6219701720597971d);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test81"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.057774618901562d, 0.48076935803388726d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.3542123153443012d);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test82"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)3617318266L);
//     java.lang.String var3 = var2.toString();
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test83"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.42960132384540173d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test84"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(10.015471524400919d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test85"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var4 = var0.density(4.937302184657956d);
    double var6 = var0.inverseCumulativeProbability(0.0d);
    double var7 = var0.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0301213984251357E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test86"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(3.399216241149525E248d, 0.8998354296541002d);
    double var3 = var2.getSupportLowerBound();
    boolean var4 = var2.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test87"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-0.9422952790472405d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8399760211277356d));

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test88"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     java.lang.String var5 = var1.nextSecureHexString(371);
//     long var8 = var1.nextSecureLong(0L, 8179512108L);
//     int var11 = var1.nextInt((-347), 5306065);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "f29192a88ff0c6aaa7672c11cfc9b6e45f198182ace5ce082e7802cff63f57d79de42ecca579518c54e47e63443c6f9569598e519979e2a276369f8f36ed1bfab02be28c85b1caaaf9bed424fa4e0a466eaf160d5dd0263b7b7cc1a6836d0d81815628ace4d70b28836dba1e32fa5553c7403de5bc24db3a54a669333fe53e9b74367a90f539707e94675625a9d7a7254ef4b24f7634717ee3d29b13e0d184e606967c25b150439a38045911691e6f93e73a3dffa3bea20d821"+ "'", var5.equals("f29192a88ff0c6aaa7672c11cfc9b6e45f198182ace5ce082e7802cff63f57d79de42ecca579518c54e47e63443c6f9569598e519979e2a276369f8f36ed1bfab02be28c85b1caaaf9bed424fa4e0a466eaf160d5dd0263b7b7cc1a6836d0d81815628ace4d70b28836dba1e32fa5553c7403de5bc24db3a54a669333fe53e9b74367a90f539707e94675625a9d7a7254ef4b24f7634717ee3d29b13e0d184e606967c25b150439a38045911691e6f93e73a3dffa3bea20d821"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4880694950L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1242245);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test89"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.9567827717396936d);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test90"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(2502316609L, 3617318266L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test91"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1619796881L, 731);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8680198150961916721L);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test92"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)731, (java.lang.Number)(-0.12466606072946027d), false);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test93"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(short)100);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    java.lang.Number var3 = var1.getMax();
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-57.29577951308232d), (java.lang.Number)0L, true);
    boolean var8 = var7.getBoundIsAllowed();
    var1.addSuppressed((java.lang.Throwable)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (short)100+ "'", var3.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test94"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(4.592255493195391d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.662169647297922d);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test95"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 44.0d, 4.440892098500626E-16d);
    double var5 = var3.probability(0.4208976513809636d);
    double var6 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test96"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.11125059697946546d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test97"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var5 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var7 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    int var12 = var11.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    java.lang.Class var16 = var15.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var17.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = var21.getNanStrategy();
    int var23 = var22.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
    org.apache.commons.math3.stat.ranking.TiesStrategy var25 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25);
    org.apache.commons.math3.stat.ranking.NaNStrategy var27 = var26.getNanStrategy();
    java.lang.Class var28 = var27.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var27);
    org.apache.commons.math3.stat.ranking.TiesStrategy var30 = var29.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22, var30);
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19, var30);
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var30);
    org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var30);
    org.apache.commons.math3.stat.ranking.NaNStrategy var35 = var34.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var36 = var34.getTiesStrategy();
    java.lang.String var37 = var36.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "MAXIMAL"+ "'", var5.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "AVERAGE"+ "'", var37.equals("AVERAGE"));

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test98"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    java.lang.String var8 = var6.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "MAXIMAL"+ "'", var8.equals("MAXIMAL"));

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test99"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     int var8 = var1.nextPascal(2147483647, 0.0d);
//     double var11 = var1.nextUniform(0.3083894584059538d, 4.484958451919815d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextCauchy((-1.7429441502075451d), (-3.2830016497499828d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 100.64560043833633d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.606166257423197d);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test100"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)20931);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test101"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1734790817, 445);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test102"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(16, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4368L);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test103"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.3214591678799613d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.37913869171980213d);

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test104"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     java.lang.String var8 = var1.nextHexString(500);
//     double var10 = var1.nextT(0.9584128699015102d);
//     var1.reSeed();
//     int var14 = var1.nextZipf(65, 0.841037877334904d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var1.nextBinomial(34, 4.65642978350631d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6967798412L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "41fcf6efe9cfd74cb0c56b29f44d4e34cce121a5783b3f7a0c89c1ebfc15665181b36d02eb9d87176cb4d9c6cdd319f023637955c00a37b75a6979a063cf42034e80f257a09a90c0b8b5c891f7df6282de8f53f351e565151c3a675ee5f72a046b02b40cd7bbf0a2ee0dc60c3edc755dc8416de9ed7521fe56661a0da76f0ff0b415967dd3406cb56ba906ec9831499a19e7a34a74e602a9bf0e014302ed7485f82e44ebc5313169888c358df17226cd652c98158d8267aa031e5b7011d9500982e1163ea70d7055285566a018dae89dad77e6dc6cc53ca905fa459e3f25154143ebf37e7fc5b88dd4a6776d2f4f228226f5fdeea988f89c9255"+ "'", var8.equals("41fcf6efe9cfd74cb0c56b29f44d4e34cce121a5783b3f7a0c89c1ebfc15665181b36d02eb9d87176cb4d9c6cdd319f023637955c00a37b75a6979a063cf42034e80f257a09a90c0b8b5c891f7df6282de8f53f351e565151c3a675ee5f72a046b02b40cd7bbf0a2ee0dc60c3edc755dc8416de9ed7521fe56661a0da76f0ff0b415967dd3406cb56ba906ec9831499a19e7a34a74e602a9bf0e014302ed7485f82e44ebc5313169888c358df17226cd652c98158d8267aa031e5b7011d9500982e1163ea70d7055285566a018dae89dad77e6dc6cc53ca905fa459e3f25154143ebf37e7fc5b88dd4a6776d2f4f228226f5fdeea988f89c9255"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.6007837326329871d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 7);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test105"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    boolean var9 = var7.equals((java.lang.Object)10.015471524400919d);
    java.lang.Class var10 = var7.getDeclaringClass();
    java.lang.String var11 = var7.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "RANDOM"+ "'", var11.equals("RANDOM"));

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test106"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.4251878220010183d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1938123060184203d);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test107"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)393769118724723329L, (java.lang.Number)(-0.06991186090907374d), false);
    java.lang.Number var5 = var4.getMax();
    boolean var6 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.06991186090907374d)+ "'", var5.equals((-0.06991186090907374d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test108"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    float var4 = var0.getContractionCriteria();
    float var5 = var0.getContractionCriteria();
    float var6 = var0.getContractionCriteria();
    var0.setElement(211, 0.6664608671166427d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.5f);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test109"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(3729464, 445);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3729464);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test110"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var3 = var2.getNumElements();
    double[] var4 = var2.getInternalValues();
    int var5 = var2.getNumElements();
    double[] var6 = var2.getElements();
    var0.addElements(var6);
    float var8 = var0.getContractionCriteria();
    float var9 = var0.getContractionCriteria();
    float var10 = var0.getExpansionFactor();
    int var11 = var0.start();
    var0.setContractionCriteria(1.2676505E30f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var0.substituteMostRecentElement(0.9000039605473131d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test111"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(112);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test112"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(53, 141);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-663925499));

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test113"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-2.369613507099535d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.440892098500626E-16d);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test114"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(2.151512277359165d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.440892098500626E-16d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test115"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(1.1095904140014485d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 63.57484771045672d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test116"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-1096480911), (java.lang.Number)1.0229403758340696d, var3);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test117"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.8504467169183425d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.016833884757088d);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test118"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.82442736154459d, 0.945481894075095d, 0.11125059697946545d);

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test119"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     int var12 = var1.nextZipf(3, 0.949950589504148d);
//     var1.reSeedSecure();
//     double var16 = var1.nextCauchy(0.0d, 0.5637033385775058d);
//     double var18 = var1.nextT(4.6624508263893025d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var1.nextSecureInt(211, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 99.48989659723676d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 10.702410701649228d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-3.6589212680025756d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.7313948757277289d));
// 
//   }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test120"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var8 = var6.density(100.0d);
//     double var11 = var6.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double[] var13 = var6.sample(100);
//     double var14 = var6.getStandardDeviation();
//     boolean var15 = var6.isSupportUpperBoundInclusive();
//     var6.reseedRandomGenerator(1L);
//     boolean var18 = var6.isSupportUpperBoundInclusive();
//     double var19 = var6.sample();
//     double var21 = var6.cumulativeProbability((-12.575882963917257d));
//     double var22 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.8589827723618979d);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test121"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)5, (java.lang.Number)Double.NEGATIVE_INFINITY, true);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    java.lang.Number var5 = var3.getMin();
    boolean var6 = var3.getBoundIsAllowed();
    boolean var7 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + Double.NEGATIVE_INFINITY+ "'", var5.equals(Double.NEGATIVE_INFINITY));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test122"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.039720900659592454d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.938893903907228E-18d);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test123"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-6275290550L), 22600);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test124"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     int var13 = var1.nextSecureInt(0, 10);
//     int var16 = var1.nextPascal(506, 0.3063909472492726d);
//     var1.reSeed(4448708824L);
//     org.apache.commons.math3.distribution.IntegerDistribution var19 = null;
//     int var20 = var1.nextInversionDeviate(var19);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test125"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(1.2182455594777868d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.19741175773404482d);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test126"); }


    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)32.53142185860535d, (java.lang.Number)(-1.315149049454551d), var2);
    java.lang.Number var4 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test127"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(295);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1386.42043881739d);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test128"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-0.41069097435491886d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.38968862454290176d));

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test129"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 253088211L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 253088211L);

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test130"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
//     java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 9617852649L);
//     java.math.BigInteger var5 = null;
//     java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
//     java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 9617852649L);
//     java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var9);
//     java.math.BigInteger var11 = null;
//     java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, var11);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test131"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.21799941329709718d), (-0.2813585913101566d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test132"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-1.4748514251205134d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test133"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    int var4 = var3.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    java.lang.Class var8 = var7.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var9.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    int var15 = var14.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var18.getNanStrategy();
    java.lang.Class var20 = var19.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19);
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14, var22);
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var22);
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var22);
    java.lang.String var26 = var22.name();
    java.lang.String var27 = var22.name();
    int var28 = var22.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
    java.lang.String var30 = var22.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "AVERAGE"+ "'", var26.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "AVERAGE"+ "'", var27.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "AVERAGE"+ "'", var30.equals("AVERAGE"));

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test134"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(short)100);
    java.lang.Number var2 = var1.getMax();
    java.lang.String var3 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + (short)100+ "'", var2.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (100) exceeded"+ "'", var3.equals("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (100) exceeded"));

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test135"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, (-10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0f));

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test136"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(7.0150167336650044d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.6360809028254333d);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test137"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double var7 = var0.cumulativeProbability(0.6139648708421599d);
    double var8 = var0.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.7303807294278502d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test138"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(507.5757515636374d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.976890346664758d);

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test139"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getMean();
//     double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     boolean var5 = var0.isSupportConnected();
//     double var6 = var0.getNumericalVariance();
//     double var7 = var0.sample();
//     double var8 = var0.getStandardDeviation();
//     double var9 = var0.getSupportUpperBound();
//     double var10 = var0.getSupportUpperBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3.714269324833091d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test140"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getStandardDeviation();
    boolean var9 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator(1L);
    boolean var12 = var0.isSupportLowerBoundInclusive();
    double var13 = var0.getNumericalMean();
    var0.reseedRandomGenerator(4298531835L);
    double var16 = var0.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0090168687688115d);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test141"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    double[] var9 = var8.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var6, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test142"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.2737368E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-42));

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test143"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-2.450405938642638d), 9.185979303078355E-72d);
    double var3 = var2.getMean();
    double var4 = var2.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-2.450405938642638d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 8.438221575658391E-143d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test144"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    int var2 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var4 = var3.getNumElements();
    double[] var5 = var3.getInternalValues();
    int var6 = var3.getNumElements();
    double[] var7 = var3.getElements();
    var0.addElements(var7);
    var0.contract();
    float var10 = var0.getContractionCriteria();
    var0.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.5f);

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test145"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var4 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var4);
//     org.apache.commons.math3.random.RandomGenerator var6 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var6);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var8 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var9 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
//     int var12 = var11.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var14 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var16 = var15.getNanStrategy();
//     java.lang.Class var17 = var16.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var19 = var18.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var19);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var19);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var3, var19);
//     org.apache.commons.math3.distribution.NormalDistribution var23 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var24 = var23.getMean();
//     double var27 = var23.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var28 = var23.getSupportUpperBound();
//     double[] var30 = var23.sample(371);
//     org.apache.commons.math3.random.RandomGenerator var31 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var31);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var33 = var32.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var34 = var32.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var35 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var34, var35);
//     org.apache.commons.math3.util.ResizableDoubleArray var37 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     int var38 = var37.start();
//     double var40 = var37.addElementRolling(4.937302184657956d);
//     int var41 = var37.start();
//     var37.contract();
//     double[] var43 = var37.getInternalValues();
//     double[] var44 = var36.rank(var43);
//     double var45 = var22.mannWhitneyUTest(var30, var43);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var46 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.util.ResizableDoubleArray var47 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     int var48 = var47.getNumElements();
//     double[] var49 = var47.getInternalValues();
//     double[] var52 = new double[] { 10.0d, 100.0d};
//     double var53 = var46.mannWhitneyU(var49, var52);
//     org.apache.commons.math3.util.ResizableDoubleArray var54 = new org.apache.commons.math3.util.ResizableDoubleArray(var49);
//     double var56 = var54.substituteMostRecentElement(2.9690791410915276d);
//     double[] var57 = var54.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var58 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var58.discardFrontElements(0);
//     org.apache.commons.math3.util.ResizableDoubleArray var61 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     double var63 = var61.addElementRolling(Double.NaN);
//     double[] var64 = var61.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var65 = new org.apache.commons.math3.util.ResizableDoubleArray(var64);
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var58, var65);
//     double[] var67 = var58.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var68 = new org.apache.commons.math3.util.ResizableDoubleArray(var67);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var69 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.util.ResizableDoubleArray var70 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     int var71 = var70.getNumElements();
//     double[] var72 = var70.getInternalValues();
//     double[] var75 = new double[] { 10.0d, 100.0d};
//     double var76 = var69.mannWhitneyU(var72, var75);
//     var68.addElements(var75);
//     var68.setContractionCriteria(2.0f);
//     org.apache.commons.math3.util.ResizableDoubleArray var80 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     double var82 = var80.addElementRolling(Double.NaN);
//     double[] var83 = var80.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var84 = new org.apache.commons.math3.util.ResizableDoubleArray(var83);
//     org.apache.commons.math3.util.ResizableDoubleArray var85 = new org.apache.commons.math3.util.ResizableDoubleArray(var83);
//     var68.addElements(var83);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var87 = var22.mannWhitneyU(var57, var83);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
//     } catch (org.apache.commons.math3.exception.NoDataException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 0.9443202050237591d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 32.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == 32.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test146"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(528324911L, 3410095769L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1801638543658401559L);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test147"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.1334305443990387d, (java.lang.Number)3.801410052452705d, false);
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 0.133 is larger than, or equal to, the maximum (3.801)"+ "'", var4.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 0.133 is larger than, or equal to, the maximum (3.801)"));

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test148"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.MathIllegalStateException var3 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var2);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test149"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo((-856701739L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test150"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed();
    double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
    var1.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var1.nextT(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test151"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(210.0d, 0.9984187364052811d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var2.inverseCumulativeProbability((-0.0019750240854171527d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test152"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(1.3925240956605238d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 79.78575355161972d);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test153"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.07847335898632968d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9969225457154951d);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test154"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.random.RandomGenerator var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test155"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var10 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var13 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var16 = var15.getNumElements();
    double[] var17 = var15.getInternalValues();
    double[] var20 = new double[] { 10.0d, 100.0d};
    double var21 = var14.mannWhitneyU(var17, var20);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    double var23 = var10.mannWhitneyU(var13, var17);
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    double var27 = var24.substituteMostRecentElement(0.3742437696541317d);
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var28.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var33 = var31.addElementRolling(Double.NaN);
    double[] var34 = var31.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var35 = new org.apache.commons.math3.util.ResizableDoubleArray(var34);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var28, var35);
    double[] var37 = var28.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray(var37);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var39 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var40 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var41 = var40.getNumElements();
    double[] var42 = var40.getInternalValues();
    double[] var45 = new double[] { 10.0d, 100.0d};
    double var46 = var39.mannWhitneyU(var42, var45);
    var38.addElements(var45);
    var24.addElements(var45);
    var0.addElements(var45);
    org.apache.commons.math3.util.ResizableDoubleArray var50 = new org.apache.commons.math3.util.ResizableDoubleArray(var45);
    org.apache.commons.math3.util.ResizableDoubleArray var51 = var50.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test156"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(20922789888000L, (-10L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-209227898880000L));

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test157"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.0000001f, (-0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0f));

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test158"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.0576550898240642d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.057591290711133565d);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test159"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextPascal(100, 0.0d);
//     double var6 = var0.nextUniform(0.8282847915800521d, 62472.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 59417.14438144365d);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test160"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin((-0.30273833427190305d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.3075645091247644d));

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test161"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.99999994f, 5.960465E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.99999994f);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test162"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(1.907349E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.2737368E-13f);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test163"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.05782461145270825d), (java.lang.Number)(-1L), (java.lang.Number)100.0d);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getArgument();
    java.lang.Number var6 = var3.getHi();
    java.lang.Number var7 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1L)+ "'", var4.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.05782461145270825d)+ "'", var5.equals((-0.05782461145270825d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 100.0d+ "'", var6.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 100.0d+ "'", var7.equals(100.0d));

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test164"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs((-0.0827727942692622d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0827727942692622d);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test165"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc((-0.8887860824270972d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7912222223977756d);

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test166"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     java.lang.String var8 = var1.nextHexString(500);
//     double var10 = var1.nextT(0.9584128699015102d);
//     var1.reSeed();
//     int var14 = var1.nextZipf(65, 0.841037877334904d);
//     int var17 = var1.nextZipf(396, 1.82442736154459d);
//     double var20 = var1.nextGamma(0.8984208211407446d, 0.51071998615462d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5116033641L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "c87852f9b8062973147279b958d327f708be1cc8639c25fd6ca9addde1868438619b2b7be4e5b7a240bd6f8f03a355abd26cb85e96bf4fe30f47f1cd05b20495f1da8e58b7875d67211a5485a0c6d54747a7e53f7714f5cf89f487f30ed508a85443b709c0f3556689b0347def892c76bef6a6b68a78f409213f807bcd50465e674288a104f2f3673104c531d87e7df8d2e259660591e302346bcb8d5888e1b4ac9e8e3f3b709835b5e132e9a7e0a126b805ba709420125720bb5ded13fb798b5361703c8870128c378b18c665e5e079dc1f38ee1d51df4e6c8acb3c281a76ab2a5249c55090688c1d7adb76cffb52735c24d23239d2017f95f3"+ "'", var8.equals("c87852f9b8062973147279b958d327f708be1cc8639c25fd6ca9addde1868438619b2b7be4e5b7a240bd6f8f03a355abd26cb85e96bf4fe30f47f1cd05b20495f1da8e58b7875d67211a5485a0c6d54747a7e53f7714f5cf89f487f30ed508a85443b709c0f3556689b0347def892c76bef6a6b68a78f409213f807bcd50465e674288a104f2f3673104c531d87e7df8d2e259660591e302346bcb8d5888e1b4ac9e8e3f3b709835b5e132e9a7e0a126b805ba709420125720bb5ded13fb798b5361703c8870128c378b18c665e5e079dc1f38ee1d51df4e6c8acb3c281a76ab2a5249c55090688c1d7adb76cffb52735c24d23239d2017f95f3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-91.62775482961813d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.17262681326557652d);
// 
//   }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test167"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-1.1538445424312467d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test168"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(4.6E-44f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test169"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var13 = var1.nextUniform(0.9999943487368532d, 44.5140274520795d);
//     double var15 = var1.nextChiSquare(51.55677237552102d);
//     double var18 = var1.nextGaussian(100.0d, 0.8939360120238292d);
//     org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var21 = var19.density(100.0d);
//     double var24 = var19.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double var25 = var19.getMean();
//     double var26 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var19);
//     java.lang.String var28 = var1.nextHexString(154);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7728114113L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 43.81860364444665d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 60.71036542079565d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 98.89910286447433d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-0.5406803054788528d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "a11281a700b21f39cdc06aab4243fbbd69f51986b3152aa17f90c5db02b2ad5d350b2d6da718fde7f1868c5802732036c8b377d038919658ea5b1507bbc1781faadcf439a71ef889241096042e"+ "'", var28.equals("a11281a700b21f39cdc06aab4243fbbd69f51986b3152aa17f90c5db02b2ad5d350b2d6da718fde7f1868c5802732036c8b377d038919658ea5b1507bbc1781faadcf439a71ef889241096042e"));
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test170"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var3);
    var1.contract();
    int var6 = var1.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test171"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)95.56912115511714d, (java.lang.Number)0.9854805897010366d, (java.lang.Number)341);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test172"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(664646591L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 664646591L);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test173"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var3 = var2.getNumElements();
    double[] var4 = var2.getInternalValues();
    int var5 = var2.getNumElements();
    double[] var6 = var2.getElements();
    var0.addElements(var6);
    float var8 = var0.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setContractionCriteria(5.960465E-8f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.5f);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test174"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    var0.setNumElements(0);
    double var6 = var0.addElementRolling(0.0d);
    int var7 = var0.start();
    int var8 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var10 = var9.getNumElements();
    int var11 = var9.start();
    int var12 = var9.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var9);
    int var14 = var0.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardMostRecentElements(447);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test175"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = new java.lang.Object[] { (-1.6286532113855836d)};
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError(var0, var2);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test176"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-3.06588826647091E-5d), 1.4329174706418153d, 1.0d);
//     boolean var4 = var3.isSupportUpperBoundInclusive();
//     double var5 = var3.sample();
//     double var6 = var3.getMean();
//     double var8 = var3.probability(0.9899600594521918d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.32047652060330933d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-3.06588826647091E-5d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test177"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(2.882619330995207E-19d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.882619330995207E-19d);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test178"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(30.0d, 1.1435499697078755d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.976869420649166E-32d);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test179"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(1.688033050333575d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test180"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-0.017486934199702348d), (java.lang.Number)0.3244779830220503d, false);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test181"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(30.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test182"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(7473772034L, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test183"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    int var3 = var0.getNumElements();
    double[] var4 = var0.getElements();
    var0.setExpansionMode(0);
    var0.discardFrontElements(0);
    var0.contract();
    int var10 = var0.getNumElements();
    float var11 = var0.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = var0.copy();
    float var13 = var0.getExpansionFactor();
    var0.addElement(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.0f);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test184"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.4983331690124966d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.49833316901249664d);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test185"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(3615, 97);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test186"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var3);
    var1.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var1.copy();
    int var7 = var1.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test187"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-42), (-11));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-11));

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test188"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.19741175773404482d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 25.915180959686545d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test189"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.2737368E-13f, (-0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.2737368E-13f);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test190"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0d, 44.93692582882734d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test191"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-0.8887857291489829d), 39.45621475410951d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 39.45621475410951d);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test192"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    int var3 = var0.getNumElements();
    double[] var4 = var0.getElements();
    var0.setExpansionMode(0);
    var0.discardFrontElements(0);
    var0.contract();
    int var10 = var0.getExpansionMode();
    int var11 = var0.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test193"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getMean();
//     double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var7 = var0.cumulativeProbability(4.158638853279167d, 24.0d);
//     double var8 = var0.sample();
//     double var10 = var0.density(2.002865034964586d);
//     double var12 = var0.cumulativeProbability((-6.545752664888063d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.inverseCumulativeProbability((-0.3981578665457376d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.600747998428365E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.3449035767823732d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.05368225884675192d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2.959826828075052E-11d);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test194"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(341, 1242245);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 85119429);

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test195"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     java.lang.String var8 = var1.nextHexString(500);
//     var1.reSeedSecure(8179512108L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 680824567L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "0e7b504c732a0d01b2f1a0ef14a7f128162292fc4f3d13afdb62ad3202f825e922da34b3b38a5401c7975142b1263fba6398d33598166950214f25ec6ab2b7e2fd076ae1470296fc19ed3b46c737f1f9bef8a1efe4313f3619d64e4dced0918cd0c35eb9a38695f37d679cd72bff9aaba3fa2d687c241b526451bb89a0b6c0b8ee1e40aa704587b48a780fa8e8d1d0c17a92e138ca7c662156e352cba705a7f057f7516cfb6416079cf23dae5ebb8be36cf7af4e5a582e9197b32c48ab5c44ea4497df95c151c426cc89fc87ddec8fec75faef5e669322b227ff091c79487c6f0ee5eda6700fa3abd4bf614130c9f47af94cf795a96d6d58cbd7"+ "'", var8.equals("0e7b504c732a0d01b2f1a0ef14a7f128162292fc4f3d13afdb62ad3202f825e922da34b3b38a5401c7975142b1263fba6398d33598166950214f25ec6ab2b7e2fd076ae1470296fc19ed3b46c737f1f9bef8a1efe4313f3619d64e4dced0918cd0c35eb9a38695f37d679cd72bff9aaba3fa2d687c241b526451bb89a0b6c0b8ee1e40aa704587b48a780fa8e8d1d0c17a92e138ca7c662156e352cba705a7f057f7516cfb6416079cf23dae5ebb8be36cf7af4e5a582e9197b32c48ab5c44ea4497df95c151c426cc89fc87ddec8fec75faef5e669322b227ff091c79487c6f0ee5eda6700fa3abd4bf614130c9f47af94cf795a96d6d58cbd7"));
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test196"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var5 = var0.getSupportUpperBound();
    double var7 = var0.probability(Double.NEGATIVE_INFINITY);
    double var9 = var0.probability(Double.POSITIVE_INFINITY);
    boolean var10 = var0.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test197"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.9985619410825101d, (java.lang.Number)29.54554454270477d, true);
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-57.29577951308232d), (java.lang.Number)0L, true);
    boolean var8 = var7.getBoundIsAllowed();
    java.lang.Number var9 = var7.getMin();
    var3.addSuppressed((java.lang.Throwable)var7);
    java.lang.Number var11 = var7.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 0L+ "'", var9.equals(0L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + (-57.29577951308232d)+ "'", var11.equals((-57.29577951308232d)));

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test198"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.9983286229463365d, (java.lang.Number)(-9012226031834035200L), false);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test199"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.4E-45f, (java.lang.Number)5.960465E-8f, false);
    java.lang.Number var4 = var3.getMax();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 5.960465E-8f+ "'", var4.equals(5.960465E-8f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test200"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-2124184289), 0.9999999f, (-1.26765045E30f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test201"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(0.27263296215929816d, (-0.573312907976816d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test202"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int var3 = var0.nextPascal(100, 0.0d);
    var0.reSeedSecure(3520920158L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var0.nextZipf((-273), 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2147483647);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test203"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(85119429, 445);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 85119429);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test204"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(4.440892098500626E-16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.440892098500626E-16d);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test205"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getNumericalMean();
    double var2 = var0.getStandardDeviation();
    boolean var3 = var0.isSupportConnected();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var5 = var0.sample(1073741824);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test206"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(2.9686693898115446d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test207"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)10, (java.lang.Number)3.7621956910836314d, (java.lang.Number)0.7172507104665835d);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    java.lang.Number var5 = var3.getLo();
    java.lang.String var6 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 3.7621956910836314d+ "'", var5.equals(3.7621956910836314d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: 10 out of [3.762, 0.717] range"+ "'", var6.equals("org.apache.commons.math3.exception.OutOfRangeException: 10 out of [3.762, 0.717] range"));

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test208"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     int var13 = var1.nextSecureInt(0, 10);
//     double var15 = var1.nextChiSquare(496.2674961884226d);
//     int var18 = var1.nextSecureInt((-1208213503), (-74));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var22 = var1.nextHypergeometric(825, 1193, 2);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4616352858L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 520.6586668084747d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1020324120));
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test209"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5805372892796278d);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test210"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-3.7625250955428156d), (-6.249905469172342E-4d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.762525147451198d);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test211"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1950148225);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }

  }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test212"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     int var8 = var1.nextInt((-347), 300);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-270));
// 
//   }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test213"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var8 = var1.nextGamma(4.937302184657956d, 97.98819663162894d);
//     var1.reSeed();
//     int var12 = var1.nextInt((-65), 825);
//     var1.reSeedSecure(7172474253L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9999999762786663d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 667.186272506935d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 432);
// 
//   }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test214"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var7 = var1.nextExponential(209.99999999999997d);
//     double var10 = var1.nextGaussian(0.6387763808612118d, 9.999999999999996d);
//     int var13 = var1.nextZipf(3570, 2.3319900186847273d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9999999959931799d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 366.29521740650983d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3.2991516384386546d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test215"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.1054274E-15f);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test216"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.5607966601082315d);
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var5 = var3.density(100.0d);
//     double var8 = var3.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double[] var10 = var3.sample(100);
//     double var11 = var3.getStandardDeviation();
//     double var13 = var3.cumulativeProbability((-0.004920366423301847d));
//     double var14 = var3.getNumericalVariance();
//     double var15 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var3);
//     double var17 = var3.cumulativeProbability(3.4965075614664802d);
//     double var19 = var3.inverseCumulativeProbability(0.0d);
//     boolean var20 = var3.isSupportConnected();
//     double var22 = var3.inverseCumulativeProbability(0.0d);
//     var3.reseedRandomGenerator(3811376747L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5955382931966243d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.4980370657191222d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.18112968119319184d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.9997643044330278d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == Double.NEGATIVE_INFINITY);
// 
//   }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test217"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextSecureHexString(6);
//     org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var5 = var4.getNumericalMean();
//     double var6 = var4.getStandardDeviation();
//     boolean var7 = var4.isSupportLowerBoundInclusive();
//     boolean var8 = var4.isSupportUpperBoundInclusive();
//     double var9 = var4.getStandardDeviation();
//     double var10 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var4);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var11.getMean();
//     double var15 = var11.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var16 = var11.getSupportUpperBound();
//     double var17 = var11.getSupportUpperBound();
//     double var18 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     double var20 = var11.density(5.451930926365849E-198d);
//     double var21 = var11.getSupportUpperBound();
//     var11.reseedRandomGenerator(484905593L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "87d75e"+ "'", var3.equals("87d75e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.9611045319004792d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.8393386770180066d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.3989422804014327d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test218"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("167c14c590365aaf7fb27f8dd66b8c93b4b3c93161da6587af2903170f60e66a1956a05934d995317f89f0618252fdb4cdee7f0d593112d505dd082031727da601a22ebe987866f0aac7ac2c5545ac0ef55cc219222d0a67fd4955c3c5ec23c88955603f0e613e768eac73fab8c56ad9124cf8686b5c7d37747deb29b0d41b27a9bb6488bcf40544a4f0485f1bead3ac327172237ecb5a04711e9d9c0b1e3");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test219"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var5 = var0.getSupportUpperBound();
    double var6 = var0.getNumericalMean();
    double var7 = var0.getSupportUpperBound();
    double var8 = var0.getMean();
    double var9 = var0.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test220"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     int var8 = var1.nextInt((-347), 300);
//     int var11 = var1.nextSecureInt(3570, 2147483647);
//     java.util.Collection var12 = null;
//     java.lang.Object[] var14 = var1.nextSample(var12, 1242245);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test221"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.13035934721721523d, 0.004409706426562607d, 0.0d);
    double var5 = var3.inverseCumulativeProbability(0.2030609190654752d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.126696037953654d);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test222"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-270), 7.1054274E-15f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test223"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(317);
//     double[] var2 = null;
//     var1.addElements(var2);
// 
//   }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test224"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-1.2676504E30f), 323293105);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.NEGATIVE_INFINITY);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test225"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.1657797866605693d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0137729690051962d);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test226"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(4615379780072436307L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4615379780072436307L);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test227"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.6260590822656884E-6d, (java.lang.Number)0.028485400656642273d, (java.lang.Number)(-0.11018662689453802d));
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.11018662689453802d)+ "'", var5.equals((-0.11018662689453802d)));

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test228"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     var1.reSeed(3384732745L);
//     double var13 = var1.nextT(1.257296821133544d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 145);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.49062916172540627d));
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test229"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.9999999984350594d, 1.4601304898599397d);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test230"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    java.lang.Class var4 = var3.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var6 = java.lang.Enum.<java.lang.Enum>valueOf(var4, "fc6d925b01828989e392528be7f0dcac1cc2994e3951a299c98dd5659d5e2bc48f777dee87e82e1ba3edb7e91be607d4905d72674237d4cb2bfdc2b40769e2a34e4cdc5ac85fdec5007306b8aaa36b111032ad64d0820acec1b98c0687d363a95050d8d651600d641a13f3e7d6815b708b11f6f7959a4ab48311648163bf18600c897316651b93d6e84731557e553a96b3384c27569ddfcd7b4d971b51963849790cb016487f112d8510ce72f32f8c61c2bda2e406e84ef5ae998abb3f2ff316a32c1a51e48ff40b3f510090607958cacc13c2fe0d07fe987aacc76dba8ab8227076ae615cf1f283f7735fe7cefe2f4915a0dc938a4e3ab2c390");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test231"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var11 = var9.addElementRolling(Double.NaN);
    double[] var12 = var9.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var6, var13);
    double[] var15 = var6.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    double[] var23 = new double[] { 10.0d, 100.0d};
    double var24 = var17.mannWhitneyU(var20, var23);
    var16.addElements(var23);
    var5.addElements(var23);
    var5.discardFrontElements(0);
    var5.addElement(9.185979303078355E-72d);
    var5.setElement(2, 363.7393755555636d);
    double[] var34 = var5.getElements();
    var5.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test232"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     int var12 = var1.nextZipf(3, 0.949950589504148d);
//     var1.reSeedSecure();
//     double var16 = var1.nextCauchy(0.0d, 0.5637033385775058d);
//     double var18 = var1.nextExponential(1.9117361753569404d);
//     double var20 = var1.nextChiSquare(4.477465921704087d);
//     int var23 = var1.nextSecureInt((-2147483648), (-1079733669));
//     double var25 = var1.nextChiSquare(2.156657827113264d);
//     java.lang.String var27 = var1.nextHexString(211);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 98.72007184269111d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.3481690303135104d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.1781963645485307d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2.4724904578083744d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 2.795220423211973d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-1236642061));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.9195606702171962d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "b0b1477239e9e708a605da95f2641df3e66cc2620a05223e8e4f73b7765dbeac704dcf73f543bdb52b47920c7252cd22204e75e353cabc6ac0eadd9550631ec74fbb819663dad73d6d0574076e6cd262d0af53b5f86c75ee635d23c92e5f9b2803daee6b7af6d4652ab"+ "'", var27.equals("b0b1477239e9e708a605da95f2641df3e66cc2620a05223e8e4f73b7765dbeac704dcf73f543bdb52b47920c7252cd22204e75e353cabc6ac0eadd9550631ec74fbb819663dad73d6d0574076e6cd262d0af53b5f86c75ee635d23c92e5f9b2803daee6b7af6d4652ab"));
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test233"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.0229403758340696d, (java.lang.Number)(byte)100, true);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test234"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.2057908312363932d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test235"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(1.0692644110943252d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9295128479722878d);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test236"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-1.26765045E30f), 5210);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.NEGATIVE_INFINITY);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test237"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(21.406780683582767d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.904139084118434E8d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test238"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    int var8 = var6.ordinal();
    java.lang.String var9 = var6.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "MAXIMAL"+ "'", var9.equals("MAXIMAL"));

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test239"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     double var9 = var1.nextGamma(2.6498507619080125d, (-0.05788914687716099d));
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var10.density(100.0d);
//     double var15 = var10.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double[] var17 = var10.sample(100);
//     double var18 = var10.getStandardDeviation();
//     boolean var19 = var10.isSupportUpperBoundInclusive();
//     var10.reseedRandomGenerator(1L);
//     boolean var22 = var10.isSupportLowerBoundInclusive();
//     double var23 = var10.getMean();
//     double var24 = var10.getSupportUpperBound();
//     double var25 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var28 = var1.nextF(0.0d, 100.99084048753582d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5528796166L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.21195483001350504d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-1.037200314417392d));
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test240"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(6347, 1.907349E-6f, 1.9073489E-6f, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test241"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.4614240535036851d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test242"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(18, 124952017);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-124951999));

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test243"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
//     int var4 = var3.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var6 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
//     java.lang.Class var9 = var8.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var11);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var11);
//     org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var14.discardFrontElements(0);
//     org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     double var19 = var17.addElementRolling(Double.NaN);
//     double[] var20 = var17.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var21);
//     double[] var23 = var14.getElements();
//     double[] var24 = var13.rank(var23);
// 
//   }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test244"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     var1.reSeed();
//     double var10 = var1.nextBeta(31.984371183438952d, 3.141592653589793d);
//     double var13 = var1.nextCauchy(0.9400207386800911d, 1.978735975787224d);
//     int var16 = var1.nextInt((-15), 3);
//     long var18 = var1.nextPoisson(32.53142185860535d);
//     int var21 = var1.nextSecureInt(211, 268848753);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var24 = var1.nextPermutation(7, 60);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9475144400881595d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-24.93925096628316d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-14));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 31L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 30542173);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test245"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-0.05618453265504479d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0d));

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test246"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     var1.reSeed();
//     double var10 = var1.nextBeta(31.984371183438952d, 3.141592653589793d);
//     var1.reSeed();
//     var1.reSeedSecure(0L);
//     double var16 = var1.nextUniform(3.6611311949500056d, 6.09669035850565E63d);
//     org.apache.commons.math3.distribution.IntegerDistribution var17 = null;
//     int var18 = var1.nextInversionDeviate(var17);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test247"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(1.7456204716704575d, 2.3136520775570846d);
    var2.reseedRandomGenerator((-6197319789L));

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test248"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(251, 6269712909L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1438535317));

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test249"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var8 = var1.nextPoisson((-0.004920366423301847d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 98.81131344251864d);
// 
//   }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test250"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-0.5458066324533807d), (java.lang.Number)0.36792469441508013d, true);
//     org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var10 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var8, (java.lang.Number)4.158638853279167d, (java.lang.Object[])var10);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, (java.lang.Object[])var10);
//     org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var6, (java.lang.Object[])var10);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test251"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    int var10 = var9.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    java.lang.String var20 = var17.name();
    java.lang.Class var21 = var17.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var23 = java.lang.Enum.<java.lang.Enum>valueOf(var21, "f9a8c4497b1cfef1d57ec479e83add43832bc64af655e5c3dc26a9038909289597e5b55e1d1af0932c43eeb62c0e8bfbaea4b07e60dfce58b89372355891c98511d43906372f8eb8b21c5617f87a2107abfcb8bbb54d6027903684d252f2d8fead85958a4e7936db5122a18e05a94b666127416733bb413fafbf3979e0cdfa4068491eda5c74f508317f0e7517429d28c85f6937d2a13e6fc919ffa6c2b8d34e3c9085db25decd574b91a7f223119f3aeb51faeeabfd375c5711df221d3b686799b16bd15ad3ab398de154203c4fb49f88d9d5f804e33868bb88fb5e9ee28b58dfe01cf63d6d88ce5d425fe0c9d0191e8e944907050ffeaf68962d77a2");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test252"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.34623503969787806d, 3.705952781032978E29d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test253"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextBinomial(0, 2.0301213984251357E-6d);
//     double var7 = var1.nextF(32.94631867978169d, 38.17833648298513d);
//     var1.reSeedSecure(5863705777L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9916639794524833d);
// 
//   }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test254"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-2.9378153224114745d), (-0.8564026207044273d), 0.949950589504148d, 22600);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test255"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(1070, 371);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 396970);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test256"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var3);
    var1.contract();
    var1.contract();

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test257"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(3.4339872044851463d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test258"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.9073489E-6f, (-1037414828));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test259"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(106.2384465452581d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4210854715202004E-14d);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test260"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.034957368513597445d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test261"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(3118086304L, 7080423162L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10198509466L);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test262"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(32.0d, 1.1580069074881836d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.4241934096691402d));

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test263"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    double[] var17 = new double[] { 10.0d, 100.0d};
    double var18 = var11.mannWhitneyU(var14, var17);
    var10.addElements(var17);
    var10.setContractionCriteria(2.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = var10.copy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var26 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var27 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var29 = var28.getNumElements();
    double[] var30 = var28.getInternalValues();
    double[] var33 = new double[] { 10.0d, 100.0d};
    double var34 = var27.mannWhitneyU(var30, var33);
    org.apache.commons.math3.util.ResizableDoubleArray var35 = new org.apache.commons.math3.util.ResizableDoubleArray(var30);
    double var36 = var23.mannWhitneyU(var26, var30);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var37 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var39 = var38.getNumElements();
    double[] var40 = var38.getInternalValues();
    double[] var43 = new double[] { 10.0d, 100.0d};
    double var44 = var37.mannWhitneyU(var40, var43);
    org.apache.commons.math3.util.ResizableDoubleArray var45 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var46 = var45.getNumElements();
    double[] var47 = var45.getInternalValues();
    double var48 = var23.mannWhitneyUTest(var40, var47);
    var22.addElements(var40);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var22.discardMostRecentElements((-47895));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1.0d);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test264"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var8 = var1.nextGamma(4.937302184657956d, 97.98819663162894d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextWeibull(58.28250505006778d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9997308705772623d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 592.1066015015454d);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test265"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.24956830782110775d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.24698566430016014d);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test266"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(91.16099711112008d, 0.8768053014700384d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test267"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var13 = var1.nextUniform(0.9999943487368532d, 44.5140274520795d);
//     double var15 = var1.nextChiSquare(51.55677237552102d);
//     double var18 = var1.nextGaussian(100.0d, 0.8939360120238292d);
//     org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var21 = var19.density(100.0d);
//     double var24 = var19.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double var25 = var19.getMean();
//     double var26 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var19);
//     double var28 = var19.cumulativeProbability(0.9999999978823586d);
//     var19.reseedRandomGenerator(4298531835L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1054963795L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 19.443825889964938d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 55.56032093099914d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 100.71585735189743d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.058135817850319745d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.8413447455561358d);
// 
//   }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test268"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    java.lang.Class var7 = var6.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = var8.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var8.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
    int var14 = var13.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.NaNStrategy var18 = var17.getNanStrategy();
    java.lang.Class var19 = var18.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var21);
    java.lang.String var25 = var21.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var28 = var27.start();
    double[] var29 = var27.getElements();
    var27.setContractionCriteria(15.999999f);
    var27.setNumElements(506);
    double[] var34 = var27.getInternalValues();
    double[] var35 = var26.rank(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "AVERAGE"+ "'", var25.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test269"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.4980370657191222d, (java.lang.Number)0.2030609190654752d, true);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.4980370657191222d+ "'", var5.equals(0.4980370657191222d));

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test270"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var6 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException(var4, (java.lang.Number)4.158638853279167d, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test271"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(2.0271437797886374d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.862040530131906d);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test272"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.13885830152301762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0024235345553037142d);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test273"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.07046473534579971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test274"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-0.5885470223243282d), 0.9999791546489307d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.5319647404087027d));

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test275"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-0.6480670652339844d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5750151908365533d));

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test276"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getMean();
//     double var2 = var0.getNumericalVariance();
//     double var3 = var0.sample();
//     boolean var4 = var0.isSupportConnected();
//     double var5 = var0.getMean();
//     boolean var6 = var0.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.3718501355904625d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
// 
//   }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test277"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var8 = var1.nextWeibull(0.7853981633974483d, 4.787491742782046d);
//     double var10 = var1.nextExponential(0.3971622936791505d);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var11.getNumericalMean();
//     double var13 = var11.getStandardDeviation();
//     boolean var14 = var11.isSupportLowerBoundInclusive();
//     double var15 = var11.getSupportLowerBound();
//     double var16 = var11.getSupportLowerBound();
//     double var17 = var11.getMean();
//     boolean var18 = var11.isSupportConnected();
//     double var19 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     double var20 = var11.getNumericalVariance();
//     double var21 = var11.getMean();
//     boolean var22 = var11.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.6446685364101326d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.12901877900468453d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-1.3982686708804652d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == true);
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test278"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(2.0f, 1.2676505E30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test279"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     double var12 = var1.nextBeta(98.00138274241472d, 0.9984187364052811d);
//     double var15 = var1.nextUniform(4.61512051684126d, 57.348154628338996d);
//     double var17 = var1.nextExponential(0.9400207386800911d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var1.nextZipf((-74), 0.9783618610526693d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 344);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.9756439162357309d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 42.08568812604232d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.7649396724934314d);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test280"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var14.contract();
    int var16 = var14.getExpansionMode();
    float var17 = var14.getContractionCriteria();
    int var18 = var14.start();
    org.apache.commons.math3.util.ResizableDoubleArray var19 = var14.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test281"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var4 = var0.density(4.937302184657956d);
    double var5 = var0.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0301213984251357E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test282"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var4 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var4);
//     org.apache.commons.math3.random.RandomGenerator var6 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var6);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var8 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var9 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
//     int var12 = var11.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var14 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var16 = var15.getNanStrategy();
//     java.lang.Class var17 = var16.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var19 = var18.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var19);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var19);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var3, var19);
//     org.apache.commons.math3.distribution.NormalDistribution var23 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var24 = var23.getMean();
//     double var27 = var23.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var28 = var23.getSupportUpperBound();
//     double[] var30 = var23.sample(371);
//     org.apache.commons.math3.random.RandomGenerator var31 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var31);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var33 = var32.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var34 = var32.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var35 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var34, var35);
//     org.apache.commons.math3.util.ResizableDoubleArray var37 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     int var38 = var37.start();
//     double var40 = var37.addElementRolling(4.937302184657956d);
//     int var41 = var37.start();
//     var37.contract();
//     double[] var43 = var37.getInternalValues();
//     double[] var44 = var36.rank(var43);
//     double var45 = var22.mannWhitneyUTest(var30, var43);
//     org.apache.commons.math3.util.ResizableDoubleArray var46 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     double var48 = var46.addElementRolling(Double.NaN);
//     double[] var49 = var46.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var50 = new org.apache.commons.math3.util.ResizableDoubleArray(var49);
//     org.apache.commons.math3.util.ResizableDoubleArray var51 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     int var52 = var51.getNumElements();
//     double[] var53 = var51.getInternalValues();
//     int var54 = var51.getNumElements();
//     double[] var55 = var51.getInternalValues();
//     var51.setContractionCriteria(7.5557864E22f);
//     double[] var58 = var51.getElements();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var59 = var22.mannWhitneyU(var49, var58);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
//     } catch (org.apache.commons.math3.exception.NoDataException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 0.9962850091454987d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test283"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("e77ab5");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test284"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var12 = var10.addElementRolling(Double.NaN);
    double[] var13 = var10.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    var0.addElements(var13);
    double var17 = var0.addElementRolling(0.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    int var20 = var18.start();
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var22 = var21.getNumElements();
    double[] var23 = var21.getInternalValues();
    int var24 = var21.getNumElements();
    double[] var25 = var21.getElements();
    var18.addElements(var25);
    var18.contract();
    float var28 = var18.getContractionCriteria();
    var18.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var18);
    org.apache.commons.math3.util.ResizableDoubleArray var32 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var33 = var32.getNumElements();
    double[] var34 = var32.getInternalValues();
    java.lang.Object var35 = null;
    boolean var36 = var32.equals(var35);
    double[] var37 = var32.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test285"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-1023), 0);
//     double var7 = var1.nextGaussian((-0.20637078079078508d), 0.3989422804014327d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var1.nextInt(95455, 6347);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-752));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.14430930556094293d));
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test286"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(1.7874209719136303d, 6.938893903907228E-18d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.7874209719136303d);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test287"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int var3 = var0.nextPascal(100, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var0.nextWeibull(0.0d, 1.6007479984283653E-5d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2147483647);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test288"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.5607966601082315d);
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var5 = var3.density(100.0d);
//     double var8 = var3.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double[] var10 = var3.sample(100);
//     double var11 = var3.getStandardDeviation();
//     double var13 = var3.cumulativeProbability((-0.004920366423301847d));
//     double var14 = var3.getNumericalVariance();
//     double var15 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var3);
//     double var18 = var0.nextCauchy(1.7100683659172744d, 0.8939360120238291d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var0.nextBeta(0.13035934721721523d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.43549382354788835d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.4980370657191222d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.04081705330872224d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.89012438316258d);
// 
//   }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test289"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     int var8 = var1.nextPascal(2147483647, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextBeta((-1.9989769647633786d), (-1.3599284608639345E8d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 100.12527731992795d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2147483647);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test290"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(206, 1704294704);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test291"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.5458066324533806d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5458066324533806d);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test292"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)1.9865549713026993d, (java.lang.Number)2.6060472602392943d);

  }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test293"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-0.5961722400471147d), 15.580488137320039d, 0.0d, (-1079733669));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test294"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var14.contract();
    int var16 = var14.getExpansionMode();
    int var17 = var14.start();
    double[] var18 = var14.getElements();
    int var19 = var14.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test295"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var5 = var0.getMean();
    double var7 = var0.density(0.0d);
    double var9 = var0.density((-0.49797416733317756d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.3989422804014327d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.35242139698553226d);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test296"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var11 = var9.addElementRolling(Double.NaN);
    double[] var12 = var9.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var6, var13);
    double[] var15 = var6.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    double[] var23 = new double[] { 10.0d, 100.0d};
    double var24 = var17.mannWhitneyU(var20, var23);
    var16.addElements(var23);
    var5.addElements(var23);
    var5.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
    org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var32 = var30.addElementRolling(Double.NaN);
    double[] var33 = var30.getElements();
    float var34 = var30.getContractionCriteria();
    float var35 = var30.getContractionCriteria();
    var30.setNumElements(50);
    int var38 = var30.start();
    org.apache.commons.math3.util.ResizableDoubleArray var39 = var30.copy();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var5, var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test297"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.3039372168225922d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.29944216733017387d);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test298"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)31.98437118343895d, (java.lang.Number)10L, false);
    java.lang.String var4 = var3.toString();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    boolean var7 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 31.984 is smaller than, or equal to, the minimum (10)"+ "'", var4.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 31.984 is smaller than, or equal to, the minimum (10)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test299"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(4286580654L, 14066561462L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test300"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(66475);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 671708.5075713872d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test301"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var14.contract();
    int var16 = var14.getExpansionMode();
    int var17 = var14.start();
    double[] var18 = var14.getElements();
    double var20 = var14.addElementRolling(5.65362408791435d);
    var14.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test302"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 100.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test303"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-74), 3570);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-264180));

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test304"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.start();
    double var3 = var0.addElementRolling(4.937302184657956d);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.exception.NotPositiveException var6 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.7212254887267799d);
    boolean var7 = var0.equals((java.lang.Object)var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test305"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var4 = null;
    org.apache.commons.math3.exception.MathArithmeticException var5 = new org.apache.commons.math3.exception.MathArithmeticException(var3, var4);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test306"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(5212001191L, 6012983238L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test307"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.5034011416095043d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5034011416095044d);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test308"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(2.746383006693607E61d, 0.9999991703434066d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948966d);

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test309"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(6.140546228630898d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test310"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial((-347));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test311"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     java.lang.String var8 = var1.nextHexString(500);
//     double var10 = var1.nextT(0.30353390504256844d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var14 = var1.nextLong(1990489697293914943L, (-5876180704L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5956152420L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "bfedd26db4b462c2307a7ff53b923ad6bc6c5eaa4955357b03681910d81b258113fd331f8baedbdfa6767936ced114436b617915bedf7648ff071196b1d8a54073b2db7802e8e067baf64f7bbb1762266b810342ef76fd428244e411f0f5336e453a541ec5b671b22dab7c979a7653259b88b83e27e67fd038e1799f2b78a6ab4e1c5f38cfd85752ba1474a13180b2b6f5a7c4fc63b6253d9cb403b6fb50f0560acbdd91d65012b1e93f7548b0853a61dbb8f0a5d7025f49c82b1da5eee77b9bff8e2f778796c1022b9450d7c5f850fdc9dc81fd0e57461e6d28e51174fb4a37bb6a6bd14bd0204e1b4a7be3d65a2df21a1452715e5ef39706ba"+ "'", var8.equals("bfedd26db4b462c2307a7ff53b923ad6bc6c5eaa4955357b03681910d81b258113fd331f8baedbdfa6767936ced114436b617915bedf7648ff071196b1d8a54073b2db7802e8e067baf64f7bbb1762266b810342ef76fd428244e411f0f5336e453a541ec5b671b22dab7c979a7653259b88b83e27e67fd038e1799f2b78a6ab4e1c5f38cfd85752ba1474a13180b2b6f5a7c4fc63b6253d9cb403b6fb50f0560acbdd91d65012b1e93f7548b0853a61dbb8f0a5d7025f49c82b1da5eee77b9bff8e2f778796c1022b9450d7c5f850fdc9dc81fd0e57461e6d28e51174fb4a37bb6a6bd14bd0204e1b4a7be3d65a2df21a1452715e5ef39706ba"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2.202548247217981d);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test312"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var3 = var0.probability(Double.NaN);
    double var4 = var0.getStandardDeviation();
    double var5 = var0.getNumericalVariance();
    double var6 = var0.getSupportUpperBound();
    double var7 = var0.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test313"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-1208213503), 323293105);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1531506608));

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test314"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)Double.NaN, (java.lang.Number)0.6139648708421599d, true);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var10 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var8, (java.lang.Number)4.158638853279167d, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test315"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    var0.setNumElements(0);
    double var6 = var0.addElementRolling(0.0d);
    int var7 = var0.start();
    int var8 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(500);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var10);
    int var12 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var15 = var14.start();
    double[] var16 = var14.getElements();
    var14.setContractionCriteria(15.999999f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test316"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.4E-45f, 10230);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test317"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(10230, 0.0f, (-2.3841858E-7f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test318"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)99.49811583654233d);

  }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test319"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextPascal(100, 0.0d);
//     long var5 = var0.nextPoisson(31.984371183438952d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 32L);
// 
//   }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test320"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(0.999987895021552d, 15.322095332102348d, false);
//     double var8 = var1.nextGamma(1.4713540043352986d, 4.787491742782046d);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var9.getMean();
//     double var13 = var9.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var14 = var9.getNumericalVariance();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     var1.reSeedSecure((-10L));
//     var1.reSeedSecure();
//     org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var20 = var19.getNumericalMean();
//     double var21 = var19.getStandardDeviation();
//     boolean var22 = var19.isSupportLowerBoundInclusive();
//     double var23 = var19.getSupportLowerBound();
//     double var24 = var19.getSupportLowerBound();
//     double var25 = var19.getMean();
//     boolean var26 = var19.isSupportConnected();
//     double var28 = var19.probability((-0.05388929638978884d));
//     double var29 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var19);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var32 = var1.nextUniform(746.3411950474298d, 63.89811043751645d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 11.879449651193957d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 7.12318207197243d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.4447930793846992d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.032704357125286306d);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test321"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var6 = var0.probability(1.0016685869732043d);
    boolean var7 = var0.isSupportUpperBoundInclusive();
    double var8 = var0.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test322"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-5.2969878277335525d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test323"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-5), (java.lang.Number)1.9865549713026993d, false);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test324"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(3.399216241149525E248d, 0.8998354296541002d);
    double var3 = var2.getMean();
    boolean var4 = var2.isSupportUpperBoundInclusive();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var6 = var2.sample(1073741824);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 3.399216241149525E248d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test325"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     java.lang.String var5 = var1.nextSecureHexString(371);
//     long var8 = var1.nextSecureLong(0L, 8179512108L);
//     int var11 = var1.nextInt((-347), 5306065);
//     double var13 = var1.nextT(0.8412441917850522d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var1.nextHypergeometric((-1037414828), 183, 112);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "08ff9755475abe407b4ef79b7aabeced6872e7383346f72939094c1bde140303523d4ac627ac2af054e7398f38c7117502f4f3064fce9ad47847b0cbdd1610eb4acbec1bdff94e31d49dd74776f8c03423908fb8455c4462d71a66ed318a1eff01ff218dedb4fa241d630da4b7f621c207f8f8d65d146da4b885a5118ca414e091243ccda054ce131ca8bb448c148f0ee2590f67131b89ee45b134e228a1e4b5bd2fdb3b056470aa22ccd2d02bbecb648e0ed0d15c6ccc4f0ce"+ "'", var5.equals("08ff9755475abe407b4ef79b7aabeced6872e7383346f72939094c1bde140303523d4ac627ac2af054e7398f38c7117502f4f3064fce9ad47847b0cbdd1610eb4acbec1bdff94e31d49dd74776f8c03423908fb8455c4462d71a66ed318a1eff01ff218dedb4fa241d630da4b7f621c207f8f8d65d146da4b885a5118ca414e091243ccda054ce131ca8bb448c148f0ee2590f67131b89ee45b134e228a1e4b5bd2fdb3b056470aa22ccd2d02bbecb648e0ed0d15c6ccc4f0ce"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1073670589L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1356255);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.08841446734643423d);
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test326"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed();
    var1.reSeed(0L);
    double var6 = var1.nextT(0.9999999984381234d);
    double var9 = var1.nextGamma(98.75180450337287d, (-0.2492647519380979d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.9584128699015102d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-21.679179376956384d));

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test327"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-1.2676505E30f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 99);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test328"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.09149003776674126d, (java.lang.Number)9.65226919384088d, true);

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test329"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGaussian((-0.8887857291489829d), 1.6260590822656884E-6d);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution((-3.06588826647091E-5d), 1.4329174706418153d, 1.0d);
//     boolean var15 = var14.isSupportUpperBoundInclusive();
//     double var17 = var14.inverseCumulativeProbability(2.7755575615628914E-17d);
//     double var18 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     org.apache.commons.math3.distribution.IntegerDistribution var19 = null;
//     int var20 = var1.nextInversionDeviate(var19);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test330"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(7969628972L, 7005080551L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test331"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     int var13 = var1.nextSecureInt(0, 10);
//     double var15 = var1.nextChiSquare(31.984371183438956d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var1.nextHypergeometric((-22), 0, 10400);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2501521895L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 26.975980617141335d);
// 
//   }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test332"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-12.575882963917257d), 4.615120516841259d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.615120516841259d);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test333"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    int var10 = var9.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    java.lang.Class var21 = var20.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var23 = java.lang.Enum.<java.lang.Enum>valueOf(var21, "16351b");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test334"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     int var1 = var0.getNumElements();
//     double[] var2 = var0.getInternalValues();
//     java.lang.Object var3 = null;
//     boolean var4 = var0.equals(var3);
//     var0.clear();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var0.copy();
//     org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var8 = var7.getMean();
//     double var11 = var7.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     boolean var12 = var7.isSupportConnected();
//     double var13 = var7.getNumericalVariance();
//     double var14 = var7.sample();
//     double var15 = var7.getNumericalVariance();
//     double var16 = var7.getStandardDeviation();
//     boolean var17 = var0.equals((java.lang.Object)var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.6381781975339198d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test335"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1827.7882294099634d, (java.lang.Number)15143.014329719106d, (java.lang.Number)(-0.23069556173552183d));

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test336"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-0.2813585913101566d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9606790970999405d);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test337"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    java.lang.Class var8 = var7.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var14 = var13.getNumElements();
    double[] var15 = var13.getInternalValues();
    double[] var18 = new double[] { 10.0d, 100.0d};
    double var19 = var12.mannWhitneyU(var15, var18);
    double[] var20 = var11.rank(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var22.discardMostRecentElements(16938270);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test338"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3520920169L, 6099185171L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-4038604059170809735L));

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test339"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(5.505380727008027d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test340"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-1605022207), 500);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1605022207));

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test341"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var5 = var0.getSupportUpperBound();
    double var7 = var0.density(29.9749466411613d);
    double var9 = var0.probability((-0.8356529210746998d));
    double var10 = var0.getNumericalMean();
    var0.reseedRandomGenerator(3118086304L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3.123726322776123E-196d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test342"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-57.29577951308232d), (java.lang.Number)0L, true);
    boolean var4 = var3.getBoundIsAllowed();
    boolean var5 = var3.getBoundIsAllowed();
    java.lang.Number var6 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0L+ "'", var6.equals(0L));

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test343"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    double[] var17 = new double[] { 10.0d, 100.0d};
    double var18 = var11.mannWhitneyU(var14, var17);
    var10.addElements(var17);
    var10.setContractionCriteria(2.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var24 = var22.addElementRolling(Double.NaN);
    double[] var25 = var22.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
    var10.addElements(var25);
    double[] var29 = var10.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setExpansionFactor(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test344"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(3645265866L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3645265866L);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test345"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-7.2481055478477545d), (java.lang.Number)2.2924316695611777d, true);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test346"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.001736111111111111d, (java.lang.Number)1.1102230246251565E-16d, (java.lang.Number)0.9133845507670576d);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test347"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(10.567764688902704d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.04870934086184d);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test348"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Throwable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, var5, var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var8);
    org.apache.commons.math3.exception.MaxCountExceededException var13 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.9999999862135353d, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test349"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     var1.reSeed(3384732745L);
//     var1.reSeedSecure(2L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var16 = var1.nextLong(7580693120L, 4748492575L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 21);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test350"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(3.4965075614664802d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.4965075614664807d);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test351"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(85119429, 478);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 85119907);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test352"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(100.63169380526709d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.0d);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test353"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    int var2 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var4 = var3.getNumElements();
    double[] var5 = var3.getInternalValues();
    int var6 = var3.getNumElements();
    double[] var7 = var3.getElements();
    var0.addElements(var7);
    var0.contract();
    float var10 = var0.getExpansionFactor();
    var0.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    int var15 = var14.start();
    var14.addElement(0.0d);
    var14.setElement(394, 100.0d);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test354"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    int var2 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var4 = var3.getNumElements();
    double[] var5 = var3.getInternalValues();
    int var6 = var3.getNumElements();
    double[] var7 = var3.getElements();
    var0.addElements(var7);
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var12);
    float var14 = var12.getContractionCriteria();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var18 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var21 = var20.getNumElements();
    double[] var22 = var20.getInternalValues();
    double[] var25 = new double[] { 10.0d, 100.0d};
    double var26 = var19.mannWhitneyU(var22, var25);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    double var28 = var15.mannWhitneyU(var18, var22);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var32 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var33 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var34 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var35 = var34.getNumElements();
    double[] var36 = var34.getInternalValues();
    double[] var39 = new double[] { 10.0d, 100.0d};
    double var40 = var33.mannWhitneyU(var36, var39);
    org.apache.commons.math3.util.ResizableDoubleArray var41 = new org.apache.commons.math3.util.ResizableDoubleArray(var36);
    double var42 = var29.mannWhitneyU(var32, var36);
    org.apache.commons.math3.util.ResizableDoubleArray var43 = new org.apache.commons.math3.util.ResizableDoubleArray(var32);
    org.apache.commons.math3.util.ResizableDoubleArray var44 = new org.apache.commons.math3.util.ResizableDoubleArray(var43);
    org.apache.commons.math3.util.ResizableDoubleArray var45 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var46 = var45.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var47 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var48 = var47.getNumElements();
    double[] var49 = var47.getInternalValues();
    int var50 = var47.getNumElements();
    double[] var51 = var47.getElements();
    var45.addElements(var51);
    float var53 = var45.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var43, var45);
    org.apache.commons.math3.util.ResizableDoubleArray var55 = new org.apache.commons.math3.util.ResizableDoubleArray(var43);
    double[] var56 = var55.getElements();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var57 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var58 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var59 = var58.getNumElements();
    double[] var60 = var58.getInternalValues();
    double[] var63 = new double[] { 10.0d, 100.0d};
    double var64 = var57.mannWhitneyU(var60, var63);
    double var65 = var15.mannWhitneyUTest(var56, var63);
    var12.addElements(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.6985353583033387d);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test355"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var11 = var9.addElementRolling(Double.NaN);
    double[] var12 = var9.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var6, var13);
    double[] var15 = var6.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    double[] var23 = new double[] { 10.0d, 100.0d};
    double var24 = var17.mannWhitneyU(var20, var23);
    var16.addElements(var23);
    var5.addElements(var23);
    var5.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
    org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var30.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var33 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var35 = var33.addElementRolling(Double.NaN);
    double[] var36 = var33.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var37 = new org.apache.commons.math3.util.ResizableDoubleArray(var36);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var30, var37);
    double[] var39 = var30.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var40 = new org.apache.commons.math3.util.ResizableDoubleArray(var39);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var41 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var42 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var43 = var42.getNumElements();
    double[] var44 = var42.getInternalValues();
    double[] var47 = new double[] { 10.0d, 100.0d};
    double var48 = var41.mannWhitneyU(var44, var47);
    var40.addElements(var47);
    var40.setContractionCriteria(2.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var52 = new org.apache.commons.math3.util.ResizableDoubleArray(var40);
    boolean var53 = var29.equals((java.lang.Object)var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test356"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter((-9.999999f), 29.54554454270477d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-9.999998f));

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test357"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(1.0789362926917403d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.04062569135821548d));

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test358"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     java.lang.String var8 = var1.nextHexString(500);
//     double var10 = var1.nextT(0.9584128699015102d);
//     double var13 = var1.nextGaussian(0.13463348377254322d, 1.257296821133544d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.nextCauchy((-0.7919113044382963d), (-0.08948812915473234d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3673750424L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "427df6cfd886545c12b5991c03c6d40c239c926e2ef5c5a4e9b7ffe91d02a432af64e48f32bbeb14e40390936441cc5ff9315a99150a551f194238ae59b0e1c905766a60e6d36b1941acbe1dded8b7dee54efbc93e68dd74d1609be10b06b69f1e49f7d366dfa197127d6b9349ae87be872d8db5abdb95769d6da24e0407045cc5c4e5bfc76af458e602d6739679e0d61e7c137562dc7c3a13359379e37d1a8ea368c18bf9f10e4cf366d35274d73cd29736f3cbdd884a9aec2cab21c8cbd4530dd197e01a7983be45beebcf2892e0a89a81d62cd359551db997589b3687af1b9e7d315da0adafb62b89423dd4b18cd71c1366473e4e3e966c6c"+ "'", var8.equals("427df6cfd886545c12b5991c03c6d40c239c926e2ef5c5a4e9b7ffe91d02a432af64e48f32bbeb14e40390936441cc5ff9315a99150a551f194238ae59b0e1c905766a60e6d36b1941acbe1dded8b7dee54efbc93e68dd74d1609be10b06b69f1e49f7d366dfa197127d6b9349ae87be872d8db5abdb95769d6da24e0407045cc5c4e5bfc76af458e602d6739679e0d61e7c137562dc7c3a13359379e37d1a8ea368c18bf9f10e4cf366d35274d73cd29736f3cbdd884a9aec2cab21c8cbd4530dd197e01a7983be45beebcf2892e0a89a81d62cd359551db997589b3687af1b9e7d315da0adafb62b89423dd4b18cd71c1366473e4e3e966c6c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.04733092961129962d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.272628662307743d);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test359"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    var0.setNumElements(0);
    var0.contract();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var6 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var10 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    double[] var17 = new double[] { 10.0d, 100.0d};
    double var18 = var11.mannWhitneyU(var14, var17);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    double var20 = var7.mannWhitneyU(var10, var14);
    double[] var24 = new double[] { 100.0d, 1.0d, 100.0d};
    double var25 = var6.mannWhitneyU(var10, var24);
    var0.addElements(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var28);
    int var30 = var28.getNumElements();
    var28.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 3);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test360"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.43514833056151364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 24.932162803338347d);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test361"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var3 = var0.probability(Double.NaN);
    double var4 = var0.getStandardDeviation();
    double var5 = var0.getNumericalVariance();
    double var6 = var0.getSupportUpperBound();
    double var7 = var0.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.NEGATIVE_INFINITY);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test362"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, (-0.9296416727984185d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test363"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 209.99999999999997d, Double.NaN);
    var3.reseedRandomGenerator((-9L));
    double var7 = var3.probability(98.87065559519353d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test364"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(3773985329L, 5116033641L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test365"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(53);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test366"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(106.2384465452581d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.736169505656349d);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test367"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getStandardDeviation();
    boolean var9 = var0.isSupportConnected();
    double var10 = var0.getNumericalMean();
    var0.reseedRandomGenerator(9617852649L);
    double var13 = var0.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0d);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test368"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    int var10 = var9.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var19.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test369"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(6269712909L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6269712909L);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test370"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(9.515414525638859E-200d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.515414525638859E-200d);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test371"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    java.lang.String var6 = var5.name();
    java.lang.String var7 = var5.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "AVERAGE"+ "'", var7.equals("AVERAGE"));

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test372"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3645265866L, 1242245);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test373"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double var6 = var0.getMean();
    double var7 = var0.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test374"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     var1.reSeed();
//     double var10 = var1.nextBeta(31.984371183438952d, 3.141592653589793d);
//     var1.reSeed();
//     double var14 = var1.nextGaussian(2.148147810647578d, 24.0d);
//     var1.reSeed();
//     var1.reSeed(1376175684L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.8847080735320658d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 8.136902553908744d);
// 
//   }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test375"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardMostRecentElements(101794);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test376"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 9617852649L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 9617852649L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var7);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 2147483647);
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)var12, (java.lang.Number)(-0.057760248426621384d), (java.lang.Number)0.6227605565158021d);
    java.lang.Number var16 = var15.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + 0.6227605565158021d+ "'", var16.equals(0.6227605565158021d));

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test377"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)10.042503014966304d, (java.lang.Number)0.9325064796530801d, false);

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test378"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     int var13 = var1.nextSecureInt(0, 10);
//     int var16 = var1.nextPascal(506, 0.3063909472492726d);
//     double var19 = var1.nextCauchy((-62471.37215405415d), 1.2588883301765685d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var21 = var1.nextSecureHexString((-65));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4979617840L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1078);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-62465.34936672366d));
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test379"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.1992748431862724d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1966783137185073d);

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test380"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     double var12 = var1.nextCauchy(0.9997098261638809d, 13.581326273360407d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-3.1284069611015615d));
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test381"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-241), 448);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 207);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test382"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var5 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var7 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var9);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "MAXIMAL"+ "'", var5.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test383"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(100.499985f, 0.23074612792124255d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.49998f);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test384"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.257296821133544d, 1.247735391779353d, 0.0d, (-15));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test385"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)218.40242276255657d);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test386"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(154, (-47515));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test387"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(1.3209627005516584d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7811869909757493d);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test388"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    int var3 = var0.getNumElements();
    double[] var4 = var0.getElements();
    var0.setExpansionMode(0);
    var0.addElement(0.0d);
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    int var12 = var11.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = var15.getNanStrategy();
    java.lang.Class var17 = var16.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.TiesStrategy var19 = var18.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var19);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var23 = var22.getNumElements();
    double[] var24 = var22.getInternalValues();
    double[] var27 = new double[] { 10.0d, 100.0d};
    double var28 = var21.mannWhitneyU(var24, var27);
    double[] var29 = var20.rank(var27);
    var0.addElements(var27);
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var32 = var31.start();
    double var34 = var31.addElementRolling(4.937302184657956d);
    int var35 = var31.start();
    var31.contract();
    double[] var37 = var31.getInternalValues();
    var31.setExpansionMode(0);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var31);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardMostRecentElements((-65));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test389"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     double var9 = var1.nextGamma(2.6498507619080125d, (-0.05788914687716099d));
//     double var12 = var1.nextGamma(0.8221799467477315d, 0.029923905963016993d);
//     int var15 = var1.nextInt((-42), 371);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var1.nextWeibull(0.0d, (-0.20637078079078508d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6663670323L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.1841637849971702d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.02593503712143133d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 316);
// 
//   }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test390"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     double var12 = var1.nextBeta(98.00138274241472d, 0.9984187364052811d);
//     double var15 = var1.nextUniform(4.61512051684126d, 57.348154628338996d);
//     double var17 = var1.nextChiSquare(6.667362175119546d);
//     var1.reSeedSecure(4796346930L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 203);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.9886022016853788d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 5.444070025717757d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 6.663481755343795d);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test391"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(268848753, 89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 89);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test392"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(448, 1.2676505E30f);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test393"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(264, (-1438535317));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1438535053));

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test394"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    int var4 = var0.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var11 = var9.addElementRolling(Double.NaN);
    double[] var12 = var9.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var6, var13);
    double[] var15 = var6.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var17 = var16.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    int var21 = var18.getNumElements();
    double[] var22 = var18.getElements();
    var16.addElements(var22);
    var6.addElements(var22);
    float var25 = var6.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var26.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var31 = var29.addElementRolling(Double.NaN);
    double[] var32 = var29.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var33 = new org.apache.commons.math3.util.ResizableDoubleArray(var32);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var26, var33);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var6, var26);
    var26.discardMostRecentElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var5, var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test395"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("MAXIMAL");
    java.lang.String var2 = var1.toString();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var3);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    boolean var7 = var5.equals((java.lang.Object)(-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test396"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     var1.reSeed(3384732745L);
//     var1.reSeedSecure(2L);
//     double var16 = var1.nextGamma(1663.1795900889629d, 0.0d);
//     long var19 = var1.nextSecureLong(2584899307L, 5863705777L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 2640210079L);
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test397"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-0.9422952790472405d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.980382773925613d));

  }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test398"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     double var8 = var1.nextExponential(44.5140274520795d);
//     int var11 = var1.nextSecureInt((-241), 0);
//     java.util.Collection var12 = null;
//     java.lang.Object[] var14 = var1.nextSample(var12, 365);
// 
//   }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test399"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(1.0097961869598682E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.8069180705335821E17d);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test400"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(byte)(-1), (java.lang.Number)(short)1, true);
    java.lang.Number var4 = var3.getMax();
    boolean var5 = var3.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)1+ "'", var4.equals((short)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test401"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     double var2 = var0.addElementRolling(Double.NaN);
//     var0.setNumElements(0);
//     double var6 = var0.addElementRolling(0.0d);
//     int var7 = var0.start();
//     int var8 = var0.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(500);
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var10);
//     int var12 = var0.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
//     org.apache.commons.math3.random.RandomGenerator var14 = null;
//     org.apache.commons.math3.random.RandomDataImpl var15 = new org.apache.commons.math3.random.RandomDataImpl(var14);
//     var15.reSeedSecure(0L);
//     java.lang.String var19 = var15.nextSecureHexString(371);
//     long var22 = var15.nextSecureLong(0L, 8179512108L);
//     long var25 = var15.nextSecureLong(3520920158L, 4448708814L);
//     java.lang.String var27 = var15.nextSecureHexString(71);
//     boolean var28 = var0.equals((java.lang.Object)71);
//     org.apache.commons.math3.distribution.NormalDistribution var29 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var30 = var29.getSupportLowerBound();
//     boolean var31 = var0.equals((java.lang.Object)var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "b13484ce452652d7c8e952ed70cb3a377332b0c1440fae52b3b2ce9b81f0cbbb7faf55e5e23b45072e5f7b50a1eae9f395425435dee969db341264b4cd95d63542062cc4d0071466936879b4303487a5fdf68d5345898457ac78a68608ee2ce3fbf321db6b6482e0aa73f827c200895048171f2f3036df2f0d9b44d3b44c6c8d6248b86a8e50c79829c84a13ed1499270ceb1c7f362d8c834d50fae5e5369fa0716e685640186ea3eac23f3cf5119c0e5f904ef097b1b1263d8"+ "'", var19.equals("b13484ce452652d7c8e952ed70cb3a377332b0c1440fae52b3b2ce9b81f0cbbb7faf55e5e23b45072e5f7b50a1eae9f395425435dee969db341264b4cd95d63542062cc4d0071466936879b4303487a5fdf68d5345898457ac78a68608ee2ce3fbf321db6b6482e0aa73f827c200895048171f2f3036df2f0d9b44d3b44c6c8d6248b86a8e50c79829c84a13ed1499270ceb1c7f362d8c834d50fae5e5369fa0716e685640186ea3eac23f3cf5119c0e5f904ef097b1b1263d8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 5078045306L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 4350422056L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "6d6fc6e1294588afc278d0acfb12faf96d84c7d626ab759ccb35fddc0db919906780ca8"+ "'", var27.equals("6d6fc6e1294588afc278d0acfb12faf96d84c7d626ab759ccb35fddc0db919906780ca8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test402"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(3.9647305893097186E-24d, 0.022957956056843462d, (-2.369613507099535d));

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test403"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    int var10 = var9.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var19.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var19.getTiesStrategy();
    boolean var24 = var22.equals((java.lang.Object)9.515414525638859E-200d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test404"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(1.9073493E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test405"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5, var6);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var8 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var11 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var14 = var13.getNumElements();
    double[] var15 = var13.getInternalValues();
    double[] var18 = new double[] { 10.0d, 100.0d};
    double var19 = var12.mannWhitneyU(var15, var18);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    double var21 = var8.mannWhitneyU(var11, var15);
    double[] var22 = var7.rank(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test406"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(0.999987895021552d, 15.322095332102348d, false);
//     double var8 = var1.nextGamma(1.4713540043352986d, 4.787491742782046d);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var9.getMean();
//     double var13 = var9.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var14 = var9.getNumericalVariance();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var18 = var1.nextGamma(99.69065826232949d, 2.786677745713106d);
//     double var22 = var1.nextUniform((-0.17393496569430167d), 69.70042867197392d, true);
//     long var25 = var1.nextLong((-10681828717L), (-4448708814L));
//     double var28 = var1.nextGamma(3.123616354820892d, 0.4705756905309871d);
//     var1.reSeedSecure();
//     double var32 = var1.nextF(2.464750698815533d, 1.1580069074881836d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var35 = var1.nextPermutation((-20), 2147483647);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.7251889808015677d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.0955607724906247d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1.111572382334062d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 296.9508046452482d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 12.990248982023193d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-5228057093L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 2.0612839587039176d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1.4116331640852504d);
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test407"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-1.3113177943322367d), 4.584981588187509d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.3113177943322367d));

  }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test408"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)24.0d, (java.lang.Number)0.723245967437971d, (java.lang.Number)825);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test409"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(9617852649L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9617852649L);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test410"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     var1.reSeed((-2502316609L));
//     double var11 = var1.nextGaussian(1.7427271998994087d, 0.8266429039966963d);
//     double var13 = var1.nextChiSquare(0.5552592332346065d);
//     double var17 = var1.nextUniform((-1.2966581127618215d), (-0.21799941329709718d), true);
//     int var20 = var1.nextInt((-7), 95455);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6043492724L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0242563501897255d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.3719042446880644E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.9808173801816362d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 77221);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test411"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-1605022207), 7);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test412"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     double var12 = var1.nextBeta(1.5855819012757701d, 4.0d);
//     long var15 = var1.nextLong(2894332613L, 3659212668L);
//     java.util.Collection var16 = null;
//     java.lang.Object[] var18 = var1.nextSample(var16, 432);
// 
//   }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test413"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(0.999987895021552d, 15.322095332102348d, false);
//     double var8 = var1.nextGamma(1.4713540043352986d, 4.787491742782046d);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var9.getMean();
//     double var13 = var9.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var14 = var9.getNumericalVariance();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var18 = var1.nextGamma(99.69065826232949d, 2.786677745713106d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var22 = var1.nextWeibull(546.6985819846524d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 14.053790191021998d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 5.4736325610664345d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.3526230874217343d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 216.28485062837d);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test414"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.880541304840417d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test415"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)8.881784197001252E-16d);

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test416"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     org.apache.commons.math3.distribution.IntegerDistribution var8 = null;
//     int var9 = var1.nextInversionDeviate(var8);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test417"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-5.011010127267165E-16d));
    java.lang.Throwable[] var3 = var2.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test418"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(3536914764L, 9010206174L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6L);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test419"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var1 = null;
    java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 9617852649L);
    java.math.BigInteger var6 = null;
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 9617852649L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var8);
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 2147483647);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 6949188755L);
    java.lang.Number var16 = null;
    org.apache.commons.math3.exception.OutOfRangeException var18 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)var15, var16, (java.lang.Number)9.332621544395286E157d);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 0L);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 208);
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 183357089);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test420"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var11 = var10.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    int var15 = var12.getNumElements();
    double[] var16 = var12.getElements();
    var10.addElements(var16);
    var0.addElements(var16);
    boolean var20 = var0.equals((java.lang.Object)' ');
    int var21 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    int var25 = var24.start();
    var24.addElement(0.0d);
    var24.clear();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var24);
    org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    int var31 = var24.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test421"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var12 = var10.addElementRolling(Double.NaN);
    double[] var13 = var10.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    var0.addElements(var13);
    double var17 = var0.addElementRolling(0.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    int var20 = var18.start();
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var22 = var21.getNumElements();
    double[] var23 = var21.getInternalValues();
    int var24 = var21.getNumElements();
    double[] var25 = var21.getElements();
    var18.addElements(var25);
    var18.contract();
    float var28 = var18.getContractionCriteria();
    var18.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionFactor((-0.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 2.5f);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test422"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.054048786363947963d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.23248394861570112d);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test423"); }


    java.math.BigInteger var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, (-1605022207));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test424"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(7521675590L, 20922789888000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7521675590L);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test425"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var8.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var10);
    java.lang.Class var12 = var10.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test426"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(51.55677237552102d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.635924796131914d);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test427"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(59417.14438144365d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 59418.0d);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test428"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    int var3 = var0.getNumElements();
    var0.clear();
    double[] var5 = var0.getInternalValues();
    double[] var6 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var8 = var7.getNumElements();
    int var9 = var7.start();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var11 = var10.getNumElements();
    double[] var12 = var10.getInternalValues();
    int var13 = var10.getNumElements();
    double[] var14 = var10.getElements();
    var7.addElements(var14);
    var7.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var7, var19);
    float var21 = var19.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var23 = var22.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var25 = var24.getNumElements();
    double[] var26 = var24.getInternalValues();
    int var27 = var24.getNumElements();
    double[] var28 = var24.getElements();
    var22.addElements(var28);
    int var30 = var22.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var19, var22);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test429"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var3 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var4 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test430"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.4E-45f, (java.lang.Number)5.960465E-8f, false);
    java.lang.Number var4 = var3.getMax();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 5.960465E-8f+ "'", var4.equals(5.960465E-8f));

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test431"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.26159702558174347d, (java.lang.Number)64.23076980428634d, false);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test432"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(short)0);
    boolean var2 = var1.getBoundIsAllowed();
    boolean var3 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test433"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.9901493918730617d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.14047649737585735d);

  }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test434"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     int var12 = var1.nextZipf(3, 0.949950589504148d);
//     var1.reSeedSecure();
//     java.util.Collection var14 = null;
//     java.lang.Object[] var16 = var1.nextSample(var14, (-124951999));
// 
//   }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test435"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(short)100);
    java.lang.Number var4 = var3.getMax();
    java.lang.Number var5 = var3.getMax();
    java.lang.Throwable[] var6 = var3.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)100+ "'", var4.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)100+ "'", var5.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test436"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    var0.contract();
    int var11 = var0.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test437"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(0L, 2894332602L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2894332602L);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test438"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1193);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1193);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test439"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.5607966601082315d);
//     double var5 = var0.nextBeta(1.7912222223977756d, 1.4447332383957143d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextT((-3.1669665405092338d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.46750528559794696d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.023498906757771835d);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test440"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(110, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 111);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test441"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    var0.setNumElements(0);
    var0.contract();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var6 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var10 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    double[] var17 = new double[] { 10.0d, 100.0d};
    double var18 = var11.mannWhitneyU(var14, var17);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    double var20 = var7.mannWhitneyU(var10, var14);
    double[] var24 = new double[] { 100.0d, 1.0d, 100.0d};
    double var25 = var6.mannWhitneyU(var10, var24);
    var0.addElements(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var28);
    int var30 = var28.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var31 = var28.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test442"); }


    float var2 = org.apache.commons.math3.util.FastMath.max((-1.2676505E30f), 9.0071993E15f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.0071993E15f);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test443"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var1 = null;
    java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 9617852649L);
    java.math.BigInteger var6 = null;
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 9617852649L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var8);
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 2147483647);
    org.apache.commons.math3.exception.OutOfRangeException var16 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)var13, (java.lang.Number)(-0.057760248426621384d), (java.lang.Number)0.6227605565158021d);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var17 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-0.057760248426621384d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test444"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-0.5788982422751958d));
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test445"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 9617852649L);
    java.math.BigInteger var8 = null;
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 0L);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 9617852649L);
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, var10);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 2147483647);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 6949188755L);
    java.lang.Number var18 = null;
    org.apache.commons.math3.exception.OutOfRangeException var20 = new org.apache.commons.math3.exception.OutOfRangeException(var2, (java.lang.Number)var17, var18, (java.lang.Number)9.332621544395286E157d);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 0L);
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 208);
    org.apache.commons.math3.exception.NumberIsTooLargeException var26 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.46201216072866136d), (java.lang.Number)208, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test446"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     int var13 = var1.nextSecureInt(0, 10);
//     double var15 = var1.nextChiSquare(496.2674961884226d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var1.nextUniform(0.0d, 0.0d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1881166538L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 488.6071474700637d);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test447"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    int var6 = var2.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test448"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(7550, (-1.9073489E-6f), 1.907349E-6f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test449"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getNumericalMean();
    double var2 = var0.getStandardDeviation();
    boolean var3 = var0.isSupportLowerBoundInclusive();
    boolean var4 = var0.isSupportUpperBoundInclusive();
    double var5 = var0.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);

  }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test450"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     double var9 = var1.nextGamma(2.6498507619080125d, (-0.05788914687716099d));
//     var1.reSeed(4966278053L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7705260298L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.008584252124044662d));
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test451"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.2196240406125857E-104d, 60.71036542079565d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8.507495820722191E-133d);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test452"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-1.26765045E30f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 99);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test453"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    int var2 = var0.start();
    int var3 = var0.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    var4.addElement(1.5690509993150914d);
    var4.contract();
    double[] var8 = var4.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test454"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(141, 101794);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test455"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var12 = var10.addElementRolling(Double.NaN);
    double[] var13 = var10.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    var0.addElements(var13);
    int var16 = var0.getNumElements();
    boolean var18 = var0.equals((java.lang.Object)(-114.59155902616463d));
    float var19 = var0.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.5f);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test456"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    int var3 = var2.start();
    int var4 = var2.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionMode((-264180));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test457"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(5.6843418860808015E-14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.6843418860808015E-14d);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test458"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(2.5242623302161973d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6562044483860003d);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test459"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(15143.014329719106d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test460"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(210.0d, 0.9984187364052811d);
    double var4 = var2.probability(4.898979485566356d);
    boolean var5 = var2.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test461"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-1271720519), 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test462"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(3.6611311949500056d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3829416026206418d);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test463"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(2.09995534605947d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6068688932887051d);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test464"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var8 = var1.nextWeibull(0.7853981633974483d, 4.787491742782046d);
//     double var10 = var1.nextExponential(0.3971622936791505d);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var11.getNumericalMean();
//     double var13 = var11.getStandardDeviation();
//     boolean var14 = var11.isSupportLowerBoundInclusive();
//     double var15 = var11.getSupportLowerBound();
//     double var16 = var11.getSupportLowerBound();
//     double var17 = var11.getMean();
//     boolean var18 = var11.isSupportConnected();
//     double var19 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     double var20 = var11.getNumericalVariance();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var11.cumulativeProbability(98.48709463470924d, 3.682752359367199d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.45922894047812207d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.1871113206952064d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.2802072334992531d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.0d);
// 
//   }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test465"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     double var9 = var1.nextT(1.5855819012757701d);
//     double var12 = var1.nextCauchy(0.001736111111111111d, 0.024588566448858762d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var1.nextSecureLong(0L, (-9617852649L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 4.067466312650193d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.008013801654100905d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.05605194917014823d);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test466"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.536743E-7f);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test467"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var2 = var1.getNumElements();
    double[] var3 = var1.getInternalValues();
    double[] var6 = new double[] { 10.0d, 100.0d};
    double var7 = var0.mannWhitneyU(var3, var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var9 = var8.getNumElements();
    double[] var10 = var8.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test468"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-10681828717L), var1, (java.lang.Number)(-1.1364083366959243d));

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test469"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-0.7950262709952429d), 1.734723475976807E-18d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.734723475976807E-18d);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test470"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var11 = var10.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    int var15 = var12.getNumElements();
    double[] var16 = var12.getElements();
    var10.addElements(var16);
    var0.addElements(var16);
    float var19 = var0.getExpansionFactor();
    var0.clear();
    double[] var21 = var0.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var24 = var22.addElementRolling(Double.NaN);
    double[] var25 = var22.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
    double[] var28 = var27.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var27);
    double[] var30 = var27.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test471"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    double var3 = var1.addElementRolling((-0.05782461145270825d));
    double var5 = var1.addElementRolling(5.129537890492898E-16d);
    var1.setExpansionMode(0);
    int var8 = var1.getNumElements();
    var1.setElement(3615, 0.5805372892796278d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test472"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(2.718279573219539d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.718279573219539d);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test473"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-4685954328653257593L), (-4038604059170809735L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-4685954328653257593L));

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test474"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.29944216733017387d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.955501191303421d);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test475"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.0d, 119.31703692887734d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test476"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     var1.reSeed(3384732745L);
//     var1.reSeedSecure(2L);
//     org.apache.commons.math3.distribution.IntegerDistribution var14 = null;
//     int var15 = var1.nextInversionDeviate(var14);
// 
//   }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test477"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.46232935299896244d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4623293529989625d);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test478"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(99.99999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100);

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test479"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-0.05788914687716099d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test480"); }


    int var1 = org.apache.commons.math3.util.FastMath.round((-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test481"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, var1);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test482"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(6926386580L, 7884487483545238962L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test483"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.5395412382954017d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.18739132644757694d);

  }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test484"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     int var13 = var1.nextSecureInt(0, 10);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getMean();
//     double var16 = var14.getNumericalVariance();
//     double var17 = var14.sample();
//     boolean var18 = var14.isSupportConnected();
//     double var19 = var14.getMean();
//     double var20 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     long var22 = var1.nextPoisson(0.004440128507415322d);
//     double var25 = var1.nextCauchy((-1.7113669808553675d), 16.636486299878868d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3685573673L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.663615071967229d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-1.0378417292962907d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-124.8212095970895d));
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test485"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.9999999862135353d, 100.89867901620401d, 0.9999994195623609d);
    double var4 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.9999999862135353d);

  }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test486"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var8 = var1.nextWeibull(0.7853981633974483d, 4.787491742782046d);
//     double var11 = var1.nextWeibull(1.315149049454551d, 1.3973342048086457d);
//     java.lang.String var13 = var1.nextSecureHexString(3570);
//     double var15 = var1.nextChiSquare(5.320796735198732d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.929273833913227d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.13711011441065468d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "00599908bb73a0886d55617d31f9c9390ccde6a3a938f331b3d20b40cb35f460ab23c666ccfc891654692890435f6e64d5e9e0173ddc7a6523224ad01d089dcf987d21bee736b8bea31ba606938728c0a30f21c5f25b0f742a49e1c11090eecb47f0dced721d4a7a6c77b7e71860b2373bab85c4bf5f737fa5e65800d32e4009f8bc75c6800fd0fbb15f9827bfde6767f46efa62d5ff4a93c9ef1fc3f10e2e2e517106169f8b5c11b66b4a73b7e9afa7a087e0f5872227b06b34c0f170bc981933a4f2da7c71270bf39812f5be28a038c62eb44edbfc1eaabba9d119845b68b43d14db390e567bf5ca39a61ad6bc7a89d5432140314b65e1ae29f974fbc40c462d2abc151ea4092859d91ce7fae27d8740e82f6b55c64d8608fc5b10317fbf4f61468acafed962e530e6ab59503747213b8e93fa6fd88f23100101db381d2c0b4085557e43efcdece22cc6b3131883518073dffc8abdc501e6d5292a1a9996efeb0a655d1ec9cd2614cc5368628bbca8c1391ae467606ef0f0a205917ffc94d84cf4626ca280855a3b3afbfc2f0b4005907110fbb4f79ca693df193c1c26a52c20b1628d66c1418b359af37513705caa6d96353659249bcb97cbd6545c7ecac7f1f62f9425f1e2e368fae519a2a1ec9e73bc843c0e5035fcdddbd2b12ca8787f2a95d07c7d6ea84e5a6e5d4f91cb8861465eca92e891730cee756482d402c16a7298f1764aaefb956a650719d68d581c3477c4236d8382c10abe0db0bf0bcd8efa4b00868bc03997fa7211e7dcb39f2c4085a6c4772123785114fb62ec3193138c5268ccf725ebd004d543cadda42b56361295fb762a3c26c13b7743b2ebfc78be3cf4142eebbba8cf0f87be07d91b089048e415963f038120bd4fc5c8d4c13c8accf21a8f274c912063cb8b76582ebc8e0d71ede4c65a5d68a2d257e59b809ffb3d65897e27e843727d53e27fb6642af915054281ed0389bf2a1f12468759f79ff4f8e6789b3fa089a04242488a7779a399cd7e73b3d244e4fa1c5117018a21d11e541e20afd5d70982bfa9aa002f733cb2fea2dab9d4ef2ccd20a1dfff08d0e27768402846ffe697f343b17bd87cfd799b01bbb2013bf4b9813995a3a77b7b159d11d4dba58e637321ea8933e77cef6bf45c13760f60bcfeec94c3dfb7bcfd10f260556ab758fdc09ab5f23255bc529ace47b85f649cb188fd26216971b15fe911fc31037b4f78ebdab708aa5c9943fd1ca11c04d0e4bc51c8b08201a1f9f13d9935ce4da6f5b7f5b28ae5b294f831f1ca84b27341d3c8433822e2ef2169a5ac4851f6b57075e4a8d94b334e1651ee339516e34ece4170735b7e9f499645f945f571caf77b3adfed5a1332ab32e9bd4b4f88417098d3b138a6157acd0f0165d62363380f3c22af1879fc998ebaa925cde13cbb4946b72c08ee5aa2cf2753778c5810c193f0c28a52259b49faf055788f136850a8c4becf2019a02502e1be6df5098ad7980c29620237371af607d1d535b69b2bdc21862e5a363e9f81fb3050339f7bcd69ed2fbc62bb58f431bccfb45deb563605299eeb883d688ffcd5d1772a0b0cd8ec0f7b18ff0ab11430f1eea8947c659f6809c8d47f6d16ff6163c9f4192a2b45716a7434974467a51570a34bd673aefbcdc4ae3cc3ab394fed739d4a68e2e5f480e2a4a5ab0f912de5321583e0cd87c84225ebbe2d62b25bf8710b80ffa09a403dfe681817387a04bcecf672d017a4cd00c36a6f97f4d181f763dd0ce58b1f6b18b2a7692c0feba72d299fb7315917fe15aa3df939221f7c00c06519332efac0525e8f32e9ec9971e1d258400d6126baafb27b4d2004c17a16b54edc03466356b96324794db63059a630dc6c4770cef0e6b5e64c79a2b8d77685c77732fc6b7b1dcc2074159137b9de68f6090967eb2b8a2214369df213e8e514446717a9647f4898089a824052154a7683d3cfde32f7d5af2598a6a1431f32d16e0f11a304268cc7e39890e5124046085d41d9548b30d76356cb2e9186127b1e5cdef91fed8db982037ae4190f1cc3f8717b646bdde1807727c8370454ff2dc3d2bd2e4a64ac87b59293ddcbde79f8cf6281af55b1ac3ef0166cf1cbb422adbb6bf07f1f19dca44ec6ee5707e116c3d4bd3cf98e98b987ddcc15024508de882004c70a1291dabd613bf545e1d2aa586de208b8bb22014ec893cb2bd4a98ee66e9a9fa99a47b448f321494b0cb531e80b7beecddf917d74432ef17a91241ecea3218e1be667723c125b7aae5f4379fd72fdd70c90e3cfa836b1dcfa1f58c7dbaac3c313880b8b1231133ddaad5933a8920dd316f2e93e3723dd5b0b258fe651311d294c604658318ad960e2bef59f7f376f6d4001d02808b848ee10639220424b81a2657b915156b26cf95d35c46be44ce5ce7ec1fe6a4b6dadd8788174cc71e18d3e52e70fa3303c59cf1c69c6771683d969d7a4ed62546a779894fbea31692361bdca66ef634ff5d436d46bb82e4c182ea7ac37a125f1f85824c7"+ "'", var13.equals("00599908bb73a0886d55617d31f9c9390ccde6a3a938f331b3d20b40cb35f460ab23c666ccfc891654692890435f6e64d5e9e0173ddc7a6523224ad01d089dcf987d21bee736b8bea31ba606938728c0a30f21c5f25b0f742a49e1c11090eecb47f0dced721d4a7a6c77b7e71860b2373bab85c4bf5f737fa5e65800d32e4009f8bc75c6800fd0fbb15f9827bfde6767f46efa62d5ff4a93c9ef1fc3f10e2e2e517106169f8b5c11b66b4a73b7e9afa7a087e0f5872227b06b34c0f170bc981933a4f2da7c71270bf39812f5be28a038c62eb44edbfc1eaabba9d119845b68b43d14db390e567bf5ca39a61ad6bc7a89d5432140314b65e1ae29f974fbc40c462d2abc151ea4092859d91ce7fae27d8740e82f6b55c64d8608fc5b10317fbf4f61468acafed962e530e6ab59503747213b8e93fa6fd88f23100101db381d2c0b4085557e43efcdece22cc6b3131883518073dffc8abdc501e6d5292a1a9996efeb0a655d1ec9cd2614cc5368628bbca8c1391ae467606ef0f0a205917ffc94d84cf4626ca280855a3b3afbfc2f0b4005907110fbb4f79ca693df193c1c26a52c20b1628d66c1418b359af37513705caa6d96353659249bcb97cbd6545c7ecac7f1f62f9425f1e2e368fae519a2a1ec9e73bc843c0e5035fcdddbd2b12ca8787f2a95d07c7d6ea84e5a6e5d4f91cb8861465eca92e891730cee756482d402c16a7298f1764aaefb956a650719d68d581c3477c4236d8382c10abe0db0bf0bcd8efa4b00868bc03997fa7211e7dcb39f2c4085a6c4772123785114fb62ec3193138c5268ccf725ebd004d543cadda42b56361295fb762a3c26c13b7743b2ebfc78be3cf4142eebbba8cf0f87be07d91b089048e415963f038120bd4fc5c8d4c13c8accf21a8f274c912063cb8b76582ebc8e0d71ede4c65a5d68a2d257e59b809ffb3d65897e27e843727d53e27fb6642af915054281ed0389bf2a1f12468759f79ff4f8e6789b3fa089a04242488a7779a399cd7e73b3d244e4fa1c5117018a21d11e541e20afd5d70982bfa9aa002f733cb2fea2dab9d4ef2ccd20a1dfff08d0e27768402846ffe697f343b17bd87cfd799b01bbb2013bf4b9813995a3a77b7b159d11d4dba58e637321ea8933e77cef6bf45c13760f60bcfeec94c3dfb7bcfd10f260556ab758fdc09ab5f23255bc529ace47b85f649cb188fd26216971b15fe911fc31037b4f78ebdab708aa5c9943fd1ca11c04d0e4bc51c8b08201a1f9f13d9935ce4da6f5b7f5b28ae5b294f831f1ca84b27341d3c8433822e2ef2169a5ac4851f6b57075e4a8d94b334e1651ee339516e34ece4170735b7e9f499645f945f571caf77b3adfed5a1332ab32e9bd4b4f88417098d3b138a6157acd0f0165d62363380f3c22af1879fc998ebaa925cde13cbb4946b72c08ee5aa2cf2753778c5810c193f0c28a52259b49faf055788f136850a8c4becf2019a02502e1be6df5098ad7980c29620237371af607d1d535b69b2bdc21862e5a363e9f81fb3050339f7bcd69ed2fbc62bb58f431bccfb45deb563605299eeb883d688ffcd5d1772a0b0cd8ec0f7b18ff0ab11430f1eea8947c659f6809c8d47f6d16ff6163c9f4192a2b45716a7434974467a51570a34bd673aefbcdc4ae3cc3ab394fed739d4a68e2e5f480e2a4a5ab0f912de5321583e0cd87c84225ebbe2d62b25bf8710b80ffa09a403dfe681817387a04bcecf672d017a4cd00c36a6f97f4d181f763dd0ce58b1f6b18b2a7692c0feba72d299fb7315917fe15aa3df939221f7c00c06519332efac0525e8f32e9ec9971e1d258400d6126baafb27b4d2004c17a16b54edc03466356b96324794db63059a630dc6c4770cef0e6b5e64c79a2b8d77685c77732fc6b7b1dcc2074159137b9de68f6090967eb2b8a2214369df213e8e514446717a9647f4898089a824052154a7683d3cfde32f7d5af2598a6a1431f32d16e0f11a304268cc7e39890e5124046085d41d9548b30d76356cb2e9186127b1e5cdef91fed8db982037ae4190f1cc3f8717b646bdde1807727c8370454ff2dc3d2bd2e4a64ac87b59293ddcbde79f8cf6281af55b1ac3ef0166cf1cbb422adbb6bf07f1f19dca44ec6ee5707e116c3d4bd3cf98e98b987ddcc15024508de882004c70a1291dabd613bf545e1d2aa586de208b8bb22014ec893cb2bd4a98ee66e9a9fa99a47b448f321494b0cb531e80b7beecddf917d74432ef17a91241ecea3218e1be667723c125b7aae5f4379fd72fdd70c90e3cfa836b1dcfa1f58c7dbaac3c313880b8b1231133ddaad5933a8920dd316f2e93e3723dd5b0b258fe651311d294c604658318ad960e2bef59f7f376f6d4001d02808b848ee10639220424b81a2657b915156b26cf95d35c46be44ce5ce7ec1fe6a4b6dadd8788174cc71e18d3e52e70fa3303c59cf1c69c6771683d969d7a4ed62546a779894fbea31692361bdca66ef634ff5d436d46bb82e4c182ea7ac37a125f1f85824c7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2.6332826831449077d);
// 
//   }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test487"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(1, 1222826114);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1222826114);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test488"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(1.0242563501897255d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7052023986372002d);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test489"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.5690509993150914d, (java.lang.Number)2.4999998f, false);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    java.lang.Number var6 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 2.4999998f+ "'", var6.equals(2.4999998f));

  }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test490"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(22.875984232951474d, (-0.10747463203439028d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test491"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    int var10 = var9.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.ranking.TiesStrategy var20 = var19.getTiesStrategy();
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var22 = var21.getNumElements();
    int var23 = var21.start();
    int var24 = var21.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var25 = var21.copy();
    var25.addElement(1.5690509993150914d);
    boolean var28 = var20.equals((java.lang.Object)1.5690509993150914d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test492"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(1.0692644110943252d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.01866218454799416d);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test493"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 1376175684L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1376175684L);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test494"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(1.1781963645485307d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.904330650556511d);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test495"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 9617852649L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 9617852649L);
    java.math.BigInteger var10 = null;
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 9617852649L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, var12);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 2147483647);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 6949188755L);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var17);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var21 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)var20);
    org.apache.commons.math3.exception.NumberIsTooSmallException var25 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1.6286532113855836d), (java.lang.Number)(-0.9376760626269405d), false);
    org.apache.commons.math3.exception.MaxCountExceededException var27 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(short)100);
    java.lang.Number var28 = var27.getMax();
    java.lang.Number var29 = var27.getMax();
    java.lang.Number var30 = var27.getMax();
    var25.addSuppressed((java.lang.Throwable)var27);
    var21.addSuppressed((java.lang.Throwable)var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + (short)100+ "'", var28.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + (short)100+ "'", var29.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + (short)100+ "'", var30.equals((short)100));

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test496"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(100.49999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.5f);

  }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test497"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     int var12 = var1.nextZipf(3, 0.949950589504148d);
//     var1.reSeedSecure();
//     double var16 = var1.nextCauchy(0.0d, 0.5637033385775058d);
//     double var18 = var1.nextExponential(1.9117361753569404d);
//     double var20 = var1.nextChiSquare(4.477465921704087d);
//     int var23 = var1.nextSecureInt((-2147483648), (-1079733669));
//     double var25 = var1.nextChiSquare(2.156657827113264d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var28 = var1.nextSecureInt(371, 53);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 99.24227765658478d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.7727007724534811d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-0.21998864638159685d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.7568387638120568d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 4.912567036213848d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-2120531244));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 2.325286571165026d);
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test498"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    java.lang.Class var8 = var7.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var14 = var13.getNumElements();
    double[] var15 = var13.getInternalValues();
    double[] var18 = new double[] { 10.0d, 100.0d};
    double var19 = var12.mannWhitneyU(var15, var18);
    double[] var20 = var11.rank(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    float var22 = var21.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 2.5f);

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test499"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     double var9 = var1.nextT(1.5855819012757701d);
//     double var12 = var1.nextCauchy((-1.8456016649756868d), 4.9E-324d);
//     double var15 = var1.nextGamma((-0.11018662689453802d), 0.7503963846834529d);
//     var1.reSeed(4286580654L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var20 = var1.nextPermutation(154, 293);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.841693191467286d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.2939159761972482d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1.8456016649756868d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.2626566136103083d);
// 
//   }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test500"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.010409007308107676d), 9.904139084118434E8d, 10.042503014966304d, (-1079733723));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

}
