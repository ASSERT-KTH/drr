
import junit.framework.*;

public class RandoopTest2 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test1"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(100L);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
    boolean var19 = org.apache.commons.math3.util.MathArrays.checkOrder(var13, var16, false, true);
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var24);
    double[] var28 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.0d);
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var13, var21);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeDivide(var31, var34);
    double[] var38 = org.apache.commons.math3.util.MathArrays.normalizeArray(var31, 100.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var39 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var13, var31);
    java.lang.Number var43 = null;
    java.lang.Comparable[] var45 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var46 = null;
    boolean var48 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var45, var46, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var49 = new org.apache.commons.math3.exception.NotFiniteNumberException(var43, (java.lang.Object[])var45);
    org.apache.commons.math3.util.MathArrays.OrderDirection var50 = null;
    boolean var52 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var45, var50, true);
    java.lang.Number var53 = null;
    java.lang.Comparable[] var55 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var56 = null;
    boolean var58 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var55, var56, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var59 = new org.apache.commons.math3.exception.NotFiniteNumberException(var53, (java.lang.Object[])var55);
    org.apache.commons.math3.util.MathArrays.OrderDirection var60 = null;
    boolean var62 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var55, var60, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var66 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.3220963206821523d, (java.lang.Number)299.89733044110505d, 8);
    int var67 = var66.getIndex();
    org.apache.commons.math3.exception.util.ExceptionContext var68 = var66.getContext();
    org.apache.commons.math3.util.MathArrays.OrderDirection var69 = var66.getDirection();
    boolean var71 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var55, var69, false);
    boolean var73 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var45, var69, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var75 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)9.927959811989089d, (java.lang.Number)7764.231540750071d, 85, var69, false);
    boolean var78 = org.apache.commons.math3.util.MathArrays.checkOrder(var13, var69, true, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test2"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    double[] var1 = new double[] { };
    double[] var3 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var3);
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var1, var3);
    double[] var7 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var7);
    double var9 = org.apache.commons.math3.util.MathArrays.distance1(var1, var7);
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
    boolean var13 = org.apache.commons.math3.util.MathArrays.checkOrder(var7, var10, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var14 = null;
    boolean var16 = org.apache.commons.math3.util.MathArrays.isMonotonic(var7, var14, false);
    double[] var18 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var18);
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double[] var23 = org.apache.commons.math3.util.MathArrays.ebeDivide(var18, var21);
    double[] var24 = new double[] { };
    double[] var26 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var24, var26);
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double var30 = org.apache.commons.math3.util.MathArrays.safeNorm(var26);
    double[] var31 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var26);
    org.apache.commons.math3.util.MathArrays.OrderDirection var32 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var26, var32, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var35 = null;
    boolean var38 = org.apache.commons.math3.util.MathArrays.checkOrder(var26, var35, true, false);
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeDivide(var7, var26);
    org.apache.commons.math3.util.Pair var42 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var43 = var42.getValue();
    double[] var44 = new double[] { };
    double[] var46 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var46);
    double var48 = org.apache.commons.math3.util.MathArrays.distance1(var44, var46);
    double[] var50 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var50);
    double var52 = org.apache.commons.math3.util.MathArrays.distance1(var44, var50);
    org.apache.commons.math3.util.MathArrays.OrderDirection var53 = null;
    boolean var56 = org.apache.commons.math3.util.MathArrays.checkOrder(var50, var53, false, true);
    double[] var57 = new double[] { };
    double[] var59 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var59);
    double var61 = org.apache.commons.math3.util.MathArrays.distance1(var57, var59);
    double[] var62 = org.apache.commons.math3.util.MathArrays.copyOf(var57);
    double[] var63 = new double[] { };
    double[] var65 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var65);
    double var67 = org.apache.commons.math3.util.MathArrays.distance1(var63, var65);
    double[] var69 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var69);
    double var71 = org.apache.commons.math3.util.MathArrays.distance1(var63, var69);
    org.apache.commons.math3.util.MathArrays.OrderDirection var72 = null;
    boolean var75 = org.apache.commons.math3.util.MathArrays.checkOrder(var69, var72, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var76 = null;
    boolean var78 = org.apache.commons.math3.util.MathArrays.isMonotonic(var69, var76, false);
    double[] var79 = new double[] { };
    double[] var81 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var81);
    double var83 = org.apache.commons.math3.util.MathArrays.distance1(var79, var81);
    double[] var85 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var85);
    double var87 = org.apache.commons.math3.util.MathArrays.distance1(var79, var85);
    double var88 = org.apache.commons.math3.util.MathArrays.safeNorm(var85);
    double[] var89 = org.apache.commons.math3.util.MathArrays.ebeDivide(var69, var85);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var62, var89);
    double[] var91 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var50, var89);
    boolean var92 = var42.equals((java.lang.Object)var50);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var93 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var39, var50);
    double var94 = var93.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + 1L+ "'", var43.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 0.0d);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test3"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-5948939577378167L));
    double var2 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.5587000669406428d));

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test4"); }


    float[] var0 = null;
    float[] var1 = new float[] { };
    boolean var2 = org.apache.commons.math3.util.MathArrays.equals(var0, var1);
    float[] var3 = null;
    float[] var4 = new float[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equals(var3, var4);
    float[] var8 = new float[] { 0.0f, (-1.0f)};
    float[] var9 = null;
    boolean var10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var9);
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var3, var8);
    float[] var12 = null;
    float[] var13 = new float[] { };
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var12, var13);
    boolean var15 = org.apache.commons.math3.util.MathArrays.equals(var8, var13);
    float[] var16 = null;
    float[] var17 = new float[] { };
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var16, var17);
    float[] var21 = new float[] { 0.0f, (-1.0f)};
    float[] var22 = null;
    boolean var23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var21, var22);
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var16, var21);
    float[] var25 = null;
    float[] var26 = new float[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var25, var26);
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var21, var26);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var8, var21);
    boolean var30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var1, var21);
    float[] var31 = new float[] { };
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var1, var31);
    float[] var33 = null;
    float[] var34 = new float[] { };
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var33, var34);
    float[] var38 = new float[] { 0.0f, (-1.0f)};
    float[] var39 = null;
    boolean var40 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var38, var39);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var33, var38);
    float[] var42 = null;
    float[] var43 = new float[] { };
    boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var42, var43);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var38, var43);
    float[] var46 = null;
    float[] var47 = new float[] { };
    boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var46, var47);
    float[] var51 = new float[] { 0.0f, (-1.0f)};
    float[] var52 = null;
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var52);
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var46, var51);
    float[] var55 = null;
    float[] var56 = new float[] { };
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var55, var56);
    boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var51, var56);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var38, var51);
    float[] var62 = new float[] { 0.0f, (-1.0f)};
    float[] var63 = null;
    boolean var64 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var62, var63);
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var51, var63);
    boolean var66 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var1, var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test5"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var3 = var1.nextPoisson(4.591420583449242d);
//     int var6 = var1.nextSecureInt((-1128991284), 4);
//     int var10 = var1.nextHypergeometric(819462356, 7, 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-538061442));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test6"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var3 = var2.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1L+ "'", var3.equals(1L));

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test7"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { false};
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, var4);
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test8"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(98.45317552126936d);
//     double var5 = var0.nextGaussian(0.0d, 92.58889101274673d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.2509236749649339d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 88.42902005251072d);
// 
//   }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test9"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var10 = var1.nextWeibull(0.9846580496679653d, 0.7157990521557022d);
//     java.lang.String var12 = var1.nextSecureHexString(4);
//     int var15 = var1.nextSecureInt(10, 100);
//     int var18 = var1.nextSecureInt(0, 7);
//     int var21 = var1.nextInt(827167750, 1205512795);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.46125744028872d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 109.48015334475656d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.08711120071396827d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "c862"+ "'", var12.equals("c862"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 941109788);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test10"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var2, var5, false);
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double[] var12 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var12);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeDivide(var9, var12);
    double[] var16 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, 1.0159264522107176d);
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeAdd(var2, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test11"); }


    int[] var1 = new int[] { 100};
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 6);
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test12"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var3 = new double[] { };
    double[] var5 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var5);
    double var7 = org.apache.commons.math3.util.MathArrays.distance1(var3, var5);
    double[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    double[] var10 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var10);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double[] var15 = org.apache.commons.math3.util.MathArrays.ebeDivide(var10, var13);
    org.apache.commons.math3.util.MathArrays.checkOrder(var15);
    double var17 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var15);
    org.apache.commons.math3.util.MathArrays.OrderDirection var18 = null;
    double[] var19 = new double[] { };
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double var23 = org.apache.commons.math3.util.MathArrays.distance1(var19, var21);
    double[] var25 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var19, var25);
    org.apache.commons.math3.util.MathArrays.OrderDirection var28 = null;
    double[] var30 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var30);
    double[] var33 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var33);
    double[] var35 = org.apache.commons.math3.util.MathArrays.ebeDivide(var30, var33);
    double[][] var36 = new double[][] { var33};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var25, var28, var36);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var3, var18, var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    double[] var41 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var41);
    double[] var44 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var44);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeDivide(var41, var44);
    double[] var48 = org.apache.commons.math3.util.MathArrays.normalizeArray(var41, 100.0d);
    org.apache.commons.math3.util.MathArrays.OrderDirection var49 = null;
    boolean var52 = org.apache.commons.math3.util.MathArrays.checkOrder(var48, var49, false, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var48);
    double var54 = org.apache.commons.math3.util.MathArrays.distance1(var39, var48);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var55 = org.apache.commons.math3.util.MathArrays.linearCombination(var1, var48);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test13"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.density(1.2316468095843844d);
    double var22 = var16.getNumericalVariance();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var24 = var16.inverseCumulativeProbability(52.09232603127015d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test14"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0737206121073526d, (java.lang.Number)104.91028148840213d, 0);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var10 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.819217204815299d, (java.lang.Number)0.5104454862955553d, 3, var8, true);
    int var11 = var10.getIndex();
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    long[] var17 = new long[] { 0L, 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var17);
    long[][] var19 = new long[][] { var17};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var19);
    org.apache.commons.math3.exception.NotFiniteNumberException var21 = new org.apache.commons.math3.exception.NotFiniteNumberException(var13, (java.lang.Number)98.42888798257793d, (java.lang.Object[])var19);
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var10, var12, (java.lang.Object[])var19);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var19);
    org.apache.commons.math3.exception.MathIllegalStateException var24 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var19);
    org.apache.commons.math3.exception.util.ExceptionContext var25 = var24.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test15"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    float[] var7 = new float[] { 0.0f, (-1.0f)};
    float[] var8 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var8);
    java.lang.Object[] var10 = new java.lang.Object[] { var8};
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var4, var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)(byte)10, var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(short)10, var10);
    double[] var15 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var15);
    double[] var18 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var18);
    double[] var20 = org.apache.commons.math3.util.MathArrays.ebeDivide(var15, var18);
    double[] var21 = new double[] { };
    double[] var23 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var23);
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var21, var23);
    org.apache.commons.math3.util.MathArrays.OrderDirection var26 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var23, var26, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var23);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var30 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var23);
    double var32 = var30.density(99.02988657003175d);
    boolean var33 = var30.isSupportUpperBoundInclusive();
    boolean var34 = var30.isSupportConnected();
    org.apache.commons.math3.util.Pair var35 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)10, (java.lang.Object)var30);
    boolean var36 = var30.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test16"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.probability(0.3055322893119356d);
    double var22 = var16.getSupportLowerBound();
    double var23 = var16.getNumericalVariance();
    double var24 = var16.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0d);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test17"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
    double[] var7 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var7);
    double[] var10 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var10);
    double[] var12 = org.apache.commons.math3.util.MathArrays.ebeDivide(var7, var10);
    org.apache.commons.math3.util.MathArrays.checkOrder(var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var12);
    double[] var15 = new double[] { };
    double[] var17 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var17);
    double var19 = org.apache.commons.math3.util.MathArrays.distance1(var15, var17);
    org.apache.commons.math3.util.MathArrays.checkPositive(var17);
    double var21 = org.apache.commons.math3.util.MathArrays.safeNorm(var17);
    double[] var22 = new double[] { };
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var22, var24);
    double[] var28 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var22, var28);
    double var31 = org.apache.commons.math3.util.MathArrays.safeNorm(var28);
    double[] var32 = new double[] { };
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var32, var34);
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var38 = org.apache.commons.math3.util.MathArrays.safeNorm(var34);
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var28, var34);
    boolean var40 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var34);
    org.apache.commons.math3.util.MathArrays.OrderDirection var41 = null;
    boolean var44 = org.apache.commons.math3.util.MathArrays.checkOrder(var17, var41, true, true);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var17);
    double[] var46 = new double[] { };
    double[] var48 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var48);
    double var50 = org.apache.commons.math3.util.MathArrays.distance1(var46, var48);
    double[] var52 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var52);
    double var54 = org.apache.commons.math3.util.MathArrays.distance1(var46, var52);
    org.apache.commons.math3.util.MathArrays.OrderDirection var55 = null;
    boolean var58 = org.apache.commons.math3.util.MathArrays.checkOrder(var52, var55, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var59 = null;
    boolean var61 = org.apache.commons.math3.util.MathArrays.isMonotonic(var52, var59, false);
    double[] var63 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var63);
    double[] var66 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var66);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var63, var66);
    double[] var69 = new double[] { };
    double[] var71 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance1(var69, var71);
    org.apache.commons.math3.util.MathArrays.checkPositive(var71);
    double var75 = org.apache.commons.math3.util.MathArrays.safeNorm(var71);
    double[] var76 = org.apache.commons.math3.util.MathArrays.ebeAdd(var63, var71);
    org.apache.commons.math3.util.MathArrays.OrderDirection var77 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var71, var77, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var80 = null;
    boolean var83 = org.apache.commons.math3.util.MathArrays.checkOrder(var71, var80, true, false);
    double[] var84 = org.apache.commons.math3.util.MathArrays.ebeDivide(var52, var71);
    double[] var85 = org.apache.commons.math3.util.MathArrays.ebeDivide(var17, var52);
    double var86 = org.apache.commons.math3.util.MathArrays.safeNorm(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 100.0d);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test18"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    long var4 = var2.nextLong();
    double var5 = var2.nextGaussian();
    double var6 = var2.nextGaussian();
    var2.setSeed(43059505226525080L);
    boolean var9 = var2.nextBoolean();
    int var10 = var2.nextInt();
    org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var13 = var11.nextPoisson(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.7157990521557022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-0.6984489763881883d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1736698663);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test19"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.cumulativeProbability(1.0646160893106429d);
    double var23 = var16.cumulativeProbability(104.91028148840213d);
    double var24 = var16.getNumericalVariance();
    double var25 = var16.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test20"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     double var8 = var1.nextUniform(1.0d, 1.2388070620041405d, false);
//     double var11 = var1.nextCauchy(0.5104454862955553d, 97.97864407980379d);
//     var1.reSeedSecure();
//     int var15 = var1.nextInt(28, 1543116286);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.99947034241454d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0480548577295459d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-5.78210535028188d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1420158228);
// 
//   }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test21"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(98.45317552126936d);
//     double var4 = var0.nextT(742.6248114744293d);
//     var0.reSeedSecure(43059505226525080L);
//     int var9 = var0.nextSecureInt(1, 85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.4161659661288477d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.44847309462488943d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 18);
// 
//   }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test22"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 1042);
// 
//   }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test23"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     java.lang.String var6 = var1.nextHexString(10);
//     double var9 = var1.nextUniform(2.1202883854072287d, 444.0293055330172d);
//     double var12 = var1.nextUniform(0.7090371711746789d, 276.2030684411809d);
//     java.lang.String var14 = var1.nextSecureHexString(28);
//     long var17 = var1.nextSecureLong(11555020432364844L, 4286978429002110849L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "f86e10eead"+ "'", var6.equals("f86e10eead"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 328.9490202460588d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 103.40095541555985d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "30a955b98310afd02c2b168ca1bd"+ "'", var14.equals("30a955b98310afd02c2b168ca1bd"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2509696443449701376L);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test24"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var17 = var16.getSupportUpperBound();
    boolean var18 = var16.isSupportLowerBoundInclusive();
    double var20 = var16.cumulativeProbability(1.0646160893106429d);
    var16.reseedRandomGenerator(10L);
    double var23 = var16.getNumericalVariance();
    double var24 = var16.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test25"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     long[] var3 = new long[] { 0L, 10L};
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
//     long[][] var5 = new long[][] { var3};
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
//     org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var7);
// 
//   }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test26"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     int var12 = var0.nextZipf(6, 321.6792596437714d);
//     double[] var14 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var14);
//     double[] var17 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var17);
//     double[] var19 = org.apache.commons.math3.util.MathArrays.ebeDivide(var14, var17);
//     double[] var20 = new double[] { };
//     double[] var22 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var22);
//     double var24 = org.apache.commons.math3.util.MathArrays.distance1(var20, var22);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var25 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var22, var25, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var22);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var19, var22);
//     double[] var31 = var29.sample(9);
//     double var32 = var29.getSupportLowerBound();
//     double var34 = var29.cumulativeProbability(1.0646160893106429d);
//     double var36 = var29.cumulativeProbability(104.91028148840213d);
//     double[] var38 = var29.sample(7);
//     double var39 = var29.getSupportUpperBound();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var40 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-60.3374195693591d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.98176471342229d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1.0d);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test27"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var6, false);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    java.lang.Number var12 = null;
    java.lang.Comparable[] var14 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    boolean var17 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var14, var15, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException(var12, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var19 = new org.apache.commons.math3.exception.NotFiniteNumberException(var10, (java.lang.Number)1010.0d, (java.lang.Object[])var14);
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
    boolean var22 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var14, var20, false);
    org.apache.commons.math3.util.Pair var24 = new org.apache.commons.math3.util.Pair((java.lang.Object)var14, (java.lang.Object)183.2309326428994d);
    java.lang.Comparable[] var26 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var27 = null;
    boolean var29 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var26, var27, true);
    java.lang.Number var30 = null;
    java.lang.Comparable[] var32 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var33 = null;
    boolean var35 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var32, var33, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var36 = new org.apache.commons.math3.exception.NotFiniteNumberException(var30, (java.lang.Object[])var32);
    org.apache.commons.math3.util.MathArrays.OrderDirection var37 = null;
    boolean var39 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var32, var37, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var43 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.3220963206821523d, (java.lang.Number)299.89733044110505d, 8);
    int var44 = var43.getIndex();
    org.apache.commons.math3.exception.util.ExceptionContext var45 = var43.getContext();
    org.apache.commons.math3.util.MathArrays.OrderDirection var46 = var43.getDirection();
    boolean var48 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var32, var46, false);
    boolean var50 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var26, var46, false);
    boolean var52 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var14, var46, false);
    boolean var54 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var46, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test28"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(100L);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
    boolean var19 = org.apache.commons.math3.util.MathArrays.checkOrder(var13, var16, false, true);
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var24);
    double[] var28 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.0d);
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var13, var21);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeDivide(var31, var34);
    double[] var38 = org.apache.commons.math3.util.MathArrays.normalizeArray(var31, 100.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var39 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var13, var31);
    org.apache.commons.math3.random.RandomDataImpl var40 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    java.lang.String var42 = var40.nextHexString(7);
    var40.reSeed();
    var40.reSeed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + "150543b"+ "'", var42.equals("150543b"));

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test29"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.checkOrder(var6, var9, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    boolean var15 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var13, false);
    double[] var16 = new double[] { };
    double[] var18 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var18);
    double var20 = org.apache.commons.math3.util.MathArrays.distance1(var16, var18);
    double[] var22 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var16, var22);
    double var25 = org.apache.commons.math3.util.MathArrays.safeNorm(var22);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var6, var22);
    double[] var27 = new double[] { };
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var27, var29);
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double var33 = org.apache.commons.math3.util.MathArrays.safeNorm(var29);
    double[] var34 = new double[] { };
    double[] var36 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var36);
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var34, var36);
    double[] var40 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var40);
    double var42 = org.apache.commons.math3.util.MathArrays.distance1(var34, var40);
    double var43 = org.apache.commons.math3.util.MathArrays.safeNorm(var40);
    double[] var44 = new double[] { };
    double[] var46 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var46);
    double var48 = org.apache.commons.math3.util.MathArrays.distance1(var44, var46);
    org.apache.commons.math3.util.MathArrays.checkPositive(var46);
    double var50 = org.apache.commons.math3.util.MathArrays.safeNorm(var46);
    double[] var51 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var40, var46);
    boolean var52 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var29, var46);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var53 = org.apache.commons.math3.util.MathArrays.linearCombination(var6, var46);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test30"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(54.23317161276515d, 0.0d, (-21.491089289801923d), (-0.2509236749649339d), 206.49499921415622d, 0.0d, 98.4533634845985d, 210.05782215493787d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 20686.29174050684d);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test31"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 7, 0);
    int var4 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test32"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     double var4 = var2.nextDouble();
//     var2.setSeed((-1));
//     var2.setSeed(0L);
//     long var9 = var2.nextLong();
//     var2.setSeed(10);
//     var2.clear();
//     org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
//     double var16 = var13.nextUniform(98.42888798257793d, 15938.704455172932d);
//     int var19 = var13.nextSecureInt((-1128991284), 9);
//     long var22 = var13.nextLong(24293682399481844L, 152600911433040288L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var25 = var13.nextLong(87064382195180672L, 95L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.01408195728001127d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-4736355256857903122L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 12168.048178086838d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-232844914));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 111759704996197392L);
// 
//   }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test33"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
//     long var4 = var3.nextLong();
//     org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
//     double var8 = var5.nextUniform(0.7090371711746789d, 3887.603878597613d);
//     long var11 = var5.nextSecureLong(100L, 152600911433040288L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var14 = var5.nextPermutation(0, (-549596712));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-414028722650554365L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 606.9017688960619d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 128365358694441744L);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test34"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var3 = var2.getValue();
    java.lang.Object var4 = null;
    boolean var5 = var2.equals(var4);
    java.lang.Object var6 = var2.getValue();
    java.lang.Object var7 = var2.getKey();
    org.apache.commons.math3.util.Pair var8 = new org.apache.commons.math3.util.Pair(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1L+ "'", var3.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1L+ "'", var6.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1L)+ "'", var7.equals((-1L)));

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test35"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("282ea33f98", "d447a2431");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "9ab108f6e"+ "'", var2.equals("9ab108f6e"));
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test36"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1042);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test37"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    long var4 = var2.nextLong();
    double var5 = var2.nextGaussian();
    double var6 = var2.nextGaussian();
    var2.setSeed(43059505226525080L);
    boolean var9 = var2.nextBoolean();
    int var10 = var2.nextInt();
    boolean var11 = var2.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.7157990521557022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-0.6984489763881883d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1736698663);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test38"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextInt((-1), 8);
//     int var10 = var0.nextInt((-1), 6);
//     double var12 = var0.nextChiSquare(0.2700290390806306d);
//     double var15 = var0.nextCauchy(98.34128277750061d, 106.0271272985156d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var18 = var0.nextPoisson((-0.02982135518297794d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 212.66577252429707d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.755303685273256E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 34.369127017942134d);
// 
//   }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test39"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     double var9 = var1.nextF(98.34128277750061d, 98.42176142483318d);
//     double var11 = var1.nextChiSquare(1.0847091605564438d);
//     double var13 = var1.nextT(98.46619727159656d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var15 = var1.nextSecureHexString((-782558606));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 99.30244631960296d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "4"+ "'", var6.equals("4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.3710012855871099d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.4415947495928676d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0434043820330993d);
// 
//   }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test40"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextInt((-1), 8);
//     var0.reSeedSecure(2L);
//     double var12 = var0.nextGaussian(0.2861352605845807d, 65.32875338235677d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextInt(1422716669, 28);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 202.19209763602294d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-16.471981948922824d));
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test41"); }


    java.lang.Number var0 = null;
    java.lang.Number var6 = null;
    java.lang.Comparable[] var8 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var11 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var8, var9, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    boolean var15 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var8, var13, true);
    java.lang.Number var16 = null;
    java.lang.Comparable[] var18 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var19 = null;
    boolean var21 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var18, var19, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var22 = new org.apache.commons.math3.exception.NotFiniteNumberException(var16, (java.lang.Object[])var18);
    org.apache.commons.math3.util.MathArrays.OrderDirection var23 = null;
    boolean var25 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var18, var23, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var29 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.3220963206821523d, (java.lang.Number)299.89733044110505d, 8);
    int var30 = var29.getIndex();
    org.apache.commons.math3.exception.util.ExceptionContext var31 = var29.getContext();
    org.apache.commons.math3.util.MathArrays.OrderDirection var32 = var29.getDirection();
    boolean var34 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var18, var32, false);
    boolean var36 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var8, var32, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var38 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)201.76160301238804d, (java.lang.Number)0.8136598226624859d, 171292551, var32, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var40 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)(-156065838496041088L), (-1), var32, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test42"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var5 = var1.nextUniform(0.0d, 9.927198205545196d, false);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var9 = var1.nextPermutation(244, 11387117);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.732413809163901d);
// 
//   }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test43"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     var1.reSeed(3513799009476651814L);
//     double var8 = var1.nextT(211.5409799176563d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.677605981961825d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.43006573376018903d));
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test44"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
    int[] var5 = new int[] { 100};
    int[] var7 = new int[] { 100};
    int[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
    int var9 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var7);
    int var10 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var7);
    int[] var12 = new int[] { 100};
    int[] var14 = new int[] { 100};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var14);
    int var16 = org.apache.commons.math3.util.MathArrays.distanceInf(var12, var14);
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var14);
    int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var14);
    int[] var20 = new int[] { 100};
    int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var20);
    double var22 = org.apache.commons.math3.util.MathArrays.distance(var14, var20);
    int[] var24 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(var24);
    int var26 = var25.nextInt();
    var25.clear();
    var25.setSeed(100L);
    int[] var31 = new int[] { 100};
    int[] var33 = new int[] { 100};
    int[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var33);
    int var35 = org.apache.commons.math3.util.MathArrays.distanceInf(var31, var33);
    int[] var36 = org.apache.commons.math3.util.MathArrays.copyOf(var33);
    org.apache.commons.math3.random.Well19937c var37 = new org.apache.commons.math3.random.Well19937c(var33);
    int[] var39 = new int[] { 100};
    int[] var40 = org.apache.commons.math3.util.MathArrays.copyOf(var39);
    int var41 = org.apache.commons.math3.util.MathArrays.distanceInf(var33, var39);
    var25.setSeed(var39);
    double var43 = org.apache.commons.math3.util.MathArrays.distance(var14, var39);
    int[] var45 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var46 = new org.apache.commons.math3.random.Well19937c(var45);
    org.apache.commons.math3.random.Well19937c var47 = new org.apache.commons.math3.random.Well19937c(var45);
    int[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45);
    int[] var50 = new int[] { 100};
    int[] var52 = new int[] { 100};
    int[] var53 = org.apache.commons.math3.util.MathArrays.copyOf(var52);
    int var54 = org.apache.commons.math3.util.MathArrays.distanceInf(var50, var52);
    int[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52);
    org.apache.commons.math3.random.Well19937c var56 = new org.apache.commons.math3.random.Well19937c(var52);
    int[] var58 = new int[] { 100};
    int[] var60 = new int[] { 100};
    int[] var61 = org.apache.commons.math3.util.MathArrays.copyOf(var60);
    int var62 = org.apache.commons.math3.util.MathArrays.distanceInf(var58, var60);
    int[] var63 = org.apache.commons.math3.util.MathArrays.copyOf(var60);
    org.apache.commons.math3.random.Well19937c var64 = new org.apache.commons.math3.random.Well19937c(var60);
    int[] var66 = org.apache.commons.math3.util.MathArrays.copyOf(var60, 10);
    int var67 = org.apache.commons.math3.util.MathArrays.distance1(var52, var60);
    int var68 = org.apache.commons.math3.util.MathArrays.distanceInf(var45, var60);
    int[] var70 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 1);
    int var71 = org.apache.commons.math3.util.MathArrays.distance1(var14, var70);
    int var72 = org.apache.commons.math3.util.MathArrays.distance1(var7, var14);
    int[] var74 = new int[] { 100};
    int[] var76 = new int[] { 100};
    int[] var77 = org.apache.commons.math3.util.MathArrays.copyOf(var76);
    int var78 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var76);
    int var79 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test45"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextInt((-1), 8);
//     int var10 = var0.nextInt((-1), 6);
//     org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair((java.lang.Object)var0, (java.lang.Object)606.9017688960619d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextWeibull((-0.3941648194355074d), 0.5850579313613672d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 192.43140104415738d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test46"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)373.2855763258904d, (java.lang.Number)(byte)1);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 373.2855763258904d+ "'", var4.equals(373.2855763258904d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 373.2855763258904d+ "'", var5.equals(373.2855763258904d));

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test47"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    double var4 = var2.nextDouble();
    var2.setSeed((-1));
    var2.setSeed(0L);
    long var9 = var2.nextLong();
    var2.setSeed(10);
    var2.clear();
    org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    double var16 = var13.nextUniform(98.42888798257793d, 15938.704455172932d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var19 = var13.nextPascal(93, (-0.7817577183806416d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.01408195728001127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-4736355256857903122L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 12168.048178086838d);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test48"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(100L);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
    boolean var19 = org.apache.commons.math3.util.MathArrays.checkOrder(var13, var16, false, true);
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var24);
    double[] var28 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.0d);
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var13, var21);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeDivide(var31, var34);
    double[] var38 = org.apache.commons.math3.util.MathArrays.normalizeArray(var31, 100.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var39 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var13, var31);
    org.apache.commons.math3.random.RandomDataImpl var40 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    java.lang.String var42 = var40.nextHexString(7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var45 = var40.nextWeibull(231.88185511644818d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + "150543b"+ "'", var42.equals("150543b"));

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test49"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
//     long var4 = var3.nextLong();
//     float var5 = var3.nextFloat();
//     int var7 = var3.nextInt(171292551);
//     java.util.List var8 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var9 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var3, var8);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test50"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var18 = var16.density(99.02988657003175d);
    boolean var19 = var16.isSupportUpperBoundInclusive();
    double var20 = var16.sample();
    double var21 = var16.sample();
    double var23 = var16.density(1.908642352606886d);
    double var24 = var16.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test51"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(short)10);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test52"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var2, var5, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var2);
    double[] var9 = new double[] { };
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var9, var11);
    org.apache.commons.math3.util.MathArrays.OrderDirection var14 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var11, var14, false);
    boolean var17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var11);
    int[] var19 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var19);
    int var21 = var20.nextInt();
    var20.clear();
    var20.setSeed(100L);
    double[] var25 = new double[] { };
    double[] var27 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var27);
    double var29 = org.apache.commons.math3.util.MathArrays.distance1(var25, var27);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double var33 = org.apache.commons.math3.util.MathArrays.distance1(var25, var31);
    org.apache.commons.math3.util.MathArrays.OrderDirection var34 = null;
    boolean var37 = org.apache.commons.math3.util.MathArrays.checkOrder(var31, var34, false, true);
    double[] var39 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var39);
    double[] var42 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeDivide(var39, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var39, 0.0d);
    double var47 = org.apache.commons.math3.util.MathArrays.distance(var31, var39);
    double[] var49 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var49);
    double[] var52 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var52);
    double[] var54 = org.apache.commons.math3.util.MathArrays.ebeDivide(var49, var52);
    double[] var56 = org.apache.commons.math3.util.MathArrays.normalizeArray(var49, 100.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var57 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var20, var31, var49);
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeDivide(var2, var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test53"); }


    java.lang.Number var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Object[])var2);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var7, true);
    java.lang.Number var10 = null;
    java.lang.Comparable[] var12 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    boolean var15 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var12, var13, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var10, (java.lang.Object[])var12);
    org.apache.commons.math3.util.MathArrays.OrderDirection var17 = null;
    boolean var19 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var12, var17, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var23 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.3220963206821523d, (java.lang.Number)299.89733044110505d, 8);
    int var24 = var23.getIndex();
    org.apache.commons.math3.exception.util.ExceptionContext var25 = var23.getContext();
    org.apache.commons.math3.util.MathArrays.OrderDirection var26 = var23.getDirection();
    boolean var28 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var12, var26, false);
    boolean var30 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var26, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var31 = null;
    boolean var33 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var31, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test54"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
    double[] var7 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var7);
    double[] var10 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var10);
    double[] var12 = org.apache.commons.math3.util.MathArrays.ebeDivide(var7, var10);
    org.apache.commons.math3.util.MathArrays.checkOrder(var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var12);
    double[] var16 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double[] var19 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double[] var21 = org.apache.commons.math3.util.MathArrays.ebeDivide(var16, var19);
    double[] var23 = org.apache.commons.math3.util.MathArrays.normalizeArray(var19, 1.0159264522107176d);
    double[] var25 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var25);
    double[] var28 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeDivide(var25, var28);
    double[] var31 = new double[] { };
    double[] var33 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var33);
    double var35 = org.apache.commons.math3.util.MathArrays.distance1(var31, var33);
    org.apache.commons.math3.util.MathArrays.checkPositive(var33);
    double var37 = org.apache.commons.math3.util.MathArrays.safeNorm(var33);
    double[] var38 = org.apache.commons.math3.util.MathArrays.ebeAdd(var25, var33);
    double[] var40 = org.apache.commons.math3.util.MathArrays.normalizeArray(var38, 0.0d);
    double[] var41 = org.apache.commons.math3.util.MathArrays.copyOf(var40);
    java.lang.Number var42 = null;
    java.lang.Comparable[] var44 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var45 = null;
    boolean var47 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var44, var45, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var48 = new org.apache.commons.math3.exception.NotFiniteNumberException(var42, (java.lang.Object[])var44);
    org.apache.commons.math3.util.MathArrays.OrderDirection var49 = null;
    boolean var51 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var44, var49, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var55 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.3220963206821523d, (java.lang.Number)299.89733044110505d, 8);
    int var56 = var55.getIndex();
    org.apache.commons.math3.exception.util.ExceptionContext var57 = var55.getContext();
    org.apache.commons.math3.util.MathArrays.OrderDirection var58 = var55.getDirection();
    boolean var60 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var44, var58, false);
    boolean var62 = org.apache.commons.math3.util.MathArrays.isMonotonic(var40, var58, false);
    boolean var65 = org.apache.commons.math3.util.MathArrays.checkOrder(var23, var58, false, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var67 = org.apache.commons.math3.util.MathArrays.isMonotonic(var0, var58, false);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test55"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     var0.reSeedSecure((-1L));
//     long var14 = var0.nextLong((-414028722650554365L), 60949576243059920L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("f6d99a5fb8", "org.apache.commons.math3.exception.NotPositiveException: 100 is smaller than the minimum (0)");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 203.3826664075927d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "92cda337ee"+ "'", var9.equals("92cda337ee"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-395828691162893376L));
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test56"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
    long var4 = var3.nextLong();
    long var5 = var3.nextLong();
    var3.clear();
    var3.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-414028722650554365L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2876919108950029338L);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test57"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     double var9 = var1.nextF(98.34128277750061d, 98.42176142483318d);
//     double var12 = var1.nextGaussian(9.927198205545196d, 0.5104454862955553d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextUniform(51.30880113197997d, 2.4464769860739253d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 100.59821178945847d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "a"+ "'", var6.equals("a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.9420055708340451d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 10.741353913363433d);
// 
//   }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test58"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(98.45317552126936d);
//     double var5 = var0.nextGaussian(0.23344772945559902d, 0.9113220391122172d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.5257427083083117d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.969289876825621d);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test59"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.34218225734736135d, (java.lang.Number)13.10342294679575d, 56781672, var3, true);

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test60"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     long var4 = var2.nextLong();
//     double var5 = var2.nextGaussian();
//     double var6 = var2.nextGaussian();
//     var2.setSeed(4286978429002110849L);
//     double var9 = var2.nextDouble();
//     var2.setSeed(80L);
//     java.util.List var12 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var13 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var12);
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test61"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var18 = var16.cumulativeProbability(0.03359081770746613d);
    double[] var20 = var16.sample(4);
    org.apache.commons.math3.random.RandomGenerator var21 = null;
    double[] var23 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var23);
    double[] var26 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double[] var28 = org.apache.commons.math3.util.MathArrays.ebeDivide(var23, var26);
    double[] var29 = new double[] { };
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double var33 = org.apache.commons.math3.util.MathArrays.distance1(var29, var31);
    double[] var35 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var29, var35);
    double var38 = org.apache.commons.math3.util.MathArrays.safeNorm(var35);
    double[] var39 = new double[] { };
    double[] var41 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var41);
    double var43 = org.apache.commons.math3.util.MathArrays.distance1(var39, var41);
    org.apache.commons.math3.util.MathArrays.checkPositive(var41);
    double var45 = org.apache.commons.math3.util.MathArrays.safeNorm(var41);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var35, var41);
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeDivide(var23, var35);
    double[] var49 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var49);
    double[] var52 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var52);
    double[] var54 = org.apache.commons.math3.util.MathArrays.ebeDivide(var49, var52);
    org.apache.commons.math3.util.MathArrays.checkOrder(var54);
    org.apache.commons.math3.util.MathArrays.checkOrder(var54);
    double[] var58 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var58);
    boolean var60 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var54, var58);
    double[] var62 = org.apache.commons.math3.util.MathArrays.normalizeArray(var54, 3.0896657965554652d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var63 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var21, var35, var54);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var64 = org.apache.commons.math3.util.MathArrays.distanceInf(var20, var54);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test62"); }


    int[] var1 = new int[] { 100};
    int[] var3 = new int[] { 100};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
    int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var7);
    int[] var10 = new int[] { 100};
    int[] var12 = new int[] { 100};
    int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var12);
    int var14 = org.apache.commons.math3.util.MathArrays.distanceInf(var10, var12);
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var12);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var12);
    int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var12, 10);
    int[] var20 = new int[] { 100};
    int[] var22 = new int[] { 100};
    int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var22);
    int var24 = org.apache.commons.math3.util.MathArrays.distanceInf(var20, var22);
    int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var22);
    org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(var22);
    int[] var28 = new int[] { 100};
    int[] var30 = new int[] { 100};
    int[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var30);
    int var32 = org.apache.commons.math3.util.MathArrays.distanceInf(var28, var30);
    int[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var30);
    org.apache.commons.math3.random.Well19937c var34 = new org.apache.commons.math3.random.Well19937c(var30);
    int[] var36 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 10);
    int var37 = org.apache.commons.math3.util.MathArrays.distance1(var22, var30);
    int var38 = org.apache.commons.math3.util.MathArrays.distanceInf(var12, var22);
    var8.setSeed(var12);
    int[] var40 = org.apache.commons.math3.util.MathArrays.copyOf(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test63"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.0737206121073526d, (java.lang.Number)9.95645506445408d, (java.lang.Number)10L);
    java.lang.Number var4 = var3.getLo();
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var10 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)100, (java.lang.Number)0.0f, 0, var8, false);
    boolean var11 = var10.getStrict();
    int var12 = var10.getIndex();
    java.lang.Number var13 = var10.getPrevious();
    java.lang.Number var14 = var10.getPrevious();
    var3.addSuppressed((java.lang.Throwable)var10);
    java.lang.Number var16 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 9.95645506445408d+ "'", var4.equals(9.95645506445408d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 0.0f+ "'", var13.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 0.0f+ "'", var14.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + 9.95645506445408d+ "'", var16.equals(9.95645506445408d));

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test64"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.81482935f, (java.lang.Number)0.9459911029453463d, (java.lang.Number)13.521216539811984d);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test65"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.819217204815299d, (java.lang.Number)0.5104454862955553d, 3, var3, true);
    int var6 = var5.getIndex();
    int var7 = var5.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test66"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double[] var5 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var5);
    double[] var7 = org.apache.commons.math3.util.MathArrays.ebeDivide(var2, var5);
    double[] var8 = new double[] { };
    double[] var10 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var10);
    double var12 = org.apache.commons.math3.util.MathArrays.distance1(var8, var10);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var10, var13, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var10);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var17 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var7, var10);
    org.apache.commons.math3.util.MathArrays.OrderDirection var18 = null;
    double[] var19 = new double[] { };
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double var23 = org.apache.commons.math3.util.MathArrays.distance1(var19, var21);
    double[] var25 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var19, var25);
    org.apache.commons.math3.util.MathArrays.OrderDirection var28 = null;
    double[] var30 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var30);
    double[] var33 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var33);
    double[] var35 = org.apache.commons.math3.util.MathArrays.ebeDivide(var30, var33);
    double[][] var36 = new double[][] { var33};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var25, var28, var36);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var7, var18, var36);
    org.apache.commons.math3.exception.NullArgumentException var39 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test67"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    boolean var17 = var16.isSupportLowerBoundInclusive();
    boolean var18 = var16.isSupportLowerBoundInclusive();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = var16.probability(7167.615997776342d, 0.7124396706724971d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test68"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 3, (-538061442));
// 
//   }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test69"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     var1.reSeed(3513799009476651814L);
//     long var9 = var1.nextSecureLong(132L, 147306534756150976L);
//     double var12 = var1.nextUniform(0.0d, 33636.46593996366d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.955857035010338d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2397793599050787L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 11227.61029681718d);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test70"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(3);
    int[] var8 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var8);
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
    int[] var13 = new int[] { 100};
    int[] var15 = new int[] { 100};
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
    int var17 = org.apache.commons.math3.util.MathArrays.distanceInf(var13, var15);
    int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
    org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(var15);
    int[] var21 = new int[] { 100};
    int[] var23 = new int[] { 100};
    int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
    int var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var21, var23);
    int[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
    org.apache.commons.math3.random.Well19937c var27 = new org.apache.commons.math3.random.Well19937c(var23);
    int[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 10);
    int var30 = org.apache.commons.math3.util.MathArrays.distance1(var15, var23);
    int var31 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var23);
    var2.setSeed(var23);
    float var33 = var2.nextFloat();
    long var34 = var2.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.6862626f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == (-3218810666832712986L));

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test71"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var9);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var1, var9);
    double[] var16 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double[] var19 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double[] var21 = org.apache.commons.math3.util.MathArrays.ebeDivide(var16, var19);
    double[] var22 = new double[] { };
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var22, var24);
    double[] var28 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var22, var28);
    double var31 = org.apache.commons.math3.util.MathArrays.safeNorm(var28);
    double[] var32 = new double[] { };
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var32, var34);
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var38 = org.apache.commons.math3.util.MathArrays.safeNorm(var34);
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var28, var34);
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeDivide(var16, var28);
    org.apache.commons.math3.util.MathArrays.checkPositive(var40);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test72"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double[] var5 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var5);
    double[] var7 = org.apache.commons.math3.util.MathArrays.ebeDivide(var2, var5);
    double[] var8 = new double[] { };
    double[] var10 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var10);
    double var12 = org.apache.commons.math3.util.MathArrays.distance1(var8, var10);
    double[] var14 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var14);
    double var16 = org.apache.commons.math3.util.MathArrays.distance1(var8, var14);
    double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    double[] var18 = new double[] { };
    double[] var20 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double var22 = org.apache.commons.math3.util.MathArrays.distance1(var18, var20);
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double var24 = org.apache.commons.math3.util.MathArrays.safeNorm(var20);
    double[] var25 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var14, var20);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var2, var14);
    double[] var28 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeDivide(var28, var31);
    org.apache.commons.math3.util.MathArrays.checkOrder(var33);
    org.apache.commons.math3.util.MathArrays.checkOrder(var33);
    double[] var37 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var33, var37);
    double[] var41 = org.apache.commons.math3.util.MathArrays.normalizeArray(var33, 3.0896657965554652d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var42 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var14, var33);
    boolean var43 = var42.isSupportUpperBoundInclusive();
    double var44 = var42.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test73"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.density(1.2316468095843844d);
    double var23 = var16.inverseCumulativeProbability(1.0d);
    boolean var24 = var16.isSupportLowerBoundInclusive();
    double var25 = var16.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test74"); }


    int[] var1 = new int[] { 100};
    int[] var3 = new int[] { 100};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
    int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var3);
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test75"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(byte)1, var1, (java.lang.Number)(short)0);
    java.lang.Number var4 = var3.getLo();
    java.lang.String var5 = var3.toString();
    java.lang.Number var6 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: 1 out of [null, 0] range"+ "'", var5.equals("org.apache.commons.math3.exception.OutOfRangeException: 1 out of [null, 0] range"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)0+ "'", var6.equals((short)0));

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test76"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     java.lang.String var6 = var1.nextHexString(10);
//     var1.reSeedSecure((-124847318341222864L));
//     double var11 = var1.nextBeta(98.4467128375208d, 0.7335444274806671d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "79ee30a2ff"+ "'", var6.equals("79ee30a2ff"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.9967906683797793d);
// 
//   }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test77"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(9);
//     var0.reSeedSecure();
//     java.lang.String var5 = var0.nextSecureHexString(30);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextHypergeometric((-96398574), (-264936759), 1736698663);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "e04bbab65"+ "'", var2.equals("e04bbab65"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "531857338190c998984bc24b4a9a2b"+ "'", var5.equals("531857338190c998984bc24b4a9a2b"));
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test78"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(100L);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
    boolean var19 = org.apache.commons.math3.util.MathArrays.checkOrder(var13, var16, false, true);
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var24);
    double[] var28 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.0d);
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var13, var21);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeDivide(var31, var34);
    double[] var38 = org.apache.commons.math3.util.MathArrays.normalizeArray(var31, 100.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var39 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var13, var31);
    org.apache.commons.math3.random.RandomDataImpl var40 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var43 = var40.nextPermutation(1420158228, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test79"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     long var7 = var1.nextSecureLong((-1L), 152600911433040288L);
//     double var9 = var1.nextChiSquare(0.01408195728001127d);
//     int var12 = var1.nextZipf(10, 1.636388788949819E-6d);
//     int var15 = var1.nextInt((-63560251), 827167750);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var1.nextPascal(1, 4.385180791776747d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 41876850150700952L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 776030222);
// 
//   }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test80"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     int[] var10 = var0.nextPermutation(9, 4);
//     org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var10);
//     int[] var13 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var13);
//     int var15 = var14.nextInt();
//     long var16 = var14.nextLong();
//     double var17 = var14.nextGaussian();
//     int[] var19 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var19);
//     int var21 = var20.nextInt();
//     long var22 = var20.nextLong();
//     byte[] var23 = new byte[] { };
//     var20.nextBytes(var23);
//     var14.nextBytes(var23);
//     var11.nextBytes(var23);
//     int var28 = var11.nextInt(98);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 193.77774211465854d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 259766232686583471L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.7157990521557022d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 259766232686583471L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 29);
// 
//   }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test81"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     double var11 = var0.nextT(211.79400708576884d);
//     long var13 = var0.nextPoisson(0.7090371711746789d);
//     double var17 = var0.nextUniform((-0.32325280016288294d), 9862.916937121827d, true);
//     int var20 = var0.nextPascal(7, 1.0d);
//     double var23 = var0.nextF(3.670312001858478d, 12168.048178086838d);
//     double var26 = var0.nextF(1.137619072613078d, 9.92817599364983E8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 210.21190078342076d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "dbfe211569"+ "'", var9.equals("dbfe211569"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.3271310346728182d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 3128.8633983699497d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.580909195365409d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.16948055148348298d);
// 
//   }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test82"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     long var7 = var1.nextSecureLong((-1L), 152600911433040288L);
//     double var9 = var1.nextChiSquare(0.01408195728001127d);
//     int var12 = var1.nextZipf(10, 1.636388788949819E-6d);
//     int var15 = var1.nextInt((-63560251), 827167750);
//     double var18 = var1.nextCauchy(0.3846288555899191d, 0.03128256092855926d);
//     double var21 = var1.nextUniform(0.0d, 4.380036973352875d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 77817776883293280L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.5987743708542158E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 481335597);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.39323484824420357d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.0266454200158974d);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test83"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.9605318349984269d, (java.lang.Number)10.63187445392841d, false);
    java.lang.Number var5 = var4.getMax();
    java.lang.Number var6 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.63187445392841d+ "'", var5.equals(10.63187445392841d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 10.63187445392841d+ "'", var6.equals(10.63187445392841d));

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test84"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(98.45317552126936d);
//     double var4 = var0.nextT(1.137619072613078d);
//     int var7 = var0.nextBinomial(85, 0.012945788904241426d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.7391442435221546d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.2486082102270052d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
// 
//   }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test85"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     var0.reSeedSecure();
//     double var9 = var0.nextT(290.77256675474683d);
//     long var11 = var0.nextPoisson(9.927959811989089d);
//     java.util.Collection var12 = null;
//     java.lang.Object[] var14 = var0.nextSample(var12, (-1));
// 
//   }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test86"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(6);
    long var3 = var0.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-6069125204240848293L));

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test87"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(byte)100, (java.lang.Object[])var3);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    boolean var10 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var8, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var11 = null;
    boolean var13 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var11, false);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test88"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(1422716669, 1422716669);
    java.lang.String var3 = var2.toString();
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    long[] var7 = new long[] { 0L, 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
    long[][] var10 = new long[][] { var7};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var10);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var10);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var10);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var4, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.apache.commons.math3.exception.DimensionMismatchException: 1,422,716,669 != 1,422,716,669"+ "'", var3.equals("org.apache.commons.math3.exception.DimensionMismatchException: 1,422,716,669 != 1,422,716,669"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test89"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var6 = var1.nextLong(87064382195180672L, (-53668619146136008L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test90"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)645.7671832224502d);

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test91"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var10 = var1.nextWeibull(0.9846580496679653d, 0.7157990521557022d);
//     java.lang.String var12 = var1.nextHexString(100);
//     long var15 = var1.nextLong((-190865323983646368L), 112L);
//     var1.reSeedSecure();
//     double var19 = var1.nextBeta(98.42888798257793d, 3.72011415598965E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.31352703706636d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 94.22401621457647d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.728223732575919d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "73cdb49575d8aec2c7a014f99d228fedabdb059329ff6b4115be407639e751ad53194409af3b2fbb599cdb9db729a06a2b19"+ "'", var12.equals("73cdb49575d8aec2c7a014f99d228fedabdb059329ff6b4115be407639e751ad53194409af3b2fbb599cdb9db729a06a2b19"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-50227525751454440L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.999999998813175d);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test92"); }


    int[] var1 = new int[] { 100};
    int[] var3 = new int[] { 100};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
    int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test93"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.density(1.2316468095843844d);
    double var22 = var16.getNumericalVariance();
    var16.reseedRandomGenerator(2876919108950029338L);
    double var25 = var16.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test94"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(98.4467128375208d, 984.6226564837881d, 98.43652237373647d, 3.0896657965554652d, 2.056788858578444d, 0.8255079335182625d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 97238.6977680067d);

  }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test95"); }
// 
// 
//     org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.819217204815299d, (java.lang.Number)0.5104454862955553d, 3, var3, true);
//     int var6 = var5.getIndex();
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     long[] var12 = new long[] { 0L, 10L};
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var12);
//     long[][] var14 = new long[][] { var12};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var14);
//     org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var8, (java.lang.Number)98.42888798257793d, (java.lang.Object[])var14);
//     org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var7, (java.lang.Object[])var14);
//     org.apache.commons.math3.exception.MathInternalError var18 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var17);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test96"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var18 = var16.density(99.02988657003175d);
    boolean var19 = var16.isSupportUpperBoundInclusive();
    double var21 = var16.probability(263.1966961055d);
    boolean var22 = var16.isSupportUpperBoundInclusive();
    boolean var23 = var16.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test97"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(1.2388070620041405d, 98.45317552126936d, true);
//     double var13 = var1.nextExponential(290.77256675474683d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextBinomial(8, 16.55908715748299d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.4237035179611d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 82.54747928195499d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 75.4360553273075d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 363.03195027893884d);
// 
//   }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test98"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var3 = var1.nextPoisson(4.591420583449242d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var1.nextBinomial(2074243331, 38.60348596763803d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4L);
// 
//   }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test99"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     long var9 = var0.nextLong((-4736355256857903122L), (-414028722650554365L));
//     double var12 = var0.nextF(23.41031146092985d, 1.2000918311981499d);
//     double var15 = var0.nextUniform(1.0557163353000482E-9d, 1.208726759939196d);
//     java.lang.String var17 = var0.nextHexString(1042);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 159.79132956066348d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-3981045582546589696L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 11.02215215275881d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.760061890226921d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "273d58801757562f854646a2310fbf2129b012a306f691de80ef356521f65d2c39b7a0b3503939d097bd1b927cdeace7b536e174f34b5557e047a25c296e0162edf949f738e6d3aa35583f7899faf082527ddc16a457678336c48caef522ce7f4ebfc797464f500d62e9b7ea8ea607dc6835d3b1e4f49d75cb4d9fddbe959bd2603776c757f015aec42dde26d3935e0be3f3a118c91212cec11fdc675b08beeca677462df58a7f2e87ca9aa36bc5c0db52c4d1cbe7a50b1e310634001179cdfaac8cf558d0914fe3fd33a971b0de88de357ae8872e00ae546eb342f379bedcf9363c16dd70ab905779d71c040796297a56bebf3d60213e1af27e4f8d9ec75f8d3e907d896b215fc35e4fe43375b1615f357b51cea0fdffde46153552c85f7d62c3664bd1d70dfdca4878063409956b057c6c1fa2ee1aa74227fa191989dcde449da50a2774ed9030dbfd7a29d212284e1932924711685fb8153ef3dae0cf1b21440e5d257455c434d323c08c2ca1f0aa994179fc04ea6dd81762a2f153edb3a217ace2036d0847c2aa6afea8dd56e0411f0acfb28f9a0bd2538405594688ba07cd617374b53f4e9db03921c09a93f96a9c91ef9a9f9e435904675eb318292a2a013a35715a3a43104c40343b36b3d41018113a2d7eadf2cd3595b49a0ff7ebc29a533882692cc0f2736bb1265174102c32568a5f689c65dbaa29ea6f7f6fabc679caeb617670a8fbea"+ "'", var17.equals("273d58801757562f854646a2310fbf2129b012a306f691de80ef356521f65d2c39b7a0b3503939d097bd1b927cdeace7b536e174f34b5557e047a25c296e0162edf949f738e6d3aa35583f7899faf082527ddc16a457678336c48caef522ce7f4ebfc797464f500d62e9b7ea8ea607dc6835d3b1e4f49d75cb4d9fddbe959bd2603776c757f015aec42dde26d3935e0be3f3a118c91212cec11fdc675b08beeca677462df58a7f2e87ca9aa36bc5c0db52c4d1cbe7a50b1e310634001179cdfaac8cf558d0914fe3fd33a971b0de88de357ae8872e00ae546eb342f379bedcf9363c16dd70ab905779d71c040796297a56bebf3d60213e1af27e4f8d9ec75f8d3e907d896b215fc35e4fe43375b1615f357b51cea0fdffde46153552c85f7d62c3664bd1d70dfdca4878063409956b057c6c1fa2ee1aa74227fa191989dcde449da50a2774ed9030dbfd7a29d212284e1932924711685fb8153ef3dae0cf1b21440e5d257455c434d323c08c2ca1f0aa994179fc04ea6dd81762a2f153edb3a217ace2036d0847c2aa6afea8dd56e0411f0acfb28f9a0bd2538405594688ba07cd617374b53f4e9db03921c09a93f96a9c91ef9a9f9e435904675eb318292a2a013a35715a3a43104c40343b36b3d41018113a2d7eadf2cd3595b49a0ff7ebc29a533882692cc0f2736bb1265174102c32568a5f689c65dbaa29ea6f7f6fabc679caeb617670a8fbea"));
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test100"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(6);
    int[] var4 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var4);
    int var6 = var5.nextInt();
    long var7 = var5.nextLong();
    byte[] var8 = new byte[] { };
    var5.nextBytes(var8);
    var0.nextBytes(var8);
    double var11 = var0.nextGaussian();
    var0.setSeed((-50227525751454440L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-0.1226031674545324d));

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test101"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     long var9 = var0.nextSecureLong((-364738407763743936L), (-28760688557591720L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 65.69992428138613d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-42611147296095416L));
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test102"); }


    int[] var1 = new int[] { 100};
    int[] var3 = new int[] { 100};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
    int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var7);
    int[] var10 = new int[] { 100};
    int[] var12 = new int[] { 100};
    int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var12);
    int var14 = org.apache.commons.math3.util.MathArrays.distanceInf(var10, var12);
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var12);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var12);
    int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var12, 10);
    int[] var20 = new int[] { 100};
    int[] var22 = new int[] { 100};
    int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var22);
    int var24 = org.apache.commons.math3.util.MathArrays.distanceInf(var20, var22);
    int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var22);
    org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(var22);
    int[] var28 = new int[] { 100};
    int[] var30 = new int[] { 100};
    int[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var30);
    int var32 = org.apache.commons.math3.util.MathArrays.distanceInf(var28, var30);
    int[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var30);
    org.apache.commons.math3.random.Well19937c var34 = new org.apache.commons.math3.random.Well19937c(var30);
    int[] var36 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 10);
    int var37 = org.apache.commons.math3.util.MathArrays.distance1(var22, var30);
    int var38 = org.apache.commons.math3.util.MathArrays.distanceInf(var12, var22);
    var8.setSeed(var12);
    int[] var41 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(var41);
    int var43 = var42.nextInt();
    double var44 = var42.nextDouble();
    var42.setSeed((-1));
    var42.setSeed(0L);
    long var49 = var42.nextLong();
    var42.setSeed(10);
    double var52 = var42.nextDouble();
    int var54 = var42.nextInt(6);
    int[] var56 = new int[] { 100};
    int[] var58 = new int[] { 100};
    int[] var59 = org.apache.commons.math3.util.MathArrays.copyOf(var58);
    int var60 = org.apache.commons.math3.util.MathArrays.distanceInf(var56, var58);
    int[] var61 = org.apache.commons.math3.util.MathArrays.copyOf(var58);
    int[] var62 = org.apache.commons.math3.util.MathArrays.copyOf(var58);
    var42.setSeed(var58);
    int[] var65 = new int[] { 100};
    int[] var67 = new int[] { 100};
    int[] var68 = org.apache.commons.math3.util.MathArrays.copyOf(var67);
    int var69 = org.apache.commons.math3.util.MathArrays.distanceInf(var65, var67);
    int[] var70 = org.apache.commons.math3.util.MathArrays.copyOf(var67);
    org.apache.commons.math3.random.Well19937c var71 = new org.apache.commons.math3.random.Well19937c(var67);
    int[] var73 = new int[] { 100};
    int[] var75 = new int[] { 100};
    int[] var76 = org.apache.commons.math3.util.MathArrays.copyOf(var75);
    int var77 = org.apache.commons.math3.util.MathArrays.distanceInf(var73, var75);
    int[] var78 = org.apache.commons.math3.util.MathArrays.copyOf(var75);
    org.apache.commons.math3.random.Well19937c var79 = new org.apache.commons.math3.random.Well19937c(var75);
    int[] var81 = org.apache.commons.math3.util.MathArrays.copyOf(var75, 10);
    int var82 = org.apache.commons.math3.util.MathArrays.distance1(var67, var75);
    org.apache.commons.math3.random.Well19937c var83 = new org.apache.commons.math3.random.Well19937c(var75);
    int[] var85 = new int[] { 100};
    int[] var87 = new int[] { 100};
    int[] var88 = org.apache.commons.math3.util.MathArrays.copyOf(var87);
    int var89 = org.apache.commons.math3.util.MathArrays.distanceInf(var85, var87);
    int[] var91 = new int[] { 100};
    int[] var92 = org.apache.commons.math3.util.MathArrays.copyOf(var91);
    int[] var94 = org.apache.commons.math3.util.MathArrays.copyOf(var91, 6);
    int var95 = org.apache.commons.math3.util.MathArrays.distanceInf(var85, var94);
    int var96 = org.apache.commons.math3.util.MathArrays.distance1(var75, var85);
    int var97 = org.apache.commons.math3.util.MathArrays.distanceInf(var58, var85);
    var8.setSeed(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.01408195728001127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == (-4736355256857903122L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.761957659063951d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == 0);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test103"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(4);
//     double var5 = var0.nextCauchy(98.88500098380753d, 1.0614018016610713d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "0969"+ "'", var2.equals("0969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 96.9319161358337d);
// 
//   }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test104"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var3 = var0.nextT(98.28206305872513d);
//     double var6 = var0.nextGamma(0.2700290390806306d, 1.0737206121073526d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextHypergeometric(11387117, 1543116286, 1736698663);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.8315362630808044d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.031680305389214056d);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test105"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.density(1.2316468095843844d);
    boolean var22 = var16.isSupportLowerBoundInclusive();
    double var23 = var16.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test106"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(1205512795, (-125716405));

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test107"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(100L);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
    boolean var19 = org.apache.commons.math3.util.MathArrays.checkOrder(var13, var16, false, true);
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var24);
    double[] var28 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.0d);
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var13, var21);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeDivide(var31, var34);
    double[] var38 = org.apache.commons.math3.util.MathArrays.normalizeArray(var31, 100.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var39 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var13, var31);
    int[] var41 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(var41);
    int var43 = var42.nextInt();
    double var44 = var42.nextDouble();
    var42.setSeed((-1));
    var42.setSeed(0L);
    long var49 = var42.nextLong();
    var42.setSeed(10);
    double var52 = var42.nextDouble();
    int var54 = var42.nextInt(6);
    int[] var56 = new int[] { 100};
    int[] var58 = new int[] { 100};
    int[] var59 = org.apache.commons.math3.util.MathArrays.copyOf(var58);
    int var60 = org.apache.commons.math3.util.MathArrays.distanceInf(var56, var58);
    int[] var61 = org.apache.commons.math3.util.MathArrays.copyOf(var58);
    int[] var62 = org.apache.commons.math3.util.MathArrays.copyOf(var58);
    var42.setSeed(var58);
    int[] var65 = new int[] { 100};
    int[] var67 = new int[] { 100};
    int[] var68 = org.apache.commons.math3.util.MathArrays.copyOf(var67);
    int var69 = org.apache.commons.math3.util.MathArrays.distanceInf(var65, var67);
    int[] var70 = org.apache.commons.math3.util.MathArrays.copyOf(var67);
    org.apache.commons.math3.random.Well19937c var71 = new org.apache.commons.math3.random.Well19937c(var67);
    int[] var73 = new int[] { 100};
    int[] var75 = new int[] { 100};
    int[] var76 = org.apache.commons.math3.util.MathArrays.copyOf(var75);
    int var77 = org.apache.commons.math3.util.MathArrays.distanceInf(var73, var75);
    int[] var78 = org.apache.commons.math3.util.MathArrays.copyOf(var75);
    org.apache.commons.math3.random.Well19937c var79 = new org.apache.commons.math3.random.Well19937c(var75);
    int[] var81 = org.apache.commons.math3.util.MathArrays.copyOf(var75, 10);
    int var82 = org.apache.commons.math3.util.MathArrays.distance1(var67, var75);
    org.apache.commons.math3.random.Well19937c var83 = new org.apache.commons.math3.random.Well19937c(var75);
    int[] var85 = new int[] { 100};
    int[] var87 = new int[] { 100};
    int[] var88 = org.apache.commons.math3.util.MathArrays.copyOf(var87);
    int var89 = org.apache.commons.math3.util.MathArrays.distanceInf(var85, var87);
    int[] var91 = new int[] { 100};
    int[] var92 = org.apache.commons.math3.util.MathArrays.copyOf(var91);
    int[] var94 = org.apache.commons.math3.util.MathArrays.copyOf(var91, 6);
    int var95 = org.apache.commons.math3.util.MathArrays.distanceInf(var85, var94);
    int var96 = org.apache.commons.math3.util.MathArrays.distance1(var75, var85);
    int var97 = org.apache.commons.math3.util.MathArrays.distanceInf(var58, var85);
    var2.setSeed(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.01408195728001127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == (-4736355256857903122L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.761957659063951d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == 0);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test108"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(3);
    int[] var8 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var8);
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
    int[] var13 = new int[] { 100};
    int[] var15 = new int[] { 100};
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
    int var17 = org.apache.commons.math3.util.MathArrays.distanceInf(var13, var15);
    int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
    org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(var15);
    int[] var21 = new int[] { 100};
    int[] var23 = new int[] { 100};
    int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
    int var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var21, var23);
    int[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
    org.apache.commons.math3.random.Well19937c var27 = new org.apache.commons.math3.random.Well19937c(var23);
    int[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 10);
    int var30 = org.apache.commons.math3.util.MathArrays.distance1(var15, var23);
    int var31 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var23);
    var2.setSeed(var23);
    org.apache.commons.math3.random.RandomDataGenerator var33 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    int var36 = var33.nextInt((-838354274), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == (-263022986));

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test109"); }


    float[] var0 = null;
    float[] var1 = null;
    float[] var2 = new float[] { };
    boolean var3 = org.apache.commons.math3.util.MathArrays.equals(var1, var2);
    float[] var6 = new float[] { 0.0f, (-1.0f)};
    float[] var7 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var6, var7);
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var1, var6);
    float[] var10 = null;
    float[] var11 = new float[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var10, var11);
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var6, var11);
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var0, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test110"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)24293682399481844L, (java.lang.Number)0.2869779568850015d, true);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test111"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var3 = new long[] { 0L, 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    long[][] var5 = new long[][] { var3};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test112"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 2080);
// 
//   }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test113"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     var1.reSeed(3513799009476651814L);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.860589914391308d);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test114"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var3 = var2.getValue();
    java.lang.Object var4 = null;
    boolean var5 = var2.equals(var4);
    java.lang.Object var6 = var2.getValue();
    java.lang.Object var7 = var2.getSecond();
    org.apache.commons.math3.util.Pair var8 = new org.apache.commons.math3.util.Pair(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1L+ "'", var3.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1L+ "'", var6.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1L+ "'", var7.equals(1L));

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test115"); }
// 
// 
//     double[] var1 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var1);
//     double[] var4 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var4);
//     double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
//     double[] var8 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 100.0d);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
//     boolean var12 = org.apache.commons.math3.util.MathArrays.checkOrder(var8, var9, false, false);
//     double[] var13 = new double[] { };
//     double[] var15 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var15);
//     double var17 = org.apache.commons.math3.util.MathArrays.distance1(var13, var15);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
//     double[] var20 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var20);
//     double[] var23 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var23);
//     double[] var25 = org.apache.commons.math3.util.MathArrays.ebeDivide(var20, var23);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var25);
//     double var27 = org.apache.commons.math3.util.MathArrays.distanceInf(var13, var25);
//     double[] var29 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var29);
//     double[] var32 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var32);
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeDivide(var29, var32);
//     double[] var35 = new double[] { };
//     double[] var37 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var37);
//     double var39 = org.apache.commons.math3.util.MathArrays.distance1(var35, var37);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var37);
//     double var41 = org.apache.commons.math3.util.MathArrays.safeNorm(var37);
//     double[] var42 = org.apache.commons.math3.util.MathArrays.ebeAdd(var29, var37);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var43 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var37, var43, true);
//     double var46 = org.apache.commons.math3.util.MathArrays.distance1(var13, var37);
//     boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var8, var37);
//     double[] var49 = org.apache.commons.math3.util.MathArrays.normalizeArray(var8, 1.0498993738364044d);
//     double[] var50 = null;
//     double[] var51 = org.apache.commons.math3.util.MathArrays.ebeDivide(var49, var50);
// 
//   }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test116"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     int var4 = var0.nextInt(0, 10);
//     double var7 = var0.nextGaussian(1.176542981693557d, 1.8507918026021757d);
//     long var10 = var0.nextLong((-414028722650554365L), 132L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextBinomial(8, 1.819217204815299d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.3677324070796596d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-104408399617870304L));
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test117"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, var1);
    java.lang.Number var3 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test118"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     double var13 = var0.nextT(99.2782319289774d);
//     double var15 = var0.nextT(98.47845151091803d);
//     double var18 = var0.nextF(98.47591907847392d, 1.0d);
//     long var21 = var0.nextSecureLong((-414028722650554365L), 5220799318019361146L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 167.8008175171178d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.14776136916515162d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4.418431122532572d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.0952655025675326d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.6547858751949384d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 508.4128288746627d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 4971118610658702336L);
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test119"); }
// 
// 
//     int[] var1 = new int[] { 100};
//     int[] var3 = new int[] { 100};
//     int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
//     int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
//     int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var3);
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 10);
//     int[] var11 = new int[] { 100};
//     int[] var13 = new int[] { 100};
//     int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
//     int var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var11, var13);
//     int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
//     org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var13);
//     int[] var19 = new int[] { 100};
//     int[] var21 = new int[] { 100};
//     int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var21);
//     int var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var19, var21);
//     int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var21);
//     org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(var21);
//     int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 10);
//     int var28 = org.apache.commons.math3.util.MathArrays.distance1(var13, var21);
//     int var29 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var13);
//     org.apache.commons.math3.random.RandomDataImpl var30 = new org.apache.commons.math3.random.RandomDataImpl();
//     var30.reSeedSecure();
//     double var34 = var30.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var37 = var30.nextZipf(8, 98.28206305872513d);
//     int[] var40 = var30.nextPermutation(9, 4);
//     int var41 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var40);
//     org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 216.89435352584687d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 94);
// 
//   }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test120"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(98.45317552126936d);
//     double var5 = var0.nextGaussian(0.0d, 92.58889101274673d);
//     int var9 = var0.nextHypergeometric(7, 0, 1);
//     int var12 = var0.nextZipf(2, 209.84511029234756d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextUniform(10074.793969498272d, 208.18143482883644d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.35545699549764914d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 21.907041556494057d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test121"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    double var4 = var2.nextDouble();
    var2.setSeed((-1));
    var2.setSeed(0L);
    long var9 = var2.nextLong();
    var2.setSeed(10);
    var2.clear();
    var2.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.01408195728001127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-4736355256857903122L));

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test122"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-1.0f), var2, true);
    java.lang.Number var5 = var4.getMin();
    boolean var6 = var4.getBoundIsAllowed();
    java.lang.Number var7 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test123"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-894180960));
// 
//   }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test124"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     var0.reSeed(152600911433040288L);
//     java.lang.String var15 = var0.nextHexString(7);
//     double var18 = var0.nextWeibull(0.6709920656782435d, 3.171769354806784d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 192.01690253110266d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.417551374131548d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.1022050677096966d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "2b12bb0"+ "'", var15.equals("2b12bb0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.1513880935116176d);
// 
//   }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test125"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextInt((-1), 8);
//     int var10 = var0.nextInt((-1), 6);
//     double var12 = var0.nextChiSquare(0.2700290390806306d);
//     double var15 = var0.nextCauchy(98.34128277750061d, 106.0271272985156d);
//     var0.reSeed();
//     double var19 = var0.nextCauchy(0.14776136916515162d, 9.92817599364983E8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 200.28631116510377d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.11825633526542967d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 173.39481215283104d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-5.919077326895714E8d));
// 
//   }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test126"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     double var7 = var1.nextGamma(91.73734938536145d, 98.96880118978186d);
//     double var10 = var1.nextUniform(0.761957659063951d, 1.8361073492936983d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var1.nextBinomial((-63560251), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 10779.934279236179d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.2762124955035359d);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test127"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)100.26932579100311d, var2, false);
    boolean var5 = var4.getBoundIsAllowed();
    java.lang.Number var6 = var4.getMax();
    java.lang.Number var7 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 100.26932579100311d+ "'", var7.equals(100.26932579100311d));

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test128"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.checkOrder(var6, var9, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    boolean var15 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var13, false);
    double[] var17 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var17);
    double[] var20 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double[] var22 = org.apache.commons.math3.util.MathArrays.ebeDivide(var17, var20);
    double[] var23 = new double[] { };
    double[] var25 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var23, var25);
    org.apache.commons.math3.util.MathArrays.checkPositive(var25);
    double var29 = org.apache.commons.math3.util.MathArrays.safeNorm(var25);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeAdd(var17, var25);
    org.apache.commons.math3.util.MathArrays.OrderDirection var31 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var25, var31, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var34 = null;
    boolean var37 = org.apache.commons.math3.util.MathArrays.checkOrder(var25, var34, true, false);
    double[] var38 = org.apache.commons.math3.util.MathArrays.ebeDivide(var6, var25);
    double[] var40 = org.apache.commons.math3.util.MathArrays.normalizeArray(var25, 98.90354239278018d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test129"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     double var9 = var0.nextExponential(9.967053788588151d);
//     long var12 = var0.nextSecureLong((-414028722650554365L), 31715294113568244L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 217.64897890758175d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 5.58882321105828d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-294760526636961408L));
// 
//   }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test130"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextZipf(100, 0.9638486378008077d);
//     long var5 = var0.nextPoisson(98.88500098380753d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextGamma(0.0d, 99.12443669408873d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 107L);
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test131"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     int[] var10 = var0.nextPermutation(9, 4);
//     double var12 = var0.nextT(284.941661635924d);
//     double[] var14 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var14);
//     double[] var17 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var17);
//     double[] var19 = org.apache.commons.math3.util.MathArrays.ebeDivide(var14, var17);
//     double[] var20 = new double[] { };
//     double[] var22 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var22);
//     double var24 = org.apache.commons.math3.util.MathArrays.distance1(var20, var22);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var25 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var22, var25, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var22);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var19, var22);
//     double[] var31 = var29.sample(9);
//     double var32 = var29.getSupportLowerBound();
//     double var34 = var29.cumulativeProbability(1.0646160893106429d);
//     double var36 = var29.cumulativeProbability(104.91028148840213d);
//     double var37 = var29.getNumericalVariance();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var38 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 212.4777814963813d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.6411643000009707d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0.0d);
// 
//   }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test132"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     var2.clear();
//     var2.setSeed(100L);
//     double[] var7 = new double[] { };
//     double[] var9 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var9);
//     double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
//     double[] var13 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var13);
//     double var15 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
//     boolean var19 = org.apache.commons.math3.util.MathArrays.checkOrder(var13, var16, false, true);
//     double[] var21 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var21);
//     double[] var24 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var24);
//     double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var24);
//     double[] var28 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.0d);
//     double var29 = org.apache.commons.math3.util.MathArrays.distance(var13, var21);
//     double[] var31 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var31);
//     double[] var34 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var34);
//     double[] var36 = org.apache.commons.math3.util.MathArrays.ebeDivide(var31, var34);
//     double[] var38 = org.apache.commons.math3.util.MathArrays.normalizeArray(var31, 100.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var39 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var13, var31);
//     org.apache.commons.math3.random.RandomDataImpl var40 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
//     java.lang.String var42 = var40.nextHexString(7);
//     var40.reSeed();
//     org.apache.commons.math3.distribution.IntegerDistribution var44 = null;
//     int var45 = var40.nextInversionDeviate(var44);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test133"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var18 = var16.density(99.02988657003175d);
    boolean var19 = var16.isSupportUpperBoundInclusive();
    double var20 = var16.sample();
    double var21 = var16.sample();
    var16.reseedRandomGenerator(111759704996197392L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test134"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var8 = org.apache.commons.math3.util.MathArrays.normalizeArray(var4, 1.0159264522107176d);
    double[] var10 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var10);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double[] var15 = org.apache.commons.math3.util.MathArrays.ebeDivide(var10, var13);
    double[] var16 = new double[] { };
    double[] var18 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var18);
    double var20 = org.apache.commons.math3.util.MathArrays.distance1(var16, var18);
    org.apache.commons.math3.util.MathArrays.checkPositive(var18);
    double var22 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
    double[] var23 = org.apache.commons.math3.util.MathArrays.ebeAdd(var10, var18);
    double[] var25 = org.apache.commons.math3.util.MathArrays.normalizeArray(var23, 0.0d);
    double[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var25);
    java.lang.Number var27 = null;
    java.lang.Comparable[] var29 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var30 = null;
    boolean var32 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var29, var30, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var33 = new org.apache.commons.math3.exception.NotFiniteNumberException(var27, (java.lang.Object[])var29);
    org.apache.commons.math3.util.MathArrays.OrderDirection var34 = null;
    boolean var36 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var29, var34, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var40 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.3220963206821523d, (java.lang.Number)299.89733044110505d, 8);
    int var41 = var40.getIndex();
    org.apache.commons.math3.exception.util.ExceptionContext var42 = var40.getContext();
    org.apache.commons.math3.util.MathArrays.OrderDirection var43 = var40.getDirection();
    boolean var45 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var29, var43, false);
    boolean var47 = org.apache.commons.math3.util.MathArrays.isMonotonic(var25, var43, false);
    boolean var50 = org.apache.commons.math3.util.MathArrays.checkOrder(var8, var43, false, true);
    org.apache.commons.math3.util.MathArrays.checkPositive(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test135"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     double var9 = var1.nextF(98.34128277750061d, 98.42176142483318d);
//     double var12 = var1.nextGaussian(9.927198205545196d, 0.5104454862955553d);
//     var1.reSeedSecure(10L);
//     double var17 = var1.nextF(50.86260633466009d, 5.477225575051661d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 100.13597997030679d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "b"+ "'", var6.equals("b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.8816368150908784d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 10.016429212474291d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.0732858727486607d);
// 
//   }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test136"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     var1.reSeed(3513799009476651814L);
//     double var10 = var1.nextUniform(10.024409082583382d, 211.79400708576884d, true);
//     long var12 = var1.nextPoisson(0.9179650267580631d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10.067518559322133d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 77.37364904639617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0L);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test137"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var3 = var2.getValue();
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl();
    var5.reSeed();
    boolean var7 = var2.equals((java.lang.Object)var5);
    org.apache.commons.math3.util.Pair var8 = new org.apache.commons.math3.util.Pair(var2);
    java.lang.Object var9 = var2.getFirst();
    java.lang.Object var10 = var2.getValue();
    java.lang.Object var11 = var2.getFirst();
    java.lang.Object var12 = var2.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1L+ "'", var3.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (-1L)+ "'", var9.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 1L+ "'", var10.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + (-1L)+ "'", var11.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 1L+ "'", var12.equals(1L));

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test138"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.002349480672631077d, (java.lang.Number)5, true);
    java.lang.Number var4 = var3.getMax();
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)7764.231540750071d, (java.lang.Number)10.0d, true);
    var3.addSuppressed((java.lang.Throwable)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 5+ "'", var4.equals(5));

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test139"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-63560251), 9);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test140"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var3 = var0.nextExponential(0.2683148062047325d);
//     double var7 = var0.nextUniform((-37.441946953176824d), 37.394228706165585d, false);
//     double var10 = var0.nextF(201.6602925919339d, 0.7117256048311531d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.0963143354074829d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 18.674530217946966d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 112.71817466757267d);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test141"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
    double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var13);
    double[] var17 = new double[] { };
    double[] var19 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance1(var17, var19);
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var13, var19);
    double[] var25 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var13);
    org.apache.commons.math3.util.MathArrays.checkPositive(var25);
    double[] var27 = new double[] { };
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var27, var29);
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double var33 = org.apache.commons.math3.util.MathArrays.safeNorm(var29);
    double[] var35 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var35);
    double[] var38 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var38);
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeDivide(var35, var38);
    double[] var41 = new double[] { };
    double[] var43 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var43);
    double var45 = org.apache.commons.math3.util.MathArrays.distance1(var41, var43);
    org.apache.commons.math3.util.MathArrays.checkPositive(var43);
    double var47 = org.apache.commons.math3.util.MathArrays.safeNorm(var43);
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeAdd(var35, var43);
    double[] var50 = org.apache.commons.math3.util.MathArrays.normalizeArray(var48, 0.0d);
    double var51 = org.apache.commons.math3.util.MathArrays.distance1(var29, var48);
    double[] var53 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var53);
    double[] var56 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var56);
    double[] var58 = org.apache.commons.math3.util.MathArrays.ebeDivide(var53, var56);
    double[] var59 = new double[] { };
    double[] var61 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var61);
    double var63 = org.apache.commons.math3.util.MathArrays.distance1(var59, var61);
    org.apache.commons.math3.util.MathArrays.checkPositive(var61);
    double var65 = org.apache.commons.math3.util.MathArrays.safeNorm(var61);
    double[] var66 = org.apache.commons.math3.util.MathArrays.ebeAdd(var53, var61);
    org.apache.commons.math3.util.MathArrays.OrderDirection var67 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var61, var67, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var70 = null;
    boolean var73 = org.apache.commons.math3.util.MathArrays.checkOrder(var61, var70, true, false);
    double[] var74 = org.apache.commons.math3.util.MathArrays.ebeDivide(var48, var61);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var25, var61);
    double[] var76 = new double[] { };
    double[] var78 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var78);
    double var80 = org.apache.commons.math3.util.MathArrays.distance1(var76, var78);
    double[] var82 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var82);
    double var84 = org.apache.commons.math3.util.MathArrays.distance1(var76, var82);
    double var85 = org.apache.commons.math3.util.MathArrays.safeNorm(var82);
    double[] var86 = new double[] { };
    double[] var88 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance1(var86, var88);
    org.apache.commons.math3.util.MathArrays.checkPositive(var88);
    double var92 = org.apache.commons.math3.util.MathArrays.safeNorm(var88);
    double[] var93 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var82, var88);
    double var94 = org.apache.commons.math3.util.MathArrays.distance(var25, var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 99.0d);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test142"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(100L);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
    boolean var19 = org.apache.commons.math3.util.MathArrays.checkOrder(var13, var16, false, true);
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var24);
    double[] var28 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.0d);
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var13, var21);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeDivide(var31, var34);
    double[] var38 = org.apache.commons.math3.util.MathArrays.normalizeArray(var31, 100.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var39 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var13, var31);
    boolean var40 = var39.isSupportConnected();
    double var41 = var39.getSupportUpperBound();
    double var42 = var39.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test143"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double[] var5 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var5);
    double[] var7 = org.apache.commons.math3.util.MathArrays.ebeDivide(var2, var5);
    double[] var8 = new double[] { };
    double[] var10 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var10);
    double var12 = org.apache.commons.math3.util.MathArrays.distance1(var8, var10);
    double[] var14 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var14);
    double var16 = org.apache.commons.math3.util.MathArrays.distance1(var8, var14);
    double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    double[] var18 = new double[] { };
    double[] var20 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double var22 = org.apache.commons.math3.util.MathArrays.distance1(var18, var20);
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double var24 = org.apache.commons.math3.util.MathArrays.safeNorm(var20);
    double[] var25 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var14, var20);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var2, var14);
    double[] var28 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeDivide(var28, var31);
    org.apache.commons.math3.util.MathArrays.checkOrder(var33);
    org.apache.commons.math3.util.MathArrays.checkOrder(var33);
    double[] var37 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var33, var37);
    double[] var41 = org.apache.commons.math3.util.MathArrays.normalizeArray(var33, 3.0896657965554652d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var42 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var14, var33);
    double[] var44 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var44);
    double[] var47 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var47);
    double[] var49 = org.apache.commons.math3.util.MathArrays.ebeDivide(var44, var47);
    double[] var50 = new double[] { };
    double[] var52 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var52);
    double var54 = org.apache.commons.math3.util.MathArrays.distance1(var50, var52);
    org.apache.commons.math3.util.MathArrays.checkPositive(var52);
    double var56 = org.apache.commons.math3.util.MathArrays.safeNorm(var52);
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeAdd(var44, var52);
    double[] var59 = org.apache.commons.math3.util.MathArrays.normalizeArray(var57, 0.0d);
    double[] var60 = org.apache.commons.math3.util.MathArrays.copyOf(var59);
    java.lang.Number var61 = null;
    java.lang.Comparable[] var63 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var64 = null;
    boolean var66 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var63, var64, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var67 = new org.apache.commons.math3.exception.NotFiniteNumberException(var61, (java.lang.Object[])var63);
    org.apache.commons.math3.util.MathArrays.OrderDirection var68 = null;
    boolean var70 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var63, var68, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var74 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.3220963206821523d, (java.lang.Number)299.89733044110505d, 8);
    int var75 = var74.getIndex();
    org.apache.commons.math3.exception.util.ExceptionContext var76 = var74.getContext();
    org.apache.commons.math3.util.MathArrays.OrderDirection var77 = var74.getDirection();
    boolean var79 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var63, var77, false);
    boolean var81 = org.apache.commons.math3.util.MathArrays.isMonotonic(var59, var77, false);
    double var82 = org.apache.commons.math3.util.MathArrays.distance1(var14, var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 100.0d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test144"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0737206121073526d, (java.lang.Number)104.91028148840213d, 0);
    int var4 = var3.getIndex();
    boolean var5 = var3.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test145"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.009617299800806443d, 120.22721817250748d, 99.2782319289774d, 197.31657362797657d, 1.1962133795075212d, 0.0d, 1.282853271652816E-9d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 19590.396821270788d);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test146"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)9.834337537501083d, (java.lang.Number)93.08095247348105d, true);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    java.lang.Number var6 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 93.08095247348105d+ "'", var6.equals(93.08095247348105d));

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test147"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.sample();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = var16.inverseCumulativeProbability(44.78362699758406d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test148"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var9);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var1, var9);
    double[] var16 = org.apache.commons.math3.util.MathArrays.normalizeArray(var14, 0.0d);
    double[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var17);
    int[] var20 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(var20);
    int var22 = var21.nextInt();
    double var23 = var21.nextDouble();
    var21.setSeed((-1));
    var21.setSeed(0L);
    long var28 = var21.nextLong();
    org.apache.commons.math3.util.Pair var29 = new org.apache.commons.math3.util.Pair((java.lang.Object)var18, (java.lang.Object)var28);
    java.lang.Object var30 = var29.getValue();
    java.lang.Object var31 = var29.getValue();
    java.lang.Object var32 = var29.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.01408195728001127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-4736355256857903122L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + (-4736355256857903122L)+ "'", var30.equals((-4736355256857903122L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + (-4736355256857903122L)+ "'", var31.equals((-4736355256857903122L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test149"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(9);
//     var0.reSeedSecure();
//     java.lang.String var5 = var0.nextSecureHexString(30);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "7d64c1d22"+ "'", var2.equals("7d64c1d22"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "f30e6353e40ad90d64c311a5bc6736"+ "'", var5.equals("f30e6353e40ad90d64c311a5bc6736"));
// 
//   }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test150"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextUniform(0.05327950722912841d, 106.86435898139051d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.47037218239929d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 61.52869286998323d);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test151"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)16412887479476156L, (java.lang.Number)1.1974708505559213d, (java.lang.Number)77.37364904639617d);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test152"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    java.lang.Object var5 = var2.getSecond();
    java.lang.Object var6 = var2.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (-1L)+ "'", var3.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1L)+ "'", var4.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1L+ "'", var5.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1L)+ "'", var6.equals((-1L)));

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test153"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
    int var5 = var3.nextInt(8);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    double var8 = var6.nextT(98.41314575899459d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-2.227904791619313d));

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test154"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed();
    var1.reSeed(94L);
    double var7 = var1.nextGamma(216.89435352584687d, 201.76160301238804d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 41215.9592544583d);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test155"); }


    int[] var1 = new int[] { 100};
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    int[] var4 = new int[] { 100};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double var6 = org.apache.commons.math3.util.MathArrays.distance(var2, var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test156"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(3);
    org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    float var8 = var2.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    double var11 = var9.nextT(98.85607777755142d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.90108645f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.25480340017252506d);

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test157"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextWeibull(1.6486550157904805d, 100.0d);
//     double var6 = var0.nextExponential(105.26207852446285d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 103.20085407431179d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.17775810994563d);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test158"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.checkOrder(var6, var9, false, true);
    double[] var13 = new double[] { };
    double[] var15 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var15);
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var13, var15);
    double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    double[] var19 = new double[] { };
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double var23 = org.apache.commons.math3.util.MathArrays.distance1(var19, var21);
    double[] var25 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var19, var25);
    org.apache.commons.math3.util.MathArrays.OrderDirection var28 = null;
    boolean var31 = org.apache.commons.math3.util.MathArrays.checkOrder(var25, var28, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var32 = null;
    boolean var34 = org.apache.commons.math3.util.MathArrays.isMonotonic(var25, var32, false);
    double[] var35 = new double[] { };
    double[] var37 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance1(var35, var37);
    double[] var41 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var41);
    double var43 = org.apache.commons.math3.util.MathArrays.distance1(var35, var41);
    double var44 = org.apache.commons.math3.util.MathArrays.safeNorm(var41);
    double[] var45 = org.apache.commons.math3.util.MathArrays.ebeDivide(var25, var41);
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var18, var45);
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var6, var45);
    int[] var49 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var50 = new org.apache.commons.math3.random.Well19937c(var49);
    int var51 = var50.nextInt();
    var50.clear();
    var50.setSeed(100L);
    double[] var55 = new double[] { };
    double[] var57 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var57);
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var55, var57);
    double[] var61 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var61);
    double var63 = org.apache.commons.math3.util.MathArrays.distance1(var55, var61);
    org.apache.commons.math3.util.MathArrays.OrderDirection var64 = null;
    boolean var67 = org.apache.commons.math3.util.MathArrays.checkOrder(var61, var64, false, true);
    double[] var69 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var69);
    double[] var72 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var72);
    double[] var74 = org.apache.commons.math3.util.MathArrays.ebeDivide(var69, var72);
    double[] var76 = org.apache.commons.math3.util.MathArrays.normalizeArray(var69, 0.0d);
    double var77 = org.apache.commons.math3.util.MathArrays.distance(var61, var69);
    double[] var79 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var79);
    double[] var82 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var82);
    double[] var84 = org.apache.commons.math3.util.MathArrays.ebeDivide(var79, var82);
    double[] var86 = org.apache.commons.math3.util.MathArrays.normalizeArray(var79, 100.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var87 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var50, var61, var79);
    boolean var88 = org.apache.commons.math3.util.MathArrays.equals(var45, var79);
    double[] var90 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 1042);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test159"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 1543116286);
//     double var6 = var0.nextCauchy(201.10872070139894d, 219.9831171065414d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1435861722);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1012.0188911657001d);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test160"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(5829916);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test161"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 1.7231465203852943d, 315951.04828560806d, 98.2718673777206d, 8.17775810994563d, 243.3065357588753d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3.1051089216971077E7d);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test162"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
    long var4 = var3.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    double var8 = var5.nextBeta(2.5523831119597444d, 6.7068743582446215d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-414028722650554365L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.13191143203599848d);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test163"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var3 = var2.getValue();
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
    java.lang.Object var5 = var4.getKey();
    java.lang.Object var6 = var4.getSecond();
    org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair(var4);
    java.lang.Object var8 = var4.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1L+ "'", var3.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1L)+ "'", var5.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1L+ "'", var6.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1L)+ "'", var8.equals((-1L)));

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test164"); }


    float[] var0 = null;
    float[] var1 = new float[] { };
    boolean var2 = org.apache.commons.math3.util.MathArrays.equals(var0, var1);
    float[] var5 = new float[] { 0.0f, (-1.0f)};
    float[] var6 = null;
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var6);
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var0, var5);
    float[] var9 = null;
    float[] var10 = new float[] { };
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var9, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var5, var10);
    float[] var15 = new float[] { 0.0f, (-1.0f)};
    float[] var16 = null;
    boolean var17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var15, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var15);
    float[] var19 = null;
    float[] var20 = new float[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var19, var20);
    float[] var22 = null;
    float[] var23 = new float[] { };
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var22, var23);
    float[] var27 = new float[] { 0.0f, (-1.0f)};
    float[] var28 = null;
    boolean var29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var27, var28);
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var22, var27);
    float[] var31 = null;
    float[] var32 = new float[] { };
    boolean var33 = org.apache.commons.math3.util.MathArrays.equals(var31, var32);
    boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var27, var32);
    float[] var35 = null;
    float[] var36 = new float[] { };
    boolean var37 = org.apache.commons.math3.util.MathArrays.equals(var35, var36);
    float[] var40 = new float[] { 0.0f, (-1.0f)};
    float[] var41 = null;
    boolean var42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var40, var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var35, var40);
    float[] var44 = null;
    float[] var45 = new float[] { };
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var44, var45);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var40, var45);
    boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var27, var40);
    boolean var49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var40);
    float[] var50 = new float[] { };
    boolean var51 = org.apache.commons.math3.util.MathArrays.equals(var20, var50);
    boolean var52 = org.apache.commons.math3.util.MathArrays.equals(var15, var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test165"); }


    java.lang.Number var0 = null;
    java.lang.Comparable[] var5 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var6, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(byte)100, (java.lang.Object[])var5);
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var10, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    boolean var15 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var13, true);
    double[] var17 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var17);
    double[] var20 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double[] var22 = org.apache.commons.math3.util.MathArrays.ebeDivide(var17, var20);
    org.apache.commons.math3.util.MathArrays.checkOrder(var22);
    org.apache.commons.math3.util.MathArrays.checkOrder(var22);
    double[] var26 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var22, var26);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var32 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.3220963206821523d, (java.lang.Number)299.89733044110505d, 8);
    int var33 = var32.getIndex();
    org.apache.commons.math3.exception.util.ExceptionContext var34 = var32.getContext();
    org.apache.commons.math3.util.MathArrays.OrderDirection var35 = var32.getDirection();
    boolean var38 = org.apache.commons.math3.util.MathArrays.checkOrder(var22, var35, true, false);
    boolean var40 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var35, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var42 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)1.7551784210590078d, 1422716669, var35, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test166"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var7 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.002349480672631077d, (java.lang.Number)5, true);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    double[] var10 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var10);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double[] var15 = org.apache.commons.math3.util.MathArrays.ebeDivide(var10, var13);
    double[] var16 = new double[] { };
    double[] var18 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var18);
    double var20 = org.apache.commons.math3.util.MathArrays.distance1(var16, var18);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var18, var21, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var18);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var25 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var15, var18);
    org.apache.commons.math3.util.MathArrays.OrderDirection var26 = null;
    double[] var27 = new double[] { };
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var27, var29);
    double[] var33 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var33);
    double var35 = org.apache.commons.math3.util.MathArrays.distance1(var27, var33);
    org.apache.commons.math3.util.MathArrays.OrderDirection var36 = null;
    double[] var38 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var38);
    double[] var41 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var41);
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeDivide(var38, var41);
    double[][] var44 = new double[][] { var41};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var33, var36, var44);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var15, var26, var44);
    org.apache.commons.math3.exception.MathIllegalStateException var47 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var8, (java.lang.Object[])var44);
    org.apache.commons.math3.exception.MathIllegalStateException var48 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var44);
    org.apache.commons.math3.exception.NotFiniteNumberException var49 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, var2, (java.lang.Object[])var44);
    org.apache.commons.math3.exception.MathArithmeticException var50 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test167"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    var16.reseedRandomGenerator(99185013732155984L);
    boolean var19 = var16.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test168"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var20 = var16.sample();
    double var21 = var16.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test169"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextWeibull(1.6486550157904805d, 100.0d);
//     double var7 = var0.nextGaussian(99.2782319289774d, 0.05877392154888082d);
//     double var9 = var0.nextExponential(3.0896657965554652d);
//     double var11 = var0.nextChiSquare(0.5870243826356631d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 54.163816970407574d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 99.18428891980028d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.27390618548170964d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.07159779612566966d);
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test170"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var2.nextWeibull(0.2683148062047325d, (-1.6720706382152082d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test171"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.density(1.2316468095843844d);
    double var23 = var16.inverseCumulativeProbability(1.0d);
    double var24 = var16.getSupportLowerBound();
    var16.reseedRandomGenerator((-115747454037461536L));
    double var28 = var16.density(63.87259279267451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test172"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     double[] var1 = new double[] { };
//     double[] var3 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var3);
//     double var5 = org.apache.commons.math3.util.MathArrays.distance1(var1, var3);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var3, var6, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var3);
//     double[] var11 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var11);
//     double[] var14 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var14);
//     double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var11, var14);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var16);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var16);
//     double[] var20 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var20);
//     boolean var22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var16, var20);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var26 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.3220963206821523d, (java.lang.Number)299.89733044110505d, 8);
//     int var27 = var26.getIndex();
//     org.apache.commons.math3.exception.util.ExceptionContext var28 = var26.getContext();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var29 = var26.getDirection();
//     boolean var32 = org.apache.commons.math3.util.MathArrays.checkOrder(var16, var29, true, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var3, var29, true);
//     boolean var36 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var0, var29, true);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test173"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)98.38153633363427d, (java.lang.Number)63.26735447683985d, (-63560251));
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = var3.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test174"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var18 = var16.density(99.02988657003175d);
    boolean var19 = var16.isSupportUpperBoundInclusive();
    double var21 = var16.probability(263.1966961055d);
    boolean var22 = var16.isSupportUpperBoundInclusive();
    var16.reseedRandomGenerator((-4848980640512349401L));
    double var25 = var16.getSupportUpperBound();
    double var26 = var16.getNumericalVariance();
    double var27 = var16.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1.0d);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test175"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.density(1.2316468095843844d);
    double var22 = var16.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test176"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-53.64296460224014d), (java.lang.Number)3.72011415598965E-4d, true);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test177"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(9);
//     var0.reSeedSecure();
//     java.lang.String var5 = var0.nextSecureHexString(92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "029b75e72"+ "'", var2.equals("029b75e72"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "7e44c1e0d645c0bb69ee22afcf34f9a5c30c6354fc5ee69a028bcad78c1ec3a918e2c17d85ce422369189a7b5547"+ "'", var5.equals("7e44c1e0d645c0bb69ee22afcf34f9a5c30c6354fc5ee69a028bcad78c1ec3a918e2c17d85ce422369189a7b5547"));
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test178"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    float var2 = var1.nextFloat();
    long var3 = var1.nextLong();
    var1.clear();
    int var5 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877557f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4286978429002110849L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 449574259);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test179"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.3220963206821523d, (java.lang.Number)299.89733044110505d, 8);
    org.apache.commons.math3.exception.NotANumberException var4 = new org.apache.commons.math3.exception.NotANumberException();
    var3.addSuppressed((java.lang.Throwable)var4);
    int var6 = var3.getIndex();
    java.lang.Number var7 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1.3220963206821523d+ "'", var7.equals(1.3220963206821523d));

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test180"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
    long var4 = var3.nextLong();
    float var5 = var3.nextFloat();
    int var7 = var3.nextInt(171292551);
    var3.setSeed((-4368667302258025984L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-414028722650554365L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.15595806f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 170315463);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test181"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var3 = var2.getValue();
    java.lang.Object var4 = null;
    boolean var5 = var2.equals(var4);
    java.lang.Object var6 = var2.getValue();
    org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1L+ "'", var3.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1L+ "'", var6.equals(1L));

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test182"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(2074243331);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test183"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(3);
    int[] var8 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var8);
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
    int[] var13 = new int[] { 100};
    int[] var15 = new int[] { 100};
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
    int var17 = org.apache.commons.math3.util.MathArrays.distanceInf(var13, var15);
    int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
    org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(var15);
    int[] var21 = new int[] { 100};
    int[] var23 = new int[] { 100};
    int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
    int var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var21, var23);
    int[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
    org.apache.commons.math3.random.Well19937c var27 = new org.apache.commons.math3.random.Well19937c(var23);
    int[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 10);
    int var30 = org.apache.commons.math3.util.MathArrays.distance1(var15, var23);
    int var31 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var23);
    var2.setSeed(var23);
    org.apache.commons.math3.random.RandomDataGenerator var33 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    var2.setSeed(941109788);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test184"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.381282650726439d, 98.43713016096305d, 54.163816970407574d, 3.8607175106694114d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 246.64356654002103d);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test185"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     var0.reSeedSecure((-1L));
//     int var14 = var0.nextZipf(9, 210.26801214771172d);
//     double var17 = var0.nextGaussian((-55.973096495762256d), 98.45377290426184d);
//     double var20 = var0.nextGamma(114.41944065908152d, 1.3043522247598183d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("708b", "a3a5196b75");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 183.4801762991831d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "60dfd93722"+ "'", var9.equals("60dfd93722"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-31.470611035046662d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 161.86742821318956d);
// 
//   }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test186"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     long var3 = var1.nextPoisson(33094.264042976356d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 32962L);
// 
//   }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test187"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     int var4 = var0.nextInt(0, 10);
//     double var7 = var0.nextGaussian(1.176542981693557d, 1.8507918026021757d);
//     long var10 = var0.nextLong((-414028722650554365L), 132L);
//     long var13 = var0.nextSecureLong((-190865323983646368L), 1L);
//     double var17 = var0.nextUniform(2.4464769860739253d, 290.8108077325299d, false);
//     double var20 = var0.nextGamma(110.67903653979582d, 290.7302955783791d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.5993730517989233d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-335397996283136768L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-100298934681925008L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 269.9724381400105d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 34277.059995789336d);
// 
//   }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test188"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     double var9 = var1.nextF(98.34128277750061d, 98.42176142483318d);
//     double var11 = var1.nextChiSquare(1.0847091605564438d);
//     double var15 = var1.nextUniform(0.002349480672631077d, 42.56784123878263d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var17 = var1.nextSecureHexString((-263022986));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.98041031739933d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "4"+ "'", var6.equals("4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.3910578152278439d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.02558108090388583d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 28.614613333440875d);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test189"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    int var4 = var1.nextZipf(98, 284.941661635924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test190"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextInt((-1), 8);
//     int var10 = var0.nextInt((-1), 6);
//     long var12 = var0.nextPoisson(0.9179650267580631d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 184.21281976213734d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test191"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.checkOrder(var6, var9, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    boolean var15 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var13, false);
    double[] var16 = new double[] { };
    double[] var18 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var18);
    double var20 = org.apache.commons.math3.util.MathArrays.distance1(var16, var18);
    double[] var22 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var16, var22);
    double var25 = org.apache.commons.math3.util.MathArrays.safeNorm(var22);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var6, var22);
    double[] var27 = new double[] { };
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var27, var29);
    double[] var33 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var33);
    double var35 = org.apache.commons.math3.util.MathArrays.distance1(var27, var33);
    org.apache.commons.math3.util.MathArrays.OrderDirection var36 = null;
    boolean var39 = org.apache.commons.math3.util.MathArrays.checkOrder(var33, var36, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var40 = null;
    boolean var42 = org.apache.commons.math3.util.MathArrays.isMonotonic(var33, var40, false);
    double[] var44 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var44);
    double[] var47 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var47);
    double[] var49 = org.apache.commons.math3.util.MathArrays.ebeDivide(var44, var47);
    double[] var50 = new double[] { };
    double[] var52 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var52);
    double var54 = org.apache.commons.math3.util.MathArrays.distance1(var50, var52);
    org.apache.commons.math3.util.MathArrays.checkPositive(var52);
    double var56 = org.apache.commons.math3.util.MathArrays.safeNorm(var52);
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeAdd(var44, var52);
    org.apache.commons.math3.util.MathArrays.OrderDirection var58 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var52, var58, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var61 = null;
    boolean var64 = org.apache.commons.math3.util.MathArrays.checkOrder(var52, var61, true, false);
    double[] var65 = org.apache.commons.math3.util.MathArrays.ebeDivide(var33, var52);
    double var66 = org.apache.commons.math3.util.MathArrays.distance(var6, var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test192"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportUpperBound();
    double var22 = var16.cumulativeProbability(0.02678742855378105d, 8871.347843840067d);
    double var23 = var16.getSupportLowerBound();
    double[] var25 = var16.sample(72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test193"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var17 = null;
    double[] var18 = new double[] { };
    double[] var20 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double var22 = org.apache.commons.math3.util.MathArrays.distance1(var18, var20);
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var18, var24);
    org.apache.commons.math3.util.MathArrays.OrderDirection var27 = null;
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double[] var32 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var32);
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeDivide(var29, var32);
    double[][] var35 = new double[][] { var32};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var24, var27, var35);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var6, var17, var35);
    double[] var39 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var39);
    double[] var42 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeDivide(var39, var42);
    double[] var45 = new double[] { };
    double[] var47 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var47);
    double var49 = org.apache.commons.math3.util.MathArrays.distance1(var45, var47);
    org.apache.commons.math3.util.MathArrays.checkPositive(var47);
    double var51 = org.apache.commons.math3.util.MathArrays.safeNorm(var47);
    double[] var52 = org.apache.commons.math3.util.MathArrays.ebeAdd(var39, var47);
    double[] var53 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var6, var52);
    double[] var54 = org.apache.commons.math3.util.MathArrays.copyOf(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test194"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var3 = var2.getValue();
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c();
    var5.setSeed(6);
    int[] var9 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var9);
    int var11 = var10.nextInt();
    long var12 = var10.nextLong();
    byte[] var13 = new byte[] { };
    var10.nextBytes(var13);
    var5.nextBytes(var13);
    int var16 = var5.nextInt();
    boolean var17 = var2.equals((java.lang.Object)var16);
    boolean var19 = var2.equals((java.lang.Object)9.927198205545196d);
    java.lang.Object var20 = var2.getFirst();
    java.lang.Object var21 = var2.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1L+ "'", var3.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1205512795);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + (-1L)+ "'", var20.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + (-1L)+ "'", var21.equals((-1L)));

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test195"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var6);
    double[] var10 = new double[] { };
    double[] var12 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance1(var10, var12);
    double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    double[] var16 = new double[] { };
    double[] var18 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var18);
    double var20 = org.apache.commons.math3.util.MathArrays.distance1(var16, var18);
    double[] var22 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var16, var22);
    org.apache.commons.math3.util.MathArrays.OrderDirection var25 = null;
    boolean var28 = org.apache.commons.math3.util.MathArrays.checkOrder(var22, var25, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var29 = null;
    boolean var31 = org.apache.commons.math3.util.MathArrays.isMonotonic(var22, var29, false);
    double[] var32 = new double[] { };
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var32, var34);
    double[] var38 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var38);
    double var40 = org.apache.commons.math3.util.MathArrays.distance1(var32, var38);
    double var41 = org.apache.commons.math3.util.MathArrays.safeNorm(var38);
    double[] var42 = org.apache.commons.math3.util.MathArrays.ebeDivide(var22, var38);
    double var43 = org.apache.commons.math3.util.MathArrays.distance(var15, var42);
    double[] var45 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var45);
    double[] var48 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeDivide(var45, var48);
    double[] var51 = new double[] { };
    double[] var53 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var53);
    double var55 = org.apache.commons.math3.util.MathArrays.distance1(var51, var53);
    org.apache.commons.math3.util.MathArrays.OrderDirection var56 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var53, var56, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var53);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var60 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var50, var53);
    org.apache.commons.math3.util.MathArrays.OrderDirection var61 = null;
    double[] var62 = new double[] { };
    double[] var64 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var64);
    double var66 = org.apache.commons.math3.util.MathArrays.distance1(var62, var64);
    double[] var68 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var68);
    double var70 = org.apache.commons.math3.util.MathArrays.distance1(var62, var68);
    org.apache.commons.math3.util.MathArrays.OrderDirection var71 = null;
    double[] var73 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var73);
    double[] var76 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var76);
    double[] var78 = org.apache.commons.math3.util.MathArrays.ebeDivide(var73, var76);
    double[][] var79 = new double[][] { var76};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var68, var71, var79);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var50, var61, var79);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var82 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var42, var50);
    double[] var83 = org.apache.commons.math3.util.MathArrays.ebeAdd(var6, var42);
    org.apache.commons.math3.exception.NumberIsTooLargeException var87 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.002349480672631077d, (java.lang.Number)5, true);
    org.apache.commons.math3.util.Pair var88 = new org.apache.commons.math3.util.Pair((java.lang.Object)var83, (java.lang.Object)var87);
    java.lang.Object var89 = var88.getFirst();
    org.apache.commons.math3.util.Pair var90 = new org.apache.commons.math3.util.Pair(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test196"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(99.31693111660628d, 19590.396821270788d, 206.49499921415622d, 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1945864.5866443478d);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test197"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.43006573376018903d), (-0.8305377380798146d), 0.7473807753292526d, 0.05949668097310608d, 1.4548538617229418d, 98.46443093966917d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 143.65301009222762d);

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test198"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(9);
//     var0.reSeedSecure();
//     int var6 = var0.nextZipf(10, 120.22721817250748d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "9a83a2943"+ "'", var2.equals("9a83a2943"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test199"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)100.26932579100311d);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test200"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)110.63436881401245d);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test201"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)85.18111844245895d, (java.lang.Number)1, true);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test202"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var3 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10, (java.lang.Number)98.47480055949d, var3);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test203"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(short)1, (java.lang.Number)(-1.0f), false);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);

  }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test204"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     var2.clear();
//     var2.setSeed(100L);
//     long var7 = var2.nextLong();
//     var2.setSeed(43059505226525080L);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl();
//     var10.reSeedSecure();
//     double var14 = var10.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var17 = var10.nextZipf(8, 98.28206305872513d);
//     int[] var20 = var10.nextPermutation(9, 4);
//     org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(var20);
//     int[] var23 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(var23);
//     int var25 = var24.nextInt();
//     long var26 = var24.nextLong();
//     double var27 = var24.nextGaussian();
//     int[] var29 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(var29);
//     int var31 = var30.nextInt();
//     long var32 = var30.nextLong();
//     byte[] var33 = new byte[] { };
//     var30.nextBytes(var33);
//     var24.nextBytes(var33);
//     var21.nextBytes(var33);
//     var2.nextBytes(var33);
//     var2.setSeed(171292551);
//     double var40 = var2.nextDouble();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3513799009476651814L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 232.51858300200655d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 259766232686583471L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.7157990521557022d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 259766232686583471L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 0.41182657728444005d);
// 
//   }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test205"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     int var4 = var0.nextInt(0, 10);
//     double var7 = var0.nextGaussian(1.176542981693557d, 1.8507918026021757d);
//     long var10 = var0.nextLong((-414028722650554365L), 132L);
//     long var13 = var0.nextSecureLong((-190865323983646368L), 1L);
//     double var17 = var0.nextUniform(2.4464769860739253d, 290.8108077325299d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var20 = var0.nextPermutation(0, 1435861722);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.4063032729800744d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-331787701474401728L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-73068929849611200L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 261.63423404030465d);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test206"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var2 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test207"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     int var6 = var0.nextPascal(1, 0.0d);
//     double var9 = var0.nextWeibull(9843.530265446541d, 70384.99599681215d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 70388.95841125153d);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test208"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.checkOrder(var6, var9, false, true);
    double[] var13 = new double[] { };
    double[] var15 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var15);
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var13, var15);
    double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    double[] var19 = new double[] { };
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double var23 = org.apache.commons.math3.util.MathArrays.distance1(var19, var21);
    double[] var25 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var19, var25);
    org.apache.commons.math3.util.MathArrays.OrderDirection var28 = null;
    boolean var31 = org.apache.commons.math3.util.MathArrays.checkOrder(var25, var28, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var32 = null;
    boolean var34 = org.apache.commons.math3.util.MathArrays.isMonotonic(var25, var32, false);
    double[] var35 = new double[] { };
    double[] var37 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance1(var35, var37);
    double[] var41 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var41);
    double var43 = org.apache.commons.math3.util.MathArrays.distance1(var35, var41);
    double var44 = org.apache.commons.math3.util.MathArrays.safeNorm(var41);
    double[] var45 = org.apache.commons.math3.util.MathArrays.ebeDivide(var25, var41);
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var18, var45);
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var6, var45);
    double[] var48 = new double[] { };
    double[] var50 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var50);
    double var52 = org.apache.commons.math3.util.MathArrays.distance1(var48, var50);
    org.apache.commons.math3.util.MathArrays.checkPositive(var50);
    double var54 = org.apache.commons.math3.util.MathArrays.safeNorm(var50);
    double[] var56 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var56);
    double[] var59 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var59);
    double[] var61 = org.apache.commons.math3.util.MathArrays.ebeDivide(var56, var59);
    double[] var62 = new double[] { };
    double[] var64 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var64);
    double var66 = org.apache.commons.math3.util.MathArrays.distance1(var62, var64);
    org.apache.commons.math3.util.MathArrays.checkPositive(var64);
    double var68 = org.apache.commons.math3.util.MathArrays.safeNorm(var64);
    double[] var69 = org.apache.commons.math3.util.MathArrays.ebeAdd(var56, var64);
    double[] var71 = org.apache.commons.math3.util.MathArrays.normalizeArray(var69, 0.0d);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var50, var69);
    double[] var74 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var74);
    double[] var77 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var77);
    double[] var79 = org.apache.commons.math3.util.MathArrays.ebeDivide(var74, var77);
    double[] var80 = new double[] { };
    double[] var82 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var82);
    double var84 = org.apache.commons.math3.util.MathArrays.distance1(var80, var82);
    org.apache.commons.math3.util.MathArrays.checkPositive(var82);
    double var86 = org.apache.commons.math3.util.MathArrays.safeNorm(var82);
    double[] var87 = org.apache.commons.math3.util.MathArrays.ebeAdd(var74, var82);
    org.apache.commons.math3.util.MathArrays.OrderDirection var88 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var82, var88, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var91 = null;
    boolean var94 = org.apache.commons.math3.util.MathArrays.checkOrder(var82, var91, true, false);
    double[] var95 = org.apache.commons.math3.util.MathArrays.ebeDivide(var69, var82);
    boolean var96 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var45, var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == false);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test209"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.33112665569960686d);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test210"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)30, var1, true);

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test211"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     double var6 = var1.nextChiSquare(9999.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var1.nextChiSquare((-0.09645555352364929d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10047.776003183593d);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test212"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)98.43713016096305d, (java.lang.Number)9.834337537501083d, 5);
    java.lang.Number var4 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 9.834337537501083d+ "'", var4.equals(9.834337537501083d));

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test213"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     long var7 = var1.nextSecureLong((-1L), 152600911433040288L);
//     double var9 = var1.nextChiSquare(0.01408195728001127d);
//     int var12 = var1.nextZipf(10, 1.636388788949819E-6d);
//     double var15 = var1.nextF(1.4815958130930773d, 299.89733044110505d);
//     double var18 = var1.nextGamma(0.4920034589828977d, 0.1490436810544255d);
//     double var21 = var1.nextGaussian(10.035931213833267d, 2.791785408803186d);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 105534036686710896L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 6.040420665241163E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.8397038590583182d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.3837562474280359d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 9.992660260869647d);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test214"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Comparable[] var5 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var6, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(byte)100, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var2, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(-115747454037461536L), (java.lang.Object[])var5);
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    java.lang.Number var14 = null;
    java.lang.Comparable[] var16 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var17 = null;
    boolean var19 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var16, var17, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var20 = new org.apache.commons.math3.exception.NotFiniteNumberException(var14, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.NotFiniteNumberException var21 = new org.apache.commons.math3.exception.NotFiniteNumberException(var12, (java.lang.Number)1010.0d, (java.lang.Object[])var16);
    org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
    boolean var24 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var16, var22, false);
    org.apache.commons.math3.util.Pair var26 = new org.apache.commons.math3.util.Pair((java.lang.Object)var16, (java.lang.Object)183.2309326428994d);
    java.lang.Comparable[] var28 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var29 = null;
    boolean var31 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var28, var29, true);
    java.lang.Number var32 = null;
    java.lang.Comparable[] var34 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var35 = null;
    boolean var37 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var34, var35, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var38 = new org.apache.commons.math3.exception.NotFiniteNumberException(var32, (java.lang.Object[])var34);
    org.apache.commons.math3.util.MathArrays.OrderDirection var39 = null;
    boolean var41 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var34, var39, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var45 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.3220963206821523d, (java.lang.Number)299.89733044110505d, 8);
    int var46 = var45.getIndex();
    org.apache.commons.math3.exception.util.ExceptionContext var47 = var45.getContext();
    org.apache.commons.math3.util.MathArrays.OrderDirection var48 = var45.getDirection();
    boolean var50 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var34, var48, false);
    boolean var52 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var28, var48, false);
    boolean var54 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var16, var48, false);
    java.lang.Comparable[] var56 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var57 = null;
    boolean var59 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var56, var57, true);
    java.lang.Number var60 = null;
    java.lang.Comparable[] var62 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var63 = null;
    boolean var65 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var62, var63, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var66 = new org.apache.commons.math3.exception.NotFiniteNumberException(var60, (java.lang.Object[])var62);
    org.apache.commons.math3.util.MathArrays.OrderDirection var67 = null;
    boolean var69 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var62, var67, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var73 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.3220963206821523d, (java.lang.Number)299.89733044110505d, 8);
    int var74 = var73.getIndex();
    org.apache.commons.math3.exception.util.ExceptionContext var75 = var73.getContext();
    org.apache.commons.math3.util.MathArrays.OrderDirection var76 = var73.getDirection();
    boolean var78 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var62, var76, false);
    boolean var80 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var56, var76, false);
    boolean var82 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var16, var76, false);
    boolean var84 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var76, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == true);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test215"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(183.75983595296293d, (-1.557125034392254d), 100.49580968713244d, (-37.441946953176824d), 201.76160301238804d, 0.5742251148047507d, 0.7644474751903642d, 9934.45675172877d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3661.3311446995654d);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test216"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     var0.reSeedSecure((-1L));
//     long var13 = var0.nextPoisson(121.6356374977755d);
//     var0.reSeed(112L);
//     org.apache.commons.math3.distribution.IntegerDistribution var16 = null;
//     int var17 = var0.nextInversionDeviate(var16);
// 
//   }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test217"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var10 = var1.nextWeibull(0.9846580496679653d, 0.7157990521557022d);
//     java.lang.String var12 = var1.nextSecureHexString(4);
//     long var15 = var1.nextSecureLong(0L, 132L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.54397791347651d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 80.97983064202243d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.6528853310026566d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "ff39"+ "'", var12.equals("ff39"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 8L);
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test218"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)10087.891121411412d);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test219"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    double var4 = var2.nextDouble();
    var2.setSeed((-1));
    var2.setSeed(0L);
    long var9 = var2.nextLong();
    var2.setSeed(10);
    double var12 = var2.nextDouble();
    int var14 = var2.nextInt(6);
    int[] var16 = new int[] { 100};
    int[] var18 = new int[] { 100};
    int[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var18);
    int var20 = org.apache.commons.math3.util.MathArrays.distanceInf(var16, var18);
    int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var18);
    int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var18);
    var2.setSeed(var18);
    int[] var25 = new int[] { 100};
    int[] var27 = new int[] { 100};
    int[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var27);
    int var29 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var27);
    int[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var27);
    org.apache.commons.math3.random.Well19937c var31 = new org.apache.commons.math3.random.Well19937c(var27);
    int[] var33 = new int[] { 100};
    int[] var35 = new int[] { 100};
    int[] var36 = org.apache.commons.math3.util.MathArrays.copyOf(var35);
    int var37 = org.apache.commons.math3.util.MathArrays.distanceInf(var33, var35);
    int[] var38 = org.apache.commons.math3.util.MathArrays.copyOf(var35);
    org.apache.commons.math3.random.Well19937c var39 = new org.apache.commons.math3.random.Well19937c(var35);
    int[] var41 = org.apache.commons.math3.util.MathArrays.copyOf(var35, 10);
    int var42 = org.apache.commons.math3.util.MathArrays.distance1(var27, var35);
    org.apache.commons.math3.random.Well19937c var43 = new org.apache.commons.math3.random.Well19937c(var35);
    int[] var45 = new int[] { 100};
    int[] var47 = new int[] { 100};
    int[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var47);
    int var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var45, var47);
    int[] var51 = new int[] { 100};
    int[] var52 = org.apache.commons.math3.util.MathArrays.copyOf(var51);
    int[] var54 = org.apache.commons.math3.util.MathArrays.copyOf(var51, 6);
    int var55 = org.apache.commons.math3.util.MathArrays.distanceInf(var45, var54);
    int var56 = org.apache.commons.math3.util.MathArrays.distance1(var35, var45);
    int var57 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var45);
    int[] var59 = new int[] { 100};
    int[] var60 = org.apache.commons.math3.util.MathArrays.copyOf(var59);
    int[] var62 = org.apache.commons.math3.util.MathArrays.copyOf(var59, 5);
    int var63 = org.apache.commons.math3.util.MathArrays.distanceInf(var45, var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.01408195728001127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-4736355256857903122L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.761957659063951d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test220"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure(10L);
    var1.reSeedSecure();
    var1.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var8 = var1.nextPermutation((-163349561), (-549596712));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test221"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     double var4 = var2.nextDouble();
//     var2.setSeed((-1));
//     var2.setSeed(0L);
//     long var9 = var2.nextLong();
//     var2.setSeed(10);
//     var2.clear();
//     org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
//     double var16 = var13.nextUniform(98.42888798257793d, 15938.704455172932d);
//     int var19 = var13.nextSecureInt((-1128991284), 9);
//     var13.reSeedSecure();
//     int var23 = var13.nextBinomial(1667864798, 0.003494754140413766d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var13.nextExponential((-0.09645555352364929d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.01408195728001127d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-4736355256857903122L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 12168.048178086838d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-755832364));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 5829916);
// 
//   }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test222"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     java.lang.String var6 = var1.nextHexString(10);
//     double var9 = var1.nextUniform(2.1202883854072287d, 444.0293055330172d);
//     double var12 = var1.nextUniform(0.7090371711746789d, 276.2030684411809d);
//     int var16 = var1.nextHypergeometric(809123836, 733888788, 11387117);
//     long var19 = var1.nextLong((-1680313010742393856L), 10L);
//     double var22 = var1.nextBeta(1012.0188911657001d, 0.2486082102270052d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "a5ef54c5da"+ "'", var6.equals("a5ef54c5da"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 193.10345814142545d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 196.55142473031393d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 235);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-1359128276736088832L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.9999997562243867d);
// 
//   }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test223"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     long var7 = var1.nextSecureLong((-1L), 152600911433040288L);
//     double var9 = var1.nextChiSquare(0.01408195728001127d);
//     int var12 = var1.nextZipf(10, 1.636388788949819E-6d);
//     int var15 = var1.nextInt((-63560251), 827167750);
//     java.lang.String var17 = var1.nextSecureHexString(73);
//     int var20 = var1.nextInt((-125716405), 170315463);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 139765032506905360L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.2646993035770478E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 598160383);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "60ea384771a7c3bb879173ada7e66557088801d15ad365e599a87f263bd88cbff0eea07d7"+ "'", var17.equals("60ea384771a7c3bb879173ada7e66557088801d15ad365e599a87f263bd88cbff0eea07d7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 25361047);
// 
//   }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test224"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     long var9 = var0.nextLong((-4736355256857903122L), (-414028722650554365L));
//     double var12 = var0.nextF(23.41031146092985d, 1.2000918311981499d);
//     double var15 = var0.nextGaussian(0.2683148062047325d, 9.921853769627177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-77.67142144266026d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-2376362477743198720L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2.132802999842056d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-6.3489703611236115d));
// 
//   }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test225"); }
// 
// 
//     int[] var1 = new int[] { 100};
//     int[] var3 = new int[] { 100};
//     int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
//     int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
//     int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var3);
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 2);
//     org.apache.commons.math3.random.RandomGenerator var10 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var11 = new org.apache.commons.math3.random.RandomDataGenerator(var10);
//     double var14 = var11.nextWeibull(100.0d, 100.0d);
//     java.lang.String var16 = var11.nextSecureHexString(1);
//     double var19 = var11.nextF(98.34128277750061d, 98.42176142483318d);
//     int[] var22 = var11.nextPermutation(1042, 10);
//     int var23 = org.apache.commons.math3.util.MathArrays.distance1(var3, var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 100.74531099207395d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "e"+ "'", var16.equals("e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.1757260803647533d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 657);
// 
//   }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test226"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     int var4 = var0.nextInt(0, 10);
//     double var7 = var0.nextGaussian(1.176542981693557d, 1.8507918026021757d);
//     double var11 = var0.nextUniform(98.47845151091803d, 99.02988657003175d, false);
//     var0.reSeed((-2806187763758602752L));
//     long var15 = var0.nextPoisson(1.2388070620041405d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.901273229528485d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 98.61858895334468d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 3L);
// 
//   }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test227"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)10147.966843902852d, (java.lang.Number)259766232686583471L);

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test228"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     double var6 = var1.nextChiSquare(9999.0d);
//     double var9 = var1.nextCauchy(328.9490202460588d, 5.58882321105828d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10050.740464906617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 321.7681697003433d);
// 
//   }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test229"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextBinomial((-1117175228), 9.879954631323606d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 192.98001287990638d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
// 
//   }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test230"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var9 = var1.nextChiSquare(5.184603928878863d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var1.nextInt(947302421, (-1117175228));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.76578644354043d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 104.84644241458426d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 5.363650552653727d);
// 
//   }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test231"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var1 = new double[] { };
    double[] var3 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var3);
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var1, var3);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var3, var6, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var3);
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    double[] var12 = new double[] { };
    double[] var14 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var14);
    double var16 = org.apache.commons.math3.util.MathArrays.distance1(var12, var14);
    double[] var18 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var18);
    double var20 = org.apache.commons.math3.util.MathArrays.distance1(var12, var18);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    double[] var23 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var23);
    double[] var26 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double[] var28 = org.apache.commons.math3.util.MathArrays.ebeDivide(var23, var26);
    double[][] var29 = new double[][] { var26};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var18, var21, var29);
    org.apache.commons.math3.exception.MathIllegalStateException var31 = new org.apache.commons.math3.exception.MathIllegalStateException(var11, (java.lang.Object[])var29);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var3, var10, var29);
    org.apache.commons.math3.exception.NullArgumentException var33 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test232"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     var0.reSeedSecure();
//     int var10 = var0.nextSecureInt(1, 2);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var13 = var0.nextPermutation(1, 92);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 42.614014695076484d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test233"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 4);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test234"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(8, (-838354274));

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test235"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(98.45317552126936d);
//     var0.reSeedSecure();
//     long var6 = var0.nextSecureLong((-124847318341222864L), 43059505226525080L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextT((-51.266690217526275d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.47043521900722535d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 18005766952934076L);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test236"); }


    float[] var0 = null;
    float[] var1 = new float[] { };
    boolean var2 = org.apache.commons.math3.util.MathArrays.equals(var0, var1);
    float[] var3 = null;
    float[] var4 = new float[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equals(var3, var4);
    float[] var8 = new float[] { 0.0f, (-1.0f)};
    float[] var9 = null;
    boolean var10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var9);
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var3, var8);
    float[] var12 = null;
    float[] var13 = new float[] { };
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var12, var13);
    boolean var15 = org.apache.commons.math3.util.MathArrays.equals(var8, var13);
    float[] var16 = null;
    float[] var17 = new float[] { };
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var16, var17);
    float[] var21 = new float[] { 0.0f, (-1.0f)};
    float[] var22 = null;
    boolean var23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var21, var22);
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var16, var21);
    float[] var25 = null;
    float[] var26 = new float[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var25, var26);
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var21, var26);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var8, var21);
    boolean var30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var1, var21);
    float[] var31 = new float[] { };
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var1, var31);
    float[] var34 = new float[] { 0.0f};
    float[] var35 = null;
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var34, var35);
    boolean var37 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var31, var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test237"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     int var4 = var0.nextInt(0, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var6 = var0.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
// 
//   }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test238"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     long var7 = var1.nextSecureLong((-1L), 152600911433040288L);
//     double var9 = var1.nextChiSquare(0.01408195728001127d);
//     int var12 = var1.nextZipf(10, 1.636388788949819E-6d);
//     double var15 = var1.nextF(1.4815958130930773d, 299.89733044110505d);
//     long var17 = var1.nextPoisson(210.0592310656816d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var1.nextInt(1435861722, (-694891488));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 115729671562132496L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.7684777328095179d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 219L);
// 
//   }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test239"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     double var4 = var2.nextDouble();
//     var2.setSeed((-1));
//     var2.setSeed(0L);
//     long var9 = var2.nextLong();
//     var2.setSeed(10);
//     var2.clear();
//     org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
//     double var16 = var13.nextUniform(98.42888798257793d, 15938.704455172932d);
//     int var19 = var13.nextSecureInt((-1128991284), 9);
//     var13.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var13.nextWeibull((-0.09645555352364929d), 290.83149155850026d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.01408195728001127d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-4736355256857903122L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 12168.048178086838d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-698218708));
// 
//   }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test240"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var3 = var0.nextExponential(0.2683148062047325d);
//     double var7 = var0.nextUniform((-37.441946953176824d), 37.394228706165585d, false);
//     long var10 = var0.nextSecureLong((-3981045582546589696L), (-183662784990199104L));
//     double[] var12 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var12);
//     double[] var15 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var15);
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var15);
//     double[] var18 = new double[] { };
//     double[] var20 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var20);
//     double var22 = org.apache.commons.math3.util.MathArrays.distance1(var18, var20);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var23 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var20, var23, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var20);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var27 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var17, var20);
//     double[] var29 = var27.sample(9);
//     double var30 = var27.getSupportLowerBound();
//     boolean var31 = var27.isSupportUpperBoundInclusive();
//     double var33 = var27.probability(0.0d);
//     double var34 = var27.getSupportLowerBound();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var35 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var27);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.4307547345072399d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.6240962668616774d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-2418201848870054400L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1.0d);
// 
//   }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test241"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var12 = var0.nextGaussian(290.77256675474683d, 0.05877392154888082d);
//     double var15 = var0.nextGaussian(0.01360821383479298d, 98.78946634923011d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextGamma(1.282853271652816E-9d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 26.778083921613472d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.28325561512337816d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 290.72403223334334d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-131.1283641852272d));
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test242"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var18 = var16.density(99.02988657003175d);
    boolean var19 = var16.isSupportUpperBoundInclusive();
    double var20 = var16.sample();
    double var21 = var16.sample();
    double var23 = var16.density(1.908642352606886d);
    boolean var24 = var16.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test243"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.checkOrder(var6, var9, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    boolean var15 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var13, false);
    double[] var17 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var17);
    double[] var20 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double[] var22 = org.apache.commons.math3.util.MathArrays.ebeDivide(var17, var20);
    double[] var23 = new double[] { };
    double[] var25 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var23, var25);
    org.apache.commons.math3.util.MathArrays.checkPositive(var25);
    double var29 = org.apache.commons.math3.util.MathArrays.safeNorm(var25);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeAdd(var17, var25);
    org.apache.commons.math3.util.MathArrays.OrderDirection var31 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var25, var31, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var34 = null;
    boolean var37 = org.apache.commons.math3.util.MathArrays.checkOrder(var25, var34, true, false);
    double[] var38 = org.apache.commons.math3.util.MathArrays.ebeDivide(var6, var25);
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test244"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     double var8 = var1.nextUniform(1.0d, 1.2388070620041405d, false);
//     double var11 = var1.nextCauchy(0.5104454862955553d, 97.97864407980379d);
//     int var14 = var1.nextZipf(3, 1.0646160893106429d);
//     long var17 = var1.nextLong((-3981045582546589696L), 3281275508936619520L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.800662302864321d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.2352602841115996d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-61.29164111011201d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2319154327397632000L);
// 
//   }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test245"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     int var4 = var0.nextInt(0, 10);
//     double var7 = var0.nextGaussian(1.176542981693557d, 1.8507918026021757d);
//     double var10 = var0.nextGamma(0.9638486378008077d, 444.0293055330172d);
//     int var13 = var0.nextInt(2080, 2147483647);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextBeta(0.0d, 9.99947034241454d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.847332518067711d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 246.09134531347857d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1640693040);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test246"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    boolean var17 = var16.isSupportLowerBoundInclusive();
    var16.reseedRandomGenerator(6066523849031269L);
    double var21 = var16.density(6.040420665241163E-9d);
    double var22 = var16.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);

  }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test247"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     java.lang.String var6 = var1.nextHexString(10);
//     double var9 = var1.nextUniform(2.1202883854072287d, 444.0293055330172d);
//     double var12 = var1.nextUniform(0.7090371711746789d, 276.2030684411809d);
//     java.lang.String var14 = var1.nextSecureHexString(28);
//     double var16 = var1.nextT(510468.5017838443d);
//     var1.reSeedSecure(95L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "6468365828"+ "'", var6.equals("6468365828"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 350.9276018749162d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 6.403428102043303d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "d330e4622f0eb9c7e906e14cd3ef"+ "'", var14.equals("d330e4622f0eb9c7e906e14cd3ef"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-1.4399496283401882d));
// 
//   }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test248"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     double var4 = var2.nextDouble();
//     var2.setSeed((-1));
//     var2.setSeed(0L);
//     long var9 = var2.nextLong();
//     var2.setSeed(10);
//     int var13 = var2.nextInt(827167750);
//     double var14 = var2.nextDouble();
//     double[] var16 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var16);
//     double[] var19 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var19);
//     double[] var21 = org.apache.commons.math3.util.MathArrays.ebeDivide(var16, var19);
//     double[] var22 = new double[] { };
//     double[] var24 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var24);
//     double var26 = org.apache.commons.math3.util.MathArrays.distance1(var22, var24);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var27 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var24, var27, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var24);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var31 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var21, var24);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var32 = null;
//     double[] var33 = new double[] { };
//     double[] var35 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var35);
//     double var37 = org.apache.commons.math3.util.MathArrays.distance1(var33, var35);
//     double[] var39 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var39);
//     double var41 = org.apache.commons.math3.util.MathArrays.distance1(var33, var39);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var42 = null;
//     double[] var44 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var44);
//     double[] var47 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var47);
//     double[] var49 = org.apache.commons.math3.util.MathArrays.ebeDivide(var44, var47);
//     double[][] var50 = new double[][] { var47};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var39, var42, var50);
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var21, var32, var50);
//     double[] var54 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var54);
//     double[] var57 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var57);
//     double[] var59 = org.apache.commons.math3.util.MathArrays.ebeDivide(var54, var57);
//     double[] var60 = new double[] { };
//     double[] var62 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var62);
//     double var64 = org.apache.commons.math3.util.MathArrays.distance1(var60, var62);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var62);
//     double var66 = org.apache.commons.math3.util.MathArrays.safeNorm(var62);
//     double[] var67 = org.apache.commons.math3.util.MathArrays.ebeAdd(var54, var62);
//     double[] var68 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var21, var67);
//     double[] var69 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var70 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var68, var69);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test249"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(byte)1, var1, (java.lang.Number)(short)0);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getHi();
    java.lang.Number var6 = var3.getLo();
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)100, (java.lang.Number)0.0f, 0, var10, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = var12.getDirection();
    int var14 = var12.getIndex();
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = var12.getDirection();
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = var12.getDirection();
    var3.addSuppressed((java.lang.Throwable)var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)0+ "'", var5.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test250"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     double var7 = var1.nextCauchy(196.71439318138044d, 36.2742304661072d);
//     double var10 = var1.nextWeibull(54.163816970407574d, 0.38568655572031113d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 96.7044327080259d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 186.07313491766945d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.37908985604912354d);
// 
//   }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test251"); }
// 
// 
//     int[] var0 = null;
//     int[] var2 = new int[] { 100};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
//     int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var2, 5);
//     int var6 = org.apache.commons.math3.util.MathArrays.distance1(var0, var5);
// 
//   }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test252"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     int var4 = var0.nextInt(0, 10);
//     double var7 = var0.nextGaussian(1.176542981693557d, 1.8507918026021757d);
//     long var10 = var0.nextLong((-414028722650554365L), 132L);
//     double var12 = var0.nextT(10.056389821547084d);
//     var0.reSeed(132L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextUniform(94.01519101181238d, 0.9386486895449817d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-2.489989219002824d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-331645108232982208L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.007815994501889145d);
// 
//   }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test253"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(98.45317552126936d);
//     double var5 = var0.nextGaussian(0.0d, 92.58889101274673d);
//     int var9 = var0.nextHypergeometric(7, 0, 1);
//     double var12 = var0.nextF(99.35991845990331d, 176.74258553386042d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0479815239874501d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 40.01257739864353d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.9687036154652069d);
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test254"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.checkOrder(var6, var9, false, true);
    double[] var13 = new double[] { };
    double[] var15 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var15);
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var13, var15);
    double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    double[] var19 = new double[] { };
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double var23 = org.apache.commons.math3.util.MathArrays.distance1(var19, var21);
    double[] var25 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var19, var25);
    org.apache.commons.math3.util.MathArrays.OrderDirection var28 = null;
    boolean var31 = org.apache.commons.math3.util.MathArrays.checkOrder(var25, var28, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var32 = null;
    boolean var34 = org.apache.commons.math3.util.MathArrays.isMonotonic(var25, var32, false);
    double[] var35 = new double[] { };
    double[] var37 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance1(var35, var37);
    double[] var41 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var41);
    double var43 = org.apache.commons.math3.util.MathArrays.distance1(var35, var41);
    double var44 = org.apache.commons.math3.util.MathArrays.safeNorm(var41);
    double[] var45 = org.apache.commons.math3.util.MathArrays.ebeDivide(var25, var41);
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var18, var45);
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var6, var45);
    double[] var48 = new double[] { };
    double[] var50 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var50);
    double var52 = org.apache.commons.math3.util.MathArrays.distance1(var48, var50);
    double[] var54 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var48, var54);
    org.apache.commons.math3.util.MathArrays.OrderDirection var57 = null;
    boolean var60 = org.apache.commons.math3.util.MathArrays.checkOrder(var54, var57, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var61 = null;
    boolean var63 = org.apache.commons.math3.util.MathArrays.isMonotonic(var54, var61, false);
    double[] var65 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var65);
    double[] var68 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var68);
    double[] var70 = org.apache.commons.math3.util.MathArrays.ebeDivide(var65, var68);
    double[] var71 = new double[] { };
    double[] var73 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var73);
    double var75 = org.apache.commons.math3.util.MathArrays.distance1(var71, var73);
    org.apache.commons.math3.util.MathArrays.checkPositive(var73);
    double var77 = org.apache.commons.math3.util.MathArrays.safeNorm(var73);
    double[] var78 = org.apache.commons.math3.util.MathArrays.ebeAdd(var65, var73);
    org.apache.commons.math3.util.MathArrays.OrderDirection var79 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var73, var79, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var82 = null;
    boolean var85 = org.apache.commons.math3.util.MathArrays.checkOrder(var73, var82, true, false);
    double[] var86 = org.apache.commons.math3.util.MathArrays.ebeDivide(var54, var73);
    double[] var87 = org.apache.commons.math3.util.MathArrays.ebeAdd(var45, var86);
    double[] var88 = new double[] { };
    double[] var90 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var90);
    double var92 = org.apache.commons.math3.util.MathArrays.distance1(var88, var90);
    double[] var94 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var94);
    double var96 = org.apache.commons.math3.util.MathArrays.distance1(var88, var94);
    double var97 = org.apache.commons.math3.util.MathArrays.safeNorm(var94);
    double var98 = org.apache.commons.math3.util.MathArrays.distance1(var45, var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == 99.0d);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test255"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var0.getContext();
    org.apache.commons.math3.exception.NotPositiveException var4 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)9.95645506445408d);
    var0.addSuppressed((java.lang.Throwable)var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test256"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-1), 30);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test257"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var20 = var16.getNumericalVariance();
    boolean var21 = var16.isSupportLowerBoundInclusive();
    double var22 = var16.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test258"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 100, (-1));
    int var4 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test259"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     var2.clear();
//     var2.setSeed(3);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
//     double var10 = var7.nextUniform(1.204447662875034E-9d, 0.9386486895449817d);
//     double var12 = var7.nextExponential(117.67233364565794d);
//     java.lang.String var14 = var7.nextSecureHexString(73);
//     int[] var17 = var7.nextPermutation(244, 18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.8458037075426783d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 65.32875338235677d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "35c8fdcedd9ea5ebbf38025025da47c1bd4f9bee3e11535b1e06032ef8502683d434732e9"+ "'", var14.equals("35c8fdcedd9ea5ebbf38025025da47c1bd4f9bee3e11535b1e06032ef8502683d434732e9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test260"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
    double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var13);
    double[] var17 = new double[] { };
    double[] var19 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance1(var17, var19);
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var13, var19);
    double[] var25 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var13);
    double[] var26 = new double[] { };
    double[] var28 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var26, var28);
    double[] var32 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distance1(var26, var32);
    org.apache.commons.math3.util.MathArrays.OrderDirection var35 = null;
    boolean var38 = org.apache.commons.math3.util.MathArrays.checkOrder(var32, var35, false, true);
    double[] var40 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var40);
    double[] var43 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var43);
    double[] var45 = org.apache.commons.math3.util.MathArrays.ebeDivide(var40, var43);
    double[] var47 = org.apache.commons.math3.util.MathArrays.normalizeArray(var40, 0.0d);
    double var48 = org.apache.commons.math3.util.MathArrays.distance(var32, var40);
    double[] var49 = org.apache.commons.math3.util.MathArrays.ebeDivide(var25, var32);
    double[] var51 = org.apache.commons.math3.util.MathArrays.copyOf(var49, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test261"); }


    java.lang.Comparable[] var2 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(byte)100, (java.lang.Object[])var2);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var7, false);
    java.lang.Number var10 = null;
    java.lang.Comparable[] var12 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    boolean var15 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var12, var13, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var10, (java.lang.Object[])var12);
    org.apache.commons.math3.util.MathArrays.OrderDirection var17 = null;
    boolean var19 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var12, var17, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var23 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.3220963206821523d, (java.lang.Number)299.89733044110505d, 8);
    int var24 = var23.getIndex();
    org.apache.commons.math3.exception.util.ExceptionContext var25 = var23.getContext();
    org.apache.commons.math3.util.MathArrays.OrderDirection var26 = var23.getDirection();
    boolean var28 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var12, var26, false);
    boolean var30 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var26, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test262"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(6);
    double var3 = var0.nextDouble();
    float var4 = var0.nextFloat();
    var0.setSeed(110321047155187952L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.6709920656782435d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5148401f);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test263"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(30, 7);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test264"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var10 = var1.nextWeibull(0.9846580496679653d, 0.7157990521557022d);
//     java.lang.String var12 = var1.nextHexString(100);
//     long var15 = var1.nextLong((-190865323983646368L), 112L);
//     var1.reSeedSecure();
//     java.util.Collection var17 = null;
//     java.lang.Object[] var19 = var1.nextSample(var17, 98);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test265"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var4 = new long[] { 0L, 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    long[][] var6 = new long[][] { var4};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)98.42888798257793d, (java.lang.Object[])var6);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var6);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test266"); }


    int[] var1 = new int[] { 100};
    int[] var3 = new int[] { 100};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(var3);
    int[] var8 = new int[] { 100};
    int[] var10 = new int[] { 100};
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var10);
    int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var14);
    int[] var17 = new int[] { 100};
    int[] var19 = new int[] { 100};
    int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var19);
    int var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var17, var19);
    int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var19);
    org.apache.commons.math3.random.Well19937c var23 = new org.apache.commons.math3.random.Well19937c(var19);
    int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 10);
    int[] var27 = new int[] { 100};
    int[] var29 = new int[] { 100};
    int[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var29);
    int var31 = org.apache.commons.math3.util.MathArrays.distanceInf(var27, var29);
    int[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29);
    org.apache.commons.math3.random.Well19937c var33 = new org.apache.commons.math3.random.Well19937c(var29);
    int[] var35 = new int[] { 100};
    int[] var37 = new int[] { 100};
    int[] var38 = org.apache.commons.math3.util.MathArrays.copyOf(var37);
    int var39 = org.apache.commons.math3.util.MathArrays.distanceInf(var35, var37);
    int[] var40 = org.apache.commons.math3.util.MathArrays.copyOf(var37);
    org.apache.commons.math3.random.Well19937c var41 = new org.apache.commons.math3.random.Well19937c(var37);
    int[] var43 = org.apache.commons.math3.util.MathArrays.copyOf(var37, 10);
    int var44 = org.apache.commons.math3.util.MathArrays.distance1(var29, var37);
    int var45 = org.apache.commons.math3.util.MathArrays.distanceInf(var19, var29);
    var15.setSeed(var19);
    int var47 = org.apache.commons.math3.util.MathArrays.distance1(var3, var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test267"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    long var4 = var2.nextLong();
    double var5 = var2.nextGaussian();
    double var6 = var2.nextGaussian();
    long var7 = var2.nextLong();
    var2.setSeed(8);
    int[] var11 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var11);
    int var13 = var12.nextInt();
    long var14 = var12.nextLong();
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c();
    var15.setSeed(6);
    int[] var19 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var19);
    int var21 = var20.nextInt();
    long var22 = var20.nextLong();
    byte[] var23 = new byte[] { };
    var20.nextBytes(var23);
    var15.nextBytes(var23);
    var12.nextBytes(var23);
    var2.nextBytes(var23);
    var2.setSeed(99L);
    float var30 = var2.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.7157990521557022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-0.6984489763881883d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 5220799318019361146L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.1240772f);

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test268"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     double var6 = var1.nextChiSquare(9999.0d);
//     int var9 = var1.nextInt((-163349561), 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9968.133343822603d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-18965047));
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test269"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)209.84511029234756d);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test270"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(98.45317552126936d);
//     java.lang.String var4 = var0.nextHexString(5829916);
//     var0.reSeedSecure(111759704996197392L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.2776090540269949d);
// 
//   }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test271"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     var0.reSeedSecure();
//     double var9 = var0.nextT(290.77256675474683d);
//     long var11 = var0.nextPoisson(9.927959811989089d);
//     double var13 = var0.nextT(2.101872816223852d);
//     long var15 = var0.nextPoisson(9.823059185582977d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 93.58772030045712d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.8099798617634248d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.6099235732132524d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 9L);
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test272"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(4, 100);
    int var3 = var2.getDimension();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var2.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test273"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     double var8 = var1.nextUniform(1.0d, 1.2388070620041405d, false);
//     int var11 = var1.nextInt(2, 9);
//     var1.reSeed((-115747454037461536L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var1.nextHypergeometric(171292551, 2147483647, 11387117);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10.116985381461465d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.1689377838324526d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2);
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test274"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.3055322893119356d, (java.lang.Number)(-77.67142144266026d), true);

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test275"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     var0.reSeedSecure((-1L));
//     var0.reSeed(2L);
//     double var16 = var0.nextWeibull(98.46619727159656d, 1.819217204815299d);
//     double var19 = var0.nextCauchy(0.009617299800806443d, 3.670312001858478d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 187.6228243665912d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "aa34d807c8"+ "'", var9.equals("aa34d807c8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.8361073492936983d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 4.548095582400535d);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test276"); }


    float[] var0 = null;
    float[] var1 = new float[] { };
    boolean var2 = org.apache.commons.math3.util.MathArrays.equals(var0, var1);
    float[] var5 = new float[] { 0.0f, (-1.0f)};
    float[] var6 = null;
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var6);
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var0, var5);
    float[] var9 = null;
    float[] var10 = new float[] { };
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var9, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var5, var10);
    float[] var13 = null;
    float[] var14 = new float[] { };
    boolean var15 = org.apache.commons.math3.util.MathArrays.equals(var13, var14);
    float[] var18 = new float[] { 0.0f, (-1.0f)};
    float[] var19 = null;
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var13, var18);
    float[] var22 = null;
    float[] var23 = new float[] { };
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var22, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var18, var23);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var5, var18);
    float[] var29 = new float[] { 0.0f, (-1.0f)};
    float[] var30 = null;
    boolean var31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var29, var30);
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var5, var30);
    float[] var33 = null;
    float[] var34 = new float[] { };
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var33, var34);
    float[] var38 = new float[] { 0.0f, (-1.0f)};
    float[] var39 = null;
    boolean var40 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var38, var39);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var33, var38);
    float[] var42 = null;
    float[] var43 = new float[] { };
    boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var42, var43);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var38, var43);
    float[] var46 = null;
    float[] var47 = new float[] { };
    boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var46, var47);
    float[] var51 = new float[] { 0.0f, (-1.0f)};
    float[] var52 = null;
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var52);
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var46, var51);
    float[] var55 = null;
    float[] var56 = new float[] { };
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var55, var56);
    boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var51, var56);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var38, var51);
    float[] var62 = new float[] { 0.0f, (-1.0f)};
    float[] var63 = null;
    boolean var64 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var62, var63);
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var51, var63);
    float[] var68 = new float[] { 0.0f, (-1.0f)};
    float[] var69 = null;
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var68, var69);
    boolean var71 = org.apache.commons.math3.util.MathArrays.equals(var63, var68);
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var30, var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == true);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test277"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.323715103057636d, (java.lang.Number)0.4322522798438455d, false);

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test278"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextInt((-1), 8);
//     int var10 = var0.nextInt((-1), 6);
//     double var12 = var0.nextChiSquare(0.2700290390806306d);
//     double var14 = var0.nextT(1.5957881318373452d);
//     var0.reSeed();
//     var0.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var0.nextHypergeometric(7, 947302421, 449574259);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 246.31614064692434d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 4.0143677861940956E-7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.1534187577555766d);
// 
//   }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test279"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     long var6 = var1.nextPoisson(0.7157990521557022d);
//     var1.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextPascal(657, 91.3629924210577d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.45109833395107d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test280"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    double[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
    double[] var10 = new double[] { };
    double[] var12 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance1(var10, var12);
    double[] var16 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var10, var16);
    org.apache.commons.math3.util.MathArrays.OrderDirection var19 = null;
    boolean var22 = org.apache.commons.math3.util.MathArrays.checkOrder(var16, var19, false, true);
    double[] var23 = new double[] { };
    double[] var25 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var23, var25);
    double[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
    double[] var29 = new double[] { };
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double var33 = org.apache.commons.math3.util.MathArrays.distance1(var29, var31);
    double[] var35 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var29, var35);
    org.apache.commons.math3.util.MathArrays.OrderDirection var38 = null;
    boolean var41 = org.apache.commons.math3.util.MathArrays.checkOrder(var35, var38, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var42 = null;
    boolean var44 = org.apache.commons.math3.util.MathArrays.isMonotonic(var35, var42, false);
    double[] var45 = new double[] { };
    double[] var47 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var47);
    double var49 = org.apache.commons.math3.util.MathArrays.distance1(var45, var47);
    double[] var51 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var51);
    double var53 = org.apache.commons.math3.util.MathArrays.distance1(var45, var51);
    double var54 = org.apache.commons.math3.util.MathArrays.safeNorm(var51);
    double[] var55 = org.apache.commons.math3.util.MathArrays.ebeDivide(var35, var51);
    double var56 = org.apache.commons.math3.util.MathArrays.distance(var28, var55);
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var55);
    double[] var58 = new double[] { };
    double[] var60 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var60);
    double var62 = org.apache.commons.math3.util.MathArrays.distance1(var58, var60);
    double[] var64 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var64);
    double var66 = org.apache.commons.math3.util.MathArrays.distance1(var58, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var67 = null;
    boolean var70 = org.apache.commons.math3.util.MathArrays.checkOrder(var64, var67, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var71 = null;
    boolean var73 = org.apache.commons.math3.util.MathArrays.isMonotonic(var64, var71, false);
    double[] var75 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var75);
    double[] var78 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var78);
    double[] var80 = org.apache.commons.math3.util.MathArrays.ebeDivide(var75, var78);
    double[] var81 = new double[] { };
    double[] var83 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var83);
    double var85 = org.apache.commons.math3.util.MathArrays.distance1(var81, var83);
    org.apache.commons.math3.util.MathArrays.checkPositive(var83);
    double var87 = org.apache.commons.math3.util.MathArrays.safeNorm(var83);
    double[] var88 = org.apache.commons.math3.util.MathArrays.ebeAdd(var75, var83);
    org.apache.commons.math3.util.MathArrays.OrderDirection var89 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var83, var89, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var92 = null;
    boolean var95 = org.apache.commons.math3.util.MathArrays.checkOrder(var83, var92, true, false);
    double[] var96 = org.apache.commons.math3.util.MathArrays.ebeDivide(var64, var83);
    double[] var97 = org.apache.commons.math3.util.MathArrays.ebeAdd(var55, var96);
    double var98 = org.apache.commons.math3.util.MathArrays.distance(var0, var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == 0.0d);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test281"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)219.9831171065414d, (java.lang.Number)2.0511996659363665d, (java.lang.Number)0.7446287025499129d);
    java.lang.Number var4 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 2.0511996659363665d+ "'", var4.equals(2.0511996659363665d));

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test282"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    double[] var10 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var6, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.normalizeArray(var6, 3.0896657965554652d);
    double[] var15 = new double[] { };
    double[] var17 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var17);
    double var19 = org.apache.commons.math3.util.MathArrays.distance1(var15, var17);
    double[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
    double[] var21 = new double[] { };
    double[] var23 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var23);
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var21, var23);
    double[] var27 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var27);
    double var29 = org.apache.commons.math3.util.MathArrays.distance1(var21, var27);
    org.apache.commons.math3.util.MathArrays.OrderDirection var30 = null;
    boolean var33 = org.apache.commons.math3.util.MathArrays.checkOrder(var27, var30, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var34 = null;
    boolean var36 = org.apache.commons.math3.util.MathArrays.isMonotonic(var27, var34, false);
    double[] var37 = new double[] { };
    double[] var39 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var39);
    double var41 = org.apache.commons.math3.util.MathArrays.distance1(var37, var39);
    double[] var43 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var43);
    double var45 = org.apache.commons.math3.util.MathArrays.distance1(var37, var43);
    double var46 = org.apache.commons.math3.util.MathArrays.safeNorm(var43);
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeDivide(var27, var43);
    double var48 = org.apache.commons.math3.util.MathArrays.distance(var20, var47);
    double[] var50 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var50);
    double[] var53 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var53);
    double[] var55 = org.apache.commons.math3.util.MathArrays.ebeDivide(var50, var53);
    double[] var56 = new double[] { };
    double[] var58 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var58);
    double var60 = org.apache.commons.math3.util.MathArrays.distance1(var56, var58);
    org.apache.commons.math3.util.MathArrays.OrderDirection var61 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var58, var61, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var58);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var65 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var55, var58);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    double[] var67 = new double[] { };
    double[] var69 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var69);
    double var71 = org.apache.commons.math3.util.MathArrays.distance1(var67, var69);
    double[] var73 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var73);
    double var75 = org.apache.commons.math3.util.MathArrays.distance1(var67, var73);
    org.apache.commons.math3.util.MathArrays.OrderDirection var76 = null;
    double[] var78 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var78);
    double[] var81 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var81);
    double[] var83 = org.apache.commons.math3.util.MathArrays.ebeDivide(var78, var81);
    double[][] var84 = new double[][] { var81};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var73, var76, var84);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var55, var66, var84);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var87 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var47, var55);
    org.apache.commons.math3.util.MathArrays.checkOrder(var47);
    boolean var89 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var6, var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == true);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test283"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    long[] var4 = new long[] { 0L, 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    long[][] var7 = new long[][] { var4};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test284"); }


    long[] var3 = new long[] { 0L, 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    long[][] var5 = new long[][] { var3};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)58410742847964304L, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test285"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(100L);
    int[] var8 = new int[] { 100};
    int[] var10 = new int[] { 100};
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var10);
    int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var10);
    int[] var16 = new int[] { 100};
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    int var18 = org.apache.commons.math3.util.MathArrays.distanceInf(var10, var16);
    var2.setSeed(var16);
    int var20 = var2.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-1347491339));

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test286"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(702625292, 0);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test287"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.checkOrder(var6, var9, false, true);
    double[] var14 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var14);
    double[] var17 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var17);
    double[] var19 = org.apache.commons.math3.util.MathArrays.ebeDivide(var14, var17);
    double[] var21 = org.apache.commons.math3.util.MathArrays.normalizeArray(var14, 0.0d);
    double var22 = org.apache.commons.math3.util.MathArrays.distance(var6, var14);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var14);
    org.apache.commons.math3.util.MathArrays.checkPositive(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test288"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
    double[] var6 = new double[] { };
    double[] var8 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var8);
    double var10 = org.apache.commons.math3.util.MathArrays.distance1(var6, var8);
    double[] var12 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance1(var6, var12);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    boolean var18 = org.apache.commons.math3.util.MathArrays.checkOrder(var12, var15, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var19 = null;
    boolean var21 = org.apache.commons.math3.util.MathArrays.isMonotonic(var12, var19, false);
    double[] var22 = new double[] { };
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var22, var24);
    double[] var28 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var22, var28);
    double var31 = org.apache.commons.math3.util.MathArrays.safeNorm(var28);
    double[] var32 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var28);
    double var33 = org.apache.commons.math3.util.MathArrays.distance(var5, var32);
    double[] var35 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var35);
    double[] var38 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var38);
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeDivide(var35, var38);
    double[] var42 = org.apache.commons.math3.util.MathArrays.normalizeArray(var35, 100.0d);
    org.apache.commons.math3.util.MathArrays.OrderDirection var43 = null;
    boolean var46 = org.apache.commons.math3.util.MathArrays.checkOrder(var42, var43, false, false);
    double[] var47 = new double[] { };
    double[] var49 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var49);
    double var51 = org.apache.commons.math3.util.MathArrays.distance1(var47, var49);
    double[] var52 = org.apache.commons.math3.util.MathArrays.copyOf(var47);
    double[] var54 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var54);
    double[] var57 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var57);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeDivide(var54, var57);
    org.apache.commons.math3.util.MathArrays.checkOrder(var59);
    double var61 = org.apache.commons.math3.util.MathArrays.distanceInf(var47, var59);
    double[] var63 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var63);
    double[] var66 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var66);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var63, var66);
    double[] var69 = new double[] { };
    double[] var71 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance1(var69, var71);
    org.apache.commons.math3.util.MathArrays.checkPositive(var71);
    double var75 = org.apache.commons.math3.util.MathArrays.safeNorm(var71);
    double[] var76 = org.apache.commons.math3.util.MathArrays.ebeAdd(var63, var71);
    org.apache.commons.math3.util.MathArrays.OrderDirection var77 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var71, var77, true);
    double var80 = org.apache.commons.math3.util.MathArrays.distance1(var47, var71);
    boolean var81 = org.apache.commons.math3.util.MathArrays.equals(var42, var71);
    double var82 = org.apache.commons.math3.util.MathArrays.distanceInf(var32, var42);
    double[] var83 = org.apache.commons.math3.util.MathArrays.copyOf(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 99.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test289"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)7764.231540750071d, (java.lang.Number)10.0d, true);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 7764.231540750071d+ "'", var4.equals(7764.231540750071d));

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test290"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var20 = var16.sample();
    boolean var21 = var16.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);

  }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test291"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(98.45317552126936d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(0L);
//     double var8 = var0.nextF(0.7335444274806671d, 98.2718673777206d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6762401523557126d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.13215603174136548d);
// 
//   }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test292"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var10 = var1.nextWeibull(0.9846580496679653d, 0.7157990521557022d);
//     java.lang.String var12 = var1.nextSecureHexString(4);
//     int var15 = var1.nextSecureInt(10, 100);
//     int var18 = var1.nextSecureInt(0, 7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("c7f8365f1d", "7");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.46464265433139d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 109.53500235688111d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.485386670017646d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "7bff"+ "'", var12.equals("7bff"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 7);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test293"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var18 = var16.density(99.02988657003175d);
    boolean var19 = var16.isSupportUpperBoundInclusive();
    double var21 = var16.probability(263.1966961055d);
    boolean var22 = var16.isSupportUpperBoundInclusive();
    var16.reseedRandomGenerator((-4848980640512349401L));
    double var25 = var16.getSupportUpperBound();
    double var28 = var16.probability(103.20085407431179d, 325.59250627415844d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test294"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    double var4 = var2.nextDouble();
    var2.setSeed((-1));
    var2.setSeed(0L);
    long var9 = var2.nextLong();
    int[] var11 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var11);
    var12.setSeed(0);
    int[] var16 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
    int var18 = var17.nextInt();
    long var19 = var17.nextLong();
    org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c();
    var20.setSeed(6);
    int[] var24 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(var24);
    int var26 = var25.nextInt();
    long var27 = var25.nextLong();
    byte[] var28 = new byte[] { };
    var25.nextBytes(var28);
    var20.nextBytes(var28);
    var17.nextBytes(var28);
    var12.nextBytes(var28);
    var2.nextBytes(var28);
    long var34 = var2.nextLong();
    float var35 = var2.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.01408195728001127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-4736355256857903122L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 3932213204370553937L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.21722412f);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test295"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(100L);
    double[] var8 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var8);
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.ebeDivide(var8, var11);
    double[] var15 = org.apache.commons.math3.util.MathArrays.normalizeArray(var8, 100.0d);
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
    boolean var18 = org.apache.commons.math3.util.MathArrays.isMonotonic(var8, var16, true);
    double[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 9);
    double[] var22 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var22);
    double var24 = org.apache.commons.math3.util.MathArrays.safeNorm(var22);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var25 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var8, var22);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var27 = var25.inverseCumulativeProbability(100.74531099207395d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 100.0d);

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test296"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextInt((-1), 8);
//     int var10 = var0.nextInt((-1), 6);
//     double var12 = var0.nextChiSquare(0.2700290390806306d);
//     double var14 = var0.nextT(1.5957881318373452d);
//     var0.reSeed();
//     var0.reSeedSecure(0L);
//     java.lang.String var19 = var0.nextHexString(98);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 228.64087682408476d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5365048540914181d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.10366968105965219d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "b06ad46c562dfc2392ad2cf7aaedd935b5ce47bdfc94266ef516ba6c6b6d950ba38fbc78aa65389a9fa5295d401141b29e"+ "'", var19.equals("b06ad46c562dfc2392ad2cf7aaedd935b5ce47bdfc94266ef516ba6c6b6d950ba38fbc78aa65389a9fa5295d401141b29e"));
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test297"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-4736355256857903122L));
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test298"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var18 = var16.density(99.02988657003175d);
    boolean var19 = var16.isSupportUpperBoundInclusive();
    double var20 = var16.sample();
    double var21 = var16.sample();
    double var22 = var16.getSupportUpperBound();
    double var23 = var16.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test299"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(61.52869286998323d, 399.9453241022398d, 10087.891121411412d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 24608.113011472615d);

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test300"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     double var9 = var1.nextF(98.34128277750061d, 98.42176142483318d);
//     int[] var12 = var1.nextPermutation(1042, 10);
//     int var15 = var1.nextZipf(28, 9741.15478920364d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var1.nextCauchy(0.46418427184961886d, (-0.7972250154848055d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 100.97727860731598d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "9"+ "'", var6.equals("9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.1400347085850377d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
// 
//   }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test301"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.setSeed(0);
    int[] var6 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var6);
    int var8 = var7.nextInt();
    long var9 = var7.nextLong();
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c();
    var10.setSeed(6);
    int[] var14 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var14);
    int var16 = var15.nextInt();
    long var17 = var15.nextLong();
    byte[] var18 = new byte[] { };
    var15.nextBytes(var18);
    var10.nextBytes(var18);
    var7.nextBytes(var18);
    var2.nextBytes(var18);
    int var23 = var2.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var24 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    var24.reSeed(98L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 60481539);

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test302"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     long var6 = var1.nextPoisson(0.7157990521557022d);
//     var1.reSeedSecure(0L);
//     int var11 = var1.nextBinomial(94, 0.0d);
//     double var14 = var1.nextGamma(1012.0188911657001d, 9.927198205545196d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.46918507264024d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10173.945496890125d);
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test303"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.09013471933871053d);

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test304"); }
// 
// 
//     int[] var1 = new int[] { 100};
//     int[] var3 = new int[] { 100};
//     int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
//     int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
//     int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var3);
//     int[] var9 = new int[] { 100};
//     int[] var11 = new int[] { 100};
//     int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
//     int var13 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var11);
//     int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
//     org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var11);
//     int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
//     int var18 = org.apache.commons.math3.util.MathArrays.distance1(var3, var11);
//     org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(var11);
//     int[] var21 = new int[] { 100};
//     int[] var23 = new int[] { 100};
//     int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
//     int var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var21, var23);
//     int[] var27 = new int[] { 100};
//     int[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var27);
//     int[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 6);
//     int var31 = org.apache.commons.math3.util.MathArrays.distanceInf(var21, var30);
//     int var32 = org.apache.commons.math3.util.MathArrays.distance1(var11, var21);
//     int[] var33 = null;
//     int var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var11, var33);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test305"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 100, 4);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test306"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var10 = var1.nextWeibull(0.9846580496679653d, 0.7157990521557022d);
//     java.lang.String var12 = var1.nextSecureHexString(4);
//     int var15 = var1.nextSecureInt(10, 100);
//     double var18 = var1.nextF(9.989741442300522d, 183.75983595296293d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var20 = var1.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.45020909377637d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 105.77066753264884d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.7930456861374079d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "c257"+ "'", var12.equals("c257"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.5782732870644827d);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test307"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.2316468095843844d, (java.lang.Number)10000.0d, (java.lang.Number)8.066350685236545d);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test308"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     int var4 = var0.nextInt(0, 10);
//     double var7 = var0.nextGaussian(1.176542981693557d, 1.8507918026021757d);
//     double var9 = var0.nextT(247.92369202626887d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.23225196769172252d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.29711011362671863d);
// 
//   }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test309"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     var0.reSeedSecure((-1L));
//     int var14 = var0.nextZipf(9, 210.26801214771172d);
//     double var17 = var0.nextGaussian((-55.973096495762256d), 98.45377290426184d);
//     int var20 = var0.nextBinomial(5, 0.9184495496004099d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var22 = var0.nextPoisson((-0.8305377380798146d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 237.0805814568644d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "5b860d052e"+ "'", var9.equals("5b860d052e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 61.7308005355027d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 4);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test310"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    long var4 = var2.nextLong();
    double var5 = var2.nextGaussian();
    double var6 = var2.nextGaussian();
    var2.setSeed(43059505226525080L);
    boolean var9 = var2.nextBoolean();
    int var10 = var2.nextInt();
    org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    double var14 = var11.nextGamma(67.97416527034792d, 0.11381348834333911d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setSecureAlgorithm("fb25", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.7157990521557022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-0.6984489763881883d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1736698663);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 7.110393399127772d);

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test311"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     int var9 = var1.nextZipf(10, 13.521216539811984d);
//     double var11 = var1.nextChiSquare(1.2388070620041405d);
//     var1.reSeed();
//     double var15 = var1.nextCauchy(0.3055322893119356d, 0.020579212303715753d);
//     int var18 = var1.nextInt(0, 1543116286);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.72452696281758d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "b"+ "'", var6.equals("b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.6472695646950817d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.28388607193113524d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 903975495);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test312"); }


    int[] var1 = new int[] { 100};
    int[] var3 = new int[] { 100};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(var3);
    var6.setSeed(259766232686583471L);
    double var9 = var6.nextDouble();
    org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var6);
    double var13 = var10.nextGamma(70384.99599681215d, 0.9687036154652069d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.2700290390806306d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 68151.43621616602d);

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test313"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     int var4 = var0.nextInt(0, 10);
//     double var7 = var0.nextGaussian(1.176542981693557d, 1.8507918026021757d);
//     long var10 = var0.nextLong((-414028722650554365L), 132L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("19c87efc5b", "7");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.8260107018540945d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-140091119549230448L));
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test314"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)373.2855763258904d, (java.lang.Number)(byte)1);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getArgument();
    java.lang.Number var6 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 373.2855763258904d+ "'", var4.equals(373.2855763258904d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (byte)1+ "'", var6.equals((byte)1));

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test315"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.checkOrder(var6, var9, false, true);
    double[] var14 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var14);
    double[] var17 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var17);
    double[] var19 = org.apache.commons.math3.util.MathArrays.ebeDivide(var14, var17);
    double[] var21 = org.apache.commons.math3.util.MathArrays.normalizeArray(var14, 0.0d);
    double var22 = org.apache.commons.math3.util.MathArrays.distance(var6, var14);
    java.lang.Number var23 = null;
    java.lang.Comparable[] var25 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var26 = null;
    boolean var28 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var25, var26, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var29 = new org.apache.commons.math3.exception.NotFiniteNumberException(var23, (java.lang.Object[])var25);
    org.apache.commons.math3.util.MathArrays.OrderDirection var30 = null;
    boolean var32 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var25, var30, true);
    java.lang.Number var33 = null;
    java.lang.Comparable[] var35 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var36 = null;
    boolean var38 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var35, var36, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var39 = new org.apache.commons.math3.exception.NotFiniteNumberException(var33, (java.lang.Object[])var35);
    org.apache.commons.math3.util.MathArrays.OrderDirection var40 = null;
    boolean var42 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var35, var40, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var46 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.3220963206821523d, (java.lang.Number)299.89733044110505d, 8);
    int var47 = var46.getIndex();
    org.apache.commons.math3.exception.util.ExceptionContext var48 = var46.getContext();
    org.apache.commons.math3.util.MathArrays.OrderDirection var49 = var46.getDirection();
    boolean var51 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var35, var49, false);
    boolean var53 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var25, var49, true);
    boolean var55 = org.apache.commons.math3.util.MathArrays.isMonotonic(var14, var49, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test316"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(152600911433040288L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var4 = var0.nextHexString((-549596712));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test317"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(5199522.875972667d, 98.88500098380753d, 1.819217204815299d, 93.9837754267852d, 98.07133134489611d, (-0.21819979512271087d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 5.141549742836437E8d);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test318"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var6);
    double[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test319"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 0, 1543116286);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test320"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(60481539);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test321"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(100L);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
    boolean var19 = org.apache.commons.math3.util.MathArrays.checkOrder(var13, var16, false, true);
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var24);
    double[] var28 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.0d);
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var13, var21);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeDivide(var31, var34);
    double[] var38 = org.apache.commons.math3.util.MathArrays.normalizeArray(var31, 100.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var39 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var13, var31);
    org.apache.commons.math3.random.RandomDataImpl var40 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    double var43 = var40.nextBeta(3.9806842939274003d, 2.4755170523669765d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.45085206284131424d);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test322"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.0991832135313893d, (java.lang.Number)3.7551631969543857d, (java.lang.Number)1.0f);

  }

}
