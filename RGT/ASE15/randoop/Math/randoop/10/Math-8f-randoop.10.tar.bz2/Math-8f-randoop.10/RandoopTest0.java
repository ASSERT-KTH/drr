
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     java.util.List var1 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var2 = new org.apache.commons.math3.distribution.DiscreteDistribution(var0, var1);
// 
//   }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 10, 0);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(1.0d, (-1.0d), 1.0d, 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    double[] var2 = new double[] { 100.0d, 1.0d};
    double[] var4 = new double[] { 10.0d};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var5 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var2, var4);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var1.nextWeibull(100.0d, (-1.0d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    int[] var2 = new int[] { 10, 0};
    int[] var4 = new int[] { 100};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var1.nextBeta(0.0d, 10.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var1.nextGamma(0.0d, (-1.0d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var6 = var1.nextLong(100L, 100L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var1.nextPoisson((-1.0d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var1.nextGaussian(0.0d, (-1.0d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     java.util.Collection var4 = null;
//     java.lang.Object[] var6 = var1.nextSample(var4, 100);
// 
//   }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 0, 1);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(1.0d, 10.0d, 0.0d, 10.0d, 0.0d, 10.0d, 100.0d, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1010.0d);

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 0, 100);
// 
//   }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 0);
// 
//   }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }
// 
// 
//     long[] var0 = null;
//     long[][] var1 = new long[][] { var0};
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
// 
//   }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var1.nextGaussian((-1.0d), (-1.0d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 99.03548077422418d);
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var4 = var1.nextSecureLong(10L, 1L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(byte)0);
    boolean var2 = var1.getBoundIsAllowed();
    java.lang.Throwable[] var3 = var1.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.checkPositive(var0);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, (-96398574));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     java.util.List var4 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var5 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var4);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)100.0d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     byte[] var2 = null;
//     var0.nextBytes(var2);
// 
//   }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var7 = var1.nextLong(1L, 1L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.962792929965206d);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    double var4 = var2.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5104454862955553d);

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { 10.0d, 0.0d, 10.0d};
//     double[] var5 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var0, var4);
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)100.0d);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    float[] var7 = new float[] { 0.0f, (-1.0f)};
    float[] var8 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var8);
    java.lang.Object[] var10 = new java.lang.Object[] { var8};
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var4, var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)(byte)10, var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(short)10, var10);
    java.lang.Number var14 = var13.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (short)10+ "'", var14.equals((short)10));

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextUniform(9.927198205545196d, 9.927198205545196d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.56010447948181d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 85.42161305221452d);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var2.nextInt((-96398574));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }
// 
// 
//     org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.lang.Object[] var3 = new java.lang.Object[] { false};
//     org.apache.commons.math3.exception.MathIllegalStateException var4 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var0, var1, var3);
//     java.lang.Throwable[] var5 = var4.getSuppressed();
//     org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     java.util.Collection var8 = null;
//     java.lang.Object[] var10 = var1.nextSample(var8, (-1));
// 
//   }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 1, 1);
// 
//   }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var2 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-1.0f), var2, true);
//     java.lang.Number var5 = var4.getMin();
//     boolean var6 = var4.getBoundIsAllowed();
//     java.lang.String var7 = var4.toString();
// 
//   }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var1.nextBinomial((-1), 98.45317552126936d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.73553231980533d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 72.63502490571015d);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    int[] var2 = new int[] { 0, 0};
    int[] var4 = new int[] { 100};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = org.apache.commons.math3.util.MathArrays.distance(var2, var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.apache.commons.math3.exception.NullArgumentException var0 = new org.apache.commons.math3.exception.NullArgumentException();

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 98.28206305872513d, 97.97864407980379d, 0.7157990521557022d, 1.2388070620041405d, 98.42599099481274d, 10.0d, 79.25588231908337d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 984.6226564837881d);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     double var8 = var1.nextUniform(1.0d, 1.2388070620041405d, false);
//     double var11 = var1.nextCauchy(0.5104454862955553d, 97.97864407980379d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextGamma(0.0d, 79.25588231908337d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.819027276683384d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.2219227737368696d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4.676205059016382d);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure(10L);
    var1.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSecureAlgorithm("", "hi!");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     double var9 = var1.nextF(98.34128277750061d, 98.42176142483318d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var1.nextSecureInt((-96398574), (-96398574));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 93.83178266567974d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "a"+ "'", var6.equals("a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.252752240288431d);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     java.util.Collection var4 = null;
//     java.lang.Object[] var6 = var0.nextSample(var4, (-96398574));
// 
//   }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var5 = var0.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7);
// 
//   }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     org.apache.commons.math3.distribution.IntegerDistribution var7 = null;
//     int var8 = var0.nextInversionDeviate(var7);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    float[] var7 = new float[] { 0.0f, (-1.0f)};
    float[] var8 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var8);
    java.lang.Object[] var10 = new java.lang.Object[] { var8};
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var4, var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)(byte)10, var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(short)10, var10);
    org.apache.commons.math3.exception.util.ExceptionContext var14 = var13.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)97.92480086319091d, (java.lang.Number)1.0737206121073526d, false);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(short)1, (java.lang.Number)(-1.0f), false);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    java.lang.Number var5 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)1+ "'", var5.equals((short)1));

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(1.2388070620041405d, 98.45317552126936d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var14 = var1.nextLong(259766232686583471L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.49305245909733d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 97.79888044132535d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 54.13050205506384d);
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextF((-1.0d), 99.2782319289774d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7);
// 
//   }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     double var6 = var1.nextT(1.2388070620041405d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var1.nextSecureInt(9, 1);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.76314614441041d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.8996006150784402d));
// 
//   }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var0.nextCauchy((-1.0d), (-0.21819979512271087d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "9650de8b8"+ "'", var2.equals("9650de8b8"));
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalArgumentException var2 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var1);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var0.nextBinomial(0, 79.25588231908337d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(1.2388070620041405d, 98.45317552126936d, true);
//     double var13 = var1.nextExponential(290.77256675474683d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("hi!", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.45236489965168d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 89.00962968661993d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 46.83774408133478d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 205.96588333076835d);
// 
//   }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var3 = var0.nextT(98.28206305872513d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var0.nextHypergeometric((-96398574), 100, 8);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.0150735200386015d));
// 
//   }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextBinomial(8, 98.45317552126936d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
// 
//   }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var3 = var0.nextT(98.28206305872513d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("6c8f794b2", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.6729191118092983d));
// 
//   }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 10, (-96398574));
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double[] var14 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var11, var14);
    double[][] var17 = new double[][] { var14};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var6, var9, var17);
    double[] var19 = new double[] { };
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double var23 = org.apache.commons.math3.util.MathArrays.distance1(var19, var21);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var19);
    double[] var26 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double[] var31 = org.apache.commons.math3.util.MathArrays.ebeDivide(var26, var29);
    org.apache.commons.math3.util.MathArrays.checkOrder(var31);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var19, var31);
    double[][] var34 = new double[][] { var19};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var6, var34);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(110.67903653979582d, (-0.21819979512271087d), 98.42599099481274d, 1.7904651608248163d, 97.96410453789858d, 149.46919877865736d, 9.871651067214367d, 115.88842315603809d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 15938.704455172932d);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(99.2782319289774d, 99.2782319289774d, 263.1966961055d, 88.2514775318289d, 9.871651067214367d, 1.0737206121073526d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 33094.264042976356d);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     var0.reSeedSecure();
//     org.apache.commons.math3.distribution.IntegerDistribution var8 = null;
//     int var9 = var0.nextInversionDeviate(var8);
// 
//   }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var3 = var0.nextT(98.28206305872513d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var6 = var0.nextPermutation((-1), 1);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.7575490947345174d);
// 
//   }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 100);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.0f, (java.lang.Number)0.2905339688026802d, true);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    float[] var0 = null;
    float[] var3 = new float[] { 0.0f, (-1.0f)};
    float[] var4 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(1.2388070620041405d, 98.45317552126936d, true);
//     double var13 = var1.nextExponential(290.77256675474683d);
//     java.util.Collection var14 = null;
//     java.lang.Object[] var16 = var1.nextSample(var14, 0);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var0.nextWeibull(0.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     org.apache.commons.math3.distribution.IntegerDistribution var12 = null;
//     int var13 = var0.nextInversionDeviate(var12);
// 
//   }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 4);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(short)1, (java.lang.Number)0, false);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextInt((-1), 8);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var9 = var0.nextSecureHexString((-96398574));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 240.02030989728036d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2);
// 
//   }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var3 = var0.nextT(98.28206305872513d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var6 = var0.nextPermutation(0, 10);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.6453998890847628d));
// 
//   }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(1.2388070620041405d, 98.45317552126936d, true);
//     java.lang.String var13 = var1.nextHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var16 = var1.nextLong(100L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.49263314477072d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 106.61725727929257d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 53.893280875245416d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "1"+ "'", var13.equals("1"));
// 
//   }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(1.2388070620041405d, 98.45317552126936d, true);
//     java.util.Collection var12 = null;
//     java.lang.Object[] var14 = var1.nextSample(var12, 1);
// 
//   }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     double[] var0 = new double[] { };
//     double[] var2 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var2);
//     double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
//     double[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
//     double[] var7 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var7);
//     double[] var10 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var10);
//     double[] var12 = org.apache.commons.math3.util.MathArrays.ebeDivide(var7, var10);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var12);
//     double var14 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var12);
//     double[] var15 = null;
//     double[] var16 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var0, var15);
// 
//   }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var9 = var1.nextT(97.97864407980379d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var1.nextBinomial((-1), 98.2718673777206d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.45268957108628d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 80.22269755380694d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1.3147030898002903d));
// 
//   }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(98.42211871395055d, 236.68158202287123d, 110.67903653979582d, 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 23405.381799800452d);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(1.2388070620041405d, 98.45317552126936d, true);
//     java.lang.String var13 = var1.nextHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var1.nextHypergeometric((-96398574), 0, 2);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.46673589685402d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 104.10817570892442d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3.1643355296496933d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "7"+ "'", var13.equals("7"));
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.nextHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     double var6 = var1.nextT(1.2388070620041405d);
//     java.util.Collection var7 = null;
//     java.lang.Object[] var9 = var1.nextSample(var7, 4);
// 
//   }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(1.2388070620041405d, 98.45317552126936d, true);
//     java.lang.String var13 = var1.nextHexString(1);
//     java.util.Collection var14 = null;
//     java.lang.Object[] var16 = var1.nextSample(var14, 6);
// 
//   }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 8, (-1));
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     long[] var7 = new long[] { 0L, 10L};
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
//     long[][] var9 = new long[][] { var7};
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var9);
//     org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var9);
// 
//   }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(98.45317552126936d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("", "8");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.7651437033386004d));
// 
//   }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var7 = var0.nextLong(100L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 178.73024921596746d);
// 
//   }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError();
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     java.lang.Object[] var4 = new java.lang.Object[] { false};
//     org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, var4);
//     java.lang.Throwable[] var6 = var5.getSuppressed();
//     org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var6);
//     org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var7);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)59.5604882521082d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)100, (java.lang.Number)0.0f, 0, var3, false);
    boolean var6 = var5.getStrict();
    boolean var7 = var5.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(97.96410453789858d, 79.25588231908337d, 0.0d, 0.3055322893119356d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 7764.231540750071d);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var0.nextUniform(104.91028148840213d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "2eeaeca98"+ "'", var2.equals("2eeaeca98"));
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var1.nextChiSquare((-0.6984489763881883d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.checkOrder(var6, var9, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    boolean var15 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var13, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var16, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextInt((-1), 8);
//     int var10 = var0.nextInt((-1), 6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var13 = var0.nextSecureLong(100L, 10L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 201.43975915891465d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSecureAlgorithm("", "bb52fd545");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var3 = var0.nextT(98.28206305872513d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextPascal(4, 1.2316468095843844d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.8507048332749682d));
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.23344772945559902d, 191.0943244061241d, 9.927959811989089d, 1.2388070620041405d, 0.3055322893119356d, 98.38153633363427d, 38.60348596763803d, 98.45317552126936d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3887.603878597613d);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var1, (java.lang.Number)(-1.0f), var3, true);
    java.lang.Number var6 = var5.getMin();
    var0.addSuppressed((java.lang.Throwable)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     double var13 = var0.nextT(99.2782319289774d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextUniform(58.468608413067535d, (-0.6984489763881883d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 72.06713924840894d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.6874541346841145d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.17884476196016544d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.2616966725489587d));
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.nextChiSquare(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var1.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.843333784734d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "1"+ "'", var6.equals("1"));
// 
//   }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     java.util.List var0 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var1 = new org.apache.commons.math3.distribution.DiscreteDistribution(var0);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    int[] var1 = new int[] { 100};
    int[] var3 = new int[] { 100};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
    int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(9);
//     var0.reSeedSecure();
//     int var6 = var0.nextInt((-96398574), 100);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "72267fb33"+ "'", var2.equals("72267fb33"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-63560251));
// 
//   }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextWeibull(1.6486550157904805d, 100.0d);
//     int var7 = var0.nextZipf(6, 0.2802818762189058d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextSecureInt(9, 6);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 43.75704264882817d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double[] var11 = org.apache.commons.math3.util.MathArrays.ebeDivide(var6, var9);
    double[] var13 = org.apache.commons.math3.util.MathArrays.normalizeArray(var6, 100.0d);
    org.apache.commons.math3.util.MathArrays.OrderDirection var14 = null;
    boolean var17 = org.apache.commons.math3.util.MathArrays.checkOrder(var13, var14, false, false);
    double[] var18 = new double[] { };
    double[] var20 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double var22 = org.apache.commons.math3.util.MathArrays.distance1(var18, var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var18);
    double[] var25 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var25);
    double[] var28 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeDivide(var25, var28);
    org.apache.commons.math3.util.MathArrays.checkOrder(var30);
    double var32 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var30);
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double[] var37 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var37);
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeDivide(var34, var37);
    double[] var40 = new double[] { };
    double[] var42 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var42);
    double var44 = org.apache.commons.math3.util.MathArrays.distance1(var40, var42);
    org.apache.commons.math3.util.MathArrays.checkPositive(var42);
    double var46 = org.apache.commons.math3.util.MathArrays.safeNorm(var42);
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeAdd(var34, var42);
    org.apache.commons.math3.util.MathArrays.OrderDirection var48 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var42, var48, true);
    double var51 = org.apache.commons.math3.util.MathArrays.distance1(var18, var42);
    boolean var52 = org.apache.commons.math3.util.MathArrays.equals(var13, var42);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var53 = org.apache.commons.math3.util.MathArrays.ebeAdd(var0, var42);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var10 = var1.nextCauchy(99.02988657003175d, 99.02988657003175d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.46619727159656d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 98.88500098380753d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 77.74838373665371d);
// 
//   }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     var0.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextF(38.60348596763803d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 106.88397107371178d);
// 
//   }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 3, 2);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)2);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0, var1, true);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = new double[] { };
//     double[] var3 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var3);
//     double var5 = org.apache.commons.math3.util.MathArrays.distance1(var1, var3);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var3);
//     double var7 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
//     double[] var8 = new double[] { };
//     double[] var10 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var10);
//     double var12 = org.apache.commons.math3.util.MathArrays.distance1(var8, var10);
//     double[] var14 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var14);
//     double var16 = org.apache.commons.math3.util.MathArrays.distance1(var8, var14);
//     double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
//     double[] var18 = new double[] { };
//     double[] var20 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var20);
//     double var22 = org.apache.commons.math3.util.MathArrays.distance1(var18, var20);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var20);
//     double var24 = org.apache.commons.math3.util.MathArrays.safeNorm(var20);
//     double[] var25 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var14, var20);
//     boolean var26 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var20);
//     double[] var27 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var0, var3);
// 
//   }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }
// 
// 
//     int[] var0 = null;
//     int[] var1 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)984.6226564837881d, (java.lang.Number)183.38519957224838d, false);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 0, 0);
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)58.468608413067535d, (java.lang.Number)98.34128277750061d, (java.lang.Number)0.7090371711746789d);

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextInt((-1), 8);
//     int var10 = var0.nextInt((-1), 6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextBinomial(6, 10.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 191.92198339198737d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2);
// 
//   }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var0.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 95.68772900107736d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.009180270465499832d);
// 
//   }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(9);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextSecureInt(9, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "e9398cfc9"+ "'", var2.equals("e9398cfc9"));
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
    double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var13);
    double[] var17 = new double[] { };
    double[] var19 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance1(var17, var19);
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var13, var19);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var19);
    double[] var26 = new double[] { };
    double[] var28 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var26, var28);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var32 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var2, var31);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     int[] var0 = null;
//     int[] var2 = new int[] { 100};
//     int[] var4 = new int[] { 100};
//     int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
//     int var6 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var4);
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var4);
//     int var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var3 = new double[] { };
    double[] var5 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var5);
    double var7 = org.apache.commons.math3.util.MathArrays.distance1(var3, var5);
    double[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    double[] var10 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var10);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double[] var15 = org.apache.commons.math3.util.MathArrays.ebeDivide(var10, var13);
    org.apache.commons.math3.util.MathArrays.checkOrder(var15);
    double var17 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var18 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     long var4 = var2.nextLong();
//     byte[] var5 = new byte[] { };
//     var2.nextBytes(var5);
//     java.util.List var7 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var8 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var7);
// 
//   }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     double var13 = var0.nextT(99.2782319289774d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var16 = var0.nextPermutation(0, 7);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 47.79352481419775d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.9513602753127945d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.018437324058439734d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.4726120981672557d));
// 
//   }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("5", "4");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.43522432974235d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 74.94873244350173d);
// 
//   }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     int var9 = var1.nextZipf(10, 13.521216539811984d);
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var1.nextSample(var10, 10);
// 
//   }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure((-1L));
//     long var8 = var1.nextPoisson(1.0847091605564438d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.90354239278018d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2L);
// 
//   }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     long var6 = var1.nextPoisson(1.2388070620041405d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var1.nextInt(3, (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.45007346454261d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 290.77256675474683d, 0.9184495496004099d, 98.42599099481274d, 21.041427092950197d, 9.95645506445408d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 299.89733044110505d);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var3 = var2.getValue();
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl();
    var5.reSeed();
    boolean var7 = var2.equals((java.lang.Object)var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var5.nextGamma(0.0d, 0.323715103057636d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1L+ "'", var3.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.OrderDirection var1 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var0, var1, false);
// 
//   }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     double var13 = var0.nextT(99.2782319289774d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextBinomial(0, 3887.603878597613d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 147.7708938370972d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.8954082963371567d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.6062221354945972d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.8452047745685733d));
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { false};
    org.apache.commons.math3.exception.MathIllegalStateException var4 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var0, var1, var3);
    java.lang.String var5 = var0.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"+ "'", var5.equals("org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"));

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)77.74838373665371d, (java.lang.Number)9.95645506445408d);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(98.41573398641329d, 0.90076811327417d, 103.89205253196047d, 83.3326923348544d, 0.2802818762189058d, 104.91028148840213d, 99.2782319289774d, 0.9638486378008077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 8871.347843840067d);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.2802818762189058d);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)98.46619727159656d);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(98.44078667812042d, 10.0d, 606.9017688960619d, 99.8591140316555d, 1.0847091605564438d, 98.07133134489611d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 61695.45968448425d);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(100L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var2.nextInt((-63560251));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var22 = var16.probability(98.46652934914283d, 63.26735447683985d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     double var4 = var2.nextDouble();
//     var2.setSeed((-1));
//     var2.setSeed(0L);
//     long var9 = var2.nextLong();
//     var2.setSeed(10);
//     double var12 = var2.nextDouble();
//     double[] var13 = new double[] { };
//     double[] var15 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var15);
//     double var17 = org.apache.commons.math3.util.MathArrays.distance1(var13, var15);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
//     double[] var19 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var20 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var13, var19);
// 
//   }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextBinomial((-96398574), 3887.603878597613d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-74.11243473719344d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.1273274678367013d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.020050501585176347d);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-6.225449347177431d), (java.lang.Number)98.46619727159656d, 7, var3, false);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(165.22373033698972d, 202.22534955410197d, 104.91028148840213d, 3887.603878597613d, (-6.225449347177431d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 441262.0438411099d);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)9.919067730863462d, var1, false);

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(9);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextF(3.7551631969543857d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "60d5b7b45"+ "'", var2.equals("60d5b7b45"));
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
    double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var13);
    double[] var17 = new double[] { };
    double[] var19 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance1(var17, var19);
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var13, var19);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var19);
    org.apache.commons.math3.util.MathArrays.OrderDirection var26 = null;
    boolean var29 = org.apache.commons.math3.util.MathArrays.checkOrder(var2, var26, true, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var30 = null;
    boolean var32 = org.apache.commons.math3.util.MathArrays.isMonotonic(var2, var30, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var4 = var0.nextPermutation(4, 100);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 2, 6);
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var8 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.0737206121073526d, (java.lang.Number)9.95645506445408d, (java.lang.Number)10L);
//     java.lang.Throwable[] var9 = var8.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var9);
// 
//   }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextGamma(1.0737206121073526d, 0.1490436810544255d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 145.29131161949542d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.38568655572031113d);
// 
//   }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var0);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.0d, var2, (java.lang.Number)1010.0d);
    java.lang.Number var5 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
//     long var4 = var3.nextLong();
//     org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
//     java.util.Collection var6 = null;
//     java.lang.Object[] var8 = var5.nextSample(var6, (-1));
// 
//   }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     var0.reSeedSecure();
//     int var10 = var0.nextSecureInt(1, 2);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextUniform(78.57664175278842d, 0.7287724395709415d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 31.048100293815807d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    float[] var0 = null;
    float[] var1 = new float[] { };
    boolean var2 = org.apache.commons.math3.util.MathArrays.equals(var0, var1);
    float[] var5 = new float[] { 0.0f, (-1.0f)};
    float[] var6 = null;
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var6);
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var0, var5);
    float[] var10 = new float[] { 0.0f};
    float[] var11 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var10, var11);
    boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     double var9 = var1.nextF(98.34128277750061d, 98.42176142483318d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var1.nextPascal(2074243331, 190.21516127970872d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.94568314369054d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "4"+ "'", var6.equals("4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0005225737520849d);
// 
//   }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     var0.reSeedSecure();
//     double var9 = var0.nextT(290.77256675474683d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextSecureInt(8, 8);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-163.22250333632866d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.06277755278130506d);
// 
//   }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     long var6 = var1.nextPoisson(1.2388070620041405d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var1.nextCauchy(92.58889101274673d, (-0.4184846162521546d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.41356166415989d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
// 
//   }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     double var8 = var1.nextUniform(1.0d, 1.2388070620041405d, false);
//     double var11 = var1.nextCauchy(10.049872943398238d, 0.003494754140413766d);
//     double var14 = var1.nextGaussian(0.0d, 441262.0438411099d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10.024409082583382d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.078838815458333d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 10.057771235263797d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 315951.04828560806d);
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { false};
    org.apache.commons.math3.exception.MathIllegalStateException var4 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var0, var1, var3);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 7, 0);
// 
//   }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     int[] var10 = var0.nextPermutation(9, 4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextSecureInt(2074243331, 3);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 235.22959049720413d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
// 
//   }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 8, 100);
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     java.lang.Comparable[] var6 = new java.lang.Comparable[] { 10};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
//     boolean var9 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var6, var7, true);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
//     boolean var12 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var6, var10, false);
//     org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var6);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(219.9831171065414d, 1.7904651608248163d, 51.30880113197997d, 0.9775554539871507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 444.0293055330172d);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
    double[] var6 = new double[] { };
    double[] var8 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var8);
    double var10 = org.apache.commons.math3.util.MathArrays.distance1(var6, var8);
    double[] var12 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance1(var6, var12);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    boolean var18 = org.apache.commons.math3.util.MathArrays.checkOrder(var12, var15, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var19 = null;
    boolean var21 = org.apache.commons.math3.util.MathArrays.isMonotonic(var12, var19, false);
    double[] var22 = new double[] { };
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var22, var24);
    double[] var28 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var22, var28);
    double var31 = org.apache.commons.math3.util.MathArrays.safeNorm(var28);
    double[] var32 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var28);
    double var33 = org.apache.commons.math3.util.MathArrays.distance(var5, var32);
    double[] var35 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var35);
    double[] var38 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var38);
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeDivide(var35, var38);
    double[] var41 = new double[] { };
    double[] var43 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var43);
    double var45 = org.apache.commons.math3.util.MathArrays.distance1(var41, var43);
    org.apache.commons.math3.util.MathArrays.OrderDirection var46 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var43, var46, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var43);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var50 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var40, var43);
    org.apache.commons.math3.util.MathArrays.OrderDirection var51 = null;
    double[] var52 = new double[] { };
    double[] var54 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var52, var54);
    double[] var58 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var58);
    double var60 = org.apache.commons.math3.util.MathArrays.distance1(var52, var58);
    org.apache.commons.math3.util.MathArrays.OrderDirection var61 = null;
    double[] var63 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var63);
    double[] var66 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var66);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var63, var66);
    double[][] var69 = new double[][] { var66};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var58, var61, var69);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var40, var51, var69);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var72 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var32, var40);
    double[] var74 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var74);
    double[] var77 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var77);
    double[] var79 = org.apache.commons.math3.util.MathArrays.ebeDivide(var74, var77);
    double[] var80 = new double[] { };
    double[] var82 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var82);
    double var84 = org.apache.commons.math3.util.MathArrays.distance1(var80, var82);
    org.apache.commons.math3.util.MathArrays.checkPositive(var82);
    double var86 = org.apache.commons.math3.util.MathArrays.safeNorm(var82);
    double[] var87 = org.apache.commons.math3.util.MathArrays.ebeAdd(var74, var82);
    double var88 = org.apache.commons.math3.util.MathArrays.distance1(var32, var82);
    double var89 = org.apache.commons.math3.util.MathArrays.safeNorm(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 99.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 1.0d);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextInt((-1), 8);
//     int var10 = var0.nextInt((-1), 6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var13 = var0.nextLong(100L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 198.85202813096708d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6);
// 
//   }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var0.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    float[] var3 = new float[] { 0.0f, (-1.0f)};
    float[] var4 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    java.lang.Object[] var6 = new java.lang.Object[] { var4};
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var6);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(1.2388070620041405d, 98.45317552126936d, true);
//     double var13 = var1.nextExponential(290.77256675474683d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextInt(4, 3);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.44555672185142d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 90.46388543820193d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 44.03770998763565d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 38.988340962195466d);
// 
//   }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     var0.reSeedSecure();
//     double var9 = var0.nextT(290.77256675474683d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextUniform(98.85607777755142d, 98.47480055949d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 42.0414312195288d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.9131913612977487d);
// 
//   }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var9);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var1, var9);
    double[] var15 = new double[] { };
    double[] var17 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var17);
    double var19 = org.apache.commons.math3.util.MathArrays.distance1(var15, var17);
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double var23 = org.apache.commons.math3.util.MathArrays.distance1(var15, var21);
    double[] var24 = new double[] { };
    double[] var26 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var24, var26);
    double[] var30 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var30);
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var24, var30);
    org.apache.commons.math3.util.MathArrays.OrderDirection var33 = null;
    boolean var36 = org.apache.commons.math3.util.MathArrays.checkOrder(var30, var33, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var37 = null;
    boolean var39 = org.apache.commons.math3.util.MathArrays.isMonotonic(var30, var37, false);
    double[] var40 = new double[] { };
    double[] var42 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var42);
    double var44 = org.apache.commons.math3.util.MathArrays.distance1(var40, var42);
    double[] var46 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var46);
    double var48 = org.apache.commons.math3.util.MathArrays.distance1(var40, var46);
    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var46);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeDivide(var30, var46);
    double[] var51 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var21, var30);
    double var52 = org.apache.commons.math3.util.MathArrays.distance1(var9, var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 100.0d);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
    double var4 = var3.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.908642352606886d);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("5c6ec55e7d", "c88e78e816");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 227.4690448296584d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = var16.inverseCumulativeProbability(202.22534955410197d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(98.2718673777206d, 321.6792596437714d, 116.28669882378713d, 1.8229678545960526d, 210.05292023350523d, 98.44078667812042d, 0.9846580496679653d, (-0.4378278462730581d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 52501.352056858435d);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)984.6226564837881d, (java.lang.Number)(-414028722650554365L), 7, var3, true);

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     long var12 = var0.nextLong((-414028722650554365L), 100L);
//     var0.reSeedSecure(2104590830736605696L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 247.45752224305923d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.8507918026021757d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-115747454037461536L));
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)100, (java.lang.Number)0.0f, 0, var3, false);
    int var6 = var5.getIndex();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var5.getDirection();
    boolean var8 = var5.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     int[] var1 = new int[] { 100};
//     int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
//     int[] var3 = null;
//     double var4 = org.apache.commons.math3.util.MathArrays.distance(var2, var3);
// 
//   }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var0.nextLong(152600911433040288L, 2L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 50.61376197705131d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 24.77889236474846d);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    double[] var0 = null;
    double[] var1 = new double[] { };
    double[] var3 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var3);
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var1, var3);
    org.apache.commons.math3.util.MathArrays.checkPositive(var3);
    double var7 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double[] var12 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var12);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeDivide(var9, var12);
    double[] var15 = new double[] { };
    double[] var17 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var17);
    double var19 = org.apache.commons.math3.util.MathArrays.distance1(var15, var17);
    org.apache.commons.math3.util.MathArrays.checkPositive(var17);
    double var21 = org.apache.commons.math3.util.MathArrays.safeNorm(var17);
    double[] var22 = org.apache.commons.math3.util.MathArrays.ebeAdd(var9, var17);
    double[] var24 = org.apache.commons.math3.util.MathArrays.normalizeArray(var22, 0.0d);
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var3, var22);
    double[] var27 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var27);
    double[] var30 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var30);
    double[] var32 = org.apache.commons.math3.util.MathArrays.ebeDivide(var27, var30);
    double[] var33 = new double[] { };
    double[] var35 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var33, var35);
    org.apache.commons.math3.util.MathArrays.checkPositive(var35);
    double var39 = org.apache.commons.math3.util.MathArrays.safeNorm(var35);
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeAdd(var27, var35);
    org.apache.commons.math3.util.MathArrays.OrderDirection var41 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var35, var41, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var44 = null;
    boolean var47 = org.apache.commons.math3.util.MathArrays.checkOrder(var35, var44, true, false);
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeDivide(var22, var35);
    double[] var50 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var50);
    double[] var53 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var53);
    double[] var55 = org.apache.commons.math3.util.MathArrays.ebeDivide(var50, var53);
    double[] var56 = new double[] { };
    double[] var58 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var58);
    double var60 = org.apache.commons.math3.util.MathArrays.distance1(var56, var58);
    org.apache.commons.math3.util.MathArrays.OrderDirection var61 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var58, var61, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var58);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var65 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var55, var58);
    double[] var67 = var65.sample(9);
    boolean var68 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var35, var67);
    boolean var69 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    double[] var9 = new double[] { };
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var9, var11);
    double[] var15 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var15);
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var9, var15);
    org.apache.commons.math3.util.MathArrays.OrderDirection var18 = null;
    boolean var21 = org.apache.commons.math3.util.MathArrays.checkOrder(var15, var18, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
    boolean var24 = org.apache.commons.math3.util.MathArrays.isMonotonic(var15, var22, false);
    double[] var25 = new double[] { };
    double[] var27 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var27);
    double var29 = org.apache.commons.math3.util.MathArrays.distance1(var25, var27);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double var33 = org.apache.commons.math3.util.MathArrays.distance1(var25, var31);
    double var34 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    double[] var35 = org.apache.commons.math3.util.MathArrays.ebeDivide(var15, var31);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var6, var15);
    double[] var38 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var38);
    double[] var41 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var41);
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeDivide(var38, var41);
    double[] var44 = new double[] { };
    double[] var46 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var46);
    double var48 = org.apache.commons.math3.util.MathArrays.distance1(var44, var46);
    org.apache.commons.math3.util.MathArrays.OrderDirection var49 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var46, var49, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var46);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var53 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var43, var46);
    org.apache.commons.math3.util.MathArrays.OrderDirection var54 = null;
    double[] var55 = new double[] { };
    double[] var57 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var57);
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var55, var57);
    double[] var61 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var61);
    double var63 = org.apache.commons.math3.util.MathArrays.distance1(var55, var61);
    org.apache.commons.math3.util.MathArrays.OrderDirection var64 = null;
    double[] var66 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var66);
    double[] var69 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var69);
    double[] var71 = org.apache.commons.math3.util.MathArrays.ebeDivide(var66, var69);
    double[][] var72 = new double[][] { var69};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var61, var64, var72);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var43, var54, var72);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var75 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var43);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     double[] var0 = new double[] { };
//     double[] var2 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var2);
//     double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
//     double[] var6 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var6);
//     double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
//     double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var6);
//     double[] var10 = new double[] { };
//     double[] var12 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var12);
//     double var14 = org.apache.commons.math3.util.MathArrays.distance1(var10, var12);
//     double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
//     double[] var16 = new double[] { };
//     double[] var18 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var18);
//     double var20 = org.apache.commons.math3.util.MathArrays.distance1(var16, var18);
//     double[] var22 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var22);
//     double var24 = org.apache.commons.math3.util.MathArrays.distance1(var16, var22);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var25 = null;
//     boolean var28 = org.apache.commons.math3.util.MathArrays.checkOrder(var22, var25, false, true);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var29 = null;
//     boolean var31 = org.apache.commons.math3.util.MathArrays.isMonotonic(var22, var29, false);
//     double[] var32 = new double[] { };
//     double[] var34 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var34);
//     double var36 = org.apache.commons.math3.util.MathArrays.distance1(var32, var34);
//     double[] var38 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var38);
//     double var40 = org.apache.commons.math3.util.MathArrays.distance1(var32, var38);
//     double var41 = org.apache.commons.math3.util.MathArrays.safeNorm(var38);
//     double[] var42 = org.apache.commons.math3.util.MathArrays.ebeDivide(var22, var38);
//     double var43 = org.apache.commons.math3.util.MathArrays.distance(var15, var42);
//     double[] var45 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var45);
//     double[] var48 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var48);
//     double[] var50 = org.apache.commons.math3.util.MathArrays.ebeDivide(var45, var48);
//     double[] var51 = new double[] { };
//     double[] var53 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var53);
//     double var55 = org.apache.commons.math3.util.MathArrays.distance1(var51, var53);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var56 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var53, var56, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var53);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var60 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var50, var53);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var61 = null;
//     double[] var62 = new double[] { };
//     double[] var64 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var64);
//     double var66 = org.apache.commons.math3.util.MathArrays.distance1(var62, var64);
//     double[] var68 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var68);
//     double var70 = org.apache.commons.math3.util.MathArrays.distance1(var62, var68);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var71 = null;
//     double[] var73 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var73);
//     double[] var76 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var76);
//     double[] var78 = org.apache.commons.math3.util.MathArrays.ebeDivide(var73, var76);
//     double[][] var79 = new double[][] { var76};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var68, var71, var79);
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var50, var61, var79);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var82 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var42, var50);
//     double[] var83 = org.apache.commons.math3.util.MathArrays.ebeAdd(var6, var42);
//     double[] var85 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var85);
//     double var87 = org.apache.commons.math3.util.MathArrays.safeNorm(var85);
//     boolean var88 = org.apache.commons.math3.util.MathArrays.equals(var42, var85);
//     double[] var89 = null;
//     double var90 = org.apache.commons.math3.util.MathArrays.distanceInf(var42, var89);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(98.34128277750061d, 0.2683148062047325d, 984.6226564837881d, 1.078838815458333d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1088.635562624777d);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0, (java.lang.Number)1.0524812686407703d, true);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeedSecure();
    double[] var3 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var3);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeDivide(var3, var6);
    double[] var9 = new double[] { };
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var9, var11);
    org.apache.commons.math3.util.MathArrays.OrderDirection var14 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var11, var14, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var18 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var8, var11);
    boolean var19 = var18.isSupportLowerBoundInclusive();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var20 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var18);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)98.34128277750061d);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var20 = var16.getNumericalVariance();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var23 = var16.cumulativeProbability(83.3326923348544d, 9.927198205545196d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)9.973067336611587d, false);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    int[] var1 = new int[] { 100};
    int[] var3 = new int[] { 100};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
    int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var3);
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 10);
    int[] var11 = new int[] { 100};
    int[] var13 = new int[] { 100};
    int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    int var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var11, var13);
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var13);
    int[] var19 = new int[] { 100};
    int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var19);
    int var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var13, var19);
    int var22 = org.apache.commons.math3.util.MathArrays.distance1(var3, var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var3, var5);
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var2, var5);
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)98.46244963963788d, var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
    double[] var6 = new double[] { };
    double[] var8 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var8);
    double var10 = org.apache.commons.math3.util.MathArrays.distance1(var6, var8);
    double[] var12 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance1(var6, var12);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    boolean var18 = org.apache.commons.math3.util.MathArrays.checkOrder(var12, var15, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var19 = null;
    boolean var21 = org.apache.commons.math3.util.MathArrays.isMonotonic(var12, var19, false);
    double[] var22 = new double[] { };
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var22, var24);
    double[] var28 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var22, var28);
    double var31 = org.apache.commons.math3.util.MathArrays.safeNorm(var28);
    double[] var32 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var28);
    double var33 = org.apache.commons.math3.util.MathArrays.distance(var5, var32);
    double[] var35 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var35);
    double[] var38 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var38);
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeDivide(var35, var38);
    double[] var42 = org.apache.commons.math3.util.MathArrays.normalizeArray(var35, 100.0d);
    org.apache.commons.math3.util.MathArrays.OrderDirection var43 = null;
    boolean var46 = org.apache.commons.math3.util.MathArrays.checkOrder(var42, var43, false, false);
    double[] var47 = new double[] { };
    double[] var49 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var49);
    double var51 = org.apache.commons.math3.util.MathArrays.distance1(var47, var49);
    double[] var52 = org.apache.commons.math3.util.MathArrays.copyOf(var47);
    double[] var54 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var54);
    double[] var57 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var57);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeDivide(var54, var57);
    org.apache.commons.math3.util.MathArrays.checkOrder(var59);
    double var61 = org.apache.commons.math3.util.MathArrays.distanceInf(var47, var59);
    double[] var63 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var63);
    double[] var66 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var66);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var63, var66);
    double[] var69 = new double[] { };
    double[] var71 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance1(var69, var71);
    org.apache.commons.math3.util.MathArrays.checkPositive(var71);
    double var75 = org.apache.commons.math3.util.MathArrays.safeNorm(var71);
    double[] var76 = org.apache.commons.math3.util.MathArrays.ebeAdd(var63, var71);
    org.apache.commons.math3.util.MathArrays.OrderDirection var77 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var71, var77, true);
    double var80 = org.apache.commons.math3.util.MathArrays.distance1(var47, var71);
    boolean var81 = org.apache.commons.math3.util.MathArrays.equals(var42, var71);
    double var82 = org.apache.commons.math3.util.MathArrays.distanceInf(var32, var42);
    double[] var83 = new double[] { };
    double[] var85 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var85);
    double var87 = org.apache.commons.math3.util.MathArrays.distance1(var83, var85);
    org.apache.commons.math3.util.MathArrays.OrderDirection var88 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var85, var88, false);
    double var91 = org.apache.commons.math3.util.MathArrays.distance1(var42, var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 99.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == 0.0d);

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     int[] var0 = null;
//     int[] var2 = new int[] { 100};
//     int[] var4 = new int[] { 100};
//     int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
//     int var6 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var4);
//     int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var4);
//     int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var4, 10);
//     int var11 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.density(1.2316468095843844d);
    double var23 = var16.inverseCumulativeProbability(1.0d);
    boolean var24 = var16.isSupportLowerBoundInclusive();
    double var25 = var16.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)100, var1, 10, var3, false);
    java.lang.Number var6 = var5.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 1.0737206121073526d, 441262.0438411099d, 0.7090371711746789d, 0.03359081770746613d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 312871.1913118577d);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(88.2514775318289d, 59.5604882521082d, 0.90076811327417d, 37.394228706165585d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5289.984619604681d);

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     long var4 = var2.nextLong();
//     double var5 = var2.nextGaussian();
//     int[] var7 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var7);
//     int var9 = var8.nextInt();
//     long var10 = var8.nextLong();
//     byte[] var11 = new byte[] { };
//     var8.nextBytes(var11);
//     var2.nextBytes(var11);
//     java.util.List var14 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var15 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var14);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)100, (java.lang.Number)0.0f, 0, var3, false);
    java.lang.Number var6 = var5.getPrevious();
    java.lang.Number var7 = var5.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.0f+ "'", var6.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)100+ "'", var7.equals((short)100));

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     double var4 = var2.nextDouble();
//     var2.setSeed((-1));
//     var2.setSeed(0L);
//     long var9 = var2.nextLong();
//     var2.setSeed(10);
//     double var12 = var2.nextDouble();
//     int var14 = var2.nextInt(6);
//     int var15 = var2.nextInt();
//     byte[] var16 = null;
//     var2.nextBytes(var16);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1L);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(98.46619727159656d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.9405132696386548d));
// 
//   }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var3 = var0.nextT(98.28206305872513d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("bb52fd545", "5");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.5187955201189185d));
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)98.45317552126936d, (java.lang.Number)77.74838373665371d, (java.lang.Number)85.18111844245895d);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
    double[] var6 = new double[] { };
    double[] var8 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var8);
    double var10 = org.apache.commons.math3.util.MathArrays.distance1(var6, var8);
    double[] var12 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance1(var6, var12);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    boolean var18 = org.apache.commons.math3.util.MathArrays.checkOrder(var12, var15, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var19 = null;
    boolean var21 = org.apache.commons.math3.util.MathArrays.isMonotonic(var12, var19, false);
    double[] var22 = new double[] { };
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var22, var24);
    double[] var28 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var22, var28);
    double var31 = org.apache.commons.math3.util.MathArrays.safeNorm(var28);
    double[] var32 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var28);
    double var33 = org.apache.commons.math3.util.MathArrays.distance(var5, var32);
    org.apache.commons.math3.util.MathArrays.checkOrder(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextWeibull(1.6486550157904805d, 100.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var0.nextBinomial(4, 98.46317465054534d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 48.68529422694341d);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    double[] var8 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var8);
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.ebeDivide(var8, var11);
    double[] var14 = new double[] { };
    double[] var16 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var14, var16);
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double var20 = org.apache.commons.math3.util.MathArrays.safeNorm(var16);
    double[] var21 = org.apache.commons.math3.util.MathArrays.ebeAdd(var8, var16);
    double[] var23 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.0d);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var2, var21);
    double[] var26 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double[] var31 = org.apache.commons.math3.util.MathArrays.ebeDivide(var26, var29);
    double[] var32 = new double[] { };
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var32, var34);
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var38 = org.apache.commons.math3.util.MathArrays.safeNorm(var34);
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeAdd(var26, var34);
    org.apache.commons.math3.util.MathArrays.OrderDirection var40 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var34, var40, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var43 = null;
    boolean var46 = org.apache.commons.math3.util.MathArrays.checkOrder(var34, var43, true, false);
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var34);
    double[] var49 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var49);
    double[] var52 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var52);
    double[] var54 = org.apache.commons.math3.util.MathArrays.ebeDivide(var49, var52);
    double[] var55 = new double[] { };
    double[] var57 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var57);
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var55, var57);
    org.apache.commons.math3.util.MathArrays.OrderDirection var60 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var57, var60, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var64 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var54, var57);
    double[] var66 = var64.sample(9);
    boolean var67 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var66);
    double[] var69 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var69);
    double[] var72 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var72);
    double[] var74 = org.apache.commons.math3.util.MathArrays.ebeDivide(var69, var72);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var34, var72);
    double[] var77 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var77);
    double[] var80 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var77, var80);
    double[] var83 = new double[] { };
    double[] var85 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var85);
    double var87 = org.apache.commons.math3.util.MathArrays.distance1(var83, var85);
    org.apache.commons.math3.util.MathArrays.OrderDirection var88 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var85, var88, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var92 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var82, var85);
    double[] var94 = var92.sample(9);
    double var95 = org.apache.commons.math3.util.MathArrays.distanceInf(var75, var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == 9999.0d);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    double[] var9 = new double[] { };
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var9, var11);
    double[] var15 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var15);
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var9, var15);
    org.apache.commons.math3.util.MathArrays.OrderDirection var18 = null;
    boolean var21 = org.apache.commons.math3.util.MathArrays.checkOrder(var15, var18, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
    boolean var24 = org.apache.commons.math3.util.MathArrays.isMonotonic(var15, var22, false);
    double[] var25 = new double[] { };
    double[] var27 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var27);
    double var29 = org.apache.commons.math3.util.MathArrays.distance1(var25, var27);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double var33 = org.apache.commons.math3.util.MathArrays.distance1(var25, var31);
    double var34 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    double[] var35 = org.apache.commons.math3.util.MathArrays.ebeDivide(var15, var31);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var6, var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var38 = org.apache.commons.math3.util.MathArrays.copyOf(var15, 2074243331);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = var16.cumulativeProbability(114.41944065908152d, 5.184603928878863d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)444.0293055330172d, (java.lang.Number)145.29131161949542d, (java.lang.Number)0.7157990521557022d);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var10 = var1.nextWeibull(0.9846580496679653d, 0.7157990521557022d);
//     java.lang.String var12 = var1.nextHexString(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception", "org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.45687879155673d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 82.93950064720558d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.8626118748162986d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "9b100385822a4b136edcd7085cd9e9bd8b4a72561fce3313ba42c6fb6442e4bc0fa12a69a8256b102607a18836341848c28e"+ "'", var12.equals("9b100385822a4b136edcd7085cd9e9bd8b4a72561fce3313ba42c6fb6442e4bc0fa12a69a8256b102607a18836341848c28e"));
// 
//   }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     var0.setSeed(6);
//     double var3 = var0.nextDouble();
//     java.util.List var4 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var5 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var0, var4);
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.0737206121073526d, (java.lang.Number)9.95645506445408d, (java.lang.Number)10L);
    java.lang.Number var4 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 10L+ "'", var4.equals(10L));

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)100, (java.lang.Number)0.0f, 0, var3, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = var5.getDirection();
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextCauchy(253.07859717090338d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 202.40087983869444d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
    long var4 = var3.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var5.nextBinomial(6, 10.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-414028722650554365L));

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
//     long var4 = var3.nextLong();
//     org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
//     double var8 = var5.nextUniform(0.7090371711746789d, 3887.603878597613d);
//     long var11 = var5.nextSecureLong(100L, 152600911433040288L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var5.nextSecureInt(8, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-414028722650554365L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 606.9017688960619d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4135290241740522L);
// 
//   }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var0.nextPoisson((-0.6984489763881883d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 206.9892985227836d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)1L, false);
    java.lang.Number var5 = var4.getMax();
    java.lang.Number var6 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1L+ "'", var5.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1L+ "'", var6.equals(1L));

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.nextGaussian(1.2000918311981499d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-1), 8);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)43.11121494208779d);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(97.97864407980379d, 252.87948712226319d, 10000.0d, 9999.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0001477678926383E8d);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1205512795);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.density(1.2316468095843844d);
    boolean var22 = var16.isSupportLowerBoundInclusive();
    double var23 = var16.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    float[] var8 = new float[] { 0.0f, (-1.0f)};
    float[] var9 = null;
    boolean var10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var9);
    java.lang.Object[] var11 = new java.lang.Object[] { var9};
    org.apache.commons.math3.exception.MathArithmeticException var12 = new org.apache.commons.math3.exception.MathArithmeticException(var5, var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)(byte)10, var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)(short)10, var11);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var0, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }
// 
// 
//     int[] var1 = new int[] { 100};
//     int[] var3 = new int[] { 100};
//     int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
//     int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
//     int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var3);
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 10);
//     int[] var10 = null;
//     int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var10);
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var20 = var16.getNumericalVariance();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var23 = var16.probability(97.96410453789858d, 9.989741442300522d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     var0.reSeedSecure();
//     int var10 = var0.nextSecureInt(1, 2);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var13 = var0.nextSecureLong(100L, (-1L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 111.53456867440332d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2);
// 
//   }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var9 = var1.nextT(97.97864407980379d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextCauchy((-1.0d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.45605738146816d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 64.78947256880389d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.13908178627467233d);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)99.67690190423247d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportUpperBound();
    double var20 = var16.getSupportUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var23 = var16.cumulativeProbability(10.066613082682853d, 0.5790983875421128d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     double var13 = var0.nextT(99.2782319289774d);
//     double var15 = var0.nextT(98.47845151091803d);
//     double var18 = var0.nextF(98.47591907847392d, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var0.nextF(0.0d, 98.46652934914283d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 140.19332929972433d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.8185378229053348d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.13714088677380712d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.33402020072503635d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.11164711274324898d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.5539723204372758d);
// 
//   }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     double var8 = var1.nextUniform(1.0d, 1.2388070620041405d, false);
//     double var11 = var1.nextCauchy(0.5104454862955553d, 97.97864407980379d);
//     int var14 = var1.nextZipf(3, 1.0646160893106429d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("cdcc", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.913188206456411d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.1053493525176519d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 51.96352932756833d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)100.0d);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    java.lang.String var3 = var1.toString();
    java.lang.Number var4 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: 100 is smaller than the minimum (0)"+ "'", var3.equals("org.apache.commons.math3.exception.NotPositiveException: 100 is smaller than the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    java.lang.Comparable[] var2 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(byte)100, (java.lang.Object[])var2);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     double var13 = var0.nextT(99.2782319289774d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var15 = var0.nextHexString((-63560251));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 168.10054842582304d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.18519625681369334d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3.1479015008133198d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.16021162109224252d));
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    java.lang.Number var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var2 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, var1);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.03359081770746613d, 83.3326923348544d, 1.0d, 0.5790983875421128d, 1.0001477678926383E8d, 88.20256579008964d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 8.821559933114485E9d);

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     double var13 = var0.nextT(99.2782319289774d);
//     double[] var15 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var15);
//     double[] var18 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var18);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.ebeDivide(var15, var18);
//     double[] var21 = new double[] { };
//     double[] var23 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var23);
//     double var25 = org.apache.commons.math3.util.MathArrays.distance1(var21, var23);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var26 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var23, var26, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var23);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var30 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var23);
//     double[] var32 = var30.sample(9);
//     double var33 = var30.getSupportLowerBound();
//     double var34 = var30.sample();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var35 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var30);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 134.39444345916218d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.021094865243866393d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 5.689135985352617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.5209164067573461d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1.0d);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var3, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)110.67903653979582d, (java.lang.Number)4.669559638492801d, false);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var17 = var16.getSupportUpperBound();
    boolean var18 = var16.isSupportLowerBoundInclusive();
    double var20 = var16.cumulativeProbability(1.0646160893106429d);
    var16.reseedRandomGenerator(10L);
    double var23 = var16.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var3 = var2.getValue();
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl();
    var5.reSeed();
    boolean var7 = var2.equals((java.lang.Object)var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var5.nextBinomial(30, 312871.1913118577d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1L+ "'", var3.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = new double[] { };
//     double[] var3 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var3);
//     double var5 = org.apache.commons.math3.util.MathArrays.distance1(var1, var3);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var3);
//     double var7 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
//     double[] var9 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var9);
//     double[] var12 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var12);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.ebeDivide(var9, var12);
//     double[] var15 = new double[] { };
//     double[] var17 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var17);
//     double var19 = org.apache.commons.math3.util.MathArrays.distance1(var15, var17);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var17);
//     double var21 = org.apache.commons.math3.util.MathArrays.safeNorm(var17);
//     double[] var22 = org.apache.commons.math3.util.MathArrays.ebeAdd(var9, var17);
//     double[] var24 = org.apache.commons.math3.util.MathArrays.normalizeArray(var22, 0.0d);
//     double var25 = org.apache.commons.math3.util.MathArrays.distance1(var3, var22);
//     double[] var27 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var27);
//     double[] var30 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var30);
//     double[] var32 = org.apache.commons.math3.util.MathArrays.ebeDivide(var27, var30);
//     double[] var33 = new double[] { };
//     double[] var35 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var35);
//     double var37 = org.apache.commons.math3.util.MathArrays.distance1(var33, var35);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var35);
//     double var39 = org.apache.commons.math3.util.MathArrays.safeNorm(var35);
//     double[] var40 = org.apache.commons.math3.util.MathArrays.ebeAdd(var27, var35);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var41 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var35, var41, true);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var44 = null;
//     boolean var47 = org.apache.commons.math3.util.MathArrays.checkOrder(var35, var44, true, false);
//     double[] var48 = org.apache.commons.math3.util.MathArrays.ebeDivide(var22, var35);
//     double[] var50 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var50);
//     double[] var53 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var53);
//     double[] var55 = org.apache.commons.math3.util.MathArrays.ebeDivide(var50, var53);
//     double[] var56 = new double[] { };
//     double[] var58 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var58);
//     double var60 = org.apache.commons.math3.util.MathArrays.distance1(var56, var58);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var61 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var58, var61, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var58);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var65 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var55, var58);
//     double[] var67 = var65.sample(9);
//     boolean var68 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var35, var67);
//     double[] var70 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var70);
//     double[] var73 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var73);
//     double[] var75 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var73);
//     double[] var76 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var35, var73);
//     double[] var77 = org.apache.commons.math3.util.MathArrays.ebeDivide(var0, var35);
// 
//   }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     int var6 = var0.nextPascal(1, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextUniform(192.2191052341085d, (-1.0d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2147483647);
// 
//   }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 7, (-1));
// 
//   }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(98.45317552126936d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextUniform(9999.0d, 98.38153633363427d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.13865996836168015d);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var3 = new long[] { 0L, 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    long[][] var5 = new long[][] { var3};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)441262.0438411099d);

  }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("a8bb2312", "6c8f794b2");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.755555727492544d);
// 
//   }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("1", "f");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "cbb200177"+ "'", var2.equals("cbb200177"));
// 
//   }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
//     java.lang.Object var3 = var2.getValue();
//     org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
//     org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var8 = var5.nextInt(0, 10);
//     double var11 = var5.nextGaussian(100.0d, 115.88842315603809d);
//     boolean var12 = var4.equals((java.lang.Object)var11);
//     java.lang.Object var13 = var4.getKey();
//     java.lang.Object var14 = null;
//     boolean var15 = var4.equals(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + 1L+ "'", var3.equals(1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 210.92556641937855d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + (-1L)+ "'", var13.equals((-1L)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
// 
//   }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     double var13 = var0.nextT(99.2782319289774d);
//     double var15 = var0.nextT(98.47845151091803d);
//     double var18 = var0.nextF(98.47591907847392d, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var0.nextUniform(742.6248114744293d, 97.96410453789858d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 233.5852185604819d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.31344911590733476d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.34470098653881387d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.20301792497098856d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.3472459376125936d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 17.525541194582576d);
// 
//   }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     int var4 = var0.nextInt(0, 10);
//     double var7 = var0.nextGaussian(1.176542981693557d, 1.8507918026021757d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var9 = var0.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.1990039344395793d);
// 
//   }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var0.nextLong(43059505226525080L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 74.46512911171332d);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(101L);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var6);
    double[] var10 = new double[] { };
    double[] var12 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance1(var10, var12);
    double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    double[] var16 = new double[] { };
    double[] var18 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var18);
    double var20 = org.apache.commons.math3.util.MathArrays.distance1(var16, var18);
    double[] var22 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var16, var22);
    org.apache.commons.math3.util.MathArrays.OrderDirection var25 = null;
    boolean var28 = org.apache.commons.math3.util.MathArrays.checkOrder(var22, var25, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var29 = null;
    boolean var31 = org.apache.commons.math3.util.MathArrays.isMonotonic(var22, var29, false);
    double[] var32 = new double[] { };
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var32, var34);
    double[] var38 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var38);
    double var40 = org.apache.commons.math3.util.MathArrays.distance1(var32, var38);
    double var41 = org.apache.commons.math3.util.MathArrays.safeNorm(var38);
    double[] var42 = org.apache.commons.math3.util.MathArrays.ebeDivide(var22, var38);
    double var43 = org.apache.commons.math3.util.MathArrays.distance(var15, var42);
    double[] var45 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var45);
    double[] var48 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeDivide(var45, var48);
    double[] var51 = new double[] { };
    double[] var53 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var53);
    double var55 = org.apache.commons.math3.util.MathArrays.distance1(var51, var53);
    org.apache.commons.math3.util.MathArrays.OrderDirection var56 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var53, var56, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var53);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var60 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var50, var53);
    org.apache.commons.math3.util.MathArrays.OrderDirection var61 = null;
    double[] var62 = new double[] { };
    double[] var64 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var64);
    double var66 = org.apache.commons.math3.util.MathArrays.distance1(var62, var64);
    double[] var68 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var68);
    double var70 = org.apache.commons.math3.util.MathArrays.distance1(var62, var68);
    org.apache.commons.math3.util.MathArrays.OrderDirection var71 = null;
    double[] var73 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var73);
    double[] var76 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var76);
    double[] var78 = org.apache.commons.math3.util.MathArrays.ebeDivide(var73, var76);
    double[][] var79 = new double[][] { var76};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var68, var71, var79);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var50, var61, var79);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var82 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var42, var50);
    double[] var83 = org.apache.commons.math3.util.MathArrays.ebeAdd(var6, var42);
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
    double[] var7 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var7);
    double[] var10 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var10);
    double[] var12 = org.apache.commons.math3.util.MathArrays.ebeDivide(var7, var10);
    double[] var13 = new double[] { };
    double[] var15 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var15);
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var13, var15);
    org.apache.commons.math3.util.MathArrays.OrderDirection var18 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var15, var18, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var15);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var22 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var12, var15);
    org.apache.commons.math3.util.MathArrays.OrderDirection var23 = null;
    double[] var24 = new double[] { };
    double[] var26 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var24, var26);
    double[] var30 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var30);
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var24, var30);
    org.apache.commons.math3.util.MathArrays.OrderDirection var33 = null;
    double[] var35 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var35);
    double[] var38 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var38);
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeDivide(var35, var38);
    double[][] var41 = new double[][] { var38};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var30, var33, var41);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var12, var23, var41);
    double[] var45 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var45);
    double[] var48 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeDivide(var45, var48);
    double[] var52 = org.apache.commons.math3.util.MathArrays.normalizeArray(var45, 100.0d);
    org.apache.commons.math3.util.MathArrays.OrderDirection var53 = null;
    boolean var56 = org.apache.commons.math3.util.MathArrays.checkOrder(var52, var53, false, false);
    double[] var57 = new double[] { };
    double[] var59 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var59);
    double var61 = org.apache.commons.math3.util.MathArrays.distance1(var57, var59);
    double[] var62 = org.apache.commons.math3.util.MathArrays.copyOf(var57);
    double[] var64 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var64);
    double[] var67 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var67);
    double[] var69 = org.apache.commons.math3.util.MathArrays.ebeDivide(var64, var67);
    org.apache.commons.math3.util.MathArrays.checkOrder(var69);
    double var71 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var69);
    double[] var73 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var73);
    double[] var76 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var76);
    double[] var78 = org.apache.commons.math3.util.MathArrays.ebeDivide(var73, var76);
    double[] var79 = new double[] { };
    double[] var81 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var81);
    double var83 = org.apache.commons.math3.util.MathArrays.distance1(var79, var81);
    org.apache.commons.math3.util.MathArrays.checkPositive(var81);
    double var85 = org.apache.commons.math3.util.MathArrays.safeNorm(var81);
    double[] var86 = org.apache.commons.math3.util.MathArrays.ebeAdd(var73, var81);
    org.apache.commons.math3.util.MathArrays.OrderDirection var87 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var81, var87, true);
    double var90 = org.apache.commons.math3.util.MathArrays.distance1(var57, var81);
    boolean var91 = org.apache.commons.math3.util.MathArrays.equals(var52, var81);
    boolean var92 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var81);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var93 = org.apache.commons.math3.util.MathArrays.ebeAdd(var0, var12);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == false);

  }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 7);
// 
//   }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(98.45317552126936d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var4 = var0.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6172681915434381d);
// 
//   }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    float[] var7 = new float[] { 0.0f, (-1.0f)};
    float[] var8 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var8);
    java.lang.Object[] var10 = new java.lang.Object[] { var8};
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var4, var10);
    org.apache.commons.math3.exception.MathArithmeticException var12 = new org.apache.commons.math3.exception.MathArithmeticException(var3, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)0.020579212303715753d, var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.3220963206821523d, (java.lang.Number)299.89733044110505d, 8);
    org.apache.commons.math3.exception.NotANumberException var4 = new org.apache.commons.math3.exception.NotANumberException();
    var3.addSuppressed((java.lang.Throwable)var4);
    boolean var6 = var3.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
    double[] var11 = new double[] { };
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var11, var13);
    double[] var17 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var17);
    double var19 = org.apache.commons.math3.util.MathArrays.distance1(var11, var17);
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
    boolean var23 = org.apache.commons.math3.util.MathArrays.checkOrder(var17, var20, false, true);
    double[] var24 = new double[] { };
    double[] var26 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var24, var26);
    double[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var24);
    double[] var30 = new double[] { };
    double[] var32 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distance1(var30, var32);
    double[] var36 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var36);
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var30, var36);
    org.apache.commons.math3.util.MathArrays.OrderDirection var39 = null;
    boolean var42 = org.apache.commons.math3.util.MathArrays.checkOrder(var36, var39, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var43 = null;
    boolean var45 = org.apache.commons.math3.util.MathArrays.isMonotonic(var36, var43, false);
    double[] var46 = new double[] { };
    double[] var48 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var48);
    double var50 = org.apache.commons.math3.util.MathArrays.distance1(var46, var48);
    double[] var52 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var52);
    double var54 = org.apache.commons.math3.util.MathArrays.distance1(var46, var52);
    double var55 = org.apache.commons.math3.util.MathArrays.safeNorm(var52);
    double[] var56 = org.apache.commons.math3.util.MathArrays.ebeDivide(var36, var52);
    double var57 = org.apache.commons.math3.util.MathArrays.distance(var29, var56);
    double[] var58 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var17, var56);
    org.apache.commons.math3.util.MathArrays.OrderDirection var59 = null;
    double[] var61 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var61);
    double[] var64 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var64);
    double[] var66 = org.apache.commons.math3.util.MathArrays.ebeDivide(var61, var64);
    double[] var67 = new double[] { };
    double[] var69 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var69);
    double var71 = org.apache.commons.math3.util.MathArrays.distance1(var67, var69);
    org.apache.commons.math3.util.MathArrays.OrderDirection var72 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var69, var72, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var69);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var76 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var66, var69);
    org.apache.commons.math3.util.MathArrays.OrderDirection var77 = null;
    double[] var78 = new double[] { };
    double[] var80 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var80);
    double var82 = org.apache.commons.math3.util.MathArrays.distance1(var78, var80);
    double[] var84 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var84);
    double var86 = org.apache.commons.math3.util.MathArrays.distance1(var78, var84);
    org.apache.commons.math3.util.MathArrays.OrderDirection var87 = null;
    double[] var89 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var89);
    double[] var92 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var92);
    double[] var94 = org.apache.commons.math3.util.MathArrays.ebeDivide(var89, var92);
    double[][] var95 = new double[][] { var92};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var84, var87, var95);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var66, var77, var95);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var58, var59, var95);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var6, var10, var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-97.02018957950251d), (java.lang.Number)0.2905339688026802d, true);

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     double var13 = var0.nextT(99.2782319289774d);
//     double var15 = var0.nextT(98.47845151091803d);
//     double var17 = var0.nextT(98.47845151091803d);
//     double var20 = var0.nextCauchy((-0.21819979512271087d), 9.871651067214367d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 22.99329045273265d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.08748839710302334d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3.585690753785132d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.1928598019429595d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.8305377380798146d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.7972250154848055d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-37.441946953176824d));
// 
//   }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var1.nextBinomial(9, 98.46324585220091d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.35380139076385d);
// 
//   }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 10, 1);
//     org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
// 
//   }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(1.2388070620041405d, 98.45317552126936d, true);
//     double var13 = var1.nextExponential(290.77256675474683d);
//     double var16 = var1.nextWeibull(0.9846580496679653d, 9.927198205545196d);
//     long var18 = var1.nextPoisson(99.02988657003175d);
//     double var21 = var1.nextWeibull(165.22373033698972d, 1.505308581282821d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.31175838896063d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 78.47624422463014d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 50.86260633466009d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 201.76160301238804d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.7079794124142618d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 112L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.5091446198888345d);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(189.69032873251956d, 9.871651067214367d, 98.38153633363427d, 78.47624422463014d, 1.4815958130930773d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 9593.170208585227d);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0557163353000482E-9d, (java.lang.Number)100.26932579100311d, true);

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     double var13 = var0.nextT(99.2782319289774d);
//     double var15 = var0.nextT(98.47845151091803d);
//     double var18 = var0.nextF(98.47591907847392d, 1.0d);
//     long var20 = var0.nextPoisson(444.0293055330172d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.0896657965554652d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.7473807753292526d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.5523831119597444d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.575535399271745d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5161149607674071d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 127.85684586340369d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 473L);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.density(1.2316468095843844d);
    double var23 = var16.inverseCumulativeProbability(1.0d);
    double var24 = var16.getSupportLowerBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var26 = var16.sample((-63560251));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0d);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-37.441946953176824d), (java.lang.Number)219.9831171065414d, (java.lang.Number)247.45752224305923d);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)210.05292023350523d, (java.lang.Number)1.5957881318373452d, var3);
    java.lang.Number var5 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.5957881318373452d+ "'", var5.equals(1.5957881318373452d));

  }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     long var6 = var1.nextPoisson(1.2388070620041405d);
//     double var8 = var1.nextT(6.7068743582446215d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextPascal(0, 1.0557163353000482E-9d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.41556992556949d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.19805057596259695d));
// 
//   }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 10);
// 
//   }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     int var9 = var1.nextZipf(10, 13.521216539811984d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var1.nextInt(0, (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 100.18985427244328d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "a"+ "'", var6.equals("a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
// 
//   }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var9 = var1.nextT(97.97864407980379d);
//     java.lang.String var11 = var1.nextHexString(10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.56004615791063d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 106.58707873865742d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.6368217509307181d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "ae923936ad"+ "'", var11.equals("ae923936ad"));
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.23344772945559902d, (java.lang.Number)312871.1913118577d, (java.lang.Number)98.2718673777206d);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    float[] var0 = null;
    float[] var1 = new float[] { };
    boolean var2 = org.apache.commons.math3.util.MathArrays.equals(var0, var1);
    float[] var5 = new float[] { 0.0f, (-1.0f)};
    float[] var6 = null;
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var6);
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var0, var5);
    float[] var9 = null;
    float[] var10 = new float[] { };
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var9, var10);
    float[] var14 = new float[] { 0.0f, (-1.0f)};
    float[] var15 = null;
    boolean var16 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var15);
    boolean var17 = org.apache.commons.math3.util.MathArrays.equals(var9, var14);
    float[] var18 = null;
    float[] var19 = new float[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var18, var19);
    float[] var23 = new float[] { 0.0f, (-1.0f)};
    float[] var24 = null;
    boolean var25 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var23, var24);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var18, var23);
    float[] var27 = null;
    float[] var28 = new float[] { };
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var27, var28);
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var23, var28);
    float[] var31 = null;
    float[] var32 = new float[] { };
    boolean var33 = org.apache.commons.math3.util.MathArrays.equals(var31, var32);
    float[] var36 = new float[] { 0.0f, (-1.0f)};
    float[] var37 = null;
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var36, var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var31, var36);
    float[] var40 = null;
    float[] var41 = new float[] { };
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var40, var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var23, var36);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var14, var23);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var5, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)2104590830736605696L, (java.lang.Number)3887.603878597613d, false);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var5 = var1.nextSecureHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)0.0d, false);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    double[] var8 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var8);
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.ebeDivide(var8, var11);
    double[] var14 = new double[] { };
    double[] var16 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var14, var16);
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double var20 = org.apache.commons.math3.util.MathArrays.safeNorm(var16);
    double[] var21 = org.apache.commons.math3.util.MathArrays.ebeAdd(var8, var16);
    double[] var23 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.0d);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var2, var21);
    double[] var26 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double[] var31 = org.apache.commons.math3.util.MathArrays.ebeDivide(var26, var29);
    double[] var32 = new double[] { };
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var32, var34);
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var38 = org.apache.commons.math3.util.MathArrays.safeNorm(var34);
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeAdd(var26, var34);
    org.apache.commons.math3.util.MathArrays.OrderDirection var40 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var34, var40, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var43 = null;
    boolean var46 = org.apache.commons.math3.util.MathArrays.checkOrder(var34, var43, true, false);
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var34);
    double[] var49 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var49);
    double[] var52 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var52);
    double[] var54 = org.apache.commons.math3.util.MathArrays.ebeDivide(var49, var52);
    double[] var55 = new double[] { };
    double[] var57 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var57);
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var55, var57);
    org.apache.commons.math3.util.MathArrays.OrderDirection var60 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var57, var60, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var64 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var54, var57);
    double[] var66 = var64.sample(9);
    boolean var67 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var66);
    double[] var69 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var69);
    double[] var72 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var72);
    double[] var74 = org.apache.commons.math3.util.MathArrays.ebeDivide(var69, var72);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var34, var72);
    double[] var77 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var77);
    double[] var80 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var77, var80);
    double[] var83 = new double[] { };
    double[] var85 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var85);
    double var87 = org.apache.commons.math3.util.MathArrays.distance1(var83, var85);
    org.apache.commons.math3.util.MathArrays.checkPositive(var85);
    double var89 = org.apache.commons.math3.util.MathArrays.safeNorm(var85);
    double[] var90 = org.apache.commons.math3.util.MathArrays.ebeAdd(var77, var85);
    double[] var92 = org.apache.commons.math3.util.MathArrays.normalizeArray(var90, 0.0d);
    double[] var93 = org.apache.commons.math3.util.MathArrays.copyOf(var92);
    double var94 = org.apache.commons.math3.util.MathArrays.distanceInf(var75, var93);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var96 = org.apache.commons.math3.util.MathArrays.copyOf(var75, (-63560251));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 10000.0d);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var1 = new double[] { };
    double[] var3 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var3);
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var1, var3);
    double[] var7 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var7);
    double var9 = org.apache.commons.math3.util.MathArrays.distance1(var1, var7);
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
    double[] var12 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var12);
    double[] var15 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var15);
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var15);
    double[][] var18 = new double[][] { var15};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var7, var10, var18);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.util.ExceptionContext var21 = var20.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     long var12 = var0.nextLong((-414028722650554365L), 100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextExponential((-1.0d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 65.35409227980702d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.99873065180545d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-240657142919925472L));
// 
//   }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     double var10 = var0.nextWeibull(97.97864407980379d, 9999.0d);
//     double var12 = var0.nextT(1.7904651608248163d);
//     double var15 = var0.nextCauchy(167.10424588351813d, 51.30880113197997d);
//     java.util.Collection var16 = null;
//     java.lang.Object[] var18 = var0.nextSample(var16, 2147483647);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)88.2514775318289d);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextWeibull(1.6486550157904805d, 100.0d);
//     double var7 = var0.nextGamma(98.88500098380753d, 1.0847091605564438d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var9 = var0.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 86.26208630951011d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 117.95264899614834d);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 10, 100);
    int var4 = var3.getDimension();
    int var5 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 100);

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     double var8 = var1.nextUniform(1.0d, 1.2388070620041405d, false);
//     double var12 = var1.nextUniform((-1.0d), 121.6356374977755d, true);
//     long var15 = var1.nextLong(259766232686583471L, 3513799009476651814L);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var1.nextHypergeometric(30, (-1), 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10.139941097566735d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.176233421123003d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 90.98483704421328d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1648973061404153856L);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
    double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var13);
    double[] var17 = new double[] { };
    double[] var19 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance1(var17, var19);
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var13, var19);
    double[] var25 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var13);
    double[] var26 = new double[] { };
    double[] var28 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var26, var28);
    double[] var32 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distance1(var26, var32);
    org.apache.commons.math3.util.MathArrays.OrderDirection var35 = null;
    boolean var38 = org.apache.commons.math3.util.MathArrays.checkOrder(var32, var35, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var39 = null;
    boolean var41 = org.apache.commons.math3.util.MathArrays.isMonotonic(var32, var39, false);
    double[] var42 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var1, var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)1.0737206121073526d, 4, var3, true);
    boolean var6 = var5.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     double var8 = var1.nextUniform(1.0d, 1.2388070620041405d, false);
//     double var12 = var1.nextUniform((-1.0d), 121.6356374977755d, true);
//     long var15 = var1.nextLong(259766232686583471L, 3513799009476651814L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var18 = var1.nextPermutation(2147483647, 4);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.834351579781941d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.1305167668343186d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 83.72012408505144d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 3182155110664172544L);
// 
//   }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     java.lang.String var6 = var1.nextHexString(10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var1.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "0bfe3093b3"+ "'", var6.equals("0bfe3093b3"));
// 
//   }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     double var8 = var1.nextUniform(1.0d, 1.2388070620041405d, false);
//     double var11 = var1.nextCauchy(0.5104454862955553d, 97.97864407980379d);
//     int var14 = var1.nextZipf(3, 1.0646160893106429d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.nextT((-0.13831581778337934d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10.058886172379516d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.196618687118677d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-653.7734831369431d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(98.46516229978855d, 78.47624422463014d, 98.44078667812042d, 263.1966961055d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 33636.46593996366d);

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     int[] var0 = null;
//     int[] var2 = new int[] { 100};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
//     int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var2, 6);
//     double var6 = org.apache.commons.math3.util.MathArrays.distance(var0, var5);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-96398574), 3);

  }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     int var10 = var1.nextInt(0, 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.43713016096305d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 91.73734938536145d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
// 
//   }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)4, (java.lang.Number)10.049872943398238d, true);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(byte)1, var1, (java.lang.Number)(short)0);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getArgument();
    java.lang.Number var6 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)1+ "'", var5.equals((byte)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var6);
    double[] var10 = new double[] { };
    double[] var12 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance1(var10, var12);
    double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    double[] var16 = new double[] { };
    double[] var18 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var18);
    double var20 = org.apache.commons.math3.util.MathArrays.distance1(var16, var18);
    double[] var22 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var16, var22);
    org.apache.commons.math3.util.MathArrays.OrderDirection var25 = null;
    boolean var28 = org.apache.commons.math3.util.MathArrays.checkOrder(var22, var25, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var29 = null;
    boolean var31 = org.apache.commons.math3.util.MathArrays.isMonotonic(var22, var29, false);
    double[] var32 = new double[] { };
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var32, var34);
    double[] var38 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var38);
    double var40 = org.apache.commons.math3.util.MathArrays.distance1(var32, var38);
    double var41 = org.apache.commons.math3.util.MathArrays.safeNorm(var38);
    double[] var42 = org.apache.commons.math3.util.MathArrays.ebeDivide(var22, var38);
    double var43 = org.apache.commons.math3.util.MathArrays.distance(var15, var42);
    double[] var45 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var45);
    double[] var48 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeDivide(var45, var48);
    double[] var51 = new double[] { };
    double[] var53 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var53);
    double var55 = org.apache.commons.math3.util.MathArrays.distance1(var51, var53);
    org.apache.commons.math3.util.MathArrays.OrderDirection var56 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var53, var56, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var53);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var60 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var50, var53);
    org.apache.commons.math3.util.MathArrays.OrderDirection var61 = null;
    double[] var62 = new double[] { };
    double[] var64 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var64);
    double var66 = org.apache.commons.math3.util.MathArrays.distance1(var62, var64);
    double[] var68 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var68);
    double var70 = org.apache.commons.math3.util.MathArrays.distance1(var62, var68);
    org.apache.commons.math3.util.MathArrays.OrderDirection var71 = null;
    double[] var73 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var73);
    double[] var76 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var76);
    double[] var78 = org.apache.commons.math3.util.MathArrays.ebeDivide(var73, var76);
    double[][] var79 = new double[][] { var76};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var68, var71, var79);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var50, var61, var79);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var82 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var42, var50);
    double[] var83 = org.apache.commons.math3.util.MathArrays.ebeAdd(var6, var42);
    org.apache.commons.math3.util.MathArrays.OrderDirection var84 = null;
    boolean var86 = org.apache.commons.math3.util.MathArrays.isMonotonic(var83, var84, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == true);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    float[] var0 = null;
    float[] var1 = null;
    float[] var2 = new float[] { };
    boolean var3 = org.apache.commons.math3.util.MathArrays.equals(var1, var2);
    float[] var4 = null;
    float[] var5 = new float[] { };
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var4, var5);
    float[] var9 = new float[] { 0.0f, (-1.0f)};
    float[] var10 = null;
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var4, var9);
    float[] var13 = null;
    float[] var14 = new float[] { };
    boolean var15 = org.apache.commons.math3.util.MathArrays.equals(var13, var14);
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var9, var14);
    float[] var17 = null;
    float[] var18 = new float[] { };
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var17, var18);
    float[] var22 = new float[] { 0.0f, (-1.0f)};
    float[] var23 = null;
    boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var22, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var17, var22);
    float[] var26 = null;
    float[] var27 = new float[] { };
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var26, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var22, var27);
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var9, var22);
    boolean var31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var22);
    float[] var32 = new float[] { };
    boolean var33 = org.apache.commons.math3.util.MathArrays.equals(var2, var32);
    boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var0, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     double var13 = var0.nextT(99.2782319289774d);
//     double var15 = var0.nextT(98.47845151091803d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextPascal(0, 0.05877392154888082d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 95.91157515814655d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.4791600509651668d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.6494523165720554d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.38612743765680607d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.6018023824902752d);
// 
//   }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(1.2388070620041405d, 98.45317552126936d, true);
//     long var13 = var1.nextPoisson(1.2388070620041405d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var16 = var1.nextSecureLong(259766232686583471L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.45869689073982d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 93.00763484687006d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 29.38782489816949d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1L);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)2104590830736605696L, (java.lang.Number)3887.603878597613d, false);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    float[] var6 = new float[] { 0.0f, (-1.0f)};
    float[] var7 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var6, var7);
    java.lang.Object[] var9 = new java.lang.Object[] { var7};
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var3, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)(byte)10, var9);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var0, var9);
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var12.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(1.2388070620041405d, 98.45317552126936d, true);
//     double var13 = var1.nextExponential(290.77256675474683d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextBinomial(7, 10.049715760608617d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.44024226889175d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 106.91752178454317d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 92.44067573366604d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 354.5497618580868d);
// 
//   }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextGaussian(0.23344772945559902d, 1.8229678545960526d);
//     double var7 = var1.nextUniform(0.7157990521557022d, 3.7551631969543857d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.1202883854072287d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.70923385857421d);
// 
//   }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     var0.reSeedSecure((-1L));
//     var0.reSeedSecure((-414028722650554365L));
//     double var15 = var0.nextT(97.96410453789858d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextInt(2074243331, 2074243331);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 193.87438681507734d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "842784174b"+ "'", var9.equals("842784174b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1.5300647817125457d));
// 
//   }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     var0.reSeedSecure((-1L));
//     var0.reSeedSecure((-414028722650554365L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextBinomial(0, 103.89205253196047d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 220.23371367216717d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "ce90ab9993"+ "'", var9.equals("ce90ab9993"));
// 
//   }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = org.apache.commons.math3.util.MathArrays.normalizeArray(var0, 3.296907484618753d);
// 
//   }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextInt((-1), 8);
//     int var10 = var0.nextInt((-1), 6);
//     double var12 = var0.nextChiSquare(0.2700290390806306d);
//     double var15 = var0.nextCauchy(98.34128277750061d, 106.0271272985156d);
//     var0.reSeed(259766232686583471L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 211.5409799176563d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.00801543912443346d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 163.87452391184175d);
// 
//   }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var1.nextSecureInt(0, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.4512787602016d);
// 
//   }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     double var9 = var1.nextF(98.34128277750061d, 98.42176142483318d);
//     double var11 = var1.nextChiSquare(1.0847091605564438d);
//     double var14 = var1.nextGamma(0.01360821383479298d, 312871.1913118577d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 99.56259882352816d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "a"+ "'", var6.equals("a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.7644474751903642d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.1707426224135316d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.012945788904241426d);
// 
//   }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     long var6 = var1.nextPoisson(1.2388070620041405d);
//     double var8 = var1.nextT(6.7068743582446215d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var1.nextHypergeometric(0, (-63560251), 10);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.4349958621076d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.8947001298509705d));
// 
//   }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10);

  }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextWeibull(1.6486550157904805d, 100.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextF(0.7446287025499129d, (-6.225449347177431d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 112.56744229345257d);
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    double[] var0 = null;
    double[] var1 = null;
    boolean var2 = org.apache.commons.math3.util.MathArrays.equals(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     double var4 = var2.nextDouble();
//     var2.setSeed((-1));
//     var2.setSeed(0L);
//     long var9 = var2.nextLong();
//     var2.setSeed(10);
//     var2.clear();
//     org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
//     java.util.List var14 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var15 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var14);
// 
//   }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 6, 2);
// 
//   }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     int var4 = var0.nextInt(0, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("e06d56c374", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
// 
//   }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     var0.reSeedSecure();
//     double var9 = var0.nextT(290.77256675474683d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var12 = var0.nextPermutation((-63560251), (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 335.30174177884646d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.0651879465677623d);
// 
//   }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(100L);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
    boolean var19 = org.apache.commons.math3.util.MathArrays.checkOrder(var13, var16, false, true);
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var24);
    double[] var28 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.0d);
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var13, var21);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeDivide(var31, var34);
    double[] var38 = org.apache.commons.math3.util.MathArrays.normalizeArray(var31, 100.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var39 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var13, var31);
    double var40 = var39.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 100.0d);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    long var3 = var2.nextLong();
    var2.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-414028722650554365L));

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var7 = var1.nextSecureLong(32486561562015632L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.756279690431388d);
// 
//   }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var1.nextInt(2147483647, 2074243331);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 100.71353281927911d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "b"+ "'", var6.equals("b"));
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(187.4155101509404d, 99.67690190423247d, 2.5523831119597444d, 0.9775554539871507d, (-0.03939892277575102d), 98.41573398641329d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 18679.615042775484d);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.0469031636391882d, (java.lang.Number)78.57664175278842d, false);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
    double[] var7 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var7);
    double[] var10 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var10);
    double[] var12 = org.apache.commons.math3.util.MathArrays.ebeDivide(var7, var10);
    org.apache.commons.math3.util.MathArrays.checkOrder(var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var12);
    double[] var16 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double[] var19 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double[] var21 = org.apache.commons.math3.util.MathArrays.ebeDivide(var16, var19);
    double[] var22 = new double[] { };
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var22, var24);
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double var28 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
    double[] var29 = org.apache.commons.math3.util.MathArrays.ebeAdd(var16, var24);
    org.apache.commons.math3.util.MathArrays.OrderDirection var30 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var24, var30, true);
    double var33 = org.apache.commons.math3.util.MathArrays.distance1(var0, var24);
    org.apache.commons.math3.util.MathArrays.OrderDirection var34 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var0, var34, false);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     org.apache.commons.math3.distribution.IntegerDistribution var5 = null;
//     int var6 = var0.nextInversionDeviate(var5);
// 
//   }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.7090371711746789d);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     float[] var11 = new float[] { 0.0f, (-1.0f)};
//     float[] var12 = null;
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var12);
//     java.lang.Object[] var14 = new java.lang.Object[] { var12};
//     org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var8, var14);
//     org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var6, (java.lang.Number)(byte)10, var14);
//     org.apache.commons.math3.exception.MathInternalError var17 = new org.apache.commons.math3.exception.MathInternalError(var5, var14);
//     org.apache.commons.math3.exception.MathArithmeticException var18 = new org.apache.commons.math3.exception.MathArithmeticException(var4, var14);
//     org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, var14);
// 
//   }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     double var13 = var0.nextT(99.2782319289774d);
//     double var15 = var0.nextT(98.47845151091803d);
//     double var17 = var0.nextT(98.47845151091803d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var20 = var0.nextPermutation(30, (-1128991284));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 132.00237830524497d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.2887607524149518d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0761129393735238d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.048828515650781903d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.4669736296382239d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.21332331638920954d);
// 
//   }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     double var9 = var1.nextF(98.34128277750061d, 98.42176142483318d);
//     double var12 = var1.nextGaussian(9.927198205545196d, 0.5104454862955553d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextWeibull(0.5622601586280797d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.47567352713547d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "e"+ "'", var6.equals("e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.8963235704318167d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 9.611749120163473d);
// 
//   }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.OrderDirection var1 = null;
//     boolean var3 = org.apache.commons.math3.util.MathArrays.isMonotonic(var0, var1, false);
// 
//   }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var20 = var16.getNumericalVariance();
    double var21 = var16.getNumericalMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var23 = var16.inverseCumulativeProbability(58.468608413067535d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    long[][] var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkRectangular(var0);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     double var10 = var0.nextWeibull(97.97864407980379d, 9999.0d);
//     double var12 = var0.nextT(1.7904651608248163d);
//     double var15 = var0.nextCauchy(167.10424588351813d, 51.30880113197997d);
//     var0.reSeedSecure(0L);
//     long var20 = var0.nextSecureLong(10L, 13L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 201.51587726590506d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 9862.916937121827d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.32325280016288294d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 284.941661635924d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 10L);
// 
//   }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     var0.setSeed(6);
//     double var3 = var0.nextDouble();
//     float var4 = var0.nextFloat();
//     double var5 = var0.nextDouble();
//     var0.setSeed(16412887479476156L);
//     java.util.List var8 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var9 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var0, var8);
// 
//   }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     double var13 = var0.nextT(99.2782319289774d);
//     double var15 = var0.nextT(98.47845151091803d);
//     double var17 = var0.nextT(98.47845151091803d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var0.nextUniform(202.22534955410197d, 1.0991832135313893d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 20.356678420280957d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.09576775522739876d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.5444337009011564d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.011142077224959928d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.6780688197808818d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.6807149503702892d);
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.density(1.2316468095843844d);
    double var23 = var16.inverseCumulativeProbability(1.0d);
    double var24 = var16.getSupportLowerBound();
    double[] var26 = var16.sample(2);
    boolean var27 = var16.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)100, (java.lang.Number)0.0f, 0, var3, false);
    boolean var6 = var5.getStrict();
    int var7 = var5.getIndex();
    java.lang.Number var8 = var5.getPrevious();
    int var9 = var5.getIndex();
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    java.lang.Number var13 = null;
    java.lang.Comparable[] var15 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
    boolean var18 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var15, var16, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var19 = new org.apache.commons.math3.exception.NotFiniteNumberException(var13, (java.lang.Object[])var15);
    org.apache.commons.math3.exception.NotFiniteNumberException var20 = new org.apache.commons.math3.exception.NotFiniteNumberException(var11, (java.lang.Number)1010.0d, (java.lang.Object[])var15);
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var10, (java.lang.Object[])var15);
    boolean var22 = var5.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0.0f+ "'", var8.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.density(1.2316468095843844d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var23 = var16.inverseCumulativeProbability(78.57664175278842d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.OrderDirection var1 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var0, var1, true);
// 
//   }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
    long var4 = var3.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    double var8 = var5.nextUniform(0.7090371711746789d, 3887.603878597613d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var5.nextInt(7, 5);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-414028722650554365L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 606.9017688960619d);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)10.0f);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var8 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 100.0d);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.checkOrder(var8, var9, false, false);
    double[] var13 = new double[] { };
    double[] var15 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var15);
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var13, var15);
    double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    double[] var20 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double[] var23 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var23);
    double[] var25 = org.apache.commons.math3.util.MathArrays.ebeDivide(var20, var23);
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distanceInf(var13, var25);
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double[] var32 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var32);
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeDivide(var29, var32);
    double[] var35 = new double[] { };
    double[] var37 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance1(var35, var37);
    org.apache.commons.math3.util.MathArrays.checkPositive(var37);
    double var41 = org.apache.commons.math3.util.MathArrays.safeNorm(var37);
    double[] var42 = org.apache.commons.math3.util.MathArrays.ebeAdd(var29, var37);
    org.apache.commons.math3.util.MathArrays.OrderDirection var43 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var37, var43, true);
    double var46 = org.apache.commons.math3.util.MathArrays.distance1(var13, var37);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var8, var37);
    double[] var48 = new double[] { };
    double[] var50 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var50);
    double var52 = org.apache.commons.math3.util.MathArrays.distance1(var48, var50);
    org.apache.commons.math3.util.MathArrays.checkPositive(var50);
    double var54 = org.apache.commons.math3.util.MathArrays.safeNorm(var50);
    double[] var56 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var56);
    double[] var59 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var59);
    double[] var61 = org.apache.commons.math3.util.MathArrays.ebeDivide(var56, var59);
    double[] var62 = new double[] { };
    double[] var64 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var64);
    double var66 = org.apache.commons.math3.util.MathArrays.distance1(var62, var64);
    org.apache.commons.math3.util.MathArrays.checkPositive(var64);
    double var68 = org.apache.commons.math3.util.MathArrays.safeNorm(var64);
    double[] var69 = org.apache.commons.math3.util.MathArrays.ebeAdd(var56, var64);
    double[] var71 = org.apache.commons.math3.util.MathArrays.normalizeArray(var69, 0.0d);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var50, var69);
    boolean var73 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var50);
    double[] var74 = org.apache.commons.math3.util.MathArrays.copyOf(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var17 = var16.getSupportUpperBound();
    boolean var18 = var16.isSupportLowerBoundInclusive();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = var16.probability(259.73936212062426d, 0.7157990521557022d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);

  }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     double var8 = var1.nextUniform(1.0d, 1.2388070620041405d, false);
//     double var11 = var1.nextCauchy(0.5104454862955553d, 97.97864407980379d);
//     double var14 = var1.nextCauchy(0.23344772945559902d, 0.5790983875421128d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.99528212163484d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.057654215217053d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 349.1228980772152d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-1.5254128255056287d));
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)236.68158202287123d);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSecureAlgorithm("1", "org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)98.6636142140316d, (java.lang.Number)30, true);
    java.lang.Number var4 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 30+ "'", var4.equals(30));

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)98.6636142140316d, (java.lang.Number)30, true);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 98.6636142140316d+ "'", var4.equals(98.6636142140316d));

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 0, 3);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    double[] var0 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var1 = null;
    double[] var3 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var3);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeDivide(var3, var6);
    double[] var9 = new double[] { };
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var9, var11);
    org.apache.commons.math3.util.MathArrays.OrderDirection var14 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var11, var14, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var18 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var8, var11);
    double[][] var19 = new double[][] { var11};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var0, var1, var19);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.0737206121073526d, (java.lang.Number)9.95645506445408d, (java.lang.Number)10L);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)4, true);
    boolean var5 = var4.getBoundIsAllowed();
    java.lang.Number var6 = var4.getMax();
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 4+ "'", var6.equals(4));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.0d, var2, (java.lang.Number)1010.0d);
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { false};
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, var8);
    var4.addSuppressed((java.lang.Throwable)var5);
    org.apache.commons.math3.exception.util.ExceptionContext var11 = var5.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var3 = var0.nextExponential(0.2683148062047325d);
//     double var7 = var0.nextUniform((-37.441946953176824d), 37.394228706165585d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextUniform(0.4282508199819778d, 0.0d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.09734609744301001d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-10.747927034507057d));
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.39583726512027007d, (java.lang.Number)(short)100, true);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    long[] var2 = new long[] { 0L, 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    long[][] var4 = new long[][] { var2};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.819217204815299d, (java.lang.Number)0.5104454862955553d, 3, var3, true);
    boolean var6 = var5.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)98.45317552126936d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     double var8 = var1.nextUniform(1.0d, 1.2388070620041405d, false);
//     double var11 = var1.nextCauchy(0.5104454862955553d, 97.97864407980379d);
//     int var14 = var1.nextZipf(3, 1.0646160893106429d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var1.nextHypergeometric(0, (-63560251), 6);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.877728515657468d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0744451656254688d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 587.0126190047333d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var8 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 0.0d);
    double[] var9 = new double[] { };
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var9, var11);
    double[] var15 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var15);
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var9, var15);
    double var18 = org.apache.commons.math3.util.MathArrays.safeNorm(var15);
    double[] var19 = new double[] { };
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double var23 = org.apache.commons.math3.util.MathArrays.distance1(var19, var21);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var19);
    double[] var25 = new double[] { };
    double[] var27 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var27);
    double var29 = org.apache.commons.math3.util.MathArrays.distance1(var25, var27);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double var33 = org.apache.commons.math3.util.MathArrays.distance1(var25, var31);
    org.apache.commons.math3.util.MathArrays.OrderDirection var34 = null;
    boolean var37 = org.apache.commons.math3.util.MathArrays.checkOrder(var31, var34, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var38 = null;
    boolean var40 = org.apache.commons.math3.util.MathArrays.isMonotonic(var31, var38, false);
    double[] var41 = new double[] { };
    double[] var43 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var43);
    double var45 = org.apache.commons.math3.util.MathArrays.distance1(var41, var43);
    double[] var47 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var47);
    double var49 = org.apache.commons.math3.util.MathArrays.distance1(var41, var47);
    double var50 = org.apache.commons.math3.util.MathArrays.safeNorm(var47);
    double[] var51 = org.apache.commons.math3.util.MathArrays.ebeDivide(var31, var47);
    double var52 = org.apache.commons.math3.util.MathArrays.distance(var24, var51);
    double[] var54 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var54);
    double[] var57 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var57);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeDivide(var54, var57);
    double[] var60 = new double[] { };
    double[] var62 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var62);
    double var64 = org.apache.commons.math3.util.MathArrays.distance1(var60, var62);
    org.apache.commons.math3.util.MathArrays.OrderDirection var65 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var62, var65, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var62);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var69 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var59, var62);
    org.apache.commons.math3.util.MathArrays.OrderDirection var70 = null;
    double[] var71 = new double[] { };
    double[] var73 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var73);
    double var75 = org.apache.commons.math3.util.MathArrays.distance1(var71, var73);
    double[] var77 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var77);
    double var79 = org.apache.commons.math3.util.MathArrays.distance1(var71, var77);
    org.apache.commons.math3.util.MathArrays.OrderDirection var80 = null;
    double[] var82 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var82);
    double[] var85 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var85);
    double[] var87 = org.apache.commons.math3.util.MathArrays.ebeDivide(var82, var85);
    double[][] var88 = new double[][] { var85};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var77, var80, var88);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var59, var70, var88);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var51, var59);
    double[] var92 = org.apache.commons.math3.util.MathArrays.ebeAdd(var15, var51);
    double var93 = org.apache.commons.math3.util.MathArrays.distance(var8, var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 1.0d);

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }
// 
// 
//     double[] var0 = new double[] { };
//     double[] var2 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var2);
//     double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var2);
//     double[][] var6 = null;
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var2, var6);
// 
//   }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)9843.530265446541d, (java.lang.Number)8, true);

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(1.2388070620041405d, 98.45317552126936d, true);
//     double var13 = var1.nextExponential(290.77256675474683d);
//     double var16 = var1.nextF(0.2683148062047325d, 9593.170208585227d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.46754514749942d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 74.45011892776634d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 57.896991195173214d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 24.602566042057642d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.381282650726439d);
// 
//   }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     double var10 = var0.nextWeibull(97.97864407980379d, 9999.0d);
//     double var12 = var0.nextT(1.7904651608248163d);
//     double var15 = var0.nextCauchy(167.10424588351813d, 51.30880113197997d);
//     double var18 = var0.nextCauchy(0.8880966432600474d, 98.47845151091803d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 203.21393087615945d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 10074.793969498272d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.3109472319089666d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 84639.17058374506d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 66.11489902375683d);
// 
//   }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.6353993387561228d, (java.lang.Number)99.56259882352816d, false);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)100, (java.lang.Number)0.0f, 0, var3, false);
    boolean var6 = var5.getStrict();
    int var7 = var5.getIndex();
    java.lang.Number var8 = var5.getPrevious();
    java.lang.Number var9 = var5.getPrevious();
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0.0f+ "'", var8.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 0.0f+ "'", var9.equals(0.0f));

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
    double[] var6 = new double[] { };
    double[] var8 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var8);
    double var10 = org.apache.commons.math3.util.MathArrays.distance1(var6, var8);
    double[] var12 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance1(var6, var12);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    boolean var18 = org.apache.commons.math3.util.MathArrays.checkOrder(var12, var15, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var19 = null;
    boolean var21 = org.apache.commons.math3.util.MathArrays.isMonotonic(var12, var19, false);
    double[] var22 = new double[] { };
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var22, var24);
    double[] var28 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var22, var28);
    double var31 = org.apache.commons.math3.util.MathArrays.safeNorm(var28);
    double[] var32 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var28);
    double var33 = org.apache.commons.math3.util.MathArrays.distance(var5, var32);
    double[] var35 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var35);
    double[] var38 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var38);
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeDivide(var35, var38);
    double[] var41 = new double[] { };
    double[] var43 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var43);
    double var45 = org.apache.commons.math3.util.MathArrays.distance1(var41, var43);
    org.apache.commons.math3.util.MathArrays.OrderDirection var46 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var43, var46, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var43);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var50 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var40, var43);
    org.apache.commons.math3.util.MathArrays.OrderDirection var51 = null;
    double[] var52 = new double[] { };
    double[] var54 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var52, var54);
    double[] var58 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var58);
    double var60 = org.apache.commons.math3.util.MathArrays.distance1(var52, var58);
    org.apache.commons.math3.util.MathArrays.OrderDirection var61 = null;
    double[] var63 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var63);
    double[] var66 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var66);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var63, var66);
    double[][] var69 = new double[][] { var66};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var58, var61, var69);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var40, var51, var69);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var72 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var32, var40);
    double[] var74 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var74);
    double[] var77 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var77);
    double[] var79 = org.apache.commons.math3.util.MathArrays.ebeDivide(var74, var77);
    double[] var80 = new double[] { };
    double[] var82 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var82);
    double var84 = org.apache.commons.math3.util.MathArrays.distance1(var80, var82);
    org.apache.commons.math3.util.MathArrays.checkPositive(var82);
    double var86 = org.apache.commons.math3.util.MathArrays.safeNorm(var82);
    double[] var87 = org.apache.commons.math3.util.MathArrays.ebeAdd(var74, var82);
    double var88 = org.apache.commons.math3.util.MathArrays.distance1(var32, var82);
    org.apache.commons.math3.util.MathArrays.OrderDirection var89 = null;
    boolean var91 = org.apache.commons.math3.util.MathArrays.isMonotonic(var32, var89, false);
    double var92 = org.apache.commons.math3.util.MathArrays.safeNorm(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 99.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 1.0d);

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextInt((-1), 8);
//     double var11 = var0.nextUniform(0.9775887691884613d, 98.42176142483318d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("org.apache.commons.math3.exception.NotPositiveException: 100 is smaller than the minimum (0)", "5");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 210.3943435656489d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 95.2850577547997d);
// 
//   }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.nextWeibull(0.09013471933871053d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(99.56259882352816d, 22.99329045273265d, 0.3343518200089379d, 0.0d, 211.11038733317636d, 0.7644474751903642d, 2.056788858578444d, 0.6709920656782435d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2452.034644566469d);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, (-1), 0);
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     java.lang.Comparable[] var7 = new java.lang.Comparable[] { 10};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
//     boolean var10 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var7, var8, true);
//     org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(byte)100, (java.lang.Object[])var7);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
//     boolean var14 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var7, var12, true);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
//     boolean var17 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var7, var15, true);
//     org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var7);
// 
//   }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var3 = var2.getValue();
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c();
    var5.setSeed(6);
    int[] var9 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var9);
    int var11 = var10.nextInt();
    long var12 = var10.nextLong();
    byte[] var13 = new byte[] { };
    var10.nextBytes(var13);
    var5.nextBytes(var13);
    int var16 = var5.nextInt();
    boolean var17 = var2.equals((java.lang.Object)var16);
    boolean var19 = var2.equals((java.lang.Object)9.927198205545196d);
    java.lang.Object var20 = var2.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1L+ "'", var3.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1205512795);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + (-1L)+ "'", var20.equals((-1L)));

  }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     long var7 = var1.nextSecureLong((-1L), 152600911433040288L);
//     int var10 = var1.nextInt(0, 2074243331);
//     long var13 = var1.nextLong(1L, 5220799318019361146L);
//     java.util.Collection var14 = null;
//     java.lang.Object[] var16 = var1.nextSample(var14, 0);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.3220963206821523d, (java.lang.Number)299.89733044110505d, 8);
    boolean var4 = var3.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    java.lang.Number var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, var1, (-96398574), var3, true);

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var2);
//     double[] var5 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var5);
//     double[] var7 = org.apache.commons.math3.util.MathArrays.ebeDivide(var2, var5);
//     double[] var8 = new double[] { };
//     double[] var10 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var10);
//     double var12 = org.apache.commons.math3.util.MathArrays.distance1(var8, var10);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var10, var13, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var10);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var17 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var7, var10);
//     double[] var19 = var17.sample(9);
//     double[] var21 = org.apache.commons.math3.util.MathArrays.normalizeArray(var19, 6.05792045843231d);
//     double[] var22 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var0, var21);
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(byte)1, var1, (java.lang.Number)(short)0);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getHi();
    java.lang.Number var6 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)0+ "'", var5.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)0+ "'", var6.equals((short)0));

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 30, 1);
    int var4 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(7);

  }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextWeibull(1.6486550157904805d, 100.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var0.nextBinomial(3, 253.07859717090338d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 183.93373753314123d);
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)9.967053788588151d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    int[] var1 = new int[] { 100};
    int[] var3 = new int[] { 100};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
    int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var3);
    int[] var9 = new int[] { 100};
    int[] var11 = new int[] { 100};
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    int var13 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var11);
    int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var11);
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    int var18 = org.apache.commons.math3.util.MathArrays.distance1(var3, var11);
    double[] var19 = new double[] { };
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double var23 = org.apache.commons.math3.util.MathArrays.distance1(var19, var21);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var19);
    double[] var26 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double[] var31 = org.apache.commons.math3.util.MathArrays.ebeDivide(var26, var29);
    org.apache.commons.math3.util.MathArrays.checkOrder(var31);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var19, var31);
    org.apache.commons.math3.util.Pair var34 = new org.apache.commons.math3.util.Pair((java.lang.Object)var18, (java.lang.Object)var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var1.nextT(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     double[] var1 = new double[] { };
//     double[] var3 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var3);
//     double var5 = org.apache.commons.math3.util.MathArrays.distance1(var1, var3);
//     double[] var7 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var7);
//     double var9 = org.apache.commons.math3.util.MathArrays.distance1(var1, var7);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
//     boolean var13 = org.apache.commons.math3.util.MathArrays.checkOrder(var7, var10, false, true);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var14 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var7, var14, false);
//     double[] var17 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var18 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var7, var17);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var2, var5, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var2);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    double[] var11 = new double[] { };
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var11, var13);
    double[] var17 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var17);
    double var19 = org.apache.commons.math3.util.MathArrays.distance1(var11, var17);
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
    double[] var22 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var22);
    double[] var25 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var25);
    double[] var27 = org.apache.commons.math3.util.MathArrays.ebeDivide(var22, var25);
    double[][] var28 = new double[][] { var25};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var17, var20, var28);
    org.apache.commons.math3.exception.MathIllegalStateException var30 = new org.apache.commons.math3.exception.MathIllegalStateException(var10, (java.lang.Object[])var28);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var2, var9, var28);
    double[] var32 = new double[] { };
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var32, var34);
    double[] var37 = org.apache.commons.math3.util.MathArrays.copyOf(var32);
    double[] var39 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var39);
    double[] var42 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeDivide(var39, var42);
    org.apache.commons.math3.util.MathArrays.checkOrder(var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distanceInf(var32, var44);
    double[] var48 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var48);
    double[] var51 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var51);
    double[] var53 = org.apache.commons.math3.util.MathArrays.ebeDivide(var48, var51);
    double[] var54 = new double[] { };
    double[] var56 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance1(var54, var56);
    org.apache.commons.math3.util.MathArrays.checkPositive(var56);
    double var60 = org.apache.commons.math3.util.MathArrays.safeNorm(var56);
    double[] var61 = org.apache.commons.math3.util.MathArrays.ebeAdd(var48, var56);
    org.apache.commons.math3.util.MathArrays.OrderDirection var62 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var56, var62, true);
    double var65 = org.apache.commons.math3.util.MathArrays.distance1(var32, var56);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var66 = org.apache.commons.math3.util.MathArrays.linearCombination(var2, var56);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.39583726512027007d, 1.3220963206821523d, 33636.46593996366d, (-1.5254128255056287d), 77.74838373665371d, 91.3629924210577d, 0.0469031636391882d, 10.049872943398238d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-44205.17684959541d));

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var3 = var0.nextExponential(0.2683148062047325d);
//     double var7 = var0.nextUniform((-37.441946953176824d), 37.394228706165585d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextPascal(6, 98.39789067617866d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.12281172730736166d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 33.57747966029853d);
// 
//   }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     double var6 = var1.nextChiSquare(9999.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var1.nextBinomial((-1128991284), 59.46089528265286d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10039.1936205993d);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var3 = var2.getValue();
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl();
    var5.reSeed();
    boolean var7 = var2.equals((java.lang.Object)var5);
    java.lang.Object var8 = var2.getSecond();
    java.lang.Object var9 = var2.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1L+ "'", var3.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 1L+ "'", var8.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 1L+ "'", var9.equals(1L));

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.0d);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(809123836);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var3 = var2.getValue();
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl();
    var5.reSeed();
    boolean var7 = var2.equals((java.lang.Object)var5);
    org.apache.commons.math3.util.Pair var8 = new org.apache.commons.math3.util.Pair(var2);
    java.lang.Object var9 = var2.getFirst();
    java.lang.Object var10 = var2.getValue();
    org.apache.commons.math3.util.Pair var11 = new org.apache.commons.math3.util.Pair(var2);
    java.lang.Object var12 = var11.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1L+ "'", var3.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (-1L)+ "'", var9.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 1L+ "'", var10.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (-1L)+ "'", var12.equals((-1L)));

  }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(9);
//     var0.reSeedSecure();
//     java.lang.String var5 = var0.nextSecureHexString(30);
//     var0.reSeedSecure(259766232686583471L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "3f332bd63"+ "'", var2.equals("3f332bd63"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "34f4a8a232072f569851e7e4c75425"+ "'", var5.equals("34f4a8a232072f569851e7e4c75425"));
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)100.0d);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    boolean var3 = var1.getBoundIsAllowed();
    boolean var4 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var2 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)38.60348596763803d, var1);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     int var9 = var1.nextZipf(10, 13.521216539811984d);
//     double var11 = var1.nextChiSquare(1.2388070620041405d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextInt((-1), (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.7314998901976d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "a"+ "'", var6.equals("a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.8848989712010062d);
// 
//   }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     var0.reSeedSecure((-1L));
//     var0.reSeed(2L);
//     double var16 = var0.nextWeibull(98.46619727159656d, 1.819217204815299d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var0.nextUniform(59.5604882521082d, (-3.560282083317369d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 220.0238081958194d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "1576fc76d0"+ "'", var9.equals("1576fc76d0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.8361073492936983d);
// 
//   }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.002349480672631077d, 175.02930993084695d, 2452.034644566469d, 208.18143482883644d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 510468.5017838443d);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(byte)1, var1, (java.lang.Number)(short)0);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getHi();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Number var8 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var6, (java.lang.Number)100.26932579100311d, var8, false);
    var3.addSuppressed((java.lang.Throwable)var10);
    java.lang.Number var12 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)0+ "'", var5.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (short)0+ "'", var12.equals((short)0));

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.3941648194355074d), 1.2316468095843844d, 161.97960724242043d, 146.69811030176578d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 23761.61681804298d);

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     long var7 = var1.nextSecureLong((-1L), 152600911433040288L);
//     int var10 = var1.nextInt(0, 2074243331);
//     double var13 = var1.nextGamma(197.31657362797657d, 0.23344772945559902d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 24293682399481844L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1543116286);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 45.06487043076392d);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 30, 2147483647);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    long[] var0 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     double var8 = var1.nextUniform(1.0d, 1.2388070620041405d, false);
//     double var11 = var1.nextCauchy(0.5104454862955553d, 97.97864407980379d);
//     int var14 = var1.nextZipf(3, 1.0646160893106429d);
//     double var16 = var1.nextT(0.03359081770746613d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10.105148859000192d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0410251609935102d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 96.27325682449595d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-0.11765698642290988d));
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.density(1.2316468095843844d);
    boolean var22 = var16.isSupportLowerBoundInclusive();
    double var24 = var16.cumulativeProbability(100.26932579100311d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var27 = var16.probability(18679.615042775484d, 1.0524812686407703d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0d);

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     double var4 = var2.nextDouble();
//     var2.setSeed((-1));
//     var2.setSeed(0L);
//     long var9 = var2.nextLong();
//     var2.setSeed(10);
//     double var12 = var2.nextDouble();
//     int var14 = var2.nextInt(6);
//     int[] var16 = new int[] { 100};
//     int[] var18 = new int[] { 100};
//     int[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var18);
//     int var20 = org.apache.commons.math3.util.MathArrays.distanceInf(var16, var18);
//     int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var18);
//     int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var18);
//     var2.setSeed(var18);
//     int[] var24 = null;
//     int var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var24);
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0, var1, true);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var5 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, var5);
    var3.addSuppressed((java.lang.Throwable)var6);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     double[] var1 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var1);
//     double[] var4 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var4);
//     double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
//     double[] var7 = new double[] { };
//     double[] var9 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var9);
//     double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var9);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var17 = null;
//     double[][] var18 = null;
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var9, var17, var18);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    long var4 = var2.nextLong();
    double var5 = var2.nextGaussian();
    double var6 = var2.nextGaussian();
    var2.setSeed(43059505226525080L);
    int var9 = var2.nextInt();
    var2.setSeed(7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.7157990521557022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-0.6984489763881883d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1128991284));

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    double[] var8 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var8);
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.ebeDivide(var8, var11);
    double[] var14 = new double[] { };
    double[] var16 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var14, var16);
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double var20 = org.apache.commons.math3.util.MathArrays.safeNorm(var16);
    double[] var21 = org.apache.commons.math3.util.MathArrays.ebeAdd(var8, var16);
    double[] var23 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.0d);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var2, var21);
    double var25 = org.apache.commons.math3.util.MathArrays.safeNorm(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 200.0d);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(3);

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     long var12 = var0.nextLong((-414028722650554365L), 100L);
//     double var14 = var0.nextT(98.42599099481274d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var16 = var0.nextHexString((-1128991284));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-232.19615517589148d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.5661342118852846d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-39396988516528032L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.2852015991809056d);
// 
//   }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 0.02678742855378105d, 98.42176142483318d, 0.3441412950324493d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 33.87099243611685d);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var8 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 100.0d);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var11 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var9, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var12, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    double var4 = var2.nextDouble();
    var2.setSeed((-1));
    var2.setSeed(0L);
    long var9 = var2.nextLong();
    var2.setSeed(10);
    var2.clear();
    org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var13.nextF(98.42599099481274d, (-0.6104374544647166d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.01408195728001127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-4736355256857903122L));

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     double var8 = var1.nextUniform(1.0d, 1.2388070620041405d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var1.nextSecureLong(92205394674091664L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10.11009297239908d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0201126541459997d);
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    int[] var1 = new int[] { 100};
    int[] var3 = new int[] { 100};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(var3);
    float var7 = var6.nextFloat();
    var6.setSeed((-96398574));
    float var10 = var6.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.6862626f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.7870785f);

  }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 5, 1);
// 
//   }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     org.apache.commons.math3.distribution.IntegerDistribution var8 = null;
//     int var9 = var0.nextInversionDeviate(var8);
// 
//   }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     long var12 = var0.nextLong((-414028722650554365L), 100L);
//     double var14 = var0.nextT(98.42599099481274d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("3c474fdeb4", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 169.21147778060947d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.6310139184685102d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-76198438767644064L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-0.15666713031728133d));
// 
//   }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    double var4 = var2.nextDouble();
    var2.setSeed((-1));
    var2.setSeed(0L);
    long var9 = var2.nextLong();
    var2.setSeed(10);
    var2.clear();
    org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var13.nextUniform(98.43713016096305d, (-0.8305377380798146d), true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.01408195728001127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-4736355256857903122L));

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    double var4 = var2.nextDouble();
    var2.setSeed((-1));
    var2.setSeed(0L);
    long var9 = var2.nextLong();
    var2.setSeed(10);
    double var12 = var2.nextDouble();
    boolean var13 = var2.nextBoolean();
    boolean var14 = var2.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.01408195728001127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-4736355256857903122L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.761957659063951d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)253.07859717090338d, (java.lang.Number)(byte)(-1), false);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var9);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var1, var9);
    double[] var16 = org.apache.commons.math3.util.MathArrays.normalizeArray(var14, 0.0d);
    double[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var17);
    double[] var20 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double[] var23 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var23);
    double[] var25 = org.apache.commons.math3.util.MathArrays.ebeDivide(var20, var23);
    double[] var26 = new double[] { };
    double[] var28 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var26, var28);
    org.apache.commons.math3.util.MathArrays.OrderDirection var31 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var28, var31, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var28);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var35 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var25, var28);
    org.apache.commons.math3.util.MathArrays.OrderDirection var36 = null;
    double[] var37 = new double[] { };
    double[] var39 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var39);
    double var41 = org.apache.commons.math3.util.MathArrays.distance1(var37, var39);
    double[] var43 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var43);
    double var45 = org.apache.commons.math3.util.MathArrays.distance1(var37, var43);
    org.apache.commons.math3.util.MathArrays.OrderDirection var46 = null;
    double[] var48 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var48);
    double[] var51 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var51);
    double[] var53 = org.apache.commons.math3.util.MathArrays.ebeDivide(var48, var51);
    double[][] var54 = new double[][] { var51};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var43, var46, var54);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var25, var36, var54);
    double[] var58 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var58);
    double[] var61 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var61);
    double[] var63 = org.apache.commons.math3.util.MathArrays.ebeDivide(var58, var61);
    double[] var64 = new double[] { };
    double[] var66 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var66);
    double var68 = org.apache.commons.math3.util.MathArrays.distance1(var64, var66);
    org.apache.commons.math3.util.MathArrays.checkPositive(var66);
    double var70 = org.apache.commons.math3.util.MathArrays.safeNorm(var66);
    double[] var71 = org.apache.commons.math3.util.MathArrays.ebeAdd(var58, var66);
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var25, var71);
    double[] var73 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var17, var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    double var4 = var2.nextDouble();
    var2.setSeed((-1));
    var2.setSeed(0L);
    long var9 = var2.nextLong();
    var2.setSeed(10);
    var2.clear();
    org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    var13.reSeed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.01408195728001127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-4736355256857903122L));

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var7 = org.apache.commons.math3.util.MathArrays.isMonotonic(var0, var5, false);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)152600911433040288L, (java.lang.Number)91.3629924210577d, true);

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(98.45317552126936d);
//     double var4 = var0.nextT(742.6248114744293d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var0.nextBinomial((-1), 200.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.18547484835002262d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.6001683708255067d);
// 
//   }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var3 = var2.getValue();
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c();
    var5.setSeed(6);
    int[] var9 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var9);
    int var11 = var10.nextInt();
    long var12 = var10.nextLong();
    byte[] var13 = new byte[] { };
    var10.nextBytes(var13);
    var5.nextBytes(var13);
    int var16 = var5.nextInt();
    boolean var17 = var2.equals((java.lang.Object)var16);
    java.lang.Object var18 = var2.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1L+ "'", var3.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1205512795);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + (-1L)+ "'", var18.equals((-1L)));

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextWeibull(1.6486550157904805d, 100.0d);
//     int var7 = var0.nextZipf(6, 0.2802818762189058d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextBinomial(3, 1.0847091605564438d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 72.60569359006797d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3);
// 
//   }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     int var6 = var0.nextPascal(1, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextCauchy(98.44078667812042d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2147483647);
// 
//   }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)100, (java.lang.Number)0.0f, 0, var3, false);
    boolean var6 = var5.getStrict();
    int var7 = var5.getIndex();
    java.lang.Number var8 = var5.getPrevious();
    int var9 = var5.getIndex();
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    java.lang.Number var13 = null;
    java.lang.Comparable[] var15 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
    boolean var18 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var15, var16, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var19 = new org.apache.commons.math3.exception.NotFiniteNumberException(var13, (java.lang.Object[])var15);
    org.apache.commons.math3.exception.NotFiniteNumberException var20 = new org.apache.commons.math3.exception.NotFiniteNumberException(var11, (java.lang.Number)1010.0d, (java.lang.Object[])var15);
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var10, (java.lang.Object[])var15);
    org.apache.commons.math3.exception.util.ExceptionContext var22 = var21.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0.0f+ "'", var8.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var17 = null;
    double[] var18 = new double[] { };
    double[] var20 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double var22 = org.apache.commons.math3.util.MathArrays.distance1(var18, var20);
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var18, var24);
    org.apache.commons.math3.util.MathArrays.OrderDirection var27 = null;
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double[] var32 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var32);
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeDivide(var29, var32);
    double[][] var35 = new double[][] { var32};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var24, var27, var35);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var6, var17, var35);
    double[] var39 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var39);
    double[] var42 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeDivide(var39, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var39, 100.0d);
    org.apache.commons.math3.util.MathArrays.OrderDirection var47 = null;
    boolean var50 = org.apache.commons.math3.util.MathArrays.checkOrder(var46, var47, false, false);
    double[] var51 = new double[] { };
    double[] var53 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var53);
    double var55 = org.apache.commons.math3.util.MathArrays.distance1(var51, var53);
    double[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var51);
    double[] var58 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var58);
    double[] var61 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var61);
    double[] var63 = org.apache.commons.math3.util.MathArrays.ebeDivide(var58, var61);
    org.apache.commons.math3.util.MathArrays.checkOrder(var63);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var51, var63);
    double[] var67 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var67);
    double[] var70 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var70);
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeDivide(var67, var70);
    double[] var73 = new double[] { };
    double[] var75 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var75);
    double var77 = org.apache.commons.math3.util.MathArrays.distance1(var73, var75);
    org.apache.commons.math3.util.MathArrays.checkPositive(var75);
    double var79 = org.apache.commons.math3.util.MathArrays.safeNorm(var75);
    double[] var80 = org.apache.commons.math3.util.MathArrays.ebeAdd(var67, var75);
    org.apache.commons.math3.util.MathArrays.OrderDirection var81 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var75, var81, true);
    double var84 = org.apache.commons.math3.util.MathArrays.distance1(var51, var75);
    boolean var85 = org.apache.commons.math3.util.MathArrays.equals(var46, var75);
    boolean var86 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var6, var75);
    double[] var87 = null;
    boolean var88 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var75, var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(1.7074069363865898d, 195.7110153997647d, 100.26932579100311d, 1.8229678545960526d, 2.0511996659363665d, 0.5622601586280797d, 3.0896657965554652d, 189.69032873251956d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1104.179131411614d);

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     org.apache.commons.math3.distribution.IntegerDistribution var2 = null;
//     int var3 = var0.nextInversionDeviate(var2);
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var3 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var3);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeDivide(var3, var6);
    double[] var9 = new double[] { };
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var9, var11);
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var11);
    double[] var17 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var17);
    double[] var20 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double[] var22 = org.apache.commons.math3.util.MathArrays.ebeDivide(var17, var20);
    double[] var23 = new double[] { };
    double[] var25 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var23, var25);
    org.apache.commons.math3.util.MathArrays.checkPositive(var25);
    double var29 = org.apache.commons.math3.util.MathArrays.safeNorm(var25);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeAdd(var17, var25);
    double[] var32 = org.apache.commons.math3.util.MathArrays.normalizeArray(var30, 0.0d);
    double var33 = org.apache.commons.math3.util.MathArrays.distance1(var11, var30);
    double[] var35 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var35);
    double[] var38 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var38);
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeDivide(var35, var38);
    double[] var41 = new double[] { };
    double[] var43 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var43);
    double var45 = org.apache.commons.math3.util.MathArrays.distance1(var41, var43);
    org.apache.commons.math3.util.MathArrays.checkPositive(var43);
    double var47 = org.apache.commons.math3.util.MathArrays.safeNorm(var43);
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeAdd(var35, var43);
    org.apache.commons.math3.util.MathArrays.OrderDirection var49 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var43, var49, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var52 = null;
    boolean var55 = org.apache.commons.math3.util.MathArrays.checkOrder(var43, var52, true, false);
    double[] var56 = org.apache.commons.math3.util.MathArrays.ebeDivide(var30, var43);
    double[] var58 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var58);
    double[] var61 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var61);
    double[] var63 = org.apache.commons.math3.util.MathArrays.ebeDivide(var58, var61);
    double[] var64 = new double[] { };
    double[] var66 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var66);
    double var68 = org.apache.commons.math3.util.MathArrays.distance1(var64, var66);
    org.apache.commons.math3.util.MathArrays.OrderDirection var69 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var66, var69, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var66);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var73 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var63, var66);
    org.apache.commons.math3.util.MathArrays.OrderDirection var74 = null;
    double[] var75 = new double[] { };
    double[] var77 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var77);
    double var79 = org.apache.commons.math3.util.MathArrays.distance1(var75, var77);
    double[] var81 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var81);
    double var83 = org.apache.commons.math3.util.MathArrays.distance1(var75, var81);
    org.apache.commons.math3.util.MathArrays.OrderDirection var84 = null;
    double[] var86 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var86);
    double[] var89 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var89);
    double[] var91 = org.apache.commons.math3.util.MathArrays.ebeDivide(var86, var89);
    double[][] var92 = new double[][] { var89};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var81, var84, var92);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var63, var74, var92);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var43, var92);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var8, var92);
    org.apache.commons.math3.exception.NotFiniteNumberException var97 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)98.90354239278018d, (java.lang.Object[])var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    boolean var17 = var16.isSupportLowerBoundInclusive();
    double var19 = var16.cumulativeProbability(98.57943496629362d);
    var16.reseedRandomGenerator(101L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var24 = var16.cumulativeProbability(9862.916937121827d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);

  }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextPascal(2147483647, 174.7686993064312d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 245.0084898233073d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "01759ecdd4"+ "'", var9.equals("01759ecdd4"));
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    double[] var3 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var3);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeDivide(var3, var6);
    double[] var9 = new double[] { };
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var9, var11);
    org.apache.commons.math3.util.MathArrays.OrderDirection var14 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var11, var14, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var18 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var8, var11);
    org.apache.commons.math3.util.MathArrays.OrderDirection var19 = null;
    double[] var20 = new double[] { };
    double[] var22 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var20, var22);
    double[] var26 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var20, var26);
    org.apache.commons.math3.util.MathArrays.OrderDirection var29 = null;
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeDivide(var31, var34);
    double[][] var37 = new double[][] { var34};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var26, var29, var37);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var8, var19, var37);
    org.apache.commons.math3.exception.MathIllegalStateException var40 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, (java.lang.Object[])var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    boolean var5 = var2.nextBoolean();
    boolean var6 = var2.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-1));
// 
//   }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }
// 
// 
//     double[] var0 = new double[] { };
//     double[] var2 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var2);
//     double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
//     double[] var6 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var6);
//     double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
//     boolean var12 = org.apache.commons.math3.util.MathArrays.checkOrder(var6, var9, false, true);
//     double[] var13 = new double[] { };
//     double[] var15 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var15);
//     double var17 = org.apache.commons.math3.util.MathArrays.distance1(var13, var15);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
//     double[] var19 = new double[] { };
//     double[] var21 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var21);
//     double var23 = org.apache.commons.math3.util.MathArrays.distance1(var19, var21);
//     double[] var25 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var25);
//     double var27 = org.apache.commons.math3.util.MathArrays.distance1(var19, var25);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var28 = null;
//     boolean var31 = org.apache.commons.math3.util.MathArrays.checkOrder(var25, var28, false, true);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var32 = null;
//     boolean var34 = org.apache.commons.math3.util.MathArrays.isMonotonic(var25, var32, false);
//     double[] var35 = new double[] { };
//     double[] var37 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var37);
//     double var39 = org.apache.commons.math3.util.MathArrays.distance1(var35, var37);
//     double[] var41 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var41);
//     double var43 = org.apache.commons.math3.util.MathArrays.distance1(var35, var41);
//     double var44 = org.apache.commons.math3.util.MathArrays.safeNorm(var41);
//     double[] var45 = org.apache.commons.math3.util.MathArrays.ebeDivide(var25, var41);
//     double var46 = org.apache.commons.math3.util.MathArrays.distance(var18, var45);
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var6, var45);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var48 = null;
//     double[][] var49 = null;
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var6, var48, var49);
// 
//   }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { false};
    org.apache.commons.math3.exception.MathIllegalStateException var4 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var0, var1, var3);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var11 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.819217204815299d, (java.lang.Number)0.5104454862955553d, 3, var9, true);
    int var12 = var11.getIndex();
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    long[] var18 = new long[] { 0L, 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var18);
    long[][] var20 = new long[][] { var18};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var20);
    org.apache.commons.math3.exception.NotFiniteNumberException var22 = new org.apache.commons.math3.exception.NotFiniteNumberException(var14, (java.lang.Number)98.42888798257793d, (java.lang.Object[])var20);
    org.apache.commons.math3.exception.MathIllegalStateException var23 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var11, var13, (java.lang.Object[])var20);
    var4.addSuppressed((java.lang.Throwable)var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    double[] var0 = null;
    double[] var1 = new double[] { };
    double[] var3 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var3);
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var1, var3);
    org.apache.commons.math3.util.MathArrays.checkPositive(var3);
    double var7 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var8 = new double[] { };
    double[] var10 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var10);
    double var12 = org.apache.commons.math3.util.MathArrays.distance1(var8, var10);
    double[] var14 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var14);
    double var16 = org.apache.commons.math3.util.MathArrays.distance1(var8, var14);
    double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    double[] var18 = new double[] { };
    double[] var20 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double var22 = org.apache.commons.math3.util.MathArrays.distance1(var18, var20);
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double var24 = org.apache.commons.math3.util.MathArrays.safeNorm(var20);
    double[] var25 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var14, var20);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var20);
    double[] var28 = org.apache.commons.math3.util.MathArrays.normalizeArray(var20, 0.2802818762189058d);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 2074243331);
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.078838815458333d, (java.lang.Number)9593.170208585227d, (java.lang.Number)149.46919877865736d);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    float[] var0 = null;
    float[] var1 = new float[] { };
    boolean var2 = org.apache.commons.math3.util.MathArrays.equals(var0, var1);
    float[] var3 = new float[] { };
    boolean var4 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var3);
    float[] var5 = null;
    float[] var6 = new float[] { };
    boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var5, var6);
    float[] var10 = new float[] { 0.0f, (-1.0f)};
    float[] var11 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var5, var10);
    float[] var14 = null;
    float[] var15 = new float[] { };
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var14, var15);
    boolean var17 = org.apache.commons.math3.util.MathArrays.equals(var10, var15);
    float[] var18 = null;
    float[] var19 = new float[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var18, var19);
    float[] var23 = new float[] { 0.0f, (-1.0f)};
    float[] var24 = null;
    boolean var25 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var23, var24);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var18, var23);
    float[] var27 = null;
    float[] var28 = new float[] { };
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var27, var28);
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var23, var28);
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var10, var23);
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var0, var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)100, (java.lang.Number)0.0f, 0, var3, false);
    int var6 = var5.getIndex();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var5.getDirection();
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = var5.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double[] var14 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var11, var14);
    double[] var17 = new double[] { };
    double[] var19 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance1(var17, var19);
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeAdd(var11, var19);
    double[] var26 = org.apache.commons.math3.util.MathArrays.normalizeArray(var24, 0.0d);
    double[] var27 = new double[] { };
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var27, var29);
    double[] var33 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var33);
    double var35 = org.apache.commons.math3.util.MathArrays.distance1(var27, var33);
    org.apache.commons.math3.util.MathArrays.OrderDirection var36 = null;
    double[] var38 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var38);
    double[] var41 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var41);
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeDivide(var38, var41);
    double[][] var44 = new double[][] { var41};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var33, var36, var44);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var24, var44);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var0, var9, var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var3 = var0.nextExponential(0.2683148062047325d);
//     double var7 = var0.nextUniform((-37.441946953176824d), 37.394228706165585d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextSecureInt(0, (-63560251));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.1592376294103447d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-6.284126970148778d));
// 
//   }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.0d, var2, (java.lang.Number)1010.0d);
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { false};
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, var8);
    var4.addSuppressed((java.lang.Throwable)var5);
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    java.lang.Number var13 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var15 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var11, (java.lang.Number)(-1.0f), var13, true);
    java.lang.Number var16 = var15.getMin();
    var5.addSuppressed((java.lang.Throwable)var15);
    boolean var18 = var15.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(0.0d, 984.6226564837881d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextGamma(98.47845151091803d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.49400998681224d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 101.41724050669195d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 65.52144518349857d);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)100, (java.lang.Number)0.0f, 0, var3, false);
    boolean var6 = var5.getStrict();
    int var7 = var5.getIndex();
    java.lang.Number var8 = var5.getPrevious();
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0.0f+ "'", var8.equals(0.0f));

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)187.83486994090094d);

  }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 827167750, 0);
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    double[] var0 = null;
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double[] var5 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var5);
    double[] var7 = org.apache.commons.math3.util.MathArrays.ebeDivide(var2, var5);
    org.apache.commons.math3.util.MathArrays.checkOrder(var7);
    org.apache.commons.math3.util.MathArrays.checkOrder(var7);
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var11);
    org.apache.commons.math3.util.MathArrays.OrderDirection var14 = null;
    boolean var16 = org.apache.commons.math3.util.MathArrays.isMonotonic(var11, var14, true);
    boolean var17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)113.4876159302585d);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportUpperBound();
    double var22 = var16.cumulativeProbability(0.02678742855378105d, 8871.347843840067d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var25 = var16.probability(3887.603878597613d, 1.4815958130930773d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)2.4464769860739253d, (java.lang.Number)113.4876159302585d, 827167750, var3, false);
    int var6 = var5.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 827167750);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var17 = var16.getSupportUpperBound();
    boolean var18 = var16.isSupportLowerBoundInclusive();
    double var20 = var16.cumulativeProbability(1.0646160893106429d);
    boolean var21 = var16.isSupportLowerBoundInclusive();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var24 = var16.probability(146.69811030176578d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);

  }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = new double[] { };
//     double[] var3 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var3);
//     double var5 = org.apache.commons.math3.util.MathArrays.distance1(var1, var3);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var3);
//     double var7 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
//     double[] var9 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var9);
//     double[] var12 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var12);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.ebeDivide(var9, var12);
//     double[] var15 = new double[] { };
//     double[] var17 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var17);
//     double var19 = org.apache.commons.math3.util.MathArrays.distance1(var15, var17);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var17);
//     double var21 = org.apache.commons.math3.util.MathArrays.safeNorm(var17);
//     double[] var22 = org.apache.commons.math3.util.MathArrays.ebeAdd(var9, var17);
//     double[] var24 = org.apache.commons.math3.util.MathArrays.normalizeArray(var22, 0.0d);
//     double var25 = org.apache.commons.math3.util.MathArrays.distance1(var3, var22);
//     double[] var27 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var27);
//     double[] var30 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var30);
//     double[] var32 = org.apache.commons.math3.util.MathArrays.ebeDivide(var27, var30);
//     double[] var33 = new double[] { };
//     double[] var35 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var35);
//     double var37 = org.apache.commons.math3.util.MathArrays.distance1(var33, var35);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var35);
//     double var39 = org.apache.commons.math3.util.MathArrays.safeNorm(var35);
//     double[] var40 = org.apache.commons.math3.util.MathArrays.ebeAdd(var27, var35);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var41 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var35, var41, true);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var44 = null;
//     boolean var47 = org.apache.commons.math3.util.MathArrays.checkOrder(var35, var44, true, false);
//     double[] var48 = org.apache.commons.math3.util.MathArrays.ebeDivide(var22, var35);
//     double[] var50 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var50);
//     double[] var53 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var53);
//     double[] var55 = org.apache.commons.math3.util.MathArrays.ebeDivide(var50, var53);
//     double[] var56 = new double[] { };
//     double[] var58 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var58);
//     double var60 = org.apache.commons.math3.util.MathArrays.distance1(var56, var58);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var61 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var58, var61, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var58);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var65 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var55, var58);
//     double[] var67 = var65.sample(9);
//     boolean var68 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var35, var67);
//     double[] var70 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var70);
//     double[] var73 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var73);
//     double[] var75 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var73);
//     double[] var76 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var35, var73);
//     double[] var78 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var78);
//     double[] var81 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var81);
//     double[] var83 = org.apache.commons.math3.util.MathArrays.ebeDivide(var78, var81);
//     double[] var84 = new double[] { };
//     double[] var86 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var86);
//     double var88 = org.apache.commons.math3.util.MathArrays.distance1(var84, var86);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var86);
//     double var90 = org.apache.commons.math3.util.MathArrays.safeNorm(var86);
//     double[] var91 = org.apache.commons.math3.util.MathArrays.ebeAdd(var78, var86);
//     double[] var93 = org.apache.commons.math3.util.MathArrays.normalizeArray(var91, 0.0d);
//     double[] var94 = org.apache.commons.math3.util.MathArrays.copyOf(var93);
//     double var95 = org.apache.commons.math3.util.MathArrays.distanceInf(var76, var94);
//     double var96 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var76);
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    double[] var9 = new double[] { };
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var9, var11);
    double[] var15 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var15);
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var9, var15);
    org.apache.commons.math3.util.MathArrays.OrderDirection var18 = null;
    boolean var21 = org.apache.commons.math3.util.MathArrays.checkOrder(var15, var18, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
    boolean var24 = org.apache.commons.math3.util.MathArrays.isMonotonic(var15, var22, false);
    double[] var25 = new double[] { };
    double[] var27 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var27);
    double var29 = org.apache.commons.math3.util.MathArrays.distance1(var25, var27);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double var33 = org.apache.commons.math3.util.MathArrays.distance1(var25, var31);
    double var34 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    double[] var35 = org.apache.commons.math3.util.MathArrays.ebeDivide(var15, var31);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var6, var15);
    double[] var37 = new double[] { };
    double[] var39 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var39);
    double var41 = org.apache.commons.math3.util.MathArrays.distance1(var37, var39);
    double[] var43 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var43);
    double var45 = org.apache.commons.math3.util.MathArrays.distance1(var37, var43);
    org.apache.commons.math3.util.MathArrays.OrderDirection var46 = null;
    boolean var49 = org.apache.commons.math3.util.MathArrays.checkOrder(var43, var46, false, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var50 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var43);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    double[] var9 = new double[] { };
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var9, var11);
    double[] var15 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var15);
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var9, var15);
    org.apache.commons.math3.util.MathArrays.OrderDirection var18 = null;
    boolean var21 = org.apache.commons.math3.util.MathArrays.checkOrder(var15, var18, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
    boolean var24 = org.apache.commons.math3.util.MathArrays.isMonotonic(var15, var22, false);
    double[] var25 = new double[] { };
    double[] var27 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var27);
    double var29 = org.apache.commons.math3.util.MathArrays.distance1(var25, var27);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double var33 = org.apache.commons.math3.util.MathArrays.distance1(var25, var31);
    double var34 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    double[] var35 = org.apache.commons.math3.util.MathArrays.ebeDivide(var15, var31);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var6, var15);
    double[] var37 = org.apache.commons.math3.util.MathArrays.copyOf(var36);
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-97.02018957950251d));
//     java.lang.Throwable var3 = null;
//     var2.addSuppressed(var3);
// 
//   }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(0.0d, 984.6226564837881d, false);
//     java.lang.String var13 = var1.nextSecureHexString(4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.46254472376323d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 103.47811340633753d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 645.7671832224502d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "b79c"+ "'", var13.equals("b79c"));
// 
//   }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     int var11 = var1.nextHypergeometric(10, 1, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var14 = var1.nextPermutation(809123836, 100);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.4693288549543d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 90.80817304277814d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
// 
//   }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    long[] var2 = new long[] { 0L, 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    long[][] var4 = new long[][] { var2};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var2 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)98.43713016096305d, (java.lang.Number)9.834337537501083d, 5);
    org.apache.commons.math3.util.Pair var8 = new org.apache.commons.math3.util.Pair((java.lang.Object)var2, (java.lang.Object)98.43713016096305d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     var0.reSeedSecure((-1L));
//     var0.reSeed(2L);
//     double var16 = var0.nextWeibull(98.46619727159656d, 1.819217204815299d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var0.nextHypergeometric(0, 5, 1);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 221.37031590264053d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "2a82b8dabc"+ "'", var9.equals("2a82b8dabc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.8361073492936983d);
// 
//   }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 1);
// 
//   }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextUniform(0.39583726512027007d, (-0.8305377380798146d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 94.14804426051023d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.07799817306294106d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.04174921903832885d);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var17 = var16.getSupportUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var19 = var16.inverseCumulativeProbability(18.70038216057098d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);

  }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     int var9 = var1.nextZipf(10, 13.521216539811984d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var1.nextHypergeometric(0, 827167750, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 100.4011697033364d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "a"+ "'", var6.equals("a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
// 
//   }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)100, var1, 10, var3, false);
    int var6 = var5.getIndex();
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    float[] var15 = new float[] { 0.0f, (-1.0f)};
    float[] var16 = null;
    boolean var17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var15, var16);
    java.lang.Object[] var18 = new java.lang.Object[] { var16};
    org.apache.commons.math3.exception.MathArithmeticException var19 = new org.apache.commons.math3.exception.MathArithmeticException(var12, var18);
    org.apache.commons.math3.exception.NotFiniteNumberException var20 = new org.apache.commons.math3.exception.NotFiniteNumberException(var10, (java.lang.Number)(byte)10, var18);
    org.apache.commons.math3.exception.MathInternalError var21 = new org.apache.commons.math3.exception.MathInternalError(var9, var18);
    org.apache.commons.math3.exception.MathArithmeticException var22 = new org.apache.commons.math3.exception.MathArithmeticException(var8, var18);
    org.apache.commons.math3.exception.MathIllegalStateException var23 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var7, var18);
    org.apache.commons.math3.util.MathArrays.OrderDirection var24 = var5.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.cumulativeProbability(1.0646160893106429d);
    double var23 = var16.cumulativeProbability(104.91028148840213d);
    double[] var25 = var16.sample(7);
    boolean var26 = var16.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)4, true);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 4+ "'", var5.equals(4));

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.819217204815299d, (java.lang.Number)0.5104454862955553d, 3, var3, true);
    int var6 = var5.getIndex();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var5.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     var0.reSeed(152600911433040288L);
//     java.lang.String var15 = var0.nextHexString(7);
//     java.util.Collection var16 = null;
//     java.lang.Object[] var18 = var0.nextSample(var16, 5);
// 
//   }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     double var8 = var1.nextUniform(1.0d, 1.2388070620041405d, false);
//     double var11 = var1.nextCauchy(0.5104454862955553d, 97.97864407980379d);
//     double var13 = var1.nextExponential(0.7079794124142618d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10.035931213833267d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.1027640215523336d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1421.7757447815013d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.3050552160103484d);
// 
//   }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    float[] var0 = null;
    float[] var1 = null;
    float[] var2 = new float[] { };
    boolean var3 = org.apache.commons.math3.util.MathArrays.equals(var1, var2);
    float[] var6 = new float[] { 0.0f, (-1.0f)};
    float[] var7 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var6, var7);
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var1, var6);
    float[] var10 = null;
    float[] var11 = new float[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var10, var11);
    float[] var15 = new float[] { 0.0f, (-1.0f)};
    float[] var16 = null;
    boolean var17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var15, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var15);
    float[] var19 = null;
    float[] var20 = new float[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var19, var20);
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var15, var20);
    float[] var23 = null;
    float[] var24 = new float[] { };
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var23, var24);
    float[] var28 = new float[] { 0.0f, (-1.0f)};
    float[] var29 = null;
    boolean var30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var28, var29);
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var23, var28);
    float[] var32 = null;
    float[] var33 = new float[] { };
    boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var32, var33);
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var28, var33);
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var15, var28);
    boolean var37 = org.apache.commons.math3.util.MathArrays.equals(var6, var15);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var0, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var18 = var16.density(99.02988657003175d);
    boolean var19 = var16.isSupportLowerBoundInclusive();
    var16.reseedRandomGenerator(2876919108950029338L);
    double var23 = var16.density(0.7157990521557022d);
    var16.reseedRandomGenerator(1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var27 = var16.inverseCumulativeProbability(224.24061129059865d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.density(1.2316468095843844d);
    double var22 = var16.getNumericalVariance();
    double var23 = var16.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     double var11 = var0.nextT(211.79400708576884d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var14 = var0.nextSecureLong(31715294113568244L, (-115747454037461536L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 257.19125690465734d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "dc9a585a48"+ "'", var9.equals("dc9a585a48"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.1837322845688281d));
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var3 = var2.getValue();
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl();
    var5.reSeed();
    boolean var7 = var2.equals((java.lang.Object)var5);
    org.apache.commons.math3.util.Pair var8 = new org.apache.commons.math3.util.Pair(var2);
    java.lang.Object var9 = var2.getFirst();
    java.lang.Object var10 = var2.getValue();
    org.apache.commons.math3.util.Pair var11 = new org.apache.commons.math3.util.Pair(var2);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double[] var16 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeDivide(var13, var16);
    double[] var19 = new double[] { };
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double var23 = org.apache.commons.math3.util.MathArrays.distance1(var19, var21);
    org.apache.commons.math3.util.MathArrays.OrderDirection var24 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var21, var24, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var21);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var28 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var21);
    double var30 = var28.density(99.02988657003175d);
    boolean var31 = var28.isSupportUpperBoundInclusive();
    double var33 = var28.probability(263.1966961055d);
    boolean var34 = var28.isSupportUpperBoundInclusive();
    var28.reseedRandomGenerator(133869137708899648L);
    boolean var37 = var2.equals((java.lang.Object)133869137708899648L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1L+ "'", var3.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (-1L)+ "'", var9.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 1L+ "'", var10.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);

  }

}
