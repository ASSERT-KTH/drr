
import junit.framework.*;

public class RandoopTest8 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test1"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(41496L, 1172653612L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test2"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var5 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var3, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test3"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.cumulativeProbability((-0.5745618421848383d));
    boolean var3 = var0.isSupportLowerBoundInclusive();
    double var4 = var0.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.28279383239600014d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test4"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("d98c8f10fc");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test5"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextWeibull(7.769493748166378d, 1.2185657441986304d);
//     int var9 = var0.nextPascal(1980, 0.0d);
//     int var12 = var0.nextSecureInt(1499, 1947);
//     double var15 = var0.nextGamma(0.6413073337280892d, 0.5878830012117422d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.1802948184604496d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1518);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.7922867468424576d);
// 
//   }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test6"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var13 = var0.nextChiSquare(3.5256464698322323d);
//     double var16 = var0.nextBeta(0.4663611619490422d, 0.595174897105027d);
//     var0.reSeed();
//     long var19 = var0.nextPoisson(0.20584945432845803d);
//     java.lang.String var21 = var0.nextHexString(100);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 14.267835698243434d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "0ae24b6872"+ "'", var8.equals("0ae24b6872"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.281952353550203d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.16435506954719767d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "eb9bb843a2c01c93be59b9a54edeaaa90ae24b6872fdbfabde2d3812b0024e585e1685e4333a5032ce08acd216854435a150"+ "'", var21.equals("eb9bb843a2c01c93be59b9a54edeaaa90ae24b6872fdbfabde2d3812b0024e585e1685e4333a5032ce08acd216854435a150"));
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test7"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(408490575, 90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 90);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test8"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.0139693382746255d, (java.lang.Number)10.792740204640475d, false);

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test9"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var4.addElement((-0.43408597923864894d));
//     double var10 = var4.getElement(0);
//     double[] var11 = var4.getElements();
//     var4.addElement(21.0d);
//     var4.setNumElements(3);
//     org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var17 = var16.getStandardDeviation();
//     double[] var19 = var16.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
//     var20.contract();
//     int var22 = var20.getNumElements();
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var20);
//     org.apache.commons.math3.util.ResizableDoubleArray var24 = var4.copy();
//     int var25 = var24.getNumElements();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var24.setExpansionFactor(2.5000005f);
//       fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
//     } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.1824348420064521d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 3);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test10"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.3841864E-7f, 0.07872787040609376d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.3841866E-7f);

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test11"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getStandardDeviation();
//     double[] var13 = var10.sample(1);
//     double var15 = var10.cumulativeProbability(0.0d);
//     double var16 = var10.getSupportUpperBound();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     double var21 = var0.nextUniform((-0.5745618421848383d), 790.5397402246074d, false);
//     double var24 = var0.nextGamma(8.10505592044534d, (-0.7719096331877858d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9.224625751635086d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.1990364049159611d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 430.99373934703704d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-10.104171034816586d));
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test12"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-1.931918750985446d), 2.0171610553467367d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0171610553467367d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test13"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.7690882075438712d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.444146842373021d);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test14"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2097152.2f, (-79579695));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test15"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double[] var6 = var0.sample(100);
//     double var7 = var0.sample();
//     double var8 = var0.sample();
//     double var9 = var0.getStandardDeviation();
//     double[] var11 = var0.sample(1868);
//     double var12 = var0.getNumericalMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.48364451851302986d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.7550042701224968d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
// 
//   }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test16"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(100L);
//     java.lang.String var19 = var0.nextHexString(33392016);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9.570458716395061d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "a13b6abae691c985ee974dec5de4eeee5ccaeb59d5bf2ed52a385537b19910610a8bfdba4b736161eb09fb400fe6f18243f9"+ "'", var8.equals("a13b6abae691c985ee974dec5de4eeee5ccaeb59d5bf2ed52a385537b19910610a8bfdba4b736161eb09fb400fe6f18243f9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.06860689453096758d);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test17"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.exception.OutOfRangeException var17 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.15512025679417774d, (java.lang.Number)1.2471705263294632d, (java.lang.Number)0.0843874063990762d);
    boolean var18 = var2.equals((java.lang.Object)1.2471705263294632d);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var20 = var19.getTiesStrategy();
    int var21 = var20.ordinal();
    int var22 = var20.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var24 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var20);
    java.lang.Class var25 = var20.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test18"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(9.536745E-7f, 0.9792351001360415d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.536747E-7f);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test19"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(9446, 1964);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1964);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test20"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
//     var1.addElement(2.0216852347077916d);
//     org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var5 = var4.getStandardDeviation();
//     double[] var7 = var4.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var12 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var11, (java.lang.Object[])var12);
//     org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var10, (java.lang.Object[])var12);
//     org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var9, (java.lang.Object[])var12);
//     boolean var16 = var8.equals((java.lang.Object)var9);
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var8);
//     int var18 = var1.start();
//     org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var20 = var19.getStandardDeviation();
//     double[] var22 = var19.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
//     org.apache.commons.math3.exception.util.Localizable var24 = null;
//     org.apache.commons.math3.exception.util.Localizable var25 = null;
//     org.apache.commons.math3.exception.util.Localizable var26 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var27 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.NullArgumentException var28 = new org.apache.commons.math3.exception.NullArgumentException(var26, (java.lang.Object[])var27);
//     org.apache.commons.math3.exception.MathInternalError var29 = new org.apache.commons.math3.exception.MathInternalError(var25, (java.lang.Object[])var27);
//     org.apache.commons.math3.exception.NullArgumentException var30 = new org.apache.commons.math3.exception.NullArgumentException(var24, (java.lang.Object[])var27);
//     boolean var31 = var23.equals((java.lang.Object)var24);
//     var23.setElement(8899, 2.3930658372149933d);
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var23);
//     org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var36);
//     org.apache.commons.math3.distribution.NormalDistribution var38 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var39 = var38.getStandardDeviation();
//     double[] var41 = var38.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var42 = new org.apache.commons.math3.util.ResizableDoubleArray(var41);
//     int var43 = var42.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var44 = var42.copy();
//     var42.addElement((-0.43408597923864894d));
//     double var48 = var42.getElement(0);
//     double[] var49 = var42.getElements();
//     var42.addElement(21.0d);
//     var42.setNumElements(3);
//     org.apache.commons.math3.distribution.NormalDistribution var54 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var55 = var54.getStandardDeviation();
//     double[] var57 = var54.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var58 = new org.apache.commons.math3.util.ResizableDoubleArray(var57);
//     var58.contract();
//     int var60 = var58.getNumElements();
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var42, var58);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var62 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var66 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var67 = new org.apache.commons.math3.util.ResizableDoubleArray(var66);
//     org.apache.commons.math3.distribution.NormalDistribution var68 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var69 = var68.getSupportUpperBound();
//     double[] var71 = var68.sample(10);
//     double var72 = var62.mannWhitneyU(var66, var71);
//     var42.addElements(var66);
//     var1.addElements(var66);
//     var1.contract();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1.0432026325043386d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 21.0d);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test21"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.99999994f), 0.012504468662168831d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.9999999f));

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test22"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-1.6804163900380429d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.777043494155161d);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test23"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1954, 2.8E-45f, 0.0f, 8512);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test24"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.36977327227972484d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.36182647411938723d);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test25"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    java.lang.Class var16 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var14);
    boolean var19 = var14.equals((java.lang.Object)12185.029950707303d);
    java.lang.String var20 = var14.name();
    int var21 = var14.ordinal();
    java.lang.String var22 = var14.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "AVERAGE"+ "'", var22.equals("AVERAGE"));

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test26"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)100L, (java.lang.Number)11166, false);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test27"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(8L, 2696L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2704L);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test28"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.6413073337280892d, 2.5517620356803068E-188d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6413073337280892d);

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test29"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeedSecure(0L);
//     int[] var15 = var0.nextPermutation(181, 27);
//     java.lang.String var17 = var0.nextSecureHexString(9142);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.391214154378117d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "fbe2d16445"+ "'", var8.equals("fbe2d16445"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test30"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(323);
    var1.contract();

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test31"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(3.5297004194695996d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9982828899112327d);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test32"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    double[] var6 = var4.getInternalValues();
    org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var8 = var7.getStandardDeviation();
    double[] var10 = var7.sample(1);
    double var11 = var7.getMean();
    double[] var13 = var7.sample(100);
    var4.addElements(var13);
    int var15 = var4.getExpansionMode();
    float var16 = var4.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var18 = var4.getElement(305);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.0f);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test33"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(0, 1947);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test34"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var5 = var0.cumulativeProbability(0.0d);
//     double var6 = var0.getSupportUpperBound();
//     boolean var7 = var0.isSupportUpperBoundInclusive();
//     double var8 = var0.getStandardDeviation();
//     double var9 = var0.getSupportUpperBound();
//     double var10 = var0.getSupportLowerBound();
//     double var12 = var0.density(0.3363717774100053d);
//     double var13 = var0.getNumericalMean();
//     double var14 = var0.sample();
//     double var16 = var0.probability(0.48262694182950977d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.3769994616483318d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.556056879171914d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test35"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    var4.clear();
    int var9 = var4.getNumElements();
    int var10 = var4.start();
    var4.setNumElements(2297);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    int var14 = var4.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test36"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)9.87430062351698d);
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var5 = var4.getStandardDeviation();
    double[] var7 = var4.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double[] var9 = var8.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var17 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var13, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var18 = var17.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var19 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var12, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathArithmeticException var20 = new org.apache.commons.math3.exception.MathArithmeticException(var11, (java.lang.Object[])var18);
    boolean var21 = var10.equals((java.lang.Object)var18);
    org.apache.commons.math3.exception.MathIllegalArgumentException var22 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalStateException var23 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, (java.lang.Object[])var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test37"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    java.lang.Class var6 = var4.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    java.lang.String var8 = var4.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    java.lang.String var10 = var2.name();
    int var11 = var2.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "MAXIMAL"+ "'", var10.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test38"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2097152.2f, 32768);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test39"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("798795fd8c");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test40"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.01329232558537528d, (java.lang.Number)0.015673944082810035d, true);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test41"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(6L, 1877);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test42"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 6L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 9694);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 4L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test43"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-0.9205743426694956d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.972791175154096d));

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test44"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(11.734114385974351d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 12L);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test45"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var4.addElement((-0.43408597923864894d));
//     double var10 = var4.getElement(0);
//     var4.clear();
//     var4.setElement(0, 236.64698555037546d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.14667482474485885d));
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test46"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    java.lang.Class var6 = var4.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    java.lang.String var8 = var4.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    java.lang.Class var10 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    java.lang.Class var16 = var14.getDeclaringClass();
    boolean var18 = var14.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    java.lang.Class var19 = var14.getDeclaringClass();
    java.lang.Class var20 = var14.getDeclaringClass();
    java.lang.String var21 = var14.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var14);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "AVERAGE"+ "'", var21.equals("AVERAGE"));

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test47"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(10L, 29640L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 29640L);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test48"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1891, (-4));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1887);

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test49"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform((-0.9986814996153957d), 30.14110668368703d);
//     double var17 = var0.nextUniform(2.0857110610969416d, 20.26878729288562d);
//     double var20 = var0.nextF(2.254237830909974E-6d, 0.7233703768189484d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.21520347022053d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ed1bc5931a"+ "'", var8.equals("ed1bc5931a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-0.5023845054579199d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 5.862761314827958d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.6473561543230427E-9d);
// 
//   }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test50"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     int var11 = var0.nextZipf(5, 0.8273572477024794d);
//     double var14 = var0.nextGamma((-1.9235391122654637d), 6.774605976508678d);
//     int[] var17 = var0.nextPermutation(11395, 321);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 32.33763307899747d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "7f0fbf846f01903f1e6b961e8dbb22d4eb028568ec0d3f651945880b1744cc417121326f95b28e7a3fd4cde07c8c062d0fa4"+ "'", var8.equals("7f0fbf846f01903f1e6b961e8dbb22d4eb028568ec0d3f651945880b1744cc417121326f95b28e7a3fd4cde07c8c062d0fa4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 22.870790273608367d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test51"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1868, 749);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2617);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test52"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(553.6455155924548d, 35840.53501424614d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test53"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(1343);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8334.694318112313d);

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test54"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var13 = var0.nextT(5.867156662812015d);
//     double var16 = var0.nextGamma(0.13558023874553457d, 0.010050505059049992d);
//     double var19 = var0.nextGamma(0.6240600968487551d, 0.0d);
//     double var21 = var0.nextExponential(0.40102927495477353d);
//     var0.reSeed();
//     double var24 = var0.nextExponential(0.40761628564048374d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 35.32464985780923d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ceb4517956"+ "'", var8.equals("ceb4517956"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.3604852789161938d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.005717684934281954d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.16585185006248196d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.3214727330827616d);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test55"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 10.0f);
    var2.addElement(0.15729920705028488d);
    var2.clear();
    double[] var6 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    var7.contract();
    float var9 = var7.getContractionCriteria();
    var7.setExpansionMode(0);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.5f);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test56"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.683999519410136d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6839995194101361d);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test57"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.5805536752331785d, 0.7837695321851785d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.4480550849109058d);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test58"); }


    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(1972, 99.99999f, Float.POSITIVE_INFINITY);
    var3.setNumElements(8899);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test59"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.5313014354155909d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test60"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1916);
    float var2 = var1.getExpansionFactor();
    int var3 = var1.getNumElements();
    float var4 = var1.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.5f);

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test61"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(8.854558633913316d, 3.1173466159040992d);
//     double var3 = var2.sample();
//     double var5 = var2.cumulativeProbability(0.22075574193664588d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var2.cumulativeProbability(3.6043304842675816d, 0.5209889136049527d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 11.245465897670554d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.002806259436965164d);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test62"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(1.2325719927685974d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.220899049867911d);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test63"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    boolean var7 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator((-16L));
    double[] var11 = var0.sample(2297);
    double var12 = var0.sample();
    double var13 = var0.sample();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var0.inverseCumulativeProbability(1.0766040743016103d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.5481764785100467d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.7745165844127913d);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test64"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.20458087156593074d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test65"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var4.addElement((-0.43408597923864894d));
//     double var10 = var4.getElement(0);
//     int var11 = var4.getExpansionMode();
//     float var12 = var4.getExpansionFactor();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.22275019757633194d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2.0f);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test66"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)5.5340486413273595d, var1, false);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test67"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
    var4.discardMostRecentElements(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 20.696514663540924d);

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test68"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     double var9 = var0.nextGamma(9.319248049587957d, (-0.4255538433808183d));
//     long var11 = var0.nextPoisson(0.9978516012375751d);
//     int var14 = var0.nextZipf(8941, 1.445343853698748d);
//     java.lang.String var16 = var0.nextHexString(3826);
//     double var19 = var0.nextGaussian(1.383036361567265d, 18.853048230723537d);
//     var0.reSeed();
//     var0.reSeed(201600L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var25 = var0.nextSecureInt(1499, (-22));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1.6190010873766296d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-3.0714505387958813d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "2de0504dfdce05722f085176cd78299f5801bea04adb861ba4db8bda0777085e612ab9533d3108b1c7c673c75cb1711fbc1475ba3f3b1b1675a57f609fa373f0733584d43eb9a75f4c2e326cf2b113d8ef006ee564e7e5fdfee490473a44312cfde5be93b340c20f11bedcd71d19323522acccce2c0fffcced09beb78a2cda0eaa0b46571ebd958386eaae694c01d4cf943aad2a4412d7a3ff0a1b9c7a274f2aa33df17b68d4232ef7f92bdb2ed5833975c9c406a0adda6a954f2cff4e60cc405de4805a3ebbe6bd18a05880204746279aaf84be338a6b19b4afc7244e1dac35f6c494387ae767750ee56380fc2e6571dc02ce4ad2dffd23d27e934a9bc9bb5b8c7c0aefb155b2f52b669c543f2bd77c354bd136d189160a912f21f5de568c9dba2401b65a75c00d0f63263a3a39b7d00bca8b31501b6e86cb4ccc9a1f72c7b4c14eb3014695c009e29224fb96c2475e18c437ee62ff9c76c62191694293b3840b58786c38efa573acf530b29e759be39059b2c86dec338e46d98888f0d21af947928a805c5f55207f93cfc76cdb75a651f872bd10e0d6caae13a1899ad387c8a78e32fd0e7d533e6c9c87a8ce6a198fae741615a1d57b5503e3da08e19a545fea9a08b250f8611acb2be9aeaf93f0c957963994e5179a423d21e497d2e857d5c48f4951ad1b42e6facae8a35f2381f10fcc50dbe2e6b578527e3c2d425fd8408202285dbc58c7848f7b54c56365d119a23d98e976dc4c9c3f1acaa9617d9c4fdfed998b1f56b1a64b4b692e878d5fc9c029b67bfc87c81d2bd0cbba246a05a1cac955f6ca9c3480d6ec20f34455a68c02ea1359a79e7d064d2a6cad84611f4c2e5b3e25040fc9895168b0899a873990b2571d996eec9b6f5f4e59f8ffebcaf33334e6973cfbb25fba2edb643c31d2d1795b0e9043f5744dadbc3e1997df70c4cede8d9009824f0377d265b1cf3c3c32d9e1396223e46bc9d1859d3ef6c821740138d8f07927d954fe76f3513b54a9c18c489b6cd36aa8000e760285c1a597b838295c04cffe2f40b5c5e36ce7311b8a59b17eae687df29ddfb25291429de589477f742c34ec021c13390651c04b0c3980b5c840a349773bf65267e6cbfa2bb0a7663d0393909e36cd771ced0c8902e0572e43c4c7eb01deaefd41ed990b880678a7a49a3230b93f8fc76fb701fbf88e9572a147193e7fb43c51552aefa2de6b3ae26b697d4ee7e77b3e63cf00b31006df42bebd458026ba5fd8f6b96915d74058916e03a29272f6f90a5d157b54a8cf284850edaa338bc340aa684fb697696aa7593e0fb3c1fe9d16f8c81d4bf82945c576e11d5194e1ef42aacd67e97c8e889a04fa13f460ee281d45a6f1f1f4b1e8365dafa695040a5adf065c4d159dd2f1bdba315840083001cc80392712467843e756c67a67b776c33865804bcb82ac83ff05c8489e2a1b2d09094fcdfcca6e0a48f038646567216ea88f609a3552383d125f044bb0daf4faf47946ccb29331a92a27d6afccae00f0f6b09d1662de019ab50084fcb0f52964d588c19c235c78785b7f5640152a2fa4dce9019eed3f9719c2f78b0e9bf8388a2455fcff5cdd03df626c64648d242e7e8d35858bc76715158fd1e00f0ebbe2dbcf3bc660192c741867663a3482573a5e7d359e8f26b1b158fb2c19a71af9afb21cd289b7717c33ace8e50773984f812aaa3ec31fec4f00f6a464b27953537442eb45dfadd02dcd40d2772d5f4d3bb151ca5a2c9e7b1fe634c6c643a22c3b90c320132885c91b4d22d7df4671403974116eba267d5831a2b48e02fa9df0d2fc9c95336e6967fa3eb45a12a95d0897e33b5d3d57ae1bb4472d948e6d6ce08348d368948d1773910f2854b13fdadddf5d17fb2f67864c42546137121d67c46b33b0880682789488e70fae26066a1b3a658acd75f095da71dd03150fdf2c2240df5e364cf4b60ddf9213735e7b4fd10cc481313d8030592e6ee22650c43b993d6957c3f3bc7b394f5ccd9845ee1a529cf5831f9a2987cb040dae959fba842fe4db0523d28c97c06f20b9a7abd1b051d8f2495280c1eeb0c45f4fb206ecba04db7decea01ccdc73706770dbd0a9d0a67f87f19f6645a03dbd76017c299e0ec7d263c68f660ff3db31962867e3b241eb4ec73e1882733f493b3f8a209dd71f3a02526179bbcc968243add3ce08297210bd17c8982c20140d7d6b2c36f5ab4a96577e7081048ee54dd35942263089cfbbb4b26a534b7e5ee55ee6623e33bfbf944d315ddaf1347d8cc6e2f8bf5f9395ae803d1952085f0b707407f9c8968582d1c6fcc8d9b41dd05bbfbc278b2269c290d0c4fff20f90360447074ac9e6c2e9b636a3bbe1cef14f4d1b22fadbcc9fb67b5f3eca8c3bd1355f7cdb955e115e2a334c9346c3cd503afc500420203310343949d1b4eed282f27569da1bff052b6ebc110605ee43289bb6a5eda8f55826f689e57a6751315d7c0b2913efa8aa3f88c0295f344d2c6fe263f67107617235fe136031314faa9f1496b39f74af2210b8f99ea1dc4cfe89e7a66969e1ec340bb2488169e4727e487e7a0022f2770d1d799a57814110d0f175f580a402e5c89182b7cecba4fa9de077ff8e93ce75270e2cdd0c264a21de41c477398eda525e7ff189c2cdba8d8b079c0b653fe033261d80c2e31e88ecda26a74a8c41a131b2b634d31429165e"+ "'", var16.equals("2de0504dfdce05722f085176cd78299f5801bea04adb861ba4db8bda0777085e612ab9533d3108b1c7c673c75cb1711fbc1475ba3f3b1b1675a57f609fa373f0733584d43eb9a75f4c2e326cf2b113d8ef006ee564e7e5fdfee490473a44312cfde5be93b340c20f11bedcd71d19323522acccce2c0fffcced09beb78a2cda0eaa0b46571ebd958386eaae694c01d4cf943aad2a4412d7a3ff0a1b9c7a274f2aa33df17b68d4232ef7f92bdb2ed5833975c9c406a0adda6a954f2cff4e60cc405de4805a3ebbe6bd18a05880204746279aaf84be338a6b19b4afc7244e1dac35f6c494387ae767750ee56380fc2e6571dc02ce4ad2dffd23d27e934a9bc9bb5b8c7c0aefb155b2f52b669c543f2bd77c354bd136d189160a912f21f5de568c9dba2401b65a75c00d0f63263a3a39b7d00bca8b31501b6e86cb4ccc9a1f72c7b4c14eb3014695c009e29224fb96c2475e18c437ee62ff9c76c62191694293b3840b58786c38efa573acf530b29e759be39059b2c86dec338e46d98888f0d21af947928a805c5f55207f93cfc76cdb75a651f872bd10e0d6caae13a1899ad387c8a78e32fd0e7d533e6c9c87a8ce6a198fae741615a1d57b5503e3da08e19a545fea9a08b250f8611acb2be9aeaf93f0c957963994e5179a423d21e497d2e857d5c48f4951ad1b42e6facae8a35f2381f10fcc50dbe2e6b578527e3c2d425fd8408202285dbc58c7848f7b54c56365d119a23d98e976dc4c9c3f1acaa9617d9c4fdfed998b1f56b1a64b4b692e878d5fc9c029b67bfc87c81d2bd0cbba246a05a1cac955f6ca9c3480d6ec20f34455a68c02ea1359a79e7d064d2a6cad84611f4c2e5b3e25040fc9895168b0899a873990b2571d996eec9b6f5f4e59f8ffebcaf33334e6973cfbb25fba2edb643c31d2d1795b0e9043f5744dadbc3e1997df70c4cede8d9009824f0377d265b1cf3c3c32d9e1396223e46bc9d1859d3ef6c821740138d8f07927d954fe76f3513b54a9c18c489b6cd36aa8000e760285c1a597b838295c04cffe2f40b5c5e36ce7311b8a59b17eae687df29ddfb25291429de589477f742c34ec021c13390651c04b0c3980b5c840a349773bf65267e6cbfa2bb0a7663d0393909e36cd771ced0c8902e0572e43c4c7eb01deaefd41ed990b880678a7a49a3230b93f8fc76fb701fbf88e9572a147193e7fb43c51552aefa2de6b3ae26b697d4ee7e77b3e63cf00b31006df42bebd458026ba5fd8f6b96915d74058916e03a29272f6f90a5d157b54a8cf284850edaa338bc340aa684fb697696aa7593e0fb3c1fe9d16f8c81d4bf82945c576e11d5194e1ef42aacd67e97c8e889a04fa13f460ee281d45a6f1f1f4b1e8365dafa695040a5adf065c4d159dd2f1bdba315840083001cc80392712467843e756c67a67b776c33865804bcb82ac83ff05c8489e2a1b2d09094fcdfcca6e0a48f038646567216ea88f609a3552383d125f044bb0daf4faf47946ccb29331a92a27d6afccae00f0f6b09d1662de019ab50084fcb0f52964d588c19c235c78785b7f5640152a2fa4dce9019eed3f9719c2f78b0e9bf8388a2455fcff5cdd03df626c64648d242e7e8d35858bc76715158fd1e00f0ebbe2dbcf3bc660192c741867663a3482573a5e7d359e8f26b1b158fb2c19a71af9afb21cd289b7717c33ace8e50773984f812aaa3ec31fec4f00f6a464b27953537442eb45dfadd02dcd40d2772d5f4d3bb151ca5a2c9e7b1fe634c6c643a22c3b90c320132885c91b4d22d7df4671403974116eba267d5831a2b48e02fa9df0d2fc9c95336e6967fa3eb45a12a95d0897e33b5d3d57ae1bb4472d948e6d6ce08348d368948d1773910f2854b13fdadddf5d17fb2f67864c42546137121d67c46b33b0880682789488e70fae26066a1b3a658acd75f095da71dd03150fdf2c2240df5e364cf4b60ddf9213735e7b4fd10cc481313d8030592e6ee22650c43b993d6957c3f3bc7b394f5ccd9845ee1a529cf5831f9a2987cb040dae959fba842fe4db0523d28c97c06f20b9a7abd1b051d8f2495280c1eeb0c45f4fb206ecba04db7decea01ccdc73706770dbd0a9d0a67f87f19f6645a03dbd76017c299e0ec7d263c68f660ff3db31962867e3b241eb4ec73e1882733f493b3f8a209dd71f3a02526179bbcc968243add3ce08297210bd17c8982c20140d7d6b2c36f5ab4a96577e7081048ee54dd35942263089cfbbb4b26a534b7e5ee55ee6623e33bfbf944d315ddaf1347d8cc6e2f8bf5f9395ae803d1952085f0b707407f9c8968582d1c6fcc8d9b41dd05bbfbc278b2269c290d0c4fff20f90360447074ac9e6c2e9b636a3bbe1cef14f4d1b22fadbcc9fb67b5f3eca8c3bd1355f7cdb955e115e2a334c9346c3cd503afc500420203310343949d1b4eed282f27569da1bff052b6ebc110605ee43289bb6a5eda8f55826f689e57a6751315d7c0b2913efa8aa3f88c0295f344d2c6fe263f67107617235fe136031314faa9f1496b39f74af2210b8f99ea1dc4cfe89e7a66969e1ec340bb2488169e4727e487e7a0022f2770d1d799a57814110d0f175f580a402e5c89182b7cecba4fa9de077ff8e93ce75270e2cdd0c264a21de41c477398eda525e7ff189c2cdba8d8b079c0b653fe033261d80c2e31e88ecda26a74a8c41a131b2b634d31429165e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 7.222211024370507d);
// 
//   }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test69"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
//     org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
//     org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
//     boolean var12 = var4.equals((java.lang.Object)var5);
//     var4.discardMostRecentElements(1);
//     org.apache.commons.math3.distribution.NormalDistribution var17 = new org.apache.commons.math3.distribution.NormalDistribution(4.5d, 0.017688387388495763d);
//     double var18 = var17.getSupportUpperBound();
//     double var19 = var17.sample();
//     double var21 = var17.density((-86.58313008438003d));
//     double var23 = var17.density(0.32120122832835923d);
//     boolean var24 = var4.equals((java.lang.Object)0.32120122832835923d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 4.494730477881272d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test70"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    java.lang.String var6 = var5.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test71"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     int var11 = var0.nextZipf(5, 0.8273572477024794d);
//     int var14 = var0.nextBinomial(1972, 0.15795521463156686d);
//     int var17 = var0.nextInt(16, 1471);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.112669308039727d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "34f530f9c9bf0a71ea1885117123058c47d4794c3f5a58a4907692ad5bf5e73fc4042d75869411d2c6acbc46b32405f95300"+ "'", var8.equals("34f530f9c9bf0a71ea1885117123058c47d4794c3f5a58a4907692ad5bf5e73fc4042d75869411d2c6acbc46b32405f95300"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 284);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 925);
// 
//   }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test72"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.48364451851302986d, (java.lang.Number)0.09401821487395612d, true);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test73"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-1149L), (-8L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test74"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    var4.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var4.copy();
    int var10 = var4.getNumElements();
    float var11 = var4.getExpansionFactor();
    int var12 = var4.getExpansionMode();
    org.apache.commons.math3.exception.NotPositiveException var14 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-0.9999999999999999d));
    org.apache.commons.math3.exception.util.ExceptionContext var15 = var14.getContext();
    boolean var16 = var4.equals((java.lang.Object)var15);
    int var17 = var4.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var19 = var4.getElement(4311469);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test75"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     double var16 = var0.nextGaussian(0.9999494957997512d, 25.472636453138065d);
//     double var18 = var0.nextT(192.9088122275434d);
//     double var21 = var0.nextCauchy(4.950886585270677E-4d, 0.6240600968487552d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.246697489268169d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "58334f16d0"+ "'", var8.equals("58334f16d0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1925);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.005447015959775088d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-7.409550648796562d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2.079557646766606d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1.1833205840073124d));
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test76"); }


    double[] var3 = new double[] { 0.0d, (-1.0d), 0.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var6 = var5.getStandardDeviation();
    double[] var8 = var5.sample(1);
    double var9 = var5.getMean();
    double[] var11 = var5.sample(100);
    var4.addElements(var11);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var4.copy();
    var4.addElement(0.9999494957997512d);
    double var17 = var4.substituteMostRecentElement(12.770914443685303d);
    int var18 = var4.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.9999494957997512d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test77"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.10765691634932728d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8789898608874487d);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test78"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(2.5000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test79"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.13558023874553457d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 55.77085302124092d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test80"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(1954);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test81"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1.0125754552662622d);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test82"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)2.1408954707709844E13d, (java.lang.Number)120.0d, (java.lang.Number)0.815297812486526d);

  }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test83"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     double var5 = var0.nextChiSquare(7.6675647339750626d);
//     int var8 = var0.nextInt(9, 1866);
//     java.lang.String var10 = var0.nextHexString(10743);
//     double var13 = var0.nextUniform(0.08556937673988257d, 6.554313158886412d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.4514100075450906d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.98339630705109d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1189);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5.869680698294024d);
// 
//   }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test84"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     var0.reSeedSecure();
//     int var10 = var0.nextBinomial(243, 0.745691842295965d);
//     long var12 = var0.nextPoisson(31.862892444737472d);
//     double var15 = var0.nextGamma(15.79755955817176d, 2.717220411501478d);
//     long var18 = var0.nextSecureLong((-1342158336L), 11L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var0.nextF(0.0d, 4.149647634883433d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.26795816502699404d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 176);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 24L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 48.32978734362822d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-472662410L));
// 
//   }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test85"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     int var11 = var0.nextZipf(5, 0.8273572477024794d);
//     int var14 = var0.nextBinomial(1972, 0.15795521463156686d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var16 = var0.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 26.72127852811005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5a9a4859e86148be113cb4e67a6f35acf07ae2653b0cdb36cd2095cd994978d2d69329091345fb2f6429d997c4167eb9db3b"+ "'", var8.equals("5a9a4859e86148be113cb4e67a6f35acf07ae2653b0cdb36cd2095cd994978d2d69329091345fb2f6429d997c4167eb9db3b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 305);
// 
//   }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test86"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(90, 1203);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test87"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.11537426317526311d);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test88"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.5834694007285642d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 33.43033413677409d);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test89"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(206L, 11L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 217L);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test90"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var7 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var3, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var8 = var7.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var11.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test91"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.1390513081053693d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.1238034320081267d);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test92"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.8E-45f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.8E-45f);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test93"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)889, (java.lang.Number)0.5879680852503826d, true);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.5879680852503826d+ "'", var5.equals(0.5879680852503826d));

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test94"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     double var9 = var0.nextUniform(0.0d, 0.5382762305934016d);
//     double var12 = var0.nextGaussian(0.16477040754512196d, 0.9999996994297856d);
//     java.lang.String var14 = var0.nextHexString(10403);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.20267870716260739d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.17505454728841088d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.35147511930312847d));
// 
//   }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test95"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     var4.addElement(14.031149057314524d);
//     double var9 = var4.getElement(0);
//     var4.contract();
//     double[] var14 = new double[] { 0.0d, (-1.0d), 0.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
//     var15.contract();
//     float var17 = var15.getExpansionFactor();
//     org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
//     boolean var20 = var15.equals((java.lang.Object)0.9999997887160175d);
//     int var21 = var15.getNumElements();
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var15);
//     double[] var23 = null;
//     var15.addElements(var23);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test96"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.5313014354155909d, (-4.440892098500627E-16d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test97"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(1916, 317);
//     int var6 = var0.nextZipf(206, 0.30593848942443524d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 201);
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test98"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(2.1739210671995393d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.453212036389512d);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test99"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     double var11 = var0.nextF(0.9672931540516151d, 1.0101518513770347d);
//     java.lang.String var13 = var0.nextHexString(59867617);
//     org.apache.commons.math3.random.RandomDataImpl var14 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var17 = var14.nextSecureLong((-1L), 1L);
//     double var20 = var14.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var22 = var14.nextHexString(10);
//     long var24 = var14.nextPoisson(3.2359311173302077d);
//     var14.reSeed(2L);
//     var14.reSeed();
//     double var29 = var14.nextChiSquare(7.617953921806563d);
//     double var31 = var14.nextExponential(1.5574077246549007d);
//     org.apache.commons.math3.distribution.NormalDistribution var35 = new org.apache.commons.math3.distribution.NormalDistribution(0.8259324122591327d, 0.2782029380240531d, 0.0d);
//     double var36 = var14.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var35);
//     double var38 = var14.nextT(0.2160727732320313d);
//     org.apache.commons.math3.random.RandomDataImpl var39 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var42 = var39.nextSecureLong((-1L), 1L);
//     double var45 = var39.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var47 = var39.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var48 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var49 = var39.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var48);
//     double var50 = var48.sample();
//     double var52 = var48.probability(7.444490968701611d);
//     double var53 = var48.getStandardDeviation();
//     double var54 = var14.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var48);
//     boolean var55 = var48.isSupportLowerBoundInclusive();
//     double var56 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.30537660450909d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "6c04c04160c48ac855f7a97418fb503d3023b3117ffeba24d60c516803be3e0c069d6a78a4ffa9ea6dd0f74e0bceadafca8a"+ "'", var8.equals("6c04c04160c48ac855f7a97418fb503d3023b3117ffeba24d60c516803be3e0c069d6a78a4ffa9ea6dd0f74e0bceadafca8a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.39250247401640465d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 7.094528828363219d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "04f5454cc3"+ "'", var22.equals("04f5454cc3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 11.090295193177663d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 2.5106043273010914d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0.4086909155105528d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0.5549305179896654d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1.4769366434721893d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var47 + "' != '" + "a4062559f3"+ "'", var47.equals("a4062559f3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 0.01641836745648252d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == (-1.4396996308704366d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == (-0.22835283920790053d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1.5302877243745072d);
// 
//   }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test100"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var14 = var0.nextWeibull(0.001908508257396575d, 1.06784626178585d);
//     long var17 = var0.nextLong(179L, 206L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.9905272347204694d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "9420d2907f"+ "'", var8.equals("9420d2907f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1992);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.3415878138914978E-161d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 179L);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test101"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(1.366367487326363d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test102"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(2.3841858E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test103"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.15729920705028488d, (java.lang.Number)(short)(-1), false);
//     java.lang.Number var5 = var4.getMax();
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var11 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MaxCountExceededException var12 = new org.apache.commons.math3.exception.MaxCountExceededException(var9, (java.lang.Number)(-1), (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.MathArithmeticException var14 = new org.apache.commons.math3.exception.MathArithmeticException(var7, (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var6, (java.lang.Object[])var11);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test104"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.distribution.NormalDistribution var1 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var1.getStandardDeviation();
    double[] var4 = var1.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    double[] var6 = var5.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var14 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var10, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var15 = var14.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var9, (java.lang.Object[])var15);
    org.apache.commons.math3.exception.MathArithmeticException var17 = new org.apache.commons.math3.exception.MathArithmeticException(var8, (java.lang.Object[])var15);
    boolean var18 = var7.equals((java.lang.Object)var15);
    org.apache.commons.math3.exception.MathInternalError var19 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test105"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)2.566440443196982d, (java.lang.Number)4.5535597409955875d, (java.lang.Number)(-0.8000034466306716d));

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test106"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.7353178427401098d, 7.007326560800911d);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test107"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(0, 17190);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 17190);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test108"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(46, (-22));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1012));

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test109"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     java.lang.Class var2 = var1.getDeclaringClass();
//     java.lang.Class var3 = var1.getDeclaringClass();
//     boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
//     java.lang.String var7 = var1.name();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
//     java.lang.Class var11 = var10.getDeclaringClass();
//     java.lang.Class var12 = var10.getDeclaringClass();
//     boolean var14 = var10.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
//     org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var16 = var15.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var17 = var15.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var18 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var20 = var19.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var18, var20);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var17, var20);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var25 = var24.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var26 = var24.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var27 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var28 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var30 = var29.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var31 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var28, var30);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var27, var30);
//     java.lang.String var33 = var30.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var34 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var26, var30);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var36 = var35.getTiesStrategy();
//     java.lang.Class var37 = var36.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var38 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var36);
//     java.lang.String var39 = var36.toString();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var40 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var26, var36);
//     org.apache.commons.math3.distribution.NormalDistribution var41 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var42 = var41.getStandardDeviation();
//     double[] var44 = var41.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var45 = new org.apache.commons.math3.util.ResizableDoubleArray(var44);
//     double[] var46 = var45.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var47 = new org.apache.commons.math3.util.ResizableDoubleArray(var46);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var48 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var52 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var53 = new org.apache.commons.math3.util.ResizableDoubleArray(var52);
//     double[] var57 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var58 = new org.apache.commons.math3.util.ResizableDoubleArray(var57);
//     double var59 = var48.mannWhitneyU(var52, var57);
//     double var60 = var40.mannWhitneyUTest(var46, var52);
//     org.apache.commons.math3.distribution.NormalDistribution var61 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var62 = var61.getStandardDeviation();
//     double[] var64 = var61.sample(1);
//     double var65 = var61.getMean();
//     double[] var67 = var61.sample(100);
//     boolean var68 = var61.isSupportLowerBoundInclusive();
//     boolean var69 = var61.isSupportUpperBoundInclusive();
//     double[] var71 = var61.sample(8899);
//     double var72 = var23.mannWhitneyUTest(var46, var71);
//     double[] var73 = var8.rank(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "AVERAGE"+ "'", var7.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "AVERAGE"+ "'", var33.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var39 + "' != '" + "AVERAGE"+ "'", var39.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 4.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 0.17971249487899976d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 0.25128227802057257d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test110"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    var4.clear();
    float var9 = var4.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.discardFrontElements(284);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.5f);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test111"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    boolean var3 = var1.equals((java.lang.Object)"ac7f8ab61330e5fa89f016091a9bf14d1dfc27b9d7edd3ce3ec344803ed848e9dde93e053930a67e0927be4be7816278403b");
    double[] var4 = var1.getElements();
    int var5 = var1.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test112"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)2.566440443196982d, (java.lang.Number)1910, true);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var8 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, (java.lang.Object[])var8);
//     org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
//     org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var8);
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test113"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(14.137624878787419d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999998951465638d);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test114"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.384186E-7f, 2097152.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2097152.5f);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test115"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-0.4275039276428256d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0d));

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test116"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-1), 2074);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test117"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(407L, 10727);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4462062475205621479L);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test118"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)241L);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test119"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.1368683E-13f, (-563));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test120"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    boolean var7 = var0.isSupportUpperBoundInclusive();
    double var8 = var0.getStandardDeviation();
    double var9 = var0.getSupportUpperBound();
    double var10 = var0.getSupportLowerBound();
    double var12 = var0.density(0.3363717774100053d);
    double var13 = var0.getNumericalMean();
    boolean var14 = var0.isSupportUpperBoundInclusive();
    double var15 = var0.getSupportLowerBound();
    double var16 = var0.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.3769994616483318d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test121"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(100.000015f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.6293945E-6f);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test122"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.29397730812946654d, (java.lang.Number)1.0076199721400823d, false);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test123"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.24494054177606187d, (-0.6974171281913673d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7391796261398474d);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test124"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(192.9088122275434d);
//     double var12 = var0.nextExponential(0.7243407758924822d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var0.nextLong(201L, 5L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15.53425050794422d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5f9aff4d8d"+ "'", var8.equals("5f9aff4d8d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 178L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.6323251825749544d);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test125"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-0.5580953333510336d), 0.14608902069952245d, 0.33765583161665175d);
    double var4 = var3.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.14608902069952245d);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test126"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double[] var6 = var0.sample(100);
//     boolean var7 = var0.isSupportLowerBoundInclusive();
//     boolean var8 = var0.isSupportUpperBoundInclusive();
//     double var11 = var0.cumulativeProbability(0.0d, 0.25587682077976953d);
//     double var12 = var0.getSupportUpperBound();
//     double[] var14 = var0.sample(11274);
//     double var15 = var0.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.10097702336242761d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.41023049431530567d));
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test127"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.6394362149555466d, (java.lang.Number)0.8988590862390544d, false);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test128"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)8941);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test129"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.addElement(0.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var6.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var6.copy();
    var10.setElement(1, (-0.8652627755109201d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test130"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(1.6601269939065664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.978373863724129d);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test131"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(1.2333864848763691d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.24753076941438146d));

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test132"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     double var11 = var0.nextF(0.6351254179184792d, 14.27900880653991d);
//     double var13 = var0.nextChiSquare(6.847746722572357d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextUniform(12639.972864705762d, 0.2835111035018974d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.0318054662936533d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "266afca9f2"+ "'", var8.equals("266afca9f2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.011284165403811748d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 11.514509726655797d);
// 
//   }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test133"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var11 = var9.sample();
//     double var13 = var9.probability(7.444490968701611d);
//     double var14 = var9.getSupportUpperBound();
//     double[] var16 = var9.sample(9694);
//     boolean var17 = var9.isSupportLowerBoundInclusive();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var9.cumulativeProbability(0.9999999999999525d, 0.1006733736677079d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.186932721521192d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "05eb76ffaf"+ "'", var8.equals("05eb76ffaf"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.8625283052508286d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.14690087982312874d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test134"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.9999999999928669d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7853981633938818d);

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test135"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
//     java.math.BigInteger var3 = null;
//     java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
//     java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
//     java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 11L);
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     java.math.BigInteger var12 = null;
//     java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
//     java.math.BigInteger var15 = null;
//     java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 0L);
//     java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, var17);
//     java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 6L);
//     org.apache.commons.math3.exception.OutOfRangeException var21 = new org.apache.commons.math3.exception.OutOfRangeException(var9, (java.lang.Number)5.363952139253263d, (java.lang.Number)14.087081017797523d, (java.lang.Number)var20);
//     java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, var20);
//     java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 1999);
//     java.math.BigInteger var25 = null;
//     java.math.BigInteger var27 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, 0L);
//     java.math.BigInteger var28 = null;
//     java.math.BigInteger var30 = org.apache.commons.math3.util.ArithmeticUtils.pow(var28, 0L);
//     java.math.BigInteger var31 = org.apache.commons.math3.util.ArithmeticUtils.pow(var27, var30);
//     java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var27, 11L);
//     java.math.BigInteger var34 = null;
//     java.math.BigInteger var36 = org.apache.commons.math3.util.ArithmeticUtils.pow(var34, 0L);
//     java.math.BigInteger var37 = null;
//     java.math.BigInteger var39 = org.apache.commons.math3.util.ArithmeticUtils.pow(var37, 0L);
//     java.math.BigInteger var40 = org.apache.commons.math3.util.ArithmeticUtils.pow(var36, var39);
//     java.math.BigInteger var42 = org.apache.commons.math3.util.ArithmeticUtils.pow(var40, 1949);
//     java.math.BigInteger var43 = org.apache.commons.math3.util.ArithmeticUtils.pow(var33, var42);
//     java.math.BigInteger var45 = org.apache.commons.math3.util.ArithmeticUtils.pow(var33, 8904);
//     java.math.BigInteger var47 = org.apache.commons.math3.util.ArithmeticUtils.pow(var45, 183L);
//     java.math.BigInteger var48 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, var45);
//     java.math.BigInteger var49 = null;
//     java.math.BigInteger var50 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, var49);
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test136"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo((-1151L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test137"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    double[] var6 = var4.getInternalValues();
    org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var8 = var7.getStandardDeviation();
    double[] var10 = var7.sample(1);
    double var11 = var7.getMean();
    double[] var13 = var7.sample(100);
    var4.addElements(var13);
    var4.discardMostRecentElements(44);
    float var17 = var4.getContractionCriteria();
    float var18 = var4.getExpansionFactor();
    float var19 = var4.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.5f);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test138"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-0.026670602226619104d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.030087417819711613d));

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test139"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-536870912L), (-6266588889437241349L));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test140"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(5.366170923935078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.226035018935781E-14d);

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test141"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     int[] var9 = var0.nextPermutation(11213, 1203);
//     double var12 = var0.nextBeta(0.0014176073333978397d, 20.43363786990329d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1.3327325860679062d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.4320032355749123E-9d);
// 
//   }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test142"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(192.9088122275434d);
//     double var12 = var0.nextExponential(0.7243407758924822d);
//     double var15 = var0.nextCauchy(5.778410523454782E-4d, 0.21635711892824916d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.727126176695558d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5cec423dd9"+ "'", var8.equals("5cec423dd9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 202L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5816531976611887d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.17571954783166566d);
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test143"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(704L, (-202L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 71104L);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test144"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var1 = null;
    java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    java.math.BigInteger var4 = null;
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0L);
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, var6);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 11L);
    java.math.BigInteger var10 = null;
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
    java.math.BigInteger var13 = null;
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 0L);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, var15);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 1949);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, var18);
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 8904);
    org.apache.commons.math3.exception.NumberIsTooLargeException var24 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)var9, (java.lang.Number)1.2821293047459659E-78d, true);
    java.lang.Number var25 = var24.getMax();
    org.apache.commons.math3.exception.util.ExceptionContext var26 = var24.getContext();
    boolean var27 = var24.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + 1.2821293047459659E-78d+ "'", var25.equals(1.2821293047459659E-78d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test145"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var13.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    java.lang.Class var18 = var17.getDeclaringClass();
    int var19 = var17.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var20.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var23 = var22.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = var22.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var25 = var22.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var26 = var22.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var28 = var27.getTiesStrategy();
    boolean var30 = var28.equals((java.lang.Object)Double.POSITIVE_INFINITY);
    boolean var32 = var28.equals((java.lang.Object)(-0.4255538433808183d));
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var33 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var26, var28);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var34 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var21, var28);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var35 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var28);
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var37 = var36.getTiesStrategy();
    java.lang.Class var38 = var37.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var37);
    org.apache.commons.math3.stat.ranking.TiesStrategy var40 = var39.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var41 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var40);
    org.apache.commons.math3.distribution.NormalDistribution var42 = new org.apache.commons.math3.distribution.NormalDistribution();
    var42.reseedRandomGenerator(2L);
    double[] var46 = var42.sample(100000);
    double[] var47 = var41.rank(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test146"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-1342601562L), (-5071615437313169176L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test147"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(11474, 90);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test148"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.0f, 247);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test149"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)50761728L, (java.lang.Number)(-2.580151816032994d), (java.lang.Number)1.780425831130733d);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test150"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(5.551536404978201d, 323);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.48640783238113E97d);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test151"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double[] var3 = var0.sample(10);
    double var4 = var0.getStandardDeviation();
    double var6 = var0.density(2.345330933436551d);
    double var7 = var0.getSupportLowerBound();
    double var8 = var0.getSupportLowerBound();
    double[] var10 = var0.sample(17271);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.025496167636629936d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test152"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(2.478622967831918d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9995439107645442d);

  }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test153"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getSupportUpperBound();
//     double[] var3 = var0.sample(10);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     double var6 = var4.addElementRolling(0.15264401491200186d);
//     float var7 = var4.getContractionCriteria();
//     double[] var8 = var4.getInternalValues();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.setExpansionMode(11297);
//       fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
//     } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5162511234866948d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test154"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.1368683E-13f, 2.5000005f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1368683E-13f);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test155"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var14 = var0.nextGamma(0.15861286098539223d, 23.79178096943456d);
//     double var16 = var0.nextChiSquare(3.730894643928354d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var0.nextF(11.179981975584864d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.324933100389016d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "3d3c13156e"+ "'", var8.equals("3d3c13156e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.8055713803594106E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 10.225064391876495d);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test156"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-388134638));

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test157"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(18.697844268442672d, 0.01641836745648252d, 0.0d);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test158"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(3.3914683902950307d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.391468390295031d);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test159"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-0.1886395846498931d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0178452709308328d);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test160"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
    java.lang.Object var17 = null;
    boolean var18 = var4.equals(var17);
    int var19 = var4.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setExpansionFactor(1.1368685E-13f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test161"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var13 = var0.nextT(5.867156662812015d);
//     double var16 = var0.nextGamma((-1.5707963267948966d), 1.5318133596204784d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var19 = var0.nextPermutation((-297256655), 1260);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12.655310311801378d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "c83fbf96d6"+ "'", var8.equals("c83fbf96d6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.757576988695372d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 4.190048786502251d);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test162"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)8.660004026414073d, (java.lang.Number)17.042216286603484d, true);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test163"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    float var9 = var6.getContractionCriteria();
    float var10 = var6.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.5f);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test164"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(20, 91530199783L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test165"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     double var14 = var0.nextChiSquare(4.950886585270677E-4d);
//     java.lang.String var16 = var0.nextSecureHexString(1868);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var0.nextF(0.9993038846818808d, (-1.0536078524937216d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.56165865283488d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "b5d638f61a"+ "'", var8.equals("b5d638f61a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.4328197799036929E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "ab0de6d422557617e092757bf26d37a02d09496a81351a06743ba35845d2f0cefdb940d872857cc975b2a47a10000e5cdc5f04d2cf8e3497243814f86c007571f2d6cf38ce44fc0ef3566f3d6f0b511833a3bdb12a06aa1e9b705b8e747f1076f10bb51a5554dc997224932ca9042e384f35817cc191c672bc97a1d5e81ea4271fd698f8eaa0b3694c286d580855a0369be81f49920fe41c2690cfb8b4e204361a3f354fb45903e3932c00650fb8352cbe6af2090fa7c3a743770826eb7dcccbbf63e0436e3389eaccc46c55570f4f246a9246409d920653d30fe0d77d99b94032a833769e1b45f9cc39441c8745b44754aa04df3074b351343bfd279dc85bbaef82e405a47cf6ee91a20e7e81d47e222af4a5c402340601ee702255f083174ecd5255ac1bcdea9d6f427bb0f9944bb1c803b8dea91a27348a719b415a14e5f1daee742e0e0d5eb7260a91ef9201be0c5608de105a1df6a73098612aa3c45b408b230e79015f1d2d2a9e4623d3771f26477c3f4313846c97344a4edadc482487217dec6ec4c223b28f3257f84d3d120d52becb2d95e2d9bd46cfa4efbda2226775d2761caaf7209751cd9d85a8a8229954fafad13416f44c4a255ffe47d8226278ae7464ce217e9be78ff20f068404ec9c508f3b0a75bb74d27dabf8e25bc20ca984b54529c3b6ccc7d895e584ac6c87a9d38ee20bb57ec91d6774cf3d19b6dfe7a4d0b677f483692f660a142e39839b6e7a133c31900cb24daa6affea34445b5d1bd6542bcd1efa10985c0a68fa7bfd758c41b630cb6fdac25b9f24fde55c82091ec98a49039a1e1823dd396ae6cf02e1dd075e4d4b8b7dbd9c73e3be586fe5ea16a83dfdc8f6aa972aaead58227068a128441351f2f81ac39f26e7c1abe29551ca66c6d266641fae49e3d3e7d5e91e9b60cd37e892e21337372313a3af429f24438322a003b39168df811c12669b478cf51794b7ad8fdcfd9f4dfdc225df9938b9f6fa3c8bf4f0b2f6ee82256272e88aedb7820b6877a19b407471a21e023b5c656d186f4b127e0b0f991af056c0e0ae2e0faa4cc899384901cfd6f5f1a36c7c90aaf8fa5b4f76f618c81f54f130289f555d22757277761732ecddca02d5e58dedc22c6471599a874380243a751edbba7ac70a622a0c23bacab430e317eae900bb5cda78523c8866b8690f08558401f76bd9bd491ae00c13a09d00667b00fbbba2a8ea080ec9b0acc3170de64e724ab658b4ad336ad985fc02f8abb077be3554f344ed6be888639b080eba716956dd707d943a867740234615007eaf69035f0621eb3e6ef6"+ "'", var16.equals("ab0de6d422557617e092757bf26d37a02d09496a81351a06743ba35845d2f0cefdb940d872857cc975b2a47a10000e5cdc5f04d2cf8e3497243814f86c007571f2d6cf38ce44fc0ef3566f3d6f0b511833a3bdb12a06aa1e9b705b8e747f1076f10bb51a5554dc997224932ca9042e384f35817cc191c672bc97a1d5e81ea4271fd698f8eaa0b3694c286d580855a0369be81f49920fe41c2690cfb8b4e204361a3f354fb45903e3932c00650fb8352cbe6af2090fa7c3a743770826eb7dcccbbf63e0436e3389eaccc46c55570f4f246a9246409d920653d30fe0d77d99b94032a833769e1b45f9cc39441c8745b44754aa04df3074b351343bfd279dc85bbaef82e405a47cf6ee91a20e7e81d47e222af4a5c402340601ee702255f083174ecd5255ac1bcdea9d6f427bb0f9944bb1c803b8dea91a27348a719b415a14e5f1daee742e0e0d5eb7260a91ef9201be0c5608de105a1df6a73098612aa3c45b408b230e79015f1d2d2a9e4623d3771f26477c3f4313846c97344a4edadc482487217dec6ec4c223b28f3257f84d3d120d52becb2d95e2d9bd46cfa4efbda2226775d2761caaf7209751cd9d85a8a8229954fafad13416f44c4a255ffe47d8226278ae7464ce217e9be78ff20f068404ec9c508f3b0a75bb74d27dabf8e25bc20ca984b54529c3b6ccc7d895e584ac6c87a9d38ee20bb57ec91d6774cf3d19b6dfe7a4d0b677f483692f660a142e39839b6e7a133c31900cb24daa6affea34445b5d1bd6542bcd1efa10985c0a68fa7bfd758c41b630cb6fdac25b9f24fde55c82091ec98a49039a1e1823dd396ae6cf02e1dd075e4d4b8b7dbd9c73e3be586fe5ea16a83dfdc8f6aa972aaead58227068a128441351f2f81ac39f26e7c1abe29551ca66c6d266641fae49e3d3e7d5e91e9b60cd37e892e21337372313a3af429f24438322a003b39168df811c12669b478cf51794b7ad8fdcfd9f4dfdc225df9938b9f6fa3c8bf4f0b2f6ee82256272e88aedb7820b6877a19b407471a21e023b5c656d186f4b127e0b0f991af056c0e0ae2e0faa4cc899384901cfd6f5f1a36c7c90aaf8fa5b4f76f618c81f54f130289f555d22757277761732ecddca02d5e58dedc22c6471599a874380243a751edbba7ac70a622a0c23bacab430e317eae900bb5cda78523c8866b8690f08558401f76bd9bd491ae00c13a09d00667b00fbbba2a8ea080ec9b0acc3170de64e724ab658b4ad336ad985fc02f8abb077be3554f344ed6be888639b080eba716956dd707d943a867740234615007eaf69035f0621eb3e6ef6"));
// 
//   }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test166"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
//     java.lang.Class var5 = var4.getDeclaringClass();
//     java.lang.Class var6 = var4.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
//     java.lang.String var8 = var4.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getStandardDeviation();
//     double[] var13 = var10.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var19 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
//     double[] var24 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
//     double var26 = var15.mannWhitneyU(var19, var24);
//     double var27 = var9.mannWhitneyUTest(var13, var19);
//     org.apache.commons.math3.distribution.NormalDistribution var28 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var29 = var28.getStandardDeviation();
//     double[] var31 = var28.sample(1);
//     double var32 = var28.getMean();
//     double[] var34 = var28.sample(100);
//     boolean var35 = var28.isSupportLowerBoundInclusive();
//     boolean var36 = var28.isSupportUpperBoundInclusive();
//     double var39 = var28.cumulativeProbability(0.0d, 0.25587682077976953d);
//     double var40 = var28.getSupportUpperBound();
//     double[] var42 = var28.sample(11274);
//     org.apache.commons.math3.distribution.NormalDistribution var46 = new org.apache.commons.math3.distribution.NormalDistribution((-4.440892098500626E-16d), 1.1102230246251565E-16d, 0.9999494957997512d);
//     double[] var48 = var46.sample(1972);
//     double var49 = var9.mannWhitneyUTest(var42, var48);
//     org.apache.commons.math3.util.ResizableDoubleArray var50 = new org.apache.commons.math3.util.ResizableDoubleArray(var42);
//     var50.contract();
//     var50.discardMostRecentElements(11007);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 4.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.17971249487899976d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0.10097702336242761d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 0.9297861630991258d);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test167"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    java.lang.String var6 = var4.toString();
    java.lang.Class var7 = var4.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var9 = java.lang.Enum.<java.lang.Enum>valueOf(var7, "08f3674814");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "MAXIMAL"+ "'", var6.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test168"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(1943, 284);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1659);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test169"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(20901888L, 26L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 543449088L);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test170"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(4L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test171"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(1822, 1919);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test172"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.4000591571530008d, (java.lang.Number)8, (java.lang.Number)(-2.225482993439564d));
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2.7589241763811208d, (java.lang.Number)1.1752011936438014d, true);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var9 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var8, var9);
    var3.addSuppressed((java.lang.Throwable)var7);
    java.lang.Number var12 = var7.getArgument();
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var7);
    org.apache.commons.math3.exception.util.ExceptionContext var14 = var13.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 2.7589241763811208d+ "'", var12.equals(2.7589241763811208d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test173"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)456.0d, (java.lang.Number)9.536744E-7f, false);
    java.lang.Number var4 = var3.getMax();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 9.536744E-7f+ "'", var4.equals(9.536744E-7f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test174"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(83847, 56L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 102681409);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test175"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1630.3898264310162d, 7.042014262199385d, 0.31871003612337145d, 1907);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test176"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    java.lang.Class var6 = var4.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    java.lang.String var8 = var4.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var10);
    org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var13 = var12.getStandardDeviation();
    double[] var15 = var12.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    org.apache.commons.math3.exception.util.Localizable var17 = null;
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    org.apache.commons.math3.exception.util.Localizable var19 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var20 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var21 = new org.apache.commons.math3.exception.NullArgumentException(var19, (java.lang.Object[])var20);
    org.apache.commons.math3.exception.MathInternalError var22 = new org.apache.commons.math3.exception.MathInternalError(var18, (java.lang.Object[])var20);
    org.apache.commons.math3.exception.NullArgumentException var23 = new org.apache.commons.math3.exception.NullArgumentException(var17, (java.lang.Object[])var20);
    boolean var24 = var16.equals((java.lang.Object)var17);
    var16.addElement(20.696514663540924d);
    double var28 = var16.substituteMostRecentElement((-1.84544373783414d));
    java.lang.Object var29 = null;
    boolean var30 = var16.equals(var29);
    var16.setElement(100, 0.0d);
    double[] var34 = var16.getInternalValues();
    float var35 = var16.getExpansionFactor();
    org.apache.commons.math3.exception.util.Localizable var36 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var40 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var36, (java.lang.Number)9.536743E-7f, (java.lang.Number)(-0.4255538433808183d), false);
    boolean var41 = var16.equals((java.lang.Object)(-0.4255538433808183d));
    org.apache.commons.math3.distribution.NormalDistribution var42 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var43 = var42.getStandardDeviation();
    double[] var45 = var42.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var46 = new org.apache.commons.math3.util.ResizableDoubleArray(var45);
    var46.contract();
    double[] var48 = var46.getInternalValues();
    org.apache.commons.math3.distribution.NormalDistribution var49 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var50 = var49.getStandardDeviation();
    double[] var52 = var49.sample(1);
    double var53 = var49.getMean();
    double[] var55 = var49.sample(100);
    var46.addElements(var55);
    var16.addElements(var55);
    double[] var58 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var59 = var11.mannWhitneyUTest(var55, var58);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test177"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(2.5167660033583883E7d, 4.463324522706254d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0773661625490005E33d);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test178"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test179"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-0.21714707451774387d), 0.9993038846818808d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.21714707451774387d));

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test180"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(1.0817096863357845d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7331895206698487d);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test181"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-2.4631199234029544d), 3.226035018935781E-14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8.444720897707411E-15d);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test182"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)9.489762288736276d);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test183"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1.0974513990119676d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.45586597778927573d);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test184"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-744.4400719213812d), 0.40231460697410537d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-744.4400719213811d));

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test185"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    java.lang.String var4 = var2.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "MAXIMAL"+ "'", var4.equals("MAXIMAL"));

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test186"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.02629215190910916d, (java.lang.Number)0.5879680852503826d, (java.lang.Number)1856);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test187"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.6477290750934385d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9111957152166736d);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test188"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var2 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var3 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var2);
//     org.apache.commons.math3.exception.MathArithmeticException var4 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var2);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var10 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var9, (java.lang.Object[])var10);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var8, (java.lang.Object[])var10);
//     org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var7, (java.lang.Object[])var10);
//     org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var10);
//     org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var10);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test189"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    boolean var8 = var6.equals((java.lang.Object)Double.POSITIVE_INFINITY);
    boolean var10 = var6.equals((java.lang.Object)(-0.4255538433808183d));
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var13.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    java.lang.Class var18 = var17.getDeclaringClass();
    int var19 = var17.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var17);
    org.apache.commons.math3.random.RandomGenerator var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var21);
    org.apache.commons.math3.random.RandomGenerator var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var23);
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var25.getTiesStrategy();
    java.lang.Class var27 = var26.getDeclaringClass();
    java.lang.String var28 = var26.toString();
    java.lang.String var29 = var26.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var26);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var31 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var26);
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var33 = var32.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var34 = var32.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var36 = var35.getTiesStrategy();
    java.lang.Class var37 = var36.getDeclaringClass();
    int var38 = var36.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var34, var36);
    org.apache.commons.math3.random.RandomGenerator var40 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var41 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var34, var40);
    org.apache.commons.math3.random.RandomGenerator var42 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var43 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var34, var42);
    org.apache.commons.math3.stat.ranking.NaturalRanking var44 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var34);
    org.apache.commons.math3.stat.ranking.NaturalRanking var45 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var46 = var45.getTiesStrategy();
    java.lang.Class var47 = var46.getDeclaringClass();
    java.lang.Class var48 = var46.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var49 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var34, var46);
    org.apache.commons.math3.util.ResizableDoubleArray var50 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var50.contract();
    org.apache.commons.math3.distribution.NormalDistribution var52 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var53 = var52.getStandardDeviation();
    double[] var55 = var52.sample(1);
    double var57 = var52.cumulativeProbability(0.0d);
    double var58 = var52.getSupportUpperBound();
    boolean var59 = var52.isSupportUpperBoundInclusive();
    var52.reseedRandomGenerator((-16L));
    double[] var63 = var52.sample(2297);
    var50.addElements(var63);
    double[] var65 = var49.rank(var63);
    org.apache.commons.math3.distribution.NormalDistribution var66 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var67 = var66.getStandardDeviation();
    double[] var69 = var66.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var70 = new org.apache.commons.math3.util.ResizableDoubleArray(var69);
    var70.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var72 = var70.copy();
    float var73 = var70.getContractionCriteria();
    var70.clear();
    double[] var75 = var70.getInternalValues();
    double var76 = var31.mannWhitneyU(var65, var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "AVERAGE"+ "'", var28.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "AVERAGE"+ "'", var29.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 2297.0d);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test190"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(1871, 1659);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test191"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform((-0.9986814996153957d), 30.14110668368703d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var17 = var0.nextPermutation(1954, 3483820);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12.497519513904164d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "81d9c50541"+ "'", var8.equals("81d9c50541"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.5245721526573628d);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test192"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(1880, 1625);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test193"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(14.57970528643039d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2147264.547242696d);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test194"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(11274, Float.POSITIVE_INFINITY, 99.999985f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test195"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var4 = var0.getMean();
    double[] var6 = var0.sample(100);
    boolean var7 = var0.isSupportLowerBoundInclusive();
    boolean var8 = var0.isSupportUpperBoundInclusive();
    double var11 = var0.cumulativeProbability(0.0d, 0.25587682077976953d);
    double var12 = var0.getSupportUpperBound();
    double[] var14 = var0.sample(11274);
    var0.reseedRandomGenerator(35041L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.10097702336242761d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test196"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(4736150592170749123L, 2184L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test197"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1942, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test198"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, var2, false);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test199"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(1.2075656224493652d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9347538475773042d);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test200"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var5 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var3, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test201"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var11 = var9.getStandardDeviation();
//     double var12 = var9.sample();
//     double var14 = var9.probability(0.9831965750110166d);
//     double var16 = var9.probability((-0.809212267196822d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 31.496042620408943d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "08256848fe"+ "'", var8.equals("08256848fe"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.2888695411772784d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.09674016192719369d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test202"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("03714bc7c5");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test203"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(1.503230239462078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9321323209944647d);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test204"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    java.lang.Class var6 = var4.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    java.lang.String var8 = var4.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    int var10 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var12, var14);
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var14);
    java.lang.String var17 = var14.name();
    java.lang.String var18 = var14.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var14);
    int var20 = var14.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "AVERAGE"+ "'", var17.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "AVERAGE"+ "'", var18.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 3);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test205"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(2.7589241763811208d, 0.8957380763521041d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.08704338813520823d);

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test206"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextWeibull(7.769493748166378d, 1.2185657441986304d);
//     int var9 = var0.nextInt((-1), 6);
//     long var12 = var0.nextLong(193L, 2184L);
//     long var14 = var0.nextPoisson(0.998614057997266d);
//     var0.reSeedSecure(12L);
//     double var18 = var0.nextChiSquare(0.11537426317526311d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.3113657993854149d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1440L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 3.681045350868614E-4d);
// 
//   }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test207"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var4.addElement((-0.43408597923864894d));
//     double var10 = var4.getElement(0);
//     double[] var11 = var4.getElements();
//     var4.addElement(21.0d);
//     var4.setNumElements(3);
//     org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var17 = var16.getStandardDeviation();
//     double[] var19 = var16.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
//     var20.contract();
//     int var22 = var20.getNumElements();
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var20);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var24 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var28 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var28);
//     org.apache.commons.math3.distribution.NormalDistribution var30 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var31 = var30.getSupportUpperBound();
//     double[] var33 = var30.sample(10);
//     double var34 = var24.mannWhitneyU(var28, var33);
//     var4.addElements(var28);
//     var4.discardMostRecentElements(0);
//     int var38 = var4.start();
//     double var40 = var4.substituteMostRecentElement((-0.04333104391869323d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5642547213896921d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 30.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == (-1.0d));
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test208"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var4 = var1.toString();
    java.lang.String var5 = var1.toString();
    boolean var7 = var1.equals((java.lang.Object)0.6767278567306203d);
    java.lang.String var8 = var1.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "AVERAGE"+ "'", var5.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test209"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.024169689715314146d);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test210"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     var4.contract();
//     double[] var6 = var4.getInternalValues();
//     org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var8 = var7.getStandardDeviation();
//     double[] var10 = var7.sample(1);
//     double var11 = var7.getMean();
//     double[] var13 = var7.sample(100);
//     var4.addElements(var13);
//     var4.setElement(1946, 0.8273175524905445d);
//     double var19 = var4.addElementRolling(0.7615941559557649d);
//     var4.setElement(1891, (-0.18588257771827132d));
//     double var24 = var4.substituteMostRecentElement((-0.33143925087381365d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.6372965055799583d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.7615941559557649d);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test211"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(55.77085302124092d, 137);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.716652990089027E42d);

  }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test212"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var13 = var12.getStandardDeviation();
//     double[] var15 = var12.sample(1);
//     double var16 = var12.getMean();
//     double[] var18 = var12.sample(100);
//     boolean var19 = var12.isSupportLowerBoundInclusive();
//     boolean var20 = var12.isSupportUpperBoundInclusive();
//     double[] var22 = var12.sample(8899);
//     double var23 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     java.lang.String var25 = var0.nextHexString(10775);
//     var0.reSeedSecure(12L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 18.724480683975337d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "3c7354ca74"+ "'", var8.equals("3c7354ca74"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1865);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.6138560218807408d);
// 
//   }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test213"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     var0.reSeedSecure();
//     double var10 = var0.nextGamma(1.257156203792693d, (-1.765071985168704d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("4117dd8e78", "a1e672253b");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 21.699971372839446d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.6542186171170703d));
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test214"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(8.854558633913316d, 3.1173466159040992d);
    boolean var3 = var2.isSupportConnected();
    double var4 = var2.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3.1173466159040992d);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test215"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    var4.clear();
    int var9 = var4.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(2187);
    int var12 = var11.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var11.copy();
    double var15 = var11.addElementRolling(6.316812892815939d);
    boolean var16 = var4.equals((java.lang.Object)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test216"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(8.125467547535871d);
//     double var5 = var0.nextGamma((-0.62278342103023d), 0.49413191900484393d);
//     double var8 = var0.nextCauchy(16.612604373395136d, 2.054051234375098d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var10 = var0.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 6.481397845115592d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9519395550667624d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 14.705271532493292d);
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test217"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(1911, 77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1834);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test218"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(192.9088122275434d);
//     double var12 = var0.nextExponential(0.7243407758924822d);
//     org.apache.commons.math3.distribution.NormalDistribution var13 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var13.reseedRandomGenerator(2L);
//     boolean var16 = var13.isSupportConnected();
//     boolean var17 = var13.isSupportLowerBoundInclusive();
//     double var18 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var13);
//     org.apache.commons.math3.distribution.IntegerDistribution var19 = null;
//     int var20 = var0.nextInversionDeviate(var19);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test219"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.01329154278510984d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.557504392620027d);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test220"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(4.810477380965351d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.881784197001252E-16d);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test221"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.0d, 1.0282304518414567d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8540917975553219d);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test222"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.105055920445338d, (java.lang.Number)0.7353178427401098d, (java.lang.Number)12569.816320050882d);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test223"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.exception.OutOfRangeException var17 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.15512025679417774d, (java.lang.Number)1.2471705263294632d, (java.lang.Number)0.0843874063990762d);
    boolean var18 = var2.equals((java.lang.Object)1.2471705263294632d);
    java.lang.Class var19 = var2.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var21 = java.lang.Enum.<java.lang.Enum>valueOf(var19, "f3961a3bb1");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test224"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double[] var6 = var0.sample(100);
//     double var7 = var0.sample();
//     double var8 = var0.sample();
//     double var10 = var0.probability((-0.3722334692039834d));
//     double var12 = var0.probability(0.7681252299306625d);
//     boolean var13 = var0.isSupportConnected();
//     double var15 = var0.density(8.854558633913314d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.04047022440392583d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.2827587817129664d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 3.765907394252531E-18d);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test225"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.09549600483812275d, (java.lang.Number)1.2578273612086598E-16d, true);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.09549600483812275d+ "'", var4.equals(0.09549600483812275d));

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test226"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-22), 655360.06f, 655360.06f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test227"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double var3 = var0.inverseCumulativeProbability(0.9999999999928669d);
    boolean var4 = var0.isSupportConnected();
    boolean var5 = var0.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 6.755176609774487d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test228"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-1953380655), 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test229"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(1.9960661999607503E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.3087224502121107E-24d);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test230"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(21428512432590984L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test231"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(32.513321074988696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test232"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.discardMostRecentElements(1);
    int var15 = var4.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = var4.copy();
    double var18 = var4.addElementRolling(2.478622967831918d);
    double var20 = var4.addElementRolling(13.72049706506842d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test233"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(2058820555291694441L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test234"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(3);
    java.lang.Object var2 = null;
    boolean var3 = var1.equals(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setContractionCriteria(2.3841858E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test235"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.004259538447620046d, (java.lang.Number)(-0.18719238578460362d), false);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test236"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(22.43277156890168d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.110522906163903d);

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test237"); }
// 
// 
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var4 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
//     double[] var9 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
//     double var11 = var0.mannWhitneyU(var4, var9);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
//     java.lang.Class var14 = var13.getDeclaringClass();
//     java.lang.Class var15 = var13.getDeclaringClass();
//     boolean var17 = var13.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
//     org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
//     org.apache.commons.math3.distribution.NormalDistribution var22 = new org.apache.commons.math3.distribution.NormalDistribution((-4.440892098500626E-16d), 1.1102230246251565E-16d, 0.9999494957997512d);
//     double[] var24 = var22.sample(1972);
//     double[] var25 = var18.rank(var24);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var27 = var26.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var28 = var26.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var30 = var29.getTiesStrategy();
//     java.lang.Class var31 = var30.getDeclaringClass();
//     int var32 = var30.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var28, var30);
//     org.apache.commons.math3.random.RandomGenerator var34 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var28, var34);
//     org.apache.commons.math3.random.RandomGenerator var36 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var28, var36);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var38 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var39 = var38.getTiesStrategy();
//     java.lang.Class var40 = var39.getDeclaringClass();
//     java.lang.String var41 = var39.toString();
//     java.lang.String var42 = var39.toString();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var43 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var28, var39);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var44 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var48 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var49 = new org.apache.commons.math3.util.ResizableDoubleArray(var48);
//     org.apache.commons.math3.distribution.NormalDistribution var50 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var51 = var50.getSupportUpperBound();
//     double[] var53 = var50.sample(10);
//     double var54 = var44.mannWhitneyU(var48, var53);
//     double[] var55 = var43.rank(var48);
//     double var56 = var0.mannWhitneyUTest(var24, var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var41 + "' != '" + "AVERAGE"+ "'", var41.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var42 + "' != '" + "AVERAGE"+ "'", var42.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 27.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 0.0027268467971602872d);
// 
//   }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test238"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     var0.reSeed();
//     double var15 = var0.nextChiSquare(7.617953921806563d);
//     double var17 = var0.nextExponential(1.5574077246549007d);
//     double var19 = var0.nextChiSquare(0.16043285994536435d);
//     var0.reSeed();
//     double var23 = var0.nextGamma(12.0d, 0.8273572477024794d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var25 = var24.getStandardDeviation();
//     double[] var27 = var24.sample(1);
//     double var28 = var24.sample();
//     double var29 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.627022327184005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "df3c943f70"+ "'", var8.equals("df3c943f70"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 4.631804672626639d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.9575728656922886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 5.786007967375775E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 14.425382504754484d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.945176412932697d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.28605363846227194d);
// 
//   }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test239"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     double var16 = var0.nextCauchy(0.0d, 295.99559901809107d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.09141892935213795d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "059dc7baae"+ "'", var8.equals("059dc7baae"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.006291551283673002d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 10398);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 31.026048518377678d);
// 
//   }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test240"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     var4.contract();
//     double[] var6 = var4.getInternalValues();
//     org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var8 = var7.getStandardDeviation();
//     double[] var10 = var7.sample(1);
//     double var11 = var7.getMean();
//     double[] var13 = var7.sample(100);
//     var4.addElements(var13);
//     var4.discardMostRecentElements(44);
//     float var17 = var4.getContractionCriteria();
//     float var18 = var4.getExpansionFactor();
//     double var20 = var4.addElementRolling(0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.11930148183271876d);
// 
//   }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test241"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(8.854558633913316d, 3.1173466159040992d);
//     double var3 = var2.sample();
//     double var5 = var2.inverseCumulativeProbability(0.16535574048640247d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var2.inverseCumulativeProbability(1.527066384736393d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 16.634484082977178d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5.822372363395199d);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test242"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NoDataException var3 = new org.apache.commons.math3.exception.NoDataException();
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test243"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    var0.reseedRandomGenerator(2L);
    boolean var3 = var0.isSupportConnected();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.inverseCumulativeProbability((-0.8961189234469322d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test244"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(9813, (-1032474271));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1032474271));

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test245"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     java.lang.String var13 = var0.nextHexString(10);
//     var0.reSeedSecure();
//     double var17 = var0.nextGaussian(7.042014262199385d, 1.179103839756096d);
//     int var20 = var0.nextInt(0, 6);
//     long var22 = var0.nextPoisson(0.6289789283637811d);
//     var0.reSeed(1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.688623367195378d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "6e5c54e0ac"+ "'", var8.equals("6e5c54e0ac"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "330135620e"+ "'", var13.equals("330135620e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 8.801864414268454d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1L);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test246"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(20, 55);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test247"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(3.1564944652919875d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test248"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double[] var6 = var0.sample(100);
//     double var7 = var0.sample();
//     double var8 = var0.sample();
//     double var9 = var0.getStandardDeviation();
//     double var10 = var0.sample();
//     double var11 = var0.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.249201904176664d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.2588482372712888d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.21111233557551398d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1.5310369359524174d));
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test249"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.09256901763469272d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test250"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("04df319186");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test251"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     var4.contract();
//     double[] var6 = var4.getInternalValues();
//     org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var8 = var7.getStandardDeviation();
//     double[] var10 = var7.sample(1);
//     double var11 = var7.getMean();
//     double[] var13 = var7.sample(100);
//     var4.addElements(var13);
//     var4.setElement(36, 0.38829865251165124d);
//     double var19 = var4.substituteMostRecentElement(1.527066384736393d);
//     double var21 = var4.substituteMostRecentElement(1.0922887042139031d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.16444495691521632d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.527066384736393d);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test252"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 832L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test253"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    int var6 = var4.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test254"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var4.addElement((-0.43408597923864894d));
//     double var10 = var4.getElement(0);
//     var4.clear();
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var13 = var12.getStandardDeviation();
//     double[] var15 = var12.sample(1);
//     double var16 = var12.getMean();
//     double[] var18 = var12.sample(100);
//     var4.addElements(var18);
//     org.apache.commons.math3.exception.util.Localizable var20 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var24 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var20, (java.lang.Number)2.5517620356803065E-188d, (java.lang.Number)0.010100839201864612d, true);
//     boolean var25 = var4.equals((java.lang.Object)var20);
//     double[] var26 = var4.getElements();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.1212133984141624d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test255"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var8, var11);
    java.lang.String var15 = var8.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "MAXIMAL"+ "'", var15.equals("MAXIMAL"));

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test256"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.3841866E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-22));

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test257"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.discardMostRecentElements(1);
    var4.setElement(9694, 0.01255108966724917d);
    double[] var18 = var4.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test258"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(5.1870964420955135d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6461740882358429d);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test259"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.1368684E-13f, (java.lang.Number)0.0f, (java.lang.Number)(short)(-1));
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test260"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var4 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var2, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test261"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(3607);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test262"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(7.996399943030428d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.996399943030428d);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test263"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var2, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var9.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test264"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     var0.reSeed(14L);
//     double var14 = var0.nextExponential(0.9999997887160175d);
//     double var17 = var0.nextBeta(4.0434293412271454E-4d, 0.17971249487899976d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var0.nextSecureInt(1859, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.53996233109681d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "a11e39690c"+ "'", var8.equals("a11e39690c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.13894921237620494d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.3844973909690124d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test265"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var6);
    java.lang.String var9 = var6.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var10 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var12.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    java.lang.Class var17 = var16.getDeclaringClass();
    java.lang.Class var18 = var16.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    java.lang.String var20 = var16.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var14, var16);
    boolean var23 = var16.equals((java.lang.Object)4.950886585270677E-4d);
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "AVERAGE"+ "'", var9.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test266"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.003547845623385577d, 0.6040591714375757d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0016026808428791783d);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test267"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(2.0134882573780497d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 115.36437924691309d);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test268"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(784, 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 268435456);

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test269"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var13 = var0.nextT(5.867156662812015d);
//     double var16 = var0.nextGamma(0.13558023874553457d, 0.010050505059049992d);
//     double var19 = var0.nextGamma(0.6240600968487551d, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var0.nextUniform(0.0d, 0.0d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.8213634502097154d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f640ac8ec0"+ "'", var8.equals("f640ac8ec0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.0687681256294912d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.002930418728145074d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.0d);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test270"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.7253353445699519d), 9.717527268210787E-6d);
    double var3 = var2.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.7253353445699519d));

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test271"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, 9.536743E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test272"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 0.017847631327128872d, (-0.9626066447946894d));

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test273"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(2106, 100.00001f, 2.3841864E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test274"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var3);
    java.lang.String var6 = var3.name();
    java.lang.String var7 = var3.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    java.lang.Class var9 = var3.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var11 = java.lang.Enum.<java.lang.Enum>valueOf(var9, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "AVERAGE"+ "'", var7.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test275"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     int[] var9 = var0.nextPermutation(11213, 1203);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextChiSquare((-2.0166116874290902d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-19.946309976618636d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test276"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.09401821487395612d, 0.9987785505199035d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.09385662285674329d);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test277"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs((-0.9999999f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999f);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test278"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.6485655316075623d, 44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.14096854940358E13d);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test279"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    var1.addElement(2.0216852347077916d);
    org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var5 = var4.getStandardDeviation();
    double[] var7 = var4.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var12 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var11, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var10, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var9, (java.lang.Object[])var12);
    boolean var16 = var8.equals((java.lang.Object)var9);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var8);
    int var18 = var1.start();
    org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var20 = var19.getStandardDeviation();
    double[] var22 = var19.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    org.apache.commons.math3.exception.util.Localizable var24 = null;
    org.apache.commons.math3.exception.util.Localizable var25 = null;
    org.apache.commons.math3.exception.util.Localizable var26 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var27 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var28 = new org.apache.commons.math3.exception.NullArgumentException(var26, (java.lang.Object[])var27);
    org.apache.commons.math3.exception.MathInternalError var29 = new org.apache.commons.math3.exception.MathInternalError(var25, (java.lang.Object[])var27);
    org.apache.commons.math3.exception.NullArgumentException var30 = new org.apache.commons.math3.exception.NullArgumentException(var24, (java.lang.Object[])var27);
    boolean var31 = var23.equals((java.lang.Object)var24);
    var23.setElement(8899, 2.3930658372149933d);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var23);
    org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var36);
    double var39 = var36.addElementRolling(0.5246524883391532d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0216852347077916d);

  }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test280"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-1.9369499619508226d), (java.lang.Number)0.01329154278510984d, true);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test281"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     double var10 = var0.nextT(20.696514663540924d);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var11.getStandardDeviation();
//     double[] var14 = var11.sample(1);
//     double var15 = var11.getMean();
//     double[] var17 = var11.sample(100);
//     double var18 = var11.sample();
//     double var19 = var11.sample();
//     double var20 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     int var23 = var0.nextBinomial(97944, 0.11537426317526311d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var25 = var24.getStandardDeviation();
//     double[] var27 = var24.sample(1);
//     double var29 = var24.cumulativeProbability(0.0d);
//     double var31 = var24.cumulativeProbability(0.0d);
//     double var32 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     long var35 = var0.nextSecureLong(67L, 163572604512568L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.673593990950069d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "7d10bf6fe31486792cf08e4cf8a21ea97317e25440660266eca34db86858d529af3ccfa9a1cce92d3092fcc8694bf3996162"+ "'", var8.equals("7d10bf6fe31486792cf08e4cf8a21ea97317e25440660266eca34db86858d529af3ccfa9a1cce92d3092fcc8694bf3996162"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.13257979660911617d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.42960084852749264d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-1.0039610846701545d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.139625305696608d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 11394);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.49330121810102073d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 89239914473837L);
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test282"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    boolean var7 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator((-16L));
    double var11 = var0.cumulativeProbability(0.0d);
    boolean var12 = var0.isSupportLowerBoundInclusive();
    double var14 = var0.probability(7.724435900937391d);
    double var15 = var0.getNumericalVariance();
    double var17 = var0.inverseCumulativeProbability(0.05823178627842507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1.5697917284879035d));

  }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test283"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(192.9088122275434d);
//     double var12 = var0.nextExponential(0.7243407758924822d);
//     org.apache.commons.math3.distribution.NormalDistribution var13 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var13.reseedRandomGenerator(2L);
//     boolean var16 = var13.isSupportConnected();
//     boolean var17 = var13.isSupportLowerBoundInclusive();
//     double var18 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var13);
//     double var19 = var13.getMean();
//     double var20 = var13.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.837602598703114d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "c326154742"+ "'", var8.equals("c326154742"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 189L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.8929464216685731d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.5559867868196782d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.604776607991365d);
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test284"); }


    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(100000, 1.9999999f, 100.00001f);
    int var4 = var3.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test285"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(10.927865106621654d, 0.20468790066148068d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999999999992d);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test286"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(3.357622663932517d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0503677390927097E-6d);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test287"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(0.5395119302779527d, (-0.2492596627920229d));
//     double var9 = var0.nextGaussian((-0.03560534527178083d), 0.8144605996323813d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.12580209160818093d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.2687601283548028d));
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test288"); }


    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(1972, 99.99999f, Float.POSITIVE_INFINITY);
    var3.setElement(2019, (-0.7505224579632126d));
    var3.setNumElements(1955);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test289"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.014931963725887733d, 0.010100839201864612d);
    double var3 = var2.getNumericalMean();
    double var4 = var2.getNumericalVariance();
    boolean var5 = var2.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.014931963725887733d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0202695258192494E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test290"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     var0.reSeed(4L);
//     double var8 = var0.nextGaussian(0.7625552649455967d, 0.15512025679417774d);
//     int var11 = var0.nextPascal(337860, 0.5322866968936354d);
//     var0.reSeedSecure();
//     int var15 = var0.nextPascal(4, 0.9978516012375751d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8988590862390544d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 295783);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0);
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test291"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.3214140785540016d, 0.006982349495073288d, 11900.986496497815d, 33392016);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.7748663257093376d);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test292"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     double var12 = var0.nextGamma(4.950886585270677E-4d, 1.5703107297735257d);
//     int var15 = var0.nextInt(2, 17018);
//     long var18 = var0.nextSecureLong(0L, 319L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var20 = var0.nextPoisson((-1.2524505937205215d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.744762875428313d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 16788);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 272L);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test293"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(10.000001f, 99.99999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.000001f);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test294"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(11531, 9105);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 104989755);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test295"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(5.786007967375775E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1728.883597515171d));

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test296"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(0, 13890);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 13890);

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test297"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     long var8 = var0.nextPoisson(0.10516633568161556d);
//     double var11 = var0.nextGaussian(0.0d, 0.5834694007285642d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.587135708879087d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.10027660545747699d);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test298"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.009999999583352414d, true);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test299"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     var0.reSeed(14L);
//     double var14 = var0.nextExponential(0.9999997887160175d);
//     long var16 = var0.nextPoisson(0.8259324122591327d);
//     org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution(363.7393755555636d, 0.059233998853640384d);
//     double var20 = var19.getNumericalMean();
//     double var22 = var19.cumulativeProbability(9901.371084813745d);
//     double var23 = var19.sample();
//     double var24 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.4097305152026766d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d35a8c1d35"+ "'", var8.equals("d35a8c1d35"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.9028924938702286d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.3844973909690124d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 363.7393755555636d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 363.7605237517419d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 363.8202823488219d);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test300"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-26.317433148677743d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.9637395171472294d));

  }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test301"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, 1.525839000944343d, 0.0d, 1592);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test302"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2979.9579870417283d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test303"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(14L, (-1151L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1137L));

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test304"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var1.contract();
    int var3 = var1.start();
    float var4 = var1.getContractionCriteria();
    var1.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.5f);

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test305"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     double var9 = var0.nextGamma(9.319248049587957d, (-0.4255538433808183d));
//     long var11 = var0.nextPoisson(0.9978516012375751d);
//     int var14 = var0.nextZipf(8941, 1.445343853698748d);
//     java.lang.String var16 = var0.nextHexString(3826);
//     double var19 = var0.nextGaussian(1.383036361567265d, 18.853048230723537d);
//     var0.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var21 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var22 = var21.getSupportUpperBound();
//     double var24 = var21.inverseCumulativeProbability(0.9999999999928669d);
//     double var26 = var21.density(25.472636453138065d);
//     double var27 = var21.getNumericalMean();
//     var21.reseedRandomGenerator(1073741824L);
//     double var30 = var21.sample();
//     double var32 = var21.probability((-0.5829554842180134d));
//     double var33 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1.5441575754473973d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-5.170019084543205d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "f9a50f5c62aa745671313e2bb94e9a8cbf7c72b6377600b66fa6b560788cf98331d14d6c7508743480d1c12848fa1c8c77bb4717f3d5183cecba26dffcbd4e4c6c701c038b94e5c005c00d2080483d133264381c3ae926475e4a0cf4caf85524891465a4438e5a8504de43359dcaae8af0ad6b4218e5d663aae1289772b51b9d1aec170aeda4d559d60a7f7933c9425e06c5dd975ffb5a9cd0a94fe02e8ac63a89802fd52aac3c975ae97dfa3821320543f76e83f7a59079a476fe5b31e71357608c08a5fe04fdb517a6c1ff64afa4cffe01b24dbce202581c35bc27677297395e8ab83a6f690b83dc7654e664cef96025cd21beba3964e5771c970759c4a7d05ae5a6e55d2781405b7695b72f75ab0c46b9123b5a1bf176cecf4cb73158f39784707bbc5bcadf5910d92e90f3c4e050c6bfada6a5542e9c117ee16755a9ca88c02c47666229a82377e33e9bd93a103691294362ad872fa86a2a68249b2b679f2675d05862417b456bfba542c51c60295de8802894561589a425aca1ab8dbaedcd636a8e59a36e0444550e780d02b3b94439a524991f5cbd58066dbec9376226b96485d031e5f190a37ed2030d8a41ac5f308289de4b5ef0b11224e08a206e3b07b378dc8360c1291d3d620382e17d968c8bedc87009182c953f9f789317d56802bbbb2dba9982dfc42901c2a4efb3a5bc679193a84892c4746d376293b8bb34b92f0ae1a5c34d2c1a2a7ff13071b4eb6a9f2c4589203dfc7c310b8bd5aaa21e656af26643d37c5bb22fe2dd7a822ec287190f37f5d52cb2c815f60639be02d47b8a1506494d429875e6735e1da668b283b79b45116667e08d30e9bd72abd3fa6d77ca6531cbfad5fd686349b8d88301f7dc9e952f6cb1c193c666f93ffa01924be9cb0975690cf59934cf66b506da2ca6b0a4d6043f6bb4bf46d80101d8587600b145e3ffde505a6692becdca86c9f00b0c672e05c8a55dfb49794f94b1e9628fc86073001c2047a1afcf67be93daa05bd422554e2e17a85b4b780da56fb17662dfa853a47eb6bc86d2bbab6d245faf39b47f405d810a991855858b85383273d92e45fda03fa1d41cfd199d6c785634077e432661376b81bf7846e1a1e637bc98f079a2bb86f45655af0f063fd7145af7a70cc5e21091bb961376e6a99e426fec5f3389cccacd9dab1076a596950789ba342f6b24021c33a652ccbda670a2622b613c2905b2e084e7da7e0491914e246ae36779c00dcdbbde49b31d44993a3ff17849543dfd99344cad6a73f8d3c474f712aa5a0db81ccd82f21ae26595bbeb6cabb73c90f4d5592c098122873f22d441746352f5af902d4e91231ba0045317f831e3c93197699eb873c3e80754a2e5101eeca4f75ace3ee5767c27eee1424e5309ae32dd0a45b0bddb9cef44cff6d85ff68b623fb0a11d8110a97a1a6848bfcf01fa1c0ef5ab2c65f1d90958f1bd78a211e8ff63952670cd12d0716ef8fe969dc6c9f75c0376ddd2ede22514f58df6989476d11efc31d4264b02dd9697f7dc0b19234fc6f3a0105367daf86cd0e95890db542d25c1555ef149ca9fce3d0fc045b1455813f2289a63e94c6914b92101cb513b8449185584ba800bc57b89311c31998d12b7374639f722883afbe1524f93fecd2cc984078fbdd36878aa60afacdb97f344507752377a15953f43a2f70a78c67ec6decf7ce6ce37248b4a02fb2b42e594f27886938cc4f4ae440083362eed9a66cae31b3572488506fc97070f62674065563808d0189adfa4a8003d3d3d237130234501cb6e5a7f263bb8ea49814967981d0e044f9cfa111482b6cc7a609d080a24ec053eba2516de6cae520d313d4a04664c623c017d362a80ae7bbfc031b98610ad947b538166da9bc43eb2143705214acf2fb941f41ff0fca0f2e7477f8095b2d5099689b1e138df67f4df6a903032f68e65a0e2455e831256b032b877de0718436f858de643ae8b71315880fe4d4d565a36885ed07aa12c2cc91b93f387430bf4b151453e038d29adc236504bf8d20779afb3d40f7fae44bef32f77864598f288a5cb9e9300a9b328e4e8e72abfcd32aefb01b7b3e3e2408a37bdb5341b7d2f57a2718b54f60ab8aecce1c189e7dc7eff30ce6253e801c6abd2cbca079c8c23aa5af1f4b066f7c109c96e8103478ed9e1046971064512d16507c6ea8e98011c1ad862b82ef52d090217c8f0b315320fc71ed74f346f815c85f7ccf0dabb5d53ec9cb2b58e25b17bf4c7e35202ea4d11bc1b914df2571f5ec3cef9a4258cfa65bad19037c2b68da11e0921c35935491f6714f6e177aaab76d8c06fc2424fbe8aeb2ab7b4b26a40aa1fbf22700509249ae237acb4362acbc93acd987eb21516c108545f585e12045fbc97ddd69c411105df6c91bb1e36f4cf1a603ef399c22d61707b82d05982bcfcc37cd47f43e51a99870e52bff7fbac1003260be5a9c8de2052bde3b4ac61538e8cb2ca2602b94e31a59279e871ed6c7600cbe20165f5b52297088994d14eaf2d46c7f0771f8282b92ab11745b37400f07b4b1f373c60a9a83c10de8a231deb93750bfc2504dd25869754560a14e0ce1dc2a9006c7f050c9c94a54fc15eb5debf624bca8da89e4a3949c9ef68faecd6242ea2a0f43190b9addaa9a705c47e5166db183964da770839b5c9e5610476138fb02f6f83689f713218b1d18ac6"+ "'", var16.equals("f9a50f5c62aa745671313e2bb94e9a8cbf7c72b6377600b66fa6b560788cf98331d14d6c7508743480d1c12848fa1c8c77bb4717f3d5183cecba26dffcbd4e4c6c701c038b94e5c005c00d2080483d133264381c3ae926475e4a0cf4caf85524891465a4438e5a8504de43359dcaae8af0ad6b4218e5d663aae1289772b51b9d1aec170aeda4d559d60a7f7933c9425e06c5dd975ffb5a9cd0a94fe02e8ac63a89802fd52aac3c975ae97dfa3821320543f76e83f7a59079a476fe5b31e71357608c08a5fe04fdb517a6c1ff64afa4cffe01b24dbce202581c35bc27677297395e8ab83a6f690b83dc7654e664cef96025cd21beba3964e5771c970759c4a7d05ae5a6e55d2781405b7695b72f75ab0c46b9123b5a1bf176cecf4cb73158f39784707bbc5bcadf5910d92e90f3c4e050c6bfada6a5542e9c117ee16755a9ca88c02c47666229a82377e33e9bd93a103691294362ad872fa86a2a68249b2b679f2675d05862417b456bfba542c51c60295de8802894561589a425aca1ab8dbaedcd636a8e59a36e0444550e780d02b3b94439a524991f5cbd58066dbec9376226b96485d031e5f190a37ed2030d8a41ac5f308289de4b5ef0b11224e08a206e3b07b378dc8360c1291d3d620382e17d968c8bedc87009182c953f9f789317d56802bbbb2dba9982dfc42901c2a4efb3a5bc679193a84892c4746d376293b8bb34b92f0ae1a5c34d2c1a2a7ff13071b4eb6a9f2c4589203dfc7c310b8bd5aaa21e656af26643d37c5bb22fe2dd7a822ec287190f37f5d52cb2c815f60639be02d47b8a1506494d429875e6735e1da668b283b79b45116667e08d30e9bd72abd3fa6d77ca6531cbfad5fd686349b8d88301f7dc9e952f6cb1c193c666f93ffa01924be9cb0975690cf59934cf66b506da2ca6b0a4d6043f6bb4bf46d80101d8587600b145e3ffde505a6692becdca86c9f00b0c672e05c8a55dfb49794f94b1e9628fc86073001c2047a1afcf67be93daa05bd422554e2e17a85b4b780da56fb17662dfa853a47eb6bc86d2bbab6d245faf39b47f405d810a991855858b85383273d92e45fda03fa1d41cfd199d6c785634077e432661376b81bf7846e1a1e637bc98f079a2bb86f45655af0f063fd7145af7a70cc5e21091bb961376e6a99e426fec5f3389cccacd9dab1076a596950789ba342f6b24021c33a652ccbda670a2622b613c2905b2e084e7da7e0491914e246ae36779c00dcdbbde49b31d44993a3ff17849543dfd99344cad6a73f8d3c474f712aa5a0db81ccd82f21ae26595bbeb6cabb73c90f4d5592c098122873f22d441746352f5af902d4e91231ba0045317f831e3c93197699eb873c3e80754a2e5101eeca4f75ace3ee5767c27eee1424e5309ae32dd0a45b0bddb9cef44cff6d85ff68b623fb0a11d8110a97a1a6848bfcf01fa1c0ef5ab2c65f1d90958f1bd78a211e8ff63952670cd12d0716ef8fe969dc6c9f75c0376ddd2ede22514f58df6989476d11efc31d4264b02dd9697f7dc0b19234fc6f3a0105367daf86cd0e95890db542d25c1555ef149ca9fce3d0fc045b1455813f2289a63e94c6914b92101cb513b8449185584ba800bc57b89311c31998d12b7374639f722883afbe1524f93fecd2cc984078fbdd36878aa60afacdb97f344507752377a15953f43a2f70a78c67ec6decf7ce6ce37248b4a02fb2b42e594f27886938cc4f4ae440083362eed9a66cae31b3572488506fc97070f62674065563808d0189adfa4a8003d3d3d237130234501cb6e5a7f263bb8ea49814967981d0e044f9cfa111482b6cc7a609d080a24ec053eba2516de6cae520d313d4a04664c623c017d362a80ae7bbfc031b98610ad947b538166da9bc43eb2143705214acf2fb941f41ff0fca0f2e7477f8095b2d5099689b1e138df67f4df6a903032f68e65a0e2455e831256b032b877de0718436f858de643ae8b71315880fe4d4d565a36885ed07aa12c2cc91b93f387430bf4b151453e038d29adc236504bf8d20779afb3d40f7fae44bef32f77864598f288a5cb9e9300a9b328e4e8e72abfcd32aefb01b7b3e3e2408a37bdb5341b7d2f57a2718b54f60ab8aecce1c189e7dc7eff30ce6253e801c6abd2cbca079c8c23aa5af1f4b066f7c109c96e8103478ed9e1046971064512d16507c6ea8e98011c1ad862b82ef52d090217c8f0b315320fc71ed74f346f815c85f7ccf0dabb5d53ec9cb2b58e25b17bf4c7e35202ea4d11bc1b914df2571f5ec3cef9a4258cfa65bad19037c2b68da11e0921c35935491f6714f6e177aaab76d8c06fc2424fbe8aeb2ab7b4b26a40aa1fbf22700509249ae237acb4362acbc93acd987eb21516c108545f585e12045fbc97ddd69c411105df6c91bb1e36f4cf1a603ef399c22d61707b82d05982bcfcc37cd47f43e51a99870e52bff7fbac1003260be5a9c8de2052bde3b4ac61538e8cb2ca2602b94e31a59279e871ed6c7600cbe20165f5b52297088994d14eaf2d46c7f0771f8282b92ab11745b37400f07b4b1f373c60a9a83c10de8a231deb93750bfc2504dd25869754560a14e0ce1dc2a9006c7f050c9c94a54fc15eb5debf624bca8da89e4a3949c9ef68faecd6242ea2a0f43190b9addaa9a705c47e5166db183964da770839b5c9e5610476138fb02f6f83689f713218b1d18ac6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-9.019035300717304d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 6.755176609774487d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 5.055823438644928E-142d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 0.5231370181288907d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == (-0.5128636469720674d));
// 
//   }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test306"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(1.625430559956864d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test307"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(1.0178452709308328d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2029264757372629d);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test308"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.exception.OutOfRangeException var17 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.15512025679417774d, (java.lang.Number)1.2471705263294632d, (java.lang.Number)0.0843874063990762d);
    boolean var18 = var2.equals((java.lang.Object)1.2471705263294632d);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var20 = var19.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var19.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test309"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getStandardDeviation();
//     double[] var13 = var10.sample(1);
//     double var15 = var10.cumulativeProbability(0.0d);
//     double var16 = var10.getSupportUpperBound();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     var0.reSeed();
//     int var21 = var0.nextZipf(1859, 9.717527268210787E-6d);
//     java.lang.String var23 = var0.nextHexString(4337);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var26 = var0.nextPermutation(33, 9679);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 41.00173304081941d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.8588261491492104d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 224);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "63c05c47e36d05c01ec8c3d0d3273ceabacdfa60fd36e238ae256db0431c3a4b1b723adb496e617de16f004ad1c1cd744dcb4d46af8a35031e1ab983dc7a341ce7cc0c77d7f598e5ab5d65c0d9fce6d85c2bf44b76145f34bb2453d19527490e3489f890fd42a0c29ac29271450b97da5db1237e145ec1369262b717490ff450100f5ffcdd696a7def7a73e7031ff1ee91f1974bc502fe4c96b2df83e3ab1a1086c40711c310681cf74d3e5d162e20d3e4bdc2d7b00d79abf0b0bf596390d64c215e5b823bca5b322d35e4f06a90c23eba6169f96c50e21bcd4efd715cd25d1fe775bbfe1b60f02de31a83351151f6ecd9a10af952c8bd5d2a3ae3ffc439b6c55875b3eaba0513a376b82101b5442026ec0fcc1d614b63fc5c917d1253248b78893c8eb7d742e5ee5a8b11836ba71314c3a330dca3aea6f64e362bf88d4f9dd20998fbf483332f504908d00771c4722202aaceacacff807187ab6ba4b34cd6e88ac8872362ca43c90ea92c251a2d315ab21b6ac898ed70306c4378da0516ed7e2e3ead02969ba03cd6845374d88a061a77145685dd01b1c04ce73eec031b75f0682d74ed7cf049f9500bd3b3888bb259f2b9b3f41b6a157f7b6bebe79d672105a9c4fa9ce2aa9be4f49474fa9c3f22dc6767bd7a0ba87e05988fa4a854795d6c6e680dbfb325582f8a8b2be483b967d10e561b31b1d1f15ecff3aeab7a62bce12166264a49b51ee391fe766cc126c56cde52b054c4a9f4889a1872d87dcb90dc6812b6b3aa035c41e4218da88fe861b44d9fcf93b2170b06b896f0e3c2f8002b46fb31d443805cf9a45d41ae5d7a91f9080aacdcb1a3fe9e5a7e4e5347a4c474c6866cc50123c54d740d43a6c96f4d309ca88a639e5c6fd7b25e02f3a03ae312c7bdd96c8c6e1248419dd46990ef3a0af6e0496a3d284e4cab7b24527d38e905d6ee0e42c46b3d102cc97f2781bb2359b6fa10f6a790cd6a23cb31aef8c54cc0781dc6f7b2ef0667442e1a086b31464d1a4b5aa854419b4c84d7b2cc73fa922f35a1d1dff015372ba682d6f8bca503c5eaf0c4fb5cab29c66dbdc5a6c778fc27ec0a298b0a097830062848cd3a5d7a174e42cd20482339e47f782d8995012be09939974fc79d817c1166abaf17d1728aa10eb9ec550f64a6b8d209dd4702f5a2be6464b7cca28c96738436f96c28949bef67b54d72fe8d5b15ffa6449f599a30a9855671528e42169ba2167620b7bd3af06166927322181eda04d68373e0fe60b1c1b6a0e2ba9ab8fb46c916209486be15504d868a454976af4b6630331031bda544ed609f746073dc7a7c0812ef73f8b5d94ce0e8549d3fea3282fcf7d299a2020d2027be81643d32a8b2702778e3a291e9ef16e8ad355433b7faff1041e44adc352cdc71c6c6ae1cfb59d7024e0a53ebfb3201ac95d4038921d602d788200d213646fb4498a68995ad578568fe553181adab14550d332d2043de02fe13cd70664c02b9c1555df1df1df98edbabcf3c025b8b0b84e47295babb6c43d24567d02ec0d03ca7eb8b9ca2bc7e0a064fad3c95df39c27676e30898860a3011d551e1d83c94628b9ab96925503ecf05d23aace60704c574548d5922fba92655f7cade7c06a24c11b9f266e7a527c0634d1c4443f5b8ebb0f4d9ebb13f15ab8318aa2e4dd23cfaecb49ebcd716787a8c0951cf069c9dcdad6102060fd341e69249b5e929e76b9add1c6765b8a67a4fb332ed51154501d0f8831398e0db6279775d5d4012e7837d85e3dc658410aa01dd5f7fed8913c3af7441756274d5eb983f17e25669376d8c8368c3da5f15c23dc77a6b8dde43f1c6a4476bf1fe0c2059644c3b4678e99177f9f6f16a91c8087afe68865c3e36754dc1e6562503a700ddd1c94306f945d695d2d48a9eeed7712d22d24a69481759e1f0a08c1e4671a59b49f8629132c854ca2a83f0ca1d6f9a00fb88d275ac9bb236381fb0fa3b07ffea67dd340038f65531b7424ce852431b73b7b4e345609329e51d7151788fc53166d53e073ccc3410afc9eeda7ba928c0628dedb83d683bfcb8a6846bc8ea44672e949f2b4ccc84c1d3fca00bb4e9f5c23ab1b23459a66fbf52d504df0e9f460f7529432bf1e8562c361436e713033c31eac5ae5f62151f530db2bcb857b1ef96d11490df4bbfa60389f746196a56f529ddcb37ee5899999c9f6331433439c661686a5611c78e9d65e14d4527a65cd9b575d210bdd6455a6d3fdb839cd64b34a2c9d172b06481d78a9f7a3a5bf8ff9ea01f3f6dd21013f9180b12051071b9dc3ec075fc710deb3c46a5c6cc181042b893a8128c17e2cfc2620b0d88283911655a46d1844a887e1d1d5d3c17c481c88ccb64b4fd9678ec1e3a264a66f4e28345da32fa13d8172a931a4837f1645053730d280e2e2d156015bfee77ddb95eee3c53f7ab891e847e072553a6f5cd6a936e68b798a93dcceb215469088fd98b3af4953df7bd06e4e994ddc202a7dd0ae34f723445443ae32ae5b7fde8696b1925e1372e6a786a8c22082db46463523e8ead290aace08612bb98d5e65896bcfc55ef94a3087e367364a17db7c420d51a8b581e82f1a4d390f9f3b51e28e2743c71b488e207902bfbea976907b30b0dca5ee01412b03ad56273540aae124f382e10c8876f97bae7c349096d235fb89336ff5cf6eb7346f2b707d581032a975b54788d31ddbd5cbb8bf25dd4bd30d438ac44938467333902ce196449f436594f83bff1a870ee7a2ad3446d11dad9151215d0e426c574f145b210863ae01a2ce47013cb07588ed4e438b95c3057c0b223dae468096557f6e3e0b88855363e00d3cfe32347060b72a073d3f4d5b67bab85d380a8fb385a0966e1e4060beb69f45610b76fba0a6955ba7130bd3f49bccbb9c10cedc6ab2846483b78355c20b7dc29ccbe2acd97ced6e0cc88e6bbd4dba69b91fdcc788416c625924cddb5290ff86a888e93dd4c19e7e0560f8a7217e76e234b7ec600b9cb7b71450a28c2d657e75c9658e2530eecad6c5126ef46938c8a754bc1b5046d9510339651eeef27df1311dae"+ "'", var23.equals("63c05c47e36d05c01ec8c3d0d3273ceabacdfa60fd36e238ae256db0431c3a4b1b723adb496e617de16f004ad1c1cd744dcb4d46af8a35031e1ab983dc7a341ce7cc0c77d7f598e5ab5d65c0d9fce6d85c2bf44b76145f34bb2453d19527490e3489f890fd42a0c29ac29271450b97da5db1237e145ec1369262b717490ff450100f5ffcdd696a7def7a73e7031ff1ee91f1974bc502fe4c96b2df83e3ab1a1086c40711c310681cf74d3e5d162e20d3e4bdc2d7b00d79abf0b0bf596390d64c215e5b823bca5b322d35e4f06a90c23eba6169f96c50e21bcd4efd715cd25d1fe775bbfe1b60f02de31a83351151f6ecd9a10af952c8bd5d2a3ae3ffc439b6c55875b3eaba0513a376b82101b5442026ec0fcc1d614b63fc5c917d1253248b78893c8eb7d742e5ee5a8b11836ba71314c3a330dca3aea6f64e362bf88d4f9dd20998fbf483332f504908d00771c4722202aaceacacff807187ab6ba4b34cd6e88ac8872362ca43c90ea92c251a2d315ab21b6ac898ed70306c4378da0516ed7e2e3ead02969ba03cd6845374d88a061a77145685dd01b1c04ce73eec031b75f0682d74ed7cf049f9500bd3b3888bb259f2b9b3f41b6a157f7b6bebe79d672105a9c4fa9ce2aa9be4f49474fa9c3f22dc6767bd7a0ba87e05988fa4a854795d6c6e680dbfb325582f8a8b2be483b967d10e561b31b1d1f15ecff3aeab7a62bce12166264a49b51ee391fe766cc126c56cde52b054c4a9f4889a1872d87dcb90dc6812b6b3aa035c41e4218da88fe861b44d9fcf93b2170b06b896f0e3c2f8002b46fb31d443805cf9a45d41ae5d7a91f9080aacdcb1a3fe9e5a7e4e5347a4c474c6866cc50123c54d740d43a6c96f4d309ca88a639e5c6fd7b25e02f3a03ae312c7bdd96c8c6e1248419dd46990ef3a0af6e0496a3d284e4cab7b24527d38e905d6ee0e42c46b3d102cc97f2781bb2359b6fa10f6a790cd6a23cb31aef8c54cc0781dc6f7b2ef0667442e1a086b31464d1a4b5aa854419b4c84d7b2cc73fa922f35a1d1dff015372ba682d6f8bca503c5eaf0c4fb5cab29c66dbdc5a6c778fc27ec0a298b0a097830062848cd3a5d7a174e42cd20482339e47f782d8995012be09939974fc79d817c1166abaf17d1728aa10eb9ec550f64a6b8d209dd4702f5a2be6464b7cca28c96738436f96c28949bef67b54d72fe8d5b15ffa6449f599a30a9855671528e42169ba2167620b7bd3af06166927322181eda04d68373e0fe60b1c1b6a0e2ba9ab8fb46c916209486be15504d868a454976af4b6630331031bda544ed609f746073dc7a7c0812ef73f8b5d94ce0e8549d3fea3282fcf7d299a2020d2027be81643d32a8b2702778e3a291e9ef16e8ad355433b7faff1041e44adc352cdc71c6c6ae1cfb59d7024e0a53ebfb3201ac95d4038921d602d788200d213646fb4498a68995ad578568fe553181adab14550d332d2043de02fe13cd70664c02b9c1555df1df1df98edbabcf3c025b8b0b84e47295babb6c43d24567d02ec0d03ca7eb8b9ca2bc7e0a064fad3c95df39c27676e30898860a3011d551e1d83c94628b9ab96925503ecf05d23aace60704c574548d5922fba92655f7cade7c06a24c11b9f266e7a527c0634d1c4443f5b8ebb0f4d9ebb13f15ab8318aa2e4dd23cfaecb49ebcd716787a8c0951cf069c9dcdad6102060fd341e69249b5e929e76b9add1c6765b8a67a4fb332ed51154501d0f8831398e0db6279775d5d4012e7837d85e3dc658410aa01dd5f7fed8913c3af7441756274d5eb983f17e25669376d8c8368c3da5f15c23dc77a6b8dde43f1c6a4476bf1fe0c2059644c3b4678e99177f9f6f16a91c8087afe68865c3e36754dc1e6562503a700ddd1c94306f945d695d2d48a9eeed7712d22d24a69481759e1f0a08c1e4671a59b49f8629132c854ca2a83f0ca1d6f9a00fb88d275ac9bb236381fb0fa3b07ffea67dd340038f65531b7424ce852431b73b7b4e345609329e51d7151788fc53166d53e073ccc3410afc9eeda7ba928c0628dedb83d683bfcb8a6846bc8ea44672e949f2b4ccc84c1d3fca00bb4e9f5c23ab1b23459a66fbf52d504df0e9f460f7529432bf1e8562c361436e713033c31eac5ae5f62151f530db2bcb857b1ef96d11490df4bbfa60389f746196a56f529ddcb37ee5899999c9f6331433439c661686a5611c78e9d65e14d4527a65cd9b575d210bdd6455a6d3fdb839cd64b34a2c9d172b06481d78a9f7a3a5bf8ff9ea01f3f6dd21013f9180b12051071b9dc3ec075fc710deb3c46a5c6cc181042b893a8128c17e2cfc2620b0d88283911655a46d1844a887e1d1d5d3c17c481c88ccb64b4fd9678ec1e3a264a66f4e28345da32fa13d8172a931a4837f1645053730d280e2e2d156015bfee77ddb95eee3c53f7ab891e847e072553a6f5cd6a936e68b798a93dcceb215469088fd98b3af4953df7bd06e4e994ddc202a7dd0ae34f723445443ae32ae5b7fde8696b1925e1372e6a786a8c22082db46463523e8ead290aace08612bb98d5e65896bcfc55ef94a3087e367364a17db7c420d51a8b581e82f1a4d390f9f3b51e28e2743c71b488e207902bfbea976907b30b0dca5ee01412b03ad56273540aae124f382e10c8876f97bae7c349096d235fb89336ff5cf6eb7346f2b707d581032a975b54788d31ddbd5cbb8bf25dd4bd30d438ac44938467333902ce196449f436594f83bff1a870ee7a2ad3446d11dad9151215d0e426c574f145b210863ae01a2ce47013cb07588ed4e438b95c3057c0b223dae468096557f6e3e0b88855363e00d3cfe32347060b72a073d3f4d5b67bab85d380a8fb385a0966e1e4060beb69f45610b76fba0a6955ba7130bd3f49bccbb9c10cedc6ab2846483b78355c20b7dc29ccbe2acd97ced6e0cc88e6bbd4dba69b91fdcc788416c625924cddb5290ff86a888e93dd4c19e7e0560f8a7217e76e234b7ec600b9cb7b71450a28c2d657e75c9658e2530eecad6c5126ef46938c8a754bc1b5046d9510339651eeef27df1311dae"));
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test310"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.6783191466250897d, 9.148516570918291d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.7916624013546924E-5d);

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test311"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextUniform(0.2577047455984825d, 13.770182159584014d);
//     long var6 = var1.nextPoisson(23.012289905639566d);
//     int var9 = var1.nextZipf(10178, 0.5950413774252329d);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var10.reseedRandomGenerator(2L);
//     double[] var14 = var10.sample(100000);
//     double var15 = var10.getMean();
//     double var16 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     boolean var17 = var10.isSupportConnected();
//     double[] var19 = var10.sample(962);
//     double var20 = var10.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4.3993056202190095d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 22L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1808);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.1286307047399447d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-0.6227064094546529d));
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test312"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1.0039610846701545d), (java.lang.Number)3.2462374214935577d, false);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test313"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var4 = var0.getMean();
    double[] var6 = var0.sample(100);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    int var8 = var7.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test314"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.2121222818363371d, (-0.8057015395917116d), 0.25128227802057257d, 1319);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test315"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(2.1424092671303407d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0024469609098009756d);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test316"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.8678437901632892d);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test317"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(4462062475205621479L, 180L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 180L);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test318"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double var3 = var0.inverseCumulativeProbability(0.9999999999928669d);
    double var4 = var0.getMean();
    boolean var5 = var0.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 6.755176609774487d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test319"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(1949, 2097153);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test320"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(22.43277156890168d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.15413553698356d);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test321"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(192.9088122275434d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 820.5075967235496d);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test322"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)22.488113044724955d, (java.lang.Number)179L, true);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test323"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, 1.9870324860653736d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test324"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2.384186E-7f, 1954);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test325"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(100.0f, 2.8E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test326"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(1990, 9194402);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test327"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     var0.reSeed(4L);
//     java.lang.String var7 = var0.nextHexString(1);
//     var0.reSeed((-21428512432588800L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "2"+ "'", var7.equals("2"));
// 
//   }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test328"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     var0.reSeedSecure(437L);
//     int var11 = var0.nextBinomial(9446, 0.2924487804079366d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.861875085664908d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2746);
// 
//   }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test329"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.5378868904281788d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0028678313886235d);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test330"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(5.810676965539079d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.10141544481845001d);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test331"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("56b0bac16e");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test332"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, var1);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test333"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    double[] var7 = var4.getInternalValues();
    var4.discardFrontElements(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setExpansionFactor(100.00001f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test334"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.setElement(8899, 2.3930658372149933d);
    var4.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.discardMostRecentElements(10178);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test335"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    var0.reseedRandomGenerator(2L);
    double[] var4 = var0.sample(100000);
    double var5 = var0.getMean();
    var0.reseedRandomGenerator(1600L);
    double var9 = var0.cumulativeProbability(0.0d);
    double var10 = var0.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test336"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(1348L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test337"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var14 = var0.nextWeibull(0.001908508257396575d, 1.06784626178585d);
//     org.apache.commons.math3.distribution.IntegerDistribution var15 = null;
//     int var16 = var0.nextInversionDeviate(var15);
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test338"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(6794.892254650551d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6795L);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test339"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
    java.lang.Object var17 = null;
    boolean var18 = var4.equals(var17);
    var4.setElement(100, 0.0d);
    double[] var22 = var4.getInternalValues();
    float var23 = var4.getExpansionFactor();
    int var24 = var4.getExpansionMode();
    double[] var25 = var4.getInternalValues();
    int var26 = var4.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);

  }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test340"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     var0.reSeed(14L);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextWeibull((-1.332977418220518d), 0.09418014555261975d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.3259478104473994d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "99ec4950e3"+ "'", var8.equals("99ec4950e3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.540144989276455d));
// 
//   }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test341"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var7 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var5, (java.lang.Number)(-1), (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)3.1039797472520814d, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test342"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(19L, (-79248L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-79229L));

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test343"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    int var7 = var6.getNumElements();
    var6.setNumElements(8899);
    int var10 = var6.start();
    int var11 = var6.getNumElements();
    int var12 = var6.getNumElements();
    var6.addElement(1.0069113723948844d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 8899);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 8899);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test344"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var13 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var14.getTiesStrategy();
    java.lang.Class var16 = var15.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    java.lang.String var18 = var15.toString();
    java.lang.String var19 = var15.name();
    java.lang.String var20 = var15.name();
    int var21 = var15.ordinal();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var15);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "MAXIMAL"+ "'", var13.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "AVERAGE"+ "'", var18.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 3);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test345"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(24.701632111266814d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.04131365211346901d);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test346"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(7.6293945E-6f, 1940);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test347"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(8106L, 206L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test348"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     var0.reSeed();
//     double var15 = var0.nextChiSquare(7.617953921806563d);
//     java.lang.String var17 = var0.nextSecureHexString(1916);
//     int var20 = var0.nextZipf(11474, 0.8744549098686318d);
//     double var23 = var0.nextBeta(0.2782029380240531d, 14.27900880653991d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var26 = var0.nextInt(3264, 1868);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5604294597003486d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1533e4c2ac"+ "'", var8.equals("1533e4c2ac"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 6.171017807871298d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "bfcdeb24c3825d8563fc739eb4899eebb1b0ab63275c195c9e324734c73147c451e3db4c608ab6f411f4dfa51f4e97f4d85861032d67b6b1caef6c3b5d5c62902c28b28b470e15fee907252f7d01bd2fb0ca195bad77697679e15cc4d5fa859ace8c04f639bd411ab8984ff0152f4fc0f6e2d48f33af3a9a1dec97eae44ecb33c71a06e4a186b509521631cef86df40e0b16958febb11fdd0f46ef95d7c287d414476dee9f49200429b25026b20cd7ace3c60333b44ecf7395ea34b2e26a8e9a08d02fb4c5f7b3b5041ff35104d9b7e66fabc070043fb030b45c048d95f29b6ea8a7532f0fd9b356a5626b9e26597d399c47b7e3f970fd340f3d64d113259313e195fe9b2780aa2cbd1356a09486ad39ab9342823dddd2d00916eb11b282b42533bc4c9d727ca359cc409c103e8bef83401de910683d7c905f1fa251e8424a95add6bcae54a2ff15829f4c73494a6c390915cd1f78d5f1c50c13fd94b7ca618d9875624a192475d6acb376903a154b5956a05a28fb076208400802884a9b150434941db8e993b132ea52a9d794aaf696dc02e0dae1a5df89a327287e01748e329d64fb34c052d18c1fa77570d22c1b9de89582688fd81073bbdff3ed09cdcdbff799deabb59756892a453d2c045f3a21fd619b492f8040a5c35b77e07c4e233dc1ae6aead8ec2018cff2fff20c4d5d6fb15cb8001f97d3918a581a52d4103e630226f0d873e6f413b3a1050fbf554973f74b78fd4f07cf3c8377184871db4caf21c796c680870c9931c621e7ed9aa5b3883fd6b5d0015d0b5991f2e168c4e560086d25950f245f9cd64cfd07b106cbfb4c3c71cf29c5b53b5face4a60d560cdd25a7154bdf06c8e76bdcbbf4d6f7e7a2c5488c306c0e08cf8b400960000e7d8aaa8286de29ba2683b55f09ae21abc049bf1f269f16880627db88b516fb7effdcf86494d53c1de2ec8f25f4678cffbd8df64a684483ef45e645482aba6ba9af515a60bbae8b2cf74fa95c57b7d0357f249e0187374aab3d613c95a151285095ef53a3a62ca63b42a291e0dc7a85c528443dc66cb6e8a581e1da341a2aa74dba2484f9833e8189fa5a57becfa98d22ccc579c008afa28416c900b7a3f4c76afeb5bf76c3ee302e89efd0e7ad4e3de581d6c14a9994219c59612917ddc4224ad8018368147b348753a7ee41485af0d997aa1418fdeef06f2f838189ce47b5a9a3cef536b3edaa50ca4c2cee3df2c5dd3ad80d071f41260100b93e23aeb42d2e6ff5df7d15c2ba25ab4fa4d7113efdd332d4b99021d18cd7f4dbef43022329709a4a7dc6dd92f94537aa096907f60c139599ea4999f7d6af9430b9fefaf70a69"+ "'", var17.equals("bfcdeb24c3825d8563fc739eb4899eebb1b0ab63275c195c9e324734c73147c451e3db4c608ab6f411f4dfa51f4e97f4d85861032d67b6b1caef6c3b5d5c62902c28b28b470e15fee907252f7d01bd2fb0ca195bad77697679e15cc4d5fa859ace8c04f639bd411ab8984ff0152f4fc0f6e2d48f33af3a9a1dec97eae44ecb33c71a06e4a186b509521631cef86df40e0b16958febb11fdd0f46ef95d7c287d414476dee9f49200429b25026b20cd7ace3c60333b44ecf7395ea34b2e26a8e9a08d02fb4c5f7b3b5041ff35104d9b7e66fabc070043fb030b45c048d95f29b6ea8a7532f0fd9b356a5626b9e26597d399c47b7e3f970fd340f3d64d113259313e195fe9b2780aa2cbd1356a09486ad39ab9342823dddd2d00916eb11b282b42533bc4c9d727ca359cc409c103e8bef83401de910683d7c905f1fa251e8424a95add6bcae54a2ff15829f4c73494a6c390915cd1f78d5f1c50c13fd94b7ca618d9875624a192475d6acb376903a154b5956a05a28fb076208400802884a9b150434941db8e993b132ea52a9d794aaf696dc02e0dae1a5df89a327287e01748e329d64fb34c052d18c1fa77570d22c1b9de89582688fd81073bbdff3ed09cdcdbff799deabb59756892a453d2c045f3a21fd619b492f8040a5c35b77e07c4e233dc1ae6aead8ec2018cff2fff20c4d5d6fb15cb8001f97d3918a581a52d4103e630226f0d873e6f413b3a1050fbf554973f74b78fd4f07cf3c8377184871db4caf21c796c680870c9931c621e7ed9aa5b3883fd6b5d0015d0b5991f2e168c4e560086d25950f245f9cd64cfd07b106cbfb4c3c71cf29c5b53b5face4a60d560cdd25a7154bdf06c8e76bdcbbf4d6f7e7a2c5488c306c0e08cf8b400960000e7d8aaa8286de29ba2683b55f09ae21abc049bf1f269f16880627db88b516fb7effdcf86494d53c1de2ec8f25f4678cffbd8df64a684483ef45e645482aba6ba9af515a60bbae8b2cf74fa95c57b7d0357f249e0187374aab3d613c95a151285095ef53a3a62ca63b42a291e0dc7a85c528443dc66cb6e8a581e1da341a2aa74dba2484f9833e8189fa5a57becfa98d22ccc579c008afa28416c900b7a3f4c76afeb5bf76c3ee302e89efd0e7ad4e3de581d6c14a9994219c59612917ddc4224ad8018368147b348753a7ee41485af0d997aa1418fdeef06f2f838189ce47b5a9a3cef536b3edaa50ca4c2cee3df2c5dd3ad80d071f41260100b93e23aeb42d2e6ff5df7d15c2ba25ab4fa4d7113efdd332d4b99021d18cd7f4dbef43022329709a4a7dc6dd92f94537aa096907f60c139599ea4999f7d6af9430b9fefaf70a69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.009019928874486358d);
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test349"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-297256655), 962);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 193982305);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test350"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.4518934003863375d, (java.lang.Number)0.7740996449567269d, false);

  }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test351"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-0.7336831272234878d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test352"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-0.9283927923794728d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.39518834996379976d);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test353"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(1910, (-127));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-242570));

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test354"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.314240134565475E126d);

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test355"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     double var5 = var0.nextChiSquare(7.6675647339750626d);
//     java.lang.String var7 = var0.nextSecureHexString(1931);
//     org.apache.commons.math3.distribution.IntegerDistribution var8 = null;
//     int var9 = var0.nextInversionDeviate(var8);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test356"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    boolean var3 = var1.equals((java.lang.Object)"ac7f8ab61330e5fa89f016091a9bf14d1dfc27b9d7edd3ce3ec344803ed848e9dde93e053930a67e0927be4be7816278403b");
    boolean var5 = var1.equals((java.lang.Object)"e1e61d906c3833fad993ec3abab2930274bc6a7e51878506413ee4218d86de3dde43ac28b4128702bc1b060bc0582a0c31d2");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test357"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)2.2058017250564452d);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test358"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)8334.694318112313d, (java.lang.Number)2, false);

  }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test359"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
//     java.lang.Class var5 = var4.getDeclaringClass();
//     int var6 = var4.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
//     org.apache.commons.math3.random.RandomGenerator var8 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
//     org.apache.commons.math3.random.RandomGenerator var10 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
//     java.lang.Class var15 = var14.getDeclaringClass();
//     java.lang.Class var16 = var14.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var14);
//     org.apache.commons.math3.random.RandomGenerator var18 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var18);
//     org.apache.commons.math3.distribution.NormalDistribution var20 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var21 = var20.getStandardDeviation();
//     double[] var23 = var20.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(var23);
//     var24.setElement(11, 0.5322866968936354d);
//     double var29 = var24.addElementRolling(1.5498468927479463d);
//     float var30 = var24.getExpansionFactor();
//     org.apache.commons.math3.util.ResizableDoubleArray var33 = new org.apache.commons.math3.util.ResizableDoubleArray(1919, 100.00001f);
//     org.apache.commons.math3.util.ResizableDoubleArray var34 = new org.apache.commons.math3.util.ResizableDoubleArray(var33);
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var24, var33);
//     boolean var36 = var2.equals((java.lang.Object)var33);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var33.discardMostRecentElements(5668);
//       fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
//     } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == (-1.6498144393022334d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
// 
//   }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test360"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    var1.addElement(2.0216852347077916d);
    org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var5 = var4.getStandardDeviation();
    double[] var7 = var4.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var12 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var11, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var10, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var9, (java.lang.Object[])var12);
    boolean var16 = var8.equals((java.lang.Object)var9);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var8);
    int var18 = var1.start();
    org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var20 = var19.getStandardDeviation();
    double[] var22 = var19.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    org.apache.commons.math3.exception.util.Localizable var24 = null;
    org.apache.commons.math3.exception.util.Localizable var25 = null;
    org.apache.commons.math3.exception.util.Localizable var26 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var27 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var28 = new org.apache.commons.math3.exception.NullArgumentException(var26, (java.lang.Object[])var27);
    org.apache.commons.math3.exception.MathInternalError var29 = new org.apache.commons.math3.exception.MathInternalError(var25, (java.lang.Object[])var27);
    org.apache.commons.math3.exception.NullArgumentException var30 = new org.apache.commons.math3.exception.NullArgumentException(var24, (java.lang.Object[])var27);
    boolean var31 = var23.equals((java.lang.Object)var24);
    var23.setElement(8899, 2.3930658372149933d);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var23);
    int var36 = var23.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test361"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos((-0.054349963021461445d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6251730830068953d);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test362"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    double[] var5 = var4.getElements();
    double[] var6 = var4.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test363"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    boolean var13 = var2.equals((java.lang.Object)(-1.5564980685845229d));
    java.lang.Class var14 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.random.RandomGenerator var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test364"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(0.6134466571100122d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.37784244231515496d);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test365"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test366"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var11 = var9.sample();
//     double[] var13 = var9.sample(243);
//     double var14 = var9.getSupportLowerBound();
//     boolean var15 = var9.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 53.55770964457071d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "902952b2da"+ "'", var8.equals("902952b2da"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.6923930026978242d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1.9158706753182937d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
// 
//   }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test367"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1935, 1.9999999f, 9.536743E-7f, 358);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test368"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var1.contract();
    int var3 = var1.start();
    float var4 = var1.getExpansionFactor();
    var1.setNumElements(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardMostRecentElements(11401);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test369"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(0, 1905);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1905);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test370"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1871, 40420L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-742911295));

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test371"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var8, var11);
    org.apache.commons.math3.random.RandomGenerator var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var15);
    org.apache.commons.math3.exception.util.Localizable var17 = null;
    org.apache.commons.math3.exception.OutOfRangeException var21 = new org.apache.commons.math3.exception.OutOfRangeException(var17, (java.lang.Number)0.049239138916696255d, (java.lang.Number)10.066508877759123d, (java.lang.Number)(-1.5707963267948966d));
    boolean var22 = var8.equals((java.lang.Object)0.049239138916696255d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test372"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.1756117415258828d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1919751743347324d);

  }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test373"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var4.addElement((-0.43408597923864894d));
//     double var10 = var4.getElement(0);
//     var4.clear();
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var13 = var12.getStandardDeviation();
//     double[] var15 = var12.sample(1);
//     double var16 = var12.getMean();
//     double[] var18 = var12.sample(100);
//     var4.addElements(var18);
//     double[] var20 = var4.getElements();
//     float var21 = var4.getExpansionFactor();
//     var4.clear();
//     double[] var23 = null;
//     var4.addElements(var23);
// 
//   }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test374"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test375"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(2.3841864E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3841866E-7f);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test376"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
    java.lang.Object var17 = null;
    boolean var18 = var4.equals(var17);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = var4.copy();
    var4.addElement(6.621888603197341d);
    var4.setElement(1848, 0.1708276255239572d);
    double[] var25 = var4.getInternalValues();
    var4.setElement(657, 0.025496167636629936d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test377"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.023928085890320375d, 8.139795503655945d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.023928085890320375d);

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test378"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     double var9 = var0.nextF(2.281783181607902d, 0.8427007929497151d);
//     double var12 = var0.nextGaussian(1.5498468927479463d, 1865.0d);
//     double var14 = var0.nextExponential(1.2042143530169682d);
//     double var17 = var0.nextGamma(0.2056151686980249d, 8.854558633913316d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var19 = var0.nextSecureHexString((-1912));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.2970669159914765d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.06323277405283767d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 244.3037755174555d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.4844006526735325d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.6124034029908156d);
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test379"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(9813, 9694);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test380"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
//     java.lang.Class var5 = var4.getDeclaringClass();
//     int var6 = var4.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
//     org.apache.commons.math3.random.RandomGenerator var8 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
//     org.apache.commons.math3.random.RandomGenerator var10 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
//     java.lang.Class var14 = var13.getDeclaringClass();
//     java.lang.String var15 = var13.toString();
//     java.lang.String var16 = var13.toString();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var13);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var22 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var25 = var24.getSupportUpperBound();
//     double[] var27 = var24.sample(10);
//     double var28 = var18.mannWhitneyU(var22, var27);
//     double[] var29 = var17.rank(var22);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var30 = var17.getNanStrategy();
//     java.lang.String var31 = var30.toString();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30);
//     java.lang.String var34 = var30.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "AVERAGE"+ "'", var16.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 21.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + "MAXIMAL"+ "'", var31.equals("MAXIMAL"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var34 + "' != '" + "MAXIMAL"+ "'", var34.equals("MAXIMAL"));
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test381"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var6);
    java.lang.String var9 = var6.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var10 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.Class var13 = var12.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    java.lang.String var15 = var12.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var12);
    org.apache.commons.math3.random.RandomGenerator var17 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var17);
    java.lang.String var19 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "AVERAGE"+ "'", var9.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "MAXIMAL"+ "'", var19.equals("MAXIMAL"));

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test382"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1.2040395048875416d);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test383"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(4.477444653656463d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test384"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(14.087081017797523d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test385"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2.3841866E-7f, 9099);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test386"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(1518);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test387"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var13 = var0.nextT(5.867156662812015d);
//     double var15 = var0.nextExponential(11.771947930619202d);
//     int var18 = var0.nextBinomial(0, 0.0031612049524534893d);
//     var0.reSeedSecure(2184L);
//     int var23 = var0.nextSecureInt(0, 2426);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var0.nextChiSquare((-0.13257979660911617d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9.87029653785763d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1f2a318bab"+ "'", var8.equals("1f2a318bab"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.061154832447118654d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2.9776548807095136d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 2340);
// 
//   }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test388"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var14 = var0.nextBeta(3628800.0d, 1.1752011936438014d);
//     java.lang.String var16 = var0.nextHexString(1859);
//     double var18 = var0.nextExponential(1.4814429877063329d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.0433441546207005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "392e0c2225"+ "'", var8.equals("392e0c2225"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.9999998134939262d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "d91eebab88d7316c84ffa5a35bec35562b6296821e4650d56ccb9323856e8af933fc7728c0018570aa09acb9454c684b52d265cf49b56242f1b25fd2e27646df4f7c581c9c5c5ac0c8802e0f86099ca940415a896c495f91b452d3075accaa0e41613e9b359ebbdca80c733aca979a5456aeb5b45d6a7c8f533f0453d8ec96e5ceebc0e6a364ef796ed631e4a1cb53dd1c8197e373a90f506b7eefab3176ba614ab69c6192a3657e6e914ccbd006cc6fab22d01e819616c39e5f94ab0e649f520ca28f6c851c85aa6c1e718bcee214521990561a6c8647d545a1cab1efb45834498525b370d3ad6e8674bb32701376cf9f0de907aaf1e8fa062fc3c8064e96266786addb3cd48e3aba5b3e2f6927c17c2aea87fefd1046279681d819317c500055258ede50278aa5a6d915523ca25bd2954da354b8b6b78f263a5bce4a51be74c68ef9f9f89ae2ea4b268f4f92f5b4c99175f6bf23c7d0474fb315d5aee5918338ff9ccc0b8a5d260fefde120d6083627f9a1c0ded52381c03650787718594378777a17ddd968f121a99439a41092c429b3fb031e977b06be0fe88bc4444f2d5549a2c01eff13c99f3ebd4abe0edc6e9c7ea44dcebf48a90a39a5c07683123ea079c45adeea93e7c0d9460d7aa8062832c34bafac60ea55301ae0a0bb48430e7c332a218ead27b41bb9ff92b8e918e89dee91cbec4c54d3643f1a7d5145af5e7efdbb6b32fa45fd4d095de16967e650dbe839400402194f3ebde9418edb78b393dc8ee897443a2a029ba33e801d4dc12f2f6a456cba6321731a28416fb433cb8cddb0e4afce422225d87153238ebad51dd02aa5bd02c88d683b3621666477fb5628063746907d9468e2510f2cd39cf98f8696a82d45cd9215b6134cd8e0293aea8b6ca6c63934c0143f689d88327b71cdcdc9e36abf4ed1d3316ac41e3ed2a54d6c560c3f77fa08c638e061a5429771a9778fa53cd0bbc819c6369e43f71a109b6df12e0116a474ec53b44101c740aedb7d6f3479f2a7c20281716cc88c31766b40bda6326e44d8f4a6c3b19418464f4036fb9d668f75f29343be183c72b18cc3ce9f6b72df103f3d81e5b8725261cb2b514bc2a0cd03dd583265798751b87aabf590ad7dc25dbb10307c9fa980042178d9c62d5243ea0f3472bae69ed66c4e4b139de705e25ebee8ee4a94e59c5bb3557ef5e62c9e0279ba4cf674602a38b3782359e23a258957d285034e3d267a7142770581c992c35e73f4eff7c015d49608b3aed54644ce67450861e1a401126f1f1184d78a9d884d87dd17c893e3b3cc107c"+ "'", var16.equals("d91eebab88d7316c84ffa5a35bec35562b6296821e4650d56ccb9323856e8af933fc7728c0018570aa09acb9454c684b52d265cf49b56242f1b25fd2e27646df4f7c581c9c5c5ac0c8802e0f86099ca940415a896c495f91b452d3075accaa0e41613e9b359ebbdca80c733aca979a5456aeb5b45d6a7c8f533f0453d8ec96e5ceebc0e6a364ef796ed631e4a1cb53dd1c8197e373a90f506b7eefab3176ba614ab69c6192a3657e6e914ccbd006cc6fab22d01e819616c39e5f94ab0e649f520ca28f6c851c85aa6c1e718bcee214521990561a6c8647d545a1cab1efb45834498525b370d3ad6e8674bb32701376cf9f0de907aaf1e8fa062fc3c8064e96266786addb3cd48e3aba5b3e2f6927c17c2aea87fefd1046279681d819317c500055258ede50278aa5a6d915523ca25bd2954da354b8b6b78f263a5bce4a51be74c68ef9f9f89ae2ea4b268f4f92f5b4c99175f6bf23c7d0474fb315d5aee5918338ff9ccc0b8a5d260fefde120d6083627f9a1c0ded52381c03650787718594378777a17ddd968f121a99439a41092c429b3fb031e977b06be0fe88bc4444f2d5549a2c01eff13c99f3ebd4abe0edc6e9c7ea44dcebf48a90a39a5c07683123ea079c45adeea93e7c0d9460d7aa8062832c34bafac60ea55301ae0a0bb48430e7c332a218ead27b41bb9ff92b8e918e89dee91cbec4c54d3643f1a7d5145af5e7efdbb6b32fa45fd4d095de16967e650dbe839400402194f3ebde9418edb78b393dc8ee897443a2a029ba33e801d4dc12f2f6a456cba6321731a28416fb433cb8cddb0e4afce422225d87153238ebad51dd02aa5bd02c88d683b3621666477fb5628063746907d9468e2510f2cd39cf98f8696a82d45cd9215b6134cd8e0293aea8b6ca6c63934c0143f689d88327b71cdcdc9e36abf4ed1d3316ac41e3ed2a54d6c560c3f77fa08c638e061a5429771a9778fa53cd0bbc819c6369e43f71a109b6df12e0116a474ec53b44101c740aedb7d6f3479f2a7c20281716cc88c31766b40bda6326e44d8f4a6c3b19418464f4036fb9d668f75f29343be183c72b18cc3ce9f6b72df103f3d81e5b8725261cb2b514bc2a0cd03dd583265798751b87aabf590ad7dc25dbb10307c9fa980042178d9c62d5243ea0f3472bae69ed66c4e4b139de705e25ebee8ee4a94e59c5bb3557ef5e62c9e0279ba4cf674602a38b3782359e23a258957d285034e3d267a7142770581c992c35e73f4eff7c015d49608b3aed54644ce67450861e1a401126f1f1184d78a9d884d87dd17c893e3b3cc107c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.12517476443833161d);
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test389"); }


    double var2 = org.apache.commons.math3.special.Erf.erf((-0.9570437588131924d), 7.673593990950069d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.8240926407168747d);

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test390"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextWeibull(7.769493748166378d, 1.2185657441986304d);
//     int var9 = var0.nextPascal(1980, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextT((-0.8961189234469322d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0516963035483042d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2147483647);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test391"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1953);

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test392"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(0.7840974525462412d, (-1.2732919183123732d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test393"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-64L), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test394"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-0.05116808664027965d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 18.878748104649713d);

  }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test395"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(0L);
//     int var18 = var0.nextBinomial(0, 0.33421337133949025d);
//     double var21 = var0.nextGamma(2.773881834450058d, 0.6472141263376315d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var24 = var0.nextPermutation(1906, 2041);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15.413807128107193d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "bffa7a2004"+ "'", var8.equals("bffa7a2004"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.4847822663991246d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 9914);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.7025354688027076d);
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test396"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(3.4456677746279425d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.950686158843932d);

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test397"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(0.08704338813520823d);
//     int[] var6 = var1.nextPermutation(2041, 321);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.916597781187384E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test398"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var21 = var18.nextSecureLong((-1L), 1L);
//     double var24 = var18.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var26 = var18.nextSecureHexString(100);
//     double var28 = var18.nextT(20.696514663540924d);
//     org.apache.commons.math3.distribution.NormalDistribution var29 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var30 = var29.getStandardDeviation();
//     double[] var32 = var29.sample(1);
//     double var33 = var29.getMean();
//     double[] var35 = var29.sample(100);
//     double var36 = var29.sample();
//     double var37 = var29.sample();
//     double var38 = var18.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     double var39 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     org.apache.commons.math3.distribution.NormalDistribution var40 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var41 = var40.getStandardDeviation();
//     double[] var43 = var40.sample(1);
//     double var44 = var40.getMean();
//     double[] var46 = var40.sample(100);
//     double var47 = var40.sample();
//     double var48 = var40.sample();
//     var40.reseedRandomGenerator(10L);
//     boolean var51 = var40.isSupportLowerBoundInclusive();
//     boolean var52 = var40.isSupportLowerBoundInclusive();
//     double var53 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var40);
//     double var57 = var0.nextUniform(0.8847656390164815d, 4.602898490399665d, true);
//     var0.reSeedSecure(2985984L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12.640810081897039d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "0a3bd4157e0fafbcfee640fa4f56084e90f2d69737986a97b670713b89dc7ee9c71a94e9a1cebef06fd05dc7ce05ba802b78"+ "'", var8.equals("0a3bd4157e0fafbcfee640fa4f56084e90f2d69737986a97b670713b89dc7ee9c71a94e9a1cebef06fd05dc7ce05ba802b78"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.09802909440074205d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 18.61783845859009d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "dbb3ef4ec9c6f7b27b8137f90098bc2a5d5adbc60f791195429e5280dd13a7ed089a70371a28053b66c67381efa67e232836"+ "'", var26.equals("dbb3ef4ec9c6f7b27b8137f90098bc2a5d5adbc60f791195429e5280dd13a7ed089a70371a28053b66c67381efa67e232836"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.3955479014339429d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1.272460079623414d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == (-0.8159290282824452d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == (-0.34502233348181227d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0.8864194471526715d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0.17868112916583714d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == (-0.26682424077519634d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == (-0.29544854101399287d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 3.4451391713380066d);
// 
//   }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test399"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.10097702336242761d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test400"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(0.5395119302779527d, (-0.2492596627920229d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextHypergeometric(89, 1911, 17190);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.008732564388176047d));
// 
//   }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test401"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)4.836250408008647d, (java.lang.Number)1818, false);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test402"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    java.lang.String var3 = var1.toString();
    java.lang.Number var4 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"+ "'", var3.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test403"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getSupportLowerBound();
//     double var5 = var0.sample();
//     double var6 = var0.getNumericalMean();
//     double var8 = var0.density((-1.0712332264705697d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.16535819531381177d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.22476298186264465d);
// 
//   }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test404"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.9969572613201069d, (-13.47212398709439d), 0.02629215190910916d, 295783);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test405"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(7.788896578666913d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.0d);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test406"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.9999999f, 2.384186E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9999999f);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test407"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(1.6601269939065664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 95.11827020658679d);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test408"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(2419200L, 31L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2419231L);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test409"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)6.525428235622169d, (java.lang.Number)3.3113021230333133d, false);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test410"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.contract();
    int var8 = var6.getExpansionMode();
    var6.setElement(5, 20.696514663540924d);
    var6.setNumElements(1);
    int var14 = var6.getNumElements();
    var6.setElement(15, (-0.47353996882709365d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test411"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    var0.reseedRandomGenerator(0L);
    double var4 = var0.probability(15.685448285813305d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test412"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-0.6393101510513624d), (java.lang.Number)0.9306833085324375d, false);

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test413"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
//     org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
//     org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
//     boolean var12 = var4.equals((java.lang.Object)var5);
//     var4.addElement(20.696514663540924d);
//     double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
//     java.lang.Object var17 = null;
//     boolean var18 = var4.equals(var17);
//     var4.setElement(100, 0.0d);
//     double[] var22 = var4.getInternalValues();
//     float var23 = var4.getExpansionFactor();
//     org.apache.commons.math3.exception.util.Localizable var24 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var28 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var24, (java.lang.Number)9.536743E-7f, (java.lang.Number)(-0.4255538433808183d), false);
//     boolean var29 = var4.equals((java.lang.Object)(-0.4255538433808183d));
//     float var30 = var4.getContractionCriteria();
//     double var32 = var4.addElementRolling(0.31121875525665216d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 20.696514663540924d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1.7867647271418194d);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test414"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo((-1137L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test415"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "f78c23674a");
// 
//   }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test416"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     int var7 = var6.getNumElements();
//     double var9 = var6.substituteMostRecentElement(31.862892444737472d);
//     var6.setNumElements(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var6.setExpansionMode(48);
//       fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
//     } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.22196756498883002d);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test417"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(118.85224728988739d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5623827172383655d);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test418"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(231.0d, 0.4391773457503936d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 231.0d);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test419"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(2097152.5f, (-1.4E-45f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.4E-45f));

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test420"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var1.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test421"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(284);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1324.0524027171775d);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test422"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(6.974265758840565d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9105841217415027d);

  }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test423"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var26 = var14.getStandardDeviation();
//     double var27 = var14.getStandardDeviation();
//     boolean var28 = var14.isSupportUpperBoundInclusive();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var30 = var14.inverseCumulativeProbability(53.55770964457071d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.585444796756933d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5f6cd2b511"+ "'", var8.equals("5f6cd2b511"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1857);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.017622735430789942d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 2.2118322412834335d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-2.5898121755280408d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.3198801916444454d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-0.4764536800408615d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
// 
//   }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test424"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("3e4d73047825023eda6ac72bf50ab7b04ead8f6e2bea74472b8b925996412c5d4b5af73c3aaa98d46e8c2e181c2d6a28b415");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test425"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
    java.lang.Object var17 = null;
    boolean var18 = var4.equals(var17);
    var4.setElement(100, 0.0d);
    int var22 = var4.getExpansionMode();
    float var23 = var4.getContractionCriteria();
    var4.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2.5f);

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test426"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     double var30 = var0.nextExponential(1.0471975511965979d);
//     java.lang.String var32 = var0.nextSecureHexString(1916);
//     double var35 = var0.nextBeta(2.5078368197853713d, 0.2555837818987815d);
//     long var38 = var0.nextSecureLong((-1342601562L), 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10.29609908192494d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f68b09b695"+ "'", var8.equals("f68b09b695"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1860);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.02550269267928422d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.4205756256308126d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.8434792106760413d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-1.0934733366438454d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-0.36154324753123307d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1041.5382028153115d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.6315529355325906d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var32 + "' != '" + "496695b631702fb854148fcceba0cedbc95d26cee4e2414d0b3fe2635430340828723e22509a3730ffb94a1b719b4502441361b617f078ab7325b43ce4588364b984e9d2173e4636c80bc1ce4839ea9e82af00bdc673861605cb77aef95a7294bb482d32d6a6062203aadc43aec90861ce3ab23e577c047f92d4e31f2e9d7f98db1f7ab6b917de26f7b3ace0b681ddcf2dba1f8a98c71a815efbb1e9b3f26fa93a230ac49e919cd1adb315bb5660dec3b5b751cc2292e3abf9a209faaf7ed212a29ee93d5557bc69d09902bc61b1746caa93c5e5447f830624098f637ed89b3e072c004a9b8e40cde00920a614de0ad860e76c865e297d4689ae3ffc0e8315547253224228b6a5063791266acc7439a034ae1f57b8903b8c918b62aa2910b9a9c0514da906c32094d6cfd3d4924b6a988198ca808f5e288280fc6dc91d381576602673750063bafbc1006c839ac0cdb445d863b2bbbb501feb242f97cb0f220b7d9b0e977e3dc8dd7b784ee4307ee3c46f24517b7e41204773ba6646f6d2ea0d28f43c9aacf8afaa5148ae645affe2e48105eafad538d81fe7d923a639cda8facd9ff50e8dfab7fa3dfd7d93f36607863f23adc975c3c3e235431aea68aa4b24a22bc222276b1765fc28911e53287baff580f8e5f960de487de458edb0351a6ae1420040dcc5fdfc606b321dccc05cdbc6347ab07dce1a62e64fd5688499b5798f999a6d2c2481ad2b43df968c00b2c8074e20909175c7b389117f0a8af30872ca85eb935768f410b01dfde8e9be7fd85873a383e5625b7c33d7e9a18639c0c6572e479cd88a85609fe22839a81049a724c8a5a579d2893ef3cde4f810c6590a6cd9a8858f828b28c74e48dc04d67d2cd07d504516731e3df9d2e72815db9bc58aabee429bb5c3c931a6f1d98357f0a0c538fb516147c110b0aded2eed2b84c1521de34ef4093be3f2289837000e8fb6807b0cb351b951d6c8292a760e33733a2a2c1b032d0f5c54c870faf10ecb040e05e0d4eb4a033d5b78c0e6514566b7b5223069ff667e710d7c6307314b31e254f549dfc2d011087e99d66d6459a0683cfcd7d56a019f44580182cde5f3000426ba5631dd6bb2900b0441bac98ec1e5bbaabeb66b945e13b287d50343c9af6873c4426e39e621deafa8afdafc11e34c96f72d5743e72e36617e5b1f7870672f201e874fbd5e8e553b0816461019f91aface33ebf86316fa78376fb025d9fd903336b46b2da637c3b28cb61efa2fb742abbcfc4cfe4893241e853433f8f2f0cf4661a78de8204346f75778bd98eb1638083cf6e460b54b121fe63b1efacb34cdac68a643daa83f4747855dcbd6b1a5"+ "'", var32.equals("496695b631702fb854148fcceba0cedbc95d26cee4e2414d0b3fe2635430340828723e22509a3730ffb94a1b719b4502441361b617f078ab7325b43ce4588364b984e9d2173e4636c80bc1ce4839ea9e82af00bdc673861605cb77aef95a7294bb482d32d6a6062203aadc43aec90861ce3ab23e577c047f92d4e31f2e9d7f98db1f7ab6b917de26f7b3ace0b681ddcf2dba1f8a98c71a815efbb1e9b3f26fa93a230ac49e919cd1adb315bb5660dec3b5b751cc2292e3abf9a209faaf7ed212a29ee93d5557bc69d09902bc61b1746caa93c5e5447f830624098f637ed89b3e072c004a9b8e40cde00920a614de0ad860e76c865e297d4689ae3ffc0e8315547253224228b6a5063791266acc7439a034ae1f57b8903b8c918b62aa2910b9a9c0514da906c32094d6cfd3d4924b6a988198ca808f5e288280fc6dc91d381576602673750063bafbc1006c839ac0cdb445d863b2bbbb501feb242f97cb0f220b7d9b0e977e3dc8dd7b784ee4307ee3c46f24517b7e41204773ba6646f6d2ea0d28f43c9aacf8afaa5148ae645affe2e48105eafad538d81fe7d923a639cda8facd9ff50e8dfab7fa3dfd7d93f36607863f23adc975c3c3e235431aea68aa4b24a22bc222276b1765fc28911e53287baff580f8e5f960de487de458edb0351a6ae1420040dcc5fdfc606b321dccc05cdbc6347ab07dce1a62e64fd5688499b5798f999a6d2c2481ad2b43df968c00b2c8074e20909175c7b389117f0a8af30872ca85eb935768f410b01dfde8e9be7fd85873a383e5625b7c33d7e9a18639c0c6572e479cd88a85609fe22839a81049a724c8a5a579d2893ef3cde4f810c6590a6cd9a8858f828b28c74e48dc04d67d2cd07d504516731e3df9d2e72815db9bc58aabee429bb5c3c931a6f1d98357f0a0c538fb516147c110b0aded2eed2b84c1521de34ef4093be3f2289837000e8fb6807b0cb351b951d6c8292a760e33733a2a2c1b032d0f5c54c870faf10ecb040e05e0d4eb4a033d5b78c0e6514566b7b5223069ff667e710d7c6307314b31e254f549dfc2d011087e99d66d6459a0683cfcd7d56a019f44580182cde5f3000426ba5631dd6bb2900b0441bac98ec1e5bbaabeb66b945e13b287d50343c9af6873c4426e39e621deafa8afdafc11e34c96f72d5743e72e36617e5b1f7870672f201e874fbd5e8e553b0816461019f91aface33ebf86316fa78376fb025d9fd903336b46b2da637c3b28cb61efa2fb742abbcfc4cfe4893241e853433f8f2f0cf4661a78de8204346f75778bd98eb1638083cf6e460b54b121fe63b1efacb34cdac68a643daa83f4747855dcbd6b1a5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0.8491407412961128d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == (-981430172L));
// 
//   }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test427"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextUniform(0.2577047455984825d, 13.770182159584014d);
//     long var6 = var1.nextPoisson(23.012289905639566d);
//     int var9 = var1.nextZipf(10178, 0.5950413774252329d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextChiSquare((-1.9158706753182937d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.6796479235191941d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 24L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1482);
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test428"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(1348L, 15936L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 21481728L);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test429"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.contract();
    int var8 = var6.getExpansionMode();
    var6.setElement(5, 20.696514663540924d);
    var6.setNumElements(1);
    int var14 = var6.getNumElements();
    double[] var15 = var6.getElements();
    org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var17 = var16.getStandardDeviation();
    double[] var19 = var16.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    var20.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var22 = var20.copy();
    var22.contract();
    int var24 = var22.getExpansionMode();
    var22.setElement(5, 20.696514663540924d);
    var22.setNumElements(1);
    int var30 = var22.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var6, var22);
    float var32 = var6.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 2.0f);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test430"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos((-3.4276683869607285d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-14.712053994093406d));

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test431"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 243);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 4L);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 40486L);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 1518);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test432"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1972);
    float var2 = var1.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5f);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test433"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(3.1855205836148377d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 24.17987277552836d);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test434"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double var3 = var0.inverseCumulativeProbability(0.9999999999928669d);
    double var4 = var0.getNumericalVariance();
    double var5 = var0.getStandardDeviation();
    double var6 = var0.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 6.755176609774487d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test435"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     int var20 = var0.nextBinomial(0, 0.7615941559557649d);
//     double var23 = var0.nextWeibull(1.2075656224493654d, 2.265662238504449d);
//     var0.reSeedSecure(40318L);
//     org.apache.commons.math3.distribution.NormalDistribution var26 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var27 = var26.getSupportUpperBound();
//     double var29 = var26.inverseCumulativeProbability(0.9999999999928669d);
//     double var31 = var26.density(25.472636453138065d);
//     double var32 = var26.getMean();
//     double var33 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var26);
//     int var36 = var0.nextPascal(80, 0.9999999627393439d);
//     int var39 = var0.nextPascal(178, 0.5652287876516469d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.0283679332088984d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "41dfec96a73fab9c2a8926cae251b3d9156be21ee1a6bf4c7f4e6dc977d03ee897cb1eed4fe98a8aa5da174ba490a1a1359d"+ "'", var8.equals("41dfec96a73fab9c2a8926cae251b3d9156be21ee1a6bf4c7f4e6dc977d03ee897cb1eed4fe98a8aa5da174ba490a1a1359d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.08606053377252651d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 2.4377532592900923d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 6.755176609774487d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 5.055823438644928E-142d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == (-0.7421833833606966d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 132);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test436"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    int var5 = var3.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 3);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test437"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-1.0480925762101703d), 1.8325125324523532d, (-0.7719096331877858d), 10398);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test438"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)7055, false);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test439"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)0.99999994f, (java.lang.Number)(-1.1998905478105057d));

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test440"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(2097152.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test441"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(100.00001f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test442"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-0.7145944252763202d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0d));

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test443"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.3803289310416418d, 1.139625305696608d);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test444"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(2021567837087569569L, 89239914473837L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2021657077002043406L);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test445"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    var4.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var4.copy();
    int var10 = var4.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    float var12 = var11.getContractionCriteria();
    var11.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.5f);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test446"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-249L), 40326L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3L);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test447"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 45);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test448"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var6);
    java.lang.String var9 = var6.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var10 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.Class var12 = var2.getDeclaringClass();
    java.lang.Class var13 = var2.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "AVERAGE"+ "'", var9.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test449"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)16.929171950095395d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test450"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)10.629103431631437d, (java.lang.Number)(-7.409550648796562d), false);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test451"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(9066);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9066);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test452"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    double[] var6 = var4.getInternalValues();
    org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var8 = var7.getStandardDeviation();
    double[] var10 = var7.sample(1);
    double var11 = var7.getMean();
    double[] var13 = var7.sample(100);
    var4.addElements(var13);
    int var15 = var4.getExpansionMode();
    var4.addElement(0.0d);
    org.apache.commons.math3.distribution.NormalDistribution var18 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var19 = var18.getStandardDeviation();
    double[] var21 = var18.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var21);
    org.apache.commons.math3.exception.util.Localizable var23 = null;
    org.apache.commons.math3.exception.util.Localizable var24 = null;
    org.apache.commons.math3.exception.util.Localizable var25 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var26 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var27 = new org.apache.commons.math3.exception.NullArgumentException(var25, (java.lang.Object[])var26);
    org.apache.commons.math3.exception.MathInternalError var28 = new org.apache.commons.math3.exception.MathInternalError(var24, (java.lang.Object[])var26);
    org.apache.commons.math3.exception.NullArgumentException var29 = new org.apache.commons.math3.exception.NullArgumentException(var23, (java.lang.Object[])var26);
    boolean var30 = var22.equals((java.lang.Object)var23);
    var22.addElement(20.696514663540924d);
    double var34 = var22.substituteMostRecentElement((-1.84544373783414d));
    java.lang.Object var35 = null;
    boolean var36 = var22.equals(var35);
    int var37 = var22.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 2);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test453"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)15.537140806031395d);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test454"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.7044581484917243d, (-0.6626065888373917d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9415661936552444d);

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test455"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     var0.reSeed();
//     double var15 = var0.nextChiSquare(7.617953921806563d);
//     double var17 = var0.nextExponential(1.5574077246549007d);
//     org.apache.commons.math3.distribution.NormalDistribution var21 = new org.apache.commons.math3.distribution.NormalDistribution(0.8259324122591327d, 0.2782029380240531d, 0.0d);
//     double var22 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var21);
//     double var24 = var0.nextT(0.2160727732320313d);
//     double var27 = var0.nextGamma(18.827809487697202d, 15.2715815643462d);
//     int var30 = var0.nextZipf(751, 0.849872022320529d);
//     double var33 = var0.nextWeibull(2.3611676403812423d, 13.359855606410402d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.765619013094787d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "bb711a082c"+ "'", var8.equals("bb711a082c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 9.09044316038733d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.4625972558324338d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.7142914699311617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.16952774032729226d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 352.2898903228096d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 475);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 8.154757082725945d);
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test456"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    var0.reseedRandomGenerator(2L);
    double[] var4 = var0.sample(100000);
    double var5 = var0.getMean();
    double var6 = var0.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-0.12950233604031103d));

  }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test457"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     double var11 = var0.nextUniform(1.9243072677253843d, 7.362895734466076d);
//     var0.reSeedSecure(64L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var16 = var0.nextPermutation(45, 4337);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10.009168748638828d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "e7f1f53228d06f37362893bf58186867b58ee9fe09d8654119205cfb8d39b1c96402084e1cfde2b8c79365adebd9aa671a16"+ "'", var8.equals("e7f1f53228d06f37362893bf58186867b58ee9fe09d8654119205cfb8d39b1c96402084e1cfde2b8c79365adebd9aa671a16"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 7.298196257588844d);
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test458"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-1.0788989510357758d), (java.lang.Number)152.58161863441052d, false);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test459"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 243);
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, var14);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 11L);
    java.math.BigInteger var18 = null;
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 0L);
    java.math.BigInteger var21 = null;
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 0L);
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, var23);
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 1949);
    java.math.BigInteger var27 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, var26);
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 11L);
    java.math.BigInteger var31 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 1L);
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, var17);
    java.math.BigInteger var34 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 14L);
    java.math.BigInteger var35 = null;
    java.math.BigInteger var37 = org.apache.commons.math3.util.ArithmeticUtils.pow(var35, 0L);
    java.math.BigInteger var38 = null;
    java.math.BigInteger var40 = org.apache.commons.math3.util.ArithmeticUtils.pow(var38, 0L);
    java.math.BigInteger var41 = org.apache.commons.math3.util.ArithmeticUtils.pow(var37, var40);
    java.math.BigInteger var43 = org.apache.commons.math3.util.ArithmeticUtils.pow(var37, 11L);
    java.math.BigInteger var44 = null;
    java.math.BigInteger var46 = org.apache.commons.math3.util.ArithmeticUtils.pow(var44, 0L);
    java.math.BigInteger var47 = null;
    java.math.BigInteger var49 = org.apache.commons.math3.util.ArithmeticUtils.pow(var47, 0L);
    java.math.BigInteger var50 = org.apache.commons.math3.util.ArithmeticUtils.pow(var46, var49);
    java.math.BigInteger var52 = org.apache.commons.math3.util.ArithmeticUtils.pow(var50, 1949);
    java.math.BigInteger var53 = org.apache.commons.math3.util.ArithmeticUtils.pow(var43, var52);
    java.math.BigInteger var55 = org.apache.commons.math3.util.ArithmeticUtils.pow(var43, 11L);
    java.math.BigInteger var57 = org.apache.commons.math3.util.ArithmeticUtils.pow(var43, 1L);
    java.math.BigInteger var58 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, var43);
    java.math.BigInteger var59 = null;
    java.math.BigInteger var61 = org.apache.commons.math3.util.ArithmeticUtils.pow(var59, 0L);
    java.math.BigInteger var62 = null;
    java.math.BigInteger var64 = org.apache.commons.math3.util.ArithmeticUtils.pow(var62, 0L);
    java.math.BigInteger var65 = org.apache.commons.math3.util.ArithmeticUtils.pow(var61, var64);
    java.math.BigInteger var67 = org.apache.commons.math3.util.ArithmeticUtils.pow(var61, 11L);
    java.math.BigInteger var68 = null;
    java.math.BigInteger var70 = org.apache.commons.math3.util.ArithmeticUtils.pow(var68, 0L);
    java.math.BigInteger var71 = null;
    java.math.BigInteger var73 = org.apache.commons.math3.util.ArithmeticUtils.pow(var71, 0L);
    java.math.BigInteger var74 = org.apache.commons.math3.util.ArithmeticUtils.pow(var70, var73);
    java.math.BigInteger var76 = org.apache.commons.math3.util.ArithmeticUtils.pow(var74, 1949);
    java.math.BigInteger var77 = org.apache.commons.math3.util.ArithmeticUtils.pow(var67, var76);
    java.math.BigInteger var79 = org.apache.commons.math3.util.ArithmeticUtils.pow(var67, 11L);
    java.math.BigInteger var81 = org.apache.commons.math3.util.ArithmeticUtils.pow(var67, 1L);
    java.math.BigInteger var83 = org.apache.commons.math3.util.ArithmeticUtils.pow(var81, 2147483647);
    java.math.BigInteger var84 = org.apache.commons.math3.util.ArithmeticUtils.pow(var43, var81);
    java.math.BigInteger var86 = org.apache.commons.math3.util.ArithmeticUtils.pow(var43, 3376);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test460"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)1.1629595418829466d, false);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.1629595418829466d+ "'", var5.equals(1.1629595418829466d));

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test461"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.clear();
    float var8 = var6.getExpansionFactor();
    var6.setContractionCriteria(2.0f);
    float var11 = var6.getContractionCriteria();
    org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var13 = var12.getStandardDeviation();
    double[] var15 = var12.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    var16.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = var16.copy();
    float var19 = var16.getContractionCriteria();
    var16.setNumElements(1818);
    double[] var22 = var16.getElements();
    var6.addElements(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test462"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(1868);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test463"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(9.486666117215478d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11.660038913667586d);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test464"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    var4.setElement(1931, 0.2577047455984825d);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setExpansionMode(1940);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test465"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextUniform(0.2577047455984825d, 13.770182159584014d);
//     long var6 = var1.nextPoisson(23.012289905639566d);
//     int var9 = var1.nextZipf(10178, 0.5950413774252329d);
//     double var12 = var1.nextF(0.8057138887308153d, 5.668146255993159d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var14 = var1.nextHexString(193982305);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4.458588520507795d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 33L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3054);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.8777985454007863d);
// 
//   }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test466"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     long var31 = var0.nextSecureLong(4L, 17L);
//     java.lang.String var33 = var0.nextSecureHexString(9813);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.151525743674435d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "cf8ecbd27f"+ "'", var8.equals("cf8ecbd27f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1924);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.003241056024798808d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1.0731953090072135d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-1.3148397497450302d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.1764703334688625d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-0.6210374341363053d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1.0629389066314468E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 4L);
// 
//   }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test467"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 8899);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test468"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.5131053078208063d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test469"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(792111645L, 2021567837087569569L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test470"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     double var5 = var0.nextChiSquare(7.6675647339750626d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("", "3d8daa534014dba79b47668622f5f09c1ea6f76abc16f98d061ba79de8651dc243ce80d1efc046022695be851339d732e30085e0debe55a1da874a8d5f3500bbc004bbe427b56af60f846573944d053766a6d8a99372fd6225e4c3371fd0243cf85ead703a7f4acc084a22d2a8cb1ac4f8438335f5b4ce3b4f36f22c9da06a1fa8ad99e8665a03a1e81bb4ba0f216cb816155b39b218316552b3e78b5f63326bce182db914e73a930bbbf3a8ac441696b615161d91cdf7ee189f5e1c02798ad26793bcfa8dc75e5683167a908901c9f45aeec3dc60e6a9a1901a26c7f7579e4ed0897040c97d2e1b630c7685e5da4d44c0eecd346394c839d1d7fbc042c277f268d8dc32812a752feac24cabf8afbc2b1a895176b380db90011b62a510f6b59ba8d8da48b8b673a11d712b9a5675f8d8d924ea7e2cb8833917bf0148a26bf33fe01fcc848bab4715e5d188672f84705dff7cae06bcc4b64b282b98c600ef15006f66f671617a38c1311b1a637d2c6741ffeb64f05c898b17ce1b6f3159f5ec2b50bad901de5b1731423ce65272d360c5fcff2c7541bef8307af18e52bd8ff613d025e5a8cc3db058e2f075580cadab902e9ed52bf8f994ae76af7c5eee63b090b6f4ba35d3f76cec4d9d635a739713fcf4877f947a1a4030ff0eceee7749ceb7545e1defca223fbc18d671d6f3b29607cc2fe68c57b8157fd4e9656aff0c4929b38cd0ea042b604e4a8e7d4e84090ca20dffaf6a3bc176686a83d0678f930eb04df46d736fea5bdf0a63bafa0813d6067b466a1bca39dfa11aa796b8053c849778a9dcef5e7d3c28f275b0908b12497e9c3b9088225be96e4139f594df6cca0d7bd55192c8f540cb2a377d1de71a4f00bc49ccaf1f878d3f79294963ea6b33e9f0b992897de509f03ed1a30ca4696c45bf69ef965be755723cdf3005e138ba722cb6e9ac8d7e05aca24ff5dc4590aed6ef29b0db8b9a34648ea311344529d2d0274d942a1bb2280c866ea4be99eba637251efa4f4282e518738c084f786baf5f293fc9d836043ae2bc3fb3e0cb1b02482005c4fd4ea7cb7c9e0c6c45b5d37ae2275849c616f688e36148b4580abc4b2691cb4213d682eb8624c8cf7005e5ac88fc1e6dc50478fa929cd53ae324e588d19725fe417279d74b3c76ecc45e72d36097f29d1abc9151d878985f3b52648d9189a601cd2d4bf2a46c5955ce5fbf0a06c93b9991fde61ee070901ef14e083a4d08c4efbe145088f45e96ec4a3828ce69cafa77a4d5f19d3f4dafbf803e92305381367defa7bde3773e5f004a36ff5523ecae10a5d57cbbf5b8bb947a4a1befed135951547f3b64d6e9");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.198389849588379d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 9.123190768409978d);
// 
//   }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test471"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-0.2082601007031496d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.817532825563339d);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test472"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(5.775578026902914E10d, 1.1675832066593317d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267746807d);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test473"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.15729920705028488d, (java.lang.Number)(short)(-1), false);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var4.getContext();
    boolean var7 = var4.getBoundIsAllowed();
    boolean var8 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test474"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.0829146515457011E-75d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.29076685826526E-38d);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test475"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-1.0328453233143338d), 0.2160727732320313d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0552046745653052d);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test476"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.9999996476336123d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13.147783281397828d);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test477"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(49.89155550935021d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.6813661512996854d);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test478"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(4.879522481508616d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6883773232746482d);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test479"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1518, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test480"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(36, 105300);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 105300);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test481"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    java.lang.Class var6 = var4.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    java.lang.String var8 = var4.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    java.lang.String var10 = var2.name();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "MAXIMAL"+ "'", var10.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test482"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.Class var5 = var2.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var7 = java.lang.Enum.<java.lang.Enum>valueOf(var5, "c4e2a6867a");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test483"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.contract();
    int var8 = var6.getExpansionMode();
    var6.setElement(5, 20.696514663540924d);
    var6.setNumElements(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setExpansionMode(20355979);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test484"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(6005197975992252401L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.9433423235185356d);
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test485"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(323);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test486"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var3);
    java.lang.String var6 = var3.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = var7.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test487"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-0.582693261274406d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7239355787101731d));

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test488"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(7, 185482209);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test489"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     var0.reSeed(14L);
//     double var14 = var0.nextExponential(0.9999997887160175d);
//     long var16 = var0.nextPoisson(0.8259324122591327d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var0.nextWeibull(1.0403360105039516d, (-1.526192903006268d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.3521631458498318d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "7e42d5a779"+ "'", var8.equals("7e42d5a779"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.2216433219645861d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.3844973909690124d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0L);
// 
//   }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test490"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(11.711799887012498d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6565423659258071d);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test491"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(617L, 5L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 612L);

  }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test492"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     java.lang.String var13 = var0.nextHexString(10);
//     var0.reSeedSecure();
//     double var17 = var0.nextBeta(20441.91590500824d, 11.711799887012498d);
//     double var20 = var0.nextWeibull(21.78619629460335d, 1.5120484726447734d);
//     double var23 = var0.nextGamma(1.527066384736393d, 0.04378400432753371d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.230043242903053d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f069f921ed"+ "'", var8.equals("f069f921ed"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "f38173fd24"+ "'", var13.equals("f38173fd24"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.9996481675647524d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.456279288377579d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.09872462348864744d);
// 
//   }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test493"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)185482209, (java.lang.Number)8.738784040374396d, true);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test494"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var13 = var10.nextSecureLong((-1L), 1L);
//     double var16 = var10.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var18 = var10.nextHexString(10);
//     int var21 = var10.nextPascal(8899, 0.8219866295031046d);
//     double var23 = var10.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var25 = var24.getStandardDeviation();
//     double[] var27 = var24.sample(1);
//     double var28 = var24.getMean();
//     double[] var30 = var24.sample(100);
//     double var31 = var24.sample();
//     double var32 = var24.sample();
//     double var33 = var24.getStandardDeviation();
//     double var34 = var24.sample();
//     double var35 = var10.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     double var36 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     org.apache.commons.math3.distribution.NormalDistribution var37 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var38 = var37.getStandardDeviation();
//     boolean var39 = var37.isSupportUpperBoundInclusive();
//     double[] var41 = var37.sample(100);
//     double var42 = var37.getNumericalVariance();
//     double var43 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var37);
//     boolean var44 = var37.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 23.381622949250797d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f912c03dc39d0b5c1de56a878c84e7969d776ae975aab486b65cd37578d8339793b564eaa3f78947a1f4a24e2c87b94d6b7e"+ "'", var8.equals("f912c03dc39d0b5c1de56a878c84e7969d776ae975aab486b65cd37578d8339793b564eaa3f78947a1f4a24e2c87b94d6b7e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.97804829978041d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "695f2da9f7"+ "'", var18.equals("695f2da9f7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1979);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.010538873713833203d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == (-0.08773313925213035d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == (-0.3759503635979353d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == (-0.9735083947956412d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == (-0.5559679641734987d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == (-1.1207239467210723d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == (-1.169994498907126d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == true);
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test495"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test496"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(7.042014262199385d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 571.8440515901871d);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test497"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1933, 1499);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test498"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(1903, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test499"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(1935, 100000);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 193500000);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test500"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(25L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 25L);

  }

}
