
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 363.7393755555636d);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-1.0d), 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-1.0d), 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0d));

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0L, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.15729920705028488d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100L);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4.440892098500626E-16d));

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-1), 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(100.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.0f);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p((-4.440892098500626E-16d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4.440892098500627E-16d));

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7615941559557649d);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-4.440892098500627E-16d), (-1.0d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.010050166663333094d);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(10.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0f);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.7615941559557649d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-4.440892098500627E-16d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999999999996d);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(0);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.0f);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-1), 100.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-1), 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1L));
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.apache.commons.math3.exception.NullArgumentException var0 = new org.apache.commons.math3.exception.NullArgumentException();

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.0d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(100.0d, (-4.440892098500626E-16d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0d);

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var2 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var1);
//     double[] var6 = new double[] { 0.0d, 1.0d, 10.0d};
//     double[] var9 = new double[] { 10.0d, 1.0d};
//     double var10 = var2.mannWhitneyUTest(var6, var9);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(100, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.0d, Double.NEGATIVE_INFINITY, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1752011936438014d);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, 0.7615941559557649d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.15729920705028488d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.15795521463156686d);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(10L, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10L);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1.0f)+ "'", var5.equals((-1.0f)));

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0f));

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.0d, 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8427007929497151d);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(100, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(10, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.010050166663333094d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999494975001091d);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(363.7393755555636d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.138332483316814d);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.1752011936438014d, 0.7615941559557649d, 0.9999494975001091d, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.536743E-7f);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.15795521463156686d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.84544373783414d));

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.15795521463156686d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1586128609853922d);

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.random.RandomGenerator var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     double[] var3 = new double[] { };
//     double[] var4 = var2.rank(var3);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.010050166663333094d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.01005033585179189d);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.010050166663333094d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.010100839201864612d);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-1L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1L));

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextPascal((-1), 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextInt(100, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(1.1752011936438014d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.32093223561005424d));

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.00001f);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var1);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(10L, (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10L);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var0.nextSecureLong(100L, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.01005033585179189d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999494957997512d);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.7615941559557649d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.4817022260739696d);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.281783181607902d);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(10, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.1586128609853922d, 2.281783181607902d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1586128609853922d);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.15729920705028488d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4128411121633297d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.15795521463156686d, 2.281783181607902d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8219866295031046d);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(10, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.8219866295031046d, 10.0d, (-0.32093223561005424d), 1);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.9999999999999996d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9999999999999999d));

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-1L), 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2L));

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.8427007929497151d, 0.1586128609853922d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8427007929497151d);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var2 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var3 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, var2);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-1), (-1.0f), 10.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(0, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.9999999999999996d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5574077246549007d);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.nextBeta(Double.NaN, 1.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0L, (-2L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(10, 100);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.nextHexString((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.8219866295031046d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8219866295031046d);

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var0.nextSample(var9, (-1));
// 
//   }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextCauchy(7.323401391309422d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15.718221473707125d);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(1.0d, 0.15795521463156686d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, 0.8219866295031046d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(10L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10L);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-0.32093223561005424d), 0.8219866295031046d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.3722334692039834d));

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 15.104412573075516d);

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var1 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, var1);
// 
//   }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("hi!", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9.348753722800135d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "8a61d14ed9"+ "'", var8.equals("8a61d14ed9"));
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1), 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.9999999999999996d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-1), (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2));

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.9999494975001091d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999831655499726d);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(7.138332483316814d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.138332483316814d);

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var0.nextSample(var9, (-1));
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.010050166663333094d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.009999999583352414d);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(1.1102230246251565E-16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.7615941559557649d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.013292325585375278d);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-2), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2));

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(100.00001f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.00001f);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-1L), (-2L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextF((-0.9999999999999999d), 0.009999999583352414d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.634599402641477d);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5517620356803065E-188d);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6L);

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var9.cumulativeProbability(0.7615941559557649d, 0.010050166663333094d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.3119685087829644d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d1abe28cce"+ "'", var8.equals("d1abe28cce"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.2471793871100777d);
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, (-0.3722334692039834d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 9.536743E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.IntegerDistribution var9 = null;
//     int var10 = var0.nextInversionDeviate(var9);
// 
//   }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextSecureInt(10, 1);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.9999494975001091d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 57.29288593298371d);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-2), 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2));

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.15729920705028488d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.14608902069952245d);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NoDataException var1 = new org.apache.commons.math3.exception.NoDataException(var0);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, (-0.43408597923864894d), (-0.3722334692039834d), 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 1L);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-2), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(2.3930658372149933d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3930658372149933d);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.0f, 0.14608902069952245d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.99999994f);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(6L, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10L);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(5, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var13 = var0.nextLong((-1L), (-2L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9.671808061480995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "3573cf8f35"+ "'", var8.equals("3573cf8f35"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.6563635001704058d);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.min(Double.NaN, 0.9999999999999996d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 243);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.5950413774252329d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4000591571530008d);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    boolean var7 = var0.isSupportUpperBoundInclusive();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var0.inverseCumulativeProbability(5.867156662812015d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.0d);

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     org.apache.commons.math3.distribution.RealDistribution var1 = null;
//     double var2 = var0.nextInversionDeviate(var1);
// 
//   }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "08f3674814");
// 
//   }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 5);
// 
//   }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, 1.1102230246251565E-16d, 0.5d, 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(3, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3);

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var13 = var0.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.447592769201261d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d11fd9333e"+ "'", var8.equals("d11fd9333e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 99);
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(20.696514663540924d, 0.010050166663333094d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5703107297735257d);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextSecureInt(1, 1);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.2185657441986304d, 0.9999831655499726d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.21858257864865782d);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(10, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100000);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 10.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setContractionCriteria(2.5f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(1.0d, (-1.383036361567265d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0d));

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(8899, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.267913798152765E236d);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3628800.0d);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.9999831655499726d, (java.lang.Number)(byte)100, (java.lang.Number)2.566440443196982d);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(100L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100L);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(2.1700484750291187d, 0.15795521463156686d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9930417854426408d);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(0, 8899);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-8899));

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(15.104412573075516d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, 0.1586128609853922d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.9930417854426408d, 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6351254179184792d);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.random.RandomGenerator var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var4 = var3.getSupportUpperBound();
//     double[] var6 = var3.sample(10);
//     double[] var7 = var2.rank(var6);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.1586128609853922d, 0.16043285994536435d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.15861286098539223d);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.010050166663333094d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.010050505059049992d);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.14608902069952245d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     double var10 = var0.nextT(20.696514663540924d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var12 = var0.nextSecureHexString((-8899));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.727464820454545d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1d5b97f432ecec1f3ca0ce367ee637e4fea7dee60daa91f120cda8deb6ba51cb0cf7e7d5a5b88d418cb7502fd0eca5211ae1"+ "'", var8.equals("1d5b97f432ecec1f3ca0ce367ee637e4fea7dee60daa91f120cda8deb6ba51cb0cf7e7d5a5b88d418cb7502fd0eca5211ae1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-2.460647943827884d));
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("08f3674814");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(2.1700484750291187d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0d);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = var0.nextT(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.1586128609853922d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.009999999583352414d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.010000166250831584d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var6 = var0.nextPermutation(0, 1);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.02239003662473929d);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(8899, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.5950413774252329d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.010385431221672573d);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1, 100000);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var4 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)(-1), (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)1.4128411121633297d, (java.lang.Object[])var4);
    java.lang.Number var7 = var6.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1.4128411121633297d+ "'", var7.equals(1.4128411121633297d));

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    double[] var5 = var4.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setElement((-1), 5.867156662812015d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.009999999583352414d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32.513321074988696d);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.8427007929497151d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("951f5f6788");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.5f, 0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5f);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.99999994f, 7.138332483316814d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(14.031149057314524d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 14.0d);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.10516633568161556d);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 120.0d);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.1102230246251565E-16d, 0.9930417854426408d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1102230246251565E-16d);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p((-0.9999999999999999d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-36.7368005696771d));

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(9.536743E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1368684E-13f);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(8899, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1L, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100L);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var6 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException(var4, (java.lang.Number)(-1), (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)1.4128411121633297d, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, var1, (java.lang.Object[])var6);
    java.lang.Number var10 = var9.getMax();
    java.lang.Number var11 = var9.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.32093223561005424d), 2.3930658372149933d, 3.0d, 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(1L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.7615941559557649d, 7.323401391309422d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.362895734466076d);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos((-2.225482993439564d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 236.64698555037546d);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 10L);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.21858257864865782d, (-0.32093223561005424d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.38829865251165124d);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2L);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.3561924887652932d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3561924887652932d);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 21.0d);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.99999994f, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9999999f);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.8967323527194379d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 14.087081017797523d);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 6L);
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var3 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)(-1), (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    double[] var5 = var4.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setContractionCriteria(1.1368684E-13f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.0d, 0.010050505059049992d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     int var11 = var0.nextZipf(5, 0.8273572477024794d);
//     org.apache.commons.math3.distribution.IntegerDistribution var12 = null;
//     int var13 = var0.nextInversionDeviate(var12);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var4.getElement((-2));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getStandardDeviation();
//     double[] var13 = var10.sample(1);
//     double var15 = var10.cumulativeProbability(0.0d);
//     double var16 = var10.getSupportUpperBound();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     org.apache.commons.math3.distribution.IntegerDistribution var18 = null;
//     int var19 = var0.nextInversionDeviate(var18);
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    int var1 = org.apache.commons.math3.util.FastMath.round((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 0.99999994f, 100.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0f);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(7.138332483316814d, 0.9999494957997512d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999494957997512d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-2), 3);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    double var8 = var0.density(0.5950413774252329d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.33421337133949025d);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double[] var3 = var0.sample(10);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setExpansionMode(1910);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.009999999583352414d, 0.10516633568161556d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.017688387388495763d);

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var5 = var0.nextHexString((-2));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1.4407807946472178d));
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-1), 8899);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.discardFrontElements(10);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-1), (-2));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(15.104412573075516d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.179103839756096d);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.010100839201864612d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.010100667450109603d);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("e1e61d906c3833fad993ec3abab2930274bc6a7e51878506413ee4218d86de3dde43ac28b4128702bc1b060bc0582a0c31d2");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-8899), 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-8904));

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(8899, 100.0f, 0.99999994f, 100);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(10L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(7.323401391309422d, (-36.7368005696771d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.0d));

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs((-1.383036361567265d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.383036361567265d);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-13.986212165712919d), 0.21858257864865782d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0030728678011815447d);

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.1901543518195821d), (-0.9999999999999999d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(8899);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(7.138332483316814d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0965853043994893d);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-1), 8);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(2.5517620356803065E-188d, (-0.43408597923864894d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.4607121656995548d));

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var11 = var0.nextSecureHexString((-8904));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.212504660698426d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2);
// 
//   }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(100000, (-2));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     double var10 = var0.nextT(20.696514663540924d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var0.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.2279958927589325d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "bb272f6fbc0267902e84b68cabd1d6336ef041cecc8761097ab980c76c9861d3094d3b4f9144290b263d05e810c98f940436"+ "'", var8.equals("bb272f6fbc0267902e84b68cabd1d6336ef041cecc8761097ab980c76c9861d3094d3b4f9144290b263d05e810c98f940436"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.33680004721905077d));
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var5 = java.lang.Enum.<java.lang.Enum>valueOf(var3, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8427007929497151d));

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.8273572477024794d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.24197688819531704d);

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var9.inverseCumulativeProbability((-0.1901543518195821d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.94364779656309d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "36d81e3196"+ "'", var8.equals("36d81e3196"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.0381695605332353d));
// 
//   }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var3);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var3);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var7 = var6.getSupportUpperBound();
//     double[] var9 = var6.sample(10);
//     org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var11.getSupportUpperBound();
//     double[] var14 = var11.sample(10);
//     org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
//     double var16 = var5.mannWhitneyUTest(var9, var14);
// 
//   }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextInt(10, 3);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 16.12779815139368d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "56548d101b62e3f16a184c5b02c82bc0e1a875823188e7610a7960c0b093ec81c84df2854a50ea1d2e44c8a0e5624f72a48e"+ "'", var8.equals("56548d101b62e3f16a184c5b02c82bc0e1a875823188e7610a7960c0b093ec81c84df2854a50ea1d2e44c8a0e5624f72a48e"));
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 40320L);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-0.4255538433808183d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0919228035719635d);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double var2 = var0.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)6L, false);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(1.4128411121633297d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(243, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)18.0d, (java.lang.Number)0.25587682077976953d, false);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1L, (-8904));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-2L), 6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4L);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.15795521463156686d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.15928211151946273d);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(3.2359311173302077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.09461932640561994d);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(14.27900880653991d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 14L);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var4 = java.lang.Enum.<java.lang.Enum>valueOf(var2, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-8904));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 100.0f, 1.0f, 8899);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var0.nextSample(var10, 10);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-8899), 100000);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0471975511965979d);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(12.887557044182769d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 12.0d);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(6.289245514671205d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5078368197853713d);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(9973, 1.9999999f, 0.0f, 5);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.004492703465851146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.004492673238610562d);

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.distribution.NormalDistribution var1 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var2 = var1.getStandardDeviation();
//     boolean var3 = var1.isSupportUpperBoundInclusive();
//     double[] var5 = var1.sample(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var6.reseedRandomGenerator(2L);
//     double[] var10 = var6.sample(100000);
//     double var11 = var0.mannWhitneyUTest(var5, var10);
//     double[] var12 = null;
//     double[] var13 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.mannWhitneyU(var12, var13);
//       fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
//     } catch (org.apache.commons.math3.exception.NullArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.9932401003309674d);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.7615941559557649d, 24.701632111266814d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999999928669d);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.discardMostRecentElements((-8904));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var10 = var0.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9539375095736062d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "0115de421c26a874d141fd689ecb4e2da2bc025caf10e4acbc30bed1a9a74ae373dfc24863d3b93b44d7bb4ed9c50eefacd3"+ "'", var8.equals("0115de421c26a874d141fd689ecb4e2da2bc025caf10e4acbc30bed1a9a74ae373dfc24863d3b93b44d7bb4ed9c50eefacd3"));
// 
//   }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var13 = var0.nextF(0.6351254179184792d, 1.0919228035719635d);
//     int var16 = var0.nextZipf(100, 2.1700484750291187d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextPascal(0, 0.8967323527194379d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.614171443190375d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "281ba845e3"+ "'", var8.equals("281ba845e3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.0465318807510764d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.6022254764975288d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.009999999583352414d, true);
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than the minimum (0.01)"+ "'", var4.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than the minimum (0.01)"));

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     int var11 = var0.nextZipf(5, 0.8273572477024794d);
//     org.apache.commons.math3.distribution.RealDistribution var12 = null;
//     double var13 = var0.nextInversionDeviate(var12);
// 
//   }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.99999994f);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-8904), (-8899));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(9.536743E-7f, 0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.99999994f);

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(2.5078368197853713d, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextUniform(2.0965853043994893d, 0.013292325585375278d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 31.144961873189285d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1e969f2385"+ "'", var8.equals("1e969f2385"));
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.9999999999999996d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999999999996d);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(2.3930658372149933d, 0.15861286098539223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5046129383761193d);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(32.513321074988696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32.0d);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.1368684E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1368685E-13f);

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-36.7368005696771d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(4L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4L);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    long var1 = org.apache.commons.math3.util.FastMath.round((-1.6425960315151908d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2L));

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("08f3674814", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.689650409250347d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "bfc6785e50"+ "'", var8.equals("bfc6785e50"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.5347111140911284d));
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(1L, (-2L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.discardMostRecentElements(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.discardMostRecentElements(9973);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var1.substituteMostRecentElement(0.004492703465851146d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5f);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.010100839201864612d, (java.lang.Number)(-1), (java.lang.Number)14.27900880653991d);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.010100839201864612d+ "'", var5.equals(0.010100839201864612d));

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setExpansionMode(5);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 20.696514663540924d);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.10516633568161556d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0055350777378302d);

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var3);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var3);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var6 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var8 = var7.getStandardDeviation();
//     boolean var9 = var7.isSupportUpperBoundInclusive();
//     double[] var11 = var7.sample(100);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var12.reseedRandomGenerator(2L);
//     double[] var16 = var12.sample(100000);
//     double var17 = var6.mannWhitneyUTest(var11, var16);
//     double[] var18 = var5.rank(var11);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(8, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum((-0.4255538433808183d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)4L);

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getStandardDeviation();
//     double[] var13 = var10.sample(1);
//     double var15 = var10.cumulativeProbability(0.0d);
//     double var16 = var10.getSupportUpperBound();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var20 = var0.nextSecureLong(100L, 4L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.605754374983784d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.05717796157243d);
// 
//   }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var2);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var6 = var5.getStandardDeviation();
//     boolean var7 = var5.isSupportUpperBoundInclusive();
//     double[] var9 = var5.sample(100);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var10.reseedRandomGenerator(2L);
//     double[] var14 = var10.sample(100000);
//     double var15 = var4.mannWhitneyUTest(var9, var14);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var20 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
//     org.apache.commons.math3.distribution.NormalDistribution var22 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var23 = var22.getSupportUpperBound();
//     double[] var25 = var22.sample(10);
//     double var26 = var16.mannWhitneyU(var20, var25);
//     double var27 = var3.mannWhitneyUTest(var9, var20);
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial((-8904));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.6351254179184792d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5658474030075499d);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(4L, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 104L);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    java.math.BigInteger var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, (-8899));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh((-0.5745618421848383d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6067002787417757d));

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(2L, 4L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     var0.reSeed();
//     java.util.Collection var14 = null;
//     java.lang.Object[] var16 = var0.nextSample(var14, 1877);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.1368685E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     var0.reSeed(14L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextWeibull((-0.3722334692039834d), 21.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.092038780080742d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "eccc2abf17"+ "'", var8.equals("eccc2abf17"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.1723368548289961d));
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(21.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.594078672416073E8d);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3841858E-7f);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(2.124989902393144d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4981750218488439d);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(5.867156662812015d, (-1.84544373783414d), 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(2.1700484750291187d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9978516012375751d);

  }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     org.apache.commons.math3.distribution.IntegerDistribution var14 = null;
//     int var15 = var0.nextInversionDeviate(var14);
// 
//   }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextHypergeometric(0, 100, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0622673638091362d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d020006b77"+ "'", var8.equals("d020006b77"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 54);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma(0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    double[] var5 = var4.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(12.0d, 236.64698555037546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.1999094085604285d);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.2471705263294632d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
    java.lang.Object var17 = null;
    boolean var18 = var4.equals(var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.discardMostRecentElements(9973);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(2.345330933436551d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.345330933436551d);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(2.3841858E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3841858E-7f);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-2), 1910);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1912));

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextF(0.0d, 1.1752011936438014d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 19.133273217212015d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "8fef57ee03"+ "'", var8.equals("8fef57ee03"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7L);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.0f, 1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(0, 1949);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1949);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)10);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.017688387388495763d, 0.01968211567084032d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.017688387388495763d);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.09461932640561994d, 0.14608902069952245d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.17405406889354452d);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(1877, 243);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 243);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-8904), (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8904);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(0, 1949);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.16043285994536435d, 2.3930658372149933d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.16043285994536438d);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextUniform(6.621888603197341d, 0.0d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.16144268089259498d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2L);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(4L, (-2L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(2.5f, 1.9999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5f);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.0919228035719635d, 1.2471705263294632d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7191244662236342d);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.380627352707058d, 14.27900880653991d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9977662621293E-6d);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-8899), 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-8889));

  }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(2.4817022260739696d, (-0.9986814996153957d), 0.017688387388495763d, 8904);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 10.0f);
    var2.addElement(0.15729920705028488d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionMode(11274);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 100000);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.1368685E-13f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1368685E-13f);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1877, 8904);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 20355937);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var4 = var0.getNumericalVariance();
    double var7 = var0.cumulativeProbability(0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1972, 36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1916, (-8899));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(12.603631635642417d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0L, (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-2L), 8L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-16L));

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
    java.lang.Object var17 = null;
    boolean var18 = var4.equals(var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.discardMostRecentElements((-1912));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.9999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9999999f);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-27.874703436170744d), (java.lang.Number)10.0f, true);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-1.84544373783414d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.0d));

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(5, 36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 180);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(11274, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 11274);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.004492673238610562d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.004482611307585709d);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1910);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1910);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.004492673238610562d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var1.nextUniform(17.041070396305297d, 0.8147655203522769d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var1.getElement(100000);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.4E-45f, 1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(1, (-8904));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(2L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5707963267948966d);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var3 = var1.nextSecureHexString((-8899));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1L, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextWeibull(7.769493748166378d, 1.2185657441986304d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextInt(243, (-2));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.2177187610377305d);
// 
//   }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     var0.reSeed(14L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextHypergeometric(5, 5, 42);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.137111396220352d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "bf9ef08c06"+ "'", var8.equals("bf9ef08c06"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.437158760306869d);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(3L, 2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6L);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.0919228035719635d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, (-0.8427007929497151d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextUniform(1.5707963267948966d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.4303414738826894d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "574b5f43e8"+ "'", var8.equals("574b5f43e8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.6301899425701292d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 10096);
// 
//   }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.discardFrontElements(100000);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(1.1515109860475812d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("7ffcf81f5c", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.8853368470843535d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ea42ab9200"+ "'", var8.equals("ea42ab9200"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2L);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(8L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3841858E-7f);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.1368685E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1368685E-13f);

  }

  public void test414() {}
//   public void test414() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var13 = var0.nextF(0.6351254179184792d, 1.0919228035719635d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextGaussian((-1.0d), (-0.3722334692039834d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.821903639042314d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "3cd111ea26"+ "'", var8.equals("3cd111ea26"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.029452603794902964d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 8.779748650423649d);
// 
//   }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(36, 8899);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(40320L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 40320L);

  }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getStandardDeviation();
//     double[] var13 = var10.sample(1);
//     double var15 = var10.cumulativeProbability(0.0d);
//     double var16 = var10.getSupportUpperBound();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     var0.reSeed();
//     double var21 = var0.nextGamma(0.0d, 6.621888603197341d);
//     java.util.Collection var22 = null;
//     java.lang.Object[] var24 = var0.nextSample(var22, 1916);
// 
//   }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var13 = var0.nextT(5.867156662812015d);
//     double var16 = var0.nextGamma(0.13558023874553457d, 0.010050505059049992d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextZipf(1, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 17.38703381415675d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f592343fca"+ "'", var8.equals("f592343fca"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.17748204008567794d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.383296589232328E-4d);
// 
//   }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-2), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 11274);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(5, 1.4E-45f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(25.472636453138065d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.775578026902914E10d);

  }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var9 = var0.nextPermutation(1972, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-22.686333242561485d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
// 
//   }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     org.apache.commons.math3.distribution.IntegerDistribution var11 = null;
//     int var12 = var0.nextInversionDeviate(var11);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-1L), 6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6L);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(25.472636453138065d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 26.0d);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(20355937, 1.1368684E-13f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(7.769493748166378d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0843874063990762d);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(6.481650533373193d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.0d);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5f);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(8904, (-8889));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(0, 100000);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100000);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(12.603631635642417d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-1.2732919183123732d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var29 = var0.nextHypergeometric(1910, (-1), 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.888613130310101d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "264d9ee5e8"+ "'", var8.equals("264d9ee5e8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1979);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.005294350625579058d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-0.5997437851013013d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.014754218756837063d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-1.3137776965542787d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-0.7184218076980982d));
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.010050166663333094d, (-2.0d), 0.004492703465851146d, (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(5, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(8904);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-8899), 44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 11);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(3.3113021230333133d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9856338779552689d));

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-16L), 4L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-64L));

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(180, 1877);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 337860);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.0d, 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5d);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var4 = var1.toString();
    java.lang.Class var5 = var1.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var7 = java.lang.Enum.<java.lang.Enum>valueOf(var5, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 1999);
// 
//   }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(1916);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 12569.816320050882d);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.14608902069952245d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.9235391122654637d));

  }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     var0.reSeed(6L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextZipf(9973, (-2.225482993439564d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.3589625405813606d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "509655037f"+ "'", var8.equals("509655037f"));
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(236.64698555037546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 237.0d);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    java.math.BigInteger var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, (-8904));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var4 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)(-1), (java.lang.Object[])var4);
//     org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var4);
//     org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var4);
//     org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var7);
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(100L, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.010100667450109603d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0101518513770347d);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(7.323401391309422d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7044581484917243d);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var2 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)(-1), (java.lang.Object[])var2);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    java.lang.Number var5 = var3.getMax();
    java.lang.Number var6 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1)+ "'", var5.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setExpansionFactor(10.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(8L, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var16 = var0.nextSecureLong(6L, 2L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.6761079973527595d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ad440ea115"+ "'", var8.equals("ad440ea115"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1849);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.01071690734166424d);
// 
//   }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(9.536743E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.536744E-7f);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var16 = var0.nextPermutation(5, (-2));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 14.425888226987244d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f6a0ac1818"+ "'", var8.equals("f6a0ac1818"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.22294919190190376d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 10260);
// 
//   }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var13 = var0.nextF(0.6351254179184792d, 1.0919228035719635d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextBinomial(5, 7.362895734466076d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 17.727762101963254d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "637766c736"+ "'", var8.equals("637766c736"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.0286463197358755d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.36097678294296d);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(1972);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 12993.88895389968d);

  }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var13 = var0.nextT(5.867156662812015d);
//     double var16 = var0.nextGamma(0.13558023874553457d, 0.010050505059049992d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextSecureInt(1910, (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15.204700639673865d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "8050dba009"+ "'", var8.equals("8050dba009"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.021967121803104086d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.9259211636663903E-9d);
// 
//   }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(1972, 36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 36);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(237.0d, 6.785547566387043d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.754151990693038E-268d);

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var27 = var0.nextPoisson((-36.7368005696771d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.751372837112554d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "9720cd3b25"+ "'", var8.equals("9720cd3b25"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1950);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0037264100913339923d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.46343020100290566d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-0.5562349478760097d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.759682882901108d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-0.903008345534854d));
// 
//   }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.13558023874553457d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.76817546549521d);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    double var7 = var0.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);

  }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma((-0.4255538433808183d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.9999999999999996d, 32.513321074988696d, 5.363952139253263d, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.9999999999999925d);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.4000591571530008d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 22.921701260427884d);

  }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-0.4329667140671784d), 0.12160808276430722d, (-0.03477795372577799d), 100);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(1.257156203792693d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.07542235768757849d);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("120a74813a");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.8652627755109201d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-1), 10);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(42, 11274);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-0.9942647162019622d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("254eae09b52a55b9592fe1b06709df283fa6be58634c71fb14009be3fc34971b2bc66925909274c43d7b98c2c42300b40ea2");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.4607121656995548d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2));

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(6L, (-16L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-16L));

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var2 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)(-1), (java.lang.Object[])var2);
    java.lang.Number var4 = var3.getMax();
    java.lang.Number var5 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1)+ "'", var4.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1)+ "'", var5.equals((-1)));

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(40320L, (-16L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)2.3930658372149933d, (java.lang.Number)0.0f, false);
    boolean var5 = var4.getBoundIsAllowed();
    java.lang.Number var6 = var4.getMin();
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.0f+ "'", var6.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.004492703465851146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.004492688352124083d);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(10.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0f);

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
//     java.math.BigInteger var3 = null;
//     java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
//     java.math.BigInteger var6 = null;
//     java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
//     java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var8);
//     java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, var5);
// 
//   }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)100);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(36, 8904);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-64L), (java.lang.Number)1.0101518513770347d, (java.lang.Number)(-1.2732919183123732d));

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.5d, (-0.47764759415577684d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.022352405844223155d);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(1.2185657441986304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.02126798438828109d);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(21.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7589241763811208d);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(20355937, 42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 20355979);

  }

}
