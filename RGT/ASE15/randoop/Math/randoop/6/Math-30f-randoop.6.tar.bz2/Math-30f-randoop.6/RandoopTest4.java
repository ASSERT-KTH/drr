
import junit.framework.*;

public class RandoopTest4 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test1"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test2"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(20355937);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 20355937);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test3"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.5000002f, 1.9999998f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5000002f);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test4"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.20219294601197874d, 6.481650533373193d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.20219294601197874d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test5"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(6.378161442562124d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.804695507808558d);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test6"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(30.60262860049912d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test7"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(36, 9.536743E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test8"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(20355979, 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1847479261));

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test9"); }


    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(11304, 2.0f, 2.5000002f);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test10"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)9.536743E-7f, (java.lang.Number)(-0.4255538433808183d), false);
    boolean var5 = var4.getBoundIsAllowed();
    boolean var6 = var4.getBoundIsAllowed();
    java.lang.Number var7 = var4.getMax();
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-0.4255538433808183d)+ "'", var7.equals((-0.4255538433808183d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test11"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-127), 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-508));

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test12"); }


    float var2 = org.apache.commons.math3.util.FastMath.max((-1.0f), 0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.99999994f);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test13"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var21 = var18.nextSecureLong((-1L), 1L);
//     double var24 = var18.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var26 = var18.nextSecureHexString(100);
//     double var28 = var18.nextT(20.696514663540924d);
//     org.apache.commons.math3.distribution.NormalDistribution var29 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var30 = var29.getStandardDeviation();
//     double[] var32 = var29.sample(1);
//     double var33 = var29.getMean();
//     double[] var35 = var29.sample(100);
//     double var36 = var29.sample();
//     double var37 = var29.sample();
//     double var38 = var18.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     double var39 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     org.apache.commons.math3.distribution.NormalDistribution var40 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var41 = var40.getStandardDeviation();
//     double[] var43 = var40.sample(1);
//     double var44 = var40.getMean();
//     double[] var46 = var40.sample(100);
//     double var47 = var40.sample();
//     double var48 = var40.sample();
//     var40.reseedRandomGenerator(10L);
//     boolean var51 = var40.isSupportLowerBoundInclusive();
//     boolean var52 = var40.isSupportLowerBoundInclusive();
//     double var53 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var40);
//     double var55 = var40.probability(13.40919037348431d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.112308319237323d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "45f3831e8e5baabc0ab026a972e5a97aaae9f9c8d300d91d1ba405ac91f17b3b6b7d45c1c8792a15fd5690a21637c0965e00"+ "'", var8.equals("45f3831e8e5baabc0ab026a972e5a97aaae9f9c8d300d91d1ba405ac91f17b3b6b7d45c1c8792a15fd5690a21637c0965e00"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.09943289076401282d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 15.659596529133324d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "ca77b703c2e3f88033d009667e7a207fd1912c4e9af0a714ec4daa33ff634935dcbc89a87a1fc1f8bc147a154fa694a5ec77"+ "'", var26.equals("ca77b703c2e3f88033d009667e7a207fd1912c4e9af0a714ec4daa33ff634935dcbc89a87a1fc1f8bc147a154fa694a5ec77"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1.0453534601915846d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0.6650434548901554d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == (-0.8961189234469322d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == (-0.8444824053746879d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0.03449694538827916d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0.8024710330055997d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 0.7383434538945063d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == (-0.9570437588131924d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 0.0d);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test14"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.03449694538827916d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.03448327091128028d);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test15"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
    java.lang.Object var17 = null;
    boolean var18 = var4.equals(var17);
    var4.setElement(100, 0.0d);
    double[] var22 = var4.getInternalValues();
    float var23 = var4.getExpansionFactor();
    org.apache.commons.math3.exception.util.Localizable var24 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var28 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var24, (java.lang.Number)9.536743E-7f, (java.lang.Number)(-0.4255538433808183d), false);
    boolean var29 = var4.equals((java.lang.Object)(-0.4255538433808183d));
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray(189);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test16"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1549);
    var1.contract();

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test17"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(1947);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test18"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.32705216023560196d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test19"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.993405468012823d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6898444666059612d);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test20"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(10775, 9.536744E-7f, 0.0f, 9);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test21"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(10.5f, 1.9999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.5f);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test22"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var0.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test23"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(8.854558633913316d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test24"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(32.261075151859934d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test25"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    double[] var7 = var4.getInternalValues();
    var4.addElement(0.7615941559557649d);
    double var11 = var4.substituteMostRecentElement(0.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = var4.copy();
    var4.clear();
    double var15 = var4.addElementRolling(4.8086879523173485d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.7615941559557649d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test26"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.10127656214144387d, 0.3769994616483318d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.39036590030677853d);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test27"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(2.5000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5000005f);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test28"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    double[] var5 = var4.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setExpansionFactor(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test29"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(11.610803109153846d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5345538362242994d);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test30"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.9999494957997512d, (-12.669478029470282d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999494957997512d);

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test31"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow((-1.8376749185262546d), (-0.27924610171153436d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test32"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     double var9 = var0.nextF(2.281783181607902d, 0.8427007929497151d);
//     double var12 = var0.nextGaussian(1.5498468927479463d, 1865.0d);
//     java.lang.String var14 = var0.nextHexString(337860);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var17 = var0.nextPermutation((-297256655), 15861760);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.743847512463007d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.605491364928535d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-510.3677075347485d));
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test33"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(6.694390071933186E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.694390071933187E-5d);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test34"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(short)100, var2, var3);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test35"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.clear();
    float var8 = var6.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setContractionCriteria(1.1368683E-13f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test36"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.7486277039791855d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test37"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.39901834264429115d, 1836);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test38"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var4.addElement((-0.43408597923864894d));
//     double var10 = var4.getElement(0);
//     var4.clear();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var4.substituteMostRecentElement(0.12130857027273921d);
//       fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
//     } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.305761175578404d));
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test39"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.9999679765543574d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.999983988148989d);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test40"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(1955, (-519016991));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test41"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     int var11 = var0.nextZipf(5, 0.8273572477024794d);
//     double var14 = var0.nextGamma((-1.9235391122654637d), 6.774605976508678d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var17 = var0.nextPermutation(5, 7);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.013871688343038d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "11b69535a540296c8bdf10adb90e26b4b59a859148b5593aa51ca08bf3391d32cb1fd2686c76f004fdebdcb4b2e21c469e4c"+ "'", var8.equals("11b69535a540296c8bdf10adb90e26b4b59a859148b5593aa51ca08bf3391d32cb1fd2686c76f004fdebdcb4b2e21c469e4c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 12.912456329786831d);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test42"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(7.105427357601002E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test43"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(10743, 8941);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test44"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.15512025679417774d, (java.lang.Number)1.2471705263294632d, (java.lang.Number)0.0843874063990762d);
    java.lang.Number var4 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.2471705263294632d+ "'", var4.equals(1.2471705263294632d));

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test45"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var3);
    java.lang.String var6 = var3.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    java.lang.String var8 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test46"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.9935022674622966d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7006764197365944d);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test47"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(11L, 29L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 319L);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test48"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.addElement(0.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var6.copy();
    int var10 = var9.getExpansionMode();
    float var11 = var9.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.5f);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test49"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.08452288246378666d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test50"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)181);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test51"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var4.addElement((-0.43408597923864894d));
//     double var10 = var4.getElement(0);
//     double[] var11 = var4.getElements();
//     var4.addElement(21.0d);
//     var4.setNumElements(3);
//     org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var17 = var16.getStandardDeviation();
//     double[] var19 = var16.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
//     var20.contract();
//     int var22 = var20.getNumElements();
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var20);
//     org.apache.commons.math3.util.ResizableDoubleArray var24 = var4.copy();
//     var24.clear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.3648740342412747d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test52"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     var0.reSeed(6L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("5aa84292e3", "02cb4e639beff50fd17a4b48128f732e059dda143bc2e1309e4460dc2d63bd020318ac7e312a5255c2f688a78e78f0f34979");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10.692621526019135d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "64a3d73c63"+ "'", var8.equals("64a3d73c63"));
// 
//   }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test53"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)6.648133937682834d, (java.lang.Number)1.1368684E-13f, false);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test54"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     double var9 = var0.nextF(2.281783181607902d, 0.8427007929497151d);
//     double var12 = var0.nextGamma((-0.4337902394648092d), 0.003547845623385577d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.2254534621059707d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.9870324860653736d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.010200975372259509d);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test55"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.7243407758924822d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8847772083337101d);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test56"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("b86a760f42");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test57"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-1), 1947);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1946);

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test58"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var7 = var0.nextUniform(1.179103839756096d, 22.877003894887903d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextGaussian(1.2203546622344768d, (-0.40140192443465506d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.6792146891443123d);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test59"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.1752011936438014d, (java.lang.Number)0.1586128609853922d, false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.1586128609853922d+ "'", var5.equals(0.1586128609853922d));

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test60"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-1.0536078524937216d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8692127392011839d));

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test61"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh((-0.3107590834442903d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.32138541515384916d));

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test62"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(7.813018098356309d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.0d);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test63"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)5.2088636151272185d, (java.lang.Number)3.0597061131596783d, true);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 3.0597061131596783d+ "'", var4.equals(3.0597061131596783d));

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test64"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     double var16 = var0.nextGaussian(0.9999494957997512d, 25.472636453138065d);
//     double var19 = var0.nextWeibull(18.0d, 25.472636453138065d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var21 = var0.nextSecureHexString((-297258196));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12.105633565877639d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f6667a77a8"+ "'", var8.equals("f6667a77a8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1908);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.005857398862032414d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-12.256250251323127d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 25.151876828074414d);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test65"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.3820170337076183d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6180752654067451d);

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test66"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-0.8427007929497151d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test67"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(193L, 1344L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1151L));

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test68"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, 0.8382617516745859d, 14.738220481169323d, 1994);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test69"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0, (-408490575));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test70"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(2, 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8);

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test71"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(100L);
//     double var18 = var0.nextGamma(0.7185451019589657d, 648.230953682526d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("09f1676c71", "org.apache.commons.math3.exception.OutOfRangeException: -1 out of [10, 6.622] range");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.392381721396043d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "6faf147bc3"+ "'", var8.equals("6faf147bc3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.4256747707800212d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 10468);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 30.842070749259253d);
// 
//   }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test72"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     var4.contract();
//     double[] var6 = var4.getInternalValues();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var8 = var7.getTiesStrategy();
//     java.lang.Class var9 = var8.getDeclaringClass();
//     java.lang.Class var10 = var8.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var13 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     boolean var16 = var14.isSupportUpperBoundInclusive();
//     double[] var18 = var14.sample(100);
//     org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var19.reseedRandomGenerator(2L);
//     double[] var23 = var19.sample(100000);
//     double var24 = var13.mannWhitneyUTest(var18, var23);
//     org.apache.commons.math3.distribution.NormalDistribution var25 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double[] var27 = var25.sample(1910);
//     org.apache.commons.math3.distribution.NormalDistribution var28 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var29 = var28.getStandardDeviation();
//     double[] var31 = var28.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var32 = new org.apache.commons.math3.util.ResizableDoubleArray(var31);
//     double[] var33 = var32.getElements();
//     double var34 = var13.mannWhitneyUTest(var27, var33);
//     double[] var35 = var11.rank(var33);
//     var4.addElements(var33);
//     org.apache.commons.math3.exception.OutOfRangeException var40 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.4000591571530008d, (java.lang.Number)8, (java.lang.Number)(-2.225482993439564d));
//     java.lang.Number var41 = var40.getLo();
//     java.lang.Number var42 = var40.getHi();
//     boolean var43 = var4.equals((java.lang.Object)var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.8429516986897995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0.34866872078240907d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var41 + "' != '" + 8+ "'", var41.equals(8));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var42 + "' != '" + (-2.225482993439564d)+ "'", var42.equals((-2.225482993439564d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test73"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(1.4377981035664862d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.023318613500485474d));

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test74"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("", "080f179253");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.5925511061991505d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test75"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var7.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var7.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test76"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(17018, 20355979);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test77"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(2021567837087569569L, 11L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test78"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.8E-45f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.8E-45f);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test79"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.527066384736393d, 4.472431190187361d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9685946216192505d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test80"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    var4.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var4.copy();
    int var10 = var4.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    int var12 = var11.getExpansionMode();
    var11.addElement(4.5535597409955875d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test81"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.002073594803565866d);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test82"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(0L);
//     long var17 = var0.nextPoisson(7.769493748166378d);
//     org.apache.commons.math3.distribution.NormalDistribution var18 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var19 = var18.getSupportUpperBound();
//     double[] var21 = var18.sample(10);
//     double var22 = var18.getStandardDeviation();
//     double var24 = var18.density(2.345330933436551d);
//     double var25 = var18.getSupportLowerBound();
//     double var26 = var18.getSupportLowerBound();
//     double var27 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var18);
//     boolean var28 = var18.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 20.58329368146181d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "7915e8fe3a"+ "'", var8.equals("7915e8fe3a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.8670357192834551d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 10993);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.025496167636629936d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 2.054051234375098d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test83"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3L, 4311469);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2388144625711178067L);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test84"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.02126798438828109d);
    java.lang.Number var2 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0.02126798438828109d+ "'", var2.equals(0.02126798438828109d));

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test85"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)7.617953921806563d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test86"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.4849465655472502d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.884699859434091d);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test87"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.0d, 0.0017904670400102447d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0017904670400102447d);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test88"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, 2097152.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test89"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double var3 = var0.inverseCumulativeProbability(0.9999999999928669d);
    boolean var4 = var0.isSupportConnected();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var6 = var0.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 6.755176609774487d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test90"); }


    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.777695809106093d, (java.lang.Number)0.1458777169601448d, var2);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test91"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(56L, 31L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31L);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test92"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    int var7 = var6.getNumElements();
    var6.setNumElements(8899);
    int var10 = var6.start();
    int var11 = var6.getNumElements();
    int var12 = var6.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.discardFrontElements(9066);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 8899);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 8899);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test93"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(11395, (-79579695));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-79568300));

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test94"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(51, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test95"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.4496917979688907d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.46500210138368253d);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test96"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    java.lang.Class var6 = var4.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    java.lang.String var8 = var4.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    int var10 = var2.ordinal();
    java.lang.Class var11 = var2.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test97"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1.0029035108007374d);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test98"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.6369655282464425d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 36.495436463842175d);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test99"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.9931164061239494d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test100"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(2.4451827154795756d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5036510690527161d);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test101"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var3 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var4 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.5662191695169728d, (java.lang.Object[])var3);
    java.lang.Number var6 = var5.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.5662191695169728d+ "'", var6.equals(0.5662191695169728d));

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test102"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-0.03477795372577799d), 0.24197688819531704d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.03477795372577799d));

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test103"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.1458777169601448d, 1.4466569298283658d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4539933221737773d);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test104"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.4833612318779604d, (-0.3689837234418783d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6081011993472895d);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test105"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(10947, 11401);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-454));

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test106"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.setNumElements(0);
    float var9 = var6.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setContractionCriteria(9.536745E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.0f);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test107"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var2 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)(-1), (java.lang.Object[])var2);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var6, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var11 = var10.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathArithmeticException var13 = new org.apache.commons.math3.exception.MathArithmeticException(var4, (java.lang.Object[])var11);
    var3.addSuppressed((java.lang.Throwable)var13);
    java.lang.Number var15 = var3.getMax();
    java.lang.Number var16 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (-1)+ "'", var15.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (-1)+ "'", var16.equals((-1)));

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test108"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.0d, 10.132200867889637d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test109"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-3.1315764174146636d), 0.8057138887308153d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8057138887308153d);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test110"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var4 = var0.getMean();
    double[] var6 = var0.sample(100);
    boolean var7 = var0.isSupportLowerBoundInclusive();
    boolean var8 = var0.isSupportUpperBoundInclusive();
    double[] var10 = var0.sample(8899);
    double var12 = var0.density(3.243310970166501d);
    double var13 = var0.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.002073594803565866d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test111"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(39916800L, 1053960288888713761L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1053960288888713761L);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test112"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalArgumentException var2 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var1);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test113"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-47.561794942941404d), 57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6.8543770234272911E18d));

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test114"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var7 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var3, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
//     java.lang.Throwable[] var8 = var7.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var8);
//     org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var8);
//     org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var8);
//     org.apache.commons.math3.exception.util.Localizable var12 = null;
//     java.lang.Object[] var13 = null;
//     org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var11, var12, var13);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test115"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(2.095003270872298d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.125467547535871d);

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test116"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.3561924887652932d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test117"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(3628800.0d, 1.5703107297735257d);
    boolean var3 = var2.isSupportUpperBoundInclusive();
    double var4 = var2.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test118"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     double var16 = var0.nextChiSquare(7.406617040824975d);
//     double var19 = var0.nextUniform((-0.4329667140671784d), 3.674181234459348d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.403139944641448d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "de02f8cc2f3faddebc91e88f0252eaeab16d567d76a73f04ca1975fdf8483735974395904457bcbd11a864bc4fc8556995c3"+ "'", var8.equals("de02f8cc2f3faddebc91e88f0252eaeab16d567d76a73f04ca1975fdf8483735974395904457bcbd11a864bc4fc8556995c3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.025054751333117468d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 17.63985625609349d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 2.5482558369267885d);
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test119"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var2 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-4.440892098500626E-16d), var2, (java.lang.Number)Double.POSITIVE_INFINITY);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test120"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.7625552649455967d, (java.lang.Number)2.265662238504449d, true);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test121"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.addElement(0.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var6.copy();
    float var10 = var9.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.5f);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test122"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(2041, 40318L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-623678255));

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test123"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test124"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 51);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test125"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(9.536744E-7f, 17018);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test126"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(2021567837087569569L, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test127"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     double var11 = var0.nextF(0.9672931540516151d, 1.0101518513770347d);
//     double var14 = var0.nextBeta(0.17971249487899976d, 0.022352405844223155d);
//     double var17 = var0.nextUniform(0.05823178627842507d, 5.651402035468341d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15.2715815643462d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "2dbf0978135b666e7282974d1f47578d44763652cee1273d14c3a254ebc6a23ff11bf1b960a977e9414dc07f1e8b6aa88af9"+ "'", var8.equals("2dbf0978135b666e7282974d1f47578d44763652cee1273d14c3a254ebc6a23ff11bf1b960a977e9414dc07f1e8b6aa88af9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0019953167668664154d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.102356077385794d);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test128"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-12.669478029470282d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.10292482065295498d));

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test129"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(14.738220481169323d, (-36.7368005696771d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-14.738220481169323d));

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test130"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(14273996, 962);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 14273034);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test131"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(3376, 9891);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 33392016);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test132"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(2L, 1348L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2696L);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test133"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(5L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test134"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-1.8922104949180976d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test135"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double[] var6 = var0.sample(100);
//     double var7 = var0.sample();
//     double var8 = var0.sample();
//     var0.reseedRandomGenerator(10L);
//     double var11 = var0.getMean();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var13 = var0.sample(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.14315082944386373d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.24937445755232082d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test136"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var1.contract();
    int var3 = var1.start();
    float var4 = var1.getContractionCriteria();
    var1.clear();
    var1.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.5f);

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test137"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var11 = var0.nextLong(29L, 40318L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextSecureInt(1919, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.539087694125625d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "03cd49ef34"+ "'", var8.equals("03cd49ef34"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 31772L);
// 
//   }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test138"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.21858257864865782d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2221670820445176d);

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test139"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextUniform(0.2577047455984825d, 13.770182159584014d);
//     long var6 = var1.nextPoisson(23.012289905639566d);
//     java.lang.String var8 = var1.nextHexString(2041);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextUniform(7.068586110544621d, (-0.8652627755109201d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.3398373305542672d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 26L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "4f11edb5d5316911f2e7dec2f2fb7b77a249d4b748434f783501ea5e2aeb321bd4dc63c43007ad52d69eea9e51a98ec0e9ea3eec0f5eb0b5ea744e773a917de2ff90f2f055b6d8dd0e2dcdbcf20c3c1aba7fc491e164ee9e37a7173d21040bc716d3094a9939179b297322f918ab88fa8452e5dc6268122e7fc0225d51ab8806fb513aadebf2c780226753d01884b87903c900885a8805efcf719051f44ef2febf943a0f7132da636a567ece2c85cf857e02df5bce9bd6751acc1461ab354ba7983898ab67dde4d6f3b941b4a893e25bbd9522f9056fb64ac2d302cd097af97b36e3fc94de3e8ac712ece8a0af4bf7247a737a4a394886da855205ebad123eeb3e45585e669e7913d8dd0c5d505b3b7102d13a731853374e0e6256dbc5b17b1a62d5289c5b48711568a78e7673e4618151d6176fc732c0f149cef8bbb4810a30375c245fa1b144f737030667a23d093b35c74fc7e100383eb4b5d5ceb96b74d99054600d3f8c1ae2a4394833479139fb4fa4f875ce08f0c6fd08a27668db96895066bcc12052c8665ba880bc8786ea3a8d5498d9c274a3cdf2298aa926b376ac606a45ab5c6c158a48def6adaa4b60c0101cbb16412720ae36b097c17f2f341c6fd8b0dc5abccfb9d7c02b3d66f0ae2c093fe6f042b41388df6d9cde29001b4eeec9ae3c6982af8ef7932d9b8ae49fdd2f033e84bee43d5428c404e6167a5ab77a5493b0dbdd8eaec08825eda6e9e58af831adcde2a17c5bc40f8b364bf1f8c371324ae227b1dd892165058fc41a0fd5e0248a57bf949fdf6ef973be6763d9f7ed916fb1a1823d0e1cebb92638c30dac5f752da26c8ebf1f2cba3fdff589021b2a0c991a94813b7d21c808e48a44ef7dac856f56de1c8f4efc57cc7d5641f7907a773c56e6ce1f5f9c225370f5b06092e7302c76075219255d04a3bf5b3f93f2dbc98c9b41c3b80611543dd924588d12ca8749d1d631566ecf62eb249f4db2f6d53dd3ca3fe01698a63ea0feba05b59fcc218faeb9aa85622b57cdf8d9cfce7ea5f711c606cfe7bd393024296ea579cd4ca82a13a19c26e3518e3ba91c32385ec8004032c115957e42dab61b4e51a7e03145b6575d0fea57adab77828caf011b94caab85b2b0434a421b23270a352b1a5c67a8765cb22173d2cc53af75714acac75dd3370cffc0372bb998e17aa97e67186648d47911b6a4007dc2e2e4cf01283ad5547b446fce12bf0c7ede3846fd4086064b5469e29f8f1a1f9e37675ca62f775aab5cda1bad9bcd0a6f3ae67c2337bc8db5cceb54f9f6a5ae3b9337594e4160e7904abb41de8ff734ea11810da25bb31d7ad2dd9919339f221ff3acd6135788a32d508bda65962d23f8f88c6600d013d0c817adf747eeef78d4c063db4ed792a39b9d716d396913725e54665b746efb00c0e5ce22f9662b709a9c1"+ "'", var8.equals("4f11edb5d5316911f2e7dec2f2fb7b77a249d4b748434f783501ea5e2aeb321bd4dc63c43007ad52d69eea9e51a98ec0e9ea3eec0f5eb0b5ea744e773a917de2ff90f2f055b6d8dd0e2dcdbcf20c3c1aba7fc491e164ee9e37a7173d21040bc716d3094a9939179b297322f918ab88fa8452e5dc6268122e7fc0225d51ab8806fb513aadebf2c780226753d01884b87903c900885a8805efcf719051f44ef2febf943a0f7132da636a567ece2c85cf857e02df5bce9bd6751acc1461ab354ba7983898ab67dde4d6f3b941b4a893e25bbd9522f9056fb64ac2d302cd097af97b36e3fc94de3e8ac712ece8a0af4bf7247a737a4a394886da855205ebad123eeb3e45585e669e7913d8dd0c5d505b3b7102d13a731853374e0e6256dbc5b17b1a62d5289c5b48711568a78e7673e4618151d6176fc732c0f149cef8bbb4810a30375c245fa1b144f737030667a23d093b35c74fc7e100383eb4b5d5ceb96b74d99054600d3f8c1ae2a4394833479139fb4fa4f875ce08f0c6fd08a27668db96895066bcc12052c8665ba880bc8786ea3a8d5498d9c274a3cdf2298aa926b376ac606a45ab5c6c158a48def6adaa4b60c0101cbb16412720ae36b097c17f2f341c6fd8b0dc5abccfb9d7c02b3d66f0ae2c093fe6f042b41388df6d9cde29001b4eeec9ae3c6982af8ef7932d9b8ae49fdd2f033e84bee43d5428c404e6167a5ab77a5493b0dbdd8eaec08825eda6e9e58af831adcde2a17c5bc40f8b364bf1f8c371324ae227b1dd892165058fc41a0fd5e0248a57bf949fdf6ef973be6763d9f7ed916fb1a1823d0e1cebb92638c30dac5f752da26c8ebf1f2cba3fdff589021b2a0c991a94813b7d21c808e48a44ef7dac856f56de1c8f4efc57cc7d5641f7907a773c56e6ce1f5f9c225370f5b06092e7302c76075219255d04a3bf5b3f93f2dbc98c9b41c3b80611543dd924588d12ca8749d1d631566ecf62eb249f4db2f6d53dd3ca3fe01698a63ea0feba05b59fcc218faeb9aa85622b57cdf8d9cfce7ea5f711c606cfe7bd393024296ea579cd4ca82a13a19c26e3518e3ba91c32385ec8004032c115957e42dab61b4e51a7e03145b6575d0fea57adab77828caf011b94caab85b2b0434a421b23270a352b1a5c67a8765cb22173d2cc53af75714acac75dd3370cffc0372bb998e17aa97e67186648d47911b6a4007dc2e2e4cf01283ad5547b446fce12bf0c7ede3846fd4086064b5469e29f8f1a1f9e37675ca62f775aab5cda1bad9bcd0a6f3ae67c2337bc8db5cceb54f9f6a5ae3b9337594e4160e7904abb41de8ff734ea11810da25bb31d7ad2dd9919339f221ff3acd6135788a32d508bda65962d23f8f88c6600d013d0c817adf747eeef78d4c063db4ed792a39b9d716d396913725e54665b746efb00c0e5ce22f9662b709a9c1"));
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test140"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 1.1368685E-13f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test141"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(8.277113894567627d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.220570418233359d));

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test142"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.4992246854372801d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.47874499203777093d);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test143"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("2036f642e40e8f9ff1fb7c4576214b0e18daf24a608c4c023efba898e8e5c8cb47cda0633e487bfaba3921aba9bd6f055cc7", "8e8e35fa00");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.39865798288044163d));
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test144"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.5000005f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test145"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     var0.reSeed(14L);
//     double var14 = var0.nextExponential(0.9999997887160175d);
//     long var16 = var0.nextPoisson(0.8259324122591327d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var18 = var0.nextSecureHexString((-408490575));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 16.924314804452056d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "7dbc404b74"+ "'", var8.equals("7dbc404b74"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.2526601508392328d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.3844973909690124d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0L);
// 
//   }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test146"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextUniform(0.2577047455984825d, 13.770182159584014d);
//     long var6 = var1.nextPoisson(23.012289905639566d);
//     java.lang.String var8 = var1.nextHexString(2041);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextWeibull((-0.1597400378918494d), 12.725432724837008d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 6.009190333711623d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 22L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "e2362cc233f667f3767b37f1387e545c3cb1aca5ec991045aa6a5890dc99b517812968e47bf850b9ecb94960b52854e10757707d5a7be88b24a5fa951562d69fc327b189d5e60c5557d26b5fb162efb410bf4d7450886b8e3e4f8e55056755b49984dd64642578294fc9c7937b38fe537db3047197c78e99001e202ffd02ef8a24f383e97dd879da0398d16ce6b70b04bb8050492fd83769da83b5a8aba9de2f3825261c39af6d6dfad685bbe0773d20e66c5076a9ce4cf7e27eba1013518492830434ab0ea74445f1616561996e61fe9a14d43f2cdb600731fc2de58c45ac5c0a4b0f5c995a35fa9737f409c9f844f949e7447425c9f9391686121b5e67f43f66a1516338f2a53e71e1d1059c577f4e09a2a38e4bc0af814bcb9961b15a308e99da055689c0ed6a0c40cbf909264fba96c01b5e237b14bce5f166240014f326a8c9b634988f769d999ffd4df73d7cc985082e8b4a6f578af50aaf9956c79b185720293085a5ac852114614d133f0e0da7b7364cc9b28039607bd9234dd537b0e5b21dc087c78097b5da70292e6f34a74a97037e368c9932b4e53a46066a53cb1358559ee4705bdfdb68c697cc1aecadea8d9461d3184a98f6510c9ec73c54c347a2b2dc768874c1e44118008857abe76f0d5f9d50ec9e8e7c01a5f879da98ae2dc2301247f77cc52e64bd5bdd211c4c5d2e0c96cbebdb4259dec2e88b2dc682835748a9d0af98418be207bccd0cf31871813e177f4c3a28813982bd2f71630c74bdbf753cd14731cb179cec17a17de1a46e76c99f82e6505ce8fb50cf13b98787f98b9aed38c4df66ced21eb42849927cc6a9dc8329050ed9ac05464571c7493a12adb9a4866787f043a6001cd1e7730c37c551a4a93f10ab99c58c1f298e6a3e6e0b6c7d19767f4d9c5f72c059e9d9d6080f98f523543fcd05cfbb42dce84b05bd749813d99263070cdaabe3362e6a53634bf848a3f70aa3f5d448076ad95c862ac5123239f7b4aad746c540bd98c16acd12c7503da924b6e7fd0fe4d83cd743e65c8d0cfcddd67c9a98d543ed058eb08e87db35e4d2927ce4b7cb648430577b5df933f2e1390b1783d9e5477b2592aba71c2a14b5808631f3ba0d5d93c866d9f3bcba8261840fd98dd4b52dfce2cc2a075a44536c2187821c15c066ab8d20e81b0b067b3484c3166fa769b3e275fa1e31fefdd36e8e9470126f6fbdb29d7a79ab0325ebe68332e9e133dc5ce949f635b8613744ceef411e8de0609d9f4b5e50273641d04785fc3e32ba14bee1b088c755b78ddc3e7a5854d6501e3db97ba002018f70d1bc963bca812efcbcbb6cfbe78058619d6d54bb80a28988ae21b17216132e18a19eab944966ffc7f262b6ac0bdc65e350a2375148e14290fbe2cc63b4687352195f16525d12b9f21d83c2f96331e7d4f4e5a0c7cdfe05304"+ "'", var8.equals("e2362cc233f667f3767b37f1387e545c3cb1aca5ec991045aa6a5890dc99b517812968e47bf850b9ecb94960b52854e10757707d5a7be88b24a5fa951562d69fc327b189d5e60c5557d26b5fb162efb410bf4d7450886b8e3e4f8e55056755b49984dd64642578294fc9c7937b38fe537db3047197c78e99001e202ffd02ef8a24f383e97dd879da0398d16ce6b70b04bb8050492fd83769da83b5a8aba9de2f3825261c39af6d6dfad685bbe0773d20e66c5076a9ce4cf7e27eba1013518492830434ab0ea74445f1616561996e61fe9a14d43f2cdb600731fc2de58c45ac5c0a4b0f5c995a35fa9737f409c9f844f949e7447425c9f9391686121b5e67f43f66a1516338f2a53e71e1d1059c577f4e09a2a38e4bc0af814bcb9961b15a308e99da055689c0ed6a0c40cbf909264fba96c01b5e237b14bce5f166240014f326a8c9b634988f769d999ffd4df73d7cc985082e8b4a6f578af50aaf9956c79b185720293085a5ac852114614d133f0e0da7b7364cc9b28039607bd9234dd537b0e5b21dc087c78097b5da70292e6f34a74a97037e368c9932b4e53a46066a53cb1358559ee4705bdfdb68c697cc1aecadea8d9461d3184a98f6510c9ec73c54c347a2b2dc768874c1e44118008857abe76f0d5f9d50ec9e8e7c01a5f879da98ae2dc2301247f77cc52e64bd5bdd211c4c5d2e0c96cbebdb4259dec2e88b2dc682835748a9d0af98418be207bccd0cf31871813e177f4c3a28813982bd2f71630c74bdbf753cd14731cb179cec17a17de1a46e76c99f82e6505ce8fb50cf13b98787f98b9aed38c4df66ced21eb42849927cc6a9dc8329050ed9ac05464571c7493a12adb9a4866787f043a6001cd1e7730c37c551a4a93f10ab99c58c1f298e6a3e6e0b6c7d19767f4d9c5f72c059e9d9d6080f98f523543fcd05cfbb42dce84b05bd749813d99263070cdaabe3362e6a53634bf848a3f70aa3f5d448076ad95c862ac5123239f7b4aad746c540bd98c16acd12c7503da924b6e7fd0fe4d83cd743e65c8d0cfcddd67c9a98d543ed058eb08e87db35e4d2927ce4b7cb648430577b5df933f2e1390b1783d9e5477b2592aba71c2a14b5808631f3ba0d5d93c866d9f3bcba8261840fd98dd4b52dfce2cc2a075a44536c2187821c15c066ab8d20e81b0b067b3484c3166fa769b3e275fa1e31fefdd36e8e9470126f6fbdb29d7a79ab0325ebe68332e9e133dc5ce949f635b8613744ceef411e8de0609d9f4b5e50273641d04785fc3e32ba14bee1b088c755b78ddc3e7a5854d6501e3db97ba002018f70d1bc963bca812efcbcbb6cfbe78058619d6d54bb80a28988ae21b17216132e18a19eab944966ffc7f262b6ac0bdc65e350a2375148e14290fbe2cc63b4687352195f16525d12b9f21d83c2f96331e7d4f4e5a0c7cdfe05304"));
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test147"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(9448);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9448);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test148"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(185482209, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 381440865);

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test149"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     java.lang.Class var2 = var1.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var7 = var4.nextSecureLong((-1L), 1L);
//     double var10 = var4.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var12 = var4.nextHexString(10);
//     int var15 = var4.nextInt((-1), 100);
//     double var17 = var4.nextT(5.867156662812015d);
//     double var19 = var4.nextExponential(11.771947930619202d);
//     int var22 = var4.nextBinomial(0, 0.0031612049524534893d);
//     var4.reSeedSecure(2184L);
//     boolean var25 = var1.equals((java.lang.Object)2184L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2.5006167915079485d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "64194836e7"+ "'", var12.equals("64194836e7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-1.0328453233143338d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 20.26878729288562d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
// 
//   }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test150"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     double var12 = var0.nextCauchy(100.0d, 120.0d);
//     org.apache.commons.math3.distribution.IntegerDistribution var13 = null;
//     int var14 = var0.nextInversionDeviate(var13);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test151"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(179L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test152"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var21 = var18.nextSecureLong((-1L), 1L);
//     double var24 = var18.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var26 = var18.nextSecureHexString(100);
//     double var28 = var18.nextT(20.696514663540924d);
//     org.apache.commons.math3.distribution.NormalDistribution var29 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var30 = var29.getStandardDeviation();
//     double[] var32 = var29.sample(1);
//     double var33 = var29.getMean();
//     double[] var35 = var29.sample(100);
//     double var36 = var29.sample();
//     double var37 = var29.sample();
//     double var38 = var18.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     double var39 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     org.apache.commons.math3.distribution.NormalDistribution var40 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var41 = var40.getStandardDeviation();
//     double[] var43 = var40.sample(1);
//     double var44 = var40.getMean();
//     double[] var46 = var40.sample(100);
//     double var47 = var40.sample();
//     double var48 = var40.sample();
//     var40.reseedRandomGenerator(10L);
//     boolean var51 = var40.isSupportLowerBoundInclusive();
//     boolean var52 = var40.isSupportLowerBoundInclusive();
//     double var53 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var40);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var57 = var0.nextHypergeometric(1868, 0, 10178);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 37.552344583313506d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "22c3af0c4850643e83a3165f7074d7246b47906e5c1d60d9169bf1aad1c0ac9aaa5766584e9f53459d8c7608bdcb0d83b3b9"+ "'", var8.equals("22c3af0c4850643e83a3165f7074d7246b47906e5c1d60d9169bf1aad1c0ac9aaa5766584e9f53459d8c7608bdcb0d83b3b9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.039381574998461136d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 3.3615629717590725d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "080963491d884772591c5a60e62b086398e2d20df708944beab3c9cd3fad09b5c5615bf645fcbfacc49827448f934f60b201"+ "'", var26.equals("080963491d884772591c5a60e62b086398e2d20df708944beab3c9cd3fad09b5c5615bf645fcbfacc49827448f934f60b201"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-1.3607439445171896d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0.7404236117316764d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0.20421888026072443d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0.03898021921703989d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0.4839648007435197d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1.7672753246355823d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == (-1.139124160648363d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == (-0.08864418651965986d));
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test153"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    java.lang.Class var11 = var10.getDeclaringClass();
    java.lang.Class var12 = var10.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    java.lang.String var14 = var10.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var8, var10);
    org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var17 = var16.getStandardDeviation();
    double[] var19 = var16.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var25 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
    double[] var30 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray(var30);
    double var32 = var21.mannWhitneyU(var25, var30);
    double var33 = var15.mannWhitneyUTest(var19, var25);
    var4.addElements(var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setElement((-79579695), (-0.4607121656995548d));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "AVERAGE"+ "'", var14.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 4.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.17971249487899976d);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test154"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.17822214633236277d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7490383304207238d));

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test155"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    double[] var6 = var4.getInternalValues();
    org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var8 = var7.getStandardDeviation();
    double[] var10 = var7.sample(1);
    double var11 = var7.getMean();
    double[] var13 = var7.sample(100);
    var4.addElements(var13);
    var4.discardMostRecentElements(44);
    var4.addElement(0.9999999999999996d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test156"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(1.1394310519489506d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.172616570636548d);

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test157"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     var0.reSeed();
//     double var15 = var0.nextChiSquare(7.617953921806563d);
//     java.lang.String var17 = var0.nextSecureHexString(1916);
//     int var20 = var0.nextZipf(11474, 0.8744549098686318d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var0.nextUniform(0.33421337133949025d, 0.15400265077124822d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.7328693136954727d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "2e4d333134"+ "'", var8.equals("2e4d333134"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 5.5937443307699946d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "1ffb668f98f0552fbdb808312fa352a115106de2df0c9ea3648ba50a410ac2f6753defae6a34274151be89d7a2b0984885573fe8695107370b67a60c2d07012843a83224c3b5a48be146651885a8a3a84ab6e4ae09691c5246699d0e66368c985c8fe9f3f0583849048e05a4dd68dd09cb96768eb878655a1915cd46a17cd4cf08047d3d98093fbd9622cc9edd43b615fab199a62342ffbacc3870ff1cbc05d91e151a8e60869207405d46bb92f1b257c7639ef16d9d54b5594b7e9252c1d3e63f5674ec4150ce5fab8a61a7b3721b6b1ea912e15798f644338d9f2288568f202315f15bc9f99c5412b5360cc70fd2dfd311f7e9f30bd76001185579b5fe04106f7a637da4d9a872a6d8d049510d1b7549ec763752dcd89440e1f249235b312df1d3058646d7da7d3237b603bb62f6d946da4628d8f8ad0f4e385f10a4fce1dfd924b497f8e157de37dfb6729190f8d12967d8231c1447f57532ac4634d3ea49cdfa5192ef6899226cd05879d2b55082ed4d80430c7e75ebb7bd5cf0a10a1bdcd8c48f25583268d14aa393d69b4078dcb8735a6c6072224b5c04aa6c3c58ec7ac91b71a2312df369972d128ff8f68abc6bdb571b68b69019c8177778eddcebe9bbd6b2c478d51fc646a881accf06f3fc26e3ea7b46c9a39aa7e416720424a9778ba595c49c45eb87a930e1ff20f70d7b545ff0c5332a4c5372165aefd0d0fa752af4dcb532adc434734e3974f31a57f73576fd55b6374b11da44db3eac64310c93f9b9276cc37a820ed1304fd08c0b865416b151162cc9633b543853d7c57d46309f843bce7580a39231a9efc53939aad386ab3aa67db44b132530782c3db8eef2ac3fe38c59b323e632837ef339753c2e06ec8bff3d3bad8bcef031c358764dc15a1aff1087a101c777c85dbd8380d7db49a7d62a691392b53d94f9a7aeaf8997f04ab0f1ba01984fa36af76eb4df0e33ce62caed03be3659e1ab2cb54094300dad2fac57ee5b482dbb39cb4241fc6dbe2b80aebd42cc66a16b8fb09197e0e46c15b42a280ca1a956c8676e915cfd5db4291545eb676bc717a19e231a3111d23079a0bde8456aa153a0837107744a6fca54acd372d6a07e6150281bbb4866a71897870e0882cce050326a352dcaf5bb95590b4c1ee0f1373fd1d80643d5b33d9d9dcffa396c31ae8479400042a55715f73a69a2d6c88e69f4ff74c229fddb0c03e30fc06056f2c09a9f0a9ab525fbd7065dcfa3250db419043485c99c00a7b43b4bc116797dda1a93d1ec1bfe4efd69ae1e68ebe97ef024f40f0d4c0bcf24763703b1168d22c1842aaf7d0f0eb54b9e96a8756028c6e9097731439a350c"+ "'", var17.equals("1ffb668f98f0552fbdb808312fa352a115106de2df0c9ea3648ba50a410ac2f6753defae6a34274151be89d7a2b0984885573fe8695107370b67a60c2d07012843a83224c3b5a48be146651885a8a3a84ab6e4ae09691c5246699d0e66368c985c8fe9f3f0583849048e05a4dd68dd09cb96768eb878655a1915cd46a17cd4cf08047d3d98093fbd9622cc9edd43b615fab199a62342ffbacc3870ff1cbc05d91e151a8e60869207405d46bb92f1b257c7639ef16d9d54b5594b7e9252c1d3e63f5674ec4150ce5fab8a61a7b3721b6b1ea912e15798f644338d9f2288568f202315f15bc9f99c5412b5360cc70fd2dfd311f7e9f30bd76001185579b5fe04106f7a637da4d9a872a6d8d049510d1b7549ec763752dcd89440e1f249235b312df1d3058646d7da7d3237b603bb62f6d946da4628d8f8ad0f4e385f10a4fce1dfd924b497f8e157de37dfb6729190f8d12967d8231c1447f57532ac4634d3ea49cdfa5192ef6899226cd05879d2b55082ed4d80430c7e75ebb7bd5cf0a10a1bdcd8c48f25583268d14aa393d69b4078dcb8735a6c6072224b5c04aa6c3c58ec7ac91b71a2312df369972d128ff8f68abc6bdb571b68b69019c8177778eddcebe9bbd6b2c478d51fc646a881accf06f3fc26e3ea7b46c9a39aa7e416720424a9778ba595c49c45eb87a930e1ff20f70d7b545ff0c5332a4c5372165aefd0d0fa752af4dcb532adc434734e3974f31a57f73576fd55b6374b11da44db3eac64310c93f9b9276cc37a820ed1304fd08c0b865416b151162cc9633b543853d7c57d46309f843bce7580a39231a9efc53939aad386ab3aa67db44b132530782c3db8eef2ac3fe38c59b323e632837ef339753c2e06ec8bff3d3bad8bcef031c358764dc15a1aff1087a101c777c85dbd8380d7db49a7d62a691392b53d94f9a7aeaf8997f04ab0f1ba01984fa36af76eb4df0e33ce62caed03be3659e1ab2cb54094300dad2fac57ee5b482dbb39cb4241fc6dbe2b80aebd42cc66a16b8fb09197e0e46c15b42a280ca1a956c8676e915cfd5db4291545eb676bc717a19e231a3111d23079a0bde8456aa153a0837107744a6fca54acd372d6a07e6150281bbb4866a71897870e0882cce050326a352dcaf5bb95590b4c1ee0f1373fd1d80643d5b33d9d9dcffa396c31ae8479400042a55715f73a69a2d6c88e69f4ff74c229fddb0c03e30fc06056f2c09a9f0a9ab525fbd7065dcfa3250db419043485c99c00a7b43b4bc116797dda1a93d1ec1bfe4efd69ae1e68ebe97ef024f40f0d4c0bcf24763703b1168d22c1842aaf7d0f0eb54b9e96a8756028c6e9097731439a350c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 330);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test158"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.9999998f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test159"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.2411313939991078d, 8.95239708538578d, (-0.8438409461494198d), 4);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test160"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test161"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)(-1), (java.lang.Number)10, (java.lang.Number)6.621888603197341d);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test162"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-0.8622539209902649d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6974171281913673d));

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test163"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(11395);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test164"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(381440865, 14273034);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.089784034779425E7d);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test165"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)183L);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test166"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.5395119302779527d, (java.lang.Number)319.5453426373688d, false);
    java.lang.Number var4 = var3.getMax();
    java.lang.Number var5 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 319.5453426373688d+ "'", var4.equals(319.5453426373688d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 319.5453426373688d+ "'", var5.equals(319.5453426373688d));

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test167"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-1.0598623819323194d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test168"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(17.121147349495974d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.726589775519777E7d);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test169"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.004492688352124083d, true);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test170"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)2.3930658372149933d, (java.lang.Number)0.0f, false);
//     boolean var5 = var4.getBoundIsAllowed();
//     java.lang.Number var6 = var4.getMin();
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     org.apache.commons.math3.exception.util.Localizable var12 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var16 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var12, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
//     java.lang.Throwable[] var17 = var16.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var18 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var11, (java.lang.Object[])var17);
//     org.apache.commons.math3.exception.MathArithmeticException var19 = new org.apache.commons.math3.exception.MathArithmeticException(var10, (java.lang.Object[])var17);
//     org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException(var9, (java.lang.Object[])var17);
//     org.apache.commons.math3.exception.MathArithmeticException var21 = new org.apache.commons.math3.exception.MathArithmeticException(var8, (java.lang.Object[])var17);
//     org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var7, (java.lang.Object[])var17);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test171"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(3376);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test172"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, 4.2E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test173"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var2, (java.lang.Number)(-64L), (java.lang.Number)(-1.4998528973459138d), false);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test174"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.0d, 1.5066193004929886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test175"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-0.45979381404967545d), 0.0030728678011815447d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.45980408214246105d);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test176"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.32705216023560196d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9469934586322785d);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test177"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var13 = var0.nextT(5.867156662812015d);
//     double var15 = var0.nextExponential(11.771947930619202d);
//     int var18 = var0.nextBinomial(0, 0.0031612049524534893d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var0.nextF(7.138332483316814d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.438772871758046d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ee265464a8"+ "'", var8.equals("ee265464a8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.16809786623619277d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2.8464812599403984d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test178"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var7);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 336L);
    org.apache.commons.math3.exception.NumberIsTooLargeException var12 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)9066, (java.lang.Number)336L, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test179"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var4.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test180"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double[] var3 = var0.sample(10);
    double var4 = var0.getStandardDeviation();
    double var5 = var0.getStandardDeviation();
    double var6 = var0.getMean();
    double var7 = var0.getSupportLowerBound();
    double var8 = var0.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.POSITIVE_INFINITY);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test181"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(13.488606530827093d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 360576.47541006305d);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test182"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.9059266752857845d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5043245423323732d);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test183"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var9 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var5, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var10 = var9.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MaxCountExceededException var14 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.13124082154743716d, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test184"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.059233998853640384d, (-12.669478029470282d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.136917357012582d);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test185"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(1053960288888713761L, 39L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1053960288888713761L);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test186"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(1342177280L, (-2L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1342177280L);

  }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test187"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
//     int var2 = var1.getExpansionMode();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var3.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
//     java.lang.Class var8 = var7.getDeclaringClass();
//     int var9 = var7.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5, var7);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var12.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var12.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var16 = var12.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
//     boolean var20 = var18.equals((java.lang.Object)Double.POSITIVE_INFINITY);
//     boolean var22 = var18.equals((java.lang.Object)(-0.4255538433808183d));
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var16, var18);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var24 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var11, var18);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var25.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var27 = var25.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var28 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var29 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var31 = var30.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var32 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var29, var31);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var28, var31);
//     java.lang.String var34 = var31.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var35 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var27, var31);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var37 = var36.getTiesStrategy();
//     java.lang.Class var38 = var37.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var37);
//     java.lang.String var40 = var37.toString();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var41 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var27, var37);
//     org.apache.commons.math3.distribution.NormalDistribution var42 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var43 = var42.getStandardDeviation();
//     double[] var45 = var42.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var46 = new org.apache.commons.math3.util.ResizableDoubleArray(var45);
//     double[] var47 = var46.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var48 = new org.apache.commons.math3.util.ResizableDoubleArray(var47);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var49 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var53 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var54 = new org.apache.commons.math3.util.ResizableDoubleArray(var53);
//     double[] var58 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var59 = new org.apache.commons.math3.util.ResizableDoubleArray(var58);
//     double var60 = var49.mannWhitneyU(var53, var58);
//     double var61 = var41.mannWhitneyUTest(var47, var53);
//     org.apache.commons.math3.distribution.NormalDistribution var62 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var63 = var62.getStandardDeviation();
//     double[] var65 = var62.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var66 = new org.apache.commons.math3.util.ResizableDoubleArray(var65);
//     int var67 = var66.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var68 = var66.copy();
//     var66.addElement((-0.43408597923864894d));
//     double var72 = var66.getElement(0);
//     var66.clear();
//     org.apache.commons.math3.distribution.NormalDistribution var74 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var75 = var74.getStandardDeviation();
//     double[] var77 = var74.sample(1);
//     double var78 = var74.getMean();
//     double[] var80 = var74.sample(100);
//     var66.addElements(var80);
//     double var82 = var24.mannWhitneyU(var53, var80);
//     var1.addElements(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var34 + "' != '" + "AVERAGE"+ "'", var34.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + "AVERAGE"+ "'", var40.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 4.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 0.17971249487899976d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == (-0.34395843497826445d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == 231.0d);
// 
//   }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test188"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(40420L, 1073741824L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 43400644526080L);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test189"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    var4.addElement(0.0d);
    double var9 = var4.substituteMostRecentElement(1.7058143237097114d);
    float var10 = var4.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test190"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(408490575, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 408490575);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test191"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    boolean var7 = var0.isSupportUpperBoundInclusive();
    double var8 = var0.getStandardDeviation();
    double var9 = var0.getStandardDeviation();
    boolean var10 = var0.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test192"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(8899, (-1912));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test193"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos((-11.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test194"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     var0.reSeed();
//     var0.reSeedSecure(193L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextCauchy(1.2411313939991078d, (-1.1998905478105057d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.996462833397743d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "aa1cc48a00c1b582648eb9f0870840fc2f5c8106faf2fd461903b8c38a28a1c816ded875c341b826b4c6c295a2cfe1884603"+ "'", var8.equals("aa1cc48a00c1b582648eb9f0870840fc2f5c8106faf2fd461903b8c38a28a1c816ded875c341b826b4c6c295a2cfe1884603"));
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test195"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 11L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, (-64L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test196"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.0d, 3.674181234459348d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test197"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test198"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(30.0d, 13.648353183307265d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.143837665461052d);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test199"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1929.4784382564899d);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test200"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test201"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(9181, 243);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9424);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test202"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test203"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, 17.412259994235388d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test204"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
    java.lang.Object var17 = null;
    boolean var18 = var4.equals(var17);
    var4.setElement(100, 0.0d);
    double[] var22 = var4.getInternalValues();
    float var23 = var4.getExpansionFactor();
    int var24 = var4.getExpansionMode();
    var4.discardFrontElements(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setNumElements((-297256655));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test205"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    boolean var7 = var0.isSupportUpperBoundInclusive();
    double var8 = var0.getStandardDeviation();
    double var10 = var0.cumulativeProbability(110.38582314186594d);
    boolean var11 = var0.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test206"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var13 = var0.nextF(0.6351254179184792d, 1.0919228035719635d);
//     var0.reSeedSecure();
//     double var17 = var0.nextWeibull(21.0d, 0.9999999999999996d);
//     double var20 = var0.nextBeta(2.6043074034995927E-287d, 3.5849972992627093d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.727752825295894d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "cce590b2a0"+ "'", var8.equals("cce590b2a0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.140742250409609d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.0263729125456353d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.055932391388095d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.0d);
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test207"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(3.292378755306352d, 5.861552970684626d, 0.8109766711360142d);
    double var5 = var3.probability(13.359855606410402d);
    var3.reseedRandomGenerator((-8L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test208"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(4.392604795910704d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999994771264d);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test209"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(193L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 193L);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test210"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double[] var3 = var0.sample(10);
    double var4 = var0.getStandardDeviation();
    double var5 = var0.getStandardDeviation();
    boolean var6 = var0.isSupportConnected();
    double var7 = var0.getSupportUpperBound();
    double var8 = var0.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test211"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(6.474290387216851d, 0.017688387388495763d);
    double var3 = var2.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 6.474290387216851d);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test212"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, 1549);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test213"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.5000002f, 34.18167228038127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5000005f);

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test214"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeedSecure(0L);
//     long var15 = var0.nextSecureLong(1L, 31L);
//     int var18 = var0.nextInt(1831, 9181);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 23.556688781581023d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "7d07d06c84"+ "'", var8.equals("7d07d06c84"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 17L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 4337);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test215"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(11.179981975584864d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 35840.53501424614d);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test216"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(1.3633284403015629d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9461495467846752d);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test217"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(100.00001f, 1848);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test218"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(100.0f, 4.2E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.2E-45f);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test219"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(8.660004026414073d, 120.0d, (-1.7746746308192902d), 17190);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test220"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(12.033846781268247d, (-0.9242374988126698d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test221"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var0.nextLong(179L, 7L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.4466306132599644d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "e09cb0bb775f3842e341c914f59d46560440f6b613fa9ca6c831db1c23ab33aaabdeeb77b17632e3c865840e61fa5c6db42f"+ "'", var8.equals("e09cb0bb775f3842e341c914f59d46560440f6b613fa9ca6c831db1c23ab33aaabdeeb77b17632e3c865840e61fa5c6db42f"));
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test222"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)21L, (java.lang.Number)5.641560223443412d, true);
    boolean var5 = var4.getBoundIsAllowed();
    boolean var6 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test223"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     var0.reSeed();
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 29.541564414477328d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ee50b1fbf2"+ "'", var8.equals("ee50b1fbf2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6L);
// 
//   }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test224"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-0.6936007984000367d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6393101510513624d));

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test225"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)16.35282631844513d, (java.lang.Number)596L, true);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test226"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-0.8652627755109201d));
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test227"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(2.8E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test228"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(4.2E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.2E-45f);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test229"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1.8136343340898944d);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test230"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.1598610844832842d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test231"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("cea8e8cec2");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test232"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.000001f);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test233"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(1.266414387970774d, 1.9977662621293E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000004718517073d);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test234"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.contract();
    int var8 = var6.getExpansionMode();
    var6.setElement(5, 20.696514663540924d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.discardFrontElements(57);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test235"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)Double.NaN, var2, false);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test236"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.15729920705028488d, 32.92464774372489d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.88917124763015d));

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test237"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(8904);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8904);

  }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test238"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(0L);
//     long var17 = var0.nextPoisson(7.769493748166378d);
//     double var19 = var0.nextExponential(8.563154148722202d);
//     double var22 = var0.nextWeibull(10.132200867889637d, 2.717220411501478d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var25 = var0.nextLong(4L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.19050579555081432d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "2707ddea7b"+ "'", var8.equals("2707ddea7b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.79377365681524d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 11674);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 12.399730408920377d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 2.7640811050131986d);
// 
//   }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test239"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1980, (java.lang.Number)(-4.440892098500627E-16d), false);
    java.lang.Number var4 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-4.440892098500627E-16d)+ "'", var4.equals((-4.440892098500627E-16d)));

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test240"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-744.4400719213812d), 0.9999494975001091d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-744.4400719213812d));

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test241"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-1342158336L), 2120L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1342156216L));

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test242"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)4.872996023937328d);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test243"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-1.004438552161161d), (-1.0341195799257004d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4416310591317447d);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test244"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.7754771523956807d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7754771523956808d);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test245"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
    java.lang.Object var17 = null;
    boolean var18 = var4.equals(var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setContractionCriteria(1.4E-45f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test246"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.010100839201864612d, (java.lang.Number)(-1), (java.lang.Number)14.27900880653991d);
//     java.lang.Number var5 = var4.getLo();
//     java.lang.Number var6 = var4.getHi();
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     java.lang.Number var11 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var12 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)1.1368685E-13f, var11);
//     java.lang.Number var13 = var12.getHi();
//     java.lang.Throwable[] var14 = var12.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var14);
//     org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var7, (java.lang.Object[])var14);
// 
//   }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test247"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma((-1.765071985168704d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test248"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionFactor(2.5000005f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test249"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(8.789412645108149d, 21.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8.789412645108149d);

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test250"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     double var16 = var0.nextGamma(0.11604808277231957d, 0.8382617516745859d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var20 = var0.nextLong(50761728L, (-1342136858L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.3396152466726745d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "0ed45b23b8"+ "'", var8.equals("0ed45b23b8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.2455182057621779d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 9226);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.002916903121203704d);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test251"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.5256849369753084d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.27927446711744686d));

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test252"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-203.38905646158537d));

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test253"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(39916800L, (-536829416L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-21428512432588800L));

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test254"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var2 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)(-1), (java.lang.Object[])var2);
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var6, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
//     java.lang.Throwable[] var11 = var10.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.MathArithmeticException var13 = new org.apache.commons.math3.exception.MathArithmeticException(var4, (java.lang.Object[])var11);
//     var3.addSuppressed((java.lang.Throwable)var13);
//     java.lang.Throwable var15 = null;
//     var3.addSuppressed(var15);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test255"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.9999999f, 100.00001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9999999f);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test256"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3440585709080678E43d);

  }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test257"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.6894714982128501d, (-0.10292482065295498d), (-0.5872139151569291d), 9192904);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test258"); }


    float var2 = org.apache.commons.math3.util.FastMath.min((-0.99999994f), 2097152.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.99999994f));

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test259"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-4.440892098500626E-16d), 1.1102230246251565E-16d, 0.9999494957997512d);
    double var4 = var3.getMean();
    double var5 = var3.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-4.440892098500626E-16d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-4.440892098500626E-16d));

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test260"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(9694, 89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 89);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test261"); }


    double[] var3 = new double[] { 0.0d, (-1.0d), 0.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.getNumElements();
    int var6 = var4.getNumElements();
    float var7 = var4.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0f);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test262"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(1919, 1916);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test263"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1491, 206L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2123201639));

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test264"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-203.38905646158537d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test265"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     var4.contract();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     float var7 = var4.getContractionCriteria();
//     double var9 = var4.addElementRolling(5.775578026902914E10d);
//     var4.addElement(0.0d);
//     var4.addElement(6.474290387216851d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.16681720112709292d);
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test266"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-2.0166116874290902d), (java.lang.Number)0.0033341336138363866d, (java.lang.Number)0.0013688605785435513d);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test267"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(4.472431190187361d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.203349670113058d);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test268"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)180, (java.lang.Number)(-0.9942647162019622d), (java.lang.Number)7.855365740969936d);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test269"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(2041, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test270"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    java.lang.Class var6 = var4.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    java.lang.String var8 = var4.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    java.lang.String var10 = var2.name();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var11);
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "MAXIMAL"+ "'", var10.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test271"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("2e419696fa");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test272"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(4.149647634883433d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.881784197001252E-16d);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test273"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(1342177280L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test274"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     var0.reSeed(14L);
//     double var14 = var0.nextExponential(0.9999997887160175d);
//     double var17 = var0.nextBeta(4.0434293412271454E-4d, 0.17971249487899976d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var19 = var0.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.491147372483642d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d48e83dac5"+ "'", var8.equals("d48e83dac5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.7433740923973843d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.3844973909690124d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
// 
//   }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test275"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(3.6686154783610574d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test276"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var13 = var0.nextT(5.867156662812015d);
//     double var15 = var0.nextExponential(11.771947930619202d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var18 = var0.nextSecureLong(2702L, 2120L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 24.77674784049039d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "8ff81c78fb"+ "'", var8.equals("8ff81c78fb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.4009563063733366d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 3.1643049709043836d);
// 
//   }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test277"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-5.6377557251187005d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test278"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1135069411L, 760L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 862652752360L);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test279"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1818);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1818);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test280"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.addElement(0.0d);
    var6.contract();
    var6.discardFrontElements(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test281"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-2.225482993439564d), 0.9999494957997512d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.2254829934395635d));

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test282"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 10.0f);
    var2.addElement(0.010050166663333094d);
    int var5 = var2.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var2.copy();
    var6.setElement(11122, 2.095003270872298d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test283"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-0.5941416427828103d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test284"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.28279383239600014d, 1.7044581484917243d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.7044581484917243d);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test285"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var3);
    java.lang.String var6 = var3.name();
    java.lang.String var7 = var3.toString();
    java.lang.Class var8 = var3.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var10 = java.lang.Enum.<java.lang.Enum>valueOf(var8, "4a66e7d6b1");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "AVERAGE"+ "'", var7.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test286"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(33392016, 2187);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test287"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(15L, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10L);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test288"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var4.addElement((-0.43408597923864894d));
//     double var10 = var4.getElement(0);
//     double[] var11 = var4.getElements();
//     var4.addElement(21.0d);
//     var4.setNumElements(3);
//     org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var17 = var16.getStandardDeviation();
//     double[] var19 = var16.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
//     var20.contract();
//     int var22 = var20.getNumElements();
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var20);
//     org.apache.commons.math3.util.ResizableDoubleArray var24 = var4.copy();
//     double var26 = var24.substituteMostRecentElement(3.674181234459348d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.823778062325079d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 21.0d);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test289"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0L, 443L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 443L);

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test290"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     var0.reSeed();
//     java.lang.String var15 = var0.nextSecureHexString(11395);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.8816197068820977d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5ccf49d89f"+ "'", var8.equals("5ccf49d89f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3L);
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test291"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.02723138689445857d, (java.lang.Number)1.5958068268285657d, false);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test292"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(0L);
//     long var17 = var0.nextPoisson(7.769493748166378d);
//     double var19 = var0.nextExponential(8.563154148722202d);
//     java.util.Collection var20 = null;
//     java.lang.Object[] var22 = var0.nextSample(var20, 17018);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test293"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(0.8649775937719963d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.09401821487395612d);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test294"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0000004718517073d, (java.lang.Number)0.3561924887652932d, false);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test295"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(1.284735195159358d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.06923396782734023d);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test296"); }


    org.apache.commons.math3.exception.MathIllegalStateException var0 = new org.apache.commons.math3.exception.MathIllegalStateException();
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var0);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test297"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-16L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 16L);

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test298"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var4.addElement((-0.43408597923864894d));
//     double var10 = var4.getElement(0);
//     double[] var11 = var4.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
//     boolean var14 = var12.equals((java.lang.Object)2.946007020743843d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.9283927923794728d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test299"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, 4.2E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test300"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 50761728L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 50761728L);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test301"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1L), 10743);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1L));

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test302"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.994492389768776d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5863119679626533d));

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test303"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.8273175524905445d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.287175276564211d);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test304"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.11537426317526311d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 28.48828414067364d);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test305"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(2702L, 2184L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2184L);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test306"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-0.03441375268533516d), 1192465837);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test307"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1980, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1980);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test308"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double var3 = var0.inverseCumulativeProbability(0.9999999999928669d);
    double var5 = var0.density(25.472636453138065d);
    double var6 = var0.getNumericalMean();
    var0.reseedRandomGenerator(1073741824L);
    double var9 = var0.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 6.755176609774487d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5.055823438644928E-142d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test309"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0f, 2.5000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5000002f);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test310"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0, 9694);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test311"); }


    double[] var3 = new double[] { 0.0d, (-1.0d), 0.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var6 = var5.getStandardDeviation();
    double[] var8 = var5.sample(1);
    double var9 = var5.getMean();
    double[] var11 = var5.sample(100);
    var4.addElements(var11);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var4.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.setContractionCriteria(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test312"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextInt(9911, 9142);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 18.522086030285006d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "fa1fb3ba176bafa1661f3195f7759b088f19c8c41f09a0ecc8836c2397abd2f51bda1c3206a822933543b558b56bf97a6c24"+ "'", var8.equals("fa1fb3ba176bafa1661f3195f7759b088f19c8c41f09a0ecc8836c2397abd2f51bda1c3206a822933543b558b56bf97a6c24"));
// 
//   }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test313"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.022352405844223155d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0226040926379294d);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test314"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(14.455221443139214d, 0.1472442938099579d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1472442938099579d);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test315"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(1931, 1919);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 70.76805765837116d);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test316"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)21L, (java.lang.Number)5.641560223443412d, true);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test317"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.009999999583352414d, 3.2359311173302077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.009999999583352414d);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test318"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(445346L, 33392016);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test319"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(325, 89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 89);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test320"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.8988590862390544d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test321"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)2.946007020743843d, (java.lang.Number)3.8508277351650975d, var3);

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test322"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.4649262233149871d), 0.0d, 0.5322866968936354d, 9448);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test323"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     double var12 = var0.nextGamma(4.950886585270677E-4d, 1.5703107297735257d);
//     int var15 = var0.nextInt(2, 17018);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var18 = var0.nextPermutation(1073741825, 9142);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12.926602583055256d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 4832);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test324"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(27, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test325"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getSupportUpperBound();
//     double[] var3 = var0.sample(10);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     double var6 = var4.addElementRolling(0.15264401491200186d);
//     float var7 = var4.getContractionCriteria();
//     float var8 = var4.getExpansionFactor();
//     org.apache.commons.math3.util.ResizableDoubleArray var9 = var4.copy();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.setExpansionMode((-20));
//       fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
//     } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.18858521699493416d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test326"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(56L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 56L);

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test327"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(0L);
//     org.apache.commons.math3.distribution.IntegerDistribution var16 = null;
//     int var17 = var0.nextInversionDeviate(var16);
// 
//   }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test328"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.010050505059049992d, (java.lang.Number)(-0.3722334692039834d), true);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.010050505059049992d+ "'", var5.equals(0.010050505059049992d));

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test329"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.setContractionCriteria(2.5f);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    var15.setExpansionMode(0);
    var15.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test330"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(9.536745E-7f, 173);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test331"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(10620, 100.0f, 2.3841864E-7f, 1972);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test332"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.9722014210914647d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4661121757259201d);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test333"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(268435456L, 2388144625711178067L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 268435456L);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test334"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)183L);
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (183) exceeded"+ "'", var2.equals("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (183) exceeded"));

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test335"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(8.105055920445338d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.10505592044534d);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test336"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var4 = var1.toString();
    java.lang.Class var5 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = var8.getTiesStrategy();
    java.lang.Class var10 = var9.getDeclaringClass();
    java.lang.Class var11 = var9.getDeclaringClass();
    boolean var13 = var9.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.distribution.NormalDistribution var18 = new org.apache.commons.math3.distribution.NormalDistribution((-4.440892098500626E-16d), 1.1102230246251565E-16d, 0.9999494957997512d);
    double[] var20 = var18.sample(1972);
    double[] var21 = var14.rank(var20);
    double[] var22 = var6.rank(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test337"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1999, 1.9999998f, 2097152.0f, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test338"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1017.1979140470148d, (java.lang.Number)(-0.8961189234469322d), false);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test339"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.14608902069952245d, 3.0182922747288487E238d, 1.6228705708311209d, (-8889));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test340"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var3);
    java.lang.String var6 = var3.name();
    java.lang.Class var7 = var3.getDeclaringClass();
    java.lang.Class var8 = var3.getDeclaringClass();
    java.lang.String var9 = var3.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "AVERAGE"+ "'", var9.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test341"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(2.287175276564211d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1586204758992398d);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test342"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(11304, 317);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 11304);

  }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test343"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var2);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var7 = var4.nextSecureLong((-1L), 1L);
//     double var10 = var4.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var12 = var4.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var13 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var14 = var4.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var13);
//     double var15 = var13.sample();
//     double var17 = var13.probability(7.444490968701611d);
//     double var18 = var13.getSupportUpperBound();
//     double[] var20 = var13.sample(9694);
//     org.apache.commons.math3.distribution.NormalDistribution var21 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var22 = var21.getStandardDeviation();
//     boolean var23 = var21.isSupportUpperBoundInclusive();
//     double[] var25 = var21.sample(100);
//     double var26 = var3.mannWhitneyU(var20, var25);
// 
//   }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test344"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var3 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var4 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.5662191695169728d, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test345"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 336L);
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, var14);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 11L);
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    java.math.BigInteger var21 = null;
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 0L);
    java.math.BigInteger var24 = null;
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 0L);
    java.math.BigInteger var27 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, var26);
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, 6L);
    org.apache.commons.math3.exception.OutOfRangeException var30 = new org.apache.commons.math3.exception.OutOfRangeException(var18, (java.lang.Number)5.363952139253263d, (java.lang.Number)14.087081017797523d, (java.lang.Number)var29);
    java.math.BigInteger var31 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, var29);
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, var31);
    java.math.BigInteger var34 = org.apache.commons.math3.util.ArithmeticUtils.pow(var32, 59867617);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test346"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(2.8E-45f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test347"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 243);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 4L);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 40486L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, (-79579695));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test348"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var13 = var0.nextChiSquare(3.5256464698322323d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextPascal(10743, (-0.2589154866568829d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12.873053774087898d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "6e245ad9bc"+ "'", var8.equals("6e245ad9bc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.698610295055114d);
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test349"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(1909, 10743);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-8834));

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test350"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var8 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var4, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var2, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathArithmeticException var13 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.util.ExceptionContext var14 = var13.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test351"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    var4.addElement(0.0d);
    var4.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test352"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var21 = var18.nextSecureLong((-1L), 1L);
//     double var24 = var18.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var26 = var18.nextSecureHexString(100);
//     double var28 = var18.nextT(20.696514663540924d);
//     org.apache.commons.math3.distribution.NormalDistribution var29 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var30 = var29.getStandardDeviation();
//     double[] var32 = var29.sample(1);
//     double var33 = var29.getMean();
//     double[] var35 = var29.sample(100);
//     double var36 = var29.sample();
//     double var37 = var29.sample();
//     double var38 = var18.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     double var39 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     double var42 = var0.nextGaussian(0.9999999627393439d, 0.022352405844223155d);
//     int var45 = var0.nextPascal(180, 0.7092829319155378d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.825732559438027d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "b4470152416ccd4720501accd558c48cddca9126dc80b79d4cb836019ea7913869c06ab66ac7bbf3ec4b4a84bc965021fbc0"+ "'", var8.equals("b4470152416ccd4720501accd558c48cddca9126dc80b79d4cb836019ea7913869c06ab66ac7bbf3ec4b4a84bc965021fbc0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0729020883812267d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 9.49284417354614d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "72ce422bfaf781f9fe5fd3afba8754458c479767235e168f42e75bd04c9855e4df51cbf7be324c7726014b38bf51cb1cf99e"+ "'", var26.equals("72ce422bfaf781f9fe5fd3afba8754458c479767235e168f42e75bd04c9855e4df51cbf7be324c7726014b38bf51cb1cf99e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.19642204925412635d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == (-0.7369430907238468d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == (-0.15675179149047103d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0.16966356194419677d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1.5684585119588663d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1.0154219876746742d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 89);
// 
//   }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test353"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(2.384186E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test354"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1073741824L), 8941);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test355"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(1.0471975511965979d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2493670505239753d);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test356"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double[] var6 = var0.sample(100);
//     double var7 = var0.sample();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.inverseCumulativeProbability((-1.420806035574538d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1.1948311124794795d));
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test357"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    java.lang.Number var6 = var4.getMax();
    java.lang.Number var7 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1.0f)+ "'", var6.equals((-1.0f)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0f)+ "'", var7.equals((-1.0f)));

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test358"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2.5000002f, 8012);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test359"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-0.7938205914625687d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6709616359926565d));

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test360"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var5 = var0.nextExponential(4.896058728199816d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextUniform(0.6369655282464425d, (-0.909770833766286d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.3510545521060373d);
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test361"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.5718637074096835d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5813337955550733d);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test362"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(1.7059487146473076d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.506607388944759d);

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test363"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     var0.reSeedSecure();
//     int var10 = var0.nextBinomial(243, 0.745691842295965d);
//     long var12 = var0.nextPoisson(31.862892444737472d);
//     java.lang.String var14 = var0.nextHexString(10240);
//     double var16 = var0.nextChiSquare(0.8837139528133744d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextZipf(9181, (-0.8773584223947262d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 24.41204568025254d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 177);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 31L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.2703396718837618d);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test364"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 10.0f);
    var4.addElement(0.15729920705028488d);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var10 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var9, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var8, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var10);
    boolean var14 = var4.equals((java.lang.Object)var10);
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test365"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(445346L, 201600L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 243746L);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test366"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-519016991), 1859);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-519018850));

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test367"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.15861286098539223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1718841767649388d);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test368"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)8.937138162549141d);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test369"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setExpansionFactor(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test370"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(14273034);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test371"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var1 = null;
//     java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
//     java.math.BigInteger var4 = null;
//     java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0L);
//     java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, var6);
//     java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 11L);
//     java.math.BigInteger var10 = null;
//     java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
//     java.math.BigInteger var13 = null;
//     java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 0L);
//     java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, var15);
//     java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 1949);
//     java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, var18);
//     java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 8904);
//     org.apache.commons.math3.exception.NumberIsTooSmallException var24 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)var21, (java.lang.Number)(-2L), true);
//     java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, var21);
// 
//   }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test372"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     double var11 = var0.nextUniform(1.9243072677253843d, 7.362895734466076d);
//     int[] var14 = var0.nextPermutation(9181, 1946);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextSecureInt(100, 37);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.687298121669981d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "db6a6ffeee2b58ee5b47bb38ac3439c11a11fdef4f5b8d6e87bae67830d7d265dd61ceea48f3c002a8de0c79e460ec30b47d"+ "'", var8.equals("db6a6ffeee2b58ee5b47bb38ac3439c11a11fdef4f5b8d6e87bae67830d7d265dd61ceea48f3c002a8de0c79e460ec30b47d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.1420241914879696d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test373"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(9.453724938289845d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.9423416211760194d);

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test374"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(8.854558633913316d, 3.1173466159040992d);
//     double var3 = var2.sample();
//     double var5 = var2.density(6.785547566387043d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7.22145333925833d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.10267613537961508d);
// 
//   }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test375"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    boolean var7 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator((-16L));
    double var11 = var0.cumulativeProbability(0.0d);
    boolean var12 = var0.isSupportLowerBoundInclusive();
    double var14 = var0.probability(7.724435900937391d);
    double var15 = var0.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-0.1397549781611366d));

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test376"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.4833612318779604d, 0.6694685033963527d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.48336123187796043d);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test377"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(2297);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 15485.096742990623d);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test378"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(2184L, (-21428512432588800L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 21428512432590984L);

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test379"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin((-2.580151816032994d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test380"); }


    double[] var3 = new double[] { 0.0d, (-1.0d), 0.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    float var6 = var4.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    var4.clear();
    var4.setNumElements(9911);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test381"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(3.292378755306352d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0d);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test382"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(9424, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test383"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeedSecure(0L);
//     long var15 = var0.nextSecureLong(1L, 31L);
//     double var17 = var0.nextChiSquare(13.40367387687556d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.5499237247333157d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "2fcff42dfa"+ "'", var8.equals("2fcff42dfa"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 26L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 11.734114385974351d);
// 
//   }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test384"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    boolean var10 = var8.equals((java.lang.Object)16.35282631844513d);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test385"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(21.30577737489313d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.952648858845086E8d);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test386"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(27, 173);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test387"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
//     var1.addElement(2.0216852347077916d);
//     org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var5 = var4.getStandardDeviation();
//     double[] var7 = var4.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var12 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var11, (java.lang.Object[])var12);
//     org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var10, (java.lang.Object[])var12);
//     org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var9, (java.lang.Object[])var12);
//     boolean var16 = var8.equals((java.lang.Object)var9);
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var8);
//     int var18 = var1.start();
//     org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var20 = var19.getStandardDeviation();
//     double[] var22 = var19.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
//     org.apache.commons.math3.exception.util.Localizable var24 = null;
//     org.apache.commons.math3.exception.util.Localizable var25 = null;
//     org.apache.commons.math3.exception.util.Localizable var26 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var27 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.NullArgumentException var28 = new org.apache.commons.math3.exception.NullArgumentException(var26, (java.lang.Object[])var27);
//     org.apache.commons.math3.exception.MathInternalError var29 = new org.apache.commons.math3.exception.MathInternalError(var25, (java.lang.Object[])var27);
//     org.apache.commons.math3.exception.NullArgumentException var30 = new org.apache.commons.math3.exception.NullArgumentException(var24, (java.lang.Object[])var27);
//     boolean var31 = var23.equals((java.lang.Object)var24);
//     var23.setElement(8899, 2.3930658372149933d);
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var23);
//     org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var36);
//     org.apache.commons.math3.distribution.NormalDistribution var38 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var39 = var38.getStandardDeviation();
//     double[] var41 = var38.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var42 = new org.apache.commons.math3.util.ResizableDoubleArray(var41);
//     int var43 = var42.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var44 = var42.copy();
//     var42.addElement((-0.43408597923864894d));
//     double var48 = var42.getElement(0);
//     double[] var49 = var42.getElements();
//     var42.addElement(21.0d);
//     var42.setNumElements(3);
//     org.apache.commons.math3.distribution.NormalDistribution var54 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var55 = var54.getStandardDeviation();
//     double[] var57 = var54.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var58 = new org.apache.commons.math3.util.ResizableDoubleArray(var57);
//     var58.contract();
//     int var60 = var58.getNumElements();
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var42, var58);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var62 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var66 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var67 = new org.apache.commons.math3.util.ResizableDoubleArray(var66);
//     org.apache.commons.math3.distribution.NormalDistribution var68 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var69 = var68.getSupportUpperBound();
//     double[] var71 = var68.sample(10);
//     double var72 = var62.mannWhitneyU(var66, var71);
//     var42.addElements(var66);
//     var1.addElements(var66);
//     float var75 = var1.getExpansionFactor();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == (-2.368715742159256d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 30.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 2.0f);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test388"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test389"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextCauchy(0.009771245257459062d, (-0.6801548754218844d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test390"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.18568215771673818d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2040395048875416d);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test391"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.204409469363068d, 4.979830522251364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0111901158394188d));

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test392"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     var0.reSeed();
//     double var15 = var0.nextChiSquare(0.27820249749496384d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var17 = var0.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 24.9057406791349d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "41ab6748ca"+ "'", var8.equals("41ab6748ca"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.4878656737685238d);
// 
//   }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test393"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 2297);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test394"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1877, 1866);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1877);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test395"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var4 = var3.getStandardDeviation();
    double[] var6 = var3.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    double[] var8 = var7.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var16 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var12, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var17 = var16.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var18 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var11, (java.lang.Object[])var17);
    org.apache.commons.math3.exception.MathArithmeticException var19 = new org.apache.commons.math3.exception.MathArithmeticException(var10, (java.lang.Object[])var17);
    boolean var20 = var9.equals((java.lang.Object)var17);
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var17);
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var17);
    org.apache.commons.math3.exception.MathInternalError var23 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test396"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.99999994f, 1.9999998f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9999998f);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test397"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-8899), 17018);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test398"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var3 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var4 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test399"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.5463889614498906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test400"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(1.4518934003863375d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4518934003863375d);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test401"); }


    long var1 = org.apache.commons.math3.util.FastMath.round((-0.02810696865979545d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test402"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(24.179442105020325d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 25.0d);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test403"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeedSecure(0L);
//     int var15 = var0.nextInt(1868, 408490575);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.189735045432425d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "8dfe6efb5b"+ "'", var8.equals("8dfe6efb5b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 21180789);
// 
//   }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test404"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     int var20 = var0.nextBinomial(0, 0.7615941559557649d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var0.nextZipf(1919, (-5.315982015318238E-16d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 25.300028820238424d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ba5bdea5fc03894b9203a809ce49103665443bb3a6f2f304786e5ad1d4c09db31455bf8f48707ce43da68492cf8fcb02982b"+ "'", var8.equals("ba5bdea5fc03894b9203a809ce49103665443bb3a6f2f304786e5ad1d4c09db31455bf8f48707ce43da68492cf8fcb02982b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.10952000054574437d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test405"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.6571109359893886d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6571109359893885d));

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test406"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(0, 1604);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test407"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     var0.reSeed(6L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextF(7.22145333925833d, (-0.8935205864267294d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.371820252036275d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "da2979e8c9"+ "'", var8.equals("da2979e8c9"));
// 
//   }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test408"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1.0395566705196257d);
    java.lang.Number var2 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 1.0395566705196257d+ "'", var2.equals(1.0395566705196257d));

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test409"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-0.7178632239611089d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6899951741902008d));

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test410"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.5813337955550733d, 0.06212744927024042d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5813337955550731d);

  }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test411"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(4.5d, 0.017688387388495763d);
//     double var3 = var2.getSupportUpperBound();
//     double var4 = var2.sample();
//     double var6 = var2.density((-86.58313008438003d));
//     double var8 = var2.density(0.32120122832835923d);
//     double var9 = var2.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4.503615153242829d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.12879048405496E-4d);
// 
//   }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test412"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var4 = var0.getMean();
    double[] var6 = var0.sample(100);
    boolean var7 = var0.isSupportLowerBoundInclusive();
    boolean var8 = var0.isSupportUpperBoundInclusive();
    double var11 = var0.cumulativeProbability(0.0d, 0.25587682077976953d);
    double var12 = var0.getSupportUpperBound();
    boolean var13 = var0.isSupportConnected();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var0.inverseCumulativeProbability((-0.42777032318295566d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.10097702336242761d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test413"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(18944L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test414() {}
//   public void test414() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test414"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var21 = var18.nextSecureLong((-1L), 1L);
//     double var24 = var18.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var26 = var18.nextSecureHexString(100);
//     double var28 = var18.nextT(20.696514663540924d);
//     org.apache.commons.math3.distribution.NormalDistribution var29 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var30 = var29.getStandardDeviation();
//     double[] var32 = var29.sample(1);
//     double var33 = var29.getMean();
//     double[] var35 = var29.sample(100);
//     double var36 = var29.sample();
//     double var37 = var29.sample();
//     double var38 = var18.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     double var39 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     double var42 = var0.nextGaussian(0.9999999627393439d, 0.022352405844223155d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var45 = var0.nextPermutation(323, (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15.173393222788675d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "6582eab4ada027b70013e61f1000e31433ac217151fdbcd0bf57c0302e8151ec47adeac467b29aa8ff40edb2920bdf95fadb"+ "'", var8.equals("6582eab4ada027b70013e61f1000e31433ac217151fdbcd0bf57c0302e8151ec47adeac467b29aa8ff40edb2920bdf95fadb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.047313186699336506d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 10.766328773552809d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "ed3054d9cb01fc9bd796dcdf803e1ab098943f8718086b93ea8971f16ef2d00ca3ad39112e7929ff1399fac7723759a483ab"+ "'", var26.equals("ed3054d9cb01fc9bd796dcdf803e1ab098943f8718086b93ea8971f16ef2d00ca3ad39112e7929ff1399fac7723759a483ab"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-0.23266158681805782d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == (-1.27907210940204d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1.3467171058941587d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == (-0.022576881746387202d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-1.0177594622777966d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1.0510771141453605d);
// 
//   }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test415"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.9893787012812597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7800592111940521d);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test416"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.2601475756166266E-229d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.5498557373738816E-115d);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test417"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(6.815929280093534d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test418"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     double var11 = var0.nextUniform(1.9243072677253843d, 7.362895734466076d);
//     int[] var14 = var0.nextPermutation(9181, 1946);
//     var0.reSeed((-1342158336L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextBinomial(1818, 1.1526881743814081d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0911129476146217d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "c0d47fc11ec0205dcf3d64cb90076ac93ffcf531f67497d78e9ac24f67ae4c035788592f37547b3363240a626f16cd8aaaa3"+ "'", var8.equals("c0d47fc11ec0205dcf3d64cb90076ac93ffcf531f67497d78e9ac24f67ae4c035788592f37547b3363240a626f16cd8aaaa3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 7.114237403322046d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
// 
//   }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test419"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    var4.addElement(0.0d);
    int var8 = var4.getExpansionMode();
    double[] var9 = var4.getInternalValues();
    var4.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test420"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(18.860854671741663d, 0.3631750422823351d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test421"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.clear();
    float var8 = var6.getExpansionFactor();
    var6.setContractionCriteria(2.0f);
    float var11 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.discardFrontElements(1972);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test422"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(1.6096293162678812d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.000957110763316d);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test423"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.24432822642129903d);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test424"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, 0.05265476731144191d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.9E-324d);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test425"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(39916800L, 40486L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test426"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1073741824L), (java.lang.Number)2.263521840245945d, false);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test427"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(3.2462374214935577d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 24.693484066683105d);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test428"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(2.1424092671303407d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0d);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test429"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.02674354022982449d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test430"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(443L, 2021567837087569569L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test431"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(4.652627453922398d, 1.0734110273220523d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.00868178747678739d);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test432"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    var4.setElement(1931, 0.2577047455984825d);
    float var11 = var4.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test433"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1L));

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test434"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.912933013825568d);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    boolean var4 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test435"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(15485.096742990623d, 0.6381355471725575d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.046561114627056484d));

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test436"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-8L), (-536829416L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-536829416L));

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test437"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    boolean var2 = var0.isSupportUpperBoundInclusive();
    double[] var4 = var0.sample(100);
    double var5 = var0.getNumericalVariance();
    boolean var6 = var0.isSupportUpperBoundInclusive();
    double var7 = var0.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.NEGATIVE_INFINITY);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test438"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(13.134402201288975d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8429615622188541d);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test439"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.1752011936438014d, 25.697333709313465d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1752011936438014d);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test440"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    var4.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var4.copy();
    int var10 = var4.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    float var12 = var4.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.0f);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test441"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-792111645L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 792111645L);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test442"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-8889), 1831);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test443"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-127), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test444"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.clear();
    float var8 = var6.getExpansionFactor();
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, var14);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 11L);
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    java.math.BigInteger var21 = null;
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 0L);
    java.math.BigInteger var24 = null;
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 0L);
    java.math.BigInteger var27 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, var26);
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, 6L);
    org.apache.commons.math3.exception.OutOfRangeException var30 = new org.apache.commons.math3.exception.OutOfRangeException(var18, (java.lang.Number)5.363952139253263d, (java.lang.Number)14.087081017797523d, (java.lang.Number)var29);
    java.math.BigInteger var31 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, var29);
    boolean var32 = var6.equals((java.lang.Object)var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var34 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, (-792111645L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test445"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-0.4161468365471424d));

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test446"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     double var12 = var0.nextGamma(4.950886585270677E-4d, 1.5703107297735257d);
//     double var15 = var0.nextCauchy((-0.5829554842180134d), 0.598569254083824d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 26.387027073327598d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.12636896871601633d);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test447"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.34866872078240907d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3639274309545897d);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test448"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.9998435319194582d, 8.6873282248717d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8.744676024586255d);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test449"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.0d, 0.2555837818987815d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test450"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1877, (-8904));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1877);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test451"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(20.665469503447394d, (-0.1901543518195821d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test452"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var13 = var10.nextSecureLong((-1L), 1L);
//     double var16 = var10.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var18 = var10.nextHexString(10);
//     int var21 = var10.nextPascal(8899, 0.8219866295031046d);
//     double var23 = var10.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var25 = var24.getStandardDeviation();
//     double[] var27 = var24.sample(1);
//     double var28 = var24.getMean();
//     double[] var30 = var24.sample(100);
//     double var31 = var24.sample();
//     double var32 = var24.sample();
//     double var33 = var24.getStandardDeviation();
//     double var34 = var24.sample();
//     double var35 = var10.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     double var36 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     org.apache.commons.math3.distribution.NormalDistribution var37 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var38 = var37.getStandardDeviation();
//     boolean var39 = var37.isSupportUpperBoundInclusive();
//     double[] var41 = var37.sample(100);
//     double var42 = var37.getNumericalVariance();
//     double var43 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var37);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var46 = var0.nextUniform(12993.88895389968d, 14.57970528643039d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.610185833459287d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "caaf6c70e0b4f82164a1e391678384c005bf2ec08486ce71157c1c6b30a770e2ea7eb6f2e3983a7771661a9535152222d99c"+ "'", var8.equals("caaf6c70e0b4f82164a1e391678384c005bf2ec08486ce71157c1c6b30a770e2ea7eb6f2e3983a7771661a9535152222d99c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 13.02136750265371d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "e46d2d5946"+ "'", var18.equals("e46d2d5946"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1906);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 7.071139343997754E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0.47115704152727467d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1.6089973758108689d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == (-0.7809559906474173d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0.23700704668856512d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0.04365174769512865d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 0.3502104927333575d);
// 
//   }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test453"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(8904, 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 69.04243114266052d);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test454"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(2.5517620356803068E-188d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5517620356803068E-188d);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test455"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.9999998f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9999998f);

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test456"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.4329667140671784d), (-1.1622852906955334d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test457"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.61794919482265d, (java.lang.Number)1831, false);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test458"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeedSecure();

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test459"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-9.83148073014245d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test460"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    var0.reseedRandomGenerator(2L);
    double[] var4 = var0.sample(100000);
    double var5 = var0.getMean();
    var0.reseedRandomGenerator(1600L);
    double var9 = var0.probability(0.0d);
    double var10 = var0.sample();
    double var11 = var0.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.848065723407808d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test461"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)260.89975491973144d, (java.lang.Number)(-1.84544373783414d), true);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test462"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(9192904, 1498);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9194402);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test463"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(89, 1.1368686E-13f, 1.1368686E-13f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test464"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var4 = java.lang.Enum.<java.lang.Enum>valueOf(var2, "b4780bd59a");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test465"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-1151L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test466"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    boolean var4 = var0.isSupportConnected();
    double var5 = var0.getMean();
    boolean var6 = var0.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test467"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.12160808276430722d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test468"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 10.0f);
    float var3 = var2.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 10.0f);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test469"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var13.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    java.lang.Class var18 = var17.getDeclaringClass();
    int var19 = var17.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var20.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var23 = var22.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = var22.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var25 = var22.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var26 = var22.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var28 = var27.getTiesStrategy();
    boolean var30 = var28.equals((java.lang.Object)Double.POSITIVE_INFINITY);
    boolean var32 = var28.equals((java.lang.Object)(-0.4255538433808183d));
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var33 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var26, var28);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var34 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var21, var28);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var35 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var28);
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var37 = var36.getTiesStrategy();
    java.lang.Class var38 = var37.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var37);
    org.apache.commons.math3.stat.ranking.TiesStrategy var40 = var39.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var41 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var40);
    java.lang.String var42 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + "MAXIMAL"+ "'", var42.equals("MAXIMAL"));

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test470"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(8904, 1.9999999f, 9.536744E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test471"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1073741825);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1073741825);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test472"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    int var7 = var6.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var6.getElement(57);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test473"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double var3 = var0.inverseCumulativeProbability(0.9999999999928669d);
    double var4 = var0.getMean();
    double var5 = var0.getNumericalVariance();
    double var6 = var0.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 6.755176609774487d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test474"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.clear();
    float var8 = var6.getExpansionFactor();
    double[] var9 = var6.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test475"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var4 = var0.getMean();
    double[] var6 = var0.sample(100);
    boolean var7 = var0.isSupportLowerBoundInclusive();
    boolean var8 = var0.isSupportUpperBoundInclusive();
    double var11 = var0.cumulativeProbability(0.0d, 0.25587682077976953d);
    double var12 = var0.getSupportUpperBound();
    boolean var13 = var0.isSupportConnected();
    boolean var14 = var0.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.10097702336242761d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test476"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = var8.getTiesStrategy();
    java.lang.Class var10 = var9.getDeclaringClass();
    java.lang.String var11 = var9.toString();
    java.lang.String var12 = var9.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7, var9);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "AVERAGE"+ "'", var11.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "AVERAGE"+ "'", var12.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test477"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)8899);
//     org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
//     boolean var4 = var2.getBoundIsAllowed();
//     java.lang.String var5 = var2.toString();
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test478"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    boolean var7 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator((-16L));
    double var11 = var0.cumulativeProbability(0.0d);
    boolean var12 = var0.isSupportLowerBoundInclusive();
    double var13 = var0.getNumericalVariance();
    double[] var15 = var0.sample(1916);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test479"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test480"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(3.0382740325466986d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.48262694182950977d);

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test481"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     java.lang.String var13 = var0.nextHexString(10);
//     var0.reSeedSecure();
//     double var17 = var0.nextBeta(20441.91590500824d, 11.711799887012498d);
//     double var20 = var0.nextWeibull(21.78619629460335d, 1.5120484726447734d);
//     double var23 = var0.nextGamma(1.527066384736393d, 0.04378400432753371d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var26 = var0.nextInt(4, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.347979014158097d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "67a7a1af52"+ "'", var8.equals("67a7a1af52"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "b9fd6403e2"+ "'", var13.equals("b9fd6403e2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.9994278166121716d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.4019952064963996d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.04378475878806262d);
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test482"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(0, 337860);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 337860);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test483"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(100.000015f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test484"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
    java.lang.Class var14 = var13.getDeclaringClass();
    java.lang.String var15 = var13.toString();
    java.lang.String var16 = var13.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var13);
    boolean var19 = var13.equals((java.lang.Object)"9d29b4957b");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "AVERAGE"+ "'", var16.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test485"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(1972);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test486"); }
// 
// 
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.distribution.NormalDistribution var1 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var2 = var1.getStandardDeviation();
//     boolean var3 = var1.isSupportUpperBoundInclusive();
//     double[] var5 = var1.sample(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var6.reseedRandomGenerator(2L);
//     double[] var10 = var6.sample(100000);
//     double var11 = var0.mannWhitneyUTest(var5, var10);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var13 = var12.getStandardDeviation();
//     double[] var15 = var12.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
//     double[] var20 = new double[] { 0.0d, (-1.0d), 0.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
//     double var22 = var0.mannWhitneyU(var15, var20);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var24 = var23.getTiesStrategy();
//     java.lang.Class var25 = var24.getDeclaringClass();
//     java.lang.Class var26 = var24.getDeclaringClass();
//     boolean var28 = var24.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
//     org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var30 = var29.getNanStrategy();
//     double[] var34 = new double[] { (-1.0d), 10.0d, 1.0d};
//     double[] var35 = var29.rank(var34);
//     org.apache.commons.math3.util.ResizableDoubleArray var37 = new org.apache.commons.math3.util.ResizableDoubleArray(189);
//     org.apache.commons.math3.random.RandomDataImpl var38 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var41 = var38.nextSecureLong((-1L), 1L);
//     double var44 = var38.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var46 = var38.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var47 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var48 = var38.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var47);
//     double var49 = var47.sample();
//     double var51 = var47.probability(7.444490968701611d);
//     double var52 = var47.getSupportUpperBound();
//     double[] var54 = var47.sample(9694);
//     var37.addElements(var54);
//     double var56 = var0.mannWhitneyUTest(var34, var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.5378868904281788d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 3.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 7.417442685503174d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var46 + "' != '" + "734eff8525"+ "'", var46.equals("734eff8525"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 0.2583458855013327d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 0.07363780285013331d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 0.31871003612337145d);
// 
//   }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test487"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-3.2615364653538212d), false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test488"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(4311469);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test489"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-2.368715742159256d));

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test490"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.384186E-7f, 13.359855606410402d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.3841864E-7f);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test491"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(336L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 336L);

  }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test492"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var4.addElement((-0.43408597923864894d));
//     double var10 = var4.getElement(0);
//     var4.clear();
//     var4.setElement(0, 0.0d);
//     var4.addElement(1.7235492783602437d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.6153238755363085d);
// 
//   }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test493"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var13 = var10.nextSecureLong((-1L), 1L);
//     double var16 = var10.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var18 = var10.nextHexString(10);
//     int var21 = var10.nextPascal(8899, 0.8219866295031046d);
//     double var23 = var10.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var25 = var24.getStandardDeviation();
//     double[] var27 = var24.sample(1);
//     double var28 = var24.getMean();
//     double[] var30 = var24.sample(100);
//     double var31 = var24.sample();
//     double var32 = var24.sample();
//     double var33 = var24.getStandardDeviation();
//     double var34 = var24.sample();
//     double var35 = var10.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     double var36 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     org.apache.commons.math3.distribution.NormalDistribution var37 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var38 = var37.getStandardDeviation();
//     boolean var39 = var37.isSupportUpperBoundInclusive();
//     double[] var41 = var37.sample(100);
//     double var42 = var37.getNumericalVariance();
//     double var43 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var37);
//     int var46 = var0.nextBinomial(11395, 0.11486505021225096d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.179552922780476d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "6d8427fe8c3ce3291df4886a241d9177b362716188fa91d06da3cbe9c9462be0d113489ddd4a7b70561fe22a5e83a0f61e7e"+ "'", var8.equals("6d8427fe8c3ce3291df4886a241d9177b362716188fa91d06da3cbe9c9462be0d113489ddd4a7b70561fe22a5e83a0f61e7e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 9.291700909115704d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "b24021730c"+ "'", var18.equals("b24021730c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1990);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.0217091653372376d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0.39237518983379205d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == (-0.7856416010077104d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == (-1.511088425813963d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == (-0.7993162117562352d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0.8957380763521041d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 0.7886022485969987d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 1319);
// 
//   }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test494"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.023932653637902992d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.023928085890320375d);

  }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test495"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var21 = var18.nextSecureLong((-1L), 1L);
//     double var24 = var18.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var26 = var18.nextSecureHexString(100);
//     double var28 = var18.nextT(20.696514663540924d);
//     org.apache.commons.math3.distribution.NormalDistribution var29 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var30 = var29.getStandardDeviation();
//     double[] var32 = var29.sample(1);
//     double var33 = var29.getMean();
//     double[] var35 = var29.sample(100);
//     double var36 = var29.sample();
//     double var37 = var29.sample();
//     double var38 = var18.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     double var39 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     double var42 = var0.nextGaussian(0.9999999627393439d, 0.022352405844223155d);
//     double var45 = var0.nextWeibull(0.8273175524905445d, 0.003960709268216542d);
//     java.lang.String var47 = var0.nextHexString(9424);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.49413191900484393d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "51b41ec7b5faf968135c058bf3ed639b32aab0d9e43edb29ee4384fbc626810425cf109dc926a8a02a67ca757e2325095613"+ "'", var8.equals("51b41ec7b5faf968135c058bf3ed639b32aab0d9e43edb29ee4384fbc626810425cf109dc926a8a02a67ca757e2325095613"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0930721414133345d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.5516364223309218d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "9ce223e2a45629d8699bdfcb3e991b1ab433ed6b32f73c79b7583c0a8b288c52fb2b8ba831c07ce6e6ca1bd594ff0248bb63"+ "'", var26.equals("9ce223e2a45629d8699bdfcb3e991b1ab433ed6b32f73c79b7583c0a8b288c52fb2b8ba831c07ce6e6ca1bd594ff0248bb63"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-1.3270697734558135d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1.7093838862932664d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0.5922600267763498d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0.7295760230965135d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0.868085526886342d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1.0020909170697345d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 0.011382569881346461d);
// 
//   }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test496"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(16.25033494608802d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 16.0d);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test497"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double var3 = var0.inverseCumulativeProbability(0.9999999999928669d);
    double var4 = var0.getMean();
    double var6 = var0.probability((-0.3689837234418783d));
    double var7 = var0.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 6.755176609774487d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test498"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    double[] var6 = var4.getInternalValues();
    org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var8 = var7.getStandardDeviation();
    double[] var10 = var7.sample(1);
    double var11 = var7.getMean();
    double[] var13 = var7.sample(100);
    var4.addElements(var13);
    var4.setElement(36, 0.38829865251165124d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setExpansionMode((-2));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

//  public void test499() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest4.test499"); }
//
//
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(221578405, 2097152.5f);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//
//  }
//
  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test500"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(12.770914443685303d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.20312051983088344d);

  }

}
