
import junit.framework.*;

public class RandoopTest16 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test1"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-7053352210166488372L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7053352210166488372L);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test2"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.setElement(10, 0.6506783754890694d);
    double[] var9 = var2.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test3"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(231424, 231415);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test4"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.9012179477612883d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9012179477612884d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test5"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getNumericalVariance();
    double var7 = var3.getNumericalMean();
    var3.reseedRandomGenerator(10L);
    boolean var10 = var3.isSupportLowerBoundInclusive();
    double var11 = var3.getNumericalMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var13 = var3.sample((-9));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.8720980175938546d);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test6"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.lang.Object[] var11 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var9, var11);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var8, var11);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var11);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var11);
    org.apache.commons.math3.exception.MaxCountExceededException var16 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)1.2619699923279821d, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test7"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(99, 230399);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 22809501);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test8"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(596700, (-8));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 596708);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test9"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(2.4695522289423613d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test10"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-2.74137897748935d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-157.06944545602886d));

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test11"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    var2.setElement(10, 0.7612753675628248d);
    double[] var8 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test12"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    var2.setNumElements(100);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var2.copy();
    var2.setNumElements(2995200);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test13"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var5, var7);
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    java.lang.Object[] var14 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var12, var14);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var10, var11, var14);
    var8.addSuppressed((java.lang.Throwable)var16);
    java.lang.Throwable[] var18 = var8.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var19 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)1.8142035178418503E-11d, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalArgumentException var20 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathInternalError var21 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test14"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("org.apache.commons.math3.exception.OutOfRangeException: 0 out of [1, 0.651] range");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test15"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.4963483631908118d, (java.lang.Number)0.49027106946002635d, false);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.49027106946002635d+ "'", var5.equals(0.49027106946002635d));

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test16"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(8.403944766223448d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.12635126973902722d);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test17"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.013044992572946019d, (java.lang.Number)0.5088287629662838d, true);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test18"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2.4758803E29f, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2379401E29f);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test19"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    var3.reseedRandomGenerator(0L);
    double var9 = var3.cumulativeProbability(0.0d);
    double var10 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4.3318907109302085E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.POSITIVE_INFINITY);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test20"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-106), 1);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test21"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(22809501);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test22"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)7081.058387126132d);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test23"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.016482024418910425d, 189.32744069823292d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.016482024418910425d);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test24"); }


    float var2 = org.apache.commons.math3.util.FastMath.min((-9.999999f), (-9.999999f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-9.999999f));

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test25"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Throwable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var4, var6);
    java.lang.Throwable[] var8 = var7.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var2, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test26"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     double var5 = var2.density(0.5403023093369417d);
//     double var8 = var2.cumulativeProbability(0.6552836562919295d, 0.976508918599899d);
//     var2.reseedRandomGenerator((-7053352210170117162L));
//     double var11 = var2.getSupportUpperBound();
//     var2.reseedRandomGenerator(7053352210170117161L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1.0362220033551528d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.1900536393062961d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0591178080680944d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test27"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(0, 273111867);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test28"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.261404880340075d, (java.lang.Number)0.31405481363425186d, false);
    boolean var4 = var3.getBoundIsAllowed();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test29"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var4 = new org.apache.commons.math3.exception.NullArgumentException(var1, var3);
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var0, var3);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Number var7 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    java.lang.Throwable[] var10 = var9.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var6, var7, (java.lang.Object[])var10);
    var5.addSuppressed((java.lang.Throwable)var11);
    java.lang.Number var13 = var11.getMax();
    java.lang.Number var14 = var11.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test30"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var10 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var8, var10);
    java.lang.Throwable[] var12 = var11.getSuppressed();
    boolean var13 = var7.equals((java.lang.Object)var12);
    var7.discardMostRecentElements(0);
    double[] var16 = var7.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test31"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var2, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)(-0.5134857372468724d), (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test32"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     double var4 = var3.getSupportUpperBound();
//     double var5 = var3.getStandardDeviation();
//     boolean var6 = var3.isSupportConnected();
//     boolean var7 = var3.isSupportUpperBoundInclusive();
//     double var9 = var3.density((-1.1022542569867815d));
//     double var10 = var3.getMean();
//     double var11 = var3.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.8623188722876839d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.1287147879181489E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2.8720980175938546d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3.457614748932637d);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test33"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.03742244455830387d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-5));

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test34"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    int var11 = var2.getExpansionMode();
    double var13 = var2.substituteMostRecentElement(1.8486933916311794d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setContractionCriteria((-0.0012207031f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test35"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-8), 596708);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-8));

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test36"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.contract();
    int var7 = var2.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardMostRecentElements((-38937600));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test37"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(852815195628176645L, 7053352210170117161L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7906167405798293806L);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test38"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-1025), 2995200);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2994175);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test39"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-2996224), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2996224));

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test40"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.3707647883932745d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2));

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test41"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.8425208950104276d);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test42"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(123.20060399822916d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4210854715202004E-14d);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test43"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = var10.copy();
    float var12 = var11.getExpansionFactor();
    boolean var13 = var7.equals((java.lang.Object)var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test44"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     double var4 = var2.sample();
//     boolean var5 = var2.isSupportLowerBoundInclusive();
//     double var7 = var2.inverseCumulativeProbability(0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.08748125829655995d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.8262834677092343d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NEGATIVE_INFINITY);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test45"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.18834749242221216d), 1.553344806071505d);
    double var4 = var2.probability(3.775826473201856d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var2.cumulativeProbability(0.9085585716960896d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test46"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9921075120451343d, (java.lang.Number)0.03741371052586975d, true);
    java.lang.Number var4 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.03741371052586975d+ "'", var4.equals(0.03741371052586975d));

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test47"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     boolean var4 = var3.isSupportConnected();
//     double var5 = var3.sample();
//     boolean var6 = var3.isSupportUpperBoundInclusive();
//     double var7 = var3.sample();
//     boolean var8 = var3.isSupportUpperBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.8839142998345588d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 4.148801421947793d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test48"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(22809501, (-1024));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test49"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-2996224), 1.0000004f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test50"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.013707783890401887d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test51"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-4295468319161797071L), (-7053352210170117263L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test52"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.9973739581060155d, (java.lang.Number)0.2879144371105764d, true);

  }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test53"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
//     double[] var5 = null;
//     double[] var6 = var2.rank(var5);
// 
//   }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test54"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.MaxCountExceededException var2 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     java.lang.Object[] var9 = new java.lang.Object[] { 100.0d};
//     org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var7, var9);
//     org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, var9);
//     org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, var9);
//     org.apache.commons.math3.exception.util.ExceptionContext var13 = var2.getContext();
//     org.apache.commons.math3.exception.util.ExceptionContext var14 = var2.getContext();
//     java.lang.Throwable[] var15 = var2.getSuppressed();
//     org.apache.commons.math3.exception.MathArithmeticException var16 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var15);
//     org.apache.commons.math3.exception.util.ExceptionContext var17 = var16.getContext();
//     org.apache.commons.math3.exception.MathInternalError var18 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var16);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test55"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1.1641534E-10f);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test56"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    int var11 = var2.getExpansionMode();
    double var13 = var2.substituteMostRecentElement(45.0d);
    double var15 = var2.getElement(0);
    double var17 = var2.addElementRolling(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 45.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 45.0d);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test57"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getNumericalVariance();
    boolean var5 = var3.isSupportUpperBoundInclusive();
    boolean var6 = var3.isSupportUpperBoundInclusive();
    double var7 = var3.getMean();
    boolean var8 = var3.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test58"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.006660192447382807d);
    java.lang.Number var2 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0.006660192447382807d+ "'", var2.equals(0.006660192447382807d));

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test59"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(4.148801421947793d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.881784197001252E-16d);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test60"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    int var2 = var1.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var6 = var5.getNumElements();
    int var7 = var5.start();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
    int var9 = var5.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var5);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray.copy(var5, var11);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test61"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(918);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test62"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.8238753788547079d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.08413847564371897d));

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test63"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-18));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 18);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test64"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-4295468319161797071L), 1688143320063612998L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5983611639225410069L));

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test65"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(3.2544789518188435d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 25.90611268385252d);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test66"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)7.560575574229005E-6d, (java.lang.Number)1.107194659485365d, (java.lang.Number)1.8519271337371066d);
    java.lang.Number var4 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.8519271337371066d+ "'", var4.equals(1.8519271337371066d));

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test67"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var6, var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var5, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test68"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)100, (java.lang.Number)2.7760523581453453d, false);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test69"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    var2.setElement(10, 0.7612753675628248d);
    var2.discardFrontElements(0);
    double[] var10 = var2.getInternalValues();
    float var11 = var2.getExpansionFactor();
    float var12 = var2.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 100.0f);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test70"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.5088287629662838d);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test71"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(3.2544789518188435d, 1.0978670566943427d, 0.4906578777776055d, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test72"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var2 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var5, var7);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var4, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, var7);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var0, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test73"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(155.33650900579727d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.17147568645416508d));

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test74"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(2994176, 918);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2993258);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test75"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.4565328629839229d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 19.95959161095043d);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test76"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-90L), 2993258);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test77"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var6 = var2.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.getElement(0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test78"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(10.0f, (-0.007409736020362853d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.999999f);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test79"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.1924023244417262d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7157896854888646d));

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test80"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    var2.contract();
    var2.setExpansionMode(0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var15.setExpansionMode(0);
    double[] var18 = var15.getInternalValues();
    double[] var19 = var15.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var12, var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test81"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//     var2.setExpansionMode(0);
//     double[] var5 = var2.getInternalValues();
//     var2.clear();
//     org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
//     var2.setNumElements(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//     var12.setExpansionMode(0);
//     double[] var15 = var12.getInternalValues();
//     var12.clear();
//     double var18 = var12.addElementRolling(0.7853981633974483d);
//     var12.addElement(0.0d);
//     var12.setNumElements(100);
//     boolean var23 = var2.equals((java.lang.Object)var12);
//     int var24 = var2.getNumElements();
//     var2.contract();
//     double[] var26 = var2.getInternalValues();
//     double[] var27 = null;
//     var2.addElements(var27);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test82"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getNumericalVariance();
    double var7 = var3.getNumericalMean();
    var3.reseedRandomGenerator(10L);
    boolean var10 = var3.isSupportLowerBoundInclusive();
    double var11 = var3.getNumericalMean();
    double var12 = var3.getSupportUpperBound();
    double var13 = var3.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == Double.NEGATIVE_INFINITY);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test83"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-7053352210166488372L), (-90L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test84"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var8 = var7.getExpansionMode();
    int var9 = var7.getNumElements();
    org.apache.commons.math3.distribution.NormalDistribution var13 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var14 = var13.getSupportUpperBound();
    double var15 = var13.getStandardDeviation();
    boolean var16 = var13.isSupportConnected();
    double var17 = var13.getSupportUpperBound();
    boolean var18 = var13.isSupportUpperBoundInclusive();
    boolean var19 = var13.isSupportConnected();
    boolean var20 = var7.equals((java.lang.Object)var19);
    double[] var21 = var7.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var21);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var22.discardFrontElements((-18));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test85"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.9127083523155106d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.28164875432624675d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test86"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
    double var3 = var2.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == Double.NEGATIVE_INFINITY);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test87"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    var2.setElement(10, 0.7612753675628248d);
    var2.discardFrontElements(0);
    var2.addElement(2.9135626894536033d);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test88"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)32.414874061853936d, (java.lang.Number)0.3185741994402654d, (java.lang.Number)5.397570075115222E-22d);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test89"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.2419199653877895d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2166585413284845d);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test90"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(11700, 1015);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 12715);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test91"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 7053352210170117173L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test92"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.9443504370351304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test93"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(3.739561347646417d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3189683178222578d);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test94"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(0, (-790794752));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test95"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(1.3205004784536853d, 1.0000000272417795d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.6564182950209079d);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test96"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.2825498340254315d, (java.lang.Number)0.7745517090716676d, false);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test97"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    var2.addElement(0.6506783754890694d);
    int var9 = var2.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    float var11 = var2.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setContractionCriteria(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.5f);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test98"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(900, 273112767);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-273111867));

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test99"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-100.0f), 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test100"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)2.755691487042354d, false);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test101"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1024, 50.0f, 100.50001f, 2994175);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test102"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, 0.2166585413284845d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test103"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.00888514508528015d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5507503625553098E-4d);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test104"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(1.2702602426089444d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2702602426089444d);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test105"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardFrontElements(2994176);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test106"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    double[] var8 = var7.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    var9.setElement(596700, 0.5683852532105546d);
    var9.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test107"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0, 596700);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 596700);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test108"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var5, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var7);
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)1024, var7);
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var0, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test109"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-109L), (-7053352210170117263L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7053352210170117263L));

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test110"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.8407359138160451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6861986540091058d);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test111"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Number var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var6, var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var5, var8);
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, var4, var8);
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var2, var8);
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var1, var8);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var0, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test112"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    boolean var6 = var3.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test113"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(3.129990516500412d, 0.17543139267904398d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.8040494263040562d));

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test114"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(230400, (-106));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-106));

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test115"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(100.0f, 0.9551779281484893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99.99999f);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test116"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(2.7270454965758133d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.122854399419089d);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test117"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.4511708924835962d, (java.lang.Number)1.5692474232144973d);
    java.lang.Number var4 = var3.getHi();
    java.lang.Number var5 = var3.getLo();
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.lang.Object[] var11 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var9, var11);
    java.lang.Throwable[] var13 = var12.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var14 = new org.apache.commons.math3.exception.MaxCountExceededException(var7, (java.lang.Number)(-5.496154324107173d), (java.lang.Object[])var13);
    var3.addSuppressed((java.lang.Throwable)var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.5692474232144973d+ "'", var4.equals(1.5692474232144973d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.4511708924835962d+ "'", var5.equals(0.4511708924835962d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test118"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    var2.setNumElements(100);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var2.copy();
    var2.setNumElements(2995200);
    int var16 = var2.getNumElements();
    double[] var17 = var2.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2995200);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test119"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    var3.reseedRandomGenerator(0L);
    boolean var8 = var3.isSupportLowerBoundInclusive();
    double var10 = var3.cumulativeProbability(2.2683541557421067d);
    double var12 = var3.probability(0.8407359138160451d);
    double var14 = var3.density(24.73278948466765d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.24191996538778948d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.2880888037361353E-140d);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test120"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(434.37252950753066d, (-0.3655932269839443d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5716379848552513d);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test121"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.4564303327104865d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 26.15153170606284d);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test122"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.contract();
    int var7 = var2.getExpansionMode();
    boolean var9 = var2.equals((java.lang.Object)26.15153170606284d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test123"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
    boolean var3 = var2.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test124"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(230399, 1.1641532E-10f, 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test125"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp((-10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.536743E-7f);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test126"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var6 = var2.getNumElements();
    double[] var7 = var2.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test127"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.976508918599899d);
    java.lang.Throwable[] var3 = var2.getSuppressed();
    java.lang.Number var4 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test128"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(1.2825498340254315d, 0.9565627942373829d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.17845615719222213d));

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test129"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(3.175810808968181d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4698901315402613d);

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test130"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.4596347826973801d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test131"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(1023.7781831699072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.624402106174204d);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test132"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-1L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test133"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.7853981633974484d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7853981633974485d);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test134"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.2419199653877895d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.24434410597703027d);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test135"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.6418208263327543d, (java.lang.Number)(-0.48346953277414534d), true);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    java.lang.Number var5 = var3.getMax();
    java.lang.Number var6 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.48346953277414534d)+ "'", var5.equals((-0.48346953277414534d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-0.48346953277414534d)+ "'", var6.equals((-0.48346953277414534d)));

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test136"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 10676);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test137"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3.8239280375108544d, (java.lang.Number)1.0334835754536079E-8d, (java.lang.Number)1.0012991368777728d);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.0012991368777728d+ "'", var5.equals(1.0012991368777728d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1.0334835754536079E-8d+ "'", var6.equals(1.0334835754536079E-8d));

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test138"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1015, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test139"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.9999999968194917d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.761594154620033d);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test140"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.5403972100018254d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.149602718784553d);

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test141"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     double var5 = var2.density(0.5403023093369417d);
//     double var8 = var2.cumulativeProbability(0.6552836562919295d, 0.976508918599899d);
//     double var10 = var2.inverseCumulativeProbability(0.9999636981980967d);
//     double var11 = var2.getStandardDeviation();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.6566195865042359d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.1900536393062961d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0591178080680944d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 8.403944766223448d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.069655856740348d);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test142"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.18834749242221216d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3));

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test143"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-0.9603035914737312d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test144"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.9022156594299824d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test145"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(1.2627647432735111E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2627647365616017E-4d);

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test146"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.1122111167200628d), (-1.8845561638255066d), (-0.5766492970787104d), 11700);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test147"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(0, 900);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test148"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.1919266570807596d);
    boolean var2 = var1.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test149"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.15053663240231746d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8314120236390998d);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test150"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.1581263863353843d);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test151"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(1.941575758241476d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test152"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-0.5545968900472659d), 0.9997833820018625d, 0.6506783754890694d);
    double var5 = var3.density(0.2419199653877895d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.29052114477037505d);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test153"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getNumericalVariance();
    boolean var5 = var3.isSupportUpperBoundInclusive();
    double var6 = var3.getNumericalMean();
    double var7 = var3.getSupportLowerBound();
    var3.reseedRandomGenerator(100L);
    double var11 = var3.probability(1.542826101286539d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test154"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.4511708924835962d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2));

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test155"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.4407844498728315d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test156"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.5607966601082315d, 0.32462331036466185d, 0.053470501981572265d);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test157"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(2996224, 3.8146973E-6f, 102912.0f, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test158"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.9997833820018625d, 0.1924023244417262d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var4 = var2.sample((-13));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test159"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(100, 599700145);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 599700245);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test160"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(26957916, 1024);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test161"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.008884911277691669d, (java.lang.Number)(-1L), true);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test162"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp((-0.001220703f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1641532E-10f);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test163"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    double[] var2 = var1.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test164"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp((-1024.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1023.99994f));

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test165"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.discardFrontElements(0);
    var2.addElement(0.8085085755675573d);
    int var11 = var2.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test166"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc((-0.4459607124434285d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4717526330792405d);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test167"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(100, 11700);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test168"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var2.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    int var8 = var7.start();
    var7.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test169"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test170"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    var2.contract();
    var2.setExpansionMode(0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double[] var13 = var2.getInternalValues();
    int var14 = var2.getNumElements();
    var2.setElement(2996224, 3.1868873092888728d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test171"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(852815195628176645L, 1024L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test172"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-2995324), (-106));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test173"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.553344806071505d, 5.403460554103678E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5533448060715047d);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test174"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    float var7 = var2.getExpansionFactor();
    var2.setExpansionMode(0);
    double var11 = var2.substituteMostRecentElement(0.4511708924835962d);
    double var13 = var2.getElement(0);
    double[] var14 = var2.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardFrontElements(230399);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test175"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    var2.addElement(0.6506783754890694d);
    int var9 = var2.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double[] var11 = var2.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test176"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(0.4488422487920356d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6796769585650928d);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test177"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    var2.contract();
    var2.setExpansionMode(0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double[] var13 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test178"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-11700));

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test179"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.9130907135554012d, 0.7316193579789825d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9130907135554011d);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test180"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-1.8626521886396386d), (-9));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.003637992555936794d));

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test181"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.0d);
    java.lang.Number var2 = var1.getMin();
    java.lang.Number var3 = var1.getArgument();
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)14.21986053821574d, (java.lang.Number)0.4917114930263137d, false);
    var1.addSuppressed((java.lang.Throwable)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0.0d+ "'", var3.equals(0.0d));

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test182"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(100.0f, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test183"); }


    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(100, 50.0f, 50.0f, 1);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var10 = new double[] { 100.0d, 1.0d};
    var7.addElements(var10);
    var7.setNumElements(1);
    var7.contract();
    var7.setExpansionMode(0);
    var7.contract();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var7);
    float var19 = var4.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 50.0f);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test184"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    boolean var6 = var3.isSupportConnected();
    double var8 = var3.probability((-0.3827413742969658d));
    double var9 = var3.getStandardDeviation();
    boolean var10 = var3.isSupportConnected();
    boolean var11 = var3.isSupportLowerBoundInclusive();
    double var14 = var3.cumulativeProbability(1.0966104455465058d, 1.8329046427950961d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0943308440870495d);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test185"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.4758803E29f, 1024.0001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.4758803E29f);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test186"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(1.3054246841316648d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7090990662594108d);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test187"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.013046161355485517d, (java.lang.Number)7081.058387126132d, false);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test188"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    var2.setExpansionFactor(50.0f);
    double var10 = var2.addElementRolling(0.31689424315458475d);
    var2.setNumElements(99);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test189"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(109L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test190"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-0.03201769847914048d), 599700145);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test191"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.0d, 1.252472486418605d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0d));

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test192"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.0677664646480862d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.02847627684499202d);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test193"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var2.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test194"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.2379401E29f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2379402E29f);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test195"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.9150123793192297d, (java.lang.Number)4.333449949606716E-4d, true);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test196"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(2.4758799E29f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test197"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-1.0362220033551528d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test198"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.0d, (-3));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test199"); }


    java.math.BigInteger var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, (-6221772920507596800L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test200"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     double var4 = var2.sample();
//     double var6 = var2.probability(57.295779276891516d);
//     double var8 = var2.density(0.017453292447995462d);
//     double var9 = var2.getNumericalVariance();
//     boolean var10 = var2.isSupportConnected();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var2.cumulativeProbability(0.28225676997321014d, (-0.08413847564371897d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.4439784548089769d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.5339174516396257d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.19207034841124335d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4.283475365339624d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == true);
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test201"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    var2.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var12.setExpansionMode(0);
    double[] var15 = var12.getInternalValues();
    var12.clear();
    double var18 = var12.addElementRolling(0.7853981633974483d);
    var12.addElement(0.0d);
    var12.setNumElements(100);
    boolean var23 = var2.equals((java.lang.Object)var12);
    int var24 = var2.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var28 = var27.getNumElements();
    int var29 = var27.start();
    var27.setElement(10, 0.7612753675628248d);
    var27.discardFrontElements(0);
    double[] var35 = var27.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray(var35);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var36);
    var2.setNumElements(1024);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardFrontElements((-2995324));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test202"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(599700145);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test203"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    var2.setNumElements(100);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var2.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var13.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var18 = var17.getNumElements();
    double[] var19 = var17.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var17);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = var14.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test204"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.0020673331348737703d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0023327323175753437d);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test205"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.2879144371105764d, (java.lang.Number)0, true);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test206"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var2.copy();
    float var7 = var2.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100.5f);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test207"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.27640092266786565d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test208"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.1641534E-10f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1641535E-10f);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test209"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.49027106946002635d, 0.6097807640004534d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.11950969454042709d));

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test210"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(1.2627647432735111E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2627647432735111E-4d);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test211"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(0.02756156531860343d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.576040613015977d);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test212"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.0000005f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test213"); }


    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 1.0000002f, 10.0f);
    int var4 = var3.getExpansionMode();
    boolean var6 = var3.equals((java.lang.Object)3.176317736551261d);
    boolean var8 = var3.equals((java.lang.Object)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test214"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-273111867), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test215"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Number var7 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var9 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var5, (java.lang.Number)5.889694544886073d, var7, true);
    java.lang.Throwable[] var10 = var9.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)0.00824820856234747d, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathArithmeticException var12 = new org.apache.commons.math3.exception.MathArithmeticException(var2, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MaxCountExceededException var13 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)3.063332550849334E67d, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test216"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(1015, 0.0f, 1.1641532E-10f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test217"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-273111867), (-1024));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test218"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-106), (-3));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-109));

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test219"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-11891), 2994176);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2994176);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test220"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(7053352210166488461L, 7053352210173745972L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7053352210166488461L);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test221"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0, 273111867);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test222"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(4.4949968685348285E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test223"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.8172154268646284d, 0.8238753788547079d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6482058301060311d);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test224"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(12715, (-38937600));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 38950315);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test225"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(599700245, 1.0000002f);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test226"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(8400190882459457459L, (-2605573555328993815L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test227"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-1.2927045528110097d), 900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0926859929987715E271d));

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test228"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-3.1735994179935405d));
    java.lang.Number var2 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + (-3.1735994179935405d)+ "'", var2.equals((-3.1735994179935405d)));

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test229"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)3.798976010926035d);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test230"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-1.8859483478114027d), (-0.32199715256667094d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9132389649161978d);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test231"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.9127083523155106d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.241317614400649d);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test232"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, 2.9784814163978397d, 2.0980109293178746d, (-8));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test233"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.015017753780066721d, (java.lang.Number)1.9634526771778158d, false);
    java.lang.Number var4 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.9634526771778158d+ "'", var4.equals(1.9634526771778158d));

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test234"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.12929424722150962d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 61.19997931247053d);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test235"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0d, 0.27640092266786565d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test236"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-1.0926859929987715E271d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test237"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(10, (-38937600));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-389376000));

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test238"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-13), 26957916);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test239"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    int var8 = var2.getNumElements();
    var2.clear();
    int var10 = var2.getNumElements();
    double var12 = var2.addElementRolling(0.6318205360130218d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setContractionCriteria((-9.999999f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test240"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow((-1.7952220558689955d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test241"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    double[] var8 = var7.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var7.substituteMostRecentElement(0.017302733052967395d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test242"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, var1, (java.lang.Object[])var4);
    java.lang.Number var6 = var5.getMax();
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var5.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var5.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test243"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(45.0d, 1.0000075606041554d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.548577593537681d);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test244"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(852815195628176636L, 23962592);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test245"); }


    long var1 = org.apache.commons.math3.util.FastMath.round((-0.41926361214787744d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test246"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     double var4 = var2.sample();
//     double var6 = var2.probability(57.295779276891516d);
//     boolean var7 = var2.isSupportLowerBoundInclusive();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var9 = var2.sample((-13));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.3581575987611913d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-3.1970553528155694d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test247"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(1.2475312893420674d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9482032886623158d);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test248"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(5.0477497738691754d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test249"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(4.5474735E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-41));

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test250"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-1.0926859929987715E271d), 1.5663644184740926d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.5707963267948966d));

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test251"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, 3.8134716207164714d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test252"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.7612753675628248d, 0.004241254589664838d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.7135579402202272d));

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test253"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.2379402E29f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test254"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(7053352210166488372L, (-7053352210170117162L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7053352210166488372L);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test255"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(359.1342053695755d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.10807918087573d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test256"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-109L), 7053352210173745971L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test257"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.43437055889937937d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.007581196426522127d);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test258"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs((-0.01928412433486901d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.01928412433486901d);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test259"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(15.055514259581079d, 1.6136426314409833d);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test260"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    double var6 = var3.getMean();
    double var7 = var3.getMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var9 = var3.sample((-18));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.8720980175938546d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test261"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo((-7053352210170117163L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test262"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    var2.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var12.setExpansionMode(0);
    double[] var15 = var12.getInternalValues();
    var12.clear();
    double var18 = var12.addElementRolling(0.7853981633974483d);
    var12.addElement(0.0d);
    var12.setNumElements(100);
    boolean var23 = var2.equals((java.lang.Object)var12);
    int var24 = var2.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var28 = var27.getNumElements();
    int var29 = var27.start();
    var27.setElement(10, 0.7612753675628248d);
    var27.discardFrontElements(0);
    double[] var35 = var27.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray(var35);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var36);
    boolean var39 = var2.equals((java.lang.Object)0.03542607474907544d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test263"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(230382);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2614265.4737673546d);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test264"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)5.051925868811929E-4d);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test265"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-1.7952220558689955d), 0.5686929365266755d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.7952220558689955d));

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test266"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.5692474232144973d, 1.0648164703369514d, 0.976508918599899d);
    boolean var4 = var3.isSupportUpperBoundInclusive();
    double var6 = var3.inverseCumulativeProbability(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.NEGATIVE_INFINITY);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test267"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1024.0001f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024.0f);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test268"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var5.setExpansionMode(0);
    double[] var8 = var5.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var12 = var11.getNumElements();
    double[] var13 = var11.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var5, var11);
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    org.apache.commons.math3.exception.util.Localizable var17 = null;
    java.lang.Object[] var19 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var20 = new org.apache.commons.math3.exception.NullArgumentException(var17, var19);
    org.apache.commons.math3.exception.MaxCountExceededException var21 = new org.apache.commons.math3.exception.MaxCountExceededException(var15, (java.lang.Number)0.7435938375035029d, var19);
    boolean var22 = var11.equals((java.lang.Object)var19);
    org.apache.commons.math3.exception.MaxCountExceededException var23 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)1.7341157890730137d, var19);
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var0, var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test269"); }
// 
// 
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.006660192447382807d);
//     java.lang.Throwable var2 = null;
//     var1.addSuppressed(var2);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test270"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(0L, 3628799L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3628799L));

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test271"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.14022847040561234d, (java.lang.Number)6.122854399419089d, (java.lang.Number)(-0.48346953277414534d));

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test272"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(7053352210173745972L, 852815195628176636L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7906167405801922608L);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test273"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-7053352210170117162L), (-5365208890106504175L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3L);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test274"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(100.50001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.6293945E-6f);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test275"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.0023327323175753437d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.002332734433224193d);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test276"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.2544789518188435d, (java.lang.Number)0.9168407258198261d, true);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    java.lang.Number var6 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.9168407258198261d+ "'", var6.equals(0.9168407258198261d));

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test277"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-0.08413847564371897d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.083940489568844d));

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test278"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double[] var7 = var3.sample(100);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    var9.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.setExpansionMode(273111867);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test279"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(91, 900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 900);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test280"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double[] var7 = var2.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardMostRecentElements(23962592);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test281"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.7745517090716676d, 0.15591759939935756d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.552131640467102d));

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test282"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var6.setExpansionMode(0);
    double[] var9 = var6.getInternalValues();
    var2.addElements(var9);
    double var12 = var2.substituteMostRecentElement(0.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var2.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardMostRecentElements(273111867);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test283"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.1522099054496074d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test284"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(1015, 1024.0f, 49.999996f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test285"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.15053663240231746d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.387990505556924d);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test286"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(2.012188277016233d, 0.1239298104866064d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1239298104866064d);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test287"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(3.7495293816565884d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.699284258750162d);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test288"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.9302363507574447d, 1.941575758241476d, 0.6681363173166157d);
    double var4 = var3.getSupportLowerBound();
    var3.reseedRandomGenerator(5365208890106504293L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test289"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.9998140209319779d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9998140209319779d);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test290"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    float var7 = var2.getExpansionFactor();
    var2.setExpansionMode(0);
    double var11 = var2.substituteMostRecentElement(0.4511708924835962d);
    double var13 = var2.getElement(0);
    double[] var14 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    var15.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test291"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double var6 = var2.addElementRolling(0.0d);
    int var7 = var2.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test292"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var1, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
//     java.lang.Throwable[] var6 = var5.getSuppressed();
//     java.lang.Throwable[] var7 = var5.getSuppressed();
//     org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var7);
//     java.lang.String var9 = var8.toString();
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test293"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    var2.setNumElements(100);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var2.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var13.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    double[] var17 = var16.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var13, var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var20 = var13.getElement(599700245);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test294"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.10485073303358433d, (-1.9567414021624154E-4d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3.060612232113507E-5d));

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test295"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.8529254698656474d, 0.0d, 3.4959757017900213d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test296"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.5683852532105547d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test297"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(23962592);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test298"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    int var7 = var2.getExpansionMode();
    float var8 = var2.getExpansionFactor();
    var2.setNumElements(0);
    double var12 = var2.addElementRolling(7.253658542162704E-25d);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var2.copy();
    double[] var17 = new double[] { 100.0d, 1.0d, (-1.0d)};
    var2.addElements(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test299"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.1479251422110193d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test300"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    boolean var6 = var3.isSupportConnected();
    double var9 = var3.cumulativeProbability(1.1591352365493741d, 10.000000000000002d);
    double var11 = var3.density(2.6058222619154248d);
    double var13 = var3.density(0.9823582712279686d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var15 = var3.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.976508918599899d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.44109980171999075d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.041917032942934654d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test301"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    float var7 = var2.getExpansionFactor();
    var2.setExpansionMode(0);
    double var11 = var2.substituteMostRecentElement(0.4511708924835962d);
    double var13 = var2.getElement(0);
    int var14 = var2.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test302"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(7053352210170117160L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7053352210170117160L);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test303"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test304"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     double var5 = var2.density(0.5403023093369417d);
//     var2.reseedRandomGenerator(10L);
//     double var9 = var2.cumulativeProbability(0.18861061650520586d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var2.inverseCumulativeProbability(1.4698901315402613d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.019086005653605104d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.1900536393062961d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.4992691191824491d);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test305"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(8.639495877295877E-5d, 10.000000000000002d);
    double var3 = var2.getStandardDeviation();
    double var5 = var2.cumulativeProbability(0.31405481363425186d);
    double var7 = var2.density(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 10.000000000000002d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5125234701320897d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.03989422803865439d);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test306"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getNumericalVariance();
    boolean var5 = var3.isSupportUpperBoundInclusive();
    boolean var6 = var3.isSupportUpperBoundInclusive();
    double var7 = var3.getMean();
    double var9 = var3.density((-2.2464654344892634d));
    double var11 = var3.density((-12.399251845187958d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0334835754536079E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 3.6401719150663264E-69d);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test307"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-11700), 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test308"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(1.4717526330792405d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9587890424764594d);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test309"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-0.797982492819634d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6735095436595417d));

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test310"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.1919266570807596d);
    boolean var2 = var1.getBoundIsAllowed();
    java.lang.Number var3 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0.1919266570807596d+ "'", var3.equals(0.1919266570807596d));

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test311"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(2993258, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test312"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    float var7 = var2.getExpansionFactor();
    var2.setExpansionMode(0);
    double[] var10 = var2.getInternalValues();
    float var11 = var2.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setContractionCriteria(1.0000002f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.5f);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test313"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    var2.addElement(0.6506783754890694d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardMostRecentElements(900);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test314"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(100.00000000000004d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test315"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.9921075120451343d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.017315542618956896d);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test316"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(2.9135626894536033d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.22605892466343286d);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test317"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(2996224, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 299622400);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test318"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(155.33650900579727d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.052010793041773d);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test319"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    float var7 = var2.getExpansionFactor();
    org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var12 = var11.getSupportUpperBound();
    double var13 = var11.getStandardDeviation();
    boolean var14 = var11.isSupportConnected();
    var11.reseedRandomGenerator(5365208890106504175L);
    boolean var17 = var2.equals((java.lang.Object)5365208890106504175L);
    int var18 = var2.start();
    int var19 = var2.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test320"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)7053352210170117161L, (java.lang.Number)0.27640092266786565d, true);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test321"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.6142995902819931d);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test322"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(230400, (-11700));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 218700);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test323"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var2.setContractionCriteria(100.0f);
    var2.contract();
    int var11 = var2.getNumElements();
    var2.setExpansionMode(0);
    double[] var14 = var2.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test324"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var4 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var2, (java.lang.Number)(byte)100);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    java.lang.Object[] var6 = new java.lang.Object[] { var4};
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var1, var6);
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var0, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test325"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 0.2166585413284845d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test326"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)3.432443690009129E42d);
    boolean var2 = var1.getBoundIsAllowed();
    java.lang.Number var3 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 3.432443690009129E42d+ "'", var3.equals(3.432443690009129E42d));

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test327"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.44109980171999075d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test328"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(1.241317614400649d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9462111345960358d);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test329"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("org.apache.commons.math3.exception.NumberIsTooSmallException: 7,081.058 is smaller than the minimum (2.872)");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test330"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-11891), 7906167405801922608L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1033075519));

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test331"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.3205004784536853d, (java.lang.Number)0.4511708924835962d, false);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test332"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-3), (java.lang.Number)38.48514870421596d, false);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test333"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-4.222640875446916d), (java.lang.Number)1.4407844498728315d, (java.lang.Number)10.0f);
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.4407844498728315d+ "'", var5.equals(1.4407844498728315d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 10.0f+ "'", var6.equals(10.0f));

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test334"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.2544789518188435d, (java.lang.Number)0.9168407258198261d, true);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    boolean var5 = var3.getBoundIsAllowed();
    java.lang.String var6 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 3.254 is larger than the maximum (0.917)"+ "'", var6.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 3.254 is larger than the maximum (0.917)"));

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test335"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test336"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     double var4 = var2.sample();
//     double var6 = var2.probability(57.295779276891516d);
//     double var8 = var2.density(0.017453292447995462d);
//     double var10 = var2.density(0.976508918599899d);
//     double var12 = var2.inverseCumulativeProbability(0.24191996538778948d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.5105154539695673d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.2969685158225493d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.19207034841124335d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.17940889770647472d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1.2566463509485577d));
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test337"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.6142995902819931d);
    java.lang.Number var2 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0.6142995902819931d+ "'", var2.equals(0.6142995902819931d));

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test338"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(109L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test339"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var10 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var8, var10);
    java.lang.Throwable[] var12 = var11.getSuppressed();
    boolean var13 = var7.equals((java.lang.Object)var12);
    var7.clear();
    var7.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test340"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.7945379304806328d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6525500924553346d);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test341"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.1048515747957178d);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test342"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-7053352210170117172L), (-7053352210170117083L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test343"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (1.645) exceeded");
// 
//   }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test344"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.9900135569345746d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6912709574862417d);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test345"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    var2.contract();
    var2.setExpansionMode(0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var13 = var12.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test346"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.15849787290633868d, 44.44139583636861d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.804948927447627E-36d);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test347"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(23962592);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.8320988864621484E8d);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test348"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.3537192987804616d, (-157.06944545602886d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.139340664351555d);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test349"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(byte)100);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    java.lang.Throwable[] var4 = var2.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test350"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-11891), (java.lang.Number)0.9022156594299824d, false);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test351"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(2.53971155532965d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0d);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test352"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(596700, 230399);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test353"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(93.72989180803069d, 2.7270454965758133d);
    double var3 = var2.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == Double.POSITIVE_INFINITY);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test354"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.10485073303358433d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.10485073303358435d);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test355"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getNumericalVariance();
    boolean var7 = var3.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test356"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.0000000272417795d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000000090805932d);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test357"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.addElement(0.8414709848078965d);
    float var9 = var2.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var2.getElement(91);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.5f);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test358"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    var2.setExpansionMode(0);
    var2.setExpansionFactor(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test359"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(4.0503838303319295d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.410840388421736d);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test360"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-0.5711267724381359d), (-1.8845561638255066d), 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test361"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-11700), (-1024));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test362"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.9085585716960896d, 2.6900155377520427d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-10.318968152213591d));

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test363"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    var2.addElement(0.6506783754890694d);
    int var9 = var2.getNumElements();
    var2.setContractionCriteria(100.0f);
    float var12 = var2.getContractionCriteria();
    int var13 = var2.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test364"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.24434410597703027d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9702962075298299d);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test365"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.1239298104866064d, (java.lang.Number)14.21986053821574d, (java.lang.Number)(-1023.99994f));

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test366"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.06945592031929565d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test367"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(4.5474735E-13f, 1.1641532E-10f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.5474735E-13f);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test368"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.15784164524753735d);

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test369"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.9188014802486864d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test370"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(596708, (-10.0f), 2.4758799E29f, (-38937600));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test371"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-7053352210170117083L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7053352210170117083L));

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test372"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(123.58778338131026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test373"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(10.0f, 102912.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 102912.0f);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test374"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.9997833820018625d, 0.1924023244417262d);
    double var3 = var2.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.1924023244417262d);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test375"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-1), (-790794752));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test376"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-1.0f), (-790794752));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0f));

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test377"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-0.30312444178518694d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.29866442992225317d));

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test378"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter((-1024.0f), 0.05349598516132738d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1023.99994f));

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test379"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var10 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var8, var10);
    java.lang.Throwable[] var12 = var11.getSuppressed();
    boolean var13 = var7.equals((java.lang.Object)var12);
    var7.addElement(1.4214549026638725d);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var21 = new double[] { 100.0d, 1.0d};
    var18.addElements(var21);
    var18.addElement(0.8414709848078965d);
    boolean var25 = var7.equals((java.lang.Object)var18);
    double[] var26 = var7.getElements();
    var7.setElement(596708, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test380"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-5));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test381"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.01849471098810033d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.135995260903093d);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test382"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    var2.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var12.setExpansionMode(0);
    double[] var15 = var12.getInternalValues();
    var12.clear();
    double var18 = var12.addElementRolling(0.7853981633974483d);
    var12.addElement(0.0d);
    var12.setNumElements(100);
    boolean var23 = var2.equals((java.lang.Object)var12);
    double[] var24 = var2.getElements();
    int var25 = var2.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test383"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(77.83267480140304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 77.83267480140306d);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test384"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0L, 7053352210173745972L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test385"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(8400190882459457459L, 100L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test386"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = var2.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test387"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double[] var7 = var2.getElements();
    boolean var9 = var2.equals((java.lang.Object)0.10446901610108233d);
    int var10 = var2.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test388"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(7.701708467424528d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7387776572306084d);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test389"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.6525500924553346d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test390"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.9565627942373829d, 3.8239280375108544d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.019878299454072185d);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test391"); }


    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(100, 49.999996f, 1024.0f);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test392"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(byte)0);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var5 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var3, (java.lang.Number)(-3.1735994179935405d));
    var2.addSuppressed((java.lang.Throwable)var5);
    java.lang.Number var7 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0+ "'", var7.equals(0));

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test393"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-7053352210170117172L), 7053352210166488461L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7053352210170117172L));

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test394"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var8 = var7.getExpansionMode();
    int var9 = var7.getNumElements();
    org.apache.commons.math3.distribution.NormalDistribution var13 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    boolean var14 = var13.isSupportUpperBoundInclusive();
    boolean var15 = var7.equals((java.lang.Object)var13);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var19 = var18.getNumElements();
    int var20 = var18.start();
    double var22 = var18.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    int var24 = var23.getExpansionMode();
    int var25 = var23.getNumElements();
    org.apache.commons.math3.distribution.NormalDistribution var29 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var30 = var29.getSupportUpperBound();
    double var31 = var29.getStandardDeviation();
    boolean var32 = var29.isSupportConnected();
    double var33 = var29.getSupportUpperBound();
    boolean var34 = var29.isSupportUpperBoundInclusive();
    boolean var35 = var29.isSupportConnected();
    boolean var36 = var23.equals((java.lang.Object)var35);
    double[] var37 = var23.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray(var37);
    var7.addElements(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test395"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(3628799L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test396"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(1.0000004f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test397"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.007581196426522127d, 1.0978670566943427d, 2.1200287568955276d, (-1025));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test398"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var6 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var4, (java.lang.Number)(byte)100);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    java.lang.Object[] var8 = new java.lang.Object[] { var6};
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var3, var8);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var2, var8);
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)2.4202087772646754d, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test399"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var2.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test400"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(3.5544029147833944d, 1.241317614400649d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.241317614400649d);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test401"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.7316193579789825d, 32.414874061853936d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7316193579789825d);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test402"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    var2.addElement(0.6506783754890694d);
    int var9 = var2.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var2.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionMode((-2996224));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test403"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.00888514508528015d);
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var2, (java.lang.Number)0.4963483631908118d, (java.lang.Number)0.49027106946002635d, false);
    var1.addSuppressed((java.lang.Throwable)var6);
    boolean var8 = var6.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test404"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var8 = var3.cumulativeProbability((-0.5063656411097587d), 1.941575758241476d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var10 = var3.sample((-3));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.14022847040561234d);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test405"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(100, 2994176);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 299417600);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test406"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.352454744646058d, 3.1757334232496706d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.352454744646058d);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test407"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.976508918599899d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7515506671315073d);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test408"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(3.1868873092888728d, 0.7853981633974485d, 0.28225676997321014d, (-9));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test409"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var2.setContractionCriteria(100.0f);
    var2.contract();
    int var11 = var2.getNumElements();
    var2.setExpansionMode(0);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test410"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-2.369654581753662d), 1.9949947071234375d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.8710278846235737d));

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test411"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-273111867), (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test412"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var2.setContractionCriteria(100.0f);
    var2.contract();
    int var11 = var2.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setContractionCriteria(50.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test413"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.8238753788547079d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.600963566321695d);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test414"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(3.8146973E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.8146977E-6f);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test415"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(2.0125565409031196d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.005359418284848427d);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test416"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(1024L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1024L);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test417"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs((-0.0012207029f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0012207029f);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test418"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.8170655554314067d, 1.1287147879181489E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 56.3852420349405d);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test419"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-1.6669870622832723d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9311522197519757d));

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test420"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.4758799E29f, 102912.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.4758799E29f);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test421"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.9085585716960896d, 208.783820926016d, (-0.07369898640584448d), 10);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test422"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)7081.058387126132d, (java.lang.Number)2.8720980175938546d, true);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var12 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var8, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
    java.lang.Throwable[] var13 = var12.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, (java.lang.Object[])var13);
    java.lang.Throwable[] var16 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var17 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathInternalError var18 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test423"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(0.8172154268646284d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.13578368077383196d);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test424"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-1), 99);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 98);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test425"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.9702962075298299d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test426"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.9362542790790519d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5504103787854016d);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test427"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-0.6112265217154569d));
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    java.lang.Number var4 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test428"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(8.639495877295877E-5d, 10.000000000000002d);
    double var3 = var2.getStandardDeviation();
    double var4 = var2.getNumericalVariance();
    var2.reseedRandomGenerator(10L);
    boolean var7 = var2.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 10.000000000000002d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 100.00000000000004d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test429"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-0.0f), 230399);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0f));

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test430"); }


    int var1 = org.apache.commons.math3.util.FastMath.round((-10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-10));

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test431"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("org.apache.commons.math3.exception.OutOfRangeException: 10 out of [1, null] range");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test432"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var3, var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var5);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var0, var5);
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var9.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test433"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.7135399484934067d, 0.7745517090716676d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7135399484934067d);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test434"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    var2.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var12.setExpansionMode(0);
    double[] var15 = var12.getInternalValues();
    var12.clear();
    double var18 = var12.addElementRolling(0.7853981633974483d);
    var12.addElement(0.0d);
    var12.setNumElements(100);
    boolean var23 = var2.equals((java.lang.Object)var12);
    int var24 = var2.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var28 = var27.getNumElements();
    int var29 = var27.start();
    var27.setElement(10, 0.7612753675628248d);
    var27.discardFrontElements(0);
    double[] var35 = var27.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray(var35);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var36);
    var2.setNumElements(1024);
    org.apache.commons.math3.distribution.NormalDistribution var43 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var45 = var43.probability(7.569397550458789d);
    double var46 = var43.getNumericalVariance();
    double[] var48 = var43.sample(100);
    var2.addElements(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test435"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 1.553344806071505d, 1.1137898361311693d);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test436"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9895469697130671d);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test437"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.2646959702629905d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test438"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(2996224);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test439"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.5063656411097587d), 0.8414709848078965d, 1.9127083523155106d, 23962592);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test440"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    var2.contract();
    var2.setExpansionMode(0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var2.copy();
    var13.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var13.getElement((-5));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test441"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(3.0040502221845453d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9243826401788826d);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test442"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(10676, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test443"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(3.8146977E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.814698E-6f);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test444"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(5.99074437799629E40d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.912853575451785E13d);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test445"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)2.7270454965758133d);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test446"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    var3.reseedRandomGenerator(0L);
    boolean var8 = var3.isSupportLowerBoundInclusive();
    double var10 = var3.cumulativeProbability(2.2683541557421067d);
    double var11 = var3.getMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var3.inverseCumulativeProbability((-0.03201769847914048d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.24191996538778948d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.8720980175938546d);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test447"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.28164875432624675d, (java.lang.Number)(-0.9603035914737312d), true);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test448"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(12.80182748008147d, 1.8265526884970353d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 12.801827480081469d);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test449"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.24434410597703027d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.323953088522587d);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test450"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(7053352210166488382L, 7053352210170117172L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test451"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(299417600, 11700);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test452"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(1.6928130654585166E12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test453"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.1200287568955276d, 1.5143161609730186E-4d, 2.302585092994046d);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test454"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var2.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test455"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos((-1.1022542569867815d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test456"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(short)100, (java.lang.Number)1.0648164703369514d, true);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test457"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var10 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var8, var10);
    java.lang.Throwable[] var12 = var11.getSuppressed();
    boolean var13 = var7.equals((java.lang.Object)var12);
    var7.addElement(1.4214549026638725d);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var21 = new double[] { 100.0d, 1.0d};
    var18.addElements(var21);
    var18.addElement(0.8414709848078965d);
    boolean var25 = var7.equals((java.lang.Object)var18);
    double[] var26 = var7.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setContractionCriteria((-1.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test458"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(90L, (-7053352210170117162L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7053352210170117162L));

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test459"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    var2.setNumElements(1);
    int var10 = var2.getNumElements();
    float var11 = var2.getExpansionFactor();
    var2.setNumElements(91);
    double[] var14 = var2.getInternalValues();
    double var16 = var2.substituteMostRecentElement(9.384006317093086E134d);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = var2.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setExpansionFactor((-0.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test460"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(2.2239078017965097d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6076604670915139d));

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test461"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getNumericalVariance();
    double var7 = var3.getNumericalMean();
    var3.reseedRandomGenerator(10L);
    double var10 = var3.getSupportUpperBound();
    double var11 = var3.getMean();
    double var12 = var3.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == Double.NEGATIVE_INFINITY);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test462"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-11891), (-41));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 487531);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test463"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-9L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test464"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    float var7 = var2.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardFrontElements(273111867);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100.0f);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test465"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-790794752), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test466"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(208.783820926016d, (-0.07655602848313875d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5711630028367114d);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test467"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.5688379597558102d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.19557808901836876d);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test468"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var7 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.2544789518188435d, (java.lang.Number)0.9168407258198261d, true);
    java.lang.Throwable[] var8 = var7.getSuppressed();
    java.lang.Throwable[] var9 = var7.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var3, (java.lang.Object[])var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test469"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(3628799L, 1688143320063612998L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test470"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-18), 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1349403648);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test471"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.2627647399175563E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0001262844472012d);

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test472"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.014003079394530937d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test473"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.6136426314409833d, 2.234177428856803d, 0.8085085755675573d);
    double var4 = var3.getMean();
    double var6 = var3.density(0.5105154539695673d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.6136426314409833d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.15807168569791985d);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test474"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(2.47588E29f, (-0.0012207031f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.47588E29f));

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test475"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.8238753788547079d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.751203422575224d);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test476"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    java.lang.Number var2 = var1.getMax();
    java.lang.Throwable[] var3 = var1.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + (-1)+ "'", var2.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test477"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(900, 1897678595);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test478"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    double[] var8 = var7.getInternalValues();
    var7.addElement(1.5692474232144973d);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test479"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.49027106946002635d);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test480"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.007409736020362853d), (java.lang.Number)3.175810808968181d, false);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test481"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-0.5545968900472659d), 0.9997833820018625d, 0.6506783754890694d);
    var3.reseedRandomGenerator((-5365208890106504175L));
    boolean var6 = var3.isSupportLowerBoundInclusive();
    double var8 = var3.density(1.9233934357131335d);
    double var10 = var3.cumulativeProbability(0.31161695384777244d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.01849471098810033d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.8068649952182254d);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test482"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(1.5716379848552513d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.543012209014963d);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test483"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.addElement(0.8414709848078965d);
    double[] var9 = var2.getInternalValues();
    var2.addElement(7.10807918087573d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test484"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh((-0.6566195865042359d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7868477507841883d));

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test485"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var2.substituteMostRecentElement((-0.03201769847914048d));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test486"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1.0d), (java.lang.Number)(short)0, true);
    java.lang.String var4 = var3.toString();
    java.lang.Number var5 = var3.getMax();
    boolean var6 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: -1 is larger than the maximum (0)"+ "'", var4.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: -1 is larger than the maximum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)0+ "'", var5.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test487"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.discardFrontElements(0);
    var2.addElement(0.8085085755675573d);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = var2.copy();
    var2.setNumElements(230382);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardFrontElements((-273111867));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test488"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.41324411876669853d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.41324411876669853d);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test489"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(12715, 100.5f, 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test490"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var2 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)5.889694544886073d, var2, true);
//     java.lang.Throwable[] var5 = var4.getSuppressed();
//     java.lang.Number var6 = var4.getMax();
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var13 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var9, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
//     java.lang.Throwable[] var14 = var13.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var8, (java.lang.Object[])var14);
//     org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var7, (java.lang.Object[])var14);
// 
//   }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest16.test491"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.013046901568216447d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test492"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.941575758241476d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test493"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.004241254589664838d, 0.41324411876669853d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.010262954723509616d);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test494"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.761594154620033d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 43.63613076156174d);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test495"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(50.0f, (-2996224));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test496"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-0.30312444178518694d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test497"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    var3.reseedRandomGenerator(0L);
    double var8 = var3.getNumericalVariance();
    boolean var9 = var3.isSupportUpperBoundInclusive();
    double var11 = var3.inverseCumulativeProbability(8.639495877295877E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-0.9255410431428124d));

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test498"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-1.0648164703369514d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.8047526389778585d));

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test499"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(2.9784814163978397d, 0.1241950607613301d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5291230241796157d);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest16.test500"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(1.5607966601082315d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0149280275816275d);

  }

}
