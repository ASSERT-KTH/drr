
import junit.framework.*;

public class RandoopTest11 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test1"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     var0.reSeed();
//     double var15 = var0.nextChiSquare(7.617953921806563d);
//     double var17 = var0.nextExponential(1.5574077246549007d);
//     double var19 = var0.nextChiSquare(0.16043285994536435d);
//     double var23 = var0.nextUniform(0.0d, 1865.0d, true);
//     var0.reSeed(17L);
//     double var28 = var0.nextUniform((-0.9653328597795057d), 0.7658486382813623d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var31 = var0.nextLong(40486L, 64L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.094317607200036d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "417272ddde"+ "'", var8.equals("417272ddde"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 6.626684582890629d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.09142084636132654d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.06417810658867298d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 684.4332801675258d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.3213645012503581d);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test2"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var9);
    boolean var12 = var8.equals((java.lang.Object)0.00333969801975283d);
    java.lang.String var13 = var8.name();
    java.lang.Class var14 = var8.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var20 = var19.getTiesStrategy();
    java.lang.Class var21 = var20.getDeclaringClass();
    java.lang.Class var22 = var20.getDeclaringClass();
    boolean var24 = var20.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.NaNStrategy var26 = var25.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var28 = var27.getTiesStrategy();
    java.lang.Class var29 = var28.getDeclaringClass();
    java.lang.String var30 = var28.toString();
    java.lang.String var31 = var28.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26, var28);
    boolean var33 = var17.equals((java.lang.Object)var28);
    org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var17);
    java.lang.String var35 = var17.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "MAXIMAL"+ "'", var13.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "AVERAGE"+ "'", var30.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "AVERAGE"+ "'", var31.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "AVERAGE"+ "'", var35.equals("AVERAGE"));

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test3"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.05086895485414943d, 35.32464985780923d, 3.7146470215815217d, 11395);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 7.878714396539011E-19d);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test4"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(1.1586204758992398d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.898690234147786d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test5"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-2.971892672230254d), var2, true);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test6"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.3989108589797407d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 22.8559086214775d);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test7"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    double[] var6 = var4.getInternalValues();
    org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var8 = var7.getStandardDeviation();
    double[] var10 = var7.sample(1);
    double var11 = var7.getMean();
    double[] var13 = var7.sample(100);
    var4.addElements(var13);
    var4.contract();
    var4.addElement((-1.2596788451662277d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setExpansionMode(11274);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test8"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, 0.5922600267763498d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test9"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    java.lang.Class var6 = var4.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    java.lang.String var8 = var4.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    java.lang.Class var10 = var2.getDeclaringClass();
    java.lang.String var11 = var2.name();
    java.lang.String var12 = var2.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "MAXIMAL"+ "'", var11.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "MAXIMAL"+ "'", var12.equals("MAXIMAL"));

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test10"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test11"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(720, 54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 720);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test12"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(0.9988643597842668d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.565706277266159E-4d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test13"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double[] var3 = var0.sample(10);
    double var4 = var0.getStandardDeviation();
    double var5 = var0.getMean();
    double var7 = var0.cumulativeProbability(57.29288593298371d);
    double var9 = var0.cumulativeProbability((-1.1622852906955334d));
    boolean var10 = var0.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.12255979974565301d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test14"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.8273572477024794d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7538884308317171d);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test15"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(20355937, 268435456);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test16"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(9181, 2.0f, 100.00002f, 791);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test17"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.3552527E-20f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3552529E-20f);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test18"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("5cf444c9b0");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test19"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(40422L, 179L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test20"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.08172139984932196d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.08172139984932197d);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test21"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(4.8086879523173485d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9953668361304775d));

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test22"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    int var8 = var4.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test23"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)25.472636453138065d, (java.lang.Number)(-1.111833199414654d), true);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test24"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     double var9 = var0.nextF(2.281783181607902d, 0.8427007929497151d);
//     long var12 = var0.nextLong(4L, 100L);
//     long var14 = var0.nextPoisson(0.8998293095978018d);
//     java.util.Collection var15 = null;
//     java.lang.Object[] var17 = var0.nextSample(var15, 298);
// 
//   }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test25"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     double var9 = var0.nextUniform(0.0d, 0.5382762305934016d);
//     double var12 = var0.nextGaussian(0.16477040754512196d, 0.9999996994297856d);
//     double var15 = var0.nextCauchy(1.6740869895151453d, 11.386092109717717d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.40063221646369224d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.5163701025781758d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1.2248441424316712d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1.2101702631958333d));
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test26"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(7.6293945E-6f, 0.3803003134220995d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.629395E-6f);

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test27"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     float var7 = var4.getContractionCriteria();
//     double var9 = var4.substituteMostRecentElement((-0.30400114025876435d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.19246137539925623d);
// 
//   }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test28"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     var0.reSeed();
//     double var15 = var0.nextChiSquare(7.617953921806563d);
//     double var17 = var0.nextExponential(1.5574077246549007d);
//     double var19 = var0.nextChiSquare(0.16043285994536435d);
//     double var23 = var0.nextUniform(0.0d, 1865.0d, true);
//     var0.reSeed(17L);
//     double var28 = var0.nextUniform((-0.9653328597795057d), 0.7658486382813623d);
//     double var31 = var0.nextCauchy(9.189990564561439E-4d, 4.810477380965351d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.0450833597383196d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f1f5258680"+ "'", var8.equals("f1f5258680"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 8.118849901868726d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.550586366473563d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.3727595085393345E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 48.419498886178765d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.3213645012503581d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 6.1235043839161944d);
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test29"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    java.lang.Class var6 = var4.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    java.lang.String var8 = var4.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    java.lang.String var10 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var11.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var15, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14, var17);
    java.lang.String var20 = var17.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var13, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var23 = var22.getTiesStrategy();
    java.lang.Class var24 = var23.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23);
    java.lang.String var26 = var23.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var27 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var13, var23);
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var23);
    org.apache.commons.math3.stat.ranking.NaNStrategy var30 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var31 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var33 = var32.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var34 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var31, var33);
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30, var33);
    java.lang.String var36 = var33.name();
    java.lang.Class var37 = var33.getDeclaringClass();
    java.lang.Class var38 = var33.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "MAXIMAL"+ "'", var10.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "AVERAGE"+ "'", var26.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + "AVERAGE"+ "'", var36.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test30"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.12636896871601633d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.240408568848469d);

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test31"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var4.addElement((-0.43408597923864894d));
//     double var10 = var4.getElement(0);
//     double[] var11 = var4.getElements();
//     var4.addElement(21.0d);
//     var4.setNumElements(3);
//     org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var17 = var16.getStandardDeviation();
//     double[] var19 = var16.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
//     var20.contract();
//     int var22 = var20.getNumElements();
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var20);
//     org.apache.commons.math3.util.ResizableDoubleArray var24 = var4.copy();
//     org.apache.commons.math3.util.ResizableDoubleArray var25 = var4.copy();
//     org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     double var28 = var26.addElementRolling(3.1173466159040992d);
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var26);
//     int var30 = var4.getNumElements();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.03563292839443829d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 3);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test32"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.872415613239279d);

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test33"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var21 = var18.nextSecureLong((-1L), 1L);
//     double var24 = var18.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var26 = var18.nextSecureHexString(100);
//     double var28 = var18.nextT(20.696514663540924d);
//     org.apache.commons.math3.distribution.NormalDistribution var29 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var30 = var29.getStandardDeviation();
//     double[] var32 = var29.sample(1);
//     double var33 = var29.getMean();
//     double[] var35 = var29.sample(100);
//     double var36 = var29.sample();
//     double var37 = var29.sample();
//     double var38 = var18.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     double var39 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     org.apache.commons.math3.distribution.NormalDistribution var40 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var41 = var40.getStandardDeviation();
//     double[] var43 = var40.sample(1);
//     double var44 = var40.getMean();
//     double[] var46 = var40.sample(100);
//     double var47 = var40.sample();
//     double var48 = var40.sample();
//     var40.reseedRandomGenerator(10L);
//     boolean var51 = var40.isSupportLowerBoundInclusive();
//     boolean var52 = var40.isSupportLowerBoundInclusive();
//     double var53 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var40);
//     double var55 = var40.density((-13.47212398709439d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.917896503556552d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "56141ed51338a5fd8facfd9c6495b8872b5f1c6cd7b6becadc9fd9fa4c1c3347b0b77ae2b1f4fd8dfb58b71dac60d5535fb4"+ "'", var8.equals("56141ed51338a5fd8facfd9c6495b8872b5f1c6cd7b6becadc9fd9fa4c1c3347b0b77ae2b1f4fd8dfb58b71dac60d5535fb4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.1288636602752493d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 9.058105870276405d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "a936c97c657226469c9313f541fb56fe5a166e190a01d58ad6d10677dafeb5fb936f30197eb5749e31c9f180a9aa65748d4e"+ "'", var26.equals("a936c97c657226469c9313f541fb56fe5a166e190a01d58ad6d10677dafeb5fb936f30197eb5749e31c9f180a9aa65748d4e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.8578747349743394d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0.5439019501969792d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1.1147483453311169d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == (-0.5485388777496082d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0.5489943340020218d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0.31907768600012554d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 0.8470213206491086d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 0.01662526685535688d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 1.5455855336520286E-40d);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test34"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(2.5549845201743038d, 62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1782786388986245E19d);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test35"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.999983988148989d, 430.99373934703704d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test36"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    int var7 = var6.start();
    double[] var8 = var6.getElements();
    float var9 = var6.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.5f);

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test37"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var21 = var18.nextSecureLong((-1L), 1L);
//     double var24 = var18.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var26 = var18.nextSecureHexString(100);
//     double var28 = var18.nextT(20.696514663540924d);
//     org.apache.commons.math3.distribution.NormalDistribution var29 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var30 = var29.getStandardDeviation();
//     double[] var32 = var29.sample(1);
//     double var33 = var29.getMean();
//     double[] var35 = var29.sample(100);
//     double var36 = var29.sample();
//     double var37 = var29.sample();
//     double var38 = var18.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     double var39 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     org.apache.commons.math3.distribution.NormalDistribution var40 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var41 = var40.getStandardDeviation();
//     double[] var43 = var40.sample(1);
//     double var45 = var40.cumulativeProbability(0.0d);
//     double var46 = var40.getSupportUpperBound();
//     boolean var47 = var40.isSupportUpperBoundInclusive();
//     var40.reseedRandomGenerator((-16L));
//     double var51 = var40.cumulativeProbability(0.0d);
//     double var52 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var40);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var56 = var0.nextHypergeometric(1954, 9194402, 19382);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.3741030973300625d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5ca699ea0de96cda81d11f77965d1239f03843c86254d4d85534defd950de4488fcb4b207dfd1a69c5d7b121d25d9d783c28"+ "'", var8.equals("5ca699ea0de96cda81d11f77965d1239f03843c86254d4d85534defd950de4488fcb4b207dfd1a69c5d7b121d25d9d783c28"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.03340850644404031d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.2113472256406719d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "c21d56652cc95eb485d5034c1075be4de5fe47e91bad5ee02112b87ca2c0ea6a90870e7a9c5aab5aad7cc7cce85fc11e4d2b"+ "'", var26.equals("c21d56652cc95eb485d5034c1075be4de5fe47e91bad5ee02112b87ca2c0ea6a90870e7a9c5aab5aad7cc7cce85fc11e4d2b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-0.9685217984589238d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0.18774325240658843d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == (-0.6981272794253387d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0.9699983566886573d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0.7662222727918642d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == (-1.8550546555767224d));
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test38"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    java.lang.Class var6 = var5.getDeclaringClass();
    int var7 = var5.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var5);
    org.apache.commons.math3.random.RandomGenerator var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var9);
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    java.lang.String var14 = var3.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    java.lang.Class var17 = var16.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    java.lang.String var19 = var16.toString();
    java.lang.String var20 = var16.name();
    java.lang.String var21 = var16.name();
    int var22 = var16.ordinal();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var3, var16);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var24 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "MAXIMAL"+ "'", var14.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "AVERAGE"+ "'", var21.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 3);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test39"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.13831284205576994d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.13920510154051363d);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test40"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-536829416L), 594L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test41"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var11 = var9.sample();
//     double[] var13 = var9.sample(243);
//     double var16 = var9.cumulativeProbability(0.56089788532758d, 1.7059487146473076d);
//     double var17 = var9.getSupportUpperBound();
//     double var18 = var9.getStandardDeviation();
//     double var20 = var9.probability(2.281783181607902d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.281094262563496d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "897a1b8a95"+ "'", var8.equals("897a1b8a95"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.6024250155838535d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.7539476341588086d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.24342476154268322d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.0d);
// 
//   }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test42"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     var4.contract();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     float var7 = var4.getContractionCriteria();
//     var4.clear();
//     org.apache.commons.math3.util.ResizableDoubleArray var9 = var4.copy();
//     int var10 = var4.getExpansionMode();
//     int var11 = var4.start();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var12.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
//     java.lang.Class var17 = var16.getDeclaringClass();
//     java.lang.Class var18 = var16.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
//     java.lang.String var20 = var16.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var14, var16);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var26 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(var26);
//     org.apache.commons.math3.distribution.NormalDistribution var28 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var29 = var28.getSupportUpperBound();
//     double[] var31 = var28.sample(10);
//     double var32 = var22.mannWhitneyU(var26, var31);
//     org.apache.commons.math3.distribution.NormalDistribution var33 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var34 = var33.getSupportUpperBound();
//     double[] var36 = var33.sample(10);
//     double var37 = var33.getStandardDeviation();
//     double var39 = var33.density(2.345330933436551d);
//     double[] var41 = var33.sample(180);
//     double var42 = var21.mannWhitneyU(var26, var41);
//     org.apache.commons.math3.distribution.NormalDistribution var43 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var44 = var43.getStandardDeviation();
//     double[] var46 = var43.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var47 = new org.apache.commons.math3.util.ResizableDoubleArray(var46);
//     int var48 = var47.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var49 = var47.copy();
//     var47.addElement((-0.43408597923864894d));
//     double var53 = var47.getElement(0);
//     double[] var54 = var47.getElements();
//     org.apache.commons.math3.random.RandomDataImpl var55 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var58 = var55.nextSecureLong((-1L), 1L);
//     double var61 = var55.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var63 = var55.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var64 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var65 = var55.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var64);
//     double var66 = var64.sample();
//     double var68 = var64.probability(7.444490968701611d);
//     double var69 = var64.getSupportUpperBound();
//     double[] var71 = var64.sample(9694);
//     double var72 = var21.mannWhitneyUTest(var54, var71);
//     org.apache.commons.math3.util.ResizableDoubleArray var73 = new org.apache.commons.math3.util.ResizableDoubleArray(var71);
//     var4.addElements(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 27.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0.025496167636629936d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 450.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == (-0.962346968895135d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 2.820002142356389d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var63 + "' != '" + "47ca269683"+ "'", var63.equals("47ca269683"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == (-0.9214996068046505d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == (-0.37489996184194724d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 0.22332504459894875d);
// 
//   }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test43"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getSupportUpperBound();
//     double[] var3 = var0.sample(10);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     double var6 = var4.addElementRolling(0.15264401491200186d);
//     float var7 = var4.getContractionCriteria();
//     float var8 = var4.getExpansionFactor();
//     org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
//     int var10 = var9.getNumElements();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.4031305227909867d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 10);
// 
//   }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test44"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextGaussian((-0.22984051317348442d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.8563574047751015d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "459e19a33a"+ "'", var8.equals("459e19a33a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4L);
// 
//   }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test45"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var7 = var0.nextUniform(1.179103839756096d, 22.877003894887903d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextSecureInt(51, (-1023));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 12.044105912017727d);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test46"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    double[] var6 = var4.getInternalValues();
    org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var8 = var7.getStandardDeviation();
    double[] var10 = var7.sample(1);
    double var11 = var7.getMean();
    double[] var13 = var7.sample(100);
    var4.addElements(var13);
    int var15 = var4.getExpansionMode();
    int var16 = var4.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 101);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test47"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1877, (-22));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test48"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.7538884308317171d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.684478721264117d);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test49"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow((-0.41023049431530567d), 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.41023049431530567d));

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test50"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(0L);
//     long var17 = var0.nextPoisson(7.769493748166378d);
//     double var19 = var0.nextExponential(8.563154148722202d);
//     double var22 = var0.nextWeibull(10.132200867889637d, 2.717220411501478d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var0.nextWeibull(0.06132899223029181d, (-0.5201403636856712d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.6625500301104962d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "809f3c7582"+ "'", var8.equals("809f3c7582"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.301940789184799d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 8462);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.5675928041183713d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 2.547259247785248d);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test51"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0111995598490069d, 1.3783576819621723d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.011199559849006903d);

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test52"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     var0.reSeedSecure();
//     int var10 = var0.nextBinomial(243, 0.745691842295965d);
//     long var13 = var0.nextSecureLong((-249L), 40320L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.12654575466583523d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 175);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 13498L);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test53"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1925, 33);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test54"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     int var11 = var0.nextZipf(5, 0.8273572477024794d);
//     double var14 = var0.nextGamma((-1.9235391122654637d), 6.774605976508678d);
//     var0.reSeedSecure(104L);
//     double var18 = var0.nextT(1.8631214203808169d);
//     double var21 = var0.nextGamma(0.6098400998484748d, 0.36944668344557197d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.278526390213065d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1dc453821230d0751f3c06ec86bd0cf3fea7ba59ab410cb87bde3fd5792306e25c85591b319140f4695ed14aa6c1adb12a23"+ "'", var8.equals("1dc453821230d0751f3c06ec86bd0cf3fea7ba59ab410cb87bde3fd5792306e25c85591b319140f4695ed14aa6c1adb12a23"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 16.031976222022013d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.30770609449771485d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.10414835139794379d);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test55"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(25.73689552674863d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 26.0d);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test56"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(Float.POSITIVE_INFINITY, 1073741698);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test57"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var13 = var10.nextSecureLong((-1L), 1L);
//     double var16 = var10.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var18 = var10.nextHexString(10);
//     int var21 = var10.nextPascal(8899, 0.8219866295031046d);
//     double var23 = var10.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var25 = var24.getStandardDeviation();
//     double[] var27 = var24.sample(1);
//     double var28 = var24.getMean();
//     double[] var30 = var24.sample(100);
//     double var31 = var24.sample();
//     double var32 = var24.sample();
//     double var33 = var24.getStandardDeviation();
//     double var34 = var24.sample();
//     double var35 = var10.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     double var36 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     org.apache.commons.math3.distribution.NormalDistribution var37 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var38 = var37.getStandardDeviation();
//     boolean var39 = var37.isSupportUpperBoundInclusive();
//     double[] var41 = var37.sample(100);
//     double var42 = var37.getNumericalVariance();
//     double var43 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var37);
//     double var46 = var0.nextCauchy(12.033846781268247d, 0.18568215771673818d);
//     double var49 = var0.nextGamma(0.1741724548940188d, 0.24197688819531704d);
//     long var52 = var0.nextSecureLong((-1342158336L), 1342198656L);
//     var0.reSeed(0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.933082063970592d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "98874477500c874b3b6158f89a5fe58dae7589d2b60f4ef35738fbbf73e232259f646856a6cd4c4d8722c6727374a4d83a9c"+ "'", var8.equals("98874477500c874b3b6158f89a5fe58dae7589d2b60f4ef35738fbbf73e232259f646856a6cd4c4d8722c6727374a4d83a9c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 17.633820779550263d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "4f465eef2d"+ "'", var18.equals("4f465eef2d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 2034);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.008118545642543286d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == (-0.8411830066015837d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == (-0.727701987344361d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0.6153181627590527d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == (-0.14008150245602932d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == (-0.7171290581323617d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1.5266197289708832d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 13.680225110928982d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 2.137813557490562E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 843753744L);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test58"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(17019, (-1953380655));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test59"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    var4.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var4.copy();
    int var10 = var4.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    var4.addElement(0.7827990487784351d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var4.getElement(5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test60"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.013292325585375278d, 3.226035018935781E-14d, (-1.0712332264705697d), 6593);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test61"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var13 = var0.nextT(5.867156662812015d);
//     double var15 = var0.nextExponential(11.771947930619202d);
//     int var18 = var0.nextBinomial(0, 0.0031612049524534893d);
//     var0.reSeedSecure(2184L);
//     long var23 = var0.nextLong(0L, 163572604512568L);
//     double var26 = var0.nextWeibull(0.22545200221767242d, 0.15512025679417774d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.077046353945397d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d826ca5269"+ "'", var8.equals("d826ca5269"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.7444485469767459d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 4.494295914262084d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 148291518349835L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.44356779411166875d);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test62"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.09005552372767583d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.4073288685676326d));

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test63"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-0.6571109359893885d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5764375405501602d));

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test64"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double[] var6 = var0.sample(100);
//     double var7 = var0.sample();
//     double var8 = var0.sample();
//     double var10 = var0.probability((-0.3722334692039834d));
//     double[] var12 = var0.sample(8);
//     boolean var13 = var0.isSupportLowerBoundInclusive();
//     double var14 = var0.getNumericalVariance();
//     boolean var15 = var0.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1.7834717159646098d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.3805996417796336d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test65"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.0031612049524534893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0031612154826976767d);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test66"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.47492043376621246d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test67"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-926.5278916735626d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-927.0d));

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test68"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(2.281783181607902d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2L);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test69"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.013321096441330034d, (java.lang.Number)(-0.04318977868047519d), true);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test70"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    java.lang.Class var4 = var3.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test71"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     var0.reSeed(100L);
//     org.apache.commons.math3.distribution.NormalDistribution var34 = new org.apache.commons.math3.distribution.NormalDistribution((-4.440892098500626E-16d), 1.1102230246251565E-16d, 0.9999494957997512d);
//     double var35 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var34);
//     double var36 = var34.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.103698838608336d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "9d296c96c0"+ "'", var8.equals("9d296c96c0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1974);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.005312141542036497d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1.3118002662492707d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-1.5738936453407835d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-2.324722804423043d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.054533041047451d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 709.7217733221731d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == (-5.315982015318238E-16d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == (-3.718738746816663E-16d));
// 
//   }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test72"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(short)1, var3, false);
    java.lang.Number var6 = var5.getMax();
    boolean var7 = var5.getBoundIsAllowed();
    java.lang.Throwable[] var8 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test73"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(177L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test74"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.5634084277386435d, (java.lang.Number)0.9999999173973604d, (java.lang.Number)0.05391151653190502d);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test75"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    var0.reseedRandomGenerator(2L);
    boolean var3 = var0.isSupportConnected();
    double var4 = var0.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test76"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(8.125467547535871d);
//     var0.reSeed(8106L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextExponential((-0.5574992050354581d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 23.743416738317624d);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test77"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    java.lang.Class var6 = var4.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    java.lang.String var8 = var4.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    java.lang.String var10 = var2.name();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    java.lang.Class var16 = var14.getDeclaringClass();
    boolean var18 = var14.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
    java.lang.Class var23 = var22.getDeclaringClass();
    java.lang.String var24 = var22.toString();
    java.lang.String var25 = var22.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var22);
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var22);
    int var28 = var2.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "MAXIMAL"+ "'", var10.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "AVERAGE"+ "'", var24.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "AVERAGE"+ "'", var25.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test78"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 243);
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, var14);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 11L);
    java.math.BigInteger var18 = null;
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 0L);
    java.math.BigInteger var21 = null;
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 0L);
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, var23);
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 1949);
    java.math.BigInteger var27 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, var26);
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 11L);
    java.math.BigInteger var31 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 1L);
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, var17);
    java.math.BigInteger var34 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 14L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var36 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, (-981430172L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test79"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     var0.reSeed();
//     double var15 = var0.nextChiSquare(7.617953921806563d);
//     double var17 = var0.nextExponential(1.5574077246549007d);
//     org.apache.commons.math3.distribution.NormalDistribution var21 = new org.apache.commons.math3.distribution.NormalDistribution(0.8259324122591327d, 0.2782029380240531d, 0.0d);
//     double var22 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var21);
//     double var24 = var0.nextT(0.2160727732320313d);
//     int var27 = var0.nextSecureInt((-32263797), 5950);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15.640198547685896d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "40ff20cad4"+ "'", var8.equals("40ff20cad4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 3.9634031922866013d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.1340264910713456d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.6622353137449954d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-3.0289372995240984d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == (-27541524));
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test80"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1953, 1962);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1962);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test81"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    java.lang.Class var6 = var4.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    java.lang.String var8 = var4.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    int var10 = var2.ordinal();
    java.lang.String var11 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "MAXIMAL"+ "'", var11.equals("MAXIMAL"));

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test82"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
//     java.lang.Class var5 = var4.getDeclaringClass();
//     int var6 = var4.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
//     org.apache.commons.math3.random.RandomGenerator var8 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
//     org.apache.commons.math3.random.RandomGenerator var10 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
//     java.lang.Class var15 = var14.getDeclaringClass();
//     java.lang.Class var16 = var14.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var14);
//     org.apache.commons.math3.random.RandomGenerator var18 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var18);
//     org.apache.commons.math3.distribution.NormalDistribution var20 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var21 = var20.getStandardDeviation();
//     double[] var23 = var20.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(var23);
//     var24.setElement(11, 0.5322866968936354d);
//     double var29 = var24.addElementRolling(1.5498468927479463d);
//     float var30 = var24.getExpansionFactor();
//     org.apache.commons.math3.util.ResizableDoubleArray var33 = new org.apache.commons.math3.util.ResizableDoubleArray(1919, 100.00001f);
//     org.apache.commons.math3.util.ResizableDoubleArray var34 = new org.apache.commons.math3.util.ResizableDoubleArray(var33);
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var24, var33);
//     boolean var36 = var2.equals((java.lang.Object)var33);
//     int var37 = var33.getNumElements();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == (-0.5638602152992479d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 12);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test83"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos((-2.4631199234029544d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 116.63336600886188d);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test84"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     var0.reSeed(14L);
//     double var14 = var0.nextExponential(0.9999997887160175d);
//     double var17 = var0.nextBeta(4.0434293412271454E-4d, 0.17971249487899976d);
//     var0.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var22 = var0.nextPermutation(1960, 2147483647);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.998642129937128d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "7ec7c03c0d"+ "'", var8.equals("7ec7c03c0d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.3057986766220219d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.3844973909690124d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test85"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.5163754206631227d, (-0.3964146282939824d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.5163754206631227d));

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test86"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     double var9 = var0.nextGamma(9.319248049587957d, (-0.4255538433808183d));
//     long var11 = var0.nextPoisson(0.9978516012375751d);
//     int var14 = var0.nextZipf(8941, 1.445343853698748d);
//     java.lang.String var16 = var0.nextHexString(3826);
//     double var19 = var0.nextGaussian(1.383036361567265d, 18.853048230723537d);
//     var0.reSeed();
//     long var22 = var0.nextPoisson(0.8019555344046855d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.5456838614769273d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-4.391156553459099d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "b272f4f2cb37f265739a4406e3a25f1ffa8dde66e488087d9c7c220b8f9d8f05ffb5ae7514183cfe0b1227acda71602a32ea0a7f3a07de0d34f92d3974eb6e75173e32c5bedbdb3d4b8f7aca5fc290666510dcaab7b2a142f3fc575d76b96cc2fea40bab186045de2d24da913cd07cd39f3ae0a5281d1de821cf23266c9272f4299b9656884a0bd468a2be3f65afe920075e6579a38ea24fbb8fe4d644319b4b31a103355a915bfb47360e32294a5dbaad4da53ee33cb3c4bdaa3b6d74fcc784f026b0ae0f20a6483d3894286d3e4e93cd19034f688c86d16726d45b5a8d1ac345c9afc127d1414d08e8c7a5069a8ecb403c093c657a2954317f1505ad6d4dc1daf5927d0ac32ccdb3f749fd28147681334abf92f26e133f6ba5d33a0c54d879d608274d48e1fb3be2bbcae77b0411aafaccfa7300d4131805c9e3d91bbd47a07e77bcc78a5c286597f745903d3874d13975a4ea5bf644fc52c93e6ed12456ccc384aa9235e23ccbb194e3fd26fb4f00f2c90e2b6d497b32655e436ba901e4ea1a014cac925319db2f60b0819745f391e2a1e414d1ebff8b49e69dfc258c796b151ea6dd7dcf77f500e3f87bf64014a99b38eb34a4f108c5b96c02f117cb83a139d21514f0a937430affa00f504c67413e468c8291a3ba3b46d9f552264f36e87088305246ca9c447ba10e43affd1638f43529d2d4a22a6948be8524772b2a9aa439b2133230856f08479fd0721321073a7ed5b16b2e07c49ad8204bf5e710747ec21685b2da366554903eb8156dd9542367dc267e70f62d77fd30f5463223ca1b24030297643e2dba3649157cc625509efea63d92b93b209d7e4aaeab54cd2282cf651f424093d7bd015a285cbebc1c67b757b5be8796fa4c70b7cde63666bd87a1b2f05872589b30f740b7a8577476d9022baee93a8945bed73bc33dccf92d0962927631374b5c82b00c2b57800fb178d7256e1aa494d3a343f39b3f5204df9eb22d38f1c9787655b42a9dd7b4e446d843124f1ed5e7d2c015b69e839615d1895a8e8fca47c45077c8d050b6c37151597788df75564a8dee15e60e4f9355893ad6e69874bba69357739719ccdbc0faebcdeca710f3a7b9d822f07cf613db74e22e8d2cdea77688f4603ade7fe6a0c54c0a8e80115045aaf50a7928d5b99de67dae6d9140a80992ab46045deb8062561d7b2c33e5d8cdcf4082a19c2ac1fadcb3489501e5e248dc785bf469e102a42402fa693f9a1a99fadae979a1c87f21770ea970f73f335c883670e9ea9aab289b349ac2f311373a6e1729fe6751ee424dbe44dc83257f1a36047995a9d5cabc2bd8cda8501865a7120466b4ec975dcd745012c451fa349dc71e5089b5f86feef6a3964a90f505eff32dd9f3bfc4ce844022b81bfbb229f5cb41391ca07a0a8db17c16a0ddbc733d416c03dc53ea92d976c5374be8650264beab215ed676b7fe6fa0fb289c0ae7bfea0ac352123751838a9cd5cdf35d841af8118a5caa75e11d7782474d31a03aa1cefb504cc24db3b649c1f719d5c6d48018d5323a1fa8936ebc4aecab5d77b483adabbcdae8a7d2304e79b33e01133e3facec366749b41c9e5edc1d07409db7818f34b6a5041c90863e28777347a3119522fd7eba7e70dd996ce8677eee538f1a80aa69352a91e02119e6ce2e51a49a00a8bed6f0edfad46b3b54d96556e04e365a22c56abdd09146798c76327263e4349109416b9c390e49e14b7a2bbef4bc931461ceb4dd0ebb25c1b093eccc585f6e88e7e33eb710b4c3144f136bf6e31f18863ddcf2ef815ce71644958f2e7e884a6c177c8ef701da68304d52b9ad36ee3047658186322e14d9738c84203bf346c1cac66a91090f9fcbad4c78927a414f4c40c9b99e2e8d69f523d74092bb2c4d7a6e7bf87a21629c522101609db3c7e297c2cb1ae0d03183fede7f0f4c02e6bb15a3daa729681fedd2a15a444f6a5bd8d08f5551df72cb117efa4dee6a5f2f697ed9181ebbe256fffc52527ad59e5f2747523b05d548eb20f667cf0087b525ba34b149870273d93493c3408d85bc1d2ac5d9618e2c330e481e16019c3c55a830d6f6bc0b97b7a63dfc78dabef533e98df36e0ed8b44cecd927b0cc6ec0b4cfa643bcdcd1bc1fe47c98be295b04f6f8f28f1f70294d170555433c365e4028b0944ca91fedd490f4e2b180f61005b693dd9aadd196148cef8870b0afbf5d67c59b2724f44779c9831eca1f6df791c89051ef1c0a6cc7d9f82f1cbcff5315089e499f68d972a4d8393eff79fda2c0650605350466ad56390c53077917c9a8eacfe4408871ddd957f3fbc78b9fdf2bb51ebef81453000bf85f5ab1f4a418b290d875eca19e5cccfffb9ce7858006b8b2d089abfa58fdb28b96b03520c007d2ac7f48f8a8c283953033005f9c438c35aec3f6efa981d420559f88fed5812a50a28d3d64aed86ae5cc4c5267f1bd3fc1582040bb6b39eea846c482ed003c50f3fdd5092c3065420d0d4b84604ecde5475539a7d4e745214faf168d721f59fe82c26d8e5435cdc0133157d780637178ceb4e55388b06e90f3cdf191ae6928d1c5b9bb4e603a3400dfcdfac995bb547dcf04a2889a14333ed1902f7a1270331700ee49b4cf634bb84eff1374c8f89af582fec6b11a6a9fe593405116bd79b43125319e3d12601cfcf7ea54cc6f565189aae18383020395"+ "'", var16.equals("b272f4f2cb37f265739a4406e3a25f1ffa8dde66e488087d9c7c220b8f9d8f05ffb5ae7514183cfe0b1227acda71602a32ea0a7f3a07de0d34f92d3974eb6e75173e32c5bedbdb3d4b8f7aca5fc290666510dcaab7b2a142f3fc575d76b96cc2fea40bab186045de2d24da913cd07cd39f3ae0a5281d1de821cf23266c9272f4299b9656884a0bd468a2be3f65afe920075e6579a38ea24fbb8fe4d644319b4b31a103355a915bfb47360e32294a5dbaad4da53ee33cb3c4bdaa3b6d74fcc784f026b0ae0f20a6483d3894286d3e4e93cd19034f688c86d16726d45b5a8d1ac345c9afc127d1414d08e8c7a5069a8ecb403c093c657a2954317f1505ad6d4dc1daf5927d0ac32ccdb3f749fd28147681334abf92f26e133f6ba5d33a0c54d879d608274d48e1fb3be2bbcae77b0411aafaccfa7300d4131805c9e3d91bbd47a07e77bcc78a5c286597f745903d3874d13975a4ea5bf644fc52c93e6ed12456ccc384aa9235e23ccbb194e3fd26fb4f00f2c90e2b6d497b32655e436ba901e4ea1a014cac925319db2f60b0819745f391e2a1e414d1ebff8b49e69dfc258c796b151ea6dd7dcf77f500e3f87bf64014a99b38eb34a4f108c5b96c02f117cb83a139d21514f0a937430affa00f504c67413e468c8291a3ba3b46d9f552264f36e87088305246ca9c447ba10e43affd1638f43529d2d4a22a6948be8524772b2a9aa439b2133230856f08479fd0721321073a7ed5b16b2e07c49ad8204bf5e710747ec21685b2da366554903eb8156dd9542367dc267e70f62d77fd30f5463223ca1b24030297643e2dba3649157cc625509efea63d92b93b209d7e4aaeab54cd2282cf651f424093d7bd015a285cbebc1c67b757b5be8796fa4c70b7cde63666bd87a1b2f05872589b30f740b7a8577476d9022baee93a8945bed73bc33dccf92d0962927631374b5c82b00c2b57800fb178d7256e1aa494d3a343f39b3f5204df9eb22d38f1c9787655b42a9dd7b4e446d843124f1ed5e7d2c015b69e839615d1895a8e8fca47c45077c8d050b6c37151597788df75564a8dee15e60e4f9355893ad6e69874bba69357739719ccdbc0faebcdeca710f3a7b9d822f07cf613db74e22e8d2cdea77688f4603ade7fe6a0c54c0a8e80115045aaf50a7928d5b99de67dae6d9140a80992ab46045deb8062561d7b2c33e5d8cdcf4082a19c2ac1fadcb3489501e5e248dc785bf469e102a42402fa693f9a1a99fadae979a1c87f21770ea970f73f335c883670e9ea9aab289b349ac2f311373a6e1729fe6751ee424dbe44dc83257f1a36047995a9d5cabc2bd8cda8501865a7120466b4ec975dcd745012c451fa349dc71e5089b5f86feef6a3964a90f505eff32dd9f3bfc4ce844022b81bfbb229f5cb41391ca07a0a8db17c16a0ddbc733d416c03dc53ea92d976c5374be8650264beab215ed676b7fe6fa0fb289c0ae7bfea0ac352123751838a9cd5cdf35d841af8118a5caa75e11d7782474d31a03aa1cefb504cc24db3b649c1f719d5c6d48018d5323a1fa8936ebc4aecab5d77b483adabbcdae8a7d2304e79b33e01133e3facec366749b41c9e5edc1d07409db7818f34b6a5041c90863e28777347a3119522fd7eba7e70dd996ce8677eee538f1a80aa69352a91e02119e6ce2e51a49a00a8bed6f0edfad46b3b54d96556e04e365a22c56abdd09146798c76327263e4349109416b9c390e49e14b7a2bbef4bc931461ceb4dd0ebb25c1b093eccc585f6e88e7e33eb710b4c3144f136bf6e31f18863ddcf2ef815ce71644958f2e7e884a6c177c8ef701da68304d52b9ad36ee3047658186322e14d9738c84203bf346c1cac66a91090f9fcbad4c78927a414f4c40c9b99e2e8d69f523d74092bb2c4d7a6e7bf87a21629c522101609db3c7e297c2cb1ae0d03183fede7f0f4c02e6bb15a3daa729681fedd2a15a444f6a5bd8d08f5551df72cb117efa4dee6a5f2f697ed9181ebbe256fffc52527ad59e5f2747523b05d548eb20f667cf0087b525ba34b149870273d93493c3408d85bc1d2ac5d9618e2c330e481e16019c3c55a830d6f6bc0b97b7a63dfc78dabef533e98df36e0ed8b44cecd927b0cc6ec0b4cfa643bcdcd1bc1fe47c98be295b04f6f8f28f1f70294d170555433c365e4028b0944ca91fedd490f4e2b180f61005b693dd9aadd196148cef8870b0afbf5d67c59b2724f44779c9831eca1f6df791c89051ef1c0a6cc7d9f82f1cbcff5315089e499f68d972a4d8393eff79fda2c0650605350466ad56390c53077917c9a8eacfe4408871ddd957f3fbc78b9fdf2bb51ebef81453000bf85f5ab1f4a418b290d875eca19e5cccfffb9ce7858006b8b2d089abfa58fdb28b96b03520c007d2ac7f48f8a8c283953033005f9c438c35aec3f6efa981d420559f88fed5812a50a28d3d64aed86ae5cc4c5267f1bd3fc1582040bb6b39eea846c482ed003c50f3fdd5092c3065420d0d4b84604ecde5475539a7d4e745214faf168d721f59fe82c26d8e5435cdc0133157d780637178ceb4e55388b06e90f3cdf191ae6928d1c5b9bb4e603a3400dfcdfac995bb547dcf04a2889a14333ed1902f7a1270331700ee49b4cf634bb84eff1374c8f89af582fec6b11a6a9fe593405116bd79b43125319e3d12601cfcf7ea54cc6f565189aae18383020395"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-29.600912288332d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0L);
// 
//   }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test87"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-1.9369499619508226d), (java.lang.Number)0.01329154278510984d, true);
    java.lang.Number var5 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.01329154278510984d+ "'", var5.equals(0.01329154278510984d));

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test88"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var13 = var2.name();
    java.lang.String var14 = var2.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "MAXIMAL"+ "'", var13.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "MAXIMAL"+ "'", var14.equals("MAXIMAL"));

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test89"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var6 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var4, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test90"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Number var4 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var6 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var2, (java.lang.Number)0.777695809106093d, var4, true);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var9.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test91"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double var6 = var0.probability(3.0741607150885346d);
//     double var8 = var0.cumulativeProbability(0.4673794558804901d);
//     double var9 = var0.sample();
//     boolean var10 = var0.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.6798857908360603d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.46328676750483894d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test92"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(326);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardMostRecentElements(1471);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test93"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-1L), (-6266588889437241349L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6266588889437241350L));

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test94"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.math.BigInteger var2 = null;
//     java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
//     java.math.BigInteger var5 = null;
//     java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
//     java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var7);
//     java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 11L);
//     java.math.BigInteger var11 = null;
//     java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0L);
//     java.math.BigInteger var14 = null;
//     java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 0L);
//     java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, var16);
//     java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 1949);
//     java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, var19);
//     java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 8904);
//     org.apache.commons.math3.exception.NumberIsTooLargeException var25 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var1, (java.lang.Number)var10, (java.lang.Number)1.2821293047459659E-78d, true);
//     java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, var10);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test95"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-8904), 180);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 12);

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test96"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     int var20 = var0.nextBinomial(0, 0.7615941559557649d);
//     double var23 = var0.nextF(0.6333241614301578d, 1.0110169304177432d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var27 = var0.nextHypergeometric(1659, 325, 1852);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 66.17449618251631d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "bd9bf9447a1c5ccacb5ca7d0d7b66457afd08e39e1416e9b19db7784f2d368f6f8bccb175383c76d1051f86aa68574826fd5"+ "'", var8.equals("bd9bf9447a1c5ccacb5ca7d0d7b66457afd08e39e1416e9b19db7784f2d368f6f8bccb175383c76d1051f86aa68574826fd5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.09013580357555628d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 83.87640505750623d);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test97"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.3034325216580789d, 3.02042532095127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6678176577221064d);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test98"); }


    int var1 = org.apache.commons.math3.util.FastMath.round((-1.1368684E-13f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test99"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var11 = var9.sample();
//     double[] var13 = var9.sample(243);
//     double var16 = var9.cumulativeProbability(0.56089788532758d, 1.7059487146473076d);
//     double var17 = var9.getSupportUpperBound();
//     double var18 = var9.getStandardDeviation();
//     double[] var20 = var9.sample(3826);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.1034460264026071d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "fb45738409"+ "'", var8.equals("fb45738409"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.7191890192149342d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.4828879179808611d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.24342476154268322d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test100"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var4 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)(-1), (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.OutOfRangeException var11 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.25587682077976953d, (java.lang.Number)14.619556314198402d, (java.lang.Number)2.124989902393144d);
    var7.addSuppressed((java.lang.Throwable)var11);
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var15 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var13, (java.lang.Number)0.815297812486526d);
    var11.addSuppressed((java.lang.Throwable)var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test101"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, (-51.46112688913703d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test102"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 2184L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2184L);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test103"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(7.1054274E-15f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.1054274E-15f);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test104"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
    java.lang.Object var17 = null;
    boolean var18 = var4.equals(var17);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = var4.copy();
    var4.addElement(6.621888603197341d);
    var4.setElement(1848, 0.1708276255239572d);
    float var25 = var4.getExpansionFactor();
    double[] var26 = var4.getInternalValues();
    var4.discardFrontElements(2);
    var4.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var31 = var4.getElement(3226426);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test105"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     double var12 = var0.nextGamma(4.950886585270677E-4d, 1.5703107297735257d);
//     int var15 = var0.nextInt(2, 17018);
//     java.lang.String var17 = var0.nextSecureHexString(37);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var0.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.2838411623133315d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2318);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "8b96bf589221b8f36b46d1a86dfdd7177caf6"+ "'", var17.equals("8b96bf589221b8f36b46d1a86dfdd7177caf6"));
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test106"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    int var6 = var4.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test107"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var4);
    java.lang.String var7 = var4.name();
    java.lang.String var8 = var4.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    java.lang.Class var10 = var4.getDeclaringClass();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var4);
    double[] var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var13.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    java.lang.Class var18 = var17.getDeclaringClass();
    int var19 = var17.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var17);
    org.apache.commons.math3.random.RandomGenerator var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var21);
    org.apache.commons.math3.random.RandomGenerator var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var23);
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var27 = var26.getTiesStrategy();
    java.lang.Class var28 = var27.getDeclaringClass();
    java.lang.Class var29 = var27.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var27);
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var31.contract();
    org.apache.commons.math3.distribution.NormalDistribution var33 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var34 = var33.getStandardDeviation();
    double[] var36 = var33.sample(1);
    double var38 = var33.cumulativeProbability(0.0d);
    double var39 = var33.getSupportUpperBound();
    boolean var40 = var33.isSupportUpperBoundInclusive();
    var33.reseedRandomGenerator((-16L));
    double[] var44 = var33.sample(2297);
    var31.addElements(var44);
    double[] var46 = var30.rank(var44);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var47 = var11.mannWhitneyUTest(var12, var46);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "AVERAGE"+ "'", var7.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test108"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(20355979, 883);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 883);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test109"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.5313014354155909d, (java.lang.Number)2297, false);
    java.lang.Number var4 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 2297+ "'", var4.equals(2297));

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test110"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test111"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double[] var3 = var0.sample(10);
    double var4 = var0.getStandardDeviation();
    double var6 = var0.density(2.345330933436551d);
    double var7 = var0.getSupportLowerBound();
    double var9 = var0.cumulativeProbability(0.5231370181288907d);
    double var10 = var0.getSupportLowerBound();
    boolean var11 = var0.isSupportLowerBoundInclusive();
    double var12 = var0.getSupportUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var0.cumulativeProbability(27.0d, (-0.0171708791073058d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.025496167636629936d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.6995605468138986d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == Double.POSITIVE_INFINITY);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test112"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var2 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1.0395566705196257d);
    java.lang.Throwable[] var3 = var2.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test113"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     int var7 = var6.getNumElements();
//     double var9 = var6.substituteMostRecentElement(31.862892444737472d);
//     org.apache.commons.math3.util.ResizableDoubleArray var10 = var6.copy();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1.1249750441597652d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test114"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.contract();
    int var8 = var6.getExpansionMode();
    var6.setElement(5, 20.696514663540924d);
    var6.setNumElements(1);
    int var14 = var6.getNumElements();
    float var15 = var6.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.0f);

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test115"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var27 = var0.nextT(0.03380985024855201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.686082301750664d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f069b8ad17"+ "'", var8.equals("f069b8ad17"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1925);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.00954066954489731d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 2.520274235984802d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-0.5500169923722096d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.15453694479083274d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-0.9986180723467728d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1.2857745369151655E12d);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test116"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-0.2935911468506942d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.3220049269578837d));

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test117"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 6L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 268435456L);
    java.math.BigInteger var11 = null;
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0L);
    java.math.BigInteger var14 = null;
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 0L);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, var16);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 243);
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, 76L);
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 20355937);
    java.math.BigInteger var24 = null;
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 0L);
    java.math.BigInteger var27 = null;
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var27, 0L);
    java.math.BigInteger var30 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, var29);
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 11L);
    org.apache.commons.math3.exception.util.Localizable var33 = null;
    java.math.BigInteger var36 = null;
    java.math.BigInteger var38 = org.apache.commons.math3.util.ArithmeticUtils.pow(var36, 0L);
    java.math.BigInteger var39 = null;
    java.math.BigInteger var41 = org.apache.commons.math3.util.ArithmeticUtils.pow(var39, 0L);
    java.math.BigInteger var42 = org.apache.commons.math3.util.ArithmeticUtils.pow(var38, var41);
    java.math.BigInteger var44 = org.apache.commons.math3.util.ArithmeticUtils.pow(var38, 6L);
    org.apache.commons.math3.exception.OutOfRangeException var45 = new org.apache.commons.math3.exception.OutOfRangeException(var33, (java.lang.Number)5.363952139253263d, (java.lang.Number)14.087081017797523d, (java.lang.Number)var44);
    java.math.BigInteger var46 = org.apache.commons.math3.util.ArithmeticUtils.pow(var32, var44);
    java.math.BigInteger var48 = org.apache.commons.math3.util.ArithmeticUtils.pow(var32, 1999);
    java.math.BigInteger var49 = null;
    java.math.BigInteger var51 = org.apache.commons.math3.util.ArithmeticUtils.pow(var49, 0L);
    java.math.BigInteger var52 = null;
    java.math.BigInteger var54 = org.apache.commons.math3.util.ArithmeticUtils.pow(var52, 0L);
    java.math.BigInteger var55 = org.apache.commons.math3.util.ArithmeticUtils.pow(var51, var54);
    java.math.BigInteger var57 = org.apache.commons.math3.util.ArithmeticUtils.pow(var51, 11L);
    java.math.BigInteger var58 = null;
    java.math.BigInteger var60 = org.apache.commons.math3.util.ArithmeticUtils.pow(var58, 0L);
    java.math.BigInteger var61 = null;
    java.math.BigInteger var63 = org.apache.commons.math3.util.ArithmeticUtils.pow(var61, 0L);
    java.math.BigInteger var64 = org.apache.commons.math3.util.ArithmeticUtils.pow(var60, var63);
    java.math.BigInteger var66 = org.apache.commons.math3.util.ArithmeticUtils.pow(var64, 1949);
    java.math.BigInteger var67 = org.apache.commons.math3.util.ArithmeticUtils.pow(var57, var66);
    java.math.BigInteger var69 = org.apache.commons.math3.util.ArithmeticUtils.pow(var57, 8904);
    java.math.BigInteger var71 = org.apache.commons.math3.util.ArithmeticUtils.pow(var69, 183L);
    java.math.BigInteger var72 = org.apache.commons.math3.util.ArithmeticUtils.pow(var32, var69);
    java.math.BigInteger var73 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, var32);
    java.math.BigInteger var74 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test118"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 2058820555291694441L);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test119"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(5.2088636151272185d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6503617158760773d);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test120"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(596L, 5862940464091933649L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test121"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.09618471341735572d);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test122"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var11 = var0.nextLong(29L, 40318L);
//     int var14 = var0.nextPascal(1865, 0.001029097815686925d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.3147559298721487d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ae405986f6"+ "'", var8.equals("ae405986f6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 15016L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1842481);
// 
//   }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test123"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(4.5d, 0.017688387388495763d);
//     double var3 = var2.getSupportUpperBound();
//     double var4 = var2.sample();
//     var2.reseedRandomGenerator(1342198656L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4.490563204941112d);
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test124"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(1.1949907117311445d, (-1.9835754660711276d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7023306425333888d);

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test125"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-0.07340078064644198d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test126"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     int var11 = var0.nextZipf(5, 0.8273572477024794d);
//     int var14 = var0.nextBinomial(1972, 0.15795521463156686d);
//     double var17 = var0.nextGaussian(3.4456677746279425d, 3.02837877258525d);
//     double var20 = var0.nextBeta(0.04378400432753371d, 0.08452288246378666d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var23 = var0.nextSecureLong(920L, 56L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 19.25367547578206d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "a5a7c469d62751740faf937622670126ec8d4c7f29c6391618a916a96eecfb4f95677d3a3a4b09b43c27ea10e98e93a7ef56"+ "'", var8.equals("a5a7c469d62751740faf937622670126ec8d4c7f29c6391618a916a96eecfb4f95677d3a3a4b09b43c27ea10e98e93a7ef56"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 324);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.1646327360471425d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 4.7264274651578715E-9d);
// 
//   }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test127"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     java.lang.Class var2 = var1.getDeclaringClass();
//     java.lang.Class var3 = var1.getDeclaringClass();
//     boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var9 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var9);
//     boolean var12 = var8.equals((java.lang.Object)0.00333969801975283d);
//     java.lang.String var13 = var8.name();
//     java.lang.Class var14 = var8.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var17 = var15.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var19 = var18.getTiesStrategy();
//     java.lang.Class var20 = var19.getDeclaringClass();
//     int var21 = var19.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var19);
//     org.apache.commons.math3.random.RandomGenerator var23 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var23);
//     org.apache.commons.math3.random.RandomGenerator var25 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var25);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
//     org.apache.commons.math3.exception.OutOfRangeException var32 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.15512025679417774d, (java.lang.Number)1.2471705263294632d, (java.lang.Number)0.0843874063990762d);
//     boolean var33 = var17.equals((java.lang.Object)1.2471705263294632d);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var34 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var35 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var37 = var36.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var38 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var35, var37);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var34, var37);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var37);
//     int var41 = var37.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var42 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var37);
//     org.apache.commons.math3.random.RandomGenerator var43 = null;
//     org.apache.commons.math3.random.RandomDataImpl var44 = new org.apache.commons.math3.random.RandomDataImpl(var43);
//     double var47 = var44.nextUniform(0.2577047455984825d, 13.770182159584014d);
//     long var49 = var44.nextPoisson(23.012289905639566d);
//     int var52 = var44.nextZipf(10178, 0.5950413774252329d);
//     org.apache.commons.math3.distribution.NormalDistribution var53 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var53.reseedRandomGenerator(2L);
//     double[] var57 = var53.sample(100000);
//     double var58 = var53.getMean();
//     double var59 = var44.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var53);
//     boolean var60 = var53.isSupportConnected();
//     double[] var62 = var53.sample(962);
//     double[] var63 = var42.rank(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "MAXIMAL"+ "'", var13.equals("MAXIMAL"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1.330360402068156d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 21L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 3339);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == (-0.3668309555065332d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test128"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var4, (java.lang.Number)0.777695809106093d, var6, true);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var2, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test129"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     int var11 = var0.nextZipf(5, 0.8273572477024794d);
//     int var14 = var0.nextBinomial(1972, 0.15795521463156686d);
//     double var17 = var0.nextGaussian(3.4456677746279425d, 3.02837877258525d);
//     double var20 = var0.nextBeta(0.04378400432753371d, 0.08452288246378666d);
//     int var23 = var0.nextInt(13890, 45295);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15.211367482082627d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1b16d46035659ea0c8a07b0c47e96bfd98b61daedeb4618ffa3a3d2470547a978a2f8076e4fd7128495a3f4d9c5d24744ee2"+ "'", var8.equals("1b16d46035659ea0c8a07b0c47e96bfd98b61daedeb4618ffa3a3d2470547a978a2f8076e4fd7128495a3f4d9c5d24744ee2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 334);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.9709828987735831d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 6.56141153373968E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 14777);
// 
//   }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test130"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     double var12 = var0.nextCauchy(100.0d, 120.0d);
//     int var16 = var0.nextHypergeometric(10947, 1604, 243);
//     var0.reSeedSecure((-762L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 30.407198167320953d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 234.1515957637355d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 26);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test131"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var9);
    boolean var12 = var8.equals((java.lang.Object)0.00333969801975283d);
    java.lang.String var13 = var8.name();
    java.lang.Class var14 = var8.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "MAXIMAL"+ "'", var13.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test132"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.08709771401391468d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.09803129470864717d);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test133"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var13.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    java.lang.Class var18 = var17.getDeclaringClass();
    java.lang.Class var19 = var17.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    java.lang.String var21 = var17.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var15, var17);
    boolean var24 = var17.equals((java.lang.Object)6.694390071933186E-5d);
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var26 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var27 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var29 = var28.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var30 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var27, var29);
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26, var29);
    java.lang.String var32 = var29.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var29);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var34 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var29);
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var36 = var35.getTiesStrategy();
    java.lang.Class var37 = var36.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var38 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var36);
    boolean var40 = var36.equals((java.lang.Object)0.8967323527194379d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var41 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var36);
    org.apache.commons.math3.random.RandomGenerator var42 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var43 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var42);
    org.apache.commons.math3.stat.ranking.NaNStrategy var44 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var45 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var46 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var47 = var46.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var48 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var45, var47);
    org.apache.commons.math3.stat.ranking.NaturalRanking var49 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var44, var47);
    java.lang.String var50 = var47.name();
    java.lang.Class var51 = var47.getDeclaringClass();
    java.lang.Class var52 = var47.getDeclaringClass();
    java.lang.String var53 = var47.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var54 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var47);
    java.lang.String var55 = var47.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var56 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "AVERAGE"+ "'", var21.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "AVERAGE"+ "'", var32.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var50 + "' != '" + "AVERAGE"+ "'", var50.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + "AVERAGE"+ "'", var53.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + "AVERAGE"+ "'", var55.equals("AVERAGE"));

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test134"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     var0.reSeedSecure();
//     long var10 = var0.nextSecureLong(3L, 31L);
//     var0.reSeedSecure();
//     double var15 = var0.nextUniform(0.0d, 0.3955479014339429d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.502726043257312d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 14L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.2938390939347139d);
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test135"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)3.84074378609149d, (java.lang.Number)(-8904), false);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test136"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.8957380763521041d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test137"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(3.1173466159040992d);
    double var4 = var0.addElementRolling(0.36977327227972484d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test138"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    boolean var2 = var0.isSupportUpperBoundInclusive();
    double[] var4 = var0.sample(100);
    double var5 = var0.getNumericalVariance();
    double var7 = var0.probability(2.1852017790592613d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test139"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var8, var11);
    org.apache.commons.math3.random.RandomGenerator var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var15);
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    java.lang.Class var19 = var18.getDeclaringClass();
    java.lang.Class var20 = var18.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    java.lang.String var22 = var18.name();
    java.lang.String var23 = var18.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var24 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var8, var18);
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "AVERAGE"+ "'", var22.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "AVERAGE"+ "'", var23.equals("AVERAGE"));

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test140"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var5 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)11.394339056267674d, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test141"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.6461740882358429d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.6461740882358427d);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test142"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.9999999f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test143"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(9.18462119589379d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.0d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test144"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(184, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test145"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     double var16 = var0.nextGaussian(0.9999494957997512d, 25.472636453138065d);
//     double var19 = var0.nextWeibull(18.0d, 25.472636453138065d);
//     var0.reSeedSecure();
//     int var24 = var0.nextHypergeometric(97944, 11283, 1994);
//     long var26 = var0.nextPoisson(3628800.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("2fcff42dfa", "6fd99f784fb3cc87e48996ed8221e926b6d01e45e7eeadbd90572416374167c694a4e089f857d30d22505d87b15c5007e746");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.742835132737483d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "0d60e344f4"+ "'", var8.equals("0d60e344f4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1968);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.00854695493161599d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.2368773428582343d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 26.53805094560329d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 233);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 3632768L);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test146"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-0.054349963021461445d));
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test147"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(5598.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.630164670075398d);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test148"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(4.0433441546207005d, 14.137624878787419d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 14.70445745908411d);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test149"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)3607);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test150"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(18.056140472530597d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 18.056140472530597d);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test151"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(77022.0080808884d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 77022L);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test152"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var6 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var3, var5);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var8 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var5);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var9.getStandardDeviation();
//     double[] var12 = var9.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
//     int var14 = var13.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var15 = var13.copy();
//     var13.addElement((-0.43408597923864894d));
//     double var19 = var13.getElement(0);
//     double[] var20 = var13.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
//     org.apache.commons.math3.distribution.NormalDistribution var22 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double[] var24 = var22.sample(1910);
//     double var25 = var8.mannWhitneyU(var20, var24);
//     org.apache.commons.math3.distribution.NormalDistribution var26 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var27 = var26.getStandardDeviation();
//     double[] var29 = var26.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray(var29);
//     int var31 = var30.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var32 = var30.copy();
//     var30.addElement((-0.43408597923864894d));
//     double var36 = var30.getElement(0);
//     double[] var37 = var30.getElements();
//     org.apache.commons.math3.distribution.NormalDistribution var38 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var39 = var38.getStandardDeviation();
//     double[] var41 = var38.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var42 = new org.apache.commons.math3.util.ResizableDoubleArray(var41);
//     org.apache.commons.math3.exception.util.Localizable var43 = null;
//     org.apache.commons.math3.exception.util.Localizable var44 = null;
//     org.apache.commons.math3.exception.util.Localizable var45 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var46 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.NullArgumentException var47 = new org.apache.commons.math3.exception.NullArgumentException(var45, (java.lang.Object[])var46);
//     org.apache.commons.math3.exception.MathInternalError var48 = new org.apache.commons.math3.exception.MathInternalError(var44, (java.lang.Object[])var46);
//     org.apache.commons.math3.exception.NullArgumentException var49 = new org.apache.commons.math3.exception.NullArgumentException(var43, (java.lang.Object[])var46);
//     boolean var50 = var42.equals((java.lang.Object)var43);
//     var42.addElement(20.696514663540924d);
//     double var54 = var42.substituteMostRecentElement((-1.84544373783414d));
//     java.lang.Object var55 = null;
//     boolean var56 = var42.equals(var55);
//     var42.setElement(100, 0.0d);
//     double[] var60 = var42.getInternalValues();
//     float var61 = var42.getExpansionFactor();
//     int var62 = var42.getExpansionMode();
//     double[] var63 = var42.getInternalValues();
//     double var64 = var8.mannWhitneyU(var37, var63);
//     org.apache.commons.math3.util.ResizableDoubleArray var65 = new org.apache.commons.math3.util.ResizableDoubleArray(var37);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var67 = var65.getElement(1898);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-1.0933042109739008d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 2962.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0.268005259269379d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 20.696514663540924d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 101.0d);
// 
//   }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test153"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(0L);
//     long var17 = var0.nextPoisson(7.769493748166378d);
//     double var19 = var0.nextExponential(8.563154148722202d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var22 = var0.nextF(0.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.7039234825142175d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1bdebc2475"+ "'", var8.equals("1bdebc2475"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9426078246649741d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 10872);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.35395612255546877d);
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test154"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 11L);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    java.math.BigInteger var15 = null;
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 0L);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, var17);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 6L);
    org.apache.commons.math3.exception.OutOfRangeException var21 = new org.apache.commons.math3.exception.OutOfRangeException(var9, (java.lang.Number)5.363952139253263d, (java.lang.Number)14.087081017797523d, (java.lang.Number)var20);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, var20);
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 1999);
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 295783);
    java.math.BigInteger var27 = null;
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var27, 0L);
    java.math.BigInteger var30 = null;
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var30, 0L);
    java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var29, var32);
    java.math.BigInteger var35 = org.apache.commons.math3.util.ArithmeticUtils.pow(var29, 11L);
    java.math.BigInteger var36 = null;
    java.math.BigInteger var38 = org.apache.commons.math3.util.ArithmeticUtils.pow(var36, 0L);
    java.math.BigInteger var39 = null;
    java.math.BigInteger var41 = org.apache.commons.math3.util.ArithmeticUtils.pow(var39, 0L);
    java.math.BigInteger var42 = org.apache.commons.math3.util.ArithmeticUtils.pow(var38, var41);
    java.math.BigInteger var44 = org.apache.commons.math3.util.ArithmeticUtils.pow(var42, 1949);
    java.math.BigInteger var45 = org.apache.commons.math3.util.ArithmeticUtils.pow(var35, var44);
    java.math.BigInteger var47 = org.apache.commons.math3.util.ArithmeticUtils.pow(var35, 8904);
    java.math.BigInteger var48 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test155"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-933400799), 1460);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1460);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test156"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.07787079419500827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 166.3870686352019d);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test157"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-1.0f));
    java.lang.Number var2 = var1.getMin();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var8 = var7.getStandardDeviation();
    double[] var10 = var7.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    double[] var12 = var11.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var20 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var16, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var21 = var20.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var22 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var15, (java.lang.Object[])var21);
    org.apache.commons.math3.exception.MathArithmeticException var23 = new org.apache.commons.math3.exception.MathArithmeticException(var14, (java.lang.Object[])var21);
    boolean var24 = var13.equals((java.lang.Object)var21);
    org.apache.commons.math3.exception.MathIllegalStateException var25 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, (java.lang.Object[])var21);
    org.apache.commons.math3.exception.MathIllegalArgumentException var26 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var21);
    org.apache.commons.math3.exception.MathInternalError var27 = new org.apache.commons.math3.exception.MathInternalError(var4, (java.lang.Object[])var21);
    org.apache.commons.math3.exception.MathIllegalStateException var28 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var3, (java.lang.Object[])var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test158"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(7.629395E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.094947E-13f);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test159"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(163824380L, (-47L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 163824427L);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test160"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 0.0d, (-51.46112688913703d), (-1263861615));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test161"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var13 = var12.getStandardDeviation();
//     double[] var15 = var12.sample(1);
//     double var16 = var12.getMean();
//     double[] var18 = var12.sample(100);
//     boolean var19 = var12.isSupportLowerBoundInclusive();
//     boolean var20 = var12.isSupportUpperBoundInclusive();
//     double[] var22 = var12.sample(8899);
//     double var23 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var25 = var0.nextExponential(17.00231119711161d);
//     var0.reSeedSecure(0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.882280698278826d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "e2aea1a3bf"+ "'", var8.equals("e2aea1a3bf"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1978);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 2.0462843572939757d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 3.7092314568336238d);
// 
//   }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test162"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     long var12 = var0.nextPoisson(8.833191496136676d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextBeta(0.8377614126493502d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 17.41678483783751d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5b71b74e7d"+ "'", var8.equals("5b71b74e7d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5104738180833464d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 12L);
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test163"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var1.getNanStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test164"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(Float.POSITIVE_INFINITY, 1.9999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test165"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.6475970207672137d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6475970207672136d);

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test166"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     double var9 = var0.nextGamma(9.319248049587957d, (-0.4255538433808183d));
//     long var11 = var0.nextPoisson(0.9978516012375751d);
//     int var14 = var0.nextZipf(8941, 1.445343853698748d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextBeta((-0.6095209624325026d), 1.6740869895151453d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-98.20603880820345d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-4.651785047987967d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test167"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(553.6455155924548d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.3183291990396695d);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test168"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-0.5574992050354581d));

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test169"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var4.addElement((-0.43408597923864894d));
//     double var10 = var4.getElement(0);
//     double[] var11 = var4.getElements();
//     var4.addElement(21.0d);
//     var4.setNumElements(3);
//     org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var17 = var16.getStandardDeviation();
//     double[] var19 = var16.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
//     var20.contract();
//     int var22 = var20.getNumElements();
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var20);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var24 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var28 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var28);
//     org.apache.commons.math3.distribution.NormalDistribution var30 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var31 = var30.getSupportUpperBound();
//     double[] var33 = var30.sample(10);
//     double var34 = var24.mannWhitneyU(var28, var33);
//     var4.addElements(var28);
//     var4.discardMostRecentElements(0);
//     int var38 = var4.start();
//     double[] var39 = var4.getInternalValues();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.4796427257790052d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 18.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test170"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(4.420565912639617d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test171"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(6.98187794279763d, 2.0134882573780497d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.995185178239606d);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test172"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     var4.contract();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     float var7 = var4.getContractionCriteria();
//     double var9 = var4.addElementRolling(1.4929039221512146d);
//     var4.clear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.5890277721286947d));
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test173"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double[] var3 = var0.sample(10);
    double var4 = var0.getStandardDeviation();
    double var6 = var0.density(2.345330933436551d);
    double var7 = var0.getMean();
    double var8 = var0.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.025496167636629936d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.POSITIVE_INFINITY);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test174"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.math.BigInteger var1 = null;
//     java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
//     java.math.BigInteger var4 = null;
//     java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0L);
//     java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, var6);
//     org.apache.commons.math3.exception.NotPositiveException var8 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)var7);
//     org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var8);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test175"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1916);
    float var2 = var1.getExpansionFactor();
    int var3 = var1.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionFactor(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test176"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     double var11 = var0.nextGaussian(0.0d, 25.472636453138065d);
//     var0.reSeed(76L);
//     long var15 = var0.nextPoisson(0.4625972558324338d);
//     int var18 = var0.nextZipf(1856, 14.137624878787419d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.7121865036431227d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "981260c864"+ "'", var8.equals("981260c864"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 33.15319147181418d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test177"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.clear();
    float var8 = var6.getExpansionFactor();
    var6.setContractionCriteria(2.0f);
    float var11 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setContractionCriteria(2.384186E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test178"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(2.0857110610969416d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.96960835080702d);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test179"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var5 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var4, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)0.5662191695169728d, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test180"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)8L, (java.lang.Number)0.7057047898438089d, true);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test181"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(119156, (-0.99999976f), 0.0f, 9666);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test182"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.09385662285674329d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.09385662285674327d);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test183"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)168095.1629734684d);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test184"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.14608902069952245d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.15729920705028488d);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test185"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.contract();
    int var8 = var6.getExpansionMode();
    var6.setElement(5, 20.696514663540924d);
    var6.setNumElements(1);
    int var14 = var6.getNumElements();
    double[] var15 = var6.getElements();
    org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var17 = var16.getStandardDeviation();
    double[] var19 = var16.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    var20.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var22 = var20.copy();
    var22.contract();
    int var24 = var22.getExpansionMode();
    var22.setElement(5, 20.696514663540924d);
    var22.setNumElements(1);
    int var30 = var22.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var6, var22);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setExpansionFactor(0.25f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test186"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(1818);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test187"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1946);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test188"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
//     java.lang.Class var5 = var4.getDeclaringClass();
//     int var6 = var4.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
//     org.apache.commons.math3.random.RandomGenerator var8 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
//     org.apache.commons.math3.random.RandomGenerator var10 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
//     boolean var13 = var2.equals((java.lang.Object)(-1.5564980685845229d));
//     java.lang.Class var14 = var2.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
//     java.lang.Class var18 = var17.getDeclaringClass();
//     int var19 = var17.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var17);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var23 = var21.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var24 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var25 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var27 = var26.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var28 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var25, var27);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24, var27);
//     java.lang.String var30 = var27.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var31 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var23, var27);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var33 = var32.getTiesStrategy();
//     java.lang.Class var34 = var33.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var33);
//     java.lang.String var36 = var33.toString();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var37 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var23, var33);
//     double[] var41 = new double[] { 0.0d, (-1.0d), 0.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var42 = new org.apache.commons.math3.util.ResizableDoubleArray(var41);
//     org.apache.commons.math3.distribution.NormalDistribution var43 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var44 = var43.getStandardDeviation();
//     double[] var46 = var43.sample(1);
//     double var47 = var43.getMean();
//     double[] var49 = var43.sample(100);
//     var42.addElements(var49);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var51 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.distribution.NormalDistribution var52 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var53 = var52.getStandardDeviation();
//     boolean var54 = var52.isSupportUpperBoundInclusive();
//     double[] var56 = var52.sample(100);
//     org.apache.commons.math3.distribution.NormalDistribution var57 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var57.reseedRandomGenerator(2L);
//     double[] var61 = var57.sample(100000);
//     double var62 = var51.mannWhitneyUTest(var56, var61);
//     org.apache.commons.math3.distribution.NormalDistribution var63 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double[] var65 = var63.sample(1910);
//     org.apache.commons.math3.distribution.NormalDistribution var66 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var67 = var66.getStandardDeviation();
//     double[] var69 = var66.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var70 = new org.apache.commons.math3.util.ResizableDoubleArray(var69);
//     double[] var71 = var70.getElements();
//     double var72 = var51.mannWhitneyUTest(var65, var71);
//     double var73 = var37.mannWhitneyUTest(var49, var65);
//     double[] var74 = var20.rank(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var30 + "' != '" + "AVERAGE"+ "'", var30.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + "AVERAGE"+ "'", var36.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 0.45519147003163885d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 0.564315118052787d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 0.13081685956703637d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
// 
//   }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test189"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var11 = var9.sample();
//     double var13 = var9.probability(7.444490968701611d);
//     double var14 = var9.getSupportUpperBound();
//     boolean var15 = var9.isSupportUpperBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 14.297291385251235d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d005bda897"+ "'", var8.equals("d005bda897"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.28596397834822856d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.40050392352432373d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
// 
//   }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test190"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     double var30 = var0.nextExponential(1.0471975511965979d);
//     double var32 = var0.nextChiSquare(0.8382617516745859d);
//     double var34 = var0.nextT(4.724327703255943d);
//     double var36 = var0.nextT(0.16444495691521632d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.847849922890541d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "eb8e478302"+ "'", var8.equals("eb8e478302"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1959);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.015788424253213584d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.26156122958435735d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-0.9603061803665608d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.470606356730314d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-1.2562464928042558d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1.7512622318391559E44d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 0.08546459680624052d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.3828189244141576d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1.0910310882337289d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0.3412505067084862d);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test191"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(14273034, 2617);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test192"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-2.580151816032994d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.637452175050094d);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test193"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     double var30 = var0.nextExponential(1.0471975511965979d);
//     double var32 = var0.nextT(4.778273159193727d);
//     double var34 = var0.nextT(0.20869243648270883d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.8468872608045873d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "b49793ac1a"+ "'", var8.equals("b49793ac1a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.02559143588220844d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.9177033480137688d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-0.43088873001373695d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-0.17492283135925044d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-2.325519227211754d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 26265.222276818942d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 3.4896784674878667d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == (-0.24281257105742604d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == (-0.28031922022926786d));
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test194"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1940, (java.lang.Number)30.200159778529517d, true);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 30.200159778529517d+ "'", var4.equals(30.200159778529517d));

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test195"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)17190, (java.lang.Number)1.1968914007497313d, false);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test196"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(1.043602225172257d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5958053091149227d);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test197"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
//     java.lang.Class var3 = var2.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     java.lang.String var5 = var2.toString();
//     java.lang.String var6 = var2.toString();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var2);
//     org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var11 = var8.nextSecureLong((-1L), 1L);
//     double var14 = var8.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var16 = var8.nextHexString(10);
//     int var19 = var8.nextPascal(8899, 0.8219866295031046d);
//     double var21 = var8.nextExponential(0.010050505059049992d);
//     var8.reSeed(104L);
//     boolean var24 = var2.equals((java.lang.Object)var8);
//     org.apache.commons.math3.distribution.NormalDistribution var25 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var26 = var25.getStandardDeviation();
//     double[] var28 = var25.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var28);
//     var29.contract();
//     var29.addElement(0.0d);
//     int var33 = var29.getExpansionMode();
//     double[] var34 = var29.getElements();
//     float var35 = var29.getContractionCriteria();
//     boolean var36 = var2.equals((java.lang.Object)var29);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var38 = var37.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var39 = var37.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var40 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var41 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var42 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var43 = var42.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var44 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var41, var43);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var45 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var40, var43);
//     java.lang.String var46 = var43.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var47 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var39, var43);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var48 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var49 = var48.getTiesStrategy();
//     java.lang.Class var50 = var49.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var51 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var49);
//     java.lang.String var52 = var49.toString();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var53 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var39, var49);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var54 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var55 = var54.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var56 = var54.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var57 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var58 = var57.getTiesStrategy();
//     java.lang.Class var59 = var58.getDeclaringClass();
//     int var60 = var58.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var61 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var56, var58);
//     org.apache.commons.math3.random.RandomGenerator var62 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var63 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var56, var62);
//     org.apache.commons.math3.random.RandomGenerator var64 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var65 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var56, var64);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var66 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var67 = var66.getTiesStrategy();
//     java.lang.Class var68 = var67.getDeclaringClass();
//     java.lang.String var69 = var67.toString();
//     java.lang.String var70 = var67.toString();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var71 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var56, var67);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var72 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var76 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var77 = new org.apache.commons.math3.util.ResizableDoubleArray(var76);
//     org.apache.commons.math3.distribution.NormalDistribution var78 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var79 = var78.getSupportUpperBound();
//     double[] var81 = var78.sample(10);
//     double var82 = var72.mannWhitneyU(var76, var81);
//     double[] var83 = var71.rank(var76);
//     org.apache.commons.math3.distribution.NormalDistribution var84 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var85 = var84.getStandardDeviation();
//     double[] var87 = var84.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var88 = new org.apache.commons.math3.util.ResizableDoubleArray(var87);
//     double[] var89 = var88.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var90 = new org.apache.commons.math3.util.ResizableDoubleArray(var89);
//     double var91 = var53.mannWhitneyU(var83, var89);
//     var29.addElements(var89);
//     double[] var93 = var29.getInternalValues();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "AVERAGE"+ "'", var5.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 16.471294343056556d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "050c98ccde"+ "'", var16.equals("050c98ccde"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1879);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 7.3478252573516E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var46 + "' != '" + "AVERAGE"+ "'", var46.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var52 + "' != '" + "AVERAGE"+ "'", var52.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var69 + "' != '" + "AVERAGE"+ "'", var69.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var70 + "' != '" + "AVERAGE"+ "'", var70.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == 27.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var91 == 3.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var93);
// 
//   }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test198"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     double var16 = var0.nextGaussian(0.9999494957997512d, 25.472636453138065d);
//     double var18 = var0.nextT(192.9088122275434d);
//     java.lang.String var20 = var0.nextSecureHexString(1793);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.605739690487886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "fb6d54d703"+ "'", var8.equals("fb6d54d703"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1909);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.008204166910915089d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-29.58808950635676d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.098515693692801d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "001f88de54e46ed93a9aa7199342b4325ae421d2ec6c326a420498f8a57905da7e7efadc15f8a3bcdeac5a387aa40ec5db3b6dd7627ab5e885a545679ea6f65ef7462b61b048f62e174745455e1199673959f4bc80cb9f32ce00703f83ea6dafa4b066db65d3367edc62c247f7be462e38ffdf98d8d0e488b1d878c5619db113c05900a1a7d678f1bb4d9a2ab3adfba50801265871c20553eeb53c12f6f1982ec3b95d19bcc1f9abac219d2bb061de86c88cbb47f9641833805dade8ffd2ec6ba2f3437d17ec809d53e8fd6e1683dc6740c581877021984a75b5e68b1f96aee1f7f57da33528292a6043cb540d7bafc5cd288f2c33abb5dde21ce981823971205ea8c1566d9613a8eb2c2a0f6a7973d0188c96133b3f53efdccd3f206b3ec7b1981ed257865809bdb212fc5b7b23fc95fe4e8e380b4611e5710e41f29ebeef4babd8e0ed39ce8a668927291f3d7aefd7c71184059917a9bdba69d468a4692ed3c6c784e9a9ef2f3048bfc89e77eb025f7536328a8033218498f3740bc52969d95779527336f0bdaea6782016bf17ae4bc19eb7281e83e77691b96bb98f5070d2590a743f0e8f2827adeca2eabc8a35d597a544afe8802249f5c1cd0e8da7e1f74f4679b7206ea700fa0c288dea8a9c78459501ecc8d530ff62f9c986a2d6317b0290224fefd43e397c22f63c1272832a2c553ce5edd3ae6ae6c5835ffee85833e3fff3598c1b4e3dd9573a5f38d2ea88b6b8d9b9881984af868ea4410f2c9e8dea2f10fdc97db905a930a01077fb8336f21ec49a2293a046d951b1c32b3ce930f07d16b54710ff34c5048aca2da6de9c37c8d83f936741ca5fd6951df9b3c95db1c875c053621083cd38e5e4d3baff72a75ab6828fd8ea39d812a8110510e29f365cb0b8a7f502b8e16bcd1cbe84fa6a17ba01204f02b5604c7e8da834a2c18e065efaa06bc4594c3141a39528b97559872c1504abe2f47d86de86e7b132d125dc0b75658b7784cc20295befa041a720b0e33f6009bd58e74d491ba0e9a3ac8d32e168fe24a1cca7891405fddfef362c635e1eb709d538b1844989972008f3d4b79fc65819065a003a6c38f95a74d70cac2011b9773cdb8c1a8ecbd7960ae3f367ac1cab0e788717617982149bb21ed255c56381917e708579e353bbc4973c0674b48de30db627c617483910c27d69fb754d24239c88a7a08549984f8ce5ccc854869a29bb689167d6c4a8fc537080d0d2bc76e030015d94cfcbd2aa6b4df4d99"+ "'", var20.equals("001f88de54e46ed93a9aa7199342b4325ae421d2ec6c326a420498f8a57905da7e7efadc15f8a3bcdeac5a387aa40ec5db3b6dd7627ab5e885a545679ea6f65ef7462b61b048f62e174745455e1199673959f4bc80cb9f32ce00703f83ea6dafa4b066db65d3367edc62c247f7be462e38ffdf98d8d0e488b1d878c5619db113c05900a1a7d678f1bb4d9a2ab3adfba50801265871c20553eeb53c12f6f1982ec3b95d19bcc1f9abac219d2bb061de86c88cbb47f9641833805dade8ffd2ec6ba2f3437d17ec809d53e8fd6e1683dc6740c581877021984a75b5e68b1f96aee1f7f57da33528292a6043cb540d7bafc5cd288f2c33abb5dde21ce981823971205ea8c1566d9613a8eb2c2a0f6a7973d0188c96133b3f53efdccd3f206b3ec7b1981ed257865809bdb212fc5b7b23fc95fe4e8e380b4611e5710e41f29ebeef4babd8e0ed39ce8a668927291f3d7aefd7c71184059917a9bdba69d468a4692ed3c6c784e9a9ef2f3048bfc89e77eb025f7536328a8033218498f3740bc52969d95779527336f0bdaea6782016bf17ae4bc19eb7281e83e77691b96bb98f5070d2590a743f0e8f2827adeca2eabc8a35d597a544afe8802249f5c1cd0e8da7e1f74f4679b7206ea700fa0c288dea8a9c78459501ecc8d530ff62f9c986a2d6317b0290224fefd43e397c22f63c1272832a2c553ce5edd3ae6ae6c5835ffee85833e3fff3598c1b4e3dd9573a5f38d2ea88b6b8d9b9881984af868ea4410f2c9e8dea2f10fdc97db905a930a01077fb8336f21ec49a2293a046d951b1c32b3ce930f07d16b54710ff34c5048aca2da6de9c37c8d83f936741ca5fd6951df9b3c95db1c875c053621083cd38e5e4d3baff72a75ab6828fd8ea39d812a8110510e29f365cb0b8a7f502b8e16bcd1cbe84fa6a17ba01204f02b5604c7e8da834a2c18e065efaa06bc4594c3141a39528b97559872c1504abe2f47d86de86e7b132d125dc0b75658b7784cc20295befa041a720b0e33f6009bd58e74d491ba0e9a3ac8d32e168fe24a1cca7891405fddfef362c635e1eb709d538b1844989972008f3d4b79fc65819065a003a6c38f95a74d70cac2011b9773cdb8c1a8ecbd7960ae3f367ac1cab0e788717617982149bb21ed255c56381917e708579e353bbc4973c0674b48de30db627c617483910c27d69fb754d24239c88a7a08549984f8ce5ccc854869a29bb689167d6c4a8fc537080d0d2bc76e030015d94cfcbd2aa6b4df4d99"));
// 
//   }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test199"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextWeibull(7.769493748166378d, 1.2185657441986304d);
//     int var9 = var0.nextInt((-1), 6);
//     int var12 = var0.nextPascal(3226426, 0.5489943340020218d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.190459847286902d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2649248);
// 
//   }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test200"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.9856338779552689d, var2, false);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test201"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var4 = var1.toString();
    java.lang.Class var5 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = var8.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var8.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var8.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var8.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var14.getTiesStrategy();
    java.lang.Class var16 = var15.getDeclaringClass();
    java.lang.Class var17 = var15.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var19 = var18.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var19);
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7, var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test202"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(9.189990564561439E-4d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0010369790979554354d));

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test203"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.clear();
    float var8 = var6.getExpansionFactor();
    var6.setContractionCriteria(2.0f);
    float var11 = var6.getContractionCriteria();
    double[] var12 = var6.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.discardMostRecentElements(97944);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test204"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double[] var6 = var0.sample(100);
//     double var7 = var0.sample();
//     double var8 = var0.sample();
//     double var9 = var0.getStandardDeviation();
//     double var10 = var0.sample();
//     double var11 = var0.getNumericalMean();
//     double[] var13 = var0.sample(80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.44449887035972063d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.4248462891538982d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-2.0450414854592704d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test205"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
//     java.lang.Class var5 = var4.getDeclaringClass();
//     java.lang.Class var6 = var4.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
//     java.lang.String var8 = var4.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
//     java.lang.Class var13 = var12.getDeclaringClass();
//     java.lang.Class var14 = var12.getDeclaringClass();
//     boolean var16 = var12.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
//     org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var18 = var17.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var17.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var20 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var20, var22);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var19, var22);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var27 = var26.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var28 = var26.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var29 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var30 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var32 = var31.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var33 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var30, var32);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var29, var32);
//     java.lang.String var35 = var32.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var36 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var28, var32);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var38 = var37.getTiesStrategy();
//     java.lang.Class var39 = var38.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var38);
//     java.lang.String var41 = var38.toString();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var42 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var28, var38);
//     org.apache.commons.math3.distribution.NormalDistribution var43 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var44 = var43.getStandardDeviation();
//     double[] var46 = var43.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var47 = new org.apache.commons.math3.util.ResizableDoubleArray(var46);
//     double[] var48 = var47.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var49 = new org.apache.commons.math3.util.ResizableDoubleArray(var48);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var50 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var54 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var55 = new org.apache.commons.math3.util.ResizableDoubleArray(var54);
//     double[] var59 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var60 = new org.apache.commons.math3.util.ResizableDoubleArray(var59);
//     double var61 = var50.mannWhitneyU(var54, var59);
//     double var62 = var42.mannWhitneyUTest(var48, var54);
//     org.apache.commons.math3.distribution.NormalDistribution var63 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var64 = var63.getStandardDeviation();
//     double[] var66 = var63.sample(1);
//     double var67 = var63.getMean();
//     double[] var69 = var63.sample(100);
//     boolean var70 = var63.isSupportLowerBoundInclusive();
//     boolean var71 = var63.isSupportUpperBoundInclusive();
//     double[] var73 = var63.sample(8899);
//     double var74 = var25.mannWhitneyUTest(var48, var73);
//     double[] var75 = var10.rank(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + "AVERAGE"+ "'", var35.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var41 + "' != '" + "AVERAGE"+ "'", var41.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 4.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 0.17971249487899976d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 0.5459218062369334d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test206"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(3.161025277788947E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.161025277788942E-15d);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test207"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.11051325275411276d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3877787807814457E-17d);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test208"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-1953380655), 1255);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test209"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var13 = var0.nextT(5.867156662812015d);
//     double var15 = var0.nextExponential(11.771947930619202d);
//     int var18 = var0.nextBinomial(0, 0.0031612049524534893d);
//     var0.reSeedSecure(2184L);
//     int var23 = var0.nextSecureInt(0, 2426);
//     long var25 = var0.nextPoisson(0.5718637074096835d);
//     org.apache.commons.math3.random.RandomDataImpl var26 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var29 = var26.nextSecureLong((-1L), 1L);
//     double var32 = var26.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var35 = var26.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var36 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var37 = var36.getStandardDeviation();
//     double[] var39 = var36.sample(1);
//     double var41 = var36.cumulativeProbability(0.0d);
//     double var42 = var36.getSupportUpperBound();
//     double var43 = var26.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var36);
//     double var44 = var36.sample();
//     double var45 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var36);
//     org.apache.commons.math3.distribution.IntegerDistribution var46 = null;
//     int var47 = var0.nextInversionDeviate(var46);
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test210"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.0d, 41.00598452531734d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test211"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.5631521198730945d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5981953585190757d);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test212"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(3);
    float var2 = var1.getContractionCriteria();
    double var4 = var1.addElementRolling(0.009999999583352414d);
    int var5 = var1.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionFactor(99.99999f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test213"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.5d, (java.lang.Number)0.5950413774252329d, false);
    java.lang.String var4 = var3.toString();
    java.lang.String var5 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 0.5 is smaller than, or equal to, the minimum (0.595)"+ "'", var4.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 0.5 is smaller than, or equal to, the minimum (0.595)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 0.5 is smaller than, or equal to, the minimum (0.595)"+ "'", var5.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 0.5 is smaller than, or equal to, the minimum (0.595)"));

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test214"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(3.292378755306352d, 5.861552970684626d, 0.8109766711360142d);
    double var5 = var3.probability(13.359855606410402d);
    boolean var6 = var3.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test215"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(17.63985625609349d, (-0.03830901737668812d), (-0.7253353445699519d), 1852);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test216"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-0.8692127392011839d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0d));

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test217"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(2.200594105225602d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test218"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double[] var3 = var0.sample(10);
    double var4 = var0.getStandardDeviation();
    double var6 = var0.density(2.345330933436551d);
    var0.reseedRandomGenerator(20901880L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.025496167636629936d);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test219"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.Class var5 = var2.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var7 = java.lang.Enum.<java.lang.Enum>valueOf(var5, "56f5c2d15c");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test220"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1919, 100.00001f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var4 = var3.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.discardMostRecentElements(17946);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test221"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-2L));
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test222"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(12.054217891468452d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5691112916217893d);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test223"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(7.957193834373427d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.881784197001252E-16d);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test224"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(7.340173857411658d, (-6.105715980305252d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.178964393734797E-6d);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test225"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-1544L), (-47L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 72568L);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test226"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-6572994968014929263L), 15936L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test227"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     double var9 = var0.nextGamma(9.319248049587957d, (-0.4255538433808183d));
//     long var11 = var0.nextPoisson(0.9978516012375751d);
//     int var14 = var0.nextZipf(8941, 1.445343853698748d);
//     double var17 = var0.nextUniform(0.965590882722694d, 0.9969493037940971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.421904925566961d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-4.368560211748956d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.9832768506419709d);
// 
//   }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test228"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "hi!");
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test229"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8623188722876839d);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test230"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 1.0f, 1.0f, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test231"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(100, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 101);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test232"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1), 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test233"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test234"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test235"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.8623188722876839d, 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.3581288330251856d);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test236"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7853981633974483d);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test237"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test238"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 1.0f, 10.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test239"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5574077246549023d);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test240"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(10.0d, (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0d));

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test241"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.3581288330251856d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0648164703369514d);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test242"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 0.0f, 1.0f, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test243"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-1), 100);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test244"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6506783754890694d);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test245"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test246"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.3581288330251856d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.551115123125783E-17d);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test247"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test248"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var2.getElement(0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test249"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-1L), (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2L));

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test250"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.7853981633974483d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 45.0d);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test251"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.3581288330251856d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.865319956825967d);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test252"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(10.0f, 1.5574077246549023d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.999999f);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test253"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(100L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test254"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 0.0f, 0.0f, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test255"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(8.865319956825967d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.0d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test256"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test257"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.7853981633974483d, 0.6506783754890694d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6506783754890694d);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test258"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(100);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test259"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.0d);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test260"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(0, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test261"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 0.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test262"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999958776927d);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test263"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(5.551115123125783E-17d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test264"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test265"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.7853981633974483d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test266"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test267"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(8.865319956825967d, 0.9999999958776927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8.865319877078154d);

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test268"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(5.551115123125783E-17d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test269"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//     int var3 = var2.getNumElements();
//     double[] var4 = null;
//     var2.addElements(var4);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test270"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(8.865319956825967d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8.865319956825967d);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test271"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.9999999958776927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6449340767586613d);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test272"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionFactor(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test273"); }


    float var2 = org.apache.commons.math3.util.FastMath.min((-1.0f), 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0f));

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test274"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.9999999958776927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test275"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(byte)100);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     java.lang.Object[] var6 = new java.lang.Object[] { (byte)1};
//     org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var4, var6);
//     org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, var6);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test276"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.6449340767586613d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2825498340254313d);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test277"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.9999999958776927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 57.295779276891516d);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test278"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(1.2825498340254313d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.941575758241476d);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test279"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7116024720019101d);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test280"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(10, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test281"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.941575758241476d, 0.0d, 10.0d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test282"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.6506783754890694d, 10.0d, 1.6449340767586613d, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test283"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.6506783754890694d, 0.6506783754890694d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test284"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.5574077246549023d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.19240232444172617d);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test285"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test286"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(57.295779276891516d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.569397550458789d);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test287"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(1.2825498340254313d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1555386051171055d);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test288"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(1, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-9));

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test289"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(100.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test290"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var3);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test291"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(1.1555386051171055d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test292"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(10, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10L);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test293"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.000000000000002d);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test294"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test295"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8414709848078965d);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test296"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.1555386051171055d, 0.3581288330251856d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2702602426089444d);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test297"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-1), true);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test298"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(1.1555386051171055d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9150123793192297d);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test299"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.3581288330251856d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test300"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test301"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.0648164703369514d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test302"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.9150123793192297d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test303"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(8.865319877078154d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.069655856740348d);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test304"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.5574077246549023d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1591352365493741d);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test305"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardFrontElements(1);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test306"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-9), 1.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test307"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.0d, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test308"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(1.1555386051171055d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test309"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)1.2825498340254313d, false);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test310"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.1555386051171055d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.1757334232496706d);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test311"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(8.865319877078154d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7081.058387126132d);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test312"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.2825498340254313d, 3.1757334232496706d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2825498340254315d);

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test313"); }
// 
// 
//     org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     java.lang.Object[] var8 = new java.lang.Object[] { 100.0d};
//     org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var6, var8);
//     org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var8);
//     org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, var8);
//     org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var11);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test314"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(8.865319956825967d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.8720980175938546d);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test315"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(1.2825498340254315d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test316"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(100L, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100L);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test317"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test318"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 1);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test319"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-1L), 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-100L));

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test320"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(57.295779276891516d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.553344806071505d);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test321"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var5 = var3.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test322"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test323"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-9));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test324"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(7.569397550458789d, 2.069655856740348d, 0.0d, (-9));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test325"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.9999999958776927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5403023093369417d);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test326"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test327"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.7116024720019101d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7790199122525784d);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test328"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(10L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test329"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.9150123793192297d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6097807640004534d);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test330"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 1.0f, (-1.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test331"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(1.2702602426089444d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9551779281484893d);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test332"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(8.865319877078154d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9L);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test333"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test334"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    java.lang.Object var7 = null;
    boolean var8 = var2.equals(var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setNumElements((-9));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test335"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-1), (-9));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test336"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0f));

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test337"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(100, 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test338"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(0, (-9));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test339"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.6506783754890694d, 0.7790199122525784d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6506783754890694d);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test340"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(100.0f, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 50.0f);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test341"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test342"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(1.2702602426089444d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.022170223590708048d);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test343"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.6097807640004534d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.010642682047134422d);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test344"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.2825498340254313d, 5.551115123125783E-17d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948966d);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test345"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)10L, (java.lang.Number)1.0648164703369514d, false);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test346"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.7435938375035028d, 8.865319956825967d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7435938375035029d);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test347"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-1), 0.0f, 0.0f, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test348"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.6506783754890694d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7612753675628248d);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test349"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-1.0f), 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test350"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(0.9551779281484893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.02756156531860343d);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test351"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(7081.058387126132d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 123.58778338131026d);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test352"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    int var9 = var2.getExpansionMode();
    double var11 = var2.getElement(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardFrontElements(10);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.0d);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test353"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(0, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test354"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.8414709848078965d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test355"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.0648164703369514d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.027274760086014354d);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test356"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.027274760086014354d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.16515071930214034d);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test357"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(10L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10L);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test358"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-9), (-9));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test359"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.7853981633974483d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test360"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    int var11 = var2.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var2.getElement(1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test361"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test362"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(10L, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10L);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test363"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(50.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test364"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.7116024720019101d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5374300498232759d);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test365"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(1.5574077246549023d, 0.19240232444172617d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5692474232144973d);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test366"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.6506783754890694d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9168407258198261d);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test367"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.6506783754890694d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 37.281124735952304d);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test368"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)100.5f);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test369"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.1919266570807596d, 0.7853981633974483d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8085085755675573d);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test370"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(2.8720980175938546d, 0.027274760086014354d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.00824820856234747d);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test371"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-100L), 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-90L));

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test372"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-90L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 90L);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test373"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(0, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test374"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(45.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test375"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test376"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    int var7 = var2.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardMostRecentElements(10);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test377"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(2.7760523581453453d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 15.05551425958108d);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test378"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.5f, 10.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test379"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 100.5f, 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test380"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setContractionCriteria(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test381"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(1.0648164703369514d, (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0648164703369514d));

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test382"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(1L, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100L);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test383"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 100.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test384"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.9551779281484893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.107194659485365d);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test385"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(100.5f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.5f);

  }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test386"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var2.getTiesStrategy();
//     org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//     var8.setExpansionMode(0);
//     double[] var11 = var8.getInternalValues();
//     var8.clear();
//     double[] var13 = var8.getElements();
//     double[] var14 = var2.rank(var13);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test387"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(37.281124735952304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 37.0d);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test388"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.3581288330251856d, 1.2825498340254313d, 0.0d, (-9));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test389"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.7853981633974483d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7853981633974484d);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test390"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test391"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(100, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test392"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(2.025675563797395d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.5812308201226335d);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test393"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test394"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(1.2825498340254313d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.6058222619154248d);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test395"); }


    java.math.BigInteger var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, (-9));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test396"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.7760523581453453d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test397"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var6.setExpansionMode(0);
    double[] var9 = var6.getInternalValues();
    var2.addElements(var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardFrontElements(100);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test398"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-90L), 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test399"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var6, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, var8);
    org.apache.commons.math3.exception.MaxCountExceededException var13 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    java.lang.Object[] var17 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var18 = new org.apache.commons.math3.exception.NullArgumentException(var15, var17);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var13, var14, var17);
    var11.addSuppressed((java.lang.Throwable)var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test400"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.107194659485365d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.034525803447559d);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test401"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(10, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test402"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.9302363507574447d, 0.976508918599899d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.3460731448215636d);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test403"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.5374300498232759d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test404"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.9995668109270821d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9997833820018625d);

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test405"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(byte)100);
//     java.lang.String var3 = var2.toString();
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test406"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(5.551115123125783E-17d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.551115123125783E-17d);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test407"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(10.000000000000002d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.17453292519943298d);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test408"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var2.substituteMostRecentElement((-1.0d));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test409"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var9 = var8.getNumElements();
    double[] var10 = var8.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var8.getElement(0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test410"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(5.551115123125783E-17d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.551115123125783E-17d);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test411"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(10.0d, 1.034525803447559d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.014741327437840844d);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test412"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.2825498340254315d, 0.02756156531860343d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5493099696436932d);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test413"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var3, var5);
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, var5);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test414"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1.1591352365493741d);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test415"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.010642682047134422d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test416"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(2.7760523581453453d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.3827413742969658d));

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test417"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.5692474232144973d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2L);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test418"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.553344806071505d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1581263863353843d);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test419"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.9995668109270821d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13.151476732942367d);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test420"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.6097807640004534d, 0.0d, 0.9999999958776927d, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test421"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1), (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test422"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.7435938375035028d, 0.17453292519943298d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7435938375035027d);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test423"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test424"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(1.941575758241476d, 1.6449340767586613d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.97848141639784d);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test425"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.9999999958776927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999958776927d);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test426"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5063656411097588d));

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test427"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-1), 0.0f, 1.0f, (-9));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test428"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(7.569397550458789d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9634526771778158d);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test429"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(2.9202368677790993d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05096774828087159d);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test430"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(1.034525803447559d, 7081.058387126132d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.034525803447559d);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test431"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var10 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var8, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var7, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var10);
    org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test432"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(3.739561347646417d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 21.02788165344431d);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test433"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.6506783754890694d, 0.7853981633974484d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7135399484934067d);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test434"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.3460731448215636d, 2.6058222619154248d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.6287023951487374d);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test435"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(100, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test436"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var3.inverseCumulativeProbability(100.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test437"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.7853981633974484d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.1932800507380157d);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test438"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.1555386051171055d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test439"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-9));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test440"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.9997833820018625d, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1023.7781831699072d);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test441"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(2.97848141639784d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0d);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test442"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-9), (-1.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test443"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(2.025675563797395d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.025675563797395d);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test444"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(9L, (-100L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test445"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(1.0648164703369514d, 1.5574077246549023d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.10446901610108233d);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test446"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test447"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 1.0f, 1.0f, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test448"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.02756156531860343d, 123.58778338131026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.02756156531860343d);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test449"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, var1, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test450"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.027274760086014354d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test451"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var6.setExpansionMode(0);
    double[] var9 = var6.getInternalValues();
    var2.addElements(var9);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test452"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-100L), (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100L);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test453"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test454"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.00824820856234747d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test455"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.7135399484934067d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.1822300333796267d));

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test456"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(10, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test457"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(2.9202368677790993d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999636981980967d);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test458"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    boolean var4 = var3.isSupportConnected();
    double var6 = var3.density(0.3581288330251856d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.006601438076270229d);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test459"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportUpperBoundInclusive();
//     double var5 = var2.getSupportUpperBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.9450663976980598d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test460"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0d);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test461"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.9150123793192297d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test462"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.0d);
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: 0 is smaller than the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotPositiveException: 0 is smaller than the minimum (0)"));

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test463"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(1L, 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test464"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.7853981633974483d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.013707783890401887d);

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test465"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test466"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.6506783754890694d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test467"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test468"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-1));

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test469"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(15.05551425958108d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5044728995807433d);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test470"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.7435938375035028d, 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7745517090716676d);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test471"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(90L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test472"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(4.3318907109302085E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.560575574229005E-6d);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test473"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(10, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test474"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(50.0f, 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 49.999996f);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test475"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(8.865319877078154d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.461644881538276d);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test476"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1.9450663976980598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.3655932269839443d));

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test477"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(1.5574077246549023d, 0.976508918599899d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5574077246549023d);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test478"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)2.6058222619154248d);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test479"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(2.7760523581453453d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.639495877295877E-5d);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test480"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.2702602426089444d, 0.19240232444172617d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.07655602848313875d));

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test481"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//     int var7 = var6.getNumElements();
//     double[] var8 = var6.getInternalValues();
//     double[] var9 = var2.rank(var8);
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test482"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.6097807640004534d, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.291334404149745E-22d);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test483"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
    double var4 = var2.density(5.551115123125783E-17d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var2.cumulativeProbability(0.3460731448215636d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.1919266570807596d);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test484"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(100L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100L);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test485"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-9), (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test486"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-9), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test487"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.9999999958776927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.017453292447995462d);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test488"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.9997833820018625d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test489"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(byte)100);
//     org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test490"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.7435938375035029d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.1034815175839263d);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test491"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double[] var7 = var2.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var2.substituteMostRecentElement(0.7116024720019101d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test492"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionMode(10);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test493"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4214549026638725d);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test494"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.9997833820018625d, 0.7135399484934067d, 0.022170223590708048d, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4906578777776055d);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test495"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-9));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test496"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-100L), (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest11.test497"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     double var4 = var3.getSupportUpperBound();
//     double var5 = var3.sample();
//     boolean var6 = var3.isSupportConnected();
//     double var7 = var3.getSupportLowerBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.074594310659796d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NEGATIVE_INFINITY);
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test498"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.014741327437840844d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test499"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.4511708924835962d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.00787441756300009d);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test500"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(100L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

}
