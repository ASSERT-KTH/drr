
import junit.framework.*;

public class RandoopTest5 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test1"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(20355937, 2297);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2297);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test2"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-297258196), 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test3"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)8.277113894567627d, (java.lang.Number)(-2.9672958426404166d), false);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test4"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.6901124746731373d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6040591714375757d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test5"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(1073741824L, 1135069411L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1073741824L);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test6"); }


    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)1.1368685E-13f, var2);
    java.lang.Number var4 = var3.getHi();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test7"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    var1.addElement(2.0216852347077916d);
    org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var5 = var4.getStandardDeviation();
    double[] var7 = var4.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var12 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var11, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var10, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var9, (java.lang.Object[])var12);
    boolean var16 = var8.equals((java.lang.Object)var9);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var8);
    int var18 = var1.start();
    org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var20 = var19.getStandardDeviation();
    double[] var22 = var19.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    org.apache.commons.math3.exception.util.Localizable var24 = null;
    org.apache.commons.math3.exception.util.Localizable var25 = null;
    org.apache.commons.math3.exception.util.Localizable var26 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var27 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var28 = new org.apache.commons.math3.exception.NullArgumentException(var26, (java.lang.Object[])var27);
    org.apache.commons.math3.exception.MathInternalError var29 = new org.apache.commons.math3.exception.MathInternalError(var25, (java.lang.Object[])var27);
    org.apache.commons.math3.exception.NullArgumentException var30 = new org.apache.commons.math3.exception.NullArgumentException(var24, (java.lang.Object[])var27);
    boolean var31 = var23.equals((java.lang.Object)var24);
    var23.setElement(8899, 2.3930658372149933d);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var23);
    var23.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test8"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
    java.lang.Class var14 = var13.getDeclaringClass();
    java.lang.String var15 = var13.toString();
    java.lang.String var16 = var13.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var13);
    int var18 = var2.ordinal();
    org.apache.commons.math3.random.RandomGenerator var19 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "AVERAGE"+ "'", var16.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test9"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(189, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test10"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-297256655), 1868);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test11"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.745691842295965d, 0.22491477372248148d, 0.5481764785100467d, 1932);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.32275508013725884d);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test12"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.9361319785805507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8144605996323813d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test13"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(2, 15L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 32768);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test14"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(2.495263527653989d, 0.056133798144741606d, 1.0494464950714408d, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test15"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(0L);
//     double var18 = var0.nextWeibull(1.3510036782572383d, 4.505452107819377E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.9381412579836104d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "94948ad972"+ "'", var8.equals("94948ad972"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5382762305934016d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 9864);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 6.593155448711632E8d);
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test16"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    double[] var6 = var4.getInternalValues();
    org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var8 = var7.getStandardDeviation();
    double[] var10 = var7.sample(1);
    double var11 = var7.getMean();
    double[] var13 = var7.sample(100);
    var4.addElements(var13);
    int var15 = var4.getExpansionMode();
    int var16 = var4.getExpansionMode();
    double[] var17 = var4.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test17"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     double var15 = var0.nextGamma(0.9999999994771264d, 6.621888603197341d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.625610117464785d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f136ceae8c"+ "'", var8.equals("f136ceae8c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 14.376050182339275d);
// 
//   }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test18"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var26 = var14.getStandardDeviation();
//     double var28 = var14.probability(0.06468609490798712d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 26.41790872611167d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "98e15af61d"+ "'", var8.equals("98e15af61d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1822);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.012732940441362056d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-0.5002028444398587d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.16535574048640247d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.3903549312082069d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.7740996449567269d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
// 
//   }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test19"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.sample();
//     double var5 = var0.getNumericalMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.925960459757085d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test20"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(99.99999f, (-297258196));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test21"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 10.0f);
    var3.addElement(0.15729920705028488d);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var8, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var7, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var6, (java.lang.Object[])var9);
    boolean var13 = var3.equals((java.lang.Object)var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var14 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test22"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)4.652627453922398d, (java.lang.Number)1.2042143530169682d, false);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test23"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.7837596368719411d, (java.lang.Number)14.964199219520955d, (java.lang.Number)0.007740528947110199d);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test24"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(2.8E-45f, 1.1368686E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.8E-45f);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test25"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(18.88681913748533d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.6630926368539996d);

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test26"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var3.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
//     java.lang.Class var8 = var7.getDeclaringClass();
//     int var9 = var7.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5, var7);
//     org.apache.commons.math3.random.RandomGenerator var11 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5, var11);
//     org.apache.commons.math3.random.RandomGenerator var13 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5, var13);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var18 = var16.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var20 = var19.getTiesStrategy();
//     java.lang.Class var21 = var20.getDeclaringClass();
//     int var22 = var20.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18, var20);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var24 = var23.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var25.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var27 = var25.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var28 = var25.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var29 = var25.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var31 = var30.getTiesStrategy();
//     boolean var33 = var31.equals((java.lang.Object)Double.POSITIVE_INFINITY);
//     boolean var35 = var31.equals((java.lang.Object)(-0.4255538433808183d));
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var36 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var29, var31);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var37 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var24, var31);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var38 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var5, var31);
//     double[] var42 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var43 = new org.apache.commons.math3.util.ResizableDoubleArray(var42);
//     org.apache.commons.math3.distribution.NormalDistribution var44 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var45 = var44.getStandardDeviation();
//     double[] var47 = var44.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var48 = new org.apache.commons.math3.util.ResizableDoubleArray(var47);
//     int var49 = var48.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var50 = var48.copy();
//     var48.addElement((-0.43408597923864894d));
//     double var54 = var48.getElement(0);
//     double[] var55 = var48.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var56 = new org.apache.commons.math3.util.ResizableDoubleArray(var55);
//     double var57 = var38.mannWhitneyU(var42, var55);
//     double[] var58 = var2.rank(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == (-1.434974079204705d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 3.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test27"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)3.222124647715011E8d);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test28"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.7618964568626004d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8662360858630441d);

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test29"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(7.492701067417301d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test30"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("868bdb3884");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test31"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(10775);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test32"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     double var9 = var0.nextGamma(9.319248049587957d, (-0.4255538433808183d));
//     long var11 = var0.nextPoisson(0.9978516012375751d);
//     int var14 = var0.nextZipf(8941, 1.445343853698748d);
//     java.lang.String var16 = var0.nextHexString(3826);
//     double var19 = var0.nextUniform(3.6686154783610574d, 6.481650533373194d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4.976180543073804d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-2.6159843945565986d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "7f3682c14258dd8480622b23bc11ead54a1c0f5c12bacc29f8aa9949e2362caa469890f1dc48eca1f01cc65511200050d99df552b56508dccb541e0fc8f4aa1c8f5de429e7197ffb19d114b03e99bcca95adb4ed03451fb69a75c76caffa3e1b23f7ed71953e1ce8aa3e6bc2396a39efa23cabe1ac9520e19ad8b168920c054f8ee5d9bd72bf022a176e47c8197f3a7a5767aa83dbf9bb74ec049ab481a7feda8a10f2037dc087d96b36dbf256a29e656c04c1d90e1613d3a788e223a72d89f9cac2a88f2368691ea1291688c9c328effbde499524e2b49fef908cc5f28fb786eb3bd3d93602a2d41e04df0fa7709d2cda54e1168b5b5f2512fcc0634934a6a0066b4fbeb7e4f70149ebac6e9657d6218e1b1c17b617d59e58dbbefc9834574bdce753650c09047e624fea7032db1f2bb055262637b70c896b708a5636c524447d61fbb762ccb5360a48919b578772bf97012ba1b852e326328a40d84e2c6412127cfb819861344bcc37c0847f5efad2678d61b3080745157e60cd09dbc0c04a3337debdc3b16dc9345c41a284979d5450c573a366b3c6eb6e0b4847c1a7856c04004262e519366a79471931221b5e02f5378205fc5fa8a6951094d729aabc01e1250e5aaa427624bb3b70e3d95b8237b4ab45c6ac0096241a39bccab781c7fa9e32b4381529ecb8fa0df055a9bc653fd2fc0232b1f3478a85c0c7ce50b8d74000be79eaa5b76a40d991480b1a8127b7d005b36e09d757efcf15670e74da2cef0b12dcdfbc9a95b0aaca3fc6f875d6a637946995e4e05edd00f9813d4b3c73d69a87c7658ebc847110f09d7acc97ebb88e90dd94fceeb8d8bdbc6e119634cb4bab42249b6ca8301e8c7697fcc815c42a9a08de30c156c4d68d40ec53e760392bf64421bce2188e62a2da37eac02342cb75e83760059c338dcef57a710d37de56b987a6b05c2f5e4cbc7db065bcdab974630a561d304773f4122e70db146289539841d4d9bc45926b09c0b7f1345ba4b37da9f445cfe520878b324a69c28104aa98df7cc53a1bebe5beeaef43417f843f3fb4a2af072059b9da51314915e053ae1265ecc4e40f3f5069126d1d4cb5039ae5e320efd577178f3c165954ddd0f4e553c820c722a4558afdad219603cab34edf641dbd211a2589b8859c3a9216a930cd24b2b539d22b2d43031cd47ae25b37df117b64ce794fa80d3224779df5a045e92ddab481d355938a2fce273c2898003e7aa0b30bea3355921932d9ea8f90dc56ebf5f46db2b08420799493d05f420ea5b0df5fc2b571d5eb28469651f09af5d3aca0c8ecf1372e014f2d7b07765051eff21d7b63cdc8bda64088ec39d5c194329d75fb69277ae04950a6d1da9e0d6a1f10f68b3a09ac8a87e8580d6c65acd0fc5c8e929c9d93c10b720ee6ae67fe48dafc349b980d48403bfb65a9497e9864a776669f8989beece5f69f227f2138afd986d0a0575e4d23b47bf2044033c8effa1b329969e0d4986420a779f6654c3d28577b0f08fb3bac531a60d851a6331d2842e33df9d361790adf301d7ecc860ed5ea6a0195e4087512a346330ebefccbb8354b4506ab64bce96d8b0c07a29ba6512c36fe6624903623c05b5aa9ce4bd69551837b74b80395cf0790ca659e25fdf205ac86634aec4ae85e163890b709fa625f037c46e2e2b4a695f16fa822f20d3ad057f27dee1aed4ffe1e1d989fd943202d28328cc0941bb3e9b6298c04d9be557b364faeb872be8454a358fc1dd8560e7ac0a527ed944ade8a2c4729c61d0132c692270cbdea1632ad906ec3f17c215604a135419a97f88ef5d746dcdfbe6bcd9adc95c9b56c4c88df78143f230a6659a0273d8b435ea3060c544dd07cc244a79a1f632412bd4971ab800624acdacbdd505ded07c471fde819dc0909057c4c219c6809d3b2934987134dffadcc33d2c51907044ce10df112f936eedaa4b4614a7967c643b4f52bef21b6d4652a7328bbe0f6025a98989f142eba5c347e6589cd7f2e3ecc3859630209491b381ee78cbb92f74416f0c16690b8f6ca544bd9e28f26c1ef88f6c0b6d7c3496c8a62e47b2442bc2d33190b260c59e310a193b5bf6d51aec3698994f1b8a4a9a0b274504925f285125b5f69cc5413f8251ae6354413744fe1b2a0b3b74d7495edcaef2487c6bd3b31409bf85bd3b06b153f4b89c7492755707787821faf7966cbbdec7430a63e2369428c784a60cf0ccd65ba893515f4b4339ff8b99ea547c05624fb9f5db3b85994c406e9668f356ad462033978fa04b9ea8a64fa50a04cb73066970a3ceabaf43e1b834fbbc2afe265ecbe0a0ae11dfd4afdec7407358dc07a8aca914022c32a1bf25b165fdb6e1c4dcfe200338dfb7b0c4c61011056a08360fc1d32ea596293bf03321a8b55b2693125161e9fd6027109d9fbbcf0817001fad2dbdb8e93d4b7bc80d2bac4fbdaeef0babeccc24627b3833ffcbbbf0d99af8b45bb9b89419a46b5e75224c7d7e3760923d8226f9067d010f36df7a9a729ca0fc4332444551c716ae04dc59346e89dab0902f988896175e730c61e7c5093a6723c7a2f2886bf7b301370d28cb9bd57013bff02a9fb10765c99b4b2e84391f858868056f195415e828f39828ccb7bb6d5b0afee5ebbbcc5e33cebacd54f65ed98fde0f4730fa65500ad512cb67c1c8c35688c911f1b3e7ef300dabdc9fa"+ "'", var16.equals("7f3682c14258dd8480622b23bc11ead54a1c0f5c12bacc29f8aa9949e2362caa469890f1dc48eca1f01cc65511200050d99df552b56508dccb541e0fc8f4aa1c8f5de429e7197ffb19d114b03e99bcca95adb4ed03451fb69a75c76caffa3e1b23f7ed71953e1ce8aa3e6bc2396a39efa23cabe1ac9520e19ad8b168920c054f8ee5d9bd72bf022a176e47c8197f3a7a5767aa83dbf9bb74ec049ab481a7feda8a10f2037dc087d96b36dbf256a29e656c04c1d90e1613d3a788e223a72d89f9cac2a88f2368691ea1291688c9c328effbde499524e2b49fef908cc5f28fb786eb3bd3d93602a2d41e04df0fa7709d2cda54e1168b5b5f2512fcc0634934a6a0066b4fbeb7e4f70149ebac6e9657d6218e1b1c17b617d59e58dbbefc9834574bdce753650c09047e624fea7032db1f2bb055262637b70c896b708a5636c524447d61fbb762ccb5360a48919b578772bf97012ba1b852e326328a40d84e2c6412127cfb819861344bcc37c0847f5efad2678d61b3080745157e60cd09dbc0c04a3337debdc3b16dc9345c41a284979d5450c573a366b3c6eb6e0b4847c1a7856c04004262e519366a79471931221b5e02f5378205fc5fa8a6951094d729aabc01e1250e5aaa427624bb3b70e3d95b8237b4ab45c6ac0096241a39bccab781c7fa9e32b4381529ecb8fa0df055a9bc653fd2fc0232b1f3478a85c0c7ce50b8d74000be79eaa5b76a40d991480b1a8127b7d005b36e09d757efcf15670e74da2cef0b12dcdfbc9a95b0aaca3fc6f875d6a637946995e4e05edd00f9813d4b3c73d69a87c7658ebc847110f09d7acc97ebb88e90dd94fceeb8d8bdbc6e119634cb4bab42249b6ca8301e8c7697fcc815c42a9a08de30c156c4d68d40ec53e760392bf64421bce2188e62a2da37eac02342cb75e83760059c338dcef57a710d37de56b987a6b05c2f5e4cbc7db065bcdab974630a561d304773f4122e70db146289539841d4d9bc45926b09c0b7f1345ba4b37da9f445cfe520878b324a69c28104aa98df7cc53a1bebe5beeaef43417f843f3fb4a2af072059b9da51314915e053ae1265ecc4e40f3f5069126d1d4cb5039ae5e320efd577178f3c165954ddd0f4e553c820c722a4558afdad219603cab34edf641dbd211a2589b8859c3a9216a930cd24b2b539d22b2d43031cd47ae25b37df117b64ce794fa80d3224779df5a045e92ddab481d355938a2fce273c2898003e7aa0b30bea3355921932d9ea8f90dc56ebf5f46db2b08420799493d05f420ea5b0df5fc2b571d5eb28469651f09af5d3aca0c8ecf1372e014f2d7b07765051eff21d7b63cdc8bda64088ec39d5c194329d75fb69277ae04950a6d1da9e0d6a1f10f68b3a09ac8a87e8580d6c65acd0fc5c8e929c9d93c10b720ee6ae67fe48dafc349b980d48403bfb65a9497e9864a776669f8989beece5f69f227f2138afd986d0a0575e4d23b47bf2044033c8effa1b329969e0d4986420a779f6654c3d28577b0f08fb3bac531a60d851a6331d2842e33df9d361790adf301d7ecc860ed5ea6a0195e4087512a346330ebefccbb8354b4506ab64bce96d8b0c07a29ba6512c36fe6624903623c05b5aa9ce4bd69551837b74b80395cf0790ca659e25fdf205ac86634aec4ae85e163890b709fa625f037c46e2e2b4a695f16fa822f20d3ad057f27dee1aed4ffe1e1d989fd943202d28328cc0941bb3e9b6298c04d9be557b364faeb872be8454a358fc1dd8560e7ac0a527ed944ade8a2c4729c61d0132c692270cbdea1632ad906ec3f17c215604a135419a97f88ef5d746dcdfbe6bcd9adc95c9b56c4c88df78143f230a6659a0273d8b435ea3060c544dd07cc244a79a1f632412bd4971ab800624acdacbdd505ded07c471fde819dc0909057c4c219c6809d3b2934987134dffadcc33d2c51907044ce10df112f936eedaa4b4614a7967c643b4f52bef21b6d4652a7328bbe0f6025a98989f142eba5c347e6589cd7f2e3ecc3859630209491b381ee78cbb92f74416f0c16690b8f6ca544bd9e28f26c1ef88f6c0b6d7c3496c8a62e47b2442bc2d33190b260c59e310a193b5bf6d51aec3698994f1b8a4a9a0b274504925f285125b5f69cc5413f8251ae6354413744fe1b2a0b3b74d7495edcaef2487c6bd3b31409bf85bd3b06b153f4b89c7492755707787821faf7966cbbdec7430a63e2369428c784a60cf0ccd65ba893515f4b4339ff8b99ea547c05624fb9f5db3b85994c406e9668f356ad462033978fa04b9ea8a64fa50a04cb73066970a3ceabaf43e1b834fbbc2afe265ecbe0a0ae11dfd4afdec7407358dc07a8aca914022c32a1bf25b165fdb6e1c4dcfe200338dfb7b0c4c61011056a08360fc1d32ea596293bf03321a8b55b2693125161e9fd6027109d9fbbcf0817001fad2dbdb8e93d4b7bc80d2bac4fbdaeef0babeccc24627b3833ffcbbbf0d99af8b45bb9b89419a46b5e75224c7d7e3760923d8226f9067d010f36df7a9a729ca0fc4332444551c716ae04dc59346e89dab0902f988896175e730c61e7c5093a6723c7a2f2886bf7b301370d28cb9bd57013bff02a9fb10765c99b4b2e84391f858868056f195415e828f39828ccb7bb6d5b0afee5ebbbcc5e33cebacd54f65ed98fde0f4730fa65500ad512cb67c1c8c35688c911f1b3e7ef300dabdc9fa"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 5.395793782742915d);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test33"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(4.000957110763316d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2837463693920309d);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test34"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(14.146757422288392d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.500226134058648d);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test35"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(6.841953917352447d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.0d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test36"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double[] var3 = var0.sample(10);
    double var4 = var0.getStandardDeviation();
    double var6 = var0.density(2.345330933436551d);
    var0.reseedRandomGenerator(10L);
    double var10 = var0.inverseCumulativeProbability(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.025496167636629936d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.NEGATIVE_INFINITY);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test37"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(0, 317);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test38"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.9999999f, 2.3841864E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.3841864E-7f);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test39"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1541);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1541);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test40"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(1962, 2.5000005f, 9.536744E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test41"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(20355937, 408490575);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-388134638));

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test42"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-1.5157441040969926d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5553328321084564d);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test43"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextSecureInt(0, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 17.466985082833986d);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test44"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(32.513321074988696d, 0.8998293095978018d, 0.0d, 77);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test45"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(99.99999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.6293945E-6f);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test46"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)2.1424092671303407d);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test47"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-1.1739977629570804d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3091286446619527d);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test48"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9999997887160175d);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test49"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(77, 10743);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test50"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(1600L, 193L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1600L);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test51"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    double[] var6 = var4.getInternalValues();
    org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var8 = var7.getStandardDeviation();
    double[] var10 = var7.sample(1);
    double var11 = var7.getMean();
    double[] var13 = var7.sample(100);
    var4.addElements(var13);
    int var15 = var4.getExpansionMode();
    double[] var16 = var4.getInternalValues();
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var17.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var20 = var17.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var17.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    org.apache.commons.math3.distribution.NormalDistribution var23 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var24 = var23.getStandardDeviation();
    double[] var26 = var23.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(var26);
    org.apache.commons.math3.exception.util.Localizable var28 = null;
    org.apache.commons.math3.exception.util.Localizable var29 = null;
    org.apache.commons.math3.exception.util.Localizable var30 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var31 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var32 = new org.apache.commons.math3.exception.NullArgumentException(var30, (java.lang.Object[])var31);
    org.apache.commons.math3.exception.MathInternalError var33 = new org.apache.commons.math3.exception.MathInternalError(var29, (java.lang.Object[])var31);
    org.apache.commons.math3.exception.NullArgumentException var34 = new org.apache.commons.math3.exception.NullArgumentException(var28, (java.lang.Object[])var31);
    boolean var35 = var27.equals((java.lang.Object)var28);
    var27.addElement(20.696514663540924d);
    double var39 = var27.substituteMostRecentElement((-1.84544373783414d));
    java.lang.Object var40 = null;
    boolean var41 = var27.equals(var40);
    var27.setElement(100, 0.0d);
    double[] var45 = var27.getInternalValues();
    double[] var46 = var22.rank(var45);
    var4.addElements(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test52"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var3 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)(-1), (java.lang.Object[])var3);
//     org.apache.commons.math3.exception.NullArgumentException var5 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var3);
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     java.lang.Number var10 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var12 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var8, (java.lang.Number)0.777695809106093d, var10, true);
//     java.lang.Throwable[] var13 = var12.getSuppressed();
//     org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var7, (java.lang.Object[])var13);
//     org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, (java.lang.Object[])var13);
// 
//   }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test53"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     var4.contract();
//     double[] var6 = var4.getInternalValues();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var8 = var7.getTiesStrategy();
//     java.lang.Class var9 = var8.getDeclaringClass();
//     java.lang.Class var10 = var8.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var13 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     boolean var16 = var14.isSupportUpperBoundInclusive();
//     double[] var18 = var14.sample(100);
//     org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var19.reseedRandomGenerator(2L);
//     double[] var23 = var19.sample(100000);
//     double var24 = var13.mannWhitneyUTest(var18, var23);
//     org.apache.commons.math3.distribution.NormalDistribution var25 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double[] var27 = var25.sample(1910);
//     org.apache.commons.math3.distribution.NormalDistribution var28 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var29 = var28.getStandardDeviation();
//     double[] var31 = var28.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var32 = new org.apache.commons.math3.util.ResizableDoubleArray(var31);
//     double[] var33 = var32.getElements();
//     double var34 = var13.mannWhitneyUTest(var27, var33);
//     double[] var35 = var11.rank(var33);
//     var4.addElements(var33);
//     org.apache.commons.math3.util.ResizableDoubleArray var37 = new org.apache.commons.math3.util.ResizableDoubleArray(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.8448592018599629d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0.17283109941283925d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test54"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var3 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var4 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var6.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test55"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(2278.7115374561713d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 39.771019031792285d);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test56"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(889);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 889);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test57"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    int var2 = var1.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var1.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test58"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.8024710330055997d, (java.lang.Number)1.0d, true);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test59"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.5d, (java.lang.Number)7.724435900937391d, (java.lang.Number)363.7393755555636d);
    java.lang.Number var4 = var3.getHi();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 363.7393755555636d+ "'", var4.equals(363.7393755555636d));

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test60"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(1865, 11531);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 21505315);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test61"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(6);
    var1.addElement(0.09549600483812275d);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test62"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(6.796653963038409d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 893.848081958187d);

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test63"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(18.827809487697202d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test64"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-0.6991346750676082d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test65"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(2.773881834450058d, 2.8060243873247024d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.8060243873247024d);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test66"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(2097152.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test67"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("422f74139a337e1fd57b66cf6c8a46f8a02a05afb02fdf163a948c214d2f9cd6642885559b4959e8929a95b9f86ad556c866", "951f5f6788");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9109297011310907d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ffa398c582"+ "'", var8.equals("ffa398c582"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1864);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test68"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("dc6d8d9237e055b89d16785fe3bb81d5022166d34f8084e20aefa1349e74be13f4dd48de1f6abcc0c6e00d71e332a62af6f5ade2a0e6d2f15081028bb677308c5b43970887672086e7f87102875961a7204928e567afe3c4f2cd838ecf3feae14745adcb64f7106203918882eea23c0a9b684b3a140a2f64c4ea88cb85d5eec25f1a17832747c55965a599e1d642163e67a97eed2bf7626447c76dbf319a764cc54a7c5b38f2d5dc7af66fb68957af27aaecc4cae51c7e7511ccd84665a800b9f5eeb003c192977843db9365d7f49e41fefa5cb14d9275ed21b6c4ae029f1d097ca2dfb7384ab5c73b36abe7ee7b132879d6d5fbfd01658e52c8e99429fd9a6baf2908a6d181362ae7a9c15f0d999bdcbb46ebc03610046bb4e86af5d2905baa9906f49074063ec2c095b34225e307cfa77ab23e44999e445b35cb4f843c439a4d3e7bd032ec932e4d32383697b75106021ac3e8944a4358d6deed6491dcd70932138924f9460f379f7fe02f5e0f738de230e4ce97d346f02c539167343d116acc1d321f035f173d45cc55163c11753ecd5d6a31072b751ca17d5eb6cd7131d44b5066fc7afba2e95f28c14413e0cff47f1f4e6a89b9aae8f807a7d0c16dd7ecd9b07a013001fee1cec4ebcb8d1571b0f95993979ee0f32f49c4f86f81b9a50776350836825d461f7cc3f7e00546b6d13d0f8e9db36b7012929214a2e3f1c25ad28325adc7bf07911d8cb4c11b338ee6a7e7bae3123d869eb4f790f5d5d8c9e010489baaa47b1caef5f5cba10250c9661ea92cb90f2c99064aef3f2df75cff3cbc2514e2218cbbeb6a408d072a6e79849c0ddbd52e70a4c976500c5d1197a7737b619dc816a97a40deae6e706066070fa322f41792dd1dea89ad6393dcac7febfa6dead7ea6f1655e2111411d90c477bd39825ede123d60aae7e08a6cece1cc2e53a6808d65b7084b2cee79eaa35769eb5bf5a321f98e6d313e0c17a053f554fe60aa2082e59fdf07994eec41077788fd8fa518891e6d66770d1716795318392e9bad77e377b2bd6390fce7c4ddaf0372dd74fe75fb553213dd70154fe9c985aa20d6498d85b6d931bc56cbc251bc9aedd4a9d83c0763c13594a7cccae1fa6269ed89d4b61b9e475b89fba011a88741077baaa7c0841d0e24801d67847b0ca02712baf4c7080627370d783b6e52df63d79ec4b000e406b2b867e4a1a0fa3d60bbced77e846e802f03ca185e750e75f30fb86c8bd4de0a499962a60a53a5c207f7067618a2235fc97ba2b6925afce4ac693779867e9c9357aafaf55de41f2725b8fe1d00ba2d9bb8d786de89d06cfbc7f8bbfad63e6b4e2cc18357ceef7cf");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test69"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(4.714973937685568d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7579555786513725d);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test70"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.4000591571530008d, (java.lang.Number)8, (java.lang.Number)(-2.225482993439564d));
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2.7589241763811208d, (java.lang.Number)1.1752011936438014d, true);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var9 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var8, var9);
    var3.addSuppressed((java.lang.Throwable)var7);
    boolean var12 = var7.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test71"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    boolean var2 = var0.isSupportUpperBoundInclusive();
    double[] var4 = var0.sample(100);
    double var5 = var0.getStandardDeviation();
    double var6 = var0.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.NEGATIVE_INFINITY);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test72"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     double var9 = var0.nextF(2.281783181607902d, 0.8427007929497151d);
//     double var12 = var0.nextGaussian(1.5498468927479463d, 1865.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextPascal(657, 1323.2753805972895d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 26.06581800056942d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 21.081413664698157d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1337.834071922932d));
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test73"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-0.7259417724656707d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.470364493873876d));

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test74"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1, 10240);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10241);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test75"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var21 = var18.nextSecureLong((-1L), 1L);
//     double var24 = var18.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var26 = var18.nextSecureHexString(100);
//     double var28 = var18.nextT(20.696514663540924d);
//     org.apache.commons.math3.distribution.NormalDistribution var29 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var30 = var29.getStandardDeviation();
//     double[] var32 = var29.sample(1);
//     double var33 = var29.getMean();
//     double[] var35 = var29.sample(100);
//     double var36 = var29.sample();
//     double var37 = var29.sample();
//     double var38 = var18.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     double var39 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     org.apache.commons.math3.distribution.NormalDistribution var40 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var41 = var40.getStandardDeviation();
//     double[] var43 = var40.sample(1);
//     double var44 = var40.getMean();
//     double[] var46 = var40.sample(100);
//     double var47 = var40.sample();
//     double var48 = var40.sample();
//     var40.reseedRandomGenerator(10L);
//     boolean var51 = var40.isSupportLowerBoundInclusive();
//     boolean var52 = var40.isSupportLowerBoundInclusive();
//     double var53 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var40);
//     boolean var54 = var40.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10.857518226018453d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "0697a756357b63f43dab9d913f56e795a0640e5917673c2a62cea41006a5133df6045c1aebd8613d34c86e31ccfc005f0ec3"+ "'", var8.equals("0697a756357b63f43dab9d913f56e795a0640e5917673c2a62cea41006a5133df6045c1aebd8613d34c86e31ccfc005f0ec3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.1248973397812645d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.0021192739250195d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "48f1999eb060a4a05ae91bb364ef9da90a29baa379a30565d9615b3102b74a61cfa7134fa507e9bc298916d2c183efae4d09"+ "'", var26.equals("48f1999eb060a4a05ae91bb364ef9da90a29baa379a30565d9615b3102b74a61cfa7134fa507e9bc298916d2c183efae4d09"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-0.8161399392524351d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0.28188208784793617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == (-0.4954181796575776d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == (-0.5977681008511015d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1.5145258052087136d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == (-0.1846122165435877d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == (-0.29195848409722047d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == (-0.1557414973394419d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test76"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2.3841864E-7f, 9886);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test77"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var6 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException(var4, (java.lang.Number)(-1), (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)3.1039797472520814d, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var15 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var11, (java.lang.Number)9.536743E-7f, (java.lang.Number)(-0.4255538433808183d), false);
    var10.addSuppressed((java.lang.Throwable)var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test78"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(1.1277576493105577d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8892632001722615d);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test79"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.3869506640453208d, 14.619556314198402d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999637717172d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test80"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(7.243371682042085d, 152.40959258449737d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 152.58161863441052d);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test81"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(1.5043245423323732d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5043245423323734d);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test82"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh((-36.7368005696771d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4.503599627370493E15d));

  }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test83"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var13 = var10.nextSecureLong((-1L), 1L);
//     double var16 = var10.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var18 = var10.nextHexString(10);
//     int var21 = var10.nextPascal(8899, 0.8219866295031046d);
//     double var23 = var10.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var25 = var24.getStandardDeviation();
//     double[] var27 = var24.sample(1);
//     double var28 = var24.getMean();
//     double[] var30 = var24.sample(100);
//     double var31 = var24.sample();
//     double var32 = var24.sample();
//     double var33 = var24.getStandardDeviation();
//     double var34 = var24.sample();
//     double var35 = var10.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     double var36 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var38 = var24.inverseCumulativeProbability((-1.2732919183123732d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 16.559873477869512d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "c07218bfb77e1bc230ef9eb1d1d5dd1ad676aeeed24d83f59f598fbb8a7074d87d72e2a0ee775d188824eb37f737dfe9409e"+ "'", var8.equals("c07218bfb77e1bc230ef9eb1d1d5dd1ad676aeeed24d83f59f598fbb8a7074d87d72e2a0ee775d188824eb37f737dfe9409e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 16.293319846864545d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "b04886b2a9"+ "'", var18.equals("b04886b2a9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1926);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.004864401162586462d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == (-0.5190904438430975d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == (-0.2075983742177674d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0.21449613607516008d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == (-0.026402874664440263d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == (-1.037738423746884d));
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test84"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var6, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var11 = var10.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var4, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var3, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.NullArgumentException var16 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathInternalError var17 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test85"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(657, (-519018850));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test86"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.257156203792693d, 0.5395119302779527d, 7.474932982660367d, 1541);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2359172532365034d);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test87"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(14.455221443139214d, 401.1937260392793d, (-26.317433148677743d), 2187);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test88"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    boolean var7 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator((-16L));
    double var11 = var0.cumulativeProbability(0.0d);
    boolean var12 = var0.isSupportLowerBoundInclusive();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var0.cumulativeProbability(7.788896578666913d, (-0.03314181870292297d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test89"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.addElement(0.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var6.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var6.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var6.getElement(14273996);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test90"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(3.0382740325466986d, (-5.012870905106836d), (-12.669478029470282d), 1935);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test91"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)8L, (java.lang.Number)(-0.008040944195450915d), (java.lang.Number)0.9170148503640131d);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test92"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.014931963725887733d, (java.lang.Number)6.173137535617105d, false);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test93"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.discardMostRecentElements(1);
    int var15 = var4.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = var4.copy();
    double[] var17 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    var18.contract();
    boolean var20 = var16.equals((java.lang.Object)var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test94"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(17.042216286603484d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.5297004194695996d);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test95"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double[] var15 = var4.getElements();
    double var17 = var4.substituteMostRecentElement(0.00486995642275377d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var19 = var4.getElement((-127));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 20.696514663540924d);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test96"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(3.7817178733294683d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3024322368447901d);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test97"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.384186E-7f, 0.040983878133039366d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.3841864E-7f);

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test98"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     double var11 = var0.nextUniform(1.9243072677253843d, 7.362895734466076d);
//     var0.reSeedSecure(64L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("f21e47d4b40d8ad54009e94628443bcaf119c5d544f14e9d95c6b6c8b2ef30cdf44e3429600f679832edf17c4f2c0af3557e", "21d0b53dc9");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.854580750171491d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5a23db0d994ed5700a14b368c44d8ef2866ac2d0adf103c157a33f077dfe5a6e5d10be055a989c5a4a0388d55dfc39836366"+ "'", var8.equals("5a23db0d994ed5700a14b368c44d8ef2866ac2d0adf103c157a33f077dfe5a6e5d10be055a989c5a4a0388d55dfc39836366"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4.094007002568118d);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test99"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(1344L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1344L);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test100"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(31L, 323);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6379912561590279263L);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test101"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getSupportUpperBound();
//     double[] var3 = var0.sample(10);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var7 = var6.getStandardDeviation();
//     double[] var9 = var6.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
//     int var11 = var10.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var12 = var10.copy();
//     var10.addElement((-0.43408597923864894d));
//     double var16 = var10.getElement(0);
//     var10.clear();
//     org.apache.commons.math3.distribution.NormalDistribution var18 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var19 = var18.getStandardDeviation();
//     double[] var21 = var18.sample(1);
//     double var22 = var18.getMean();
//     double[] var24 = var18.sample(100);
//     var10.addElements(var24);
//     org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
//     var4.addElements(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.24158146820013862d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test102"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var8 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var4, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathArithmeticException var13 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test103"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(2.3841864E-7f, 2.384186E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.3841864E-7f);

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test104"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     var0.reSeedSecure();
//     double var10 = var0.nextGamma(0.9870467554527248d, 3.1173466159040992d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextBinomial((-20), 0.026208459687631067d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.3955016189256086d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5646645559419596d);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test105"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(45.302715014579164d, 0.8147655203522769d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test106"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(39916800L, 23342337775350L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 39916800L);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test107"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(189);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test108"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var5 = new org.apache.commons.math3.exception.OutOfRangeException(var2, (java.lang.Number)2.3841858E-7f, (java.lang.Number)(byte)0);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test109"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(1.500226134058648d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9661320315433753d);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test110"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    java.lang.Class var6 = var4.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    java.lang.String var8 = var4.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    java.lang.String var10 = var2.name();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    java.lang.Class var16 = var14.getDeclaringClass();
    boolean var18 = var14.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
    java.lang.Class var23 = var22.getDeclaringClass();
    java.lang.String var24 = var22.toString();
    java.lang.String var25 = var22.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var22);
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var22);
    int var28 = var22.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "MAXIMAL"+ "'", var10.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "AVERAGE"+ "'", var24.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "AVERAGE"+ "'", var25.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 3);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test111"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.7694320094117615d);

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test112"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     double var12 = var0.nextGamma(4.950886585270677E-4d, 1.5703107297735257d);
//     double var15 = var0.nextCauchy(4.625610117464785d, 0.993405468012823d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 13.413689499681306d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3.1512452982845316E-206d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2.989763698395241d);
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test113"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1348L, (-1073741824L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1073740476L));

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test114"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0L, (-1073740476L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test115"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-0.1557414973394419d), 0.17971249487899976d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1557414973394419d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test116"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, (-0.5169964470868834d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.4E-45f));

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test117"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 10.0f);
    var2.addElement(0.010050166663333094d);
    int var5 = var2.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var2.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionFactor(9.536745E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test118"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = null;
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var8);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 11L);
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    java.math.BigInteger var15 = null;
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 0L);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, var17);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 1949);
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, var20);
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 8904);
    java.math.BigInteger var24 = null;
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 0L);
    java.math.BigInteger var27 = null;
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var27, 0L);
    java.math.BigInteger var30 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, var29);
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 11L);
    java.math.BigInteger var33 = null;
    java.math.BigInteger var35 = org.apache.commons.math3.util.ArithmeticUtils.pow(var33, 0L);
    java.math.BigInteger var36 = null;
    java.math.BigInteger var38 = org.apache.commons.math3.util.ArithmeticUtils.pow(var36, 0L);
    java.math.BigInteger var39 = org.apache.commons.math3.util.ArithmeticUtils.pow(var35, var38);
    java.math.BigInteger var41 = org.apache.commons.math3.util.ArithmeticUtils.pow(var35, 11L);
    java.math.BigInteger var42 = null;
    java.math.BigInteger var44 = org.apache.commons.math3.util.ArithmeticUtils.pow(var42, 0L);
    java.math.BigInteger var45 = null;
    java.math.BigInteger var47 = org.apache.commons.math3.util.ArithmeticUtils.pow(var45, 0L);
    java.math.BigInteger var48 = org.apache.commons.math3.util.ArithmeticUtils.pow(var44, var47);
    java.math.BigInteger var50 = org.apache.commons.math3.util.ArithmeticUtils.pow(var48, 1949);
    java.math.BigInteger var51 = org.apache.commons.math3.util.ArithmeticUtils.pow(var41, var50);
    java.math.BigInteger var52 = org.apache.commons.math3.util.ArithmeticUtils.pow(var32, var50);
    java.math.BigInteger var53 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, var52);
    org.apache.commons.math3.exception.OutOfRangeException var54 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1260, (java.lang.Number)0.12953442899394188d, (java.lang.Number)var53);
    java.lang.Number var55 = var54.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test119"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test120"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test121"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(13L, 64L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 832L);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test122"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    var1.addElement(2.0216852347077916d);
    org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var5 = var4.getStandardDeviation();
    double[] var7 = var4.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var12 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var11, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var10, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var9, (java.lang.Object[])var12);
    boolean var16 = var8.equals((java.lang.Object)var9);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var8);
    var1.addElement(0.9996270344745914d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test123"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    var1.addElement(2.0216852347077916d);
    org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var5 = var4.getStandardDeviation();
    double[] var7 = var4.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var12 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var11, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var10, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var9, (java.lang.Object[])var12);
    boolean var16 = var8.equals((java.lang.Object)var9);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var8);
    int var18 = var1.start();
    org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var20 = var19.getStandardDeviation();
    double[] var22 = var19.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    org.apache.commons.math3.exception.util.Localizable var24 = null;
    org.apache.commons.math3.exception.util.Localizable var25 = null;
    org.apache.commons.math3.exception.util.Localizable var26 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var27 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var28 = new org.apache.commons.math3.exception.NullArgumentException(var26, (java.lang.Object[])var27);
    org.apache.commons.math3.exception.MathInternalError var29 = new org.apache.commons.math3.exception.MathInternalError(var25, (java.lang.Object[])var27);
    org.apache.commons.math3.exception.NullArgumentException var30 = new org.apache.commons.math3.exception.NullArgumentException(var24, (java.lang.Object[])var27);
    boolean var31 = var23.equals((java.lang.Object)var24);
    var23.setElement(8899, 2.3930658372149933d);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var23);
    org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var36);
    float var38 = var36.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 2.0f);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test124"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1868, 9181);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 11049);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test125"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.683999519410136d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.981788102829491d);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test126"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(456.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0246701172301718d);

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test127"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(0L);
//     long var17 = var0.nextPoisson(7.769493748166378d);
//     double var20 = var0.nextCauchy(2.3844973909690124d, 1.5958068268285657d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var22 = var0.nextPoisson((-2.9263858980416066d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15.467246982755576d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "92e453d63a"+ "'", var8.equals("92e453d63a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.4920397263329566d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 9846);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.312485139643675d);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test128"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(1972, (-454));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2426);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test129"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(4.810477380965351d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2309711878897286d);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test130"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double[] var3 = var0.sample(10);
    double var4 = var0.getStandardDeviation();
    double var5 = var0.getStandardDeviation();
    boolean var6 = var0.isSupportConnected();
    double var8 = var0.cumulativeProbability((-1.4664683179220708d));
    double var9 = var0.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.07126037312984851d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test131"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-2L), 760L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-762L));

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test132"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var2 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var3 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.MathArithmeticException var4 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test133"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)9.954021851066004d, (java.lang.Number)(-2), (java.lang.Number)0.9999494957997512d);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test134"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(21L, 9886);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5071615437313169417L);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test135"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(221578405, 11166);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 221578405);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test136"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(2187);
    int var2 = var1.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var1.copy();
    double var5 = var3.addElementRolling(0.8427007929497151d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test137"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(2.5000005f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test138"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(40422L, 40318L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test139"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(9066);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 73551.46387892697d);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test140"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.2040395048875416d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0638496266255846d);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test141"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    var0.reseedRandomGenerator(2L);
    double[] var4 = var0.sample(100000);
    double var5 = var0.getMean();
    var0.reseedRandomGenerator(1600L);
    double var9 = var0.probability(22.921701260427884d);
    double var10 = var0.getSupportLowerBound();
    boolean var11 = var0.isSupportUpperBoundInclusive();
    double var12 = var0.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test142"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("fb28aecd8f");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test143"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1344L, 1848);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test144"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getStandardDeviation();
//     double[] var13 = var10.sample(1);
//     double var15 = var10.cumulativeProbability(0.0d);
//     double var16 = var10.getSupportUpperBound();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     var0.reSeed();
//     double var21 = var0.nextGamma(0.0d, 6.621888603197341d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var24 = var0.nextBinomial(20355937, (-0.5829554842180134d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.577042839181731d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.8660428313561424d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test145"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("4b577424da");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test146"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-0.24400375803666813d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.2392738836991271d));

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test147"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.8095647691467661d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0495400714605962d);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test148"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(2.220446049250313E-16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test149"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(22.488113044724955d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 22L);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test150"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(5.147442998493695d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.999932391214571d);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test151"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.2040395048875416d, 0.0d, (-0.21714707451774387d), 337860);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test152"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var4.addElement((-0.43408597923864894d));
//     double var10 = var4.getElement(0);
//     double[] var11 = var4.getElements();
//     var4.addElement(21.0d);
//     var4.setNumElements(3);
//     org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var17 = var16.getStandardDeviation();
//     double[] var19 = var16.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
//     var20.contract();
//     int var22 = var20.getNumElements();
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var20);
//     var4.addElement(1.0258239749326856d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.17505375505910667d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test153"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.4992246854372801d, 4.392604795910704d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.49922468543728016d);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test154"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.1472442938099579d, (java.lang.Number)(-0.9283927923794728d), (java.lang.Number)0.14220936728216432d);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test155"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.setElement(1916, 152.40959258449737d);
    boolean var17 = var4.equals((java.lang.Object)0.7754771523956807d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.discardMostRecentElements(9194402);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test156"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-0.9226762801750023d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test157"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     double var11 = var0.nextUniform(1.9243072677253843d, 7.362895734466076d);
//     var0.reSeedSecure(64L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextBinomial((-519018850), 7.417442685503174d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 23.882284399353008d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "47d527c043a85fe7cc0b2577246c594a5b40f7c6b0b12dcbc3cffc6bc491417894500cdc2c99cda69775615a107c1449a1cf"+ "'", var8.equals("47d527c043a85fe7cc0b2577246c594a5b40f7c6b0b12dcbc3cffc6bc491417894500cdc2c99cda69775615a107c1449a1cf"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4.171147075608501d);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test158"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(2.172616570636548d, (-0.7490383304207238d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.172616570636548d));

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test159"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    java.lang.Class var16 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var14);
    boolean var19 = var14.equals((java.lang.Object)12185.029950707303d);
    java.lang.String var20 = var14.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test160"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    var4.addElement(14.031149057314524d);
    int var8 = var4.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test161"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.998614057997266d, (java.lang.Number)1.9243072677253843d, (java.lang.Number)2.548200099728448d);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test162"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.1861816512250563d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test163"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(136);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 136);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test164"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.0217091653372376d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test165"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var4.addElement((-0.43408597923864894d));
//     double var10 = var4.getElement(0);
//     double[] var11 = var4.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
//     double[] var13 = var12.getInternalValues();
//     double var15 = var12.substituteMostRecentElement((-0.7719096331877858d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.6110343852803757d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.43408597923864894d));
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test166"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)70L, (java.lang.Number)12.330475398334398d, false);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test167"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-2.368715742159256d), 0.009560404023090774d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.002264455567255741d);

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test168"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.9229025290830416d, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test169"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.08709771401391468d);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test170"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.6067002787417757d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 34.761365401314364d);

  }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test171"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextUniform(0.2577047455984825d, 13.770182159584014d);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 3.039212213752883d);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test172"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.9229025290830416d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test173"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.39542063198610805d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 21.131281759057803d);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test174"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextUniform(0.2577047455984825d, 13.770182159584014d);
//     long var6 = var1.nextPoisson(23.012289905639566d);
//     int var9 = var1.nextZipf(10178, 0.5950413774252329d);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var10.reseedRandomGenerator(2L);
//     double[] var14 = var10.sample(100000);
//     double var15 = var10.getMean();
//     double var16 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     org.apache.commons.math3.distribution.NormalDistribution var17 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var18 = var17.getStandardDeviation();
//     double[] var20 = var17.sample(1);
//     double var22 = var17.cumulativeProbability(0.0d);
//     double var23 = var17.getSupportUpperBound();
//     boolean var24 = var17.isSupportUpperBoundInclusive();
//     double var25 = var17.getStandardDeviation();
//     double var26 = var17.getStandardDeviation();
//     double var27 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var17);
//     double var29 = var17.cumulativeProbability(0.9198491443997944d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 6.529615211802063d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 18L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.6555563249192761d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.12423236470277398d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.8211742011485986d);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test175"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-8L));

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test176"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double var2 = var0.getMean();
    boolean var3 = var0.isSupportUpperBoundInclusive();
    double var4 = var0.getStandardDeviation();
    double var5 = var0.getNumericalVariance();
    boolean var6 = var0.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test177"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.6486773691008259d, (java.lang.Number)0.0021869535431851416d, false);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test178"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-0.11850575220980186d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test179"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     double var9 = var0.nextUniform(0.0d, 0.5382762305934016d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextUniform(1.5707963267948968d, (-0.05460705760283351d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.404806514114059d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.23183675868272263d);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test180"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma((-3.0302829572605017d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1093.4585771450825d);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test181"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.addElement(0.0d);
    var6.contract();
    int var10 = var6.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test182"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.clear();
    float var8 = var6.getExpansionFactor();
    var6.setContractionCriteria(2.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setExpansionMode(11274);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test183"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var18 = var0.nextPermutation(37, 173);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 21.562517802430545d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "78441532a8"+ "'", var8.equals("78441532a8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.4304074015696627d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 11261);
// 
//   }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test184"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(0.8109766711360142d);
//     double var5 = var1.nextT(2.1273833160569158d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.09545662227586584d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9409370488285718d);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test185"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(20.696514663540924d, (-0.7670545828181671d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.7670545828181671d));

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test186"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(67);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test187"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(1962, 1962);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1962);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test188"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-0.21079377391683451d), 0.204409469363068d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.21079377391683451d));

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test189"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.07307369578140543d, 8.867868873398907d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.8341724966700643d));

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test190"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test191"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextWeibull(7.769493748166378d, 1.2185657441986304d);
//     var0.reSeed(201600L);
//     double var11 = var0.nextGaussian(0.004492673238610562d, 2.5078368197853713d);
//     var0.reSeed(56L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var16 = var0.nextSecureLong(2702L, 2702L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.1143052929210997d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.2366575586410038d);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test192"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test193"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double[] var6 = var0.sample(100);
//     double var7 = var0.sample();
//     double var8 = var0.sample();
//     var0.reseedRandomGenerator(10L);
//     boolean var11 = var0.isSupportLowerBoundInclusive();
//     boolean var12 = var0.isSupportLowerBoundInclusive();
//     double var13 = var0.getMean();
//     double var14 = var0.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.474409494669181d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.2499259308357185d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test194"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(4L, 206L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-202L));

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test195"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(1.232595164407831E-32d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-8.112963841460668E31d));

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test196"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 11L);
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, var14);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 1949);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, var17);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 11L);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 1L);
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, 2147483647);
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, 2068);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test197"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     var0.reSeed();
//     double var15 = var0.nextChiSquare(7.617953921806563d);
//     double var17 = var0.nextExponential(1.5574077246549007d);
//     double var19 = var0.nextChiSquare(0.16043285994536435d);
//     double var23 = var0.nextUniform(0.0d, 1865.0d, true);
//     var0.reSeed(17L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var28 = var0.nextSecureInt(1891, 206);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9.732229183567819d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "102123b50f"+ "'", var8.equals("102123b50f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 10.748347601895881d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.9129303807679762d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.005901540937696641d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 390.76985165092105d);
// 
//   }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test198"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     var0.reSeed(100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var33 = var0.nextCauchy(0.2221670820445176d, (-1.5707963267948966d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.63041846901895d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "81c7d1f461"+ "'", var8.equals("81c7d1f461"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1975);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.00833577433652229d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.7021369143444105d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.5526902517652836d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.280983265129762d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-0.08581185456959825d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1.3962939541452606E-50d);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test199"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 720.0d);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test200"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     double var16 = var0.nextGamma(0.11604808277231957d, 0.8382617516745859d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextPascal(57, 2.478622967831918d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15.570243412716033d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "a03234f9e5"+ "'", var8.equals("a03234f9e5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.775108566164224d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 10811);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 4.3569561613583397E-4d);
// 
//   }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test201"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-0.5609650318917322d), (-1.8290460732017313d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test202"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(8.482253567196562d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2414.1593965507764d);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test203"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(1544L, 268435456L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1544L);

  }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test204"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var13 = var10.nextSecureLong((-1L), 1L);
//     double var16 = var10.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var18 = var10.nextHexString(10);
//     int var21 = var10.nextPascal(8899, 0.8219866295031046d);
//     double var23 = var10.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var25 = var24.getStandardDeviation();
//     double[] var27 = var24.sample(1);
//     double var28 = var24.getMean();
//     double[] var30 = var24.sample(100);
//     double var31 = var24.sample();
//     double var32 = var24.sample();
//     double var33 = var24.getStandardDeviation();
//     double var34 = var24.sample();
//     double var35 = var10.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     double var36 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     org.apache.commons.math3.distribution.NormalDistribution var37 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var38 = var37.getStandardDeviation();
//     boolean var39 = var37.isSupportUpperBoundInclusive();
//     double[] var41 = var37.sample(100);
//     double var42 = var37.getNumericalVariance();
//     double var43 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var37);
//     boolean var44 = var37.isSupportUpperBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.102000498440122d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "014554278f23e95e04f6905f3c1a264d7818d62d219748ee2022f604129279998844fba50fe103b7ea9fed315ebfeeb2ba5c"+ "'", var8.equals("014554278f23e95e04f6905f3c1a264d7818d62d219748ee2022f604129279998844fba50fe103b7ea9fed315ebfeeb2ba5c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 16.475510988377376d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "21183a66ab"+ "'", var18.equals("21183a66ab"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1960);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.0032266786368965877d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == (-1.2663122085618537d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1.6093509989546804d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0.3204734177704431d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == (-1.0712332264705697d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == (-0.13168601072456645d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1.3684997729910229d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
// 
//   }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test205"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.Class var8 = var7.getDeclaringClass();
    java.lang.Class var9 = var7.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var11);
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test206"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     int var11 = var0.nextZipf(5, 0.8273572477024794d);
//     double var14 = var0.nextGamma((-1.9235391122654637d), 6.774605976508678d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("8caa431381", "e36355d318");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 22.375202272495844d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "09e9eb2d6181fb5c8c3e1c06f74a0a83d0957ef8d754f4c66e7c73b75577bfc6f51bea5a6c0fd206c6b03a348f180620b598"+ "'", var8.equals("09e9eb2d6181fb5c8c3e1c06f74a0a83d0957ef8d754f4c66e7c73b75577bfc6f51bea5a6c0fd206c6b03a348f180620b598"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 21.4040345553054d);
// 
//   }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test207"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     var4.contract();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     float var7 = var4.getContractionCriteria();
//     double var9 = var4.addElementRolling(5.775578026902914E10d);
//     var4.addElement(0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.discardMostRecentElements(1868);
//       fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
//     } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.3186311322852706d);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test208"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-0.27927446711744686d));
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (-0.279) exceeded"+ "'", var2.equals("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (-0.279) exceeded"));

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test209"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test210"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 99.99999f, 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test211"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(260.89975491973144d, 1999);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test212"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-2.7546764176043674d));

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test213"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-79568300), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test214"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    int var6 = var1.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test215"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.setContractionCriteria(2.5f);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.discardFrontElements(9694);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test216"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(2.384186E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.384186E-7f);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test217"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double var3 = var0.inverseCumulativeProbability(0.9999999999928669d);
    boolean var4 = var0.isSupportConnected();
    var0.reseedRandomGenerator(13L);
    double var9 = var0.cumulativeProbability(1.3685539292803346d, 3.222124647715011E8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 6.755176609774487d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.08556937673988257d);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test218"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(2.5000005f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5000005f);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test219"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(7, 1960);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test220"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(1.5081270399690594d, 1.0101518513770347d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.12018772212251197d));

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test221"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.1920929E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1920929E-7f);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test222"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.15729920705028488d, (java.lang.Number)(short)(-1), false);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    java.lang.Number var6 = var4.getMax();
    java.lang.Number var7 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)(-1)+ "'", var6.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0.15729920705028488d+ "'", var7.equals(0.15729920705028488d));

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test223"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-127));

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test224"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-8834), (-388134638));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-388134638));

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test225"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(7.105427357601002E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.4073748835532856E14d));

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test226"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)2.566440443196982d, (java.lang.Number)1910, true);
    boolean var5 = var4.getBoundIsAllowed();
    java.lang.Number var6 = var4.getMax();
    java.lang.Number var7 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1910+ "'", var6.equals(1910));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1910+ "'", var7.equals(1910));

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test227"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(9194402, 2068);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test228"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.384186E-7f, 1.1368684E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.384186E-7f);

  }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test229"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var13 = var0.nextT(5.867156662812015d);
//     double var15 = var0.nextExponential(11.771947930619202d);
//     int var18 = var0.nextPascal(164, 0.1455743100721331d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var21 = var0.nextLong(319L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.2775014423458995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "384bd58f29"+ "'", var8.equals("384bd58f29"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.2912023203518393d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2.6706193981662056d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1034);
// 
//   }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test230"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var4.addElement((-0.43408597923864894d));
//     double var10 = var4.getElement(0);
//     double[] var11 = var4.getElements();
//     var4.addElement(21.0d);
//     var4.setNumElements(3);
//     org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var17 = var16.getStandardDeviation();
//     double[] var19 = var16.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
//     var20.contract();
//     int var22 = var20.getNumElements();
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var20);
//     org.apache.commons.math3.util.ResizableDoubleArray var24 = var4.copy();
//     int var25 = var24.getExpansionMode();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.2946664596753215d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0);
// 
//   }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test231"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.0d, (-0.20914827636968839d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test232"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     double var14 = var0.nextChiSquare(4.950886585270677E-4d);
//     double var17 = var0.nextUniform(0.0d, 1.0076199721400823d);
//     var0.reSeed();
//     double var20 = var0.nextExponential(7.724435900937391d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12.51206791512923d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "0a3fbfd19d"+ "'", var8.equals("0a3fbfd19d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.4328197799036929E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.7895105047158603d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 4.118046445935819d);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test233"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(104L, 1073741824L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 111669149696L);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test234"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.0d, 61.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 61.0d);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test235"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1471, 57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 83847);

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test236"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double[] var6 = var0.sample(100);
//     double var7 = var0.sample();
//     double var8 = var0.sample();
//     double var10 = var0.probability((-0.3722334692039834d));
//     double[] var12 = var0.sample(8);
//     boolean var13 = var0.isSupportLowerBoundInclusive();
//     double var14 = var0.getNumericalMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.8352207158484265d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.1794257117280909d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0d);
// 
//   }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test237"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var11 = var9.sample();
//     double var13 = var9.probability(7.444490968701611d);
//     double var14 = var9.getStandardDeviation();
//     double var15 = var9.getMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.595448572523193d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ae6105fddc"+ "'", var8.equals("ae6105fddc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.1756117415258828d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.01812146259910505d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test238"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.7295760230965135d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6767278567306203d);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test239"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)16.35282631844513d, (java.lang.Number)2391.4058730231495d, false);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test240"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-35944354));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test241"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.9508003231777231d, 13.413689499681306d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-51.46112688913703d));

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test242"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-792111645L), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test243"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.58453276514297E-5d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test244"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var11 = var0.nextLong(29L, 40318L);
//     java.util.Collection var12 = null;
//     java.lang.Object[] var14 = var0.nextSample(var12, 10993);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test245"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(40320L, (-1342158336L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1342198656L);

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test246"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     double var31 = var0.nextUniform((-0.03560534527178083d), 12185.029950707305d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var35 = var0.nextPascal(1891, (-0.1846122165435877d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10.59347242434611d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "eb51928dc3"+ "'", var8.equals("eb51928dc3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1818);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.005611379195054024d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-0.08842274510705649d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.8923031031859512d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.5744713890082527d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-0.7858224535519799d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1.6597798520209999E-15d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 8511.71577229138d);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test247"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1.7044581484917243d);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test248"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.7440848746643383d), (java.lang.Number)(-0.03561286880569323d), false);
    boolean var5 = var4.getBoundIsAllowed();
    java.lang.Number var6 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-0.03561286880569323d)+ "'", var6.equals((-0.03561286880569323d)));

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test249"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.8E-45f, 0.10267613537961508d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.2E-45f);

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test250"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     double var9 = var0.nextGamma(9.319248049587957d, (-0.4255538433808183d));
//     long var11 = var0.nextPoisson(0.9978516012375751d);
//     int var14 = var0.nextZipf(8941, 1.445343853698748d);
//     java.lang.String var16 = var0.nextHexString(3826);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var0.nextBeta((-6.887851652052518d), 1.6228705708311209d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.3940528421168041d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-3.6200707989862617d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "cacc13389ca4993f10d9f09ef7e25561b319ef809772475868a58a6921f0caaba60c1d9ad5ff4a901f9e0c79d90f02bbe718cceb3c1d4404e0d38bc699ab99ed65eafe1c751645f561e7edcaeaefcba76490fb7cc743aed5def82a08e87e1433637e07c223a5388b0c433efc6ce5851a8f03138a8bfe047dc114a185b8adb1b2bca4595f2713033e72517f07464e2d19e448486dd3ae3fd2f99656b5c5af4a4b79098291d9163460deee94785ae6fb72239c0d12ec7f2e1842df330d1332497fe73a131a5a66aaf5ea5cae995b8a9cf1ea7bda2c3ea189bf7a32d39beeaa44996c810d5403ef59a541c7b2132f143742be0a2256c5c78eda75f37055082649b55cbf5f654c8aa9e9428274689bb35784992e0cc3799cc5c3c52d1cbabee02ccf7ca187978f735ad69c7c8aa4d8e8b6b94624c7f5ae3b2f745a972e20dc299fe25111239874a2bcd5640f778c4d6444375c9e76106ac8da23ec99ea62e21ee6eb36f99826610bdfc3a845f1175dcab17b6d78661210fbb93852c4839a3f09df09a21e2cf0b511b39ec452410bb39027175a7018c7e8abc62c37d67ec3848be5151d316f7c71656227b937845eec905ef29ca9b6a48fd7886fb804374ab74093c7635fb05ccbfc16b092181cf3b76c375af2c3728fae94d040fa6ac9353a1854f48b89d2c5b1bf13546355f202aff7922cb3f13939bf802b92bf6b78e1026c62c7f5375030d3acc14272582c50d3bf83f642a7321952761f938e6cbc196e560cf1a2760ce371ace3ce6c2a7fbfe7a729b0874e7daf11d51a8a0647dd041160249745d981b82e42dbbde9189870dfb3fa39313d43737a0c817112f58b710903445f4daf46024119afeaf6b1cb91e290ef22586a14cc87c22ce0cb86af03552a0dca5d33b589c8fc1a3e8e0a0ff04861f73bfce6bb70a31183be64dfab60da268aceb2b8392853b187f841e6842ae90435d8b248aeff0b4d651f1f114849ab095a85763135608190a9d548e7d2b012b232098c85acea0631321a9e1edfeb72bee4d4a46a423816be16b0b8bafd18a4aba69cd73df457e8bce094f42930e33ed743bf7b76e8415c2e89931451be8ea706925dec2238f1a37f825078236c96b903a03db1ee5122b4fe4c3f274d9d6e5310d16f2e2ab11e5563fdf5466b196960eea5348315096d7d3907df3dc0451829ee4008297c464704d50d2a8ad98efebbdbf8d75cff201765f46b0855f232fb85dadc61831225200d0b39d30d39816d424924c54b2c614debd1bab0b369cad060c8f71efbb395ab6f4952020cd564d626f527193aae80f0a8b5804fe84580e2f29ff74ecd55849ef728e799b03040218ebb74ae34ffbb3c81eed6d906f211474b2ed6da073af52614b9b41a6ff5589b8f080516c3d62fb706c6774febb5aee805d80bebfebb48f65f7bf2093c6e2d854a6004f7b1ec9e8d44ed7d7eab3433ef7994aee6e33c255f670cefc3bd90247dc1bf71a36c378b6e1e7da8a084ec9efa7b1eee0459b9773d2f71e9ccbda704dfbbe569640357d4af8bf5355bba8749fe5466c7d5a3ff50cfc669ba4479c52c916b6ed763cf7c7c60b46e0c7014a56f9b33c588c3dfca3a7bfb2a1f547d571d627ba2043721f0eaeb3b75c5586da9a9eda562b05930f4f2c140135f1e2f50d0ab99552a1dc19b525b5b68b4fb1a34c7b099c7cf1b0fc4de00f4ffdd0a16b1b6e26ef34145386ea4bf46aa81afe720f2386097502766b1d5c98b5d6e7013708ccb250e0e6901baa92e5294efa27fe59abf17b6f6115aee4b31eefdcd4a82701fe0580afbfbfed1fe455863b32559fedd7cd129ac7c4de9b00d3948c3846cb2ef9f928ae6b4def3b4e95304a8cf168163b29e33d3af6d927286f1de12cd7401d558ee46c508788d28b6da5f811faddb2c95d4ccbd6b00482fa64e348cd49e9100d4ec6d94cd209355ffea26e0952f9dcb562e08aa3e0f525692f240dd829cdc1ff1e6e07948074c332ca66b2a1e73a14edfdc923c62b0e4a524ce6c1ceca3807abce791b3a9b678d3ba53552fe691a8ed74099a580fdcc0ffe6a87d649bff04be01fad18a51c4babe29a12b15892985642da9a84bbeb38b38371e8699acdfe8f67665d2324c12239c4e925afd6e47c729323b41eb6efaf536970d2546dbd3d7fc23988f2d8d4d72af09c0d32518c1eddabdfe03e1216cb5e2742d6917e81d254bb16530b882f613e54ff19b39ecedf6d17220da10a29b0af3df7253e44ff74ae61f24af1d7a1b29d6ffe96e73d659e2d68d3f7d4fe9280903f89cb91ca109ab5a6a160df881a4fdbade923e9bdbef7a0deea0a846b0382957abb3b8845e4ebfef11f237bf1ce02e73628bb479647092d95b3563bbde4a92ff063704fe8f25e4db4a6eaca3e3792d8690ba53111278734bdf9a267903d395c356af45f2dcd2f5bbec7e268c3290e00d809a967bad4af5162fc511ae20471c83191b7105c96f8356f9e4bba4d9583046360ae2728747fba01cec1bbad06f4f0c11c493b7b943999fa078300bd5079dcb45d77590ba8c371ae89f6a45abc929b0e51dda8ca1ad23692112ee81b38d2bab2135ab99bfa6fc1a9096fe479a6b518842eeb01e7894456d7d31f69339064083bc6d3eef351ba1c88b95980f127bdb10101e31f43bf2f1feed2724e43460aa022d7c8dbe57d0c48d4331af0202b11e2ec5c77874eb9f"+ "'", var16.equals("cacc13389ca4993f10d9f09ef7e25561b319ef809772475868a58a6921f0caaba60c1d9ad5ff4a901f9e0c79d90f02bbe718cceb3c1d4404e0d38bc699ab99ed65eafe1c751645f561e7edcaeaefcba76490fb7cc743aed5def82a08e87e1433637e07c223a5388b0c433efc6ce5851a8f03138a8bfe047dc114a185b8adb1b2bca4595f2713033e72517f07464e2d19e448486dd3ae3fd2f99656b5c5af4a4b79098291d9163460deee94785ae6fb72239c0d12ec7f2e1842df330d1332497fe73a131a5a66aaf5ea5cae995b8a9cf1ea7bda2c3ea189bf7a32d39beeaa44996c810d5403ef59a541c7b2132f143742be0a2256c5c78eda75f37055082649b55cbf5f654c8aa9e9428274689bb35784992e0cc3799cc5c3c52d1cbabee02ccf7ca187978f735ad69c7c8aa4d8e8b6b94624c7f5ae3b2f745a972e20dc299fe25111239874a2bcd5640f778c4d6444375c9e76106ac8da23ec99ea62e21ee6eb36f99826610bdfc3a845f1175dcab17b6d78661210fbb93852c4839a3f09df09a21e2cf0b511b39ec452410bb39027175a7018c7e8abc62c37d67ec3848be5151d316f7c71656227b937845eec905ef29ca9b6a48fd7886fb804374ab74093c7635fb05ccbfc16b092181cf3b76c375af2c3728fae94d040fa6ac9353a1854f48b89d2c5b1bf13546355f202aff7922cb3f13939bf802b92bf6b78e1026c62c7f5375030d3acc14272582c50d3bf83f642a7321952761f938e6cbc196e560cf1a2760ce371ace3ce6c2a7fbfe7a729b0874e7daf11d51a8a0647dd041160249745d981b82e42dbbde9189870dfb3fa39313d43737a0c817112f58b710903445f4daf46024119afeaf6b1cb91e290ef22586a14cc87c22ce0cb86af03552a0dca5d33b589c8fc1a3e8e0a0ff04861f73bfce6bb70a31183be64dfab60da268aceb2b8392853b187f841e6842ae90435d8b248aeff0b4d651f1f114849ab095a85763135608190a9d548e7d2b012b232098c85acea0631321a9e1edfeb72bee4d4a46a423816be16b0b8bafd18a4aba69cd73df457e8bce094f42930e33ed743bf7b76e8415c2e89931451be8ea706925dec2238f1a37f825078236c96b903a03db1ee5122b4fe4c3f274d9d6e5310d16f2e2ab11e5563fdf5466b196960eea5348315096d7d3907df3dc0451829ee4008297c464704d50d2a8ad98efebbdbf8d75cff201765f46b0855f232fb85dadc61831225200d0b39d30d39816d424924c54b2c614debd1bab0b369cad060c8f71efbb395ab6f4952020cd564d626f527193aae80f0a8b5804fe84580e2f29ff74ecd55849ef728e799b03040218ebb74ae34ffbb3c81eed6d906f211474b2ed6da073af52614b9b41a6ff5589b8f080516c3d62fb706c6774febb5aee805d80bebfebb48f65f7bf2093c6e2d854a6004f7b1ec9e8d44ed7d7eab3433ef7994aee6e33c255f670cefc3bd90247dc1bf71a36c378b6e1e7da8a084ec9efa7b1eee0459b9773d2f71e9ccbda704dfbbe569640357d4af8bf5355bba8749fe5466c7d5a3ff50cfc669ba4479c52c916b6ed763cf7c7c60b46e0c7014a56f9b33c588c3dfca3a7bfb2a1f547d571d627ba2043721f0eaeb3b75c5586da9a9eda562b05930f4f2c140135f1e2f50d0ab99552a1dc19b525b5b68b4fb1a34c7b099c7cf1b0fc4de00f4ffdd0a16b1b6e26ef34145386ea4bf46aa81afe720f2386097502766b1d5c98b5d6e7013708ccb250e0e6901baa92e5294efa27fe59abf17b6f6115aee4b31eefdcd4a82701fe0580afbfbfed1fe455863b32559fedd7cd129ac7c4de9b00d3948c3846cb2ef9f928ae6b4def3b4e95304a8cf168163b29e33d3af6d927286f1de12cd7401d558ee46c508788d28b6da5f811faddb2c95d4ccbd6b00482fa64e348cd49e9100d4ec6d94cd209355ffea26e0952f9dcb562e08aa3e0f525692f240dd829cdc1ff1e6e07948074c332ca66b2a1e73a14edfdc923c62b0e4a524ce6c1ceca3807abce791b3a9b678d3ba53552fe691a8ed74099a580fdcc0ffe6a87d649bff04be01fad18a51c4babe29a12b15892985642da9a84bbeb38b38371e8699acdfe8f67665d2324c12239c4e925afd6e47c729323b41eb6efaf536970d2546dbd3d7fc23988f2d8d4d72af09c0d32518c1eddabdfe03e1216cb5e2742d6917e81d254bb16530b882f613e54ff19b39ecedf6d17220da10a29b0af3df7253e44ff74ae61f24af1d7a1b29d6ffe96e73d659e2d68d3f7d4fe9280903f89cb91ca109ab5a6a160df881a4fdbade923e9bdbef7a0deea0a846b0382957abb3b8845e4ebfef11f237bf1ce02e73628bb479647092d95b3563bbde4a92ff063704fe8f25e4db4a6eaca3e3792d8690ba53111278734bdf9a267903d395c356af45f2dcd2f5bbec7e268c3290e00d809a967bad4af5162fc511ae20471c83191b7105c96f8356f9e4bba4d9583046360ae2728747fba01cec1bbad06f4f0c11c493b7b943999fa078300bd5079dcb45d77590ba8c371ae89f6a45abc929b0e51dda8ca1ad23692112ee81b38d2bab2135ab99bfa6fc1a9096fe479a6b518842eeb01e7894456d7d31f69339064083bc6d3eef351ba1c88b95980f127bdb10101e31f43bf2f1feed2724e43460aa022d7c8dbe57d0c48d4331af0202b11e2ec5c77874eb9f"));
// 
//   }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test251"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double[] var6 = var0.sample(100);
//     double var7 = var0.sample();
//     double var8 = var0.sample();
//     var0.reseedRandomGenerator(10L);
//     boolean var11 = var0.isSupportLowerBoundInclusive();
//     boolean var12 = var0.isSupportUpperBoundInclusive();
//     double var13 = var0.getMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.6050333467378823d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5037298382546922d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test252"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.8773584223947262d), 4.77200768795183d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.8773584223947261d));

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test253"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(6, 1990);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test254"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(0, 9679);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test255"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    boolean var4 = var0.isSupportConnected();
    double var5 = var0.getMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var0.cumulativeProbability(4.252640503606456d, 0.6594953449564702d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test256"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getSupportUpperBound();
//     double[] var3 = var0.sample(10);
//     double var4 = var0.getStandardDeviation();
//     double var5 = var0.getStandardDeviation();
//     double var6 = var0.getNumericalVariance();
//     double var7 = var0.getNumericalVariance();
//     double var9 = var0.probability(0.9999999999999925d);
//     double var11 = var0.probability(3.0741607150885346d);
//     double var12 = var0.sample();
//     double var13 = var0.getMean();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.inverseCumulativeProbability(12.968498074057063d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.31887028853467786d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test257"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    boolean var12 = var10.equals((java.lang.Object)Double.POSITIVE_INFINITY);
    boolean var14 = var10.equals((java.lang.Object)(-0.4255538433808183d));
    java.lang.Class var15 = var10.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test258"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var13 = var0.nextT(5.867156662812015d);
//     double var16 = var0.nextGamma((-1.5707963267948966d), 1.5318133596204784d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("3d401b72a8b2f4c6c1b76baeb2219ddb838020faf1f28fa1d621ef09ccbb8f1e11d844aea76355f8795f80f182795d3e7001", "b8e1377af3");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.779433304777926d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "b7fe17d655"+ "'", var8.equals("b7fe17d655"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.2815870883198853d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 4.130793794718219d);
// 
//   }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test259"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     double var10 = var0.nextT(20.696514663540924d);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var11.getStandardDeviation();
//     double[] var14 = var11.sample(1);
//     double var15 = var11.getMean();
//     double[] var17 = var11.sample(100);
//     double var18 = var11.sample();
//     double var19 = var11.sample();
//     double var20 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     boolean var21 = var11.isSupportLowerBoundInclusive();
//     double var22 = var11.getStandardDeviation();
//     double var24 = var11.cumulativeProbability(1.8196112019611284d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12.789038453894047d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "712e8200d0fe45cb9d9ef8df7b15152c287b02d73e9f0557a93d684fb2e9189c568e39d7523d832917075061323991391f1c"+ "'", var8.equals("712e8200d0fe45cb9d9ef8df7b15152c287b02d73e9f0557a93d684fb2e9189c568e39d7523d832917075061323991391f1c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5481951234157928d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.3790949569766503d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-0.42463405052246417d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-0.62278342103023d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.965590882722694d);
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test260"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    var4.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var4.copy();
    double[] var10 = var4.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test261"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var14 = var0.nextBeta(3628800.0d, 1.1752011936438014d);
//     long var17 = var0.nextSecureLong(2L, 704L);
//     double var19 = var0.nextExponential(6.870630919684177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.505798864106619d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "efe23980d8"+ "'", var8.equals("efe23980d8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.9999993283394013d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 241L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 7.565776487083803d);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test262"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(70L, 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 67L);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test263"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.41759531141436157d);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test264"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log1p((-1.3270697734558135d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test265"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(4.425407576344319d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9997135112320019d);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test266"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(17L, 7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 410338673L);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test267"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException(var0);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test268"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(8L, 16L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16L);

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test269"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var11 = var9.sample();
//     var9.reseedRandomGenerator(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var15 = var9.sample((-79568300));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.8529823900936446d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "3fdc79b883"+ "'", var8.equals("3fdc79b883"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.777699189669149d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.3573964815250585d);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test270"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 0.0f, (-1.4E-45f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test271"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.9660876476533402d, 2.265662238504449d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.2995745908511087d));

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test272"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(10.629103431631437d, 0.38738301051282215d, 8.881784197001252E-16d, 136);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.8130849985369987E-12d);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test273"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.132200867889637d, (java.lang.Number)336L, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test274"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.937657633755765d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2158283916032282d);

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test275"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)1.1629595418829466d, false);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test276"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    var4.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var4.copy();
    java.lang.Object var10 = null;
    boolean var11 = var4.equals(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test277"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     int var11 = var0.nextZipf(5, 0.8273572477024794d);
//     int var14 = var0.nextBinomial(1972, 0.15795521463156686d);
//     var0.reSeed();
//     var0.reSeed(184L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12.242034728861416d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ce6e03e94d996d3c6cee81c616e4fcb367e8ccf98d33f574a842fc20a5b2faca150fd8c55eac102df9a83cff64a8341ccde6"+ "'", var8.equals("ce6e03e94d996d3c6cee81c616e4fcb367e8ccf98d33f574a842fc20a5b2faca150fd8c55eac102df9a83cff64a8341ccde6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 326);
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test278"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(8.881784197001252E-16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test279"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var7 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var6, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var5, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var4, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MaxCountExceededException var12 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)(-1.2458743353298596d), (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test280"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, (-0.7928258089770865d), 0.04378400432753372d, 657);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test281"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(6.716856895119818d, 0.39542063198610805d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.39542063198610805d);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test282"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(17.041070396305297d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5167660033583883E7d);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test283"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test284"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(1.691467799108048d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0975581339764322d));

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test285"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    var4.addElement(0.0d);
    int var8 = var4.getExpansionMode();
    double[] var9 = var4.getInternalValues();
    double var11 = var4.substituteMostRecentElement((-0.32138541515384916d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test286"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs((-0.5002028444398587d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5002028444398587d);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test287"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(14.087081017797523d, 1.6096293162678812d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.17994611088998624d);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test288"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10241);

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test289"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     var0.reSeedSecure();
//     long var10 = var0.nextSecureLong(3L, 31L);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextWeibull(0.0d, 0.023928085890320375d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 22.333051728250606d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 27L);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test290"); }


    double[] var3 = new double[] { 0.0d, (-1.0d), 0.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.getNumElements();
    float var6 = var4.getExpansionFactor();
    int var7 = var4.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test291"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(12.330475398334398d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.203572685383409d);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test292"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-3.951670396639844d));

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test293"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(10.191783235597585d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test294"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.5322866968936354d, 0.07683545068520695d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.069455911176068d);

  }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test295"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1916);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var6 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var6);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, (java.lang.Object[])var6);
//     org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, (java.lang.Object[])var6);
// 
//   }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test296"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     double var9 = var0.nextF(2.281783181607902d, 0.8427007929497151d);
//     double var12 = var0.nextGaussian(1.5498468927479463d, 1865.0d);
//     double var14 = var0.nextExponential(1.2042143530169682d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextHypergeometric(0, 1836, (-1912));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 18.5967325886862d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.9112088288831273d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1221.305349607978d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.41654699923999855d);
// 
//   }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test297"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     double var11 = var0.nextF(0.9672931540516151d, 1.0101518513770347d);
//     double var14 = var0.nextBeta(0.17971249487899976d, 0.022352405844223155d);
//     long var16 = var0.nextPoisson(0.9708257025166332d);
//     long var19 = var0.nextLong(39L, 832L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.449774534968612d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "cafd2e08c251eed7fa51c642bcb9def524bdd4a9e858b97f94118acc4cbf7ba993faea8cfb0aa99a2af2565428827492e178"+ "'", var8.equals("cafd2e08c251eed7fa51c642bcb9def524bdd4a9e858b97f94118acc4cbf7ba993faea8cfb0aa99a2af2565428827492e178"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 6.6672736628423985d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.4966925639895038d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 437L);
// 
//   }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test298"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextBinomial(1949, (-0.6919677581039431d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.111624383870936d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "aa9e50be55"+ "'", var8.equals("aa9e50be55"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.500232414365367d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 9907);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test299"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(26.7679349511499d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.173773763042785d);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test300"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1831, 9.536745E-7f, 2.384186E-7f, 1319);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test301"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(6.1537643330283105d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8325125324523532d);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test302"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1962);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1962);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test303"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(3.539472048166337d, 0.14608902069952245d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0333355513777982d);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test304"); }


    long var1 = org.apache.commons.math3.util.FastMath.round((-1.0759648717954502d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1L));

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test305"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-4.440892098500627E-16d));
    java.lang.Number var3 = var2.getMin();
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var8 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var4, (java.lang.Number)0.15729920705028488d, (java.lang.Number)(short)(-1), false);
    java.lang.Number var9 = var8.getMax();
    var2.addSuppressed((java.lang.Throwable)var8);
    boolean var11 = var8.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (short)(-1)+ "'", var9.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test306"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextHypergeometric(1499, (-1032474271), 1549);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.8875123595766565d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5ac190d3267056e19e3b36185781ad42a9bc30a5b471931e324850798c565b9c855bb13c248157574657df0ad27d03f59ea7"+ "'", var8.equals("5ac190d3267056e19e3b36185781ad42a9bc30a5b471931e324850798c565b9c855bb13c248157574657df0ad27d03f59ea7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.04488966906969368d);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test307"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)(-1), (java.lang.Number)10, (java.lang.Number)6.621888603197341d);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 10+ "'", var4.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 6.621888603197341d+ "'", var5.equals(6.621888603197341d));

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test308"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1963);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1963);

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test309"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     double var16 = var0.nextGaussian(0.9999494957997512d, 25.472636453138065d);
//     double var19 = var0.nextWeibull(18.0d, 25.472636453138065d);
//     var0.reSeedSecure();
//     double var22 = var0.nextT(0.7243407758924822d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var0.nextUniform(6.378161442562124d, 1.0125754552662622d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 18.75979158656865d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ae2ee02372"+ "'", var8.equals("ae2ee02372"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1925);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.006375300075493783d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-29.67354077595195d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 25.773442100892886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 3.249081810297215d);
// 
//   }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test310"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     double var12 = var0.nextGamma(4.950886585270677E-4d, 1.5703107297735257d);
//     var0.reSeed(17L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextUniform(1.7855355255055831d, 0.013292325585375278d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.2688542490400698d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2.1058454369342592E-100d);
// 
//   }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test311"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
//     java.lang.Class var5 = var4.getDeclaringClass();
//     int var6 = var4.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
//     org.apache.commons.math3.random.RandomGenerator var8 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
//     org.apache.commons.math3.random.RandomGenerator var10 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
//     java.lang.Class var14 = var13.getDeclaringClass();
//     java.lang.String var15 = var13.toString();
//     java.lang.String var16 = var13.toString();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var13);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var22 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var25 = var24.getSupportUpperBound();
//     double[] var27 = var24.sample(10);
//     double var28 = var18.mannWhitneyU(var22, var27);
//     double[] var29 = var17.rank(var22);
//     org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
//     int var31 = var30.getNumElements();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "AVERAGE"+ "'", var16.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 21.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 3);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test312"); }


    double[] var3 = new double[] { 0.0d, (-1.0d), 0.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    var4.addElement(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test313"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(1343);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test314"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.7658486382813623d, 4.763527419740368d, 0.0d, (-8889));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test315"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(16.92631233422619d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test316"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)8.563154148722202d, (java.lang.Number)2.5078368197853713d, false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 8.563154148722202d+ "'", var5.equals(8.563154148722202d));

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test317"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.718887609175217d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.578319739955868d);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test318"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.4518934003863375d, true);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test319"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)10L);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test320"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-4.440892098500626E-16d), 1.1102230246251565E-16d, 0.9999494957997512d);
    double[] var5 = var3.sample(1972);
    double var6 = var3.getNumericalMean();
    double var7 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-4.440892098500626E-16d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-4.440892098500626E-16d));

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test321"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     java.lang.String var13 = var0.nextHexString(10);
//     var0.reSeedSecure();
//     double var17 = var0.nextGaussian(7.042014262199385d, 1.179103839756096d);
//     long var19 = var0.nextPoisson(0.9999679765543574d);
//     double var22 = var0.nextCauchy((-0.9611654079124452d), 36.22576630637032d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.463660911867485d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "cbbaf7b34a"+ "'", var8.equals("cbbaf7b34a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "ae4e3878c6"+ "'", var13.equals("ae4e3878c6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 6.316812892815939d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-36.243500142833796d));
// 
//   }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test322"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextUniform(0.2577047455984825d, 13.770182159584014d);
//     long var6 = var1.nextPoisson(23.012289905639566d);
//     long var8 = var1.nextPoisson(4.625610117464785d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 8.535667735449547d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 29L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 6L);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test323"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(10178, 11213);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test324"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-762L), 5071615437313169417L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-762L));

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test325"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(15.460506451516764d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test326"); }
// 
// 
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.distribution.NormalDistribution var1 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var2 = var1.getStandardDeviation();
//     boolean var3 = var1.isSupportUpperBoundInclusive();
//     double[] var5 = var1.sample(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var6.reseedRandomGenerator(2L);
//     double[] var10 = var6.sample(100000);
//     double var11 = var0.mannWhitneyUTest(var5, var10);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var13 = var12.getSupportUpperBound();
//     double[] var15 = var12.sample(10);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.distribution.NormalDistribution var17 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var18 = var17.getStandardDeviation();
//     boolean var19 = var17.isSupportUpperBoundInclusive();
//     double[] var21 = var17.sample(100);
//     org.apache.commons.math3.distribution.NormalDistribution var22 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var22.reseedRandomGenerator(2L);
//     double[] var26 = var22.sample(100000);
//     double var27 = var16.mannWhitneyUTest(var21, var26);
//     org.apache.commons.math3.distribution.NormalDistribution var28 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var29 = var28.getStandardDeviation();
//     double[] var31 = var28.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var32 = new org.apache.commons.math3.util.ResizableDoubleArray(var31);
//     double[] var36 = new double[] { 0.0d, (-1.0d), 0.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var37 = new org.apache.commons.math3.util.ResizableDoubleArray(var36);
//     double var38 = var16.mannWhitneyU(var31, var36);
//     double var39 = var0.mannWhitneyU(var15, var36);
//     org.apache.commons.math3.util.ResizableDoubleArray var40 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.018485661248235252d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.0420049190150672d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 3.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 20.0d);
// 
//   }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test327"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
//     java.lang.Class var5 = var4.getDeclaringClass();
//     int var6 = var4.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
//     org.apache.commons.math3.random.RandomGenerator var8 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
//     org.apache.commons.math3.random.RandomGenerator var10 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
//     java.lang.Class var14 = var13.getDeclaringClass();
//     java.lang.String var15 = var13.toString();
//     java.lang.String var16 = var13.toString();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var13);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var22 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var25 = var24.getSupportUpperBound();
//     double[] var27 = var24.sample(10);
//     double var28 = var18.mannWhitneyU(var22, var27);
//     double[] var29 = var17.rank(var22);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var30 = var17.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var31 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30, var31);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var33 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30, var33);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var36 = var35.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var37 = var35.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var38 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var39 = var38.getTiesStrategy();
//     java.lang.Class var40 = var39.getDeclaringClass();
//     int var41 = var39.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var42 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var37, var39);
//     org.apache.commons.math3.random.RandomGenerator var43 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var44 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var37, var43);
//     org.apache.commons.math3.random.RandomGenerator var45 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var46 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var37, var45);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var47 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var37);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var48 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var49 = var48.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var50 = var48.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var51 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var52 = var51.getTiesStrategy();
//     java.lang.Class var53 = var52.getDeclaringClass();
//     int var54 = var52.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var55 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var50, var52);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var56 = var55.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var57 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var58 = var57.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var59 = var57.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var60 = var57.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var61 = var57.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var62 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var63 = var62.getTiesStrategy();
//     boolean var65 = var63.equals((java.lang.Object)Double.POSITIVE_INFINITY);
//     boolean var67 = var63.equals((java.lang.Object)(-0.4255538433808183d));
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var68 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var61, var63);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var69 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var56, var63);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var70 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var37, var63);
//     java.lang.String var71 = var63.toString();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var72 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30, var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "AVERAGE"+ "'", var16.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 27.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var71 + "' != '" + "AVERAGE"+ "'", var71.equals("AVERAGE"));
// 
//   }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test328"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(2.8E-45f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.8E-45f);

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test329"); }
// 
// 
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
//     java.lang.Class var6 = var5.getDeclaringClass();
//     java.lang.Class var7 = var5.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
//     java.lang.String var9 = var5.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var10 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var3, var5);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var11.getStandardDeviation();
//     double[] var14 = var11.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var20 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
//     double[] var25 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
//     double var27 = var16.mannWhitneyU(var20, var25);
//     double var28 = var10.mannWhitneyUTest(var14, var20);
//     org.apache.commons.math3.distribution.NormalDistribution var29 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var30 = var29.getStandardDeviation();
//     double[] var32 = var29.sample(1);
//     double var33 = var29.getMean();
//     double[] var35 = var29.sample(100);
//     boolean var36 = var29.isSupportLowerBoundInclusive();
//     boolean var37 = var29.isSupportUpperBoundInclusive();
//     double var40 = var29.cumulativeProbability(0.0d, 0.25587682077976953d);
//     double var41 = var29.getSupportUpperBound();
//     double[] var43 = var29.sample(11274);
//     org.apache.commons.math3.distribution.NormalDistribution var47 = new org.apache.commons.math3.distribution.NormalDistribution((-4.440892098500626E-16d), 1.1102230246251565E-16d, 0.9999494957997512d);
//     double[] var49 = var47.sample(1972);
//     double var50 = var10.mannWhitneyUTest(var43, var49);
//     org.apache.commons.math3.distribution.NormalDistribution var51 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var52 = var51.getStandardDeviation();
//     double[] var54 = var51.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var55 = new org.apache.commons.math3.util.ResizableDoubleArray(var54);
//     int var56 = var55.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var57 = var55.copy();
//     var55.addElement((-0.43408597923864894d));
//     double var61 = var55.getElement(0);
//     var55.clear();
//     org.apache.commons.math3.distribution.NormalDistribution var63 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var64 = var63.getStandardDeviation();
//     double[] var66 = var63.sample(1);
//     double var67 = var63.getMean();
//     double[] var69 = var63.sample(100);
//     var55.addElements(var69);
//     double[] var71 = var55.getElements();
//     double var72 = var0.mannWhitneyUTest(var43, var71);
//     org.apache.commons.math3.util.ResizableDoubleArray var73 = new org.apache.commons.math3.util.ResizableDoubleArray(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "AVERAGE"+ "'", var9.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 4.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.17971249487899976d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 0.10097702336242761d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0.43513355514796126d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == (-0.06416560144381053d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 0.565066791552435d);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test330"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.discardMostRecentElements(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var4.substituteMostRecentElement(0.1455743100721331d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test331"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1845, 7.6293945E-6f, 2.5000002f, 338177);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test332"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    boolean var7 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator((-16L));
    double[] var11 = var0.sample(2297);
    double var12 = var0.sample();
    double var13 = var0.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.5481764785100467d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == Double.POSITIVE_INFINITY);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test333"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(2696L, 4337);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test334"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.5395119302779527d, 0.7285929127156267d, 0.010000166250831584d);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test335"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(12.725432724837008d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 168095.1629734684d);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test336"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)192);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test337"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(17946, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test338"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(2.3841864E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test339"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    java.lang.Class var6 = var5.getDeclaringClass();
    int var7 = var5.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var5);
    org.apache.commons.math3.random.RandomGenerator var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var9);
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var11);
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var14, var16);
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var16);
    java.lang.String var19 = var16.name();
    java.lang.Class var20 = var16.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var16);
    java.lang.String var22 = var16.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "AVERAGE"+ "'", var22.equals("AVERAGE"));

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test340"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(152.40959258449737d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.755593766437044E65d);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test341"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.5000002f, 2.8570488891639516d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5000005f);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test342"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(8.488974763639089d, 1.7857104142610332d, 0.38980836088158677d, 1865);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.9997650985387475d);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test343"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(16.475510988377376d, (-0.1901543518195821d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16.475510988377376d);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test344"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(22L, 16L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6L);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test345"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.setElement(8899, 2.3930658372149933d);
    var4.clear();
    int var17 = var4.start();
    var4.setNumElements(1999);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test346"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.017688387388495763d, (java.lang.Number)4.440892098500626E-16d, (java.lang.Number)0.9999987388901819d);
    java.lang.String var4 = var3.toString();
    java.lang.Number var5 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: 0.018 out of [0, 1] range"+ "'", var4.equals("org.apache.commons.math3.exception.OutOfRangeException: 0.018 out of [0, 1] range"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 4.440892098500626E-16d+ "'", var5.equals(4.440892098500626E-16d));

  }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test347"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     double var5 = var0.nextChiSquare(7.6675647339750626d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextBeta(0.5753788165723316d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1.058179058943379d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 9.94583783372484d);
// 
//   }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test348"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(56L, (-1342158336L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test349"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-14.738220481169323d), 0.16043285994536435d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 14.739093651039374d);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test350"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.4128411121633297d, (java.lang.Number)0.0f, (java.lang.Number)3.2359311173302077d);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getHi();
    java.lang.Number var6 = var3.getLo();
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var3.getContext();
    java.lang.Number var8 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.0f+ "'", var4.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 3.2359311173302077d+ "'", var5.equals(3.2359311173302077d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.0f+ "'", var6.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0.0f+ "'", var8.equals(0.0f));

  }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test351"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)100.0d, (java.lang.Number)2.5447811413859593d, false);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var15 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var11, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
//     java.lang.Throwable[] var16 = var15.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var10, (java.lang.Object[])var16);
//     org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException(var9, (java.lang.Object[])var16);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var19 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var8, (java.lang.Object[])var16);
//     org.apache.commons.math3.exception.MaxCountExceededException var20 = new org.apache.commons.math3.exception.MaxCountExceededException(var6, (java.lang.Number)6.621888603197341d, (java.lang.Object[])var16);
//     org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var16);
// 
//   }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test352"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.28486305636986253d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2929666834123186d);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test353"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)8899);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test354"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var6 = var5.getStandardDeviation();
    double[] var8 = var5.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    double[] var10 = var9.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var18 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var14, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var19 = var18.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var20 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var13, (java.lang.Object[])var19);
    org.apache.commons.math3.exception.MathArithmeticException var21 = new org.apache.commons.math3.exception.MathArithmeticException(var12, (java.lang.Object[])var19);
    boolean var22 = var11.equals((java.lang.Object)var19);
    org.apache.commons.math3.exception.MathIllegalStateException var23 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var19);
    org.apache.commons.math3.exception.MathIllegalStateException var24 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var19);
    org.apache.commons.math3.exception.MaxCountExceededException var25 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)0.9661320315433753d, (java.lang.Object[])var19);
    org.apache.commons.math3.exception.NullArgumentException var26 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test355"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.9360333153081093d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5498468927479463d);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test356"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     double var9 = var0.nextF(2.281783181607902d, 0.8427007929497151d);
//     double var12 = var0.nextGaussian(1.5498468927479463d, 1865.0d);
//     java.lang.String var14 = var0.nextHexString(337860);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var17 = var0.nextPermutation(1471, 1964);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 14.512330519341884d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 8.882026879076173d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-245.6128623448422d));
// 
//   }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test357"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double[] var6 = var0.sample(100);
//     double var7 = var0.sample();
//     double var8 = var0.sample();
//     var0.reseedRandomGenerator(10L);
//     boolean var11 = var0.isSupportLowerBoundInclusive();
//     boolean var12 = var0.isSupportLowerBoundInclusive();
//     double var13 = var0.getMean();
//     boolean var14 = var0.isSupportConnected();
//     boolean var15 = var0.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.7196442616799688d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.05116808664027965d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test358"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(6379912561590279263L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6379912561590279263L);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test359"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, 4.505452107819377E9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test360"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     double var30 = var0.nextExponential(1.0471975511965979d);
//     var0.reSeed(70L);
//     double var34 = var0.nextChiSquare(18.88681913748533d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 22.666039334536638d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "9a3f7e78af"+ "'", var8.equals("9a3f7e78af"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1910);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.01633551247036075d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.29012532982348616d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.6979005689945283d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.5433347981567266d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.32077927207006307d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1.2156721739560978E-106d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.0647947145094934d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 10.139396516109224d);
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test361"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(34.18167228038127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 34.0d);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test362"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(3.5498557373738816E-115d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.935578493738491E228d);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test363"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(29.90785919790278d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.1040481002909335d);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test364"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.06416560144381053d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.06416560144381052d));

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test365"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-1.9369499619508226d), (java.lang.Number)0.01329154278510984d, true);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test366"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(39L, 760L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 29640L);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test367"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var8, var11);
    org.apache.commons.math3.random.RandomGenerator var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var15);
    java.lang.Object var17 = null;
    boolean var18 = var8.equals(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test368"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     double var16 = var0.nextChiSquare(7.406617040824975d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextPascal(1831, (-1.9369499619508226d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.579569686699536d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "4491e5c77b7c951a9649f27eab2397cd8c15a9ab9d1eaa5348b38db5da1bd91abcd82018a5b60e85820177403574afaf844e"+ "'", var8.equals("4491e5c77b7c951a9649f27eab2397cd8c15a9ab9d1eaa5348b38db5da1bd91abcd82018a5b60e85820177403574afaf844e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.08657192366797849d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 5.4891598472587955d);
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test369"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.02126798438828109d);
    java.lang.Throwable[] var2 = var1.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test370"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     double var11 = var0.nextF(0.9672931540516151d, 1.0101518513770347d);
//     double var14 = var0.nextBeta(0.17971249487899976d, 0.022352405844223155d);
//     long var16 = var0.nextPoisson(0.9708257025166332d);
//     double var18 = var0.nextExponential(0.0930721414133345d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.149721646214323d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "25374b8ba3334f44ca9a489e9f62fba82980c16edefb5e41c94363e7673bbdbccd69db170b0f8a1cee3a7dd01bd3cf4dc698"+ "'", var8.equals("25374b8ba3334f44ca9a489e9f62fba82980c16edefb5e41c94363e7673bbdbccd69db170b0f8a1cee3a7dd01bd3cf4dc698"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.016357636867740992d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.014270653194875608d);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test371"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)9.536743E-7f, (java.lang.Number)(-0.4255538433808183d), false);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.4255538433808183d)+ "'", var5.equals((-0.4255538433808183d)));

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test372"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(2.5000005f, 7.6293945E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.6293945E-6f);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test373"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    double[] var6 = var4.getInternalValues();
    org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var8 = var7.getStandardDeviation();
    double[] var10 = var7.sample(1);
    double var11 = var7.getMean();
    double[] var13 = var7.sample(100);
    var4.addElements(var13);
    var4.discardMostRecentElements(44);
    int var17 = var4.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test374"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var13 = var0.nextF(0.6351254179184792d, 1.0919228035719635d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextBeta((-0.16784300742992436d), 1017.1979140470148d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 13.616074977165002d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "43ef121c7b"+ "'", var8.equals("43ef121c7b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.6158230135394698d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.10821920082498535d);
// 
//   }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test375"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.010200975372259509d, 3.2020584262095704d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.010200975372259509d);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test376"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(9448);
    var1.addElement(1.2040395048875416d);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test377"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.6184722231648824d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8560901830053456d);

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test378"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     var0.reSeed(14L);
//     double var14 = var0.nextExponential(0.9999997887160175d);
//     long var16 = var0.nextPoisson(0.8259324122591327d);
//     java.lang.String var18 = var0.nextHexString(42);
//     double var21 = var0.nextF(0.5964152485658248d, 10.315306670398176d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 56.59787571911576d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "506c112505"+ "'", var8.equals("506c112505"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3043475340952027d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.3844973909690124d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "5c367c693ab2045ddb12c77b8096115d2235c49c11"+ "'", var18.equals("5c367c693ab2045ddb12c77b8096115d2235c49c11"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.004413844527276482d);
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test379"); }


    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)1.1368685E-13f, var2);
    java.lang.Number var4 = var3.getHi();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    java.lang.Number var6 = var3.getArgument();
    java.lang.Number var7 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)10+ "'", var6.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)10+ "'", var7.equals((short)10));

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test380"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     var0.reSeed();
//     double var15 = var0.nextChiSquare(7.617953921806563d);
//     java.lang.String var17 = var0.nextSecureHexString(1916);
//     int var20 = var0.nextZipf(11474, 0.8744549098686318d);
//     org.apache.commons.math3.distribution.IntegerDistribution var21 = null;
//     int var22 = var0.nextInversionDeviate(var21);
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test381"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    double[] var5 = var4.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setExpansionMode(2297);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test382"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("9452c66100");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test383"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(13.387418481339157d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1266968393422565d);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test384"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(8.95239708538578d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3863.195184583202d);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test385"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(0, 1906);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test386"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)7.362895734466076d, (java.lang.Number)17946, true);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test387"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)4.0434293412271454E-4d);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test388"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var21 = var18.nextSecureLong((-1L), 1L);
//     double var24 = var18.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var26 = var18.nextSecureHexString(100);
//     double var28 = var18.nextT(20.696514663540924d);
//     org.apache.commons.math3.distribution.NormalDistribution var29 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var30 = var29.getStandardDeviation();
//     double[] var32 = var29.sample(1);
//     double var33 = var29.getMean();
//     double[] var35 = var29.sample(100);
//     double var36 = var29.sample();
//     double var37 = var29.sample();
//     double var38 = var18.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     double var39 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     double var42 = var0.nextGaussian(0.9999999627393439d, 0.022352405844223155d);
//     double var45 = var0.nextWeibull(0.8273175524905445d, 0.003960709268216542d);
//     double var48 = var0.nextWeibull(0.1210138782754731d, 0.8847656390164815d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.6394362149555466d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "408db48e388aa33178771f63c86817e7d79c8f275dbd466f1e2fb88640ec9d9020eec9d504a6d25732a44a744e9a45f603d8"+ "'", var8.equals("408db48e388aa33178771f63c86817e7d79c8f275dbd466f1e2fb88640ec9d9020eec9d504a6d25732a44a744e9a45f603d8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.13035232540311623d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 10.636371637289402d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "c34e1ed07f0e602051516dc0cd20e0f13709a9b9514b78565c0fe8e335a22a82a9a0b2e6b5fb2067f6b74bbb929e5ac60b77"+ "'", var26.equals("c34e1ed07f0e602051516dc0cd20e0f13709a9b9514b78565c0fe8e335a22a82a9a0b2e6b5fb2067f6b74bbb929e5ac60b77"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-0.5036827456585442d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == (-1.1142044395596675d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0.8271771155001076d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0.7840523431903383d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-1.931918750985446d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0.9971027061668425d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 0.003937893767876276d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 163.5770925405509d);
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test389"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.07340078064644198d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4));

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test390"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    double[] var7 = var4.getInternalValues();
    var4.addElement(0.7615941559557649d);
    double var11 = var4.substituteMostRecentElement(0.0d);
    var4.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.7615941559557649d);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test391"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.9999999f, var2, true);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test392"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32.94631867978169d);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test393"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0L, 2985984L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test394"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, 2.384186E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test395"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     double var10 = var0.nextT(20.696514663540924d);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var11.getStandardDeviation();
//     double[] var14 = var11.sample(1);
//     double var15 = var11.getMean();
//     double[] var17 = var11.sample(100);
//     double var18 = var11.sample();
//     double var19 = var11.sample();
//     double var20 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     int var23 = var0.nextBinomial(97944, 0.11537426317526311d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var25 = var24.getStandardDeviation();
//     double[] var27 = var24.sample(1);
//     double var29 = var24.cumulativeProbability(0.0d);
//     double var31 = var24.cumulativeProbability(0.0d);
//     double var32 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var36 = var0.nextUniform(1.595448572523193d, (-0.5863119679626533d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12.731067736069097d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ee00ca77d5f61b538c758915426cd911fdb2f68e793207ca37acdb6e41889474966d93db0bcd3d39db9587d64fcd38639d02"+ "'", var8.equals("ee00ca77d5f61b538c758915426cd911fdb2f68e793207ca37acdb6e41889474966d93db0bcd3d39db9587d64fcd38639d02"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.22481505323835332d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.1611593499385387d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-1.9272035039490085d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.41999798726154763d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 11240);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.23972982633315693d);
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test396"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-4.440892098500626E-16d), 1.1102230246251565E-16d, 0.9999494957997512d);
    double[] var5 = var3.sample(1972);
    double var6 = var3.getNumericalMean();
    double var7 = var3.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-4.440892098500626E-16d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-4.440892098500626E-16d));

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test397"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.21858257864865782d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2151979182862757d);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test398"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1344L, 2985984L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 20901888L);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test399"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.6461740882358429d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.1870964420955135d);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test400"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 11L);
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, var14);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 1949);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, var17);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 184L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test401"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(2.30643501820425d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3212360281535291d);

  }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test402"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, (-2.172616570636548d), 1.328015533856871d, 62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test403"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var8, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    java.lang.Class var18 = var17.getDeclaringClass();
    java.lang.Class var19 = var17.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    java.lang.String var21 = var17.name();
    java.lang.String var22 = var17.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var8, var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "AVERAGE"+ "'", var21.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "AVERAGE"+ "'", var22.equals("AVERAGE"));

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test404"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.9E-324d);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test405"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-36.7368005696771d), 2106);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test406"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     double var11 = var0.nextF(0.9672931540516151d, 1.0101518513770347d);
//     double var14 = var0.nextBeta(0.17971249487899976d, 0.022352405844223155d);
//     double var17 = var0.nextGaussian((-1.2524505937205215d), 0.29645940554818306d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.6010123146065154d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "7fb383605c5b184fff7fc2925a2b80ae174c7fe1cec85dfa764ac922581b44ac39055d6d1d596e2e27c175bb02497992c017"+ "'", var8.equals("7fb383605c5b184fff7fc2925a2b80ae174c7fe1cec85dfa764ac922581b44ac39055d6d1d596e2e27c175bb02497992c017"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.0171610553467367d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-1.458894958782291d));
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test407"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var4 = var0.getMean();
    double[] var6 = var0.sample(100);
    boolean var7 = var0.isSupportLowerBoundInclusive();
    boolean var8 = var0.isSupportUpperBoundInclusive();
    double[] var10 = var0.sample(8899);
    double var12 = var0.density(3.243310970166501d);
    double var14 = var0.probability(0.4496917979688907d);
    boolean var15 = var0.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.002073594803565866d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test408"); }


    long var1 = org.apache.commons.math3.util.FastMath.round((-0.30400114025876435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test409"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
//     java.lang.Class var3 = var2.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     java.lang.String var5 = var2.toString();
//     java.lang.String var6 = var2.toString();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var2);
//     org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var11 = var8.nextSecureLong((-1L), 1L);
//     double var14 = var8.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var16 = var8.nextHexString(10);
//     int var19 = var8.nextPascal(8899, 0.8219866295031046d);
//     double var21 = var8.nextExponential(0.010050505059049992d);
//     var8.reSeed(104L);
//     boolean var24 = var2.equals((java.lang.Object)var8);
//     var8.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var28 = var8.nextBeta(2.4817022260739696d, (-4.6101815318357406E-4d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "AVERAGE"+ "'", var5.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.4078367818904618d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "87dc3a78d4"+ "'", var16.equals("87dc3a78d4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1893);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0026165793964599026d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
// 
//   }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test410"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double[] var3 = var0.sample(10);
    double var4 = var0.getStandardDeviation();
    double var6 = var0.density(2.345330933436551d);
    boolean var7 = var0.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.025496167636629936d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test411"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 11L);
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, var14);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 11L);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var17);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 1956);
    java.math.BigInteger var21 = null;
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 0L);
    java.math.BigInteger var24 = null;
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 0L);
    java.math.BigInteger var27 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, var26);
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 336L);
    java.math.BigInteger var30 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test412"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)2.5517620356803065E-188d, (java.lang.Number)0.010100839201864612d, true);
//     boolean var5 = var4.getBoundIsAllowed();
//     org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test413"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    var1.addElement(2.0216852347077916d);
    org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var5 = var4.getStandardDeviation();
    double[] var7 = var4.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var12 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var11, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var10, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var9, (java.lang.Object[])var12);
    boolean var16 = var8.equals((java.lang.Object)var9);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var8);
    boolean var19 = var8.equals((java.lang.Object)0.01769023251015941d);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    float var21 = var8.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var23 = var8.getElement(5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2.0f);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test414"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-792111645L), 51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6266588889437241349L));

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test415"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
//     java.lang.Class var5 = var4.getDeclaringClass();
//     java.lang.Class var6 = var4.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
//     java.lang.String var8 = var4.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var10 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var14 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
//     org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var17 = var16.getSupportUpperBound();
//     double[] var19 = var16.sample(10);
//     double var20 = var10.mannWhitneyU(var14, var19);
//     org.apache.commons.math3.distribution.NormalDistribution var21 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var22 = var21.getSupportUpperBound();
//     double[] var24 = var21.sample(10);
//     double var25 = var21.getStandardDeviation();
//     double var27 = var21.density(2.345330933436551d);
//     double[] var29 = var21.sample(180);
//     double var30 = var9.mannWhitneyU(var14, var29);
//     org.apache.commons.math3.distribution.NormalDistribution var31 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var32 = var31.getStandardDeviation();
//     double[] var34 = var31.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var35 = new org.apache.commons.math3.util.ResizableDoubleArray(var34);
//     var35.contract();
//     var35.addElement(0.0d);
//     int var39 = var35.getExpansionMode();
//     double[] var40 = var35.getElements();
//     float var41 = var35.getContractionCriteria();
//     org.apache.commons.math3.distribution.NormalDistribution var42 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var43 = var42.getStandardDeviation();
//     double[] var45 = var42.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var46 = new org.apache.commons.math3.util.ResizableDoubleArray(var45);
//     int var47 = var46.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var48 = var46.copy();
//     var46.addElement((-0.43408597923864894d));
//     double var52 = var46.getElement(0);
//     var46.clear();
//     org.apache.commons.math3.distribution.NormalDistribution var54 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var55 = var54.getStandardDeviation();
//     double[] var57 = var54.sample(1);
//     double var58 = var54.getMean();
//     double[] var60 = var54.sample(100);
//     var46.addElements(var60);
//     double[] var62 = var46.getElements();
//     var35.addElements(var62);
//     org.apache.commons.math3.distribution.NormalDistribution var64 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var65 = var64.getStandardDeviation();
//     double[] var67 = var64.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var68 = new org.apache.commons.math3.util.ResizableDoubleArray(var67);
//     int var69 = var68.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var70 = var68.copy();
//     var68.addElement((-0.43408597923864894d));
//     double var74 = var68.getElement(0);
//     var68.clear();
//     org.apache.commons.math3.distribution.NormalDistribution var76 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var77 = var76.getStandardDeviation();
//     double[] var79 = var76.sample(1);
//     double var80 = var76.getMean();
//     double[] var82 = var76.sample(100);
//     var68.addElements(var82);
//     double[] var84 = var68.getElements();
//     double var85 = var9.mannWhitneyU(var62, var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 27.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.025496167636629936d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 456.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == (-0.22136313545838288d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == (-1.0810165788990012d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 5598.0d);
// 
//   }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test416"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.9492418148147879d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test417"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.014931963725887733d, 0.010100839201864612d);
    double var4 = var2.probability(1.2182350462871465d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test418"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.8136343340898944d, 5950);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test419"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(21L, (-1342156216L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test420"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
    java.lang.Class var14 = var13.getDeclaringClass();
    java.lang.String var15 = var13.toString();
    java.lang.String var16 = var13.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var13);
    org.apache.commons.math3.stat.ranking.NaNStrategy var18 = var17.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var20 = var19.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var19.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var23 = var22.getTiesStrategy();
    java.lang.Class var24 = var23.getDeclaringClass();
    int var25 = var23.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var23);
    org.apache.commons.math3.stat.ranking.NaNStrategy var27 = var26.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var29 = var28.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var30 = var28.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var31 = var28.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var32 = var28.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var34 = var33.getTiesStrategy();
    boolean var36 = var34.equals((java.lang.Object)Double.POSITIVE_INFINITY);
    boolean var38 = var34.equals((java.lang.Object)(-0.4255538433808183d));
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var39 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var32, var34);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var40 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var27, var34);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var41 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var18, var34);
    org.apache.commons.math3.random.RandomGenerator var42 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var43 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18, var42);
    org.apache.commons.math3.stat.ranking.NaturalRanking var44 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var45 = var44.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var46 = var44.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var47 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var48 = var47.getTiesStrategy();
    java.lang.Class var49 = var48.getDeclaringClass();
    int var50 = var48.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var51 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var46, var48);
    org.apache.commons.math3.random.RandomGenerator var52 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var53 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var46, var52);
    org.apache.commons.math3.random.RandomGenerator var54 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var55 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var46, var54);
    org.apache.commons.math3.stat.ranking.NaturalRanking var56 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var46);
    org.apache.commons.math3.stat.ranking.NaturalRanking var57 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var58 = var57.getTiesStrategy();
    java.lang.Class var59 = var58.getDeclaringClass();
    java.lang.Class var60 = var58.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var61 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var46, var58);
    org.apache.commons.math3.util.ResizableDoubleArray var62 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var62.contract();
    org.apache.commons.math3.distribution.NormalDistribution var64 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var65 = var64.getStandardDeviation();
    double[] var67 = var64.sample(1);
    double var69 = var64.cumulativeProbability(0.0d);
    double var70 = var64.getSupportUpperBound();
    boolean var71 = var64.isSupportUpperBoundInclusive();
    var64.reseedRandomGenerator((-16L));
    double[] var75 = var64.sample(2297);
    var62.addElements(var75);
    double[] var77 = var61.rank(var75);
    double[] var78 = var43.rank(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "AVERAGE"+ "'", var16.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test421"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var3);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    java.lang.String var7 = var6.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "AVERAGE"+ "'", var7.equals("AVERAGE"));

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test422"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var11 = var9.getStandardDeviation();
//     double var12 = var9.sample();
//     double var14 = var9.probability(0.9831965750110166d);
//     double var15 = var9.getSupportUpperBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10.27119569869835d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "53d04277c6"+ "'", var8.equals("53d04277c6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.16986106745393842d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.7543798511310535d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test423"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(792111645L, 4L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6880596746291516113L);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test424"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.012616251897226852d, 7.046728077975162d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9857648394656219d);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test425"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(2097152.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2097152.2f);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test426"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double var3 = var0.inverseCumulativeProbability(0.9999999999928669d);
    double var5 = var0.density(25.472636453138065d);
    double var6 = var0.getMean();
    double var7 = var0.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 6.755176609774487d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5.055823438644928E-142d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test427"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var2 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var1);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var5 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var3, (java.lang.Number)(-0.054349963021461445d));
    var2.addSuppressed((java.lang.Throwable)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test428"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(1.2578273612086598E-16d, 0.05018787100240351d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.08172139984932196d);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test429"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(97944);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1027649.9187935544d);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test430"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double[] var15 = var4.getElements();
    int var16 = var4.getExpansionMode();
    var4.setNumElements(0);
    float var19 = var4.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setExpansionFactor(1.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0f);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test431"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-0.06416560144381053d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3877787807814457E-17d);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test432"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(18.860854671741663d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test433"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.38980836088158677d, (-6.573514975132984d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.3898083608815867d);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test434"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-13.986212165712919d), 0.005870341773588088d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 13.986212165712919d);

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test435"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     var0.reSeedSecure();
//     double var18 = var0.nextF(363.7393755555636d, 3.539472048166337d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 30.29322238358034d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "2808317203246e8b11b5da9e10b5146275342d3f04beac5d1a42961da15f7666d1fd5bb4ea6f82fd078d66399b1021182f91"+ "'", var8.equals("2808317203246e8b11b5da9e10b5146275342d3f04beac5d1a42961da15f7666d1fd5bb4ea6f82fd078d66399b1021182f91"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.14078967238605264d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 4.463324522706254d);
// 
//   }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test436"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(0L);
//     long var17 = var0.nextPoisson(7.769493748166378d);
//     double var19 = var0.nextExponential(8.563154148722202d);
//     double var22 = var0.nextWeibull(10.132200867889637d, 2.717220411501478d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var25 = var0.nextPermutation(9864, 11474);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.00387348357715d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "0ea1855a62"+ "'", var8.equals("0ea1855a62"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.056326354690943034d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 8337);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.9949658700499101d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 2.7285663899503576d);
// 
//   }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test437"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var1.substituteMostRecentElement(9.473197167431062d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test438"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    var4.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test439"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc((-1.3153939754132578d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9371495531669236d);

  }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test440"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(0L);
//     long var17 = var0.nextPoisson(7.769493748166378d);
//     double var19 = var0.nextExponential(8.563154148722202d);
//     org.apache.commons.math3.distribution.IntegerDistribution var20 = null;
//     int var21 = var0.nextInversionDeviate(var20);
// 
//   }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test441"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(9.699108969439779d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9626066447946894d));

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test442"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     double var30 = var0.nextExponential(1.0471975511965979d);
//     double var32 = var0.nextChiSquare(0.8382617516745859d);
//     double var34 = var0.nextT(4.724327703255943d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var37 = var0.nextSecureInt(1946, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 19.56141280421755d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ab862bb1fc"+ "'", var8.equals("ab862bb1fc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1958);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.00910597566561064d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-0.7598042599258252d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-0.7920982173377809d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.5754539978544506d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-0.7951334725239231d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 3.022984018010778E-45d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 0.3320275943374953d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.14713268146060465d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1.117352298963628d);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test443"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-1.0328453233143338d), 12.393507168217106d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.08314548357851374d));

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test444"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var1 = null;
    java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    java.math.BigInteger var4 = null;
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0L);
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, var6);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 243);
    org.apache.commons.math3.exception.NumberIsTooLargeException var12 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)var9, (java.lang.Number)(-1.1622852906955334d), false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, (-20));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test445"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)3.9618384776455216d, (java.lang.Number)(-0.25285068072145095d), true);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.25285068072145095d)+ "'", var5.equals((-0.25285068072145095d)));

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test446"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(1859, 9.536745E-7f, 2.5f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test447"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-47.561794942941404d), (java.lang.Number)7.417442685503174d, false);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test448"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double[] var6 = var0.sample(100);
//     double var7 = var0.sample();
//     double var8 = var0.sample();
//     var0.reseedRandomGenerator(10L);
//     boolean var11 = var0.isSupportLowerBoundInclusive();
//     boolean var12 = var0.isSupportUpperBoundInclusive();
//     double var13 = var0.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.7192295413813803d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.5574992050354581d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.0d);
// 
//   }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test449"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.0191751878926154d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test450"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test451"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(186, 1073741825);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test452"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double[] var6 = var0.sample(100);
//     double var7 = var0.sample();
//     double var8 = var0.sample();
//     double var10 = var0.probability((-0.3722334692039834d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.inverseCumulativeProbability(1.0258239749326856d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.4424260161373575d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.6624290175723739d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
// 
//   }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test453"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("7f3682c14258dd8480622b23bc11ead54a1c0f5c12bacc29f8aa9949e2362caa469890f1dc48eca1f01cc65511200050d99df552b56508dccb541e0fc8f4aa1c8f5de429e7197ffb19d114b03e99bcca95adb4ed03451fb69a75c76caffa3e1b23f7ed71953e1ce8aa3e6bc2396a39efa23cabe1ac9520e19ad8b168920c054f8ee5d9bd72bf022a176e47c8197f3a7a5767aa83dbf9bb74ec049ab481a7feda8a10f2037dc087d96b36dbf256a29e656c04c1d90e1613d3a788e223a72d89f9cac2a88f2368691ea1291688c9c328effbde499524e2b49fef908cc5f28fb786eb3bd3d93602a2d41e04df0fa7709d2cda54e1168b5b5f2512fcc0634934a6a0066b4fbeb7e4f70149ebac6e9657d6218e1b1c17b617d59e58dbbefc9834574bdce753650c09047e624fea7032db1f2bb055262637b70c896b708a5636c524447d61fbb762ccb5360a48919b578772bf97012ba1b852e326328a40d84e2c6412127cfb819861344bcc37c0847f5efad2678d61b3080745157e60cd09dbc0c04a3337debdc3b16dc9345c41a284979d5450c573a366b3c6eb6e0b4847c1a7856c04004262e519366a79471931221b5e02f5378205fc5fa8a6951094d729aabc01e1250e5aaa427624bb3b70e3d95b8237b4ab45c6ac0096241a39bccab781c7fa9e32b4381529ecb8fa0df055a9bc653fd2fc0232b1f3478a85c0c7ce50b8d74000be79eaa5b76a40d991480b1a8127b7d005b36e09d757efcf15670e74da2cef0b12dcdfbc9a95b0aaca3fc6f875d6a637946995e4e05edd00f9813d4b3c73d69a87c7658ebc847110f09d7acc97ebb88e90dd94fceeb8d8bdbc6e119634cb4bab42249b6ca8301e8c7697fcc815c42a9a08de30c156c4d68d40ec53e760392bf64421bce2188e62a2da37eac02342cb75e83760059c338dcef57a710d37de56b987a6b05c2f5e4cbc7db065bcdab974630a561d304773f4122e70db146289539841d4d9bc45926b09c0b7f1345ba4b37da9f445cfe520878b324a69c28104aa98df7cc53a1bebe5beeaef43417f843f3fb4a2af072059b9da51314915e053ae1265ecc4e40f3f5069126d1d4cb5039ae5e320efd577178f3c165954ddd0f4e553c820c722a4558afdad219603cab34edf641dbd211a2589b8859c3a9216a930cd24b2b539d22b2d43031cd47ae25b37df117b64ce794fa80d3224779df5a045e92ddab481d355938a2fce273c2898003e7aa0b30bea3355921932d9ea8f90dc56ebf5f46db2b08420799493d05f420ea5b0df5fc2b571d5eb28469651f09af5d3aca0c8ecf1372e014f2d7b07765051eff21d7b63cdc8bda64088ec39d5c194329d75fb69277ae04950a6d1da9e0d6a1f10f68b3a09ac8a87e8580d6c65acd0fc5c8e929c9d93c10b720ee6ae67fe48dafc349b980d48403bfb65a9497e9864a776669f8989beece5f69f227f2138afd986d0a0575e4d23b47bf2044033c8effa1b329969e0d4986420a779f6654c3d28577b0f08fb3bac531a60d851a6331d2842e33df9d361790adf301d7ecc860ed5ea6a0195e4087512a346330ebefccbb8354b4506ab64bce96d8b0c07a29ba6512c36fe6624903623c05b5aa9ce4bd69551837b74b80395cf0790ca659e25fdf205ac86634aec4ae85e163890b709fa625f037c46e2e2b4a695f16fa822f20d3ad057f27dee1aed4ffe1e1d989fd943202d28328cc0941bb3e9b6298c04d9be557b364faeb872be8454a358fc1dd8560e7ac0a527ed944ade8a2c4729c61d0132c692270cbdea1632ad906ec3f17c215604a135419a97f88ef5d746dcdfbe6bcd9adc95c9b56c4c88df78143f230a6659a0273d8b435ea3060c544dd07cc244a79a1f632412bd4971ab800624acdacbdd505ded07c471fde819dc0909057c4c219c6809d3b2934987134dffadcc33d2c51907044ce10df112f936eedaa4b4614a7967c643b4f52bef21b6d4652a7328bbe0f6025a98989f142eba5c347e6589cd7f2e3ecc3859630209491b381ee78cbb92f74416f0c16690b8f6ca544bd9e28f26c1ef88f6c0b6d7c3496c8a62e47b2442bc2d33190b260c59e310a193b5bf6d51aec3698994f1b8a4a9a0b274504925f285125b5f69cc5413f8251ae6354413744fe1b2a0b3b74d7495edcaef2487c6bd3b31409bf85bd3b06b153f4b89c7492755707787821faf7966cbbdec7430a63e2369428c784a60cf0ccd65ba893515f4b4339ff8b99ea547c05624fb9f5db3b85994c406e9668f356ad462033978fa04b9ea8a64fa50a04cb73066970a3ceabaf43e1b834fbbc2afe265ecbe0a0ae11dfd4afdec7407358dc07a8aca914022c32a1bf25b165fdb6e1c4dcfe200338dfb7b0c4c61011056a08360fc1d32ea596293bf03321a8b55b2693125161e9fd6027109d9fbbcf0817001fad2dbdb8e93d4b7bc80d2bac4fbdaeef0babeccc24627b3833ffcbbbf0d99af8b45bb9b89419a46b5e75224c7d7e3760923d8226f9067d010f36df7a9a729ca0fc4332444551c716ae04dc59346e89dab0902f988896175e730c61e7c5093a6723c7a2f2886bf7b301370d28cb9bd57013bff02a9fb10765c99b4b2e84391f858868056f195415e828f39828ccb7bb6d5b0afee5ebbbcc5e33cebacd54f65ed98fde0f4730fa65500ad512cb67c1c8c35688c911f1b3e7ef300dabdc9fa");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test454"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.0d, (-4));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test455"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(8.125467547535871d);
//     double var5 = var0.nextWeibull(0.8957380763521041d, 0.8057138887308153d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 4.592006298127415d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.0743630386030425d);
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test456"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1498);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test457"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1.4884958348083221d);
    java.lang.Number var2 = var1.getMax();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var1.getContext();
    java.lang.Number var4 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 1.4884958348083221d+ "'", var2.equals(1.4884958348083221d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.4884958348083221d+ "'", var4.equals(1.4884958348083221d));

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test458"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.1368684E-13f, (java.lang.Number)96, true);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var12 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var13 = new org.apache.commons.math3.exception.MaxCountExceededException(var10, (java.lang.Number)(-1), (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var9, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var8, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MaxCountExceededException var16 = new org.apache.commons.math3.exception.MaxCountExceededException(var6, (java.lang.Number)3.1039797472520814d, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, (java.lang.Object[])var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test459"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.815297812486526d);
//     org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test460"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(7, 9424);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test461"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.0031612049524534893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000049966125368d);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test462"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-2.220570418233359d), (java.lang.Number)6.54642801564943d, true);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test463"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.943576962045356d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test464"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.14608902069952245d, 3.84074378609149d, 1.380627352707058d);
    double var5 = var3.probability(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test465"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos((-0.43408597923864894d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.019819759043043d);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test466"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1988, (-933400799));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test467"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum((-8.112963841460668E31d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test468"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var1, (java.lang.Number)(-64L), (java.lang.Number)(-1.4998528973459138d), false);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test469"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum((-0.5944808302367326d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test470"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextUniform(0.2577047455984825d, 13.770182159584014d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var7 = var1.nextSecureLong(336L, 241L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.247943454954983d);
// 
//   }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test471"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(201600L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test472"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(6.409807892850133d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test473"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(8.16295314101948d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0134882573780497d);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test474"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(4.149647634883433d, 1.402946643516479d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.044855014049433824d);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test475"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var3.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test476"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin((-0.21197904983175375d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.21359958774772642d));

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test477"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(0, 10240);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test478"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(3.1040481002909335d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test479"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1818, 1.1368683E-13f, Float.POSITIVE_INFINITY, 11122);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test480"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(1.0494464950714408d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.71756975428893d);

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test481"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow((-0.7618917772261586d), 0.8678437901632892d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test482"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextUniform(0.9059266752857845d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.920043435503309d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
// 
//   }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test483"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(22L, 319L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 22L);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test484"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(22.488113044724955d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.840679879452236E9d);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test485"); }


    double var2 = org.apache.commons.math3.special.Erf.erf((-1.509983016796422d), 0.1794257117280909d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1675832066593317d);

  }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test486"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     long var12 = var0.nextPoisson(0.022129300557461942d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12.156051169789169d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1f4ce8d10a"+ "'", var8.equals("1f4ce8d10a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.2927598550805989d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0L);
// 
//   }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test487"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)2.566440443196982d, (java.lang.Number)1910, true);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test488"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("d5591445cb");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test489"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(305, 11122);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3392210);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test490"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(4.0434293412271454E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.020108280237820304d);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test491"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     var0.reSeed();
//     var0.reSeedSecure(193L);
//     org.apache.commons.math3.distribution.IntegerDistribution var12 = null;
//     int var13 = var0.nextInversionDeviate(var12);
// 
//   }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test492"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     var0.reSeed(14L);
//     double var14 = var0.nextExponential(0.9999997887160175d);
//     double var17 = var0.nextBeta(4.0434293412271454E-4d, 0.17971249487899976d);
//     double var21 = var0.nextUniform((-2.222243528679365d), 0.0d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 13.024850069430421d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "bd6f31a659"+ "'", var8.equals("bd6f31a659"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.3687784142034636d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.3844973909690124d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-0.1910854532327787d));
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test493"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(100.00001f, 0.6351254179184792d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test494"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1865.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4482083557958737d);

  }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test495"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var14 = var0.nextBeta(3628800.0d, 1.1752011936438014d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextBinomial((-127), (-3.244985903582095d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 14.524475568714204d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "3ed4c4c9a5"+ "'", var8.equals("3ed4c4c9a5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.9999999851638934d);
// 
//   }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test496"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     var0.reSeed(14L);
//     double var15 = var0.nextCauchy(7.362895734466076d, 3.63988988172153d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 14.923559779399769d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "308473ea56"+ "'", var8.equals("308473ea56"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.15636668179139937d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-6.529433490302414d));
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test497"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextWeibull(7.769493748166378d, 1.2185657441986304d);
//     var0.reSeed((-6266588889437241349L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.091889819827183d);
// 
//   }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test498"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     double[] var5 = var4.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
//     double[] var7 = null;
//     var6.addElements(var7);
// 
//   }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test499"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-1.5157441040969926d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9679339159763662d));

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test500"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1.3901021467651349d);

  }

}
