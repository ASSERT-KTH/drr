
import junit.framework.*;

public class RandoopTest7 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test1"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getStandardDeviation();
//     double[] var13 = var10.sample(1);
//     double var15 = var10.cumulativeProbability(0.0d);
//     double var16 = var10.getSupportUpperBound();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var0.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.3210130979804413d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.1803173195097953d);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test2"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(1955, 14870406);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1955);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test3"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.5080318112008301d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.662016810828726d);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test4"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(1.20315545057639648E17d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 39.3288942286425d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test5"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    boolean var8 = var6.equals((java.lang.Object)Double.POSITIVE_INFINITY);
    boolean var10 = var6.equals((java.lang.Object)(-0.4255538433808183d));
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var14);
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test6"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(1.3104251711043777E-106d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4786564631117545E-106d);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test7"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.4128411121633297d, (java.lang.Number)0.0f, (java.lang.Number)3.2359311173302077d);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getHi();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var3.getContext();
    java.lang.String var7 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.0f+ "'", var4.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 3.2359311173302077d+ "'", var5.equals(3.2359311173302077d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: 1.413 out of [0, 3.236] range"+ "'", var7.equals("org.apache.commons.math3.exception.OutOfRangeException: 1.413 out of [0, 3.236] range"));

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test8"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(100.0f, 1.1368683E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test9"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-64L), (java.lang.Number)(-1.4998528973459138d), false);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    java.lang.Number var6 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1.4998528973459138d)+ "'", var6.equals((-1.4998528973459138d)));

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test10"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(2.773881834450058d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.224793205566016d);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test11"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(12.033846781268247d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0480937679486297d);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test12"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    boolean var7 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator((-16L));
    double var11 = var0.cumulativeProbability(0.0d);
    boolean var12 = var0.isSupportLowerBoundInclusive();
    double var14 = var0.probability(7.724435900937391d);
    double[] var16 = var0.sample(100);
    double var17 = var0.sample();
    double var20 = var0.cumulativeProbability(1.0202695258192494E-4d, 0.33032554595260544d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.7233703768189484d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.12938230094830172d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test13"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.0740960524045222d, 1.235382052479336d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0740960524045224d);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test14"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(319L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 319L);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test15"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-6266588889437241349L), 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6266588889437241339L));

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test16"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1646);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1646);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test17"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.257156203792693d, (-0.7938205914625687d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.1340143234151143d);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test18"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2097152.0f, 657);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test19"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(7.911749035071693d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.9117490350716935d);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test20"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.2075656224493654d, 0.9996587052669305d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2075656224493652d);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test21"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1.5260880873743516d);
    java.lang.Number var2 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 1.5260880873743516d+ "'", var2.equals(1.5260880873743516d));

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test22"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-0.703678356020831d), 10.629103431631437d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test23"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var9 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var5, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
//     java.lang.Throwable[] var10 = var9.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, (java.lang.Object[])var10);
//     org.apache.commons.math3.exception.MathArithmeticException var12 = new org.apache.commons.math3.exception.MathArithmeticException(var3, (java.lang.Object[])var10);
//     org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var10);
//     org.apache.commons.math3.exception.MaxCountExceededException var14 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.14608902069952245d, (java.lang.Object[])var10);
//     org.apache.commons.math3.exception.util.Localizable var15 = null;
//     org.apache.commons.math3.exception.util.Localizable var16 = null;
//     org.apache.commons.math3.exception.util.Localizable var17 = null;
//     org.apache.commons.math3.exception.util.Localizable var18 = null;
//     java.lang.Number var19 = null;
//     org.apache.commons.math3.exception.util.Localizable var20 = null;
//     org.apache.commons.math3.exception.util.Localizable var22 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var24 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MaxCountExceededException var25 = new org.apache.commons.math3.exception.MaxCountExceededException(var22, (java.lang.Number)(-1), (java.lang.Object[])var24);
//     org.apache.commons.math3.exception.MaxCountExceededException var26 = new org.apache.commons.math3.exception.MaxCountExceededException(var20, (java.lang.Number)1.4128411121633297d, (java.lang.Object[])var24);
//     org.apache.commons.math3.exception.MaxCountExceededException var27 = new org.apache.commons.math3.exception.MaxCountExceededException(var18, var19, (java.lang.Object[])var24);
//     org.apache.commons.math3.exception.MathIllegalStateException var28 = new org.apache.commons.math3.exception.MathIllegalStateException(var17, (java.lang.Object[])var24);
//     org.apache.commons.math3.exception.NullArgumentException var29 = new org.apache.commons.math3.exception.NullArgumentException(var16, (java.lang.Object[])var24);
//     org.apache.commons.math3.exception.MathIllegalStateException var30 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var14, var15, (java.lang.Object[])var24);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test24"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)6.594078672416073E8d, (java.lang.Number)0.003960709268216542d, false);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test25"); }


    double[] var3 = new double[] { 0.0d, (-1.0d), 0.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setExpansionMode(8);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test26"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.9999686853143476d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.718196707650845d);

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test27"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.9999999999999925d);
//     java.lang.String var3 = var2.toString();
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test28"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.013292325585375278d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.01329232558537528d);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test29"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)1859, (java.lang.Number)0.0333355513777982d);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test30"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(10.000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.536743E-7f);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test31"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 243);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 76L);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 20355937);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, (-5071615437313169176L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test32"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-1.9560314953337563d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.14141852888218237d);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test33"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.21635711892824916d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test34"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(9181, 99.99999f);
    double var4 = var2.addElementRolling(0.8725996883920981d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test35"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(0L);
//     long var17 = var0.nextPoisson(7.769493748166378d);
//     double var19 = var0.nextExponential(8.563154148722202d);
//     double var22 = var0.nextWeibull(10.132200867889637d, 2.717220411501478d);
//     var0.reSeedSecure(201600L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9.486666117215478d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "928ef0e24b"+ "'", var8.equals("928ef0e24b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.47353996882709365d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 9963);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.4703828505018744d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 2.200594105225602d);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test36"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.2702896443043805d, 14.031149057314524d, (-0.6899951741902008d));

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test37"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    var4.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var4.copy();
    int var10 = var4.getExpansionMode();
    int var11 = var4.start();
    int var12 = var4.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test38"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(20901888L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test39"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.cumulativeProbability((-0.5745618421848383d));
    boolean var3 = var0.isSupportLowerBoundInclusive();
    double var5 = var0.density(0.0031612049524534893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.28279383239600014d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.39894028704807305d);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test40"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    var1.setNumElements(11274);
    int var4 = var1.start();
    double var6 = var1.getElement(9181);
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test41"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)0.17994611088998624d, true);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test42"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(136, 192);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3264);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test43"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1868, 23L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test44"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.2869055500219597d, 0.46500210138368253d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.10810075412908787d));

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test45"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.044855014049433824d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.1043199007520377d));

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test46"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(1856);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test47"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     int var11 = var0.nextZipf(5, 0.8273572477024794d);
//     int var14 = var0.nextBinomial(1972, 0.15795521463156686d);
//     var0.reSeed();
//     var0.reSeedSecure(0L);
//     long var20 = var0.nextLong((-2L), 760L);
//     double var23 = var0.nextCauchy(7.769493748166378d, 41.00598452531734d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.632067507984996d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "82642d5431b9f94a1fa5a04bc6c33cadc44a6ce713665779555478d97897c11928fc07a92f7db12c791f34643555fb4f38c0"+ "'", var8.equals("82642d5431b9f94a1fa5a04bc6c33cadc44a6ce713665779555478d97897c11928fc07a92f7db12c791f34643555fb4f38c0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 321);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 617L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 16.4324585534432d);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test48"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var5 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var4, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.6894714982128501d, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test49"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.0755947130980142d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.3312580140185375d);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test50"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.03160874217224052d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.03211360376884049d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test51"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.07307369578140543d);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test52"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(317);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test53"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.9029384322790375d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.966538993199365d);

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test54"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     double var9 = var0.nextF(2.281783181607902d, 0.8427007929497151d);
//     double var12 = var0.nextGaussian(1.5498468927479463d, 1865.0d);
//     double var14 = var0.nextExponential(1.2042143530169682d);
//     double var17 = var0.nextGamma(0.2056151686980249d, 8.854558633913316d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var19 = var0.nextSecureHexString((-297258196));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.698697449780848d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.21094000675518862d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-782.3573691894716d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.945040899351198d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.070790560248949d);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test55"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var4 = var3.getStandardDeviation();
    double[] var6 = var3.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    double[] var8 = var7.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var16 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var12, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var17 = var16.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var18 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var11, (java.lang.Object[])var17);
    org.apache.commons.math3.exception.MathArithmeticException var19 = new org.apache.commons.math3.exception.MathArithmeticException(var10, (java.lang.Object[])var17);
    boolean var20 = var9.equals((java.lang.Object)var17);
    double[] var21 = var9.getElements();
    double[] var22 = var0.rank(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test56"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.5d, (java.lang.Number)0.5950413774252329d, false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.5950413774252329d+ "'", var5.equals(0.5950413774252329d));

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test57"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(1831);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11929.278017117034d);

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test58"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var4.addElement((-0.43408597923864894d));
//     double var10 = var4.getElement(0);
//     double[] var11 = var4.getElements();
//     var4.addElement(21.0d);
//     var4.setNumElements(3);
//     org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var17 = var16.getStandardDeviation();
//     double[] var19 = var16.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
//     var20.contract();
//     int var22 = var20.getNumElements();
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var20);
//     org.apache.commons.math3.util.ResizableDoubleArray var24 = var4.copy();
//     var4.addElement(648.230953682526d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.24441930484563598d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test59"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(12185.029950707305d, 0.9999494975001091d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.15732017207537896d));

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test60"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     double var14 = var0.nextChiSquare(4.950886585270677E-4d);
//     double var17 = var0.nextUniform(0.0d, 1.0076199721400823d);
//     var0.reSeed();
//     double var21 = var0.nextGaussian(1.224793205566016d, 0.9469934586322785d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.2622261001534978d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "43643b7ac9"+ "'", var8.equals("43643b7ac9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.4328197799036929E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.7895105047158603d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.9590416566058654d);
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test61"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.5481764785100467d, (-1.489479862150504d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5481764785100467d);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test62"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(2391.4058730231495d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2391.0d);

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test63"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(116.37840993773725d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test64"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(15.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 25.191221182738687d);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test65"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.007740528947110199d);
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: 0.008 is smaller than, or equal to, the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: 0.008 is smaller than, or equal to, the minimum (0)"));

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test66"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(29L, 42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2058820555291694441L);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test67"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(6.474290387216851d, 0.017688387388495763d);
    boolean var3 = var2.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test68"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(35.325404896545464d, (-0.7388836490239469d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 35.33313147955716d);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test69"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 243);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 76L);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 20355937);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 1541);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test70"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(3.2020584262095704d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.268094485163345d);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test71"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(67, 9448);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9448);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test72"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double[] var3 = var0.sample(10);
    boolean var4 = var0.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test73"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.025447064960620585d, (java.lang.Number)1.8656062934668467d, false);
    java.lang.Number var4 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.8656062934668467d+ "'", var4.equals(1.8656062934668467d));

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test74"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(26.41790872611167d, 9448);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test75"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextUniform(8.105055920445338d, 0.3817640040286389d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.717719777387541d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f7eb2f9b7e"+ "'", var8.equals("f7eb2f9b7e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test76"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(2097152.2f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2097152);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test77"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var6);
    java.lang.String var9 = var6.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var10 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var12 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "AVERAGE"+ "'", var9.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "MAXIMAL"+ "'", var12.equals("MAXIMAL"));

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test78"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-0.6801548754218844d), (java.lang.Number)11.521860423020517d, true);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test79"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1646, 186);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1832);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test80"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    var4.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = var4.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.discardMostRecentElements((-8889));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test81"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var3);
    java.lang.String var6 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test82"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(118, 5950);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 702100);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test83"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(3483820, 1.1368684E-13f, 99.999985f, 114);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test84"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(1935, 1836);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1836);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test85"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.1368686E-13f, 2.384186E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1368686E-13f);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test86"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.8427007929497151d, 0.2165005641975397d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.26495626491431057d);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test87"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-1.064524325544892d), (java.lang.Number)(-408490575), (java.lang.Number)1990);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test88"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.6901124746731373d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8837036035804766d);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test89"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
    java.lang.Object var17 = null;
    boolean var18 = var4.equals(var17);
    var4.setElement(100, 0.0d);
    double[] var22 = var4.getInternalValues();
    float var23 = var4.getExpansionFactor();
    int var24 = var4.getExpansionMode();
    var4.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test90"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2.5000002f, 18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 655360.06f);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test91"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-8L), (-6266588889437241339L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test92"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("263c07e599", "f3ae8740a03dfef9748b65388148810636968d1dd8b8b00310c38f292aa967268dfd9b58ca788a853550fd0d456b99de8a58");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-2.2787835856053116d));
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test93"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.4663611619490422d, var2);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test94"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 11L);
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, var14);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 1949);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, var17);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 1845);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, 136);
    java.math.BigInteger var23 = null;
    java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, 0L);
    java.math.BigInteger var26 = null;
    java.math.BigInteger var28 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 0L);
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, var28);
    java.math.BigInteger var31 = org.apache.commons.math3.util.ArithmeticUtils.pow(var28, 243);
    java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var31, 76L);
    java.math.BigInteger var35 = org.apache.commons.math3.util.ArithmeticUtils.pow(var33, 20355937);
    java.math.BigInteger var36 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test95"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     var0.reSeed(14L);
//     double var14 = var0.nextExponential(0.9999997887160175d);
//     double var17 = var0.nextBeta(4.0434293412271454E-4d, 0.17971249487899976d);
//     var0.reSeed(0L);
//     double var21 = var0.nextExponential(1.1526881743814081d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15.25256584365584d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "42ab1cabd1"+ "'", var8.equals("42ab1cabd1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.759037311756944d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.3844973909690124d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.5607635869100653d);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test96"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(2068, (-1032474271));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test97"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(163822260L, 2120L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 163824380L);

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test98"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(0.5692664420629978d, (-2.1317775244386943d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test99"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    java.lang.Class var16 = var14.getDeclaringClass();
    boolean var18 = var14.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    java.lang.Class var19 = var14.getDeclaringClass();
    java.lang.Class var20 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var14);
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var24 = var2.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "MAXIMAL"+ "'", var24.equals("MAXIMAL"));

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test100"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var14 = var0.nextWeibull(0.001908508257396575d, 1.06784626178585d);
//     long var17 = var0.nextSecureLong(22L, 163822260L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.825421147865245d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "419c71badb"+ "'", var8.equals("419c71badb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1886);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.1797167837849394E107d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 87491968L);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test101"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)3.1039797472520814d, (java.lang.Number)97.88222946238736d, false);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test102"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("9fc8aa73a5");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test103"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var4 = var1.toString();
    java.lang.String var5 = var1.name();
    java.lang.String var6 = var1.toString();
    int var7 = var1.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "AVERAGE"+ "'", var5.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test104"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     double var9 = var0.nextUniform(0.0d, 0.5382762305934016d);
//     double var12 = var0.nextGaussian(0.16477040754512196d, 0.9999996994297856d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("3a42c5474d17bd274c76cd2cb75707f205dca245d0633058360554eb6554a5d621502053afad03616967f86aebeca0c73663", "53d04277c6");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.0266633738526483d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.2551608393570196d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.7943901680727532d);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test105"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var9);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var11.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var15, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14, var17);
    java.lang.String var20 = var17.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var13, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var23 = var22.getTiesStrategy();
    java.lang.Class var24 = var23.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23);
    java.lang.String var26 = var23.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var27 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var13, var23);
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "AVERAGE"+ "'", var26.equals("AVERAGE"));

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test106"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getStandardDeviation();
//     double[] var13 = var10.sample(1);
//     double var15 = var10.cumulativeProbability(0.0d);
//     double var16 = var10.getSupportUpperBound();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var22 = var0.nextHypergeometric(0, 1910, 9679);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.59008365325801d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0756021525025523d);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test107"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(0, 1933);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test108"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    double[] var5 = var4.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var13 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var9, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var14 = var13.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var8, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MathArithmeticException var16 = new org.apache.commons.math3.exception.MathArithmeticException(var7, (java.lang.Object[])var14);
    boolean var17 = var6.equals((java.lang.Object)var14);
    double[] var18 = var6.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setExpansionFactor(10.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test109"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(8.535667735449547d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.0d);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test110"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(100L, 1135069411L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 113506941100L);

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test111"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     var4.contract();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var6.contract();
//     org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var9.getStandardDeviation();
//     double[] var12 = var9.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
//     int var14 = var13.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var15 = var13.copy();
//     var13.addElement((-0.43408597923864894d));
//     double var19 = var13.getElement(0);
//     double[] var20 = var13.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
//     var6.addElements(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-1.0296314616092215d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test112"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.8668721092811237d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6472141263376315d);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test113"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5430806348152437d);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test114"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.9792351001360415d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test115"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 54);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test116"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(437L, 8L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1833982015598883169L);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test117"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     int[] var9 = var0.nextPermutation(11213, 1203);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextSecureInt(20355937, 37);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-2.4396661486906006d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test118"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(2.2702896443043805d, (-0.1901543518195821d), 0.0d, 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test119"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.4000591571530008d, (java.lang.Number)8, (java.lang.Number)(-2.225482993439564d));
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2.7589241763811208d, (java.lang.Number)1.1752011936438014d, true);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var9 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var8, var9);
    var3.addSuppressed((java.lang.Throwable)var7);
    java.lang.Number var12 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 8+ "'", var12.equals(8));

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test120"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos((-0.4634046666243402d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 74.16451825672664d);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test121"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(832L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test122"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-0.046561114627056484d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.04549377550453836d));

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test123"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.014931963725887733d, 0.010100839201864612d);
    double var3 = var2.getNumericalMean();
    double var4 = var2.getNumericalVariance();
    double var6 = var2.cumulativeProbability(4.5d);
    boolean var7 = var2.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.014931963725887733d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0202695258192494E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test124"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1935, 51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-843938129));

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test125"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(7.825421147865245d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.028556603463002962d);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test126"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    boolean var7 = var0.isSupportUpperBoundInclusive();
    boolean var8 = var0.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test127"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(43);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test128"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.01329232558537528d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.013291542812767239d);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test129"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(40422L, (-5071615437313169176L));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test130"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
//     java.lang.Class var5 = var4.getDeclaringClass();
//     java.lang.Class var6 = var4.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
//     java.lang.String var8 = var4.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getStandardDeviation();
//     double[] var13 = var10.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var19 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
//     double[] var24 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
//     double var26 = var15.mannWhitneyU(var19, var24);
//     double var27 = var9.mannWhitneyUTest(var13, var19);
//     org.apache.commons.math3.distribution.NormalDistribution var28 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var29 = var28.getStandardDeviation();
//     double[] var31 = var28.sample(1);
//     double var32 = var28.getMean();
//     double[] var34 = var28.sample(100);
//     boolean var35 = var28.isSupportLowerBoundInclusive();
//     boolean var36 = var28.isSupportUpperBoundInclusive();
//     double var39 = var28.cumulativeProbability(0.0d, 0.25587682077976953d);
//     double var40 = var28.getSupportUpperBound();
//     double[] var42 = var28.sample(11274);
//     org.apache.commons.math3.distribution.NormalDistribution var46 = new org.apache.commons.math3.distribution.NormalDistribution((-4.440892098500626E-16d), 1.1102230246251565E-16d, 0.9999494957997512d);
//     double[] var48 = var46.sample(1972);
//     double var49 = var9.mannWhitneyUTest(var42, var48);
//     org.apache.commons.math3.util.ResizableDoubleArray var50 = new org.apache.commons.math3.util.ResizableDoubleArray(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 4.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.17971249487899976d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0.10097702336242761d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 0.49667185183131635d);
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test131"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     double var30 = var0.nextExponential(1.0471975511965979d);
//     int var33 = var0.nextZipf(36, 1.6449340668481562d);
//     java.lang.String var35 = var0.nextHexString(1943);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.776182421640576d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ce379bfe32"+ "'", var8.equals("ce379bfe32"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1911);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.013984286871349448d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1.2251275799309957d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.8936792579521354d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.3409202657269044d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.5076501006332114d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1617.63930912464d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 0.7261065250648808d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + "614696c3efc46e434a936689f957bf4d5c6caab1a7f0a053d79e275ea4fc0e8bc1bf309f43277b7f193b32c47f6b5ae2897d0250452b2e2a34c1e9b87150be6c3075fe01d9817d8dcff0a354cc03d90747167c91edacff0c359aafc157a0529cec1d69be9b481f7e7bb48cb07437ec6d82b371c3f64e533393d49cf0ddead3826aacffa3447708778e009d721b94a6b57b58285ea5a73b7b2a8183f0b881d5d5b6be208d125e48b1577cd40f2ce63fd5f22e3b64c2bffd32266fc6ee66a3c65213f42a2bd9f5516173f015eef6e07bccf29830a14f5fc8f468a6af4205d24cc3f8d385bed110fe41d64fb4f89cd620750955c5d7c066e301ec5b8b253d5c3ace80f321115bf068d743687556814b16cc1fc2fbce45964d3f266a7c4d1e476f535666418480b51b2e1bba45c5fa5b368524eecaba779e58dd73135bb04d85e5a16eb8bd4c56634544c22ca9537c931b48df6fbd2ee4cf64715b9faa2564bf8310b0badb661b48cfc19cc8a5aaced72b78b7ad431bff2756d305c7026b46a494f5f4e9b942e03553a3c6f7468008ce4206eeaf0e52a840f2892c64d63a3c217cd5cd16d589c7849de36c8303e4a2ce0a0d0edfa605857a279be67d77806de831b70e82e87e658ec688fcb815d91db82b7436b9b9bdd7c0796ceedc2b92e12d60f15139a8f606740b73aa7e93b323e92c17f0b32c61f78651238202e5f2c77238f1e0d0c321e1644f04fc10715bc34e066fd8886c541983c37e9842fd829ee0983f7d9bd0404ebd92ce6a157f548d87b0987de9632dfc6a2ece9a98a8617cb172be85c8e5759b33aeebc0f9ab7d911bc70cce0aee6a909182e6627e8ed5e1548840700287d32a376073ea7b616c07736722ca01033c18d635a4019e71afb6feb160abfa4ba72be31bc1616acf0944c4ca3c5ef187d2780e269d7afec8d85c81c1ac837eadbc4edda463efcd9e8ad44e3444dd74b8bc3fa1d0433677e5fc9257be0128f793c6ba2ba4a207a814a05b60391b2cdf6177de48cb5f06766ef0b31129e6b47494257779b77fcb94e429bbe02222229e30a51a26467f441de5e69184a7a63d7dd3d581fe817aff23fce41f292dd3a2d20fe81e96e31e8fb7090a0eafb7cc56d307fc44628c3596fd80eaa4e7bbff6034c3c3d0f02a636f6da30c1cbc940ece07a44b10803445bbc14bf4b39a341865e5541069db7979b3bfc4d6321ab3f9426a81dcd84a45aa9980fc6368542fb1cc09caac8af1234080e7ccee0c265e2e4d5f082acabdd5576d64cdbf5ebabdc8dd1745e9d2c01b76df4d3cf611d001f489a944e440f499c1a800a1073abcf88843336c24eec967d5d9317697ae70e9a1537495fb4f526333ebf4e74"+ "'", var35.equals("614696c3efc46e434a936689f957bf4d5c6caab1a7f0a053d79e275ea4fc0e8bc1bf309f43277b7f193b32c47f6b5ae2897d0250452b2e2a34c1e9b87150be6c3075fe01d9817d8dcff0a354cc03d90747167c91edacff0c359aafc157a0529cec1d69be9b481f7e7bb48cb07437ec6d82b371c3f64e533393d49cf0ddead3826aacffa3447708778e009d721b94a6b57b58285ea5a73b7b2a8183f0b881d5d5b6be208d125e48b1577cd40f2ce63fd5f22e3b64c2bffd32266fc6ee66a3c65213f42a2bd9f5516173f015eef6e07bccf29830a14f5fc8f468a6af4205d24cc3f8d385bed110fe41d64fb4f89cd620750955c5d7c066e301ec5b8b253d5c3ace80f321115bf068d743687556814b16cc1fc2fbce45964d3f266a7c4d1e476f535666418480b51b2e1bba45c5fa5b368524eecaba779e58dd73135bb04d85e5a16eb8bd4c56634544c22ca9537c931b48df6fbd2ee4cf64715b9faa2564bf8310b0badb661b48cfc19cc8a5aaced72b78b7ad431bff2756d305c7026b46a494f5f4e9b942e03553a3c6f7468008ce4206eeaf0e52a840f2892c64d63a3c217cd5cd16d589c7849de36c8303e4a2ce0a0d0edfa605857a279be67d77806de831b70e82e87e658ec688fcb815d91db82b7436b9b9bdd7c0796ceedc2b92e12d60f15139a8f606740b73aa7e93b323e92c17f0b32c61f78651238202e5f2c77238f1e0d0c321e1644f04fc10715bc34e066fd8886c541983c37e9842fd829ee0983f7d9bd0404ebd92ce6a157f548d87b0987de9632dfc6a2ece9a98a8617cb172be85c8e5759b33aeebc0f9ab7d911bc70cce0aee6a909182e6627e8ed5e1548840700287d32a376073ea7b616c07736722ca01033c18d635a4019e71afb6feb160abfa4ba72be31bc1616acf0944c4ca3c5ef187d2780e269d7afec8d85c81c1ac837eadbc4edda463efcd9e8ad44e3444dd74b8bc3fa1d0433677e5fc9257be0128f793c6ba2ba4a207a814a05b60391b2cdf6177de48cb5f06766ef0b31129e6b47494257779b77fcb94e429bbe02222229e30a51a26467f441de5e69184a7a63d7dd3d581fe817aff23fce41f292dd3a2d20fe81e96e31e8fb7090a0eafb7cc56d307fc44628c3596fd80eaa4e7bbff6034c3c3d0f02a636f6da30c1cbc940ece07a44b10803445bbc14bf4b39a341865e5541069db7979b3bfc4d6321ab3f9426a81dcd84a45aa9980fc6368542fb1cc09caac8af1234080e7ccee0c265e2e4d5f082acabdd5576d64cdbf5ebabdc8dd1745e9d2c01b76df4d3cf611d001f489a944e440f499c1a800a1073abcf88843336c24eec967d5d9317697ae70e9a1537495fb4f526333ebf4e74"));
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test132"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var8 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var4, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test133"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(11531, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test134"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.08556937673988257d, 5.186154479812513d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.622462881095657E-5d);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test135"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(56L, 5071615437313169417L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test136"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(1343, 1906);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-563));

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test137"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(16.929171950095395d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 16.929171950095395d);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test138"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(9448, Float.POSITIVE_INFINITY);
    int var3 = var2.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test139"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var4 = var0.getMean();
    double var5 = var0.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test140"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 336L);
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, var14);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 11L);
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    java.math.BigInteger var21 = null;
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 0L);
    java.math.BigInteger var24 = null;
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 0L);
    java.math.BigInteger var27 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, var26);
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, 6L);
    org.apache.commons.math3.exception.OutOfRangeException var30 = new org.apache.commons.math3.exception.OutOfRangeException(var18, (java.lang.Number)5.363952139253263d, (java.lang.Number)14.087081017797523d, (java.lang.Number)var29);
    java.math.BigInteger var31 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, var29);
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, var31);
    java.math.BigInteger var34 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test141"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.33765583161665175d, (-1.0082650460352727d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0082650460352727d));

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test142"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double var3 = var0.inverseCumulativeProbability(0.9999999999928669d);
    double var4 = var0.getMean();
    double var5 = var0.getNumericalVariance();
    var0.reseedRandomGenerator(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 6.755176609774487d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test143"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(2.220446049250313E-16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test144"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, 832L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test145"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(152.40959258449737d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8732.426412400067d);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test146"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(9.536743E-7f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0f);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test147"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-81.0584148752008d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5834694007285642d);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test148"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var14.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var13, var15);
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var15);
    java.lang.String var18 = var15.name();
    java.lang.Class var19 = var15.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var15);
    int var21 = var15.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "AVERAGE"+ "'", var18.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 3);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test149"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.8416025804595201d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3755506720016193d);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test150"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(2.200594105225602d, 0.03211360376884049d);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test151"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(9.536744E-7f, 1.1368685E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.536744E-7f);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test152"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-4.440892098500626E-16d), 1.1102230246251565E-16d, 0.9999494957997512d);
    double var4 = var3.getMean();
    double var6 = var3.density(100.0d);
    double var7 = var3.getSupportUpperBound();
    boolean var8 = var3.isSupportLowerBoundInclusive();
    double var9 = var3.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-4.440892098500626E-16d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.232595164407831E-32d);

  }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test153"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(2.095003270872298d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test154"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(13.672682806945344d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 14.0d);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test155"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getStandardDeviation();
//     double[] var13 = var10.sample(1);
//     double var15 = var10.cumulativeProbability(0.0d);
//     double var16 = var10.getSupportUpperBound();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     double var20 = var0.nextUniform((-0.46723055192344254d), 0.004492688352124083d);
//     int var23 = var0.nextBinomial(1952, 0.7625552649455967d);
//     double var26 = var0.nextWeibull(0.3613755384667159d, 4.252640503606456d);
//     int var29 = var0.nextSecureInt((-933400799), 9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var32 = var0.nextF((-2.6159843945565986d), 1.2411313939991078d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.90806718947514d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.05433917282256734d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-0.2796732414823411d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1499);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1.6833883939330427d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == (-652746831));
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test156"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.9604645E-8f);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test157"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var4 = var0.getMean();
    double[] var6 = var0.sample(100);
    boolean var7 = var0.isSupportLowerBoundInclusive();
    boolean var8 = var0.isSupportUpperBoundInclusive();
    double var11 = var0.cumulativeProbability(0.0d, 0.25587682077976953d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var13 = var0.sample((-2));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.10097702336242761d);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test158"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 11L);
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, var14);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 1949);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, var17);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 11L);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, 1570);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test159"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("48e4e03c11");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test160"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.07542235768757849d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test161"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(2.0216852347077916d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9957514803699739d);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test162"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)13062, (java.lang.Number)30.523856729395693d, (java.lang.Number)(-0.3037876249224356d));

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test163"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.7192295413813803d, (java.lang.Number)1960, false);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test164"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(2.773881834450058d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.773881834450058d);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test165"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-519016991), 8904);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test166"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(11.734114385974351d, 8.867868873398907d, 25.505964044321736d, 10993);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.07597370043968373d);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test167"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(1877);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test168"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var5 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1999, (java.lang.Number)(byte)10, (java.lang.Number)1.1368684E-13f);
    java.lang.Number var6 = var5.getLo();
    java.lang.Number var7 = var5.getHi();
    java.lang.Throwable[] var8 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (byte)10+ "'", var6.equals((byte)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1.1368684E-13f+ "'", var7.equals(1.1368684E-13f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test169"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 4.2E-45f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test170"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)11.687404490978503d, (java.lang.Number)1947, false);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test171"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(243746L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test172"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var1 = null;
    java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    java.math.BigInteger var4 = null;
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0L);
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, var6);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 11L);
    java.math.BigInteger var10 = null;
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
    java.math.BigInteger var13 = null;
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 0L);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, var15);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 1949);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, var18);
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 1845);
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 1910);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var24 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1910);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test173"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(22.921701260427884d, (-0.07340078064644198d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test174"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var9 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var5, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var10 = var9.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathArithmeticException var12 = new org.apache.commons.math3.exception.MathArithmeticException(var3, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MaxCountExceededException var14 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.14608902069952245d, (java.lang.Object[])var10);
    java.lang.Number var15 = var14.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + 0.14608902069952245d+ "'", var15.equals(0.14608902069952245d));

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test175"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.exception.OutOfRangeException var17 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.15512025679417774d, (java.lang.Number)1.2471705263294632d, (java.lang.Number)0.0843874063990762d);
    boolean var18 = var2.equals((java.lang.Object)1.2471705263294632d);
    java.lang.String var19 = var2.toString();
    org.apache.commons.math3.random.RandomGenerator var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "MAXIMAL"+ "'", var19.equals("MAXIMAL"));

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test176"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.addElement(0.0d);
    var6.contract();
    var6.addElement(601302.1420828041d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test177"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.setElement(8899, 2.3930658372149933d);
    var4.clear();
    double[] var17 = var4.getInternalValues();
    org.apache.commons.math3.exception.MaxCountExceededException var19 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.27820249749496384d);
    boolean var20 = var4.equals((java.lang.Object)var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test178"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(2.773881834450058d, 2.2702896443043805d);
    boolean var3 = var2.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test179"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     var4.contract();
//     double[] var6 = var4.getInternalValues();
//     boolean var8 = var4.equals((java.lang.Object)0.4000591571530008d);
//     double var10 = var4.substituteMostRecentElement(1.4377981035664862d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.37726454411479016d);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test180"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(2.2058017250564452d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9981882619055036d);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test181"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-0.47764759415577684d), 0.39036590030677853d, 0.0d);
    boolean var4 = var3.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test182"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(3.639262048589646d, 8.937138162549141d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.639262048589646d);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test183"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var6 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var3, var5);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var8 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var5);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var9.getStandardDeviation();
//     double[] var12 = var9.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
//     int var14 = var13.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var15 = var13.copy();
//     var13.addElement((-0.43408597923864894d));
//     double var19 = var13.getElement(0);
//     double[] var20 = var13.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
//     org.apache.commons.math3.distribution.NormalDistribution var22 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double[] var24 = var22.sample(1910);
//     double var25 = var8.mannWhitneyU(var20, var24);
//     org.apache.commons.math3.distribution.NormalDistribution var26 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var27 = var26.getStandardDeviation();
//     double[] var29 = var26.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray(var29);
//     int var31 = var30.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var32 = var30.copy();
//     var30.addElement((-0.43408597923864894d));
//     double var36 = var30.getElement(0);
//     double[] var37 = var30.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray(var37);
//     double[] var39 = var38.getInternalValues();
//     org.apache.commons.math3.distribution.NormalDistribution var40 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var41 = var40.getStandardDeviation();
//     double[] var43 = var40.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var44 = new org.apache.commons.math3.util.ResizableDoubleArray(var43);
//     int var45 = var44.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var46 = var44.copy();
//     var44.addElement((-0.43408597923864894d));
//     double var50 = var44.getElement(0);
//     double[] var51 = var44.getElements();
//     var44.addElement(21.0d);
//     var44.setNumElements(3);
//     org.apache.commons.math3.distribution.NormalDistribution var56 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var57 = var56.getStandardDeviation();
//     double[] var59 = var56.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var60 = new org.apache.commons.math3.util.ResizableDoubleArray(var59);
//     var60.contract();
//     int var62 = var60.getNumElements();
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var44, var60);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var64 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var68 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var69 = new org.apache.commons.math3.util.ResizableDoubleArray(var68);
//     org.apache.commons.math3.distribution.NormalDistribution var70 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var71 = var70.getSupportUpperBound();
//     double[] var73 = var70.sample(10);
//     double var74 = var64.mannWhitneyU(var68, var73);
//     var44.addElements(var68);
//     double var76 = var8.mannWhitneyUTest(var39, var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-0.03554235716198755d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 2264.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == (-0.28407667056064967d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == (-1.3584608228011368d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 21.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == 0.08326451666355006d);
// 
//   }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test184"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-0.03507398520359854d), (-0.7336831272234878d), 9.073947473259423d, 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test185"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(2.287123383678145E-108d, 14.137624878787419d, 17.63985625609349d, 1906);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test186"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-1151L), (-2L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1149L));

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test187"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(6794.892254650551d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.3909208038755523d));

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test188"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    var0.reseedRandomGenerator(2L);
    boolean var3 = var0.isSupportConnected();
    double var5 = var0.cumulativeProbability((-0.8163202194796267d));
    double var7 = var0.density(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.20715850648830503d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.3989422804014327d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test189"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-0.5120066175593998d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8000034466306716d));

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test190"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     double var9 = var0.nextF(2.281783181607902d, 0.8427007929497151d);
//     double var12 = var0.nextGaussian(1.5498468927479463d, 1865.0d);
//     java.lang.String var14 = var0.nextHexString(337860);
//     double var16 = var0.nextExponential(0.9064553692223704d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextInt(1845, (-79579695));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.860835663643612d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.005934759200147643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2195.3422252440173d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.8930131356965625d);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test191"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 10.0f);
    var2.addElement(0.010050166663333094d);
    int var5 = var2.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var2.copy();
    double var8 = var6.substituteMostRecentElement((-6.8543770234272911E18d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.010050166663333094d);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test192"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(9142, 10240);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 19382);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test193"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-0.6573666282510751d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.5192433191631562d));

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test194"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Number var4 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var6 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var2, (java.lang.Number)0.777695809106093d, var4, true);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test195"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.15928211151946273d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test196"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double[] var3 = var0.sample(10);
    double var4 = var0.getStandardDeviation();
    double var5 = var0.getStandardDeviation();
    double var6 = var0.getNumericalVariance();
    double var7 = var0.getNumericalVariance();
    double var9 = var0.probability(0.9999999999999925d);
    double var11 = var0.probability(3.0741607150885346d);
    boolean var12 = var0.isSupportConnected();
    double var14 = var0.cumulativeProbability((-1.6804163900380429d));
    double var17 = var0.cumulativeProbability((-0.2741071856213786d), 0.6134466571100122d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.046438164661925074d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.33820835220462875d);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test197"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(760L, 2120L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1611200L);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test198"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-0.26541595406829316d), 0.017338196224138975d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.26541595406829316d));

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test199"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc((-0.21079377391683451d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.234378816808383d);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test200"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)7.042014262199385d);
    java.lang.Number var2 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 7.042014262199385d+ "'", var2.equals(7.042014262199385d));

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test201"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(8336, 206);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8130);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test202"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(2388144625711178067L, 437L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4736150592170749123L);

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test203"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     double var10 = var0.nextT(20.696514663540924d);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var11.getStandardDeviation();
//     double[] var14 = var11.sample(1);
//     double var15 = var11.getMean();
//     double[] var17 = var11.sample(100);
//     double var18 = var11.sample();
//     double var19 = var11.sample();
//     double var20 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     int var23 = var0.nextBinomial(97944, 0.11537426317526311d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var25 = var24.getStandardDeviation();
//     double[] var27 = var24.sample(1);
//     double var29 = var24.cumulativeProbability(0.0d);
//     double var31 = var24.cumulativeProbability(0.0d);
//     double var32 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     double var36 = var0.nextUniform(0.0d, 1.0494464950714408d, true);
//     int var39 = var0.nextZipf(1949, 0.06995726965750072d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 20.43363786990329d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "940361e1ebbf4b3be01ff1855029467d8c45a4951dc956542851b614ac64628be90c603c7be1d9c356311408dd77548fdb7a"+ "'", var8.equals("940361e1ebbf4b3be01ff1855029467d8c45a4951dc956542851b614ac64628be90c603c7be1d9c356311408dd77548fdb7a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.6276196103907326d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.085231219840113d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.5058255554865116d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.6682733056724008d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 11297);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == (-1.894456238596887d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0.46063354783176597d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1074);
// 
//   }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test204"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var2 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.NullArgumentException var3 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var2);
//     org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var2);
//     org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var9 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var8, (java.lang.Object[])var9);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, (java.lang.Object[])var9);
//     org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var6, (java.lang.Object[])var9);
// 
//   }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test205"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(2.384186E-7f, 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.384186E-7f);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test206"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(437L, (-79248L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test207"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(2.203349670113058d, 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.20334967011305816d);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test208"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    boolean var3 = var1.equals((java.lang.Object)Double.POSITIVE_INFINITY);
    boolean var5 = var1.equals((java.lang.Object)(-0.4255538433808183d));
    java.lang.Class var6 = var1.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var8 = java.lang.Enum.<java.lang.Enum>valueOf(var6, "6d8427fe8c3ce3291df4886a241d9177b362716188fa91d06da3cbe9c9462be0d113489ddd4a7b70561fe22a5e83a0f61e7e");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test209"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     java.lang.String var13 = var0.nextHexString(10);
//     var0.reSeedSecure();
//     double var17 = var0.nextGaussian(7.042014262199385d, 1.179103839756096d);
//     int var20 = var0.nextInt(0, 6);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var24 = var0.nextF((-0.62278342103023d), 16.915172776155245d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 31.099665990547162d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "2b7b851ae1"+ "'", var8.equals("2b7b851ae1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "261a3f10d8"+ "'", var13.equals("261a3f10d8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 7.105652260362468d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 6);
// 
//   }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test210"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     double var30 = var0.nextExponential(1.0471975511965979d);
//     double var32 = var0.nextChiSquare(0.8382617516745859d);
//     double var34 = var0.nextT(4.592006298127415d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.663172800658405d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "2069ed6c83"+ "'", var8.equals("2069ed6c83"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1880);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.00332272562923812d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.2595920564631063d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1.1932543104190492d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.7605981878751495d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-1.025685832634586d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 2.5627598040949364E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.0766040743016103d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 2.996772598911692d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == (-0.8524265421923486d));
// 
//   }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test211"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var1 = null;
//     java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
//     java.math.BigInteger var4 = null;
//     java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0L);
//     java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, var6);
//     java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 11L);
//     java.math.BigInteger var10 = null;
//     java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
//     java.math.BigInteger var13 = null;
//     java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 0L);
//     java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, var15);
//     java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 11L);
//     java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, var18);
//     java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, var19);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test212"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.25587682077976953d, (java.lang.Number)14.619556314198402d, (java.lang.Number)2.124989902393144d);
    java.lang.Number var4 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 14.619556314198402d+ "'", var4.equals(14.619556314198402d));

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test213"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.16046277562098465d, (-1.4352209005379446d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test214"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
    java.lang.Class var14 = var13.getDeclaringClass();
    java.lang.String var15 = var13.toString();
    java.lang.String var16 = var13.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var13);
    boolean var19 = var13.equals((java.lang.Object)4.2130907952045655d);
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "AVERAGE"+ "'", var16.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test215"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0d, (-0.3627453412423001d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.3627453412423001d));

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test216"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     float var7 = var4.getContractionCriteria();
//     var4.setElement(1931, 0.2577047455984825d);
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var14 = var11.nextSecureLong((-1L), 1L);
//     double var17 = var11.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var19 = var11.nextHexString(10);
//     int var22 = var11.nextPascal(8899, 0.8219866295031046d);
//     double var24 = var11.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var25 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var26 = var25.getStandardDeviation();
//     double[] var28 = var25.sample(1);
//     double var29 = var25.getMean();
//     double[] var31 = var25.sample(100);
//     double var32 = var25.sample();
//     double var33 = var25.sample();
//     double var34 = var25.getStandardDeviation();
//     double var35 = var25.sample();
//     double var36 = var11.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var25);
//     double var39 = var11.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     boolean var40 = var4.equals((java.lang.Object)var39);
//     org.apache.commons.math3.exception.util.Localizable var41 = null;
//     org.apache.commons.math3.exception.util.Localizable var43 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var44 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.NullArgumentException var45 = new org.apache.commons.math3.exception.NullArgumentException(var43, (java.lang.Object[])var44);
//     org.apache.commons.math3.exception.MaxCountExceededException var46 = new org.apache.commons.math3.exception.MaxCountExceededException(var41, (java.lang.Number)0.5662191695169728d, (java.lang.Object[])var44);
//     boolean var47 = var4.equals((java.lang.Object)0.5662191695169728d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 25.23308563977893d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "6fd8a1e568"+ "'", var19.equals("6fd8a1e568"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1894);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.024194470033531684d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == (-0.18588210293294594d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.6477290750934385d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1.3670442491858539d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == (-1.8819840246663304d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 5.717330209145673E58d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == false);
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test217"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-79248L), 2021567837087569569L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2021567837087569569L);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test218"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(3.067679042763838d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test219"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var4 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var5 = new org.apache.commons.math3.exception.NullArgumentException(var3, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test220"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(10.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.5f);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test221"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(18944L, 45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test222"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)360576.47541006305d, (java.lang.Number)0.0111995598490069d, (java.lang.Number)1.6281553712289d);
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.6281553712289d+ "'", var5.equals(1.6281553712289d));

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test223"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(28L, 407L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 28L);

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test224"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     long var31 = var0.nextSecureLong(4L, 17L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var34 = var0.nextBeta(1.4021130954622116d, (-8.110291000076801E-10d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10.094877526067501d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "57708dd1ff"+ "'", var8.equals("57708dd1ff"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1929);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.0591780668733182E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1.6312264590899832d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1.1451195264689975d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.2589885496500928d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-0.5075434515875937d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 6.6282932236835656E-21d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 7L);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test225"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(22.488113044724955d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.1564944652919875d);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test226"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1343);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1343);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test227"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     var0.reSeedSecure();
//     int var10 = var0.nextBinomial(243, 0.745691842295965d);
//     long var12 = var0.nextPoisson(31.862892444737472d);
//     double var15 = var0.nextGamma(15.79755955817176d, 2.717220411501478d);
//     long var18 = var0.nextSecureLong((-1342158336L), 11L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var21 = var0.nextPermutation(136, 9181);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9.124033481348128d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 182);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 28L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 50.89092378273869d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-704887721L));
// 
//   }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test228"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     var0.reSeed();
//     double var15 = var0.nextChiSquare(7.617953921806563d);
//     java.lang.String var17 = var0.nextSecureHexString(1916);
//     int var20 = var0.nextZipf(11474, 0.8744549098686318d);
//     double var23 = var0.nextGaussian(1.0d, 4.879522481508616d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10.764037787816575d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "71d6c60ce5"+ "'", var8.equals("71d6c60ce5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 4.44421734802554d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "2671aa5179e4eeb24d4054541b3ac4a64c238a214de9946292fc71a2b575708a95c1e2ebc5992b0214c48886d5fe4d5f599b82e519f1ae44911c7cbf88440a27171419c1c7a82d444654b2cd5a3db1994afcf84f32252acac2133d8dfedc091b71dc6d061d6053ed96cc98cc660a7633d3c6385d14511480947e8aaef1768f259c46f0efc36e88fc54389f2a7e73bb617175b5e8cd6cf7a3d0dc26e3b7587f410617b2d81bde9d5ab32036c8022183a39c7d25a44dbf9dbe25427163a7efda1bee03a93f63bfe7944e3416454726aa59a6967b31f73873de799305872afeb0bbe1dce02403c77286efdb27be09ebbcb2e5dc8280410c19089812aa9a4150ca8e26343a2f2f3aa67628c9308283f5ab3100a816b0e79b47e288cf40c85a1c43233984d669805683eef51bb8682dea95f5dcf37654e7f5baddb2085fc89df4fb9b45321305f93ce22c749e19f6363e6ea1b6cc7b5b7aafe9eb7b5d7bd029bdf634acec9e5772b516e6c7763ab54ae12a7dc17248188c82f8bb7fa2b1f5fb2e55038f174af5d27cad444264db3d98564367c9399a4f430d1ecefa526adf01bac58fe4cd43fce3f8a56aaed7e595d34538b395df06b01632f4c926226af54502e1a6467252cc8781705a4c510435129b2579bd93241f68ff0e1d36ed6eeb0044ce6939bb77155c68fcbbd3c15350b38e3a0b17a4bd35b7e590dccc2c94863f0a4c1ef7cbd8c4f7d9eb8d85f9b1fc9e0295b906ad71bd1a12b372b43e18d98de7090b3a9e10d63df21261aa1a2e0bacfe34a17d572212822b16e6de0466106875951e59b2d6c4c42c1f061fc3336a4f804aa2b60181ae8a279034399d9dfcb4b6129184ed8be9678cb351b7da44e35a88952414c59e111265b878e4fa4236b3a06a04d1a435ef4e2b7c1cdd9df85295f2c84d14073d6c9109719e4060cc51cd0d33f1d69c39331fe7edda1b8452ad682e90c42cf66797085349463f5db2d099658de3163463e0cade13efc3aaaa04f55bf277a6aeb0ac9f9495212fab7774f9b319f0aac546751880be76d09121a0c1ff6117026b5e610a1d3dd693cb5aca3cf321a4c436a164a35d9b361c6e476fcf22abe7d479de906e38bd839ce7f9744b9362ef334482ba749da526d49ef39594c32c52efb976636683b849662770c36e7d765dd4c64287e956d8ed41c74d36fcde8e724bc57440d8676d0b3b709018f7f4fb2de5ae4d513a371dbe2f55cb200459cc2adc85882bd9b5ae351905f3cd905f009084b297d8a3bd80c50352871d61dc7de00e7740eb0b560cd754aaa195aab0bb85ea88d3536dfa33e9eee3ded6e263086b3438001ab86a7600c20eac747d34"+ "'", var17.equals("2671aa5179e4eeb24d4054541b3ac4a64c238a214de9946292fc71a2b575708a95c1e2ebc5992b0214c48886d5fe4d5f599b82e519f1ae44911c7cbf88440a27171419c1c7a82d444654b2cd5a3db1994afcf84f32252acac2133d8dfedc091b71dc6d061d6053ed96cc98cc660a7633d3c6385d14511480947e8aaef1768f259c46f0efc36e88fc54389f2a7e73bb617175b5e8cd6cf7a3d0dc26e3b7587f410617b2d81bde9d5ab32036c8022183a39c7d25a44dbf9dbe25427163a7efda1bee03a93f63bfe7944e3416454726aa59a6967b31f73873de799305872afeb0bbe1dce02403c77286efdb27be09ebbcb2e5dc8280410c19089812aa9a4150ca8e26343a2f2f3aa67628c9308283f5ab3100a816b0e79b47e288cf40c85a1c43233984d669805683eef51bb8682dea95f5dcf37654e7f5baddb2085fc89df4fb9b45321305f93ce22c749e19f6363e6ea1b6cc7b5b7aafe9eb7b5d7bd029bdf634acec9e5772b516e6c7763ab54ae12a7dc17248188c82f8bb7fa2b1f5fb2e55038f174af5d27cad444264db3d98564367c9399a4f430d1ecefa526adf01bac58fe4cd43fce3f8a56aaed7e595d34538b395df06b01632f4c926226af54502e1a6467252cc8781705a4c510435129b2579bd93241f68ff0e1d36ed6eeb0044ce6939bb77155c68fcbbd3c15350b38e3a0b17a4bd35b7e590dccc2c94863f0a4c1ef7cbd8c4f7d9eb8d85f9b1fc9e0295b906ad71bd1a12b372b43e18d98de7090b3a9e10d63df21261aa1a2e0bacfe34a17d572212822b16e6de0466106875951e59b2d6c4c42c1f061fc3336a4f804aa2b60181ae8a279034399d9dfcb4b6129184ed8be9678cb351b7da44e35a88952414c59e111265b878e4fa4236b3a06a04d1a435ef4e2b7c1cdd9df85295f2c84d14073d6c9109719e4060cc51cd0d33f1d69c39331fe7edda1b8452ad682e90c42cf66797085349463f5db2d099658de3163463e0cade13efc3aaaa04f55bf277a6aeb0ac9f9495212fab7774f9b319f0aac546751880be76d09121a0c1ff6117026b5e610a1d3dd693cb5aca3cf321a4c436a164a35d9b361c6e476fcf22abe7d479de906e38bd839ce7f9744b9362ef334482ba749da526d49ef39594c32c52efb976636683b849662770c36e7d765dd4c64287e956d8ed41c74d36fcde8e724bc57440d8676d0b3b709018f7f4fb2de5ae4d513a371dbe2f55cb200459cc2adc85882bd9b5ae351905f3cd905f009084b297d8a3bd80c50352871d61dc7de00e7740eb0b560cd754aaa195aab0bb85ea88d3536dfa33e9eee3ded6e263086b3438001ab86a7600c20eac747d34"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.8857372819322061d);
// 
//   }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test229"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     var0.reSeedSecure(437L);
//     java.lang.String var10 = var0.nextSecureHexString(37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10.818526273176142d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "c522d2a81750838dd0f9ad4b19454647762bf"+ "'", var10.equals("c522d2a81750838dd0f9ad4b19454647762bf"));
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test230"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(50, 2106);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 105300);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test231"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.2913360570060418d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 16.692326486428954d);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test232"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.8847443243832113d, 53.69538586542132d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8847443243832113d);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test233"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.0015344089955228349d);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test234"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(323, 1988);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 642124);

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test235"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
//     int var2 = var1.getExpansionMode();
//     var1.clear();
//     int var4 = var1.getNumElements();
//     org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var8 = var5.nextSecureLong((-1L), 1L);
//     double var11 = var5.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     var5.reSeedSecure();
//     int var15 = var5.nextBinomial(243, 0.745691842295965d);
//     boolean var16 = var1.equals((java.lang.Object)var15);
//     double[] var17 = var1.getInternalValues();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 23.128389912057397d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 189);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test236"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.993405468012823d);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test237"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.14431182850092306d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.14381144578732213d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test238"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(443L, 32L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test239"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.9971027061668425d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test240"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(16.35282631844513d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test241"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var13 = var0.nextT(5.867156662812015d);
//     double var16 = var0.nextGamma(0.13558023874553457d, 0.010050505059049992d);
//     double var19 = var0.nextGamma(0.6240600968487551d, 0.0d);
//     double var21 = var0.nextExponential(0.40102927495477353d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var0.nextGaussian(2.263521840245945d, (-1.0d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7427150799221538d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1c0d5e3f33"+ "'", var8.equals("1c0d5e3f33"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.2215980927174809d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.1063808689648077E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.2149240832861491d);
// 
//   }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test242"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getSupportUpperBound();
//     double[] var3 = var0.sample(10);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     double var6 = var4.addElementRolling(0.15264401491200186d);
//     float var7 = var4.getContractionCriteria();
//     int var8 = var4.getExpansionMode();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.setExpansionMode(1930);
//       fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
//     } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.43473571500031893d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test243"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    var4.addElement(0.0d);
    var4.discardMostRecentElements(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test244"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.32270435687048d, 0.03449694538827916d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.01182043211587186d);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test245"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(11166);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 92913.71961342696d);

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test246"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     var0.reSeed();
//     double var15 = var0.nextChiSquare(7.617953921806563d);
//     double var17 = var0.nextExponential(1.5574077246549007d);
//     double var19 = var0.nextChiSquare(0.16043285994536435d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.265397438855741d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "4eab36da89"+ "'", var8.equals("4eab36da89"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 5.403374463082058d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.4620297174607717d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.6223863382454309E-9d);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test247"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.3841858E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-22));

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test248"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-0.6487974831986031d), 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test249"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(1.1675832066593317d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9013047075853036d);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test250"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-4.440892098500626E-16d), 1.1102230246251565E-16d, 0.9999494957997512d);
    double var4 = var3.getMean();
    double var6 = var3.density(100.0d);
    double var7 = var3.getNumericalVariance();
    double var9 = var3.probability(2.3930658372149933d);
    double var11 = var3.density(2.495263527653989d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-4.440892098500626E-16d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.232595164407831E-32d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test251"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     var0.reSeed(4L);
//     double var8 = var0.nextGaussian(0.7625552649455967d, 0.15512025679417774d);
//     int var11 = var0.nextPascal(337860, 0.5322866968936354d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextGaussian((-0.3570413923482837d), (-0.6936007984000367d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8988590862390544d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 295783);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test252"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    int var7 = var6.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setContractionCriteria(1.9999998f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test253"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-1.000047053808632d), 4.5656690655869046d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test254"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
//     int var2 = var1.getExpansionMode();
//     var1.clear();
//     int var4 = var1.getNumElements();
//     org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var8 = var5.nextSecureLong((-1L), 1L);
//     double var11 = var5.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     var5.reSeedSecure();
//     int var15 = var5.nextBinomial(243, 0.745691842295965d);
//     boolean var16 = var1.equals((java.lang.Object)var15);
//     org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(189);
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 7.877382141809851d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 178);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test255"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 1.9999999f, 9.536745E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test256"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma((-0.6190659680329689d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test257"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.13234633557495218d, 0.3409202657269044d, 0.0d, 2106);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.11020387651727559d);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test258"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 243);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 76L);
    org.apache.commons.math3.exception.NumberIsTooLargeException var13 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)76L, (java.lang.Number)19.53899193057841d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test259"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.0019953167668664154d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test260"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(655360.06f, 99.99999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 655360.06f);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test261"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.010050505059049992d, (java.lang.Number)(-0.3722334692039834d), true);
    boolean var5 = var4.getBoundIsAllowed();
    java.lang.Throwable[] var6 = var4.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test262"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(2.9854328371062793d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test263"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(9448, Float.POSITIVE_INFINITY);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setContractionCriteria(1.1368684E-13f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test264"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.014931963725887733d, 0.010100839201864612d);
    double var3 = var2.getNumericalMean();
    double var4 = var2.getNumericalVariance();
    double var6 = var2.probability(9.770764564815813d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.014931963725887733d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0202695258192494E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test265"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 336L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 2388144625711178067L);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 1848);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test266"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-1), 1255);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test267"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var5, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MaxCountExceededException var13 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)(-1.2458743353298596d), (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathArithmeticException var14 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test268"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var9);
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test269"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    java.lang.Class var6 = var1.getDeclaringClass();
    java.lang.Class var7 = var1.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var9 = java.lang.Enum.<java.lang.Enum>valueOf(var7, "org.apache.commons.math3.exception.OutOfRangeException: -1 out of [10, 6.622] range");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test270"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(1.2411313939991078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.4595253376173973d);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test271"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.3631750422823351d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test272"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(17.00231119711161d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test273"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(1.0869569206500849d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8270409253589942d);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test274"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("af06ab406e");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test275"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(751, 100.0f, 2097152.5f, (-454));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test276"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)10.764037787816575d, (java.lang.Number)0.07224964287885981d, false);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test277"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1541, 10743);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10743);

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test278"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var13 = var10.nextSecureLong((-1L), 1L);
//     double var16 = var10.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var18 = var10.nextHexString(10);
//     int var21 = var10.nextPascal(8899, 0.8219866295031046d);
//     double var23 = var10.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var25 = var24.getStandardDeviation();
//     double[] var27 = var24.sample(1);
//     double var28 = var24.getMean();
//     double[] var30 = var24.sample(100);
//     double var31 = var24.sample();
//     double var32 = var24.sample();
//     double var33 = var24.getStandardDeviation();
//     double var34 = var24.sample();
//     double var35 = var10.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     double var36 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     org.apache.commons.math3.distribution.NormalDistribution var37 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var38 = var37.getStandardDeviation();
//     boolean var39 = var37.isSupportUpperBoundInclusive();
//     double[] var41 = var37.sample(100);
//     double var42 = var37.getNumericalVariance();
//     double var43 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var37);
//     double var46 = var0.nextCauchy(12.033846781268247d, 0.18568215771673818d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var49 = var0.nextZipf(0, 34.761365401314364d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.9767154850887385d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "9a19d7368ce7020d6cf08b4c10fed2d6b2f42e26a775c7da1ce49bf27b7e1396f46cb010bc883214542084456af31726eb96"+ "'", var8.equals("9a19d7368ce7020d6cf08b4c10fed2d6b2f42e26a775c7da1ce49bf27b7e1396f46cb010bc883214542084456af31726eb96"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 13.172254115947158d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "6bf4f0c153"+ "'", var18.equals("6bf4f0c153"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1843);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.001867611192396746d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == (-0.11888905789357603d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1.8202909677295578d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0.49745813880982503d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == (-0.35125940863592087d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0.3583719646341045d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == (-0.21761536713567642d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 12.100403172827145d);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test279"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.0d, (-1.0341195799257004d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test280"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var6 = var5.getStandardDeviation();
    double[] var8 = var5.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    double[] var10 = var9.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var18 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var14, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var19 = var18.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var20 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var13, (java.lang.Object[])var19);
    org.apache.commons.math3.exception.MathArithmeticException var21 = new org.apache.commons.math3.exception.MathArithmeticException(var12, (java.lang.Object[])var19);
    boolean var22 = var11.equals((java.lang.Object)var19);
    org.apache.commons.math3.exception.MathIllegalStateException var23 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var19);
    org.apache.commons.math3.exception.MathIllegalStateException var24 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var19);
    org.apache.commons.math3.exception.MathIllegalArgumentException var25 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var19);
    org.apache.commons.math3.exception.MaxCountExceededException var26 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)2.478622967831918d, (java.lang.Object[])var19);
    org.apache.commons.math3.exception.util.ExceptionContext var27 = var26.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test281"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    double[] var7 = var4.getInternalValues();
    var4.addElement(0.7615941559557649d);
    double var11 = var4.substituteMostRecentElement(0.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.7615941559557649d);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test282"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    boolean var7 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator((-16L));
    double var11 = var0.cumulativeProbability(0.0d);
    boolean var12 = var0.isSupportLowerBoundInclusive();
    double var14 = var0.probability(7.724435900937391d);
    double[] var16 = var0.sample(100);
    double var17 = var0.sample();
    double var18 = var0.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.7233703768189484d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test283"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-0.7375679184295869d), (-1.3592179773872326d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.6444166042660533d));

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test284"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    int var2 = var1.ordinal();
    int var3 = var1.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var5 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "AVERAGE"+ "'", var5.equals("AVERAGE"));

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test285"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getStandardDeviation();
//     double[] var13 = var10.sample(1);
//     double var15 = var10.cumulativeProbability(0.0d);
//     double var16 = var10.getSupportUpperBound();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     var0.reSeed();
//     int var21 = var0.nextZipf(1859, 9.717527268210787E-6d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var24 = var0.nextGaussian(0.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.7316292978479275d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.11977463144087032d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 924);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test286"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0, 325);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test287"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0);
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test288"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.06923396782734023d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test289"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("7a8acb685dc039a3f738ed7f6f75abc8e991ad0e1efb49d75753b18a88c6222a6e5f8eafce24db3b3e45b88478685e5316e03c8c11b740ddf233ce750348c299be61c93dbfacb1d3f918b3506dda75b4098035a28077c653f5b871bea2a91f02ff401d14422cb4a2fb03a67b6a21bb3b5f3bb3a23018f43e8bd8c3e1eaafec8043016e16a2322f2e5c664db9fb9aebb06215e7709535bee31c08ace86224b29fb0838857964cbcc49dd0752c4dbe88e5d4069f043d653964b333c20609f4a0d50ca706d51781f15d6fd8139fef2be34f48f9105f0df7bc38fc4bacc0a233266481d0a9d29c7460478587fdcc5156ece110401a65c5782f06f5d324b7c0033e3fa6de0bf5fea5c5a79b2d1ad8ed5c7065e90b9c8d11888216144c3ebd587aeef8762698e5bc04264cea2944650fb0c807408e52d14e62f1fa87a049d41344249262e2ee9c912a0ce1249c235f26f8bbce15f3cb0054fed62be8ce15bf078b681695441bc6e7cc46dcf1fffc32a5b16253636021d5fd4f6a0f1e8026cdb6134bfcbf7a093b019ea5617c07c8804e51e8392ffb6da1b2c341145fdb8f1d639a65e4a976d517c7d47ca4ef9fdacc032af0940d12f4caa166ad0fdeeede1e2ea33217467ce8323d5876cb18dd271346b0d37e413773c9959bcb8624c3d354dd26c72cf3ab60adbbe3277984723ef4310d6c9c74c613938b9daf781ced7063bfe9cf0d293c80e73e0d2255af4732db28681719861cc9e545c740279ac22e9fcffaf0ca1bf62f5f84985add4cf7cfb220e52578dd10b41c7b9f7d2ac7e1a59fbfc3c971e9ceb65565f4959352c8beb9da8e0b80dbe05c5b4ba69a442901b8416e0333bc46df6d867fba8bcfb192f7a5a34b3b1fb7483f60780737afd40eb178e6a71dbf27925bb0e04d0c75400a025cc3bc962c09c075f562e8dd0b55578b2e11eab1d13b4a76b1a8da37909907a66721d669466e2c7b6c9df59a6e1f30c930db5875f72b324ec2886d08a7284865db32e87eb40fa140e0925df317e0860f0ee769afe632d689ee4732ab3bef4a43a9ad690b1b20ba40340723f74f09d3cad654651fab99dd1464f6fcfb27ae6abe84bff501af105142e0f67ba675eb96354b7a8db4f25166bab0732c12add5d831dff74910157e9dae71d8cd4d4fb0ebff4cea0c19eef97507d8b7d95c2ee2c7a64edf1b824641b3a3621070607f8c17d3afcbad05391f1b659f38cf6e587dd13d9d3d447c77b0f321ecc636c868d36bb3f1af8f91e252ee6edff8318179bb4cc68c260a44431e61a7e74b8e2fd6fa1dba59c59ff72fbe8fcb8cf115bf2917d83ee6f1c6926d34445a2c2efa1f81578fa8c66b7b");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test290"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
    var4.setElement(48, 10.514381454610717d);
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
    java.lang.Class var22 = var21.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    java.lang.String var24 = var21.toString();
    java.lang.Class var25 = var21.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    boolean var27 = var4.equals((java.lang.Object)var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "AVERAGE"+ "'", var24.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test291"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    java.lang.Class var6 = var4.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    java.lang.String var8 = var4.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test292"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(1973, 11297);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test293"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
//     java.lang.Class var3 = var2.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     java.lang.String var5 = var2.toString();
//     java.lang.String var6 = var2.toString();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var2);
//     org.apache.commons.math3.random.RandomGenerator var8 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var11.getStandardDeviation();
//     double[] var14 = var11.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
//     var15.contract();
//     var15.addElement(0.0d);
//     int var19 = var15.getExpansionMode();
//     double[] var20 = var15.getElements();
//     double[] var21 = var9.rank(var20);
//     org.apache.commons.math3.distribution.NormalDistribution var22 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var23 = var22.getStandardDeviation();
//     double[] var25 = var22.sample(1);
//     double var26 = var22.getMean();
//     double[] var28 = var22.sample(100);
//     boolean var29 = var22.isSupportLowerBoundInclusive();
//     boolean var30 = var22.isSupportUpperBoundInclusive();
//     double var33 = var22.cumulativeProbability(0.0d, 0.25587682077976953d);
//     double var34 = var22.getSupportUpperBound();
//     double[] var36 = var22.sample(11274);
//     double var37 = var7.mannWhitneyU(var21, var36);
// 
//   }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test294"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(179, 89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1733452589));

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test295"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)2106, var1, false);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test296"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-1.3592179773872326d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.1077192509273825d));

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test297"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(1.1076389360610999d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8946463157932409d);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test298"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double[] var3 = var0.sample(10);
    double var4 = var0.getStandardDeviation();
    double var6 = var0.density(2.345330933436551d);
    double var7 = var0.getMean();
    double var9 = var0.probability(0.003547845623385577d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.025496167636629936d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test299"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0, 1866);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test300"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1848, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test301"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 6L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 268435456L);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 336L);
    java.math.BigInteger var13 = null;
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 0L);
    java.math.BigInteger var16 = null;
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 0L);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, var18);
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 243);
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 4L);
    java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 40486L);
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var28 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, (-536870912L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test302"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.10097702336242761d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.99490615081029d);

  }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test303"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var8 = var0.nextGamma(1.7166172049198016d, 0.1006733736677079d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var10 = var0.nextHexString((-8834));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.9531388118303861d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.07410234714732693d);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test304"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    boolean var7 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator((-16L));
    double var11 = var0.cumulativeProbability(0.0d);
    boolean var12 = var0.isSupportLowerBoundInclusive();
    double var14 = var0.probability(7.724435900937391d);
    double[] var16 = var0.sample(100);
    boolean var17 = var0.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test305"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(13.048557790427207d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3542586301422443d);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test306"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     var0.reSeed();
//     double var15 = var0.nextChiSquare(7.617953921806563d);
//     double var17 = var0.nextExponential(1.5574077246549007d);
//     org.apache.commons.math3.distribution.NormalDistribution var21 = new org.apache.commons.math3.distribution.NormalDistribution(0.8259324122591327d, 0.2782029380240531d, 0.0d);
//     double var22 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var21);
//     double var24 = var0.nextExponential(12569.816320050882d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var27 = var0.nextBinomial(1942, 1.3212360281535291d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.4852696843490956d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "7a9ace60ea"+ "'", var8.equals("7a9ace60ea"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 9.557260154328954d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.9388126796931795d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.5602984225891392d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 17747.687379201638d);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test307"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, (-0.25891548665688296d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-4.9E-324d));

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test308"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(12.51206791512923d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5266936117876826d);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test309"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(648.230953682526d, 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.124123189026901E7d);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test310"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     long var31 = var0.nextSecureLong(4L, 17L);
//     java.lang.String var33 = var0.nextSecureHexString(9813);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var36 = var0.nextSecureInt(64, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 31.77691157637767d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "9a7061f499"+ "'", var8.equals("9a7061f499"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1986);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.00460706503257858d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1.7085408469084096d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-0.5115048485551725d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.5677626008152183d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-1.200565702373492d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 5.970695127408577E12d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 5L);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test311"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 1073741824L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1073741824L);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test312"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.exception.OutOfRangeException var17 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.15512025679417774d, (java.lang.Number)1.2471705263294632d, (java.lang.Number)0.0843874063990762d);
    boolean var18 = var2.equals((java.lang.Object)1.2471705263294632d);
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var20, var22);
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19, var22);
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var22);
    org.apache.commons.math3.distribution.NormalDistribution var29 = new org.apache.commons.math3.distribution.NormalDistribution((-3.4276683869607285d), 0.05607495010201036d, (-0.8057015395917116d));
    boolean var30 = var22.equals((java.lang.Object)var29);
    int var31 = var22.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 3);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test313"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(1963, 1956);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 44.53973326018833d);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test314"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var13.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    java.lang.Class var18 = var17.getDeclaringClass();
    java.lang.Class var19 = var17.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    java.lang.String var21 = var17.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var15, var17);
    boolean var24 = var17.equals((java.lang.Object)6.694390071933186E-5d);
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var26 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var27 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var29 = var28.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var30 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var27, var29);
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26, var29);
    java.lang.String var32 = var29.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var29);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var34 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var29);
    org.apache.commons.math3.stat.ranking.NaNStrategy var35 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var36 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var38 = var37.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var39 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var36, var38);
    org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var35, var38);
    java.lang.String var41 = var38.name();
    java.lang.String var42 = var38.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var43 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var38);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var44 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "AVERAGE"+ "'", var21.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "AVERAGE"+ "'", var32.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + "AVERAGE"+ "'", var41.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + "AVERAGE"+ "'", var42.equals("AVERAGE"));

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test315"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    boolean var13 = var2.equals((java.lang.Object)(-1.5564980685845229d));
    java.lang.Class var14 = var2.getDeclaringClass();
    java.lang.Class var15 = var2.getDeclaringClass();
    java.lang.Object var16 = null;
    boolean var17 = var2.equals(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test316"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    var4.setElement(1931, 0.2577047455984825d);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test317"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.08220761481937006d, 8.854558633913314d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9074471803502604d);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test318"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-1.5192433191631562d), (-0.5446254332868388d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.519243319163156d));

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test319"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(9446);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 77022.0080808884d);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test320"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-0.40925037755477284d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6641479237699602d);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test321"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)9.453724938289845d, (java.lang.Number)(-6.887851652052518d), (java.lang.Number)0.06257000654723877d);
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-6.887851652052518d)+ "'", var5.equals((-6.887851652052518d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.06257000654723877d+ "'", var6.equals(0.06257000654723877d));

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test322"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.23189973871007186d, (java.lang.Number)4066.8844691618797d, (java.lang.Number)4.3312580140185375d);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test323"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-231249447L), 199L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 46018639953L);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test324"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(99.99999f, 3.269495958997823E144d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test325"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(0.48262694182950977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6072369230342884d);

  }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test326"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var6);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var6);
//     java.lang.String var9 = var6.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var10 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var6);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
//     java.lang.Class var13 = var12.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
//     java.lang.String var15 = var12.toString();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var12);
//     org.apache.commons.math3.random.RandomGenerator var17 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var17);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.distribution.NormalDistribution var20 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var21 = var20.getStandardDeviation();
//     boolean var22 = var20.isSupportUpperBoundInclusive();
//     double[] var24 = var20.sample(100);
//     org.apache.commons.math3.distribution.NormalDistribution var25 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var25.reseedRandomGenerator(2L);
//     double[] var29 = var25.sample(100000);
//     double var30 = var19.mannWhitneyUTest(var24, var29);
//     org.apache.commons.math3.distribution.NormalDistribution var31 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var32 = var31.getStandardDeviation();
//     double[] var34 = var31.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var35 = new org.apache.commons.math3.util.ResizableDoubleArray(var34);
//     double[] var39 = new double[] { 0.0d, (-1.0d), 0.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var40 = new org.apache.commons.math3.util.ResizableDoubleArray(var39);
//     double var41 = var19.mannWhitneyU(var34, var39);
//     double[] var42 = var18.rank(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "AVERAGE"+ "'", var9.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 0.8857635107974847d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 3.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test327"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double var2 = var0.getMean();
    boolean var3 = var0.isSupportUpperBoundInclusive();
    boolean var4 = var0.isSupportConnected();
    double var6 = var0.density(0.3091286446619527d);
    double var7 = var0.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3803289310416418d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test328"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)91530199783L, (java.lang.Number)96, false);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test329"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(0.8670357192834551d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0923260297859545d);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test330"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NoDataException var1 = new org.apache.commons.math3.exception.NoDataException(var0);
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var6 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var2, (java.lang.Number)21L, (java.lang.Number)5.641560223443412d, true);
    boolean var7 = var6.getBoundIsAllowed();
    var1.addSuppressed((java.lang.Throwable)var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test331"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.5000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test332"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-1.526192903006268d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.026637091178029842d));

  }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test333"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     double var9 = var0.nextGamma(9.319248049587957d, (-0.4255538433808183d));
//     long var11 = var0.nextPoisson(0.9978516012375751d);
//     int var14 = var0.nextZipf(8941, 1.445343853698748d);
//     java.lang.String var16 = var0.nextHexString(3826);
//     double var19 = var0.nextGaussian(1.383036361567265d, 18.853048230723537d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var0.nextHypergeometric(12767, (-1953380655), 1499);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.04696361804082275d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-2.297393446279663d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "3ee3e007067fa34d0cef6319600486480723028bb24dc6b9eeeaf43f23cceed24c1c81dd8223e4b46326f21f5a775202ff1e3bb3ae6c02980364e88c18503bab9bfb8d959dde5eb65f23baf65bb1e6d86972e22ed21f0206e0c31609e96b77df5ceb4b7468046cd9eec1be12679de3cd4f12611a42942a6faf92921ff8cfada8cc343de4af143e5b1252b082fc58c54f8da9215faa5c1dd8d4f496542f3ab1c81fcc8b649281a438e06edcd71ae0d573108d21aaf66fde587efa5789fc2bcdafd473022175eef6eec9975c7be346e55b4c1a414e1095cce6e70684ca9d70e312f1827f6a152b8f48db49617637920c8a00402c9e7cdcfd2e34a8f177e9fc1fb16bc3d8d1afc2cb46ec4569a0881f58e5556deb5ad46616b894130a247f6c29e682b4c298c0c64e961afa04c9c1429d5fc74210527fab7bd8d2c2ec89b76b95aa8009f44447d7b16f6469f26b7356d7221b82afd959f84a78d618769f3749d81a200191980cb0f6248b53018a643f5d9294518fc1ee9c692b5707aa0e108cccc1220004d3a3de36922b9231d3a4907e93e1092b2435b3a1cafb52e591d543a3aea26ccf77e2ec9e276fc0038b02e18ee423e1940410201d8841e5af915e1b497c7ae510c7f4425507fdbec4ba111e1d74266b659ff19be75a41c59941e3897e3f6ba30daace550833a450f4750b635853674dd0cfede5fb2be4c87a41d50eb25f3e11dbe733cdb59b82cdd2eddaa48495049394b893b9cb54f985bf261f24ee41ee500c61c1d7aa796fa3a72fc30b6915228e177c979693209d75842ca5e37ad24bc5e4f17591009337c866c3fd6bb68b9f427629c79148d0efb4bd8f09b33959c567f654018f6417692fcfcbcc4b4150f85bb0b3b29e361488128eb354d68a7aaa98cc936bff695596f1ae1adb215547ffb1cc2e290dd8aa350230f7d37a4c14f3cb1d03a5b021409537c0f8cdd732422c7dfa82f3ca8877fe0e04d44543fe0bbe6571515bcc93cc5f47386bc7bfdf9cd72cacc26ef8fc565235e57fb35c9354307a26b3b9f4c393697503620673e610d3bfdc4d079b401084457c536107d876fa56d4f74af58e217678e9023756bfcbf7f97a2e201239e14129cc98449c155507480f344b4d1a479b0678b8266be98a46ef05c575e6796ae3aa6ef07339642e4e0b2e249b349822c2d74c57e6633906215d5fbfb552a1bfc62fed30cccfd7a95c7c81f91bf66385dfceda13b57702d263cde4088f5b9605ee70ca7fd4bd3e3e99f8005ba041d1d307caeb160f037308c15234d92a6f08b418d5af79242f68eb1aadd30000f63f88aae46fd5cc1d1d7a30ab89b39807f9f44aa6fc2df399c42817c379f40880bdf76ac2677f2932ab40af83811857870e8dd5df079697533e65230197a4ae2d40e42b2037e6c48cb9a3f39084660094262ae3877ce3cc8a791a9977453a8165d8d92e8af8741bd244aa9e11851b01f84f57b101e378cec5bded7f18e4e6a81f078e913ad008155a69e86b504fa6d24b4269979805bd36cf347815a6ae06e27d14f73630273eb8895405b69869e8ff7130f08ae930821a363a7e96a34e72c38d0fd843be573eb9d292d2efa74efdbfb1ff1500cdf71d88dfc2d8dd68aa335115e72a8f7d8921fda767a0b87943b2742c61b0ee65808ce09a960463276e4331de2143f1e2d7bd417167bc1a88143f902b2fb6871be965f96d85c5c4603fab78c1741b6a0f778a46ef4a8419edb9ba7fe80371a5d133326e45fbe45c6ea18410037b4e225d349053197e7d08bc51d4e3bcd31034aec2ec278fbdf3ddaf30697a6e46382e3265b44bbd433b5addae6666eb916769a5235e4b9c615135dfb7eeebe0bb986929d79a00bb1c25555074b818b4272bdf0ef10c1e1f6f5e256f33c0e79ffe30228d04ee404db264c7ec452b3586bf38b1b46eb4f352a5b453b6e8adf9e47a55061529936435dab95153d61d7425df15aca0feb6de3a2b68ff06239cf3aabcd69d16dbef8894e4da43697c66dd333491150c78948ce2b320701d3ae918b30336b43bee84be9d117776f3e9d1295112d9aacb70336433c9c15fd99478069eb8872edb5aefcfa5f6f17b9f7115fc21842cab8f8ffcc0f6f5e803e0609ca88ca77fc29cd5f181599434673de55d61241d6cd1533fdc98c771a89b00644cb9d9e56028cc360c92283137f41e43f6feba95dcac522bbd1b07f710c47a0d483e3325ff482fc101c18b658b18e767bed6483c31aac85cf9f785ec331800b602ac69bbd5c6a5131dc2ba77e6384fc98cca8fa28641a07fee8a3879e3ba666c4cd938475084f9ada33ae131b6e0de2d9a8f7d359ee01ed341f05979be64d45298acd472d43153f16430c9b8ca9d1389534c3e91e84552c5a4f4270378d99441d482e47dd0eafd75d9374098a1239e401912ff5334ff2d71cb994db53fbfbf947c07399310b51d55ddcfb623a38fb0b8861efff4c8ba89148650fc1b0078ffd767d9f8de53b906d12bdac8b2a27b150f8b73b73400defd417f61c2f87e5c81a125089127601ec551cecac72bb242e21849481ea94f47e470f2ac0798cd2ef3a80a8bef43998ed8f2ef37a28bc532c72ba30086d124e20ee994d859ac6e0eed7d1aa97577bfa0fcfad0f250860ffe3fccaf4af1888a0d3f4d340f2d9985a14fc200a07dd242cbbe8d12dc4d87ac241ccdc06e6343f508"+ "'", var16.equals("3ee3e007067fa34d0cef6319600486480723028bb24dc6b9eeeaf43f23cceed24c1c81dd8223e4b46326f21f5a775202ff1e3bb3ae6c02980364e88c18503bab9bfb8d959dde5eb65f23baf65bb1e6d86972e22ed21f0206e0c31609e96b77df5ceb4b7468046cd9eec1be12679de3cd4f12611a42942a6faf92921ff8cfada8cc343de4af143e5b1252b082fc58c54f8da9215faa5c1dd8d4f496542f3ab1c81fcc8b649281a438e06edcd71ae0d573108d21aaf66fde587efa5789fc2bcdafd473022175eef6eec9975c7be346e55b4c1a414e1095cce6e70684ca9d70e312f1827f6a152b8f48db49617637920c8a00402c9e7cdcfd2e34a8f177e9fc1fb16bc3d8d1afc2cb46ec4569a0881f58e5556deb5ad46616b894130a247f6c29e682b4c298c0c64e961afa04c9c1429d5fc74210527fab7bd8d2c2ec89b76b95aa8009f44447d7b16f6469f26b7356d7221b82afd959f84a78d618769f3749d81a200191980cb0f6248b53018a643f5d9294518fc1ee9c692b5707aa0e108cccc1220004d3a3de36922b9231d3a4907e93e1092b2435b3a1cafb52e591d543a3aea26ccf77e2ec9e276fc0038b02e18ee423e1940410201d8841e5af915e1b497c7ae510c7f4425507fdbec4ba111e1d74266b659ff19be75a41c59941e3897e3f6ba30daace550833a450f4750b635853674dd0cfede5fb2be4c87a41d50eb25f3e11dbe733cdb59b82cdd2eddaa48495049394b893b9cb54f985bf261f24ee41ee500c61c1d7aa796fa3a72fc30b6915228e177c979693209d75842ca5e37ad24bc5e4f17591009337c866c3fd6bb68b9f427629c79148d0efb4bd8f09b33959c567f654018f6417692fcfcbcc4b4150f85bb0b3b29e361488128eb354d68a7aaa98cc936bff695596f1ae1adb215547ffb1cc2e290dd8aa350230f7d37a4c14f3cb1d03a5b021409537c0f8cdd732422c7dfa82f3ca8877fe0e04d44543fe0bbe6571515bcc93cc5f47386bc7bfdf9cd72cacc26ef8fc565235e57fb35c9354307a26b3b9f4c393697503620673e610d3bfdc4d079b401084457c536107d876fa56d4f74af58e217678e9023756bfcbf7f97a2e201239e14129cc98449c155507480f344b4d1a479b0678b8266be98a46ef05c575e6796ae3aa6ef07339642e4e0b2e249b349822c2d74c57e6633906215d5fbfb552a1bfc62fed30cccfd7a95c7c81f91bf66385dfceda13b57702d263cde4088f5b9605ee70ca7fd4bd3e3e99f8005ba041d1d307caeb160f037308c15234d92a6f08b418d5af79242f68eb1aadd30000f63f88aae46fd5cc1d1d7a30ab89b39807f9f44aa6fc2df399c42817c379f40880bdf76ac2677f2932ab40af83811857870e8dd5df079697533e65230197a4ae2d40e42b2037e6c48cb9a3f39084660094262ae3877ce3cc8a791a9977453a8165d8d92e8af8741bd244aa9e11851b01f84f57b101e378cec5bded7f18e4e6a81f078e913ad008155a69e86b504fa6d24b4269979805bd36cf347815a6ae06e27d14f73630273eb8895405b69869e8ff7130f08ae930821a363a7e96a34e72c38d0fd843be573eb9d292d2efa74efdbfb1ff1500cdf71d88dfc2d8dd68aa335115e72a8f7d8921fda767a0b87943b2742c61b0ee65808ce09a960463276e4331de2143f1e2d7bd417167bc1a88143f902b2fb6871be965f96d85c5c4603fab78c1741b6a0f778a46ef4a8419edb9ba7fe80371a5d133326e45fbe45c6ea18410037b4e225d349053197e7d08bc51d4e3bcd31034aec2ec278fbdf3ddaf30697a6e46382e3265b44bbd433b5addae6666eb916769a5235e4b9c615135dfb7eeebe0bb986929d79a00bb1c25555074b818b4272bdf0ef10c1e1f6f5e256f33c0e79ffe30228d04ee404db264c7ec452b3586bf38b1b46eb4f352a5b453b6e8adf9e47a55061529936435dab95153d61d7425df15aca0feb6de3a2b68ff06239cf3aabcd69d16dbef8894e4da43697c66dd333491150c78948ce2b320701d3ae918b30336b43bee84be9d117776f3e9d1295112d9aacb70336433c9c15fd99478069eb8872edb5aefcfa5f6f17b9f7115fc21842cab8f8ffcc0f6f5e803e0609ca88ca77fc29cd5f181599434673de55d61241d6cd1533fdc98c771a89b00644cb9d9e56028cc360c92283137f41e43f6feba95dcac522bbd1b07f710c47a0d483e3325ff482fc101c18b658b18e767bed6483c31aac85cf9f785ec331800b602ac69bbd5c6a5131dc2ba77e6384fc98cca8fa28641a07fee8a3879e3ba666c4cd938475084f9ada33ae131b6e0de2d9a8f7d359ee01ed341f05979be64d45298acd472d43153f16430c9b8ca9d1389534c3e91e84552c5a4f4270378d99441d482e47dd0eafd75d9374098a1239e401912ff5334ff2d71cb994db53fbfbf947c07399310b51d55ddcfb623a38fb0b8861efff4c8ba89148650fc1b0078ffd767d9f8de53b906d12bdac8b2a27b150f8b73b73400defd417f61c2f87e5c81a125089127601ec551cecac72bb242e21849481ea94f47e470f2ac0798cd2ef3a80a8bef43998ed8f2ef37a28bc532c72ba30086d124e20ee994d859ac6e0eed7d1aa97577bfa0fcfad0f250860ffe3fccaf4af1888a0d3f4d340f2d9985a14fc200a07dd242cbbe8d12dc4d87ac241ccdc06e6343f508"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-16.997939267098193d));
// 
//   }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test334"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     int var7 = var6.getNumElements();
//     double var9 = var6.substituteMostRecentElement(31.862892444737472d);
//     double var11 = var6.substituteMostRecentElement(1929.4784382564899d);
//     var6.contract();
//     var6.setNumElements(181);
//     var6.contract();
//     var6.contract();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.8231890989165793d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 31.862892444737472d);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test335"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    var4.addElement(0.0d);
    int var8 = var4.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var4.getElement(1073741698);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test336"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.4249487886097677d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 20.550312678391688d);

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test337"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)2.5517620356803065E-188d, (java.lang.Number)0.010100839201864612d, true);
//     boolean var5 = var4.getBoundIsAllowed();
//     boolean var6 = var4.getBoundIsAllowed();
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     org.apache.commons.math3.exception.util.Localizable var12 = null;
//     org.apache.commons.math3.exception.util.Localizable var13 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var14 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var13, (java.lang.Object[])var14);
//     org.apache.commons.math3.exception.MathInternalError var16 = new org.apache.commons.math3.exception.MathInternalError(var12, (java.lang.Object[])var14);
//     org.apache.commons.math3.exception.MathArithmeticException var17 = new org.apache.commons.math3.exception.MathArithmeticException(var11, (java.lang.Object[])var14);
//     org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException(var10, (java.lang.Object[])var14);
//     org.apache.commons.math3.exception.MaxCountExceededException var19 = new org.apache.commons.math3.exception.MaxCountExceededException(var8, (java.lang.Number)(-1.2458743353298596d), (java.lang.Object[])var14);
//     org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var7, (java.lang.Object[])var14);
// 
//   }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test338"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextWeibull(7.769493748166378d, 1.2185657441986304d);
//     int var9 = var0.nextPascal(1980, 0.0d);
//     double var12 = var0.nextCauchy(0.07721018280235958d, 0.13234633557495218d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextGaussian(61.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.1759357880304884d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.12958193624153969d);
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test339"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1916);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var1.substituteMostRecentElement(8.277113894567627d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test340"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(7.6293945E-6f, 9.536744E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.6293945E-6f);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test341"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.014371477299916167d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test342"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-0.17559123192568796d), (-9.83148073014245d), 4.069455911176068d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test343"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1952, 13L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test344"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(8.471368814739497E-51d, 0.5718637074096835d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8.471368814739497E-51d);

  }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test345"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     java.lang.String var13 = var0.nextHexString(10);
//     var0.reSeedSecure();
//     double var17 = var0.nextGaussian(7.042014262199385d, 1.179103839756096d);
//     double var20 = var0.nextCauchy((-1.4998528973459138d), 2.7076386898590252d);
//     var0.reSeedSecure();
//     org.apache.commons.math3.distribution.NormalDistribution var22 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var23 = var22.getStandardDeviation();
//     double[] var25 = var22.sample(1);
//     double var26 = var22.getMean();
//     double[] var28 = var22.sample(100);
//     double var29 = var22.sample();
//     double var30 = var22.sample();
//     double var32 = var22.probability((-0.3722334692039834d));
//     double var34 = var22.probability(0.7681252299306625d);
//     boolean var35 = var22.isSupportLowerBoundInclusive();
//     double var36 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var22);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var38 = var0.nextHexString((-80136));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.803066169229119d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "48390245f1"+ "'", var8.equals("48390245f1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "57aca7d756"+ "'", var13.equals("57aca7d756"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 7.385542629806067d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-4.643982359808197d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.91427087169167d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == (-2.6440305484153814d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == (-0.6051818132474679d));
// 
//   }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test346"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(410338673L, 6379912561590279263L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test347"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-843938129), (-519018850));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test348"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.9999494975001091d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test349"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.random.RandomGenerator var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var8 = var7.getTiesStrategy();
//     java.lang.Class var9 = var8.getDeclaringClass();
//     int var10 = var8.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var8);
//     org.apache.commons.math3.random.RandomGenerator var12 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var12);
//     org.apache.commons.math3.random.RandomGenerator var14 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var14);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
//     java.lang.Class var18 = var17.getDeclaringClass();
//     java.lang.String var19 = var17.toString();
//     java.lang.String var20 = var17.toString();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var26 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(var26);
//     org.apache.commons.math3.distribution.NormalDistribution var28 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var29 = var28.getSupportUpperBound();
//     double[] var31 = var28.sample(10);
//     double var32 = var22.mannWhitneyU(var26, var31);
//     double[] var33 = var21.rank(var26);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var34 = var21.getNanStrategy();
//     java.lang.String var35 = var34.toString();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var37 = var36.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var38 = var36.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var39 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var40 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var41 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var42 = var41.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var43 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var40, var42);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var44 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var39, var42);
//     java.lang.String var45 = var42.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var46 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var38, var42);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var47 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var48 = var47.getTiesStrategy();
//     java.lang.Class var49 = var48.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var50 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var48);
//     java.lang.String var51 = var48.toString();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var52 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var38, var48);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var53 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var34, var48);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var54 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var55 = var54.getTiesStrategy();
//     java.lang.Class var56 = var55.getDeclaringClass();
//     java.lang.Class var57 = var55.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var58 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var55);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var59 = var58.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var60 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.distribution.NormalDistribution var61 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var62 = var61.getStandardDeviation();
//     boolean var63 = var61.isSupportUpperBoundInclusive();
//     double[] var65 = var61.sample(100);
//     org.apache.commons.math3.distribution.NormalDistribution var66 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var66.reseedRandomGenerator(2L);
//     double[] var70 = var66.sample(100000);
//     double var71 = var60.mannWhitneyUTest(var65, var70);
//     org.apache.commons.math3.distribution.NormalDistribution var72 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double[] var74 = var72.sample(1910);
//     org.apache.commons.math3.distribution.NormalDistribution var75 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var76 = var75.getStandardDeviation();
//     double[] var78 = var75.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var79 = new org.apache.commons.math3.util.ResizableDoubleArray(var78);
//     double[] var80 = var79.getElements();
//     double var81 = var60.mannWhitneyUTest(var74, var80);
//     double[] var82 = var58.rank(var80);
//     org.apache.commons.math3.distribution.NormalDistribution var83 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var83.reseedRandomGenerator(2L);
//     double[] var87 = var83.sample(100000);
//     double var88 = var53.mannWhitneyUTest(var80, var87);
//     double[] var89 = var2.rank(var87);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test350"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)(-1), (java.lang.Number)10, (java.lang.Number)6.621888603197341d);
    java.lang.String var4 = var3.toString();
    java.lang.Number var5 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: -1 out of [10, 6.622] range"+ "'", var4.equals("org.apache.commons.math3.exception.OutOfRangeException: -1 out of [10, 6.622] range"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 6.621888603197341d+ "'", var5.equals(6.621888603197341d));

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test351"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 10.0f);
    var2.addElement(0.15729920705028488d);
    var2.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var2.substituteMostRecentElement(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test352"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(2.1459739668757587d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5439838562906946d));

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test353"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.8046108761210242d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.235826316117689d);

  }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test354"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(0L);
//     int var18 = var0.nextBinomial(0, 0.33421337133949025d);
//     int var21 = var0.nextInt(0, 12767);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 19.97329937834332d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "c65344d916"+ "'", var8.equals("c65344d916"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.8019555344046855d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 10403);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 749);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test355"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    double[] var5 = var4.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    var6.clear();
    float var8 = var6.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.5f);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test356"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(2097152.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2097153);

  }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test357"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var26 = var14.getStandardDeviation();
//     double var28 = var14.density(0.01255108966724917d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 35.956666096236276d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f3961a3bb1"+ "'", var8.equals("f3961a3bb1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1954);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.011097490220331765d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1.4813556532548569d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 2.250302549626871d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.1073888029778205d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.40231460697410537d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.3989108589797407d);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test358"); }


    java.lang.Number var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test359"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(4.2E-45f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.2E-45f);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test360"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1344L, 407L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1751L);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test361"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(261.0d, 184);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.399701378655952E57d);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test362"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(1962, 0.0f, 2.5000002f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test363"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    boolean var13 = var2.equals((java.lang.Object)(-1.5564980685845229d));
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var15, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14, var17);
    java.lang.String var20 = var17.name();
    java.lang.String var21 = var17.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var24 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "AVERAGE"+ "'", var21.equals("AVERAGE"));

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test364"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-1.6937792675979062d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9833962003677833d));

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test365"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, (-4.503599627370493E15d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test366"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(16.354803803411567d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.75260196445581d);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test367"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(8336, 1871);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1871);

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test368"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var21 = var18.nextSecureLong((-1L), 1L);
//     double var24 = var18.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var26 = var18.nextSecureHexString(100);
//     double var28 = var18.nextT(20.696514663540924d);
//     org.apache.commons.math3.distribution.NormalDistribution var29 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var30 = var29.getStandardDeviation();
//     double[] var32 = var29.sample(1);
//     double var33 = var29.getMean();
//     double[] var35 = var29.sample(100);
//     double var36 = var29.sample();
//     double var37 = var29.sample();
//     double var38 = var18.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     double var39 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     org.apache.commons.math3.distribution.NormalDistribution var40 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var41 = var40.getStandardDeviation();
//     double[] var43 = var40.sample(1);
//     double var44 = var40.getMean();
//     double[] var46 = var40.sample(100);
//     double var47 = var40.sample();
//     double var48 = var40.sample();
//     var40.reseedRandomGenerator(10L);
//     boolean var51 = var40.isSupportLowerBoundInclusive();
//     boolean var52 = var40.isSupportLowerBoundInclusive();
//     double var53 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var40);
//     double var55 = var0.nextChiSquare(4.3312580140185375d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.84008164872586d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "87bc9ad79d376d1f4c901ea60ff3b1bb9d6ea528ac29f9c2ccd66b7acebe55f4eeadb2fae6d0525b08f517963d1e065861cf"+ "'", var8.equals("87bc9ad79d376d1f4c901ea60ff3b1bb9d6ea528ac29f9c2ccd66b7acebe55f4eeadb2fae6d0525b08f517963d1e065861cf"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.09418014555261975d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 11.313587077804998d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "2a28b1851f7e8a659f5b6e9b88f20cf9e9ab65ebb5f68a668ea3e13e3da9ae7885e2bda6873808a218d0582f1bc444ffb9ea"+ "'", var26.equals("2a28b1851f7e8a659f5b6e9b88f20cf9e9ab65ebb5f68a668ea3e13e3da9ae7885e2bda6873808a218d0582f1bc444ffb9ea"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.1976680070552211d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0.5163754206631227d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == (-0.799812575076354d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0.1479381019675631d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-1.2222938382629314d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0.055344187105710436d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 0.2332267376163847d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == (-1.332977418220518d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 3.1798408186341236d);
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test369"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.setElement(8899, 2.3930658372149933d);
    var4.clear();
    double[] var17 = var4.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test370"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.clear();
    float var8 = var6.getExpansionFactor();
    var6.setContractionCriteria(2.0f);
    float var11 = var6.getContractionCriteria();
    var6.addElement((-0.27924610171153436d));
    double var15 = var6.substituteMostRecentElement((-0.300194891342756d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.discardFrontElements((-1953380655));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-0.27924610171153436d));

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test371"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(6.579251212010101d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 360.00069444444455d);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test372"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.0d, 0.5433347981567266d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test373"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.5d, (java.lang.Number)7.724435900937391d, (java.lang.Number)363.7393755555636d);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    java.lang.Number var5 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 7.724435900937391d+ "'", var5.equals(7.724435900937391d));

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test374"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(3.2086886772456507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8940972287696577d);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test375"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(183L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 183L);

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test376"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double[] var6 = var0.sample(100);
//     double var7 = var0.sample();
//     double var8 = var0.sample();
//     var0.reseedRandomGenerator(10L);
//     boolean var11 = var0.isSupportLowerBoundInclusive();
//     boolean var12 = var0.isSupportLowerBoundInclusive();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.inverseCumulativeProbability(1.5145258052087136d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-3.071839773241222d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.12785264434915766d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test377"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.552060002488522d, 192.9088122275434d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.753019033373932E-86d);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test378"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double[] var3 = var0.sample(10);
    double var4 = var0.getStandardDeviation();
    double var5 = var0.getStandardDeviation();
    double var6 = var0.getNumericalVariance();
    double var7 = var0.getNumericalVariance();
    double var9 = var0.probability(0.9999999999999925d);
    double var11 = var0.probability(3.0741607150885346d);
    var0.reseedRandomGenerator(12L);
    var0.reseedRandomGenerator(91530199783L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test379"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(100, 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9022318084E12d);

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test380"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(3.204410333955557d, (-0.338441311980818d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test381"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0, 5668);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test382"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(67L, 523L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 35041L);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test383"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("ecfccdb12b");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test384"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, 4L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test385"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     double var11 = var0.nextF(0.6351254179184792d, 14.27900880653991d);
//     double var13 = var0.nextChiSquare(6.847746722572357d);
//     double var16 = var0.nextBeta(7.617953921806563d, 21.86927808496264d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.943031290230727d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "0e5442e05e"+ "'", var8.equals("0e5442e05e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.2527966485303046d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.4860529689831106d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.2989577585010827d);
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test386"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.clear();
    float var8 = var6.getExpansionFactor();
    var6.setContractionCriteria(2.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = var6.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var6.substituteMostRecentElement(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test387"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.9969493037940971d, 0.6901124746731373d);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test388"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.38723217154802d, 0.15630386727208576d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.3872321715480199d);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test389"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Throwable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var6 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var4, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var3, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)2.946007020743843d, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test390"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)8.797429825798508d, (java.lang.Number)1818, false);

  }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test391"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var0.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.9993996079017906d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "627b10a5c8"+ "'", var8.equals("627b10a5c8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1898);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.005924655995725668d);
// 
//   }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test392"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    double[] var6 = var4.getInternalValues();
    org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var8 = var7.getStandardDeviation();
    double[] var10 = var7.sample(1);
    double var11 = var7.getMean();
    double[] var13 = var7.sample(100);
    var4.addElements(var13);
    var4.setElement(36, 0.38829865251165124d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var19 = var4.getElement((-4));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test393"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(962, 11274);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 962);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test394"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
    java.lang.Object var17 = null;
    boolean var18 = var4.equals(var17);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = var4.copy();
    var4.addElement(6.621888603197341d);
    var4.setElement(1848, 0.1708276255239572d);
    double var26 = var4.substituteMostRecentElement(0.03378478068568291d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.1708276255239572d);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test395"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(1942, 1.1368683E-13f, 100.00001f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test396"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.16043285994536438d, 0.25587682077976953d, (-0.6801548754218844d));
    double var4 = var3.getNumericalMean();
    double var5 = var3.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.16043285994536438d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.25587682077976953d);

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test397"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     var0.reSeed();
//     double var15 = var0.nextChiSquare(7.617953921806563d);
//     double var17 = var0.nextExponential(1.5574077246549007d);
//     double var19 = var0.nextChiSquare(0.16043285994536435d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var0.nextUniform(0.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.770301703433816d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "63c0a9f959"+ "'", var8.equals("63c0a9f959"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 4.873560250298862d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.219968178591565d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 2.021256360892064E-5d);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test398"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(80, 784);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test399"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(2.799734029061339d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2277422966290603d);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test400"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(113506941100L, 8L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 113506941108L);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test401"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1833.4649444186343d, 0.29012532982348616d, 20.665469503447394d);

  }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test402"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(0L);
//     long var17 = var0.nextPoisson(7.769493748166378d);
//     double var20 = var0.nextCauchy(2.3844973909690124d, 1.5958068268285657d);
//     int var24 = var0.nextHypergeometric(9192904, 1906, 17190);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var27 = var0.nextSecureInt(338177, 2297);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9.7765994046177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "0840d7c7b2"+ "'", var8.equals("0840d7c7b2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.5170040419808531d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 8865);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-7.1999685561550555d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 5);
// 
//   }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test403"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-0.1397549781611366d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.002439184514964604d));

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test404"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(3.1855205836148377d, 0.9792351001360415d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9406303691389064d);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test405"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-3.244985903582095d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.10376326254210537d));

  }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test406"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var18 = var0.nextSecureLong(5071615437313169417L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.097305516993742d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "cb37746e3f"+ "'", var8.equals("cb37746e3f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.8994677454598671d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 9920);
// 
//   }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test407"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
//     java.lang.Class var5 = var4.getDeclaringClass();
//     java.lang.Class var6 = var4.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
//     java.lang.String var8 = var4.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getStandardDeviation();
//     double[] var13 = var10.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
//     var14.contract();
//     org.apache.commons.math3.util.ResizableDoubleArray var16 = var14.copy();
//     var16.contract();
//     int var18 = var16.getExpansionMode();
//     var16.setElement(5, 20.696514663540924d);
//     int var22 = var16.getExpansionMode();
//     double[] var23 = var16.getElements();
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var25 = var24.getStandardDeviation();
//     double[] var27 = var24.sample(1);
//     double var28 = var24.getMean();
//     double[] var30 = var24.sample(100);
//     double var31 = var24.sample();
//     double var32 = var24.sample();
//     double var34 = var24.probability((-0.3722334692039834d));
//     double[] var36 = var24.sample(8);
//     double var37 = var9.mannWhitneyUTest(var23, var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1.1920563570514449d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == (-0.4354951964142367d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0.7962534147376392d);
// 
//   }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test408"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 11L);
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, var14);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 1949);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, var17);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 1845);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, 136);
    org.apache.commons.math3.exception.NumberIsTooSmallException var25 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)var22, (java.lang.Number)3.4828309946604796d, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test409"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(2.718196707650845d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 14.15297235332853d);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test410"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     var0.reSeedSecure(2184L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextWeibull((-0.0975581339764322d), (-1.0480925762101703d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 18.045156983749646d);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test411"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(11474, 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test412"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(2058820555291694441L, 40318L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6005197975992252401L);

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test413"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     double var11 = var0.nextF(0.9672931540516151d, 1.0101518513770347d);
//     long var14 = var0.nextSecureLong(1073741824L, 1342177280L);
//     double var17 = var0.nextWeibull(1.234378816808383d, 0.24565773749873202d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.5920878820872515d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "b20ae305eb3303a05005f3a454b16c62357cc52978930ec33a1ad91a72c16066c47027e1fce236985a5e427f0699c87fabd3"+ "'", var8.equals("b20ae305eb3303a05005f3a454b16c62357cc52978930ec33a1ad91a72c16066c47027e1fce236985a5e427f0699c87fabd3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3.357622663932517d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1172653612L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.3333589215675262d);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test414"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(1.6740869895151453d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.090617157768497d);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test415"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1822);

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test416"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     var0.reSeed();
//     double var15 = var0.nextChiSquare(7.617953921806563d);
//     double var17 = var0.nextExponential(1.5574077246549007d);
//     org.apache.commons.math3.distribution.NormalDistribution var21 = new org.apache.commons.math3.distribution.NormalDistribution(0.8259324122591327d, 0.2782029380240531d, 0.0d);
//     double var22 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var21);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var25 = var0.nextZipf(43, (-2.5244024552889823d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10.97766467970271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "13c56e4906"+ "'", var8.equals("13c56e4906"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 12.196889745259378d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.851511035284384d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1.0131076945458406d);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test417"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-6.100747048741361d), 0.0d, (-0.9679339159763662d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test418"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getStandardDeviation();
//     double[] var13 = var10.sample(1);
//     double var15 = var10.cumulativeProbability(0.0d);
//     double var16 = var10.getSupportUpperBound();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     double var20 = var0.nextUniform((-0.46723055192344254d), 0.004492688352124083d);
//     int var23 = var0.nextBinomial(1952, 0.7625552649455967d);
//     double var26 = var0.nextWeibull(0.3613755384667159d, 4.252640503606456d);
//     double var29 = var0.nextGaussian((-0.8303092966149682d), 1.4128411121633297d);
//     double var31 = var0.nextExponential(1.3043475340952027d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 14.098758641721778d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.5788493556454056d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-0.37743086488641814d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1502);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 23.694063377570263d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == (-0.813268945754157d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 2.6830532210059452d);
// 
//   }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test419"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.1920929E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test420"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1933, 1962);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1962);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test421"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(20.184060820812302d, 0.966538993199365d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 20.184060820812302d);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test422"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1871, 1972);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test423"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.distribution.NormalDistribution var1 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var1.getStandardDeviation();
    double[] var4 = var1.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    double[] var6 = var5.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var14 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var10, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var15 = var14.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var9, (java.lang.Object[])var15);
    org.apache.commons.math3.exception.MathArithmeticException var17 = new org.apache.commons.math3.exception.MathArithmeticException(var8, (java.lang.Object[])var15);
    boolean var18 = var7.equals((java.lang.Object)var15);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var15);
    org.apache.commons.math3.exception.util.ExceptionContext var20 = var19.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test424"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(0.5036510690527161d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5652287876516469d);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test425"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     java.lang.String var13 = var0.nextHexString(10);
//     var0.reSeedSecure();
//     double var17 = var0.nextGaussian(7.042014262199385d, 1.179103839756096d);
//     double var20 = var0.nextGamma(0.0d, 1.1085491470603452d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var0.nextZipf(1891, (-27.874703436170744d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.779249754581006d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "2abc3cafa4"+ "'", var8.equals("2abc3cafa4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "bd14edd107"+ "'", var13.equals("bd14edd107"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 7.958984252511077d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.0d);
// 
//   }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test426"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double[] var6 = var0.sample(100);
//     double var7 = var0.sample();
//     double var8 = var0.sample();
//     double var9 = var0.getStandardDeviation();
//     double var10 = var0.sample();
//     double var11 = var0.getNumericalMean();
//     double var12 = var0.getSupportUpperBound();
//     double var13 = var0.getNumericalMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-2.0349786765628965d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1.0061810290320632d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.2730887254230184d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test427"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-536870912L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 536870912L);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test428"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(1.3684997729910229d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05294724538175817d);

  }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test429"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var13 = var0.nextT(5.867156662812015d);
//     double var15 = var0.nextExponential(11.771947930619202d);
//     int var18 = var0.nextBinomial(0, 0.0031612049524534893d);
//     var0.reSeedSecure(2184L);
//     int var23 = var0.nextSecureInt(0, 2426);
//     long var25 = var0.nextPoisson(0.5718637074096835d);
//     org.apache.commons.math3.random.RandomDataImpl var26 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var29 = var26.nextSecureLong((-1L), 1L);
//     double var32 = var26.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var35 = var26.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var36 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var37 = var36.getStandardDeviation();
//     double[] var39 = var36.sample(1);
//     double var41 = var36.cumulativeProbability(0.0d);
//     double var42 = var36.getSupportUpperBound();
//     double var43 = var26.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var36);
//     double var44 = var36.sample();
//     double var45 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var36);
//     boolean var46 = var36.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.989726476413246d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "c7b246b586"+ "'", var8.equals("c7b246b586"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.428935981203757d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 11.06699780188733d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 137);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 5.727386887843373d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == (-1.042752518371462d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 0.13831284205576994d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 2.6845617943716698d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test430"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(byte)10);
    boolean var2 = var1.getBoundIsAllowed();
    java.lang.Number var3 = var1.getArgument();
    boolean var4 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)10+ "'", var3.equals((byte)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test431"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(54, 0.0f, 10.000001f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test432"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp((-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.9604645E-8f);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test433"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    java.lang.Class var11 = var10.getDeclaringClass();
    java.lang.Class var12 = var10.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    java.lang.String var14 = var10.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var8, var10);
    org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var17 = var16.getStandardDeviation();
    double[] var19 = var16.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var25 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
    double[] var30 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray(var30);
    double var32 = var21.mannWhitneyU(var25, var30);
    double var33 = var15.mannWhitneyUTest(var19, var25);
    var4.addElements(var19);
    org.apache.commons.math3.distribution.NormalDistribution var35 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var36 = var35.getStandardDeviation();
    double[] var38 = var35.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var39 = new org.apache.commons.math3.util.ResizableDoubleArray(var38);
    var39.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var41 = var39.copy();
    var41.addElement(0.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var44 = var41.copy();
    int var45 = var44.getExpansionMode();
    var44.setNumElements(67);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var44);
    float var49 = var44.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "AVERAGE"+ "'", var14.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 4.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.17971249487899976d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 2.0f);

  }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test434"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var2 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.NullArgumentException var3 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var2);
//     org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var2);
//     org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var11 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var10, (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var9, (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.MaxCountExceededException var14 = new org.apache.commons.math3.exception.MaxCountExceededException(var7, (java.lang.Number)11.394339056267674d, (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var6, (java.lang.Object[])var11);
// 
//   }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test435"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var4.addElement((-0.43408597923864894d));
//     double var10 = var4.getElement(0);
//     double[] var11 = var4.getElements();
//     var4.setNumElements(64);
//     var4.addElement(21.120232711293063d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5295919284945939d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test436"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1172653612L, (-79579695));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test437"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.9971027061668425d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7839474158762535d);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test438"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(202L, 22L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 180L);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test439"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var11 = var9.sample();
//     double var13 = var9.probability(7.444490968701611d);
//     double var14 = var9.getSupportUpperBound();
//     double[] var16 = var9.sample(9694);
//     boolean var17 = var9.isSupportLowerBoundInclusive();
//     double var19 = var9.density(0.004492703465851146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9.122933421732759d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "0ebfb78db3"+ "'", var8.equals("0ebfb78db3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.7101168092958805d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1.1586804383564708d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.39893825421957235d);
// 
//   }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test440"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextWeibull(7.769493748166378d, 1.2185657441986304d);
//     int var9 = var0.nextPascal(1980, 0.0d);
//     int var12 = var0.nextPascal(9066, 0.06995726965750072d);
//     int var15 = var0.nextBinomial(1877, 1.2578273612086598E-16d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.5131053078208063d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 119156);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0);
// 
//   }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test441"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-1342156216L), 445346L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1342601562L));

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test442"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     int[] var9 = var0.nextPermutation(11213, 1203);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var0.nextLong(56L, (-2L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.32948325703119286d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test443"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(18);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test444"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.5843347878184303d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test445"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(99.999985f, 2.3841858E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99.999985f);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test446"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)95, (java.lang.Number)0.09545662227586584d, true);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test447"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(30.694830394718466d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.1408954707709844E13d);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test448"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeedSecure(0L);
//     var0.reSeed();
//     long var16 = var0.nextLong((-1342136858L), 21428512432590984L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.0073295510214315d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "08ff070269"+ "'", var8.equals("08ff070269"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 14476565355254286L);
// 
//   }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test449"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(760L, (-1342136858L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1342136858L));

  }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test450"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var1, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
//     java.lang.Throwable[] var6 = var5.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var6);
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     org.apache.commons.math3.exception.util.Localizable var12 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var13 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var14 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var12, (java.lang.Object[])var13);
//     org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var11, (java.lang.Object[])var13);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var10, (java.lang.Object[])var13);
//     org.apache.commons.math3.exception.MathArithmeticException var17 = new org.apache.commons.math3.exception.MathArithmeticException(var9, (java.lang.Object[])var13);
//     org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var8, (java.lang.Object[])var13);
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test451"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-79579695), 838);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-79578857));

  }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test452"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     double var9 = var0.nextF(2.281783181607902d, 0.8427007929497151d);
//     long var12 = var0.nextLong(4L, 100L);
//     double var14 = var0.nextT(18.59245611312501d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 26.407391962561153d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 24.163869920689454d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 100L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.012685301733947772d);
// 
//   }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test453"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(9194402);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test454"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo((-202L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test455"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(11.394339056267674d, 14.792906103929404d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 14.792906103929404d);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test456"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.9915639738034129d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test457"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(56L, 35041L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test458"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(1502);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test459"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextPascal((-127), (-0.5977681008511015d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.206573345275304d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "247992fa89"+ "'", var8.equals("247992fa89"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9389835520978849d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 12088);
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test460"); }


    long var1 = org.apache.commons.math3.util.FastMath.round((-0.43408597923864894d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test461"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    boolean var7 = var0.isSupportUpperBoundInclusive();
    double var8 = var0.getStandardDeviation();
    double var9 = var0.getStandardDeviation();
    double var10 = var0.getSupportLowerBound();
    double var11 = var0.getStandardDeviation();
    boolean var12 = var0.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test462"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(1.1675832066593317d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test463"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(10.0d, (-47.561794942941404d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.742868942871478E-48d);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test464"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-1.2732919183123732d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2931351592514078d);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test465"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.15512025679417774d, var1, false);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test466"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 7.002151457729533d, 2.0171610553467367d, (-623678255));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test467"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     java.lang.Class var2 = var1.getDeclaringClass();
//     java.lang.Class var3 = var1.getDeclaringClass();
//     boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
//     java.lang.Class var6 = var1.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var9 = var8.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var8.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
//     java.lang.Class var13 = var12.getDeclaringClass();
//     java.lang.Class var14 = var12.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
//     java.lang.String var16 = var12.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var10, var12);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var22 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var25 = var24.getSupportUpperBound();
//     double[] var27 = var24.sample(10);
//     double var28 = var18.mannWhitneyU(var22, var27);
//     org.apache.commons.math3.distribution.NormalDistribution var29 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var30 = var29.getSupportUpperBound();
//     double[] var32 = var29.sample(10);
//     double var33 = var29.getStandardDeviation();
//     double var35 = var29.density(2.345330933436551d);
//     double[] var37 = var29.sample(180);
//     double var38 = var17.mannWhitneyU(var22, var37);
//     org.apache.commons.math3.distribution.NormalDistribution var39 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var40 = var39.getStandardDeviation();
//     double[] var42 = var39.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var43 = new org.apache.commons.math3.util.ResizableDoubleArray(var42);
//     int var44 = var43.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var45 = var43.copy();
//     var43.addElement((-0.43408597923864894d));
//     double var49 = var43.getElement(0);
//     double[] var50 = var43.getElements();
//     org.apache.commons.math3.random.RandomDataImpl var51 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var54 = var51.nextSecureLong((-1L), 1L);
//     double var57 = var51.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var59 = var51.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var60 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var61 = var51.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var60);
//     double var62 = var60.sample();
//     double var64 = var60.probability(7.444490968701611d);
//     double var65 = var60.getSupportUpperBound();
//     double[] var67 = var60.sample(9694);
//     double var68 = var17.mannWhitneyUTest(var50, var67);
//     double[] var69 = var7.rank(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "AVERAGE"+ "'", var16.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 18.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0.025496167636629936d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 447.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == (-0.07458733982868475d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 13.82547337933909d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var59 + "' != '" + "14794a1b02"+ "'", var59.equals("14794a1b02"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 0.586968401150083d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == (-0.0837550109278979d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 0.6413073337280892d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
// 
//   }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test468"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getStandardDeviation();
//     double[] var13 = var10.sample(1);
//     double var15 = var10.cumulativeProbability(0.0d);
//     double var16 = var10.getSupportUpperBound();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var0.nextBinomial(16216148, 10.066508877759123d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 17.136992019592583d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.16593395295792637d);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test469"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.4496917979688907d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2));

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test470"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1919, 100.00001f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var4 = var3.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.discardFrontElements(1946);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test471"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.12255979974565301d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.12317904337668156d);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test472"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.1479381019675631d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1379673782970171d);

  }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test473"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     double var9 = var0.nextUniform(0.0d, 0.5382762305934016d);
//     int var12 = var0.nextSecureInt(751, 1946);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.28560845748695685d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.5219032391758957d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 751);
// 
//   }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test474"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.5145258052087136d, (java.lang.Number)2.3003553743104947d, (java.lang.Number)0.9170148503640131d);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test475"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.616997084235088d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2716120022377455d);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test476"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc((-1.4352209005379446d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9576138584853786d);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test477"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.clear();
    float var8 = var6.getExpansionFactor();
    var6.setContractionCriteria(2.0f);
    float var11 = var6.getContractionCriteria();
    var6.addElement((-0.27924610171153436d));
    double var15 = var6.substituteMostRecentElement((-0.300194891342756d));
    float var16 = var6.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-0.27924610171153436d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.0f);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test478"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(15.095802671691928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 15.0d);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test479"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var4);
    java.lang.String var7 = var4.name();
    java.lang.String var8 = var4.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "AVERAGE"+ "'", var7.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test480"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 6L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 268435456L);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 1600L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test481"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.7066174912281796E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0011950297877714891d);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test482"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(2L, 79833600L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test483"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(100.000015f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.00002f);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test484"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    int var7 = var6.getNumElements();
    var6.setNumElements(8899);
    int var10 = var6.start();
    int var11 = var6.getNumElements();
    int var12 = var6.getNumElements();
    var6.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray.copy(var6, var14);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 8899);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 8899);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test485"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(1053960288888713761L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test486"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(14.544490524041342d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 14.544490524041343d);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test487"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     int var20 = var0.nextBinomial(0, 0.7615941559557649d);
//     double var23 = var0.nextWeibull(1.2075656224493654d, 2.265662238504449d);
//     var0.reSeed();
//     java.util.Collection var25 = null;
//     java.lang.Object[] var27 = var0.nextSample(var25, 1949);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test488"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.912933013825568d);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test489"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(79833600L, 4L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 79833600L);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test490"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(305, 1793);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1019227855));

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test491"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.1368685E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-43));

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test492"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    boolean var13 = var2.equals((java.lang.Object)(-1.5564980685845229d));
    java.lang.Class var14 = var2.getDeclaringClass();
    java.lang.String var15 = var2.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "MAXIMAL"+ "'", var15.equals("MAXIMAL"));

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test493"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var13 = var12.getStandardDeviation();
//     double[] var15 = var12.sample(1);
//     double var16 = var12.getMean();
//     double[] var18 = var12.sample(100);
//     boolean var19 = var12.isSupportLowerBoundInclusive();
//     boolean var20 = var12.isSupportUpperBoundInclusive();
//     double[] var22 = var12.sample(8899);
//     double var23 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     java.lang.String var25 = var0.nextHexString(10775);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var28 = var0.nextPascal(10241, (-1.5564980685845229d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.3627504064063d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "2b68cb8baa"+ "'", var8.equals("2b68cb8baa"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1899);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-1.587543398034724d));
// 
//   }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test494"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.0d, 0.9908408930517206d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9908408930517206d);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test495"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
    boolean var10 = var8.equals((java.lang.Object)(-1.737874520729035d));
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var12.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    java.lang.Class var17 = var16.getDeclaringClass();
    int var18 = var16.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14, var16);
    org.apache.commons.math3.random.RandomGenerator var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14, var20);
    org.apache.commons.math3.random.RandomGenerator var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14, var22);
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var25.getTiesStrategy();
    java.lang.Class var27 = var26.getDeclaringClass();
    java.lang.Class var28 = var26.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14, var26);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var30 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var11, var26);
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var26);
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var33 = var32.getTiesStrategy();
    java.lang.Class var34 = var33.getDeclaringClass();
    java.lang.Class var35 = var33.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var33);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var37 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var8, var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test496"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.8946463157932409d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test497"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.8136343340898944d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test498"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("012c442bc7");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test499"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 0.0f, 1.1920929E-7f, 248);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test500"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(0L);
//     long var17 = var0.nextPoisson(7.769493748166378d);
//     double var19 = var0.nextExponential(8.563154148722202d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 13.72049706506842d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ae7ed790f0"+ "'", var8.equals("ae7ed790f0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.46433885006816616d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 9105);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 6.408605199220259d);
// 
//   }

}
