
import junit.framework.*;

public class RandoopTest13 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test1"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.8414709848078964d, 0.7745517090716676d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8414709848078964d);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test2"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setContractionCriteria(1.0000002f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test3"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var6, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var8);
    org.apache.commons.math3.exception.MaxCountExceededException var12 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)1.1591352365493741d, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test4"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(9L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9L);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test5"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(1.1458509338674643d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5337363865076407d);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test6"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(900, (-1024));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test7"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.8999371873429769d, 0.3460731448215636d);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test8"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.7745517090716676d);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test9"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var2.copy();
    float var4 = var3.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var7.setExpansionMode(0);
    double[] var10 = var7.getInternalValues();
    var3.addElements(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test10"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(1688143320063612998L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test11"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(1.1591352365493741d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9895469697130671d);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test12"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-0.18834749242221216d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0d));

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test13"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(7053352210170117173L, 90L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7053352210170117173L);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test14"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-13), 102912.0f, 0.0f, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test15"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(100.5f, 2.074594310659796d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.49999f);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test16"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, (-109L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-109L));

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test17"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.02756156531860343d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.02755458954302434d);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test18"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(100.0f, 0.7435938375035029d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99.99999f);

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test19"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-1024));
//     org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test20"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(900, (-8));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test21"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(100, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test22"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.8999371873429769d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6418208263327543d);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test23"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(125.31727114935688d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test24"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 90L);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test25"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.contract();
    int var7 = var2.start();
    var2.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test26"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(230400);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test27"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0L, 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test28"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-13));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test29"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 10.0f, 1.0000002f, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test30"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 10);
// 
//   }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test31"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.9168407258198261d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5688379597558102d);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test32"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-1024), (-11700));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2995200);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test33"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-10.0f), (-13));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0012207031f));

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test34"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)3.8146973E-6f);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test35"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    boolean var6 = var4.getBoundIsAllowed();
    boolean var7 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

//  public void test36() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest13.test36"); }
//
//
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(273111867);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//
//  }
//
  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test37"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(900, 273111867);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 273112767);

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test38"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 2995200);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test39"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(1.8142035178418503E-11d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8142035178418503E-11d);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test40"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-0.5452181278046861d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.42028468248206136d));

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test41"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (-1) exceeded");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test42"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(1.271554272071574d, 1.4567813447268017d);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test43"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(102912.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test44"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(2.8720980175938546d, (-0.42028468248206136d), 1.8142035178418503E-11d, 91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test45"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-1.2927045528110097d), 1024);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test46"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.2544789518188435d, (java.lang.Number)0.9168407258198261d, true);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.NotPositiveException var6 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.010642682047134422d);
    var3.addSuppressed((java.lang.Throwable)var6);
    java.lang.Number var8 = var6.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0.010642682047134422d+ "'", var8.equals(0.010642682047134422d));

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test47"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(1.8519271337371066d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test48"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.013707783890401887d, 0.5403023093369417d, 1.0832618148996653d, (-11700));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test49"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(49.999996f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.8146973E-6f);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test50"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(1.4407844498728315d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8938555297316175d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test51"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(10, (-11700));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test52"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.3581288330251856d, 0.007421211557185701d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.35812883302518556d);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test53"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.5574077246549023d, 1.8519271337371066d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6875191546609779d);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test54"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.8720980175938546d);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test55"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(100.49999f, 49.999992f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.49999f);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test56"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(1.9154696972910814d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6499628652950262d);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test57"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.8938555297316175d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.1122111167200628d));

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test58"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-0.7108770633520998d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6112265217154569d));

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test59"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.3581288330251856d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5984386627092083d);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test60"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    boolean var6 = var3.isSupportConnected();
    double var9 = var3.cumulativeProbability(1.1591352365493741d, 10.000000000000002d);
    double var10 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.976508918599899d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.POSITIVE_INFINITY);

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test61"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
//     double[] var5 = new double[] { };
//     double[] var6 = var2.rank(var5);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test62"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)7.253658542162704E-25d, (java.lang.Number)0.05094568456366692d, (java.lang.Number)3.1868873092888728d);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test63"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.27640092266786565d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.30412140489554756d);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test64"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.discardFrontElements(0);
    org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var14 = var12.probability(7.569397550458789d);
    double[] var16 = var12.sample(100);
    var2.addElements(var16);
    float var18 = var2.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 100.0f);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test65"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-1024), (-1.0f), (-1024.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test66"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)2.9202368677790993d, var1, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test67"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(50.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 50);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test68"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(100.49999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.49999f);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test69"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(3.291334404149745E-22d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.2913344041497453E-22d);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test70"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-0.5063656411097588d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5260760501008375d));

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test71"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    var3.reseedRandomGenerator(0L);
    boolean var8 = var3.isSupportLowerBoundInclusive();
    double var10 = var3.cumulativeProbability(2.2683541557421067d);
    double var12 = var3.probability(0.8407359138160451d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var3.inverseCumulativeProbability(1.107194659485365d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.24191996538778948d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test72"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test73"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getNumericalVariance();
    double var7 = var3.getNumericalMean();
    double var8 = var3.getNumericalMean();
    double var9 = var3.getNumericalVariance();
    double var11 = var3.probability(1023.7781831699072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test74"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.9443504370351304d, 3.4959757017900213d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.621276550532239d);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test75"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    boolean var6 = var3.isSupportConnected();
    boolean var7 = var3.isSupportLowerBoundInclusive();
    double var8 = var3.getMean();
    var3.reseedRandomGenerator(10L);
    double var11 = var3.getStandardDeviation();
    double[] var13 = var3.sample(900);
    double var14 = var3.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.7435938375035028d);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test76"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.7612753675628248d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.2727601369496029d));

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test77"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter((-1024.0f), (-0.1090955663635007d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1023.99994f));

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test78"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(7.569397550458789d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 433.6945330979522d);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test79"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-89L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 89L);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test80"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(5365208890106504175L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5365208890106504175L);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test81"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
//     org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//     int var8 = var7.getNumElements();
//     double[] var9 = var7.getElements();
//     double[] var10 = var2.rank(var9);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test82"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.4404105453251124d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.356142290695572d));

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test83"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    var2.addElement(0.6506783754890694d);
    int var9 = var2.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var2.clear();
    var2.setNumElements(230400);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test84"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)5.889694544886073d, var2, true);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Number var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    java.lang.Object[] var13 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var11, var13);
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var10, var13);
    org.apache.commons.math3.exception.MaxCountExceededException var16 = new org.apache.commons.math3.exception.MaxCountExceededException(var8, var9, var13);
    org.apache.commons.math3.exception.NullArgumentException var17 = new org.apache.commons.math3.exception.NullArgumentException(var7, var13);
    org.apache.commons.math3.exception.NullArgumentException var18 = new org.apache.commons.math3.exception.NullArgumentException(var6, var13);
    var4.addSuppressed((java.lang.Throwable)var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test85"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(2.97848141639784d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5288560012036268E-5d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test86"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    var2.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var12.setExpansionMode(0);
    double[] var15 = var12.getInternalValues();
    var12.clear();
    double var18 = var12.addElementRolling(0.7853981633974483d);
    var12.addElement(0.0d);
    var12.setNumElements(100);
    boolean var23 = var2.equals((java.lang.Object)var12);
    int var24 = var2.getNumElements();
    int var25 = var2.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test87"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial((-11700));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test88"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    var2.setNumElements(100);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var2.copy();
    var13.setExpansionMode(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.setElement((-1024), 0.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test89"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(900, (-1023.99994f), 102912.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test90"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma((-0.9719625010961676d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test91"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)2.302585092994046d);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test92"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-18));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test93"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.10446901610108233d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test94"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-7053352210170117162L), 1688143320063612998L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test95"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(2.9202368677790993d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7341157890730137d);

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test96"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     double var4 = var2.sample();
//     boolean var5 = var2.isSupportLowerBoundInclusive();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var2.inverseCumulativeProbability((-0.42028468248206136d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.8724996273093084d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-2.881696932270113d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test97"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.976508918599899d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9921075120451343d);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test98"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)273111867, (java.lang.Number)0.7745517090716676d, (java.lang.Number)100);
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: 273,111,867 out of [0.775, 100] range"+ "'", var4.equals("org.apache.commons.math3.exception.OutOfRangeException: 273,111,867 out of [0.775, 100] range"));

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test99"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(1.261404880340075d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9255594160121382d);

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test100"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-0.15640941223089536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test101"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0L, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

//  public void test102() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest13.test102"); }
//
//
//    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//    var2.setExpansionMode(0);
//    double[] var5 = var2.getInternalValues();
//    double[] var6 = var2.getInternalValues();
//    java.lang.Object var7 = null;
//    boolean var8 = var2.equals(var7);
//    double[] var9 = var2.getElements();
//    org.apache.commons.math3.distribution.NormalDistribution var13 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//    double var15 = var13.probability(7.569397550458789d);
//    double[] var17 = var13.sample(100);
//    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
//    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var18);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      var18.setElement(273111867, 149.30261776898763d);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var5);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var6);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var8 == false);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var9);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var15 == 0.0d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var17);
//
//  }
//
  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test103"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.999566810927082d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.999566810927082d);

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test104"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, 2.653014502388273d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test105"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(230400, (-0.0012207031f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test106"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma((-2.8749746418437887d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 67.07376554895923d);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test107"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(100.0f, (-1023.99994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-100.0f));

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test108"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-5.496154324107173d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9999663392570808d));

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test109"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.05349598516132738d, 5.859571186401306E15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-12.39925184518796d));

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test110"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionMode(900);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test111"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.14022847040561234d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7755575615628914E-17d);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test112"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(91, 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test113"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1L, (-90L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 90L);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test114"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    int var8 = var2.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setContractionCriteria(49.999996f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test115"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1L, (-7053352210170117162L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7053352210170117161L));

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test116"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.5337363865076407d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.49027106946002635d);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test117"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.02755458954302434d, 12.289172084189628d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.6984987799795914d));

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test118"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
//     java.lang.Throwable[] var5 = var4.getSuppressed();
//     org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
//     java.lang.String var10 = var8.toString();
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test119"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var2.getNanStrategy();
//     org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//     var11.setExpansionMode(0);
//     double[] var14 = var11.getInternalValues();
//     org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//     int var18 = var17.getNumElements();
//     double[] var19 = var17.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var11, var17);
//     double[] var21 = var11.getElements();
//     double[] var22 = var2.rank(var21);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test120"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.8407359138160451d, 3.0640997968584167d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5876916151719559d);

  }

//  public void test121() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest13.test121"); }
//
//
//    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//    var2.setExpansionMode(0);
//    double[] var5 = var2.getInternalValues();
//    var2.clear();
//    double var8 = var2.addElementRolling(0.7853981633974483d);
//    var2.addElement(0.0d);
//    int var11 = var2.getExpansionMode();
//    boolean var13 = var2.equals((java.lang.Object)100.0f);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      var2.setNumElements(273112767);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var5);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var8 == 0.0d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var11 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var13 == false);
//
//  }
//
  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test122"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma((-0.5260760501008375d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test123"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(273112767);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 273112767);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test124"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.261404880340075d, (java.lang.Number)(-0.7108770633520998d), true);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test125"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(3.1757334232496706d, 3.206744283698114d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.581388139970086d);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test126"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.581388139970086d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.45830303092382607d);

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test127"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos((-1.2927045528110097d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test128"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-18), 900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 882);

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test129"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var3 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var1, (java.lang.Number)(byte)100);
//     org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
//     java.lang.Object[] var5 = new java.lang.Object[] { var3};
//     org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var0, var5);
//     org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var6);
// 
//   }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test130"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var4, var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var3, var6);
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, var2, var6);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var0, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test131"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.9302363507574447d, 0.45830303092382607d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5974167300266131d);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test132"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(12.80182748008147d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test133"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-7053352210170117162L), (-90L));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test134"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-0.5063656411097588d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.4868981666828701d));

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test135"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.6552836562919295d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6156490123256325d);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test136"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    boolean var5 = var3.isSupportConnected();
    boolean var6 = var3.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test137"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0, 2995200);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2995200);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test138"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.14022847040561234d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.15719982251077522d);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test139"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)3.2544789518188435d, (java.lang.Number)3.469446951953614E-18d, true);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test140"); }
// 
// 
//     java.lang.Number var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.4511708924835962d, (java.lang.Number)1.5692474232144973d);
//     java.lang.Number var4 = var3.getHi();
//     org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
//     java.lang.Throwable var6 = null;
//     var3.addSuppressed(var6);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test141"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-7053352210170117172L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test142"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.017453292447995462d, 2.653014502388273d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.653014502388273d);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test143"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    double[] var2 = var1.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardMostRecentElements(2995200);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test144"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)3.432443690009129E42d);
    boolean var2 = var1.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test145"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.30412140489554756d);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test146"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(1.553344806071505d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.027110981284700568d);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test147"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(1.1591352365493741d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.07248713056628153d));

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test148"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.31161695384777244d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.31689424315458475d);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test149"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(byte)10, (java.lang.Number)7.253658542162704E-25d, true);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test150"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(7.569397550458789d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.569397550458789d);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test151"); }


    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(900, 1.0000002f, 49.999996f);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test152"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-0.07248713056628153d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9973739581060155d);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test153"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.8170655554314067d);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test154"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1.0d), (java.lang.Number)(short)0, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test155"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(3628800L, (-7053352210170117172L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7053352210166488372L));

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test156"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(1.4596347826973801d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test157"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.9015803832466946d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2642564124929525d);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test158"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(2.7303477737455633d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9998872123077203d);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test159"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.4511708924835962d, (java.lang.Number)1.5692474232144973d);
    java.lang.Number var4 = var3.getHi();
    java.lang.Number var5 = var3.getHi();
    java.lang.Number var6 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.5692474232144973d+ "'", var4.equals(1.5692474232144973d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.5692474232144973d+ "'", var5.equals(1.5692474232144973d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.4511708924835962d+ "'", var6.equals(0.4511708924835962d));

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test160"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(1688143320063612998L, 3628800L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test161"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 7053352210170117273L);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test162"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(37.281124735952304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5523396555581458E16d);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test163"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1L, (-100L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test164"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(10.000000000000002d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5440211108893713d));

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test165"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    boolean var4 = var3.isSupportConnected();
    double var6 = var3.cumulativeProbability((-2.8749746418437887d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.3262835274474583E-11d);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test166"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-0.011211302394241729d), (java.lang.Number)(-0.07369898640584448d), false);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test167"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    java.lang.Object var7 = null;
    boolean var8 = var2.equals(var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionFactor((-100.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test168"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.9135626894536033d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test169"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.5683852532105546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7654140519453434d);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test170"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.4407844498728315d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test171"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    var2.setNumElements(100);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var2.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var13.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    double[] var17 = var16.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var13, var16);
    var13.setElement(0, 0.8407359138160451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test172"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(433.6945330979522d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test173"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.013046161355485517d, (java.lang.Number)7081.058387126132d, false);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test174"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.013046161355485517d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test175"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     double var4 = var3.getSupportUpperBound();
//     double var5 = var3.sample();
//     boolean var6 = var3.isSupportConnected();
//     boolean var7 = var3.isSupportConnected();
//     double var9 = var3.cumulativeProbability(0.008884911277691669d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.0040502221845453d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4.4949968685348285E-4d);
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test176"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-7053352210170117172L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7053352210170117172L));

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test177"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.97848141639784d, 0.018584553336844337d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.9784814163978397d);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test178"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     boolean var4 = var3.isSupportConnected();
//     double var5 = var3.sample();
//     double var6 = var3.getNumericalMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.853156418282929d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.8720980175938546d);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test179"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(3.3043872045584766d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 189.32744069823292d);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test180"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(3.1757334232496706d, 0.14022847040561234d, 0.9999999958776927d, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.3341713442711427E-4d);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test181"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(10, (-9));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 90);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test182"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.9973739581060155d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7840834169173322d);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test183"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(100.50001f, 100.50001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.50001f);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test184"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(3628800L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test185"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-89L));
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test186"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(1023.7781831699072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test187"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(273111867, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 273111867);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test188"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(2.011669054126255E-4d, 0.27640092266786565d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.011669054126255E-4d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test189"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.addElement(0.8414709848078965d);
    boolean var10 = var2.equals((java.lang.Object)(byte)100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var2.getElement((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test190"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     boolean var4 = var3.isSupportConnected();
//     double var5 = var3.sample();
//     boolean var6 = var3.isSupportUpperBoundInclusive();
//     double var7 = var3.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.0420504515947533d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.7435938375035028d);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test191"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getSupportLowerBound();
    double var8 = var3.cumulativeProbability(8.639495877295877E-5d);
    double var9 = var3.getNumericalVariance();
    double var11 = var3.cumulativeProbability(0.7377840776591889d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 4.333449949606716E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.006660192447382807d);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test192"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)0, (java.lang.Number)1L, (java.lang.Number)0.6506783754890694d);
    java.lang.Number var4 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.6506783754890694d+ "'", var4.equals(0.6506783754890694d));

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test193"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(2.3341713442711427E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000000272417795d);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test194"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var6 = var2.probability(45.0d);
//     boolean var7 = var2.isSupportConnected();
//     boolean var8 = var2.isSupportUpperBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.5134857372468724d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test195"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(273112767, 273111867);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 273112767);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test196"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setElement((-11700), 8.865319877078154d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test197"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(3.1868873092888728d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test198"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(0.6506783754890694d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.32462331036466185d);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test199"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.013044992572946019d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.8845561638255066d));

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test200"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double var6 = var2.addElementRolling(0.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var9.setExpansionMode(0);
    double[] var12 = var9.getInternalValues();
    var9.clear();
    double var15 = var9.addElementRolling(0.7853981633974483d);
    var9.addElement(0.0d);
    int var18 = var9.getExpansionMode();
    double var20 = var9.substituteMostRecentElement(45.0d);
    double var22 = var9.getElement(0);
    boolean var23 = var2.equals((java.lang.Object)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 45.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test201"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)0, (java.lang.Number)1L, (java.lang.Number)0.6506783754890694d);
    java.lang.Number var4 = var3.getArgument();
    java.lang.Number var5 = var3.getHi();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var3.getContext();
    java.lang.Number var7 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)0+ "'", var4.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.6506783754890694d+ "'", var5.equals(0.6506783754890694d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0.6506783754890694d+ "'", var7.equals(0.6506783754890694d));

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test202"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-2.8749746418437887d));

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test203"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    var2.setElement(10, 0.6506783754890694d);
    var2.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test204"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-1024), 2995200);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2996224));

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test205"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.5575415009635386d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test206"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.6681363173166157d, 0.7377840776591889d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9953549536546394d);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test207"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-1), (-8));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test208"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(3.8146973E-6f, 273112767);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test209"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(2.6530145023882725d, 0.5984386627092083d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.04232224736962027d);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test210"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.013044992572946019d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.014718862937539223d);

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test211"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     double var4 = var3.getSupportUpperBound();
//     double var5 = var3.sample();
//     boolean var6 = var3.isSupportLowerBoundInclusive();
//     double var7 = var3.getStandardDeviation();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.071488278091593d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.8623188722876839d);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test212"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.17453292519943298d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test213"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    int var11 = var2.getExpansionMode();
    double var13 = var2.substituteMostRecentElement(45.0d);
    var2.addElement(0.1919266570807596d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setNumElements((-2996224));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test214"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(1.0920257253823424d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test215"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-100.0f), (java.lang.Number)0.9900135569345746d, true);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test216"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(45.0d, 3.469446951953614E-18d, (-0.356142290695572d), 230400);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test217"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.15719982251077522d, 1.261404880340075d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.15719982251077522d);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test218"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)2.5288560012036268E-5d, (java.lang.Number)0.1048515747957178d, false);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test219"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-1), 100);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test220"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.0d, 0.3581288330251856d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.3581288330251856d);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test221"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(2995200);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test222"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(1.875547735158801d, 0.9995668109270821d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.875547735158801d);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test223"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.27640092266786565d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.004824106156104485d);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test224"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var4 = new org.apache.commons.math3.exception.NullArgumentException(var1, var3);
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test225"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)100.50001f);

  }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test226"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.013046161355485517d, (java.lang.Number)7081.058387126132d, false);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test227"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(50.0f, 1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000001f);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test228"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.0000002f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000002f);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test229"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(byte)100);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    java.lang.Number var4 = var2.getMin();
    boolean var5 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test230"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var5, var7);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var4, var7);
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, var3, var7);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var1, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test231"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.882621046799009d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.05422572066892015d));

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test232"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-0.07369898640584448d), (java.lang.Number)3.0640997968584167d, true);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test233"); }


    double var2 = org.apache.commons.math3.special.Erf.erf((-0.07655602848313875d), 2.9202368677790993d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0861794612026863d);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test234"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-0.15640941223089536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0122569092365554d);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test235"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.5974167300266131d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7729273769421117d);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test236"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.00888514508528015d, 0.8948703487679698d, 0.9255594160121382d, (-13));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test237"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.9998872123077203d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5557770183873325d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test238"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(230400, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 230399);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test239"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-9), 1024);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1015);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test240"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    int var7 = var2.getNumElements();
    var2.setNumElements(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardMostRecentElements((-1024));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test241"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(230399, 900);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test242"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.999566810927082d, (java.lang.Number)(-0.3827413742969658d), (java.lang.Number)1.4214549026638725d);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test243"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(7.560575574229005E-6d, 1.5686873292356027d, 15.05551425958108d, (-18));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test244"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(3.1757334232496706d, 0.022170223590708048d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.175810808968181d);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test245"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.5692474232144973d, 1.0648164703369514d, 0.976508918599899d);
    double var4 = var3.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.5692474232144973d);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test246"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardMostRecentElements((-9));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test247"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(900, (-18));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 918);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test248"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(21.02788165344431d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.4852155806570816E-194d);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test249"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.7435938375035029d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test250"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(1.9634526771778158d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test251"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(4.333449949606716E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.02482883928436441d);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test252"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-1.4222039535789144d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-6.680216650916437d));

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test253"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var2 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)5.889694544886073d, var2, true);
//     org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
//     java.lang.Number var6 = var4.getMax();
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     java.lang.Number var10 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var12 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var8, (java.lang.Number)5.889694544886073d, var10, true);
//     java.lang.Throwable[] var13 = var12.getSuppressed();
//     org.apache.commons.math3.exception.util.Localizable var14 = null;
//     org.apache.commons.math3.exception.util.Localizable var15 = null;
//     org.apache.commons.math3.exception.util.Localizable var16 = null;
//     java.lang.Number var17 = null;
//     org.apache.commons.math3.exception.util.Localizable var18 = null;
//     org.apache.commons.math3.exception.util.Localizable var19 = null;
//     java.lang.Object[] var21 = new java.lang.Object[] { (byte)1};
//     org.apache.commons.math3.exception.NullArgumentException var22 = new org.apache.commons.math3.exception.NullArgumentException(var19, var21);
//     org.apache.commons.math3.exception.MathInternalError var23 = new org.apache.commons.math3.exception.MathInternalError(var18, var21);
//     org.apache.commons.math3.exception.MaxCountExceededException var24 = new org.apache.commons.math3.exception.MaxCountExceededException(var16, var17, var21);
//     org.apache.commons.math3.exception.NullArgumentException var25 = new org.apache.commons.math3.exception.NullArgumentException(var15, var21);
//     org.apache.commons.math3.exception.NullArgumentException var26 = new org.apache.commons.math3.exception.NullArgumentException(var14, var21);
//     var12.addSuppressed((java.lang.Throwable)var26);
//     java.lang.Object[] var28 = new java.lang.Object[] { var12};
//     org.apache.commons.math3.exception.MathIllegalStateException var29 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var7, var28);
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test254"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.30412140489554756d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.31405481363425186d);

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test255"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(45.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test256"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-109L), 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-109L));

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test257"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    var3.reseedRandomGenerator(0L);
    double var9 = var3.cumulativeProbability(0.8170655554314067d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.00858267380786032d);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test258"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.14022847040561234d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.15053663240231746d);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test259"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var2.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var9 = new double[] { 100.0d, 1.0d};
    var6.addElements(var9);
    var6.setNumElements(1);
    int var13 = var6.getExpansionMode();
    double var15 = var6.getElement(0);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setElement((-18), (-4.222640875446916d));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 100.0d);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test260"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    var2.contract();
    var2.setExpansionMode(0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    float var13 = var12.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.discardFrontElements(918);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0f);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test261"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)4.333449949606716E-4d, (java.lang.Number)(-1.4222039535789144d), true);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test262"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(1.5688379597558102d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.09894964678763474d);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test263"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    boolean var6 = var3.isSupportConnected();
    boolean var7 = var3.isSupportLowerBoundInclusive();
    double var8 = var3.getMean();
    double var9 = var3.getSupportLowerBound();
    double var11 = var3.probability(0.0d);
    double var14 = var3.cumulativeProbability(0.05096774828087159d, 67.07376554895923d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.9994652256775848d);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test264"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, 0.013707783890401887d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.9E-324d);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test265"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-0.07369898640584448d), 2.8720980175938546d, (-2.74137897748935d));

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test266"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-0.18834749242221216d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5732181689620152d));

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test267"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(125.3172711493569d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test268"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-18), 1024);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9216);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test269"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1024.0f), (java.lang.Number)0.8085085755675573d, false);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test270"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(3.1757334232496706d, 4.333449949606716E-4d, 0.19240232444172617d);
    double var5 = var3.probability(2.461644881538276d);
    double[] var7 = var3.sample(91);
    double var8 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3.1757334232496706d);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test271"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1024, (-90L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test272"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     double var4 = var2.sample();
//     double var6 = var2.probability(57.295779276891516d);
//     double var8 = var2.density(0.017453292447995462d);
//     double var10 = var2.density(0.976508918599899d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var2.cumulativeProbability(0.00888514508528015d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.3572989575984433d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-2.3710017435132085d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.19207034841124335d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.17940889770647472d);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test273"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-0.07369898640584448d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.41926361214787744d));

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test274"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-0.07248713056628153d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.07242366803704509d));

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test275"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     double var4 = var3.getSupportUpperBound();
//     double var5 = var3.getStandardDeviation();
//     boolean var6 = var3.isSupportConnected();
//     boolean var7 = var3.isSupportUpperBoundInclusive();
//     double var8 = var3.sample();
//     double var10 = var3.cumulativeProbability((-2.369654581753662d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.8623188722876839d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.711133530704986d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6.059140411629471E-10d);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test276"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)2.97848141639784d);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test277"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("org.apache.commons.math3.exception.OutOfRangeException: 273,111,867 out of [0.775, 100] range");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test278"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.5686873292356027d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.252472486418605d);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test279"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var5 = new org.apache.commons.math3.exception.NullArgumentException(var2, var4);
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.lang.Object[] var11 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var9, var11);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var8, var11);
    var5.addSuppressed((java.lang.Throwable)var13);
    java.lang.Throwable[] var15 = var5.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var16 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var15);
    org.apache.commons.math3.exception.MathInternalError var17 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test280"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-11700), (-8));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test281"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(1, (-2996224));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test282"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(2.3341713442711427E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32.936098519779875d);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test283"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(1.2846447019565141d, 0.6499628652950262d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4397096014569957d);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test284"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.8125360099710831d);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test285"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.9999999958776927d, 0.32462331036466185d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999958776927d);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test286"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(3628800L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3628800L);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test287"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var9 = var8.getNumElements();
    double[] var10 = var8.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var8);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var12);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test288"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(5.551115123125783E-17d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.551115123125783E-17d);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test289"); }


    java.math.BigInteger var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, (-90L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test290"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.2822567699732101d, 1.2825498340254313d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.28225676997321014d);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test291"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-18), 230400);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 230382);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test292"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(900, 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test293"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getSupportUpperBound();
    boolean var8 = var3.isSupportUpperBoundInclusive();
    double var9 = var3.getMean();
    double var10 = var3.getSupportLowerBound();
    double var11 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == Double.POSITIVE_INFINITY);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test294"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(230382, 230382);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test295"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    var2.setNumElements(100);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var2.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var13.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.discardMostRecentElements((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test296"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.5984386627092083d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test297"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var2.getNanStrategy();
//     org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//     var10.setExpansionMode(0);
//     double[] var13 = var10.getInternalValues();
//     double[] var14 = var10.getInternalValues();
//     org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
//     double[] var16 = var2.rank(var14);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test298"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.24191996538778948d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2467526067237062d);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test299"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.7853981633974483d, 0.027274760086014354d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7853981633974483d);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test300"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    var3.reseedRandomGenerator(0L);
    boolean var8 = var3.isSupportLowerBoundInclusive();
    double var10 = var3.cumulativeProbability(2.2683541557421067d);
    double var12 = var3.density(0.5683852532105546d);
    boolean var13 = var3.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.24191996538778948d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.013044992572946019d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test301"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(1.271554272071574d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0609874103075077d);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test302"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.05349598516132738d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 350.95295412280007d);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test303"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-5365208890106504175L), 1688143320063612998L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7053352210170117173L));

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test304"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.6449340767586613d, (-0.9999934230547683d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test305"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
//     java.lang.Throwable[] var5 = var4.getSuppressed();
//     java.lang.Throwable[] var6 = var4.getSuppressed();
//     java.lang.Number var7 = var4.getMax();
//     org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test306"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.004824106156104485d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.004824124867400347d);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test307"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.4743594998530665d, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7371797499265332d);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test308"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)1.2825498340254313d, (java.lang.Number)1.0136684045930817d);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test309"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(2.711133530704986d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 155.33650900579727d);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test310"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-7053352210170117172L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7053352210170117172L);

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test311"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//     int var3 = var2.getNumElements();
//     int var4 = var2.start();
//     double var6 = var2.addElementRolling(0.8414709848078965d);
//     org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
//     int var8 = var7.getExpansionMode();
//     int var9 = var7.getNumElements();
//     org.apache.commons.math3.distribution.NormalDistribution var13 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     boolean var14 = var13.isSupportUpperBoundInclusive();
//     boolean var15 = var7.equals((java.lang.Object)var13);
//     double[] var16 = null;
//     var7.addElements(var16);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test312"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setContractionCriteria(1.0000002f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test313"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     double var5 = var3.probability(7.569397550458789d);
//     double var6 = var3.getNumericalVariance();
//     double var7 = var3.getNumericalMean();
//     double var8 = var3.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7435938375035028d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.8720980175938546d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.2239078017965097d);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test314"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(100, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test315"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.contract();
    int var7 = var2.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionFactor(102912.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test316"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getNumericalVariance();
    double var7 = var3.getNumericalMean();
    double var8 = var3.getNumericalMean();
    double var9 = var3.getNumericalVariance();
    boolean var10 = var3.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test317"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-1.8845561638255066d), var1, (java.lang.Number)90L);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test318"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(273111867);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

//  public void test319() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest13.test319"); }
//
//
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(273111867, 3.8146973E-6f);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//
//  }
//
  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test320"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(1.2642564124929525d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11.206667166178734d);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test321"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-0.5732181689620152d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test322"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1, (java.lang.Number)(short)1, (java.lang.Number)0.0d);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    java.lang.Number var6 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)1+ "'", var6.equals((short)1));

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test323"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.102254256986782d));

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test324"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = var2.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test325"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var3, var5);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var2, var5);
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)1.1287147879181489E-5d, var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test326"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)7.569397550458789d);
    java.lang.Throwable[] var3 = var2.getSuppressed();
    java.lang.Number var4 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test327"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(7053352210170117173L, (-7053352210170117173L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test328"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var6, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var2, var8);
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var1, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test329"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(5365208890106504284L, 5365208890106504175L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test330"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-7053352210170117161L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7053352210170117161L);

  }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test331"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, 0.4404105453251124d, 0.7790199122525784d, 91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test332"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(230382, (-13));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test333"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.9895469697130671d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.6900155377520427d);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test334"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    var3.reseedRandomGenerator(0L);
    boolean var8 = var3.isSupportLowerBoundInclusive();
    double var9 = var3.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test335"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.9997833820018625d, 0.9150123793192297d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9998017900254869d);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test336"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(5.99074437799629E40d, 2.6287023951487374d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.6287023951487374d);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test337"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.4596347826973801d, (java.lang.Number)1.6449340767586613d, false);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var10 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var8, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var7, var10);
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var4, var10);
    var3.addSuppressed((java.lang.Throwable)var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test338"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var8 = var7.getExpansionMode();
    int var9 = var7.getNumElements();
    org.apache.commons.math3.distribution.NormalDistribution var13 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    boolean var14 = var13.isSupportUpperBoundInclusive();
    boolean var15 = var7.equals((java.lang.Object)var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setContractionCriteria((-100.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test339"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-2996224), (-100.0f), 1.0000001f, 230399);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test340"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(0L, (-7053352210166488372L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7053352210166488372L);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test341"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(273111867, 1024);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 13813.387644810302d);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test342"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.9997833820018625d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.542826101286539d);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test343"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10L);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test344"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(6.059140411629471E-10d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test345"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(0, (-1.0f), 1.0000002f, 900);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test346"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(90L, (-8));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test347"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(2.302585092994046d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.113407146813537d));

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test348"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-1), 100.5f, 50.0f, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test349"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     double var4 = var3.getSupportUpperBound();
//     double var5 = var3.sample();
//     boolean var6 = var3.isSupportLowerBoundInclusive();
//     double var7 = var3.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.775826473201856d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.7435938375035028d);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test350"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var2 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var5, var7);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var4, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var7);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test351"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.0000002f, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0000005f);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test352"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test353"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs((-0.3497344566073914d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3497344566073914d);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test354"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(7053352210166488372L, (-7053352210166488372L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7053352210166488372L);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test355"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-2996224), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2996224));

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test356"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1.5574077105338615d);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test357"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(230382, 1015);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1015);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test358"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(1.1555386051171055d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.857430970394393d);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test359"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("org.apache.commons.math3.exception.NumberIsTooLargeException: -1 is larger than the maximum (0)");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test360"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(67.07376554895923d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8265526884970353d);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test361"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0L, (-7053352210170117162L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test362"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-7053352210170117173L), 90L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7053352210170117083L));

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test363"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-7053352210170117173L), 7053352210170117173L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7053352210170117173L);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test364"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.05349598516132738d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.053470501981572265d);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test365"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)10L, var2);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test366"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(900, (-7053352210170117173L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test367"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(100L, 1688143320063612998L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test368"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-1), (-1024));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1024));

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test369"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(7053352210170117173L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7053352210170117173L);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test370"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-18), 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-18));

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test371"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-18), 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-790794752));

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test372"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    double var6 = var3.getMean();
    double var7 = var3.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.NEGATIVE_INFINITY);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test373"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    boolean var4 = var3.isSupportUpperBoundInclusive();
    double var5 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.POSITIVE_INFINITY);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test374"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.05094568456366692d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test375"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.0000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000004f);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test376"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(2995200, (-13));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-38937600));

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test377"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.6136426314409833d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test378"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(7053352210170117173L, (-90L));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test379"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1, (-11700));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 11700);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test380"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-0.0012207031f), 230399);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.NEGATIVE_INFINITY);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test381"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.7756486815267315d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test382"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.8085085755675573d, 2.3341713442711427E-4d);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test383"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var8.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var11 = var8.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test384"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.05094568456366692d, 1015);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.7887638162297866E304d);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test385"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(900, 273111867);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 900);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test386"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(32.936098519779875d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.187485916486629d);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test387"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-7053352210170117172L), 7053352210170117173L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test388"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 230399);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test389"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.252472486418605d, 3.775826473201856d, 0.00744881699401668d, 11700);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.03741371052586975d);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test390"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(short)10);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test391"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-1024), 900);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test392"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-100L), (-7053352210170117162L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7053352210170117162L));

  }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test393"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     double var4 = var3.getSupportUpperBound();
//     double var5 = var3.getStandardDeviation();
//     double var6 = var3.sample();
//     double var7 = var3.getNumericalMean();
//     double[] var9 = var3.sample(10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.8623188722876839d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.4202087772646754d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.8720980175938546d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test394"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.0000002f, (-0.43403492507390196d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000001f);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test395"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.9994652256775848d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test396"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(125.3172711493569d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0980109293178746d);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test397"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.017453292447995462d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.017302733052967395d);

  }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test398"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh((-2.8749746418437887d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test399"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)7081.058387126132d, (java.lang.Number)2.8720980175938546d, true);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var11 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var7, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
    java.lang.Throwable[] var12 = var11.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var6, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test400"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.7756486815267315d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.316202817425833d);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test401"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getSupportUpperBound();
    boolean var8 = var3.isSupportUpperBoundInclusive();
    boolean var9 = var3.isSupportConnected();
    var3.reseedRandomGenerator(89L);
    var3.reseedRandomGenerator(7053352210166488372L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test402"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    int var11 = var2.getExpansionMode();
    double var13 = var2.substituteMostRecentElement(45.0d);
    double var15 = var2.getElement(0);
    double var17 = var2.substituteMostRecentElement((-1.4222039535789144d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 45.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 45.0d);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test403"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getNumericalVariance();
    double var7 = var3.getNumericalMean();
    var3.reseedRandomGenerator(10L);
    double var10 = var3.getSupportUpperBound();
    double var11 = var3.getMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var3.inverseCumulativeProbability(24.73278948466765d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.8720980175938546d);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test404"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    int var9 = var2.getExpansionMode();
    double var11 = var2.getElement(0);
    int var12 = var2.getNumElements();
    var2.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var17 = var16.getNumElements();
    int var18 = var16.start();
    double var20 = var16.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
    int var22 = var21.getExpansionMode();
    boolean var23 = var2.equals((java.lang.Object)var21);
    int var24 = var2.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test405"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var3 = new org.apache.commons.math3.exception.NullArgumentException(var0, var2);
    org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var7, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, var9);
    var3.addSuppressed((java.lang.Throwable)var11);
    java.lang.Throwable[] var13 = var3.getSuppressed();
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    java.lang.Number var17 = null;
    org.apache.commons.math3.exception.OutOfRangeException var18 = new org.apache.commons.math3.exception.OutOfRangeException(var14, (java.lang.Number)0, (java.lang.Number)5.551115123125783E-17d, var17);
    java.lang.Number var19 = var18.getLo();
    java.lang.Number var20 = var18.getArgument();
    var3.addSuppressed((java.lang.Throwable)var18);
    java.lang.Number var22 = var18.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + 5.551115123125783E-17d+ "'", var19.equals(5.551115123125783E-17d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + 0+ "'", var20.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test406"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.00390625f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test407"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.2822567699732101d, 12.80182748008147d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 12.80493872355369d);

  }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test408"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-0.9999663392570808d), 0.004824124867400347d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test409"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    int var9 = var2.getExpansionMode();
    double var11 = var2.getElement(0);
    int var12 = var2.getNumElements();
    var2.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var17 = var16.getNumElements();
    int var18 = var16.start();
    double var20 = var16.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
    int var22 = var21.getExpansionMode();
    boolean var23 = var2.equals((java.lang.Object)var21);
    var21.setElement(230399, 0.7135399484934067d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test410"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.5683852532105546d, 3.0698672482364424d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5683852532105547d);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test411"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0L, 5365208890106504284L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5365208890106504284L);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test412"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.019286515134173187d), 0.008884911277691669d);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test413"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(4.283475365339624d, (-0.04527916949109096d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.2837146740488246d);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test414"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(2.234177428856803d, 0.8938555297316175d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0514491238515675d);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test415"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    var2.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setContractionCriteria(2.0000005f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test416"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(7053352210170117172L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7053352210170117172L);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test417"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-18), 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test418"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(6.42838750810497E-25d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-55.70390359439574d));

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test419"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.8206943562278073d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7316193579789825d);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test420"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-13), 49.999992f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test421"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.7840834169173322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9012179477612883d);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test422"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var6, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
    java.lang.Throwable[] var11 = var10.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathIllegalArgumentException var14 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, (java.lang.Object[])var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test423"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-0.019286515134173187d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9998140209319779d);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test424"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardMostRecentElements(273111867);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test425"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.9150123793192297d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4968061604740894d);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test426"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-11700));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11700);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test427"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, (-10.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test428"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(2.6530145023882725d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.440892098500626E-16d);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test429"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.02755458954302434d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.16599575158125085d);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test430"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(3.1757334232496706d, 4.333449949606716E-4d, 0.19240232444172617d);
    double var5 = var3.probability(2.461644881538276d);
    double[] var7 = var3.sample(91);
    double var9 = var3.probability((-1.4308317753439705d));
    double[] var11 = var3.sample(230399);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test431"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test432"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(2.0000005f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0000005f);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test433"); }


    float var2 = org.apache.commons.math3.util.FastMath.max((-1023.99994f), 0.00390625f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.00390625f);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test434"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(3628800L, 90L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3628800L);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test435"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(0, 900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 900);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test436"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.3707647883932746d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test437"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(7.560575574229005E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000075606041554d);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test438"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.02217385702297738d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.28094010967218624d);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test439"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-0.04527916949109096d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0d));

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test440"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-6.680216650916437d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9987444940634167d));

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test441"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.24191996538778948d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.24434410597703024d);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test442"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 7053352210170117172L);
// 
//   }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test443"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
//     org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//     double[] var10 = new double[] { 100.0d, 1.0d};
//     var7.addElements(var10);
//     double[] var12 = var2.rank(var10);
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test444"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(100, 100.0f, 1.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test445"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(2995200, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1127.5111283084475d);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test446"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test447"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.0d, 0.9995668109270821d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8425208950104276d);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test448"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    double[] var8 = var7.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    double var11 = var9.substituteMostRecentElement((-4.222640875446916d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test449"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(9216);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9216);

  }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test450"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma((-1.2927045528110097d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test451"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(273112767);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test452"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)4.333449949606716E-4d, (java.lang.Number)(-1.4222039535789144d), true);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1.4222039535789144d)+ "'", var5.equals((-1.4222039535789144d)));

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test453"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(24.73278948466765d, 0.976508918599899d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.007409736020362853d));

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test454"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.8407359138160451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.318072250632669d);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test455"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-11700), 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-11800));

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test456"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(1688143320063612998L, 89L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test457"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.006601438076270229d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9925511830059833d);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test458"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getNumericalVariance();
    double var7 = var3.getNumericalMean();
    double var8 = var3.getMean();
    double[] var10 = var3.sample(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var12 = var3.sample((-790794752));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test459"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.2544789518188435d, (java.lang.Number)0.9168407258198261d, true);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    boolean var5 = var3.getBoundIsAllowed();
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test460"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-2.369654581753662d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.0d));

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test461"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.45830303092382607d, 0.013707783890401887d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.458303030923826d);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test462"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getNumericalVariance();
    double var7 = var3.getNumericalMean();
    double var8 = var3.getStandardDeviation();
    double var9 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.POSITIVE_INFINITY);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test463"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)3.432443690009129E42d);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test464"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.2825498340254313d, (java.lang.Number)0.8623188722876839d, (java.lang.Number)0.006660192447382807d);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test465"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.4966969119672996d, (-1.0648164703369514d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1749646538763177d);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test466"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.8085085755675573d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6905778852975565d);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test467"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.5575415009635386d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8230490790621229d);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test468"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.0d, 1.5692474232144973d, 2.97848141639784d);
    double var5 = var3.cumulativeProbability(1.5044728995807433d);
    var3.reseedRandomGenerator(7053352210170117273L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.626074551533144d);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test469"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double[] var7 = var2.getElements();
    int var8 = var2.start();
    var2.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test470"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.999566810927082d, 1.1555386051171055d, 4.333449949606716E-4d, (-13));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test471"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.9255594160121382d, (java.lang.Number)0.8085085755675573d, false);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test472"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.9302363507574447d, 1.1581263863353843d, 0.010927062287200275d, 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2879144371105764d);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test473"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(1015, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.0590220060195755E23d);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test474"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.15053663240231746d, 12.80493872355369d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 12.805823557727937d);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test475"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.12929424722150962d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1380249355799548d);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test476"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-1024.0f), 49.999992f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024.0f);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test477"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(90L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test478"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(3.5875012564434425d, 1.4214549026638725d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.8588468880340976d);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test479"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.15719982251077522d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.15591759939935756d);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test480"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(1.261404880340075d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test481"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-1.7952220558689955d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.215363133481191d));

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test482"); }


    float var2 = org.apache.commons.math3.util.FastMath.max((-1.0f), 100.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.5f);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test483"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-0.7108770633520998d), (-0.3497344566073914d), 1.3262835274474583E-11d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest13.test484"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow((-0.07655602848313875d), 0.45830303092382607d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test485"); }


    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(100, 50.0f, 50.0f, 1);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var10 = new double[] { 100.0d, 1.0d};
    var7.addElements(var10);
    var7.setNumElements(1);
    var7.contract();
    var7.setExpansionMode(0);
    var7.contract();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var7);
    var7.setElement(900, 0.7377840776591889d);
    int var22 = var7.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test486"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.9921075120451343d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5902737038068222d));

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test487"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(2.6530145023882725d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.264555748619563d);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test488"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(9L, (-7053352210170117172L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test489"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    java.lang.Object var7 = null;
    boolean var8 = var2.equals(var7);
    double[] var9 = var2.getElements();
    org.apache.commons.math3.distribution.NormalDistribution var13 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var15 = var13.probability(7.569397550458789d);
    double[] var17 = var13.sample(100);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var18);
    var2.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test490"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(1.2619699923279821d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9077345831441337d);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test491"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.2544789518188435d, (java.lang.Number)0.9168407258198261d, true);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    boolean var6 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test492"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1.1287147879181489E-5d);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test493"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var6 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var4, (java.lang.Number)(byte)100);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    java.lang.Object[] var8 = new java.lang.Object[] { var6};
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var3, var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var8);
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.31689424315458475d, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test494"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var5 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)(short)100, var3, (java.lang.Number)(-0.07369898640584448d));
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test495"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1.6449340767586613d);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test496"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(0, 230399);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test497"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(1.0000000272417795d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test498"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.00824820856234747d, 1.5574077105338615d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9992336791296752d);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test499"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, 50.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest13.test500"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(7053352210170117273L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

}
