
import junit.framework.*;

public class RandoopTest9 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test1"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-3.367280973669702d), 1.151525743674435d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.367280973669702d);

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test2"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextBeta(0.14381144578732213d, 0.35102546408704066d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12.254368927331646d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "4958dc3fd3"+ "'", var8.equals("4958dc3fd3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 5.9905031793799945E-6d);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test3"); }


    java.math.BigInteger var1 = null;
    java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    java.math.BigInteger var4 = null;
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0L);
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, var6);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 201600L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 1980);
    org.apache.commons.math3.exception.NumberIsTooLargeException var13 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.17009363656516285d, (java.lang.Number)var11, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test4"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     var0.reSeedSecure();
//     double var10 = var0.nextGamma(0.9870467554527248d, 3.1173466159040992d);
//     int var13 = var0.nextZipf(1880, 6.54642801564943d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10.909143060110047d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 12.24584295887153d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
// 
//   }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test5"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.contract();
    int var8 = var6.getExpansionMode();
    var6.setElement(5, 20.696514663540924d);
    int var12 = var6.getExpansionMode();
    double[] var13 = var6.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setExpansionFactor(1.4E-45f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test6"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     int var11 = var0.nextZipf(5, 0.8273572477024794d);
//     int var14 = var0.nextBinomial(1972, 0.15795521463156686d);
//     var0.reSeed();
//     var0.reSeedSecure(0L);
//     var0.reSeedSecure();
//     var0.reSeedSecure((-21428512432588800L));
//     int var23 = var0.nextInt(80, 3483820);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.4814972122487378d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "da62e153cbce3524b01b6c82a648c9dcf024eed85173727553b6c25077aa223cfc23f36e7e3b400a2c26b5d8f7bad4bfc264"+ "'", var8.equals("da62e153cbce3524b01b6c82a648c9dcf024eed85173727553b6c25077aa223cfc23f36e7e3b400a2c26b5d8f7bad4bfc264"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 298);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 2108578);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test7"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1894, (-1.0f), 10.000001f, 1625);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test8"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.6505375708978487d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test9"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.5658474030075499d, 14.031149057314524d);
//     long var7 = var1.nextSecureLong((-16L), 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 6.782718095330396d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-14L));
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test10"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(1342156216L, 5L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test11"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double[] var6 = var0.sample(100);
//     double var7 = var0.sample();
//     double var8 = var0.sample();
//     var0.reseedRandomGenerator(10L);
//     boolean var11 = var0.isSupportLowerBoundInclusive();
//     double var12 = var0.getMean();
//     double var14 = var0.inverseCumulativeProbability(2.4806185630527824E-155d);
//     boolean var15 = var0.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.5507026725851218d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.2702772223189203d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-1.0038989723989089E77d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
// 
//   }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test12"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     var0.reSeed();
//     double var15 = var0.nextChiSquare(7.617953921806563d);
//     double var17 = var0.nextExponential(1.5574077246549007d);
//     org.apache.commons.math3.distribution.NormalDistribution var21 = new org.apache.commons.math3.distribution.NormalDistribution(0.8259324122591327d, 0.2782029380240531d, 0.0d);
//     double var22 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var21);
//     double var24 = var0.nextT(0.2160727732320313d);
//     double var27 = var0.nextGamma(18.827809487697202d, 15.2715815643462d);
//     int var30 = var0.nextZipf(751, 0.849872022320529d);
//     var0.reSeed(2120L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.1299948832297446d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d567a82471"+ "'", var8.equals("d567a82471"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 8.440558850928293d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 5.0102877407598525d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.5917840179288886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-0.0171708791073058d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 315.2723610714864d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 13);
// 
//   }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test13"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-1.9158706753182937d), 0.7139447943156824d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test14"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(3.4456677746279425d, (-0.7196442616799688d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.5200162324168884d);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test15"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    boolean var7 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator((-16L));
    double var11 = var0.cumulativeProbability(0.0d);
    boolean var12 = var0.isSupportLowerBoundInclusive();
    double var14 = var0.probability(7.724435900937391d);
    double var16 = var0.probability(1.1968914007497313d);
    double var18 = var0.density((-0.25427675857172194d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.3862513837781128d);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test16"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.0403360105039516d, 0.09554782997590798d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9186308647505389d);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test17"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc((-1.6937792675979062d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9833962003677834d);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test18"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.0494464950714408d, 0.7840974525462412d, 0.2056151686980249d);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test19"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.9999998f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test20"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.6138560218807408d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8475418427286887d);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test21"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.5950413774252329d);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test22"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 260.5649409718632d);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test23"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(1544L, (-1151L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test24"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(791);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test25"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     double var9 = var0.nextF(2.281783181607902d, 0.8427007929497151d);
//     long var12 = var0.nextLong(4L, 100L);
//     double var14 = var0.nextExponential(1.5574077246549007d);
//     int var17 = var0.nextInt(0, 882);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.2539339411976553d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 68.27594762562589d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 21L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.5291581709584627d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 52);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test26"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(1.2821293047459659E-78d, 1.5430806348152348d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2821293047459659E-78d);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test27"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.3533554734503997d, 16.143912296931635d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16.143912296931635d);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test28"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.9708257025166332d);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test29"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.09943289076401282d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.3082723270545062d));

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test30"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 201600L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 2019);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 67L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test31"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.9170148503640131d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test32"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     double var31 = var0.nextCauchy(7.0d, 3.243310970166501d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var33 = var0.nextPoisson((-0.2889949763416441d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.9181539233736915d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "fb6ab379d2"+ "'", var8.equals("fb6ab379d2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1917);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.02208436675969583d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.565743057611285d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.962037317415989d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.11412790507015594d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-0.03690874013431603d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 6.655736324013254E-48d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 4.589874040809319d);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test33"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    var4.clear();
    var4.contract();
    int var10 = var4.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test34"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)4.876708896375146d, var2, true);
    boolean var5 = var4.getBoundIsAllowed();
    boolean var6 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test35"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var0.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
//     java.lang.String var6 = var4.toString();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var10 = var7.nextSecureLong((-1L), 1L);
//     double var13 = var7.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var15 = var7.nextSecureHexString(100);
//     long var18 = var7.nextSecureLong((-2L), 0L);
//     boolean var19 = var4.equals((java.lang.Object)0L);
//     java.lang.String var20 = var4.name();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var23 = var21.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var25 = var24.getTiesStrategy();
//     java.lang.Class var26 = var25.getDeclaringClass();
//     int var27 = var25.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23, var25);
//     org.apache.commons.math3.random.RandomGenerator var29 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23, var29);
//     org.apache.commons.math3.random.RandomGenerator var31 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23, var31);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var35 = var34.getTiesStrategy();
//     java.lang.Class var36 = var35.getDeclaringClass();
//     java.lang.Class var37 = var35.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var38 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23, var35);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var39 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "MAXIMAL"+ "'", var6.equals("MAXIMAL"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 17.68208349544003d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "028a653711b613bbbec415d049b220a557f5ea13a9c99893f764b69ae287e8504a605782bfb3de86b862cc7c7b7e32c947ae"+ "'", var15.equals("028a653711b613bbbec415d049b220a557f5ea13a9c99893f764b69ae287e8504a605782bfb3de86b862cc7c7b7e32c947ae"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "MAXIMAL"+ "'", var20.equals("MAXIMAL"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test36"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-933400799), 8336);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test37"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1919, 100.00001f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var2.addElement(0.8261560512869992d);
    var2.setExpansionFactor(100.00001f);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test38"); }


    long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5040L);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test39"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(3.9381412579836104d, 2.1424092671303407d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.17854829383606408d);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test40"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var6 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException(var4, (java.lang.Number)(-1), (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)1.4128411121633297d, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test41"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.011012866100247d, 4.879522481508616d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.20430420029235355d);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test42"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 201600L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 64L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test43"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.001908508257396575d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32.8629149120096d);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test44"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     double var16 = var0.nextGaussian(0.9999494957997512d, 25.472636453138065d);
//     double var19 = var0.nextWeibull(18.0d, 25.472636453138065d);
//     int var23 = var0.nextHypergeometric(9194402, 1932, 10775);
//     double var26 = var0.nextWeibull(3.2418781084293336E-115d, 0.7429416278213549d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.231510093681979d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "0440217b3f"+ "'", var8.equals("0440217b3f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1903);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.001973296196054164d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 17.18697259560036d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 24.80702125728093d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.0d);
// 
//   }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test45"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.2156721739560978E-106d, (java.lang.Number)0.14431182850092306d, true);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test46"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)Double.NaN, var2, false);
    java.lang.Number var5 = var4.getMax();
    java.lang.Number var6 = var4.getMax();
    java.lang.Number var7 = var4.getMax();
    boolean var8 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test47"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, 445346L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test48"); }


    double[] var3 = new double[] { 0.0d, (-1.0d), 0.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.getNumElements();
    int var6 = var4.getNumElements();
    var4.contract();
    var4.setElement(0, 2.19655331989498d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test49"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-1.1981027661961499d), 0.5805536752331785d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5805536752331785d);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test50"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var4 = var0.getMean();
    var0.reseedRandomGenerator((-2L));
    double var7 = var0.getSupportUpperBound();
    double var8 = var0.getSupportLowerBound();
    double var9 = var0.getMean();
    double var11 = var0.probability(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test51"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = null;
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var8);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 336L);
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    java.math.BigInteger var15 = null;
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 0L);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, var17);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 11L);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.math.BigInteger var24 = null;
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 0L);
    java.math.BigInteger var27 = null;
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var27, 0L);
    java.math.BigInteger var30 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, var29);
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 6L);
    org.apache.commons.math3.exception.OutOfRangeException var33 = new org.apache.commons.math3.exception.OutOfRangeException(var21, (java.lang.Number)5.363952139253263d, (java.lang.Number)14.087081017797523d, (java.lang.Number)var32);
    java.math.BigInteger var34 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, var32);
    java.math.BigInteger var35 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, var34);
    org.apache.commons.math3.exception.NumberIsTooLargeException var37 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var1, (java.lang.Number)21428512432590984L, (java.lang.Number)var35, true);
    org.apache.commons.math3.exception.NumberIsTooSmallException var40 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)var35, (java.lang.Number)11401, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test52"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(59867617, 1891);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test53"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(6.409807892850133d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8068450135554232d);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test54"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(1.3719317734535352d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0538549837673954d);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test55"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.6245519507192409d, 1.1833077938740821d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.48564086005836404d);

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test56"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getSupportUpperBound();
//     double[] var3 = var0.sample(10);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     double var6 = var4.addElementRolling(0.15264401491200186d);
//     org.apache.commons.math3.util.ResizableDoubleArray var7 = var4.copy();
//     var4.clear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.2579286377283017d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test57"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(2.756744637980549d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.375418273515332d);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test58"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, 9.999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test59"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    boolean var7 = var0.isSupportUpperBoundInclusive();
    double var8 = var0.getStandardDeviation();
    double[] var10 = var0.sample(7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var12 = var0.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test60"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.966538993199365d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.966538993199365d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test61"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("b2f6691a6f");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test62"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var7 = var0.cumulativeProbability(0.0d);
    double var8 = var0.getMean();
    double var10 = var0.cumulativeProbability((-1.737874520729035d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.04111646306255168d);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test63"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.discardMostRecentElements(1);
    var4.clear();
    int var16 = var4.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test64"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextWeibull(7.769493748166378d, 1.2185657441986304d);
//     long var8 = var0.nextPoisson(0.9999999999928669d);
//     double var11 = var0.nextF(0.4683012692236799d, 2.5498468927479463d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var13 = var0.nextHexString((-209507103));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.3049185458007468d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4.2131089229228245d);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test65"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(180L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 180L);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test66"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)2419200L);

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test67"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     var0.reSeed();
//     double var15 = var0.nextChiSquare(7.617953921806563d);
//     double var17 = var0.nextExponential(1.5574077246549007d);
//     org.apache.commons.math3.distribution.NormalDistribution var21 = new org.apache.commons.math3.distribution.NormalDistribution(0.8259324122591327d, 0.2782029380240531d, 0.0d);
//     double var22 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var21);
//     double var24 = var0.nextT(0.2160727732320313d);
//     double var27 = var0.nextGamma(18.827809487697202d, 15.2715815643462d);
//     int var30 = var0.nextZipf(751, 0.849872022320529d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var33 = var0.nextBeta((-0.24441930484563598d), 10.937839899374197d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 13.842499342861633d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "35ec806c10"+ "'", var8.equals("35ec806c10"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 10.168020053992196d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.7804011233967991d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.8699771447708469d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-11.759394518333565d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 193.40415186307226d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 240);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test68"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setExpansionFactor(1.4E-45f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test69"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    boolean var7 = var0.isSupportUpperBoundInclusive();
    double var8 = var0.getStandardDeviation();
    double var9 = var0.getSupportUpperBound();
    double var10 = var0.getSupportLowerBound();
    double var12 = var0.density(0.3363717774100053d);
    double var13 = var0.getNumericalMean();
    boolean var14 = var0.isSupportUpperBoundInclusive();
    double var15 = var0.getSupportLowerBound();
    double[] var17 = var0.sample(305);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.3769994616483318d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test70"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-1.0f), 9.536743E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test71"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    double[] var6 = var4.getInternalValues();
    org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var8 = var7.getStandardDeviation();
    double[] var10 = var7.sample(1);
    double var11 = var7.getMean();
    double[] var13 = var7.sample(100);
    var4.addElements(var13);
    int var15 = var4.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setContractionCriteria(9.536743E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test72"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(0L, 1544L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1544L));

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test73"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 572.9577951308232d);

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test74"); }
// 
// 
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.distribution.NormalDistribution var1 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var2 = var1.getStandardDeviation();
//     boolean var3 = var1.isSupportUpperBoundInclusive();
//     double[] var5 = var1.sample(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var6.reseedRandomGenerator(2L);
//     double[] var10 = var6.sample(100000);
//     double var11 = var0.mannWhitneyUTest(var5, var10);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double[] var14 = var12.sample(1910);
//     org.apache.commons.math3.distribution.NormalDistribution var15 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var16 = var15.getStandardDeviation();
//     double[] var18 = var15.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
//     double[] var20 = var19.getElements();
//     double var21 = var0.mannWhitneyUTest(var14, var20);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.distribution.NormalDistribution var23 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var24 = var23.getStandardDeviation();
//     boolean var25 = var23.isSupportUpperBoundInclusive();
//     double[] var27 = var23.sample(100);
//     org.apache.commons.math3.distribution.NormalDistribution var28 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var28.reseedRandomGenerator(2L);
//     double[] var32 = var28.sample(100000);
//     double var33 = var22.mannWhitneyUTest(var27, var32);
//     org.apache.commons.math3.distribution.NormalDistribution var34 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var35 = var34.getStandardDeviation();
//     double[] var37 = var34.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray(var37);
//     double[] var42 = new double[] { 0.0d, (-1.0d), 0.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var43 = new org.apache.commons.math3.util.ResizableDoubleArray(var42);
//     double var44 = var22.mannWhitneyU(var37, var42);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var45 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var46 = var45.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var47 = var45.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var48 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var49 = var48.getTiesStrategy();
//     java.lang.Class var50 = var49.getDeclaringClass();
//     int var51 = var49.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var52 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var47, var49);
//     org.apache.commons.math3.random.RandomGenerator var53 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var54 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var47, var53);
//     org.apache.commons.math3.random.RandomGenerator var55 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var56 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var47, var55);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var57 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var58 = var57.getTiesStrategy();
//     java.lang.Class var59 = var58.getDeclaringClass();
//     java.lang.String var60 = var58.toString();
//     java.lang.String var61 = var58.toString();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var62 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var47, var58);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var63 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var67 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var68 = new org.apache.commons.math3.util.ResizableDoubleArray(var67);
//     org.apache.commons.math3.distribution.NormalDistribution var69 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var70 = var69.getSupportUpperBound();
//     double[] var72 = var69.sample(10);
//     double var73 = var63.mannWhitneyU(var67, var72);
//     double[] var74 = var62.rank(var67);
//     double var75 = var0.mannWhitneyUTest(var42, var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.053482246108287446d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.6833754963577685d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.5161386605871523d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 2.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var60 + "' != '" + "AVERAGE"+ "'", var60.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var61 + "' != '" + "AVERAGE"+ "'", var61.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 21.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 0.19043026382552408d);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test75"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(2.7150680826102613d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.41370924523691804d);

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test76"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var11 = var9.sample();
//     double var13 = var9.probability(7.444490968701611d);
//     double var14 = var9.getSupportUpperBound();
//     double[] var16 = var9.sample(9694);
//     double[] var18 = var9.sample(1911);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.875622307434833d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f10a788b75"+ "'", var8.equals("f10a788b75"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.11487089984735804d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1.549096676852366d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test77"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(2097152.0f, 0.26630169371107804d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2097151.9f);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test78"); }


    double[] var3 = new double[] { 0.0d, (-1.0d), 0.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    float var6 = var4.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    boolean var9 = var4.equals((java.lang.Object)0.9999997887160175d);
    var4.setNumElements(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test79"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.1629595418829466d, 2.9854328371062793d, 2.265662238504449d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test80"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.35147511930312847d), (java.lang.Number)0.41759531141436157d, (java.lang.Number)0.02550269267928422d);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test81"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.1368684E-13f, (-0.9999999f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.1368684E-13f));

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test82"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, 2.0965853043994893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test83"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(2.8272517061213667d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0393051112252554d);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test84"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma((-0.40925037755477284d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test85"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-0.1555273203891208d), (java.lang.Number)0.15729920705028488d, (java.lang.Number)15.460506451516764d);
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 15.460506451516764d+ "'", var5.equals(15.460506451516764d));

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test86"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.1764703334688625d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-5.985952042211632d));

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test87"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-0.2392738836991271d), 7.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test88"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(3.3113021230333133d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 27.4208075007045d);

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test89"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var5 = var0.cumulativeProbability(0.0d);
//     double var6 = var0.getSupportUpperBound();
//     boolean var7 = var0.isSupportUpperBoundInclusive();
//     double var8 = var0.getStandardDeviation();
//     double var9 = var0.getStandardDeviation();
//     double var10 = var0.getSupportUpperBound();
//     boolean var11 = var0.isSupportUpperBoundInclusive();
//     double var12 = var0.sample();
//     double var13 = var0.getMean();
//     double var15 = var0.cumulativeProbability((-0.0975581339764322d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.7949467086580815d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.4611415850534408d);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test90"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 790.5397402246074d, 17.042216286603484d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test91"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.07636096944268304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.07643520118725046d);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test92"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(1943, 102681409);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test93"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(9891, 2297);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9891);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test94"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 10.0f);
    var2.addElement(0.010050166663333094d);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var2.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var2.getElement(17190);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test95"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.9595680454252316d), 6.057306437399964d, 0.9907609904401303d, 1891);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test96"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)2097152.5f, (java.lang.Number)(-0.6991346750676082d), true);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    java.lang.Throwable[] var5 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test97"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    java.lang.Class var6 = var4.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    java.lang.String var8 = var4.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    int var10 = var2.ordinal();
    java.lang.String var11 = var2.name();
    java.lang.Class var12 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var13.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    java.lang.Class var18 = var17.getDeclaringClass();
    int var19 = var17.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var17);
    org.apache.commons.math3.random.RandomGenerator var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var21);
    org.apache.commons.math3.random.RandomGenerator var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var23);
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var27 = var26.getTiesStrategy();
    java.lang.Class var28 = var27.getDeclaringClass();
    java.lang.Class var29 = var27.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var27);
    java.lang.String var31 = var27.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var32 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "MAXIMAL"+ "'", var11.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "AVERAGE"+ "'", var31.equals("AVERAGE"));

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test98"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(13.359855606410402d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test99"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(0.8109766711360142d);
//     double var6 = var1.nextCauchy((-0.6050333467378823d), 6.694390071933186E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.91301489318588d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.6046634365653298d));
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test100"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(163824380L, 704L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 704L);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test101"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1999, (java.lang.Number)(byte)10, (java.lang.Number)1.1368684E-13f);
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getHi();
    java.lang.Throwable[] var7 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var14 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var10, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var15 = var14.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var9, (java.lang.Object[])var15);
    var8.addSuppressed((java.lang.Throwable)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)10+ "'", var5.equals((byte)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1.1368684E-13f+ "'", var6.equals(1.1368684E-13f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test102"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.010100839201864612d, (java.lang.Number)(-1), (java.lang.Number)14.27900880653991d);
//     java.lang.Number var5 = var4.getHi();
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var10 = new org.apache.commons.math3.exception.OutOfRangeException(var6, (java.lang.Number)9.954021851066004d, (java.lang.Number)(-2), (java.lang.Number)0.9999494957997512d);
//     var4.addSuppressed((java.lang.Throwable)var10);
//     java.lang.String var12 = var10.toString();
// 
//   }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test103"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double[] var6 = var0.sample(100);
//     double var7 = var0.sample();
//     double var8 = var0.sample();
//     var0.reseedRandomGenerator(10L);
//     double var11 = var0.getMean();
//     double var12 = var0.getSupportLowerBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.4492623014948807d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5785016365981144d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == Double.NEGATIVE_INFINITY);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test104"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.017688387388495763d, 9.069283351067833d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.5464626747200704d));

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test105"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)12.773612389148536d);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test106"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     var0.reSeedSecure(437L);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var0.nextSample(var9, 882);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test107"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)14.0d);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test108"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var13.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    java.lang.Class var18 = var17.getDeclaringClass();
    int var19 = var17.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var20.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var23 = var22.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = var22.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var25 = var22.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var26 = var22.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var28 = var27.getTiesStrategy();
    boolean var30 = var28.equals((java.lang.Object)Double.POSITIVE_INFINITY);
    boolean var32 = var28.equals((java.lang.Object)(-0.4255538433808183d));
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var33 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var26, var28);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var34 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var21, var28);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var35 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var28);
    java.lang.String var36 = var28.toString();
    java.lang.String var37 = var28.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + "AVERAGE"+ "'", var36.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "AVERAGE"+ "'", var37.equals("AVERAGE"));

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test109"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-1.0f), 1073741698);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.NEGATIVE_INFINITY);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test110"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)7.825421147865245d, (java.lang.Number)6.477865207019324d, false);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test111"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var9);
    boolean var12 = var8.equals((java.lang.Object)0.00333969801975283d);
    java.lang.String var13 = var8.name();
    java.lang.String var14 = var8.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var17 = var15.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var19 = var18.getTiesStrategy();
    java.lang.Class var20 = var19.getDeclaringClass();
    int var21 = var19.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var19);
    org.apache.commons.math3.random.RandomGenerator var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var23);
    org.apache.commons.math3.random.RandomGenerator var25 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var25);
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var29 = var28.getTiesStrategy();
    java.lang.Class var30 = var29.getDeclaringClass();
    java.lang.Class var31 = var29.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var29);
    boolean var34 = var29.equals((java.lang.Object)12185.029950707303d);
    java.lang.String var35 = var29.name();
    int var36 = var29.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "MAXIMAL"+ "'", var13.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "MAXIMAL"+ "'", var14.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "AVERAGE"+ "'", var35.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 3);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test112"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(2419200L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test113"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.19488214288778757d, 1.6601269939065664d, 2.2328594647609696E16d, 10403);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.01946449922149521d);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test114"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1189);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1189);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test115"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh((-2.2635760879410207E20d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test116"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.setContractionCriteria(2.5f);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    float var16 = var4.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setExpansionMode(192);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.0f);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test117"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(1832, 1570);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2876240);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test118"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, (-1.803747060838157d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test119"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)6.621888603197341d);
    var0.addSuppressed((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.4849465655472502d);
    var0.addSuppressed((java.lang.Throwable)var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test120"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var1.contract();
    int var3 = var1.start();
    float var4 = var1.getContractionCriteria();
    var1.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var1.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var6.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test121"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0f));
    java.lang.Number var2 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + (-1.0f)+ "'", var2.equals((-1.0f)));

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test122"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-64L), 1440L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-92160L));

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test123"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(180, 48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 720);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test124"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var13 = var0.nextF(0.6351254179184792d, 1.0919228035719635d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextZipf((-8834), (-0.2888695411772784d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.278617721410951d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5f1d20a777"+ "'", var8.equals("5f1d20a777"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.8356287763849521d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 127.88130391551145d);
// 
//   }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test125"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextWeibull(7.769493748166378d, 1.2185657441986304d);
//     int var9 = var0.nextPascal(1980, 0.0d);
//     double var12 = var0.nextCauchy(0.07721018280235958d, 0.13234633557495218d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextInt(17946, (-127));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.2876230479362896d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.9662161970818984d);
// 
//   }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test126"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(15861760, 2.3841866E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test127"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     double[] var5 = var4.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var10 = var7.nextSecureLong((-1L), 1L);
//     double var13 = var7.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var15 = var7.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var17 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var16);
//     double var18 = var16.sample();
//     double var20 = var16.probability(7.444490968701611d);
//     double var21 = var16.getSupportUpperBound();
//     double[] var23 = var16.sample(9694);
//     var6.addElements(var23);
//     int var25 = var6.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 7.530978450776851d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "86c19619e9"+ "'", var15.equals("86c19619e9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0305621857959943d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.0003534426350873d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0);
// 
//   }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test128"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var5 = var0.nextExponential(4.896058728199816d);
//     double var8 = var0.nextF(0.6372965055799583d, 0.39036590030677853d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 6.953773646220496d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 5.483015162464164d);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test129"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-0.9149746404329026d), 0.018485661248235252d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.5505956065919997d));

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test130"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 20355979);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test131"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.15512025679417774d, (java.lang.Number)1.2471705263294632d, (java.lang.Number)0.0843874063990762d);
    java.lang.Number var4 = var3.getHi();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.0843874063990762d+ "'", var4.equals(0.0843874063990762d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test132"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextUniform(0.2577047455984825d, 13.770182159584014d);
//     long var6 = var1.nextPoisson(0.23735441101118224d);
//     var1.reSeed(113506941100L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.281240920580538d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test133"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(19382, 2.3841864E-7f, 2097151.9f, 271);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test134"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    double[] var5 = var4.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    float var7 = var4.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = var4.copy();
    var4.contract();
    var4.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test135"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)12767, (java.lang.Number)303.1282921189383d, (java.lang.Number)13.72214533590941d);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test136"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double[] var2 = var0.sample(1910);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.cumulativeProbability(1.0494464950714408d, 0.03378478068568291d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test137"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(Float.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Float.POSITIVE_INFINITY);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test138"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-4), (-1.1368684E-13f), 2.8E-45f, 9424);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test139"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    double[] var5 = var4.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    float var7 = var4.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = var4.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setExpansionMode(268435456);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test140"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.9999999999999996d, (java.lang.Number)0.12993052037421432d, false);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test141"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2.5f, 2297);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test142"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var2 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)(-1), (java.lang.Object[])var2);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var6, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var11 = var10.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathArithmeticException var13 = new org.apache.commons.math3.exception.MathArithmeticException(var4, (java.lang.Object[])var11);
    var3.addSuppressed((java.lang.Throwable)var13);
    org.apache.commons.math3.exception.util.ExceptionContext var15 = var13.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test143"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.011295342728316431d, (-2.7193732266766655d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.71939668506329d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test144"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    boolean var10 = var8.equals((java.lang.Object)"468530cf61");
    java.lang.Class var11 = var8.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var13 = java.lang.Enum.<java.lang.Enum>valueOf(var11, "369ff86437459a9efdf212375c058d72c4c17b6985af56bed0c59bdbe287719436a48bc1b6bcdd3f8005a7623bef7ba5788f1260a4fd7b2d379e51734a2abeb31071ef0525d59ee2da2d0661c54c33a0ce1134f4198df36b2c7c019a89ab48ded92746c9f5c87bf02d4746d987fb755cfaa30291ee897226bc83be89c65360450b94c2f364ad688e589dda644707229f1b7e4374b449d1b67fc60d269ca33481dfbcd3f1bcb9694ebdb38a10944b28b7912da9067998de15d835d0eb44c4a1424b0055e2f33b9694c3b4635bd217e2efb6102292cec3da61b11c7cb69c5a387c7e776c08acb0ecdff8f4049662a4967c04c226c0792538ab807a1d47149609e117512a38f6afdea856339516ea6016ad5ef13e8c6de77f31231011f9f4e2e2d5211cce84159e805ce8663dffb8c8aabd21f0fad0f8d0f1898a2e48a565b0585f44c5c35c82438bddd94cb873f8871fed9f68acd16b19d7d32807f5d88d710ca521b632af584cf8b53973c7282ebaa4cff7f37b64b405a4dfed7dae7bc466f01117dfede37b4117a3fd598469600e65810c009225a546529f1d324a3c5bbc881e7d9609c9a232844d0fcaa052c23b4c80ae595469d4877c54889509a1f935b8be765798ad1874707262c964e044ae530ec3257df7d42788a39ddcf5cbfaf9e4eafa199feafc2ee98516f2a8b20777fd9b5561fc151c624d8230c4756dbe4b2ff56969c64fcc2dce93840abfd0b7215088dcd7ea43d3595e2fdb765861c6fa540b6a75b78c0c35e40a49d477d6b60aadcaf80fac47fc194d06b1868fd15daa1a6cfe211336313b912b5f182324b067235b4d36e59b5baa4c9c7a3197db9086b28524928c79e134284a03f1774c8d9492e81c209375b7c7828b83ee30ede6c90b63a6fceeb27b5e2142b6fb216bb88e8f5de852fa2a5cea5caf3a4bb46249b2c6660725414bd0d6e7763a63cf16fa5ca2b23dceb2fba0cbe4ab9f73c6000fffd639c52cb3f66c82a163296e673582818ff38f8f8011efcba050dd2de10e02775522a61a13b77a22e40b2b7809a0dc716364b5e1f5a19e5c355b2507eba87aca184b04ffadace6cce2deb1dd407c5a6801823302c09cfc31d29fbd9ed8b91967424b5b2877357d6e42a33d4d9b73f3ac289167d55a97a52703980875bd9fcb7aebf8eeec19fafd80dd8a19924b125332601f4eb6e47c0be0ff6188192cedb517d5a84db30a42effd40a598c0128acb75b56536e78762054bca29e08d89ff3ce7a1de42e332866291521d7311749bdfa49a47a874e50828d7e1aaf5928bf0f77a0f3ad3504e2c8c8e5e68d143a03cbc6f179b5faf929ca99ee2ba34e374547f0551696e44313af57921e8e9a543e8f889b52bd2a780542fe9a32566ca9b65bc5de3519ade2d9fde297e9fcb903e584957bac22ab5a03310b496cafaa0f9fd07cb4c84ca75e1c057d664a56c7459c3f0d276029e6d6dd85e92f1f67582f73f279a2f499602131da69f6c5a4a18f303de649f925287a25b4e434e5c4f4b93c4c343aba18598a0b9636e2d4093303c5d2af5b8341387a0962b4d9166b923ce38b9ef547ab63bd560e8998f626b8232f9400e5ff8a9f8adb6ccfb51201ea6a9e248d2e04b0c42de0399885f6d4eaf71924c3a853ec4028ae1fe10737cfe138c255765b833b34cca03548a16bac6fdc5a11997d77dc4040360668fa64a5bc409deaa0386534618fbb3d3344ba3d11ba7adc23fd56a6915d9dc36bd15aa85b7cde23d175502518ab9faa6bf1d5f2ef305312c7a4cf71276cea760f5065c247feb4d5101cafb8b45767cf5168e3ef59bca5b66a2f32322d80838803ecd76ae19c8506dc9f5522cd9c73cda5c18340db0ca15525af6f8756dbafd6725916134dde3ceadfa22618c326dc4b793e7fad6fc6c1bf8e232b432cc9d93b76b4b232209e17b8d84d407db0dc896512af3bc5a4967aaddbb987b18a46ff7c197b7c448709efce3312af9bf087552c83cbdf50d856fc4cfa3e75209c531e7a1a29c8bec3867fe2a92381c6ce040de3ce7df5add224ae766bc737894fcbb9480f066d51fcd1ecf1074f05670eed2b20a2962ed71dc4befd22e732985f8431b9d5da9c113cefba4ce19ec3d0e1ea657935254109f052b9153769b52bf1d37705f6e03323dd5dddcfed41b5dc9ec348ae0dcefdf01b1a62aab5b401976b0624bd23ba3fe70c22526c1e0fa0674680b073f86d3911481f6988cfb16a632d3cea5e1db434ee2caac8a81090158e289cb1798823966d1e68c411e81c4fe2adec1276fe8bee500dab383220fc1a664bfa3642d77af955aac50e8babcbc0194dc4f8176a85fd33b3be27b9f82ba18aff6c0db87a2e0e05b69d3ad0362e5d14abd1e3c72944566128c44923b072e44eb0a8b26c434900b9487728c0fc85520b26c76ecc998a1cb8264a127c8f1236ef7f50437c5e9cec1727d8e56e3ae98e972538fba481cdd5e1e779432f43a84045295576efa9e3a273d5b07f41f46784eb684f76cb346a666e17b4aea76912d6016c7d6e9f65def525877b713a831f73e0f1ef5f1167a5c98dc52959c325f07aa957e6f1d58fb17867d3c9f2a8241c73830a3a95e7e709c59d0ef1bd0c41323c92f1c2f6b5e70348003983890ee3a01875ad00f58afa5f438c444d5be37849a462e6fcb97bc816dabe490d3727e1574f9dbd4fb42321e7981cc7623f0beb3dbb9b82733a61dcc81d46be4c520305524d8a832ae57d51b67e4672a26c7eb41206a126a0f5091ee7d2547d189e16a81f0714b38daf959150430878c45389a113c287fa34a76bcdf596f4f235549fed0faa098db9c469315db7511b483152d4a6492d43e86b0eb9821c3854575c0dfbdd19df57f9c50f59a64cec09b8e44afe376815181b51adc79a980bfc36f08b7240c0dfd9e65a0be4152406ed7067c30a80831314ee95e428d2ff88139a29b0a8bac04d036beedc40787a6b160079594df1dcb7a751fb83570fb0b2b19efca8d13baa0403bf97ceb84481b3291e4c2ff583b149738ae9364f317af497956d87f9dc31f4b56370bb7adfedd3");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test145"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     var0.reSeed(100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var33 = var0.nextInt(83847, (-79578857));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.144384024883217d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "27f99e859a"+ "'", var8.equals("27f99e859a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1911);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.017971695195954523d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.7046080853790481d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.19735507760221152d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.2542424539299037d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.7445296171305898d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1.1581037959843192E29d);
// 
//   }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test146"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var4.addElement((-0.43408597923864894d));
//     double var10 = var4.getElement(0);
//     double[] var11 = var4.getElements();
//     var4.addElement(21.0d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getSupportUpperBound();
//     double[] var17 = var14.sample(10);
//     org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
//     double var20 = var18.addElementRolling(0.15264401491200186d);
//     float var21 = var18.getContractionCriteria();
//     float var22 = var18.getExpansionFactor();
//     boolean var23 = var4.equals((java.lang.Object)var18);
//     double var25 = var18.addElementRolling(18.59245611312501d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5631521198730945d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.240554286235614d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-1.8276580703681848d));
// 
//   }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test147"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var1.getNanStrategy();
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var6 = var5.getStandardDeviation();
//     double[] var8 = var5.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
//     double[] var10 = var9.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
//     org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var15 = var12.nextSecureLong((-1L), 1L);
//     double var18 = var12.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var20 = var12.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var21 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var22 = var12.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var21);
//     double var23 = var21.sample();
//     double var25 = var21.probability(7.444490968701611d);
//     double var26 = var21.getSupportUpperBound();
//     double[] var28 = var21.sample(9694);
//     var11.addElements(var28);
//     double[] var30 = var1.rank(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 10.039093752000452d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "48991a068c"+ "'", var20.equals("48991a068c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-0.5976946367548442d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-0.5479653530210633d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test148"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var5 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var4, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var2, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test149"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     double var16 = var0.nextGamma(0.11604808277231957d, 0.8382617516745859d);
//     var0.reSeedSecure();
//     int[] var20 = var0.nextPermutation(305, 189);
//     double var23 = var0.nextCauchy((-0.12889359106140577d), 110.38582314186594d);
//     org.apache.commons.math3.distribution.RealDistribution var24 = null;
//     double var25 = var0.nextInversionDeviate(var24);
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test150"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1946);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1946);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test151"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(2.250302549626871d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.039275188657011996d);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test152"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double var3 = var0.inverseCumulativeProbability(0.9999999999928669d);
    double var5 = var0.inverseCumulativeProbability(0.31440677756159524d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 6.755176609774487d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.48339745476011003d));

  }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test153"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     java.lang.String var13 = var0.nextHexString(10);
//     var0.reSeedSecure();
//     double var17 = var0.nextGaussian(7.042014262199385d, 1.179103839756096d);
//     double var20 = var0.nextCauchy((-1.4998528973459138d), 2.7076386898590252d);
//     long var22 = var0.nextPoisson(0.9999999987705535d);
//     double var24 = var0.nextExponential(6.621888603197341d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 16.872851798277587d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "901f045774"+ "'", var8.equals("901f045774"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "c021de9d19"+ "'", var13.equals("c021de9d19"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 7.200302587995003d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-0.15604005655262565d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 5.630890694624637d);
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test154"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    boolean var8 = var6.equals((java.lang.Object)Double.POSITIVE_INFINITY);
    boolean var10 = var6.equals((java.lang.Object)(-0.4255538433808183d));
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var13.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    java.lang.Class var18 = var17.getDeclaringClass();
    int var19 = var17.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var17);
    org.apache.commons.math3.random.RandomGenerator var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var21);
    org.apache.commons.math3.random.RandomGenerator var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var23);
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var25.getTiesStrategy();
    java.lang.Class var27 = var26.getDeclaringClass();
    java.lang.String var28 = var26.toString();
    java.lang.String var29 = var26.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var26);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var31 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var26);
    org.apache.commons.math3.random.RandomGenerator var32 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var32);
    org.apache.commons.math3.random.RandomGenerator var34 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var34);
    int var36 = var4.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "AVERAGE"+ "'", var28.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "AVERAGE"+ "'", var29.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test155"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var9);
    boolean var12 = var8.equals((java.lang.Object)0.00333969801975283d);
    java.lang.String var13 = var8.name();
    java.lang.Class var14 = var8.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var17 = var15.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var19 = var18.getTiesStrategy();
    java.lang.Class var20 = var19.getDeclaringClass();
    int var21 = var19.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var19);
    org.apache.commons.math3.random.RandomGenerator var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var23);
    org.apache.commons.math3.random.RandomGenerator var25 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var25);
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    org.apache.commons.math3.exception.OutOfRangeException var32 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.15512025679417774d, (java.lang.Number)1.2471705263294632d, (java.lang.Number)0.0843874063990762d);
    boolean var33 = var17.equals((java.lang.Object)1.2471705263294632d);
    org.apache.commons.math3.stat.ranking.NaNStrategy var34 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var35 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var37 = var36.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var38 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var35, var37);
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var34, var37);
    org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var37);
    int var41 = var37.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var42 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var37);
    int var43 = var8.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "MAXIMAL"+ "'", var13.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test156"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.0d, (-1.2458743353298596d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.141592653589793d);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test157"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var1, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test158"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     double var7 = var4.substituteMostRecentElement(14.52858068311814d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.13499677314172964d);
// 
//   }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test159"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(2.5000005f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5000007f);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test160"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    var0.reseedRandomGenerator(4L);
    double var5 = var0.density(0.5607801502120882d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.3408967199433627d);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test161"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(698150.78941603d, 6.841953917352447d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.841953917352447d);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test162"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.7548870922037547d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.12211800055593576d));

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test163"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(2.8E-45f, 100.00001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.8E-45f);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test164"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = null;
    double[] var4 = new double[] { 0.0d, (-1.0d), 0.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var7 = var6.getStandardDeviation();
    double[] var9 = var6.sample(1);
    double var10 = var6.getMean();
    double[] var12 = var6.sample(100);
    var5.addElements(var12);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var5.copy();
    var5.addElement(0.9999494957997512d);
    double var18 = var5.substituteMostRecentElement(12.770914443685303d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var5);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.9999494957997512d);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test165"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.71939668506329d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test166"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var1 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var5 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
//     org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var8 = var7.getSupportUpperBound();
//     double[] var10 = var7.sample(10);
//     double var11 = var1.mannWhitneyU(var5, var10);
//     var0.addElements(var5);
//     var0.clear();
//     double var15 = var0.addElementRolling((-9.097928974726221d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 27.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test167"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(10.825664296799586d, (-0.5559867868196782d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test168"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    java.lang.Class var11 = var10.getDeclaringClass();
    java.lang.Class var12 = var10.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    java.lang.String var14 = var10.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var8, var10);
    org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var17 = var16.getStandardDeviation();
    double[] var19 = var16.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var25 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
    double[] var30 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray(var30);
    double var32 = var21.mannWhitneyU(var25, var30);
    double var33 = var15.mannWhitneyUTest(var19, var25);
    var4.addElements(var19);
    var4.setNumElements(206);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "AVERAGE"+ "'", var14.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 4.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.17971249487899976d);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test169"); }


    float var2 = org.apache.commons.math3.util.FastMath.max((-1.4E-45f), 9.536744E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.536744E-7f);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test170"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-563), 3625451L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 492775925);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test171"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-0.582693261274406d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5583924428104816d);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test172"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var4 = null;
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0L);
    java.math.BigInteger var7 = null;
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var9);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 11L);
    java.math.BigInteger var13 = null;
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 0L);
    java.math.BigInteger var16 = null;
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 0L);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, var18);
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, 1949);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, var21);
    org.apache.commons.math3.exception.OutOfRangeException var23 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)6.88482624909385d, (java.lang.Number)1.1515109860475812d, (java.lang.Number)var12);
    java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    org.apache.commons.math3.exception.NumberIsTooLargeException var27 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-1.0598623819323194d), (java.lang.Number)var25, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test173"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.0d, 25.697333709313465d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test174"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(1255, 17018);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test175"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.1650603907741712d, (java.lang.Number)1498, true);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test176"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(2.6464439284783032d, 1.369076254094909E-4d, 2.8188929084501755d, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test177"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(2.0857110610969416d, 1491);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test178"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var5 = var0.nextExponential(4.896058728199816d);
//     double var8 = var0.nextF(0.8046108761210242d, 1929.4784382564899d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 6.564572655053539d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.1688557776451347d);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test179"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh((-1.0082650460352727d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.1879951111340057d));

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test180"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    boolean var8 = var6.equals((java.lang.Object)Double.POSITIVE_INFINITY);
    boolean var10 = var6.equals((java.lang.Object)(-0.4255538433808183d));
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var13.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    java.lang.Class var18 = var17.getDeclaringClass();
    int var19 = var17.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var17);
    org.apache.commons.math3.random.RandomGenerator var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var21);
    org.apache.commons.math3.random.RandomGenerator var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var23);
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var25.getTiesStrategy();
    java.lang.Class var27 = var26.getDeclaringClass();
    java.lang.String var28 = var26.toString();
    java.lang.String var29 = var26.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var26);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var31 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var26);
    org.apache.commons.math3.random.RandomGenerator var32 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var32);
    org.apache.commons.math3.random.RandomGenerator var34 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var34);
    org.apache.commons.math3.random.RandomGenerator var36 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "AVERAGE"+ "'", var28.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "AVERAGE"+ "'", var29.equals("AVERAGE"));

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test181"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(751, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test182"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var8, var11);
    org.apache.commons.math3.random.RandomGenerator var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var15);
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    java.lang.Class var19 = var18.getDeclaringClass();
    java.lang.Class var20 = var18.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    java.lang.String var22 = var18.name();
    java.lang.String var23 = var18.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var24 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var8, var18);
    java.lang.Class var25 = var18.getDeclaringClass();
    int var26 = var18.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "AVERAGE"+ "'", var22.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "AVERAGE"+ "'", var23.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 3);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test183"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.01812146259910505d, 0.07106541156532857d, 0.1455743100721331d);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test184"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.6098400998484748d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6986808794827079d);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test185"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.9982828899112327d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9994273020500808d);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test186"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(2419200L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2419200L);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test187"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(25L, 79833600L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 79833600L);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test188"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    var4.setElement(1931, 0.2577047455984825d);
    int var11 = var4.getNumElements();
    int var12 = var4.getExpansionMode();
    int var13 = var4.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1932);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test189"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    boolean var2 = var0.isSupportUpperBoundInclusive();
    boolean var3 = var0.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test190"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(0, 11007);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test191"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.4249487886097677d);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test192"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var1.contract();
    int var3 = var1.start();
    float var4 = var1.getExpansionFactor();
    var1.setNumElements(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionFactor(99.999985f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test193"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.setElement(11, 0.5322866968936354d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setElement((-297258196), (-5.012870905106836d));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test194"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.9360333153081093d, 1.5302877243745072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8032716991111156d);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test195"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    java.lang.Class var6 = var4.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    java.lang.String var8 = var4.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    java.lang.Class var10 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test196"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.9999999f, 9.536747E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9999999f);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test197"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var6, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var11 = var10.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathIllegalArgumentException var14 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.NullArgumentException var16 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathArithmeticException var17 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test198"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.999983988148989d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999919940424469d);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test199"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.contract();
    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var3 = var2.getStandardDeviation();
    double[] var5 = var2.sample(1);
    double var7 = var2.cumulativeProbability(0.0d);
    double var8 = var2.getSupportUpperBound();
    boolean var9 = var2.isSupportUpperBoundInclusive();
    var2.reseedRandomGenerator((-16L));
    double[] var13 = var2.sample(2297);
    var0.addElements(var13);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    double[] var16 = var15.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setExpansionMode(1992);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test200"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.002073594803565866d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32.85571758007182d);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test201"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var6, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var11 = var10.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathIllegalArgumentException var14 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.NullArgumentException var17 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test202"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.5658474030075499d, 14.031149057314524d);
//     java.util.Collection var5 = null;
//     java.lang.Object[] var7 = var1.nextSample(var5, 186);
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test203"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(9181, 99.99999f);
    int var3 = var2.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test204"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.29397730812946654d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2857914043847783d);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test205"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.setContractionCriteria(2.5f);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var17 = var16.getStandardDeviation();
    double[] var19 = var16.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    int var21 = var20.start();
    org.apache.commons.math3.util.ResizableDoubleArray var22 = var20.copy();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var20.setExpansionFactor(100.00002f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test206"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.007740528947110199d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3509771597300298E-4d);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test207"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     double var6 = var0.nextGamma(0.45207061712111124d, (-0.23684948973501402d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.22881246163275917d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.023458319952451002d));
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test208"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)2.281783181607902d, (java.lang.Number)0.3555392670770524d, (java.lang.Number)1.151525743674435d);

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test209"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(4.954761098952899d, (-0.24690024329386945d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test210"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     int var6 = var0.nextInt((-35944354), 1868);
//     java.lang.String var8 = var0.nextHexString(3607);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.6602649835670793d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-14167134));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "621a6b4608124a54ac79b32806aa89153b57f46cdcb996eaa6dd75ebde42a9118756f9dd23140585733aa0a08b2cd4fc5651d32f780312edb387bd8ec2522d9970f4edc995e037e7dcb34c92018a0706585ead906374beb511f27fd1c754760abea2be91f57b648ab7c2842d595ac391e0effd0c7b2a01a81e6dd353fe4fa270ecbe3f6314262dfe985c03f24308437920afa8470c63ec60579996fdf29a8e23debeac0f13e603e9a0b2b262640926146a1f120bb288cbfcb27c4a4eae5c8b73530e0dccdb38d63a6600fc0519cbbb447fb3490fe1a01ce8370f9eb5ca76a0dc3fbaea92486aea4227049a755d7c72ffbba30986a5c63d2de1276b723f59e97e1ca57c118badc5a33ca3b2adc6c122e66c7bcb12fe35b0b6ad600dbbcc8356c47062b0bb6a495a69e4cc64eb1275da12203a9ada02b971f16fbf0c2b7aa701397de36cafdecabb03b639cea8f7bad4241252f5a1bdaea78ce8abb0cd7a34311b047e3071bb21aca853432f5c2f804bfa5b56198f629c78e171773c8515e80374139dafb9ad51bd1a0ece47a0a250b0db75af400c8593417f119873ba045c3bfdf19f9dd87d0f76d29f5732293b9aa113e902ef3bef71f4437c19c507932353f5fa8723a1cda6e42f37ceeba266958e6fb188ea1b902f97d65afb4cb6c50fcfde1ced2507216864937dfc1bc3b4ced5691f5ffa3b43e7138ffc77f5a510fcab198e0ef743b4291a1650ab49b0f1cec744c7e26e74a0e7b3dfe4854d4e6e6343b81e90ce87efb1ba896da2551751427716ff899100ddc301ff41a8423565878b8c4abf485204072daad728c008d0a3d39d4378190a382d356e1fc6699769e926a8451acad8dc6f95c505ab1dcfdc2d1571e1c755716a918eac71b3c1bdbd366bf63c05f8cbf5997690aa8afe5d88d5300a30f7c03984d284f5310e3faad9f4cd511f543adf01c821a83fd053122164d0a22897b55acf2713b1f2d73dea58c22000e6035f8ffe99b6d3925200c14ae9bcf5c52f5ba3a801d9fa404ba1a79cb3e157ce1371574314fe788c3377929070728f7bf2db2e6cd8ef0fbd8e79f4724a3cc518b81d88104f1666fe18830d03a40f9e24ca4a2010d6e2d4f721fe1f5b44d55515088062294b9f8a0c130a2567ca87a529f7c527250d117a700a9cae8aaa0663d40c9dd39ba451319d4336228cbdaf431711c37ae673fcafc82507c5a2e79a2c0c787cfef5f55d9cbcedffc0ad78a917026c87866336864323e545df6df8dd7426531ac74b544835fa39e981f8c3691be744a4ae891fee20b0ee05a99b990ac68d700c04295d7d7b1a4b0554d5fa8d9996bde0704cc7132d5cd7b91a94b5612643690f625f876915d0830bc6d6815cb5ef2137df2400c796e919608d302a6bcb3b4bfebacd2ad0b4a36d4ed249d77c28d5d960734ba16ebccf8d4b096dab7231410a8d644991f5086564f2f3b725aec24c801f82af351441c685d469d36fdc3279735ead75e5e04241fd91da874c97d3848531e88d916659e1edb0b5ef5ea1e24359bab5d12cbae0a1e70f136355abb4d32d90a01b0afb12946d9dec24ea43886f97f29d1fb55470e6173f8c30d15488e17e4b2efcc322f4be769eecac4f30aa7b9d58f2e0f01cb297d29c983a9cbacb444ab0dd10241c001e6d7348138daf99e71203380e88866e0394be5de5cf487cdc89594c69a615c3fae2195f365eea0d466cfcf09b7f0536335d6d25affb375ba34b74636a861acb498d83264fb3caa868f58c0952c4e3c0726ae19b54a0c9b204e3b7805e365d103a0d8460fb028f99705ba2108ef225e0b05215a8559afdc9f56b2bfb3d6a7cfe9d2e685b2713e7c5b77aa06f81b143c6d2edc81d0b8f1ca46c2d9ec8d65b1062ce8a4656c0e1a979b5374f062ffb01ae6bd93a2c5548caec172b3e1e7c74aa8e3b37de2790bfbf6c5e57e2331cfc5057b1945f3b45674ca69153aa89e854e6fe98759ffbed8a39238bdee6f90f251bcaac4b8fa500a013cbd01f5877b6d1138734be4c66ecb9fb3bca8c7e696807df4f35d77f7753e661a976f6cf3b8bc63466a0ffe91bb7e2db89b83f84e535345a56c635d237ca9f984a13e55ec50636f7f1b5b116d37598c2b26d1fed9a7a2479b173d429214af5d17aab65a9f8d468fa898e11c7e9339bd96f345f8c879632a6d07691186e26a53c83848b19846e88f5d68d9a2014e29eb71c6ff08fe035e5e2c76aa89331c90ac94ded1aa788d9897412ecc131b79b36b12f8cc6e9373c6814b414168189118c90aba4641c339773edf11f8922384c1490f9d9b5d992405a3b40b1caf7a7b54efe95de67212295d1b33cfc488743c7f9b5c60214b8bf0c2528ed795ded8f53a66bfbd19d23f6f02bb438deaeab9242b198ec1c04d9c108731c8a201015c166ae316f3056b0617ecd3b8f509dca8e21424ea14aaf431e8f0cd1a4a45d40caeb474af610486a12553dea998eff8c3e730eccd7e0e8e421cd437a806d60140c4af971eb3fb35132dcf42c4e20b25d42672269248e3b91e64557aecbb94b5a8"+ "'", var8.equals("621a6b4608124a54ac79b32806aa89153b57f46cdcb996eaa6dd75ebde42a9118756f9dd23140585733aa0a08b2cd4fc5651d32f780312edb387bd8ec2522d9970f4edc995e037e7dcb34c92018a0706585ead906374beb511f27fd1c754760abea2be91f57b648ab7c2842d595ac391e0effd0c7b2a01a81e6dd353fe4fa270ecbe3f6314262dfe985c03f24308437920afa8470c63ec60579996fdf29a8e23debeac0f13e603e9a0b2b262640926146a1f120bb288cbfcb27c4a4eae5c8b73530e0dccdb38d63a6600fc0519cbbb447fb3490fe1a01ce8370f9eb5ca76a0dc3fbaea92486aea4227049a755d7c72ffbba30986a5c63d2de1276b723f59e97e1ca57c118badc5a33ca3b2adc6c122e66c7bcb12fe35b0b6ad600dbbcc8356c47062b0bb6a495a69e4cc64eb1275da12203a9ada02b971f16fbf0c2b7aa701397de36cafdecabb03b639cea8f7bad4241252f5a1bdaea78ce8abb0cd7a34311b047e3071bb21aca853432f5c2f804bfa5b56198f629c78e171773c8515e80374139dafb9ad51bd1a0ece47a0a250b0db75af400c8593417f119873ba045c3bfdf19f9dd87d0f76d29f5732293b9aa113e902ef3bef71f4437c19c507932353f5fa8723a1cda6e42f37ceeba266958e6fb188ea1b902f97d65afb4cb6c50fcfde1ced2507216864937dfc1bc3b4ced5691f5ffa3b43e7138ffc77f5a510fcab198e0ef743b4291a1650ab49b0f1cec744c7e26e74a0e7b3dfe4854d4e6e6343b81e90ce87efb1ba896da2551751427716ff899100ddc301ff41a8423565878b8c4abf485204072daad728c008d0a3d39d4378190a382d356e1fc6699769e926a8451acad8dc6f95c505ab1dcfdc2d1571e1c755716a918eac71b3c1bdbd366bf63c05f8cbf5997690aa8afe5d88d5300a30f7c03984d284f5310e3faad9f4cd511f543adf01c821a83fd053122164d0a22897b55acf2713b1f2d73dea58c22000e6035f8ffe99b6d3925200c14ae9bcf5c52f5ba3a801d9fa404ba1a79cb3e157ce1371574314fe788c3377929070728f7bf2db2e6cd8ef0fbd8e79f4724a3cc518b81d88104f1666fe18830d03a40f9e24ca4a2010d6e2d4f721fe1f5b44d55515088062294b9f8a0c130a2567ca87a529f7c527250d117a700a9cae8aaa0663d40c9dd39ba451319d4336228cbdaf431711c37ae673fcafc82507c5a2e79a2c0c787cfef5f55d9cbcedffc0ad78a917026c87866336864323e545df6df8dd7426531ac74b544835fa39e981f8c3691be744a4ae891fee20b0ee05a99b990ac68d700c04295d7d7b1a4b0554d5fa8d9996bde0704cc7132d5cd7b91a94b5612643690f625f876915d0830bc6d6815cb5ef2137df2400c796e919608d302a6bcb3b4bfebacd2ad0b4a36d4ed249d77c28d5d960734ba16ebccf8d4b096dab7231410a8d644991f5086564f2f3b725aec24c801f82af351441c685d469d36fdc3279735ead75e5e04241fd91da874c97d3848531e88d916659e1edb0b5ef5ea1e24359bab5d12cbae0a1e70f136355abb4d32d90a01b0afb12946d9dec24ea43886f97f29d1fb55470e6173f8c30d15488e17e4b2efcc322f4be769eecac4f30aa7b9d58f2e0f01cb297d29c983a9cbacb444ab0dd10241c001e6d7348138daf99e71203380e88866e0394be5de5cf487cdc89594c69a615c3fae2195f365eea0d466cfcf09b7f0536335d6d25affb375ba34b74636a861acb498d83264fb3caa868f58c0952c4e3c0726ae19b54a0c9b204e3b7805e365d103a0d8460fb028f99705ba2108ef225e0b05215a8559afdc9f56b2bfb3d6a7cfe9d2e685b2713e7c5b77aa06f81b143c6d2edc81d0b8f1ca46c2d9ec8d65b1062ce8a4656c0e1a979b5374f062ffb01ae6bd93a2c5548caec172b3e1e7c74aa8e3b37de2790bfbf6c5e57e2331cfc5057b1945f3b45674ca69153aa89e854e6fe98759ffbed8a39238bdee6f90f251bcaac4b8fa500a013cbd01f5877b6d1138734be4c66ecb9fb3bca8c7e696807df4f35d77f7753e661a976f6cf3b8bc63466a0ffe91bb7e2db89b83f84e535345a56c635d237ca9f984a13e55ec50636f7f1b5b116d37598c2b26d1fed9a7a2479b173d429214af5d17aab65a9f8d468fa898e11c7e9339bd96f345f8c879632a6d07691186e26a53c83848b19846e88f5d68d9a2014e29eb71c6ff08fe035e5e2c76aa89331c90ac94ded1aa788d9897412ecc131b79b36b12f8cc6e9373c6814b414168189118c90aba4641c339773edf11f8922384c1490f9d9b5d992405a3b40b1caf7a7b54efe95de67212295d1b33cfc488743c7f9b5c60214b8bf0c2528ed795ded8f53a66bfbd19d23f6f02bb438deaeab9242b198ec1c04d9c108731c8a201015c166ae316f3056b0617ecd3b8f509dca8e21424ea14aaf431e8f0cd1a4a45d40caeb474af610486a12553dea998eff8c3e730eccd7e0e8e421cd437a806d60140c4af971eb3fb35132dcf42c4e20b25d42672269248e3b91e64557aecbb94b5a8"));
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test211"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var3);
    java.lang.String var6 = var3.name();
    java.lang.String var7 = var3.toString();
    java.lang.Class var8 = var3.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "AVERAGE"+ "'", var7.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test212"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
    java.lang.Object var17 = null;
    boolean var18 = var4.equals(var17);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = var4.copy();
    var4.addElement(6.621888603197341d);
    var4.setElement(1848, 0.1708276255239572d);
    float var25 = var4.getExpansionFactor();
    double[] var26 = var4.getInternalValues();
    var4.setContractionCriteria(2.5000005f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test213"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.5d, (java.lang.Number)7.724435900937391d, (java.lang.Number)363.7393755555636d);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    java.lang.String var5 = var4.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"+ "'", var5.equals("org.apache.commons.math3.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"));

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test214"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     var4.contract();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     float var7 = var4.getContractionCriteria();
//     double var9 = var4.addElementRolling(5.775578026902914E10d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.discardFrontElements((-1953380655));
//       fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
//     } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.253871408004799d);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test215"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.024194470033531684d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.024192110192683847d);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test216"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.9590416566058654d, (-0.13168601072456645d), (-1.2576425716658453d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test217"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    boolean var2 = var0.isSupportUpperBoundInclusive();
    double[] var4 = var0.sample(100);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    int var6 = var5.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test218"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     var0.reSeed(100L);
//     org.apache.commons.math3.distribution.NormalDistribution var34 = new org.apache.commons.math3.distribution.NormalDistribution((-4.440892098500626E-16d), 1.1102230246251565E-16d, 0.9999494957997512d);
//     double var35 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var34);
//     double var38 = var0.nextGamma(15.0d, 24.306596265105895d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var41 = var0.nextZipf(1491, (-0.8159290282824452d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 17.028254258804687d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "b9e4e76a63"+ "'", var8.equals("b9e4e76a63"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1935);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0016691655829754717d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.259934002984661d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-0.8876544459197215d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-0.21214723715107114d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-0.150196974636142d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1.0600967566142618E59d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == (-5.315982015318238E-16d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 295.99559901809107d);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test219"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.912933013825568d);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    boolean var3 = var1.getBoundIsAllowed();
    java.lang.Number var4 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test220"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)2.587135708879087d, (java.lang.Number)1.055932391388095d, true);

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test221"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(192.9088122275434d);
//     double var12 = var0.nextExponential(0.7243407758924822d);
//     org.apache.commons.math3.distribution.NormalDistribution var13 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var13.reseedRandomGenerator(2L);
//     boolean var16 = var13.isSupportConnected();
//     boolean var17 = var13.isSupportLowerBoundInclusive();
//     double var18 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var13);
//     double var20 = var13.density(0.3820170337076183d);
//     double var21 = var13.getSupportUpperBound();
//     double var22 = var13.sample();
//     double var23 = var13.getStandardDeviation();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 34.5848541726092d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "75e15caea7"+ "'", var8.equals("75e15caea7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 209L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.3034325216580789d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.8038066873061299d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.3708687545713982d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.604776607991365d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test222"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(1.3440585709080678E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.04323229440977d));

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test223"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(2702L, 87491968L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 236403297536L);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test224"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.1083320717391616d);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test225"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(791);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test226"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(18.860854671741663d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.552713678800501E-15d);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test227"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    var1.addElement(2.0216852347077916d);
    org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var5 = var4.getStandardDeviation();
    double[] var7 = var4.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var12 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var11, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var10, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var9, (java.lang.Object[])var12);
    boolean var16 = var8.equals((java.lang.Object)var9);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var8);
    int var18 = var1.start();
    org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var20 = var19.getStandardDeviation();
    double[] var22 = var19.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    org.apache.commons.math3.exception.util.Localizable var24 = null;
    org.apache.commons.math3.exception.util.Localizable var25 = null;
    org.apache.commons.math3.exception.util.Localizable var26 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var27 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var28 = new org.apache.commons.math3.exception.NullArgumentException(var26, (java.lang.Object[])var27);
    org.apache.commons.math3.exception.MathInternalError var29 = new org.apache.commons.math3.exception.MathInternalError(var25, (java.lang.Object[])var27);
    org.apache.commons.math3.exception.NullArgumentException var30 = new org.apache.commons.math3.exception.NullArgumentException(var24, (java.lang.Object[])var27);
    boolean var31 = var23.equals((java.lang.Object)var24);
    var23.setElement(8899, 2.3930658372149933d);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var23);
    double var37 = var1.substituteMostRecentElement(1.8887342986603224d);
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 2.0216852347077916d);

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test228"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(1916, 317);
//     java.lang.String var5 = var0.nextHexString(1836);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextInt(1932, 41);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "5409d248b8b9c67ded5f98bbff4617c94c31e80d95da8a99bddb74dcae31706184bb2e67f2bd669062aec739f705397ad7a2578710f8c691f1eb00ffdc1a5642316e09d51f6d62899db985aa983ccd7a94406d0ccb053bd2ffc8a540a738f708c18614779ed624b8bb7406f22de0632c5f6740d7ae536f66f155ea73f3f5eebc93cb4eca68aeb37f0601904fb1580e810d2f090e3c86698ccd5fa55050827ae462bd9a5f24036e6f04d014c97cf502122c2bc3ca92c2924f1a634f7402818ede7c0e3b55fa852973241e724812d698d00d4cb381416be438a66c7cfdaa71b9b5d8f35063d5cf69c6d2d98c9ea6ac14f0c7572b8c93b08443744ff134d6c74f5b54c06af31d2f9c9e886ad1a5fbc4aed7eddcd9e50a1aac3eb05eb06af1b39a24bb0f7e27fce1cd35cb28055b0090072dd0b8d6e673e5a0e40384bbfb7e4c680c21daf6333b43344f1d59c1b8801418a88455317a41f5dfb2c2da9d5066214959b195b2f84c34090090bc6842eb0e58f68b0f1bef5032ac84edec6dc8f7daee96b18e898bd0fbecdf5356ba7f0da660502c45763a21341ab64cf7f349881b071e369b6a05b131272a5fd6154c966bf7d900a0bbae29471eee8db82105d210c974bee060bfa042980c60f58c23da586f47965cfc2eaad55453a67012a6256f32914ec0d74e7baec2ebfc2518285c019f891f1c0c141191bbc666ab66cc819bf16777851ded8d43665f9523f9a0a3d799da8b0a76a3bc77a0a060864f5f889d16e9eeae1884b6321aa80a3aba221d200dbab65c9e27652e4a33da3ef1c669b03135076b2a375e1b044bd385ce4d71a84310959048f528bcffd81efdbee49be42d02bafaa881d1475135e583ba24513b7a7daa32e98151c6bcd664a31f1f637e7ab13207c45723da41844ffc59f7f7958f458d40a1c5765530af1a1555c51117ea21310c8de410fa0b185189a938f2052a8df35a1b60de1405d1ebe95b0d24c4af2b39cc91eabc188244167b0fb65360686740925d9c1117f1b166165ea8118454085b31e267b0fc34877b3fd05a0ed1e94c0b3abee62f126d7cf03315e478de680396b5e38020f594aaf44bad051580f95969389c0bd6be04fe5420549b491037672559e27a3081c03e78f93f14ab3df9133a8720f383627908be2b0ef0390a085dfc5482d6ca8590f73e3c58e999866347e4e3b906aae88f35307cc3fe3afee44c1834360c7e43e8f640a6863ee2665305a1890704c06c8f52c465bc6358058d409a011ca2f74357adab6254653ea31ad9952dabc69c3e"+ "'", var5.equals("5409d248b8b9c67ded5f98bbff4617c94c31e80d95da8a99bddb74dcae31706184bb2e67f2bd669062aec739f705397ad7a2578710f8c691f1eb00ffdc1a5642316e09d51f6d62899db985aa983ccd7a94406d0ccb053bd2ffc8a540a738f708c18614779ed624b8bb7406f22de0632c5f6740d7ae536f66f155ea73f3f5eebc93cb4eca68aeb37f0601904fb1580e810d2f090e3c86698ccd5fa55050827ae462bd9a5f24036e6f04d014c97cf502122c2bc3ca92c2924f1a634f7402818ede7c0e3b55fa852973241e724812d698d00d4cb381416be438a66c7cfdaa71b9b5d8f35063d5cf69c6d2d98c9ea6ac14f0c7572b8c93b08443744ff134d6c74f5b54c06af31d2f9c9e886ad1a5fbc4aed7eddcd9e50a1aac3eb05eb06af1b39a24bb0f7e27fce1cd35cb28055b0090072dd0b8d6e673e5a0e40384bbfb7e4c680c21daf6333b43344f1d59c1b8801418a88455317a41f5dfb2c2da9d5066214959b195b2f84c34090090bc6842eb0e58f68b0f1bef5032ac84edec6dc8f7daee96b18e898bd0fbecdf5356ba7f0da660502c45763a21341ab64cf7f349881b071e369b6a05b131272a5fd6154c966bf7d900a0bbae29471eee8db82105d210c974bee060bfa042980c60f58c23da586f47965cfc2eaad55453a67012a6256f32914ec0d74e7baec2ebfc2518285c019f891f1c0c141191bbc666ab66cc819bf16777851ded8d43665f9523f9a0a3d799da8b0a76a3bc77a0a060864f5f889d16e9eeae1884b6321aa80a3aba221d200dbab65c9e27652e4a33da3ef1c669b03135076b2a375e1b044bd385ce4d71a84310959048f528bcffd81efdbee49be42d02bafaa881d1475135e583ba24513b7a7daa32e98151c6bcd664a31f1f637e7ab13207c45723da41844ffc59f7f7958f458d40a1c5765530af1a1555c51117ea21310c8de410fa0b185189a938f2052a8df35a1b60de1405d1ebe95b0d24c4af2b39cc91eabc188244167b0fb65360686740925d9c1117f1b166165ea8118454085b31e267b0fc34877b3fd05a0ed1e94c0b3abee62f126d7cf03315e478de680396b5e38020f594aaf44bad051580f95969389c0bd6be04fe5420549b491037672559e27a3081c03e78f93f14ab3df9133a8720f383627908be2b0ef0390a085dfc5482d6ca8590f73e3c58e999866347e4e3b906aae88f35307cc3fe3afee44c1834360c7e43e8f640a6863ee2665305a1890704c06c8f52c465bc6358058d409a011ca2f74357adab6254653ea31ad9952dabc69c3e"));
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test229"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(8899, 9.536747E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test230"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var1 = null;
//     java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
//     java.math.BigInteger var4 = null;
//     java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0L);
//     java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, var6);
//     java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 11L);
//     java.math.BigInteger var10 = null;
//     java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
//     java.math.BigInteger var13 = null;
//     java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 0L);
//     java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, var15);
//     java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 1949);
//     java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, var18);
//     java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, var9);
// 
//   }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test231"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
//     java.lang.Class var3 = var2.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     java.lang.String var5 = var2.toString();
//     java.lang.String var6 = var2.toString();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var2);
//     org.apache.commons.math3.random.RandomGenerator var8 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var11.getStandardDeviation();
//     double[] var14 = var11.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
//     var15.contract();
//     var15.addElement(0.0d);
//     int var19 = var15.getExpansionMode();
//     double[] var20 = var15.getElements();
//     double[] var21 = var9.rank(var20);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var23 = var22.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var24 = var22.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var25.getTiesStrategy();
//     java.lang.Class var27 = var26.getDeclaringClass();
//     int var28 = var26.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24, var26);
//     org.apache.commons.math3.random.RandomGenerator var30 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24, var30);
//     org.apache.commons.math3.random.RandomGenerator var32 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24, var32);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var35 = var34.getTiesStrategy();
//     java.lang.Class var36 = var35.getDeclaringClass();
//     java.lang.String var37 = var35.toString();
//     java.lang.String var38 = var35.toString();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24, var35);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var40 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var44 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var45 = new org.apache.commons.math3.util.ResizableDoubleArray(var44);
//     org.apache.commons.math3.distribution.NormalDistribution var46 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var47 = var46.getSupportUpperBound();
//     double[] var49 = var46.sample(10);
//     double var50 = var40.mannWhitneyU(var44, var49);
//     double[] var51 = var39.rank(var44);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var52 = var39.getNanStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var53 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.distribution.NormalDistribution var54 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var55 = var54.getStandardDeviation();
//     boolean var56 = var54.isSupportUpperBoundInclusive();
//     double[] var58 = var54.sample(100);
//     org.apache.commons.math3.distribution.NormalDistribution var59 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var59.reseedRandomGenerator(2L);
//     double[] var63 = var59.sample(100000);
//     double var64 = var53.mannWhitneyUTest(var58, var63);
//     org.apache.commons.math3.distribution.NormalDistribution var65 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var66 = var65.getStandardDeviation();
//     double[] var68 = var65.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var69 = new org.apache.commons.math3.util.ResizableDoubleArray(var68);
//     double[] var73 = new double[] { 0.0d, (-1.0d), 0.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var74 = new org.apache.commons.math3.util.ResizableDoubleArray(var73);
//     double var75 = var53.mannWhitneyU(var68, var73);
//     double[] var76 = var39.rank(var68);
//     double var77 = var7.mannWhitneyUTest(var20, var68);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test232"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(3.1173466159040992d);
    float var3 = var0.getContractionCriteria();
    var0.setElement(0, 0.7839474158762535d);
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.5f);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test233"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, 0.19236629307868022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.9E-324d);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test234"); }


    java.math.BigInteger var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, (-35944354));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test235"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.3408967199433627d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 22.283841449159915d);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test236"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = null;
    org.apache.commons.math3.distribution.NormalDistribution var1 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var1.getStandardDeviation();
    double[] var4 = var1.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var8, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var7, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var6, (java.lang.Object[])var9);
    boolean var13 = var5.equals((java.lang.Object)var6);
    var5.discardMostRecentElements(1);
    int var16 = var5.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var17 = var5.copy();
    double var19 = var5.addElementRolling(2.478622967831918d);
    var5.setNumElements(1491);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var5);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test237"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(16216148, 1960);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16218108);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test238"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-1.2266514872174121d), (java.lang.Number)(-0.03477795372577799d), false);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test239"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var2 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.NullArgumentException var3 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var2);
//     org.apache.commons.math3.exception.NullArgumentException var4 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var2);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test240"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-5071615437313169176L), 12L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4L);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test241"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(1313L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test242"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.11523471458721654d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.122136788537695d);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test243"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var8 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var4, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var2, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var9);
    java.lang.Throwable[] var13 = var12.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var14 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.util.ExceptionContext var15 = var14.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test244"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     var0.reSeed(14L);
//     double var15 = var0.nextCauchy(7.362895734466076d, 3.63988988172153d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("cafb9f5a32", "0e94ee33fe");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.036335113576018d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "65cb36e06d"+ "'", var8.equals("65cb36e06d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.6112791153835848d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-6.529433490302414d));
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test245"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.5000005f, 14.792906103929404d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5000007f);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test246"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(13.40367387687556d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1095972979990962d);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test247"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4227843322079321d);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test248"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.5785016365981144d, 0.1609204618510406d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6319549518571901d);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test249"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getStandardDeviation();
//     double[] var13 = var10.sample(1);
//     double var15 = var10.cumulativeProbability(0.0d);
//     double var16 = var10.getSupportUpperBound();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     boolean var18 = var10.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.205401213151264d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-2.228044959035931d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test250"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var4.setElement(1953, 0.0d);
    int var10 = var4.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1954);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test251"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var8, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    java.lang.Class var18 = var17.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    java.lang.String var20 = var17.toString();
    java.lang.String var21 = var17.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var8, var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "AVERAGE"+ "'", var21.equals("AVERAGE"));

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test252"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-1342156216L), 78324127259616L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test253"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)100000);
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: 100,000 is smaller than the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotPositiveException: 100,000 is smaller than the minimum (0)"));

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test254"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     var0.reSeedSecure();
//     double var18 = var0.nextCauchy(5.363952139253263d, 25.03080200374832d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.285875478972182d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "c56483c2affe495441cadb3fd573dd6a7c8ab5d45593ee1310920eb7537bcda242f7c8a07d2010008e02c1428d513f3826a3"+ "'", var8.equals("c56483c2affe495441cadb3fd573dd6a7c8ab5d45593ee1310920eb7537bcda242f7c8a07d2010008e02c1428d513f3826a3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.1292618753905499d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 28.255366106925216d);
// 
//   }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test255"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     var0.reSeedSecure();
//     int var10 = var0.nextBinomial(243, 0.745691842295965d);
//     long var12 = var0.nextPoisson(31.862892444737472d);
//     java.lang.String var14 = var0.nextHexString(10240);
//     long var17 = var0.nextLong(177L, 268435456L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.151301779564477d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 175);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 29L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 110303277L);
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test256"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.8341080646002629d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3027592195709965d);

  }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test257"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(8.854558633913316d, 3.1173466159040992d);
//     double var3 = var2.sample();
//     double var4 = var2.getMean();
//     double var5 = var2.getMean();
//     boolean var6 = var2.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.886700414012366d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 8.854558633913316d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 8.854558633913316d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test258"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.0638496266255846d, (-0.6487974831986031d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0638496266255844d);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test259"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(9.999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test260"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var11 = var9.sample();
//     double[] var13 = var9.sample(243);
//     double var16 = var9.cumulativeProbability(0.56089788532758d, 1.7059487146473076d);
//     double var17 = var9.getSupportUpperBound();
//     boolean var18 = var9.isSupportLowerBoundInclusive();
//     boolean var19 = var9.isSupportUpperBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.853757430656069d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "16932893ed"+ "'", var8.equals("16932893ed"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.31034070968864363d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.5668172130264508d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.24342476154268322d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
// 
//   }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test261"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     double var11 = var0.nextGaussian(0.0d, 25.472636453138065d);
//     var0.reSeed(76L);
//     java.util.Collection var14 = null;
//     java.lang.Object[] var16 = var0.nextSample(var14, 8941);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test262"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)2097152.5f, (java.lang.Number)(-0.6991346750676082d), true);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test263"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 1.0f, 0.0f, 1592);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test264"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var4 = var0.getMean();
    var0.reseedRandomGenerator((-2L));
    double var7 = var0.getSupportUpperBound();
    double var8 = var0.getSupportLowerBound();
    var0.reseedRandomGenerator(2985984L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var0.inverseCumulativeProbability((-0.799812575076354d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.NEGATIVE_INFINITY);

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test265"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     var0.reSeedSecure((-6266588889437241349L));
//     java.util.Collection var31 = null;
//     java.lang.Object[] var33 = var0.nextSample(var31, 0);
// 
//   }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test266"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-0.15473005880536628d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test267"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var2 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)(-1), (java.lang.Object[])var2);
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var6, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
//     java.lang.Throwable[] var11 = var10.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.MathArithmeticException var13 = new org.apache.commons.math3.exception.MathArithmeticException(var4, (java.lang.Object[])var11);
//     var3.addSuppressed((java.lang.Throwable)var13);
//     java.lang.Number var15 = var3.getMax();
//     org.apache.commons.math3.exception.MathInternalError var16 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
// 
//   }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test268"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(4.0442469174590314E-4d, 54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.285467564185108E12d);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test269"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    int var2 = var1.ordinal();
    int var3 = var1.ordinal();
    int var4 = var1.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test270"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var1.contract();
    int var3 = var1.start();
    float var4 = var1.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var6 = var5.getElements();
    int var7 = var5.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test271"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)4.212413715260051d, (java.lang.Number)9.699108969439779d, false);
    java.lang.Number var4 = var3.getMax();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 9.699108969439779d+ "'", var4.equals(9.699108969439779d));

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test272"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     var4.contract();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var6.contract();
//     int var8 = var6.getExpansionMode();
//     var6.setElement(5, 20.696514663540924d);
//     var6.setNumElements(1);
//     int var14 = var6.getNumElements();
//     double var16 = var6.substituteMostRecentElement((-0.41023049431530567d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-2.975857228660455d));
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test273"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    boolean var7 = var0.isSupportUpperBoundInclusive();
    double var8 = var0.getStandardDeviation();
    double var9 = var0.getSupportUpperBound();
    double var10 = var0.getSupportLowerBound();
    double var12 = var0.density(0.3363717774100053d);
    double var13 = var0.getNumericalMean();
    boolean var14 = var0.isSupportUpperBoundInclusive();
    double var15 = var0.getSupportLowerBound();
    double var17 = var0.cumulativeProbability(232570.84495793137d);
    double var19 = var0.density(0.0d);
    double var20 = var0.getSupportUpperBound();
    boolean var21 = var0.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.3769994616483318d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.3989422804014327d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test274"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextUniform(2872.0d, 0.39518834996379976d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-12.859268542940052d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test275"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(22.95389613245281d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 23.0d);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test276"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(40422L, 17L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test277"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)12.968498074057063d);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test278"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(164, 0.0f, 2097152.2f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test279"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(192.9088122275434d);
//     double var12 = var0.nextExponential(0.7243407758924822d);
//     double var15 = var0.nextBeta(3.0139693382746255d, 0.4992246854372801d);
//     double var17 = var0.nextExponential(5.363952139253263d);
//     org.apache.commons.math3.distribution.IntegerDistribution var18 = null;
//     int var19 = var0.nextInversionDeviate(var18);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test280"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.3204734177704431d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test281"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     long var31 = var0.nextSecureLong(4L, 17L);
//     int var34 = var0.nextSecureInt(247, 1868);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.107945449080532d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5cf444c9b0"+ "'", var8.equals("5cf444c9b0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1954);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.008231818772828388d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-0.6632568688704717d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-0.7508001443795297d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.24748746648920894d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.2522078586338771d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 8.434573034566355E-40d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 13L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1417);
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test282"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-1.3148397497450302d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9963357452725248d);

  }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test283"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextUniform(0.2577047455984825d, 13.770182159584014d);
//     long var6 = var1.nextPoisson(23.012289905639566d);
//     int var9 = var1.nextZipf(10178, 0.5950413774252329d);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var10.reseedRandomGenerator(2L);
//     double[] var14 = var10.sample(100000);
//     double var15 = var10.getMean();
//     double var16 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     double var20 = var1.nextUniform(0.0d, 0.18579629985980917d, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 7.954239580503796d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 5273);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-0.6096080891858406d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.09159300731664433d);
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test284"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-0.03314181870292297d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0005492403435987d);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test285"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var9);
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var12, var14);
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test286"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(2187, 1834);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2187);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test287"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = var8.getTiesStrategy();
    java.lang.Class var10 = var9.getDeclaringClass();
    java.lang.String var11 = var9.toString();
    java.lang.String var12 = var9.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7, var9);
    int var14 = var7.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    java.lang.Class var16 = var7.getDeclaringClass();
    java.lang.Class var17 = var7.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "AVERAGE"+ "'", var11.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "AVERAGE"+ "'", var12.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test288"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.5499237247333157d, 0.1794257117280909d, 0.586968401150083d, (-623678255));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test289"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double var3 = var0.inverseCumulativeProbability(0.9999999999928669d);
    double var5 = var0.density(25.472636453138065d);
    double var6 = var0.getNumericalMean();
    boolean var7 = var0.isSupportLowerBoundInclusive();
    double var8 = var0.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 6.755176609774487d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5.055823438644928E-142d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test290"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
//     java.lang.Class var5 = var4.getDeclaringClass();
//     java.lang.Class var6 = var4.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
//     java.lang.String var8 = var4.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var10);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
//     java.lang.Class var14 = var13.getDeclaringClass();
//     java.lang.Class var15 = var13.getDeclaringClass();
//     boolean var17 = var13.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
//     org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var18.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var18.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var21 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var21);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var24 = var23.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var25 = var23.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var27 = var26.getTiesStrategy();
//     java.lang.Class var28 = var27.getDeclaringClass();
//     java.lang.Class var29 = var27.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var27);
//     java.lang.String var31 = var27.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var32 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var25, var27);
//     org.apache.commons.math3.distribution.NormalDistribution var33 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var34 = var33.getStandardDeviation();
//     double[] var36 = var33.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var37 = new org.apache.commons.math3.util.ResizableDoubleArray(var36);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var38 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var42 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var43 = new org.apache.commons.math3.util.ResizableDoubleArray(var42);
//     double[] var47 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var48 = new org.apache.commons.math3.util.ResizableDoubleArray(var47);
//     double var49 = var38.mannWhitneyU(var42, var47);
//     double var50 = var32.mannWhitneyUTest(var36, var42);
//     double[] var51 = var22.rank(var36);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var52 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var53 = var52.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var54 = var52.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var55 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var56 = var55.getTiesStrategy();
//     java.lang.Class var57 = var56.getDeclaringClass();
//     int var58 = var56.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var59 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var54, var56);
//     org.apache.commons.math3.random.RandomGenerator var60 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var61 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var54, var60);
//     org.apache.commons.math3.random.RandomGenerator var62 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var63 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var54, var62);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var64 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var54);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var65 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var66 = var65.getTiesStrategy();
//     java.lang.Class var67 = var66.getDeclaringClass();
//     java.lang.Class var68 = var66.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var69 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var54, var66);
//     org.apache.commons.math3.util.ResizableDoubleArray var70 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var70.contract();
//     org.apache.commons.math3.distribution.NormalDistribution var72 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var73 = var72.getStandardDeviation();
//     double[] var75 = var72.sample(1);
//     double var77 = var72.cumulativeProbability(0.0d);
//     double var78 = var72.getSupportUpperBound();
//     boolean var79 = var72.isSupportUpperBoundInclusive();
//     var72.reseedRandomGenerator((-16L));
//     double[] var83 = var72.sample(2297);
//     var70.addElements(var83);
//     double[] var85 = var69.rank(var83);
//     double var86 = var11.mannWhitneyUTest(var36, var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + "AVERAGE"+ "'", var31.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 4.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0.17971249487899976d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == 0.38317823503995163d);
// 
//   }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test291"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     var0.reSeed(6L);
//     double var12 = var0.nextExponential(17.412259994235388d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextWeibull(11.660038913667586d, (-0.4648175818707581d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.01646017909156d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "3d3e163e4b"+ "'", var8.equals("3d3e163e4b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 10.85264471496672d);
// 
//   }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test292"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(3.970219057649513d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6034639151230372d);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test293"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.22150320281102273d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4706412676455633d);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test294"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.exception.OutOfRangeException var17 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.15512025679417774d, (java.lang.Number)1.2471705263294632d, (java.lang.Number)0.0843874063990762d);
    boolean var18 = var2.equals((java.lang.Object)1.2471705263294632d);
    java.lang.Class var19 = var2.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var21 = java.lang.Enum.<java.lang.Enum>valueOf(var19, "50a51691c03cd9bb7426a9f75d17a17c917d3378437891b3ca5ab635bb2ffbdf6069f741e3b0371bd373283d4d005d8f2a74");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test295"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(96, 11394);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1093824);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test296"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.7187353997098677d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2696025041175751d);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test297"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-2.7193732266766655d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.2184129568812898d));

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test298"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getStandardDeviation();
//     double[] var13 = var10.sample(1);
//     double var15 = var10.cumulativeProbability(0.0d);
//     double var16 = var10.getSupportUpperBound();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     var0.reSeed();
//     double var21 = var0.nextGamma(0.0d, 6.621888603197341d);
//     int var24 = var0.nextSecureInt(3, 100000);
//     org.apache.commons.math3.distribution.IntegerDistribution var25 = null;
//     int var26 = var0.nextInversionDeviate(var25);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test299"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double[] var3 = var0.sample(10);
    double var4 = var0.getStandardDeviation();
    double var5 = var0.getMean();
    double var7 = var0.cumulativeProbability(57.29288593298371d);
    double var8 = var0.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test300"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 10.0f);
    var2.addElement(0.010050166663333094d);
    var2.clear();

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test301"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
    java.lang.Object var17 = null;
    boolean var18 = var4.equals(var17);
    var4.setElement(100, 0.0d);
    double[] var22 = var4.getInternalValues();
    int var23 = var4.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test302"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test303"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(100.00002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100);

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test304"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getStandardDeviation();
//     double[] var13 = var10.sample(1);
//     double var15 = var10.cumulativeProbability(0.0d);
//     double var16 = var10.getSupportUpperBound();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     double var20 = var0.nextUniform((-0.46723055192344254d), 0.004492688352124083d);
//     int var23 = var0.nextBinomial(1952, 0.7625552649455967d);
//     double var26 = var0.nextWeibull(0.3613755384667159d, 4.252640503606456d);
//     int var29 = var0.nextSecureInt((-933400799), 9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var31 = var0.nextPoisson((-2.0073159449835396d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0345355918535366d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.24449744575367197d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-0.32033001754681073d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1490);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.7331693360283985d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == (-265381860));
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test305"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.5000005f, (-0.9037815823889354d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5000002f);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test306"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.9999987388901819d);
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException(var2);
    var1.addSuppressed((java.lang.Throwable)var3);
    java.lang.String var5 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (null) exceeded"+ "'", var5.equals("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (null) exceeded"));

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test307"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1.9870324860653736d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.4043208515655084d));

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test308"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.027234753583409273d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0003708888255274d);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test309"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(0.16952774032729226d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6987678206966943d);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test310"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(2021657077002043406L, 1611200L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test311"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-231249447L), 297L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-68681085759L));

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test312"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(315.2723610714864d, 53.69538586542132d, 70.76805765837116d);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test313"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(short)1, var1, false);
    java.lang.Number var4 = var3.getMax();
    java.lang.Number var5 = var3.getMax();
    java.lang.Throwable[] var6 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test314"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(3.791046411301009d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999173973604d);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test315"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.4530491401698906d, (java.lang.Number)0.857736258406415d, false);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test316"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     var0.reSeed(6L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 20.157560900834664d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "a9b69c13fd"+ "'", var8.equals("a9b69c13fd"));
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test317"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.9999999987705535d, 2027.861907575249d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999975068552912d);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test318"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(7.755593766437044E65d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 152.40959258449737d);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test319"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.384186E-7f, 2097152.2f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2097152.2f);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test320"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(8.854558633913316d, 3.1173466159040992d);
    boolean var3 = var2.isSupportConnected();
    double[] var5 = var2.sample(13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test321"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(2041);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test322"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.clear();
    float var8 = var6.getExpansionFactor();
    var6.setContractionCriteria(2.0f);
    float var11 = var6.getContractionCriteria();
    var6.addElement((-0.27924610171153436d));
    var6.contract();
    var6.setElement(11122, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test323"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    org.apache.commons.math3.distribution.NormalDistribution var8 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var9 = var8.getSupportUpperBound();
    boolean var10 = var4.equals((java.lang.Object)var9);
    var4.setNumElements(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test324"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.5000002f, 2097152.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2097152.5f);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test325"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-0.6991346750676082d), 1.445343853698748d, 0.15264401491200186d);
    double var4 = var3.getNumericalVariance();
    double var6 = var3.cumulativeProbability((-1.472086343694072d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0890188554247477d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.29639844152031597d);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test326"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(23.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.8281684713331012d);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test327"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(35.18478424589681d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7249341929013728d);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test328"); }


    double[] var3 = new double[] { 0.0d, (-1.0d), 0.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var6 = var5.getStandardDeviation();
    double[] var8 = var5.sample(1);
    double var9 = var5.getMean();
    double[] var11 = var5.sample(100);
    var4.addElements(var11);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var4.copy();
    var4.addElement(0.9999494957997512d);
    double var17 = var4.substituteMostRecentElement(12.770914443685303d);
    float var18 = var4.getContractionCriteria();
    float var19 = var4.getExpansionFactor();
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var21 = var4.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.9999494957997512d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test329"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
    java.lang.Object var17 = null;
    boolean var18 = var4.equals(var17);
    var4.setElement(100, 0.0d);
    int var22 = var4.getExpansionMode();
    var4.setElement(10620, 22.877003894887903d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test330"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     double var9 = var0.nextGamma(9.319248049587957d, (-0.4255538433808183d));
//     long var11 = var0.nextPoisson(0.9978516012375751d);
//     double var13 = var0.nextExponential(14.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.5857166250962631d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-7.2241299233030105d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 27.953537675509402d);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test331"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test332"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)14.440916910074137d, (java.lang.Number)2.9667411161580297d, false);
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.004259538447620046d, (java.lang.Number)(-0.18719238578460362d), false);
    var4.addSuppressed((java.lang.Throwable)var8);
    java.lang.Number var10 = var8.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (-0.18719238578460362d)+ "'", var10.equals((-0.18719238578460362d)));

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test333"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(18L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test334"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(16L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16L);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test335"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(100.000015f, 0.9999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.000015f);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test336"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var8 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var4, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test337"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(6.407357880391434d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 605.2896731702729d);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test338"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.1368684E-13f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test339"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-1.765071985168704d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.082403154357515d);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test340"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(137, 243);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 243);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test341"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(4.6566128730773926E-10d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.6566128730773926E-10d);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test342"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     java.lang.String var13 = var0.nextHexString(10);
//     var0.reSeedSecure();
//     double var17 = var0.nextBeta(20441.91590500824d, 11.711799887012498d);
//     double var20 = var0.nextWeibull(21.78619629460335d, 1.5120484726447734d);
//     var0.reSeed(11L);
//     var0.reSeed(50761728L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var27 = var0.nextLong(40318L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.447745598635891d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5be1787ca3"+ "'", var8.equals("5be1787ca3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "3318a124b6"+ "'", var13.equals("3318a124b6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.9995622384167101d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.4684476469790577d);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test343"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, (-1.458894958782291d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test344"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(163824380L, 70L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 70L);

  }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test345"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var21 = var18.nextSecureLong((-1L), 1L);
//     double var24 = var18.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var26 = var18.nextSecureHexString(100);
//     double var28 = var18.nextT(20.696514663540924d);
//     org.apache.commons.math3.distribution.NormalDistribution var29 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var30 = var29.getStandardDeviation();
//     double[] var32 = var29.sample(1);
//     double var33 = var29.getMean();
//     double[] var35 = var29.sample(100);
//     double var36 = var29.sample();
//     double var37 = var29.sample();
//     double var38 = var18.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     double var39 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     org.apache.commons.math3.distribution.NormalDistribution var40 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var41 = var40.getStandardDeviation();
//     double[] var43 = var40.sample(1);
//     double var44 = var40.getMean();
//     double[] var46 = var40.sample(100);
//     double var47 = var40.sample();
//     double var48 = var40.sample();
//     var40.reseedRandomGenerator(10L);
//     boolean var51 = var40.isSupportLowerBoundInclusive();
//     boolean var52 = var40.isSupportLowerBoundInclusive();
//     double var53 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var40);
//     java.lang.String var55 = var0.nextHexString(1907);
//     double var57 = var0.nextExponential(2.235826316117689d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.973332767592167d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f6d4a0b48c351a6b452ffaa28f6e70e5103bf0e943b81c9bdb98731f4b69a23e855aa0dfc9ab87032a6c9f4621703783c1da"+ "'", var8.equals("f6d4a0b48c351a6b452ffaa28f6e70e5103bf0e943b81c9bdb98731f4b69a23e855aa0dfc9ab87032a6c9f4621703783c1da"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.03871822046844357d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 19.189018017917366d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "6c1ef08bba79c756b66c5f7507279ecca1512dd87ac6d71e81219f0844312619fd1cb1fe258426e15fba9df29aea6798ba9a"+ "'", var26.equals("6c1ef08bba79c756b66c5f7507279ecca1512dd87ac6d71e81219f0844312619fd1cb1fe258426e15fba9df29aea6798ba9a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.9923200855574594d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0.43640377908370515d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == (-0.19618663951452156d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == (-0.7783855961514757d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0.7804998782562619d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1.4034839509994628d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == (-0.3659799871598735d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == (-2.0085134460594767d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var55 + "' != '" + "0f4ac7b374046853773fa23f0c2bdf1612f9efe160ea97361aa55869a6f874ece8c55e502c7cb4fffe11011bf2158c9525c79cd14fcca73edd236fee3768be7a8151436166abc8fbcb02d930ec25590375d24a0b479bfb19c8d93647c8084ea89f67bcb422e22f26bc6afa46ab6b70188dd2e3eccbd57291cb48322fa093a91970d0fb074194fceffe540af2e0f61f0492cdb45d8bf5ab479f447bf9256f5e2cc76e331ba2e6586d604254c8c2b020ba64cb7e02688e7cd3307e3f728f59a8bca98d1b4a6c54bb72a5c61f45dbbbcd60e3ded3a580c70c49b94ca15351eb9a0aff4f1097f23caac3925d36831e06fbb9b4f995e80dd2c16d7abbf791ddb43155c1dd0967ac700ca0fda80691572de35cfdd8a5edf1626a4d9616d4673e622a0424e5e05955ac49abf778af89a3af3acbeb01deb1732822b6d3f92f133c4e5ae35a8afe5edfb3250960d1108df08d5c5f80107898310d5bd128f34a79ac85af559ac244c5ace92ef69ac86c59e8420fa91c582033a7d8ccb717a41270762a394ebc29349142e70d3c06719b74e2eefd7dd67474c0364987edfd10f7549261c201712aa58fca2e1e508a7172d9fcdc139fbf4cbc6cb90c8294c96f2dbc4105f1862846a2f60efeeaad1c3e291d8b1f78722f2e24d6701627f9892146d94852e7006c88cf03f73a6f518b894821650e7d82568d563a93b4590261a66060497b321f7ed64959977bc1b579b9d6619a1ebd0aa74689fb9ed1edc07e5649dacc0cbbe9c6351d0ac90f2c4735a6f1711ecab31012718f80bbd69423894838881958ce454c208e83e8bbbaa03583694be5cb7a6764d78662d3bcec37d6073e12bf6ae681868de3bea94df2ded61c2d4028676642b2b125ee8a9ad721b345c26f377ff4136ca30d3f2ce03a9d88043240ea5475aa07bd02962e541db078298f08176de3eb9bdb8ab33d21fd177428ffe302f4a82b8ccb6b1e9c228b24b2b040989be07442563bda07206d69a978582412516188d6c898baa9589131d09e869cd34043e913f1decfba9e50f473d23694b40e1a14ac60e3f975ffd4d9e14b96cf4e5c4dc0881c535eb3992e806b634e712c68cfc4b7e1315bfe5f66c04584dbdc2e85bb441f5de899cecf88393b2ee70be52e4bbc3c4e4edd4f53a348c38274239fe34f122ffe1aa7c3416f88af970f26889336e47273f7264caac5b9d39a4c5fab015137cdc65d511cb08974102277fcc7953f1d1742154b531bea7d81cb913bf2566729c43da43a2d20325f551676fcb1e256075b1aedb20482b34b93f637b59344ce5c580450347dda7405e1edfb096e35e625d538742cc544b42e01cab"+ "'", var55.equals("0f4ac7b374046853773fa23f0c2bdf1612f9efe160ea97361aa55869a6f874ece8c55e502c7cb4fffe11011bf2158c9525c79cd14fcca73edd236fee3768be7a8151436166abc8fbcb02d930ec25590375d24a0b479bfb19c8d93647c8084ea89f67bcb422e22f26bc6afa46ab6b70188dd2e3eccbd57291cb48322fa093a91970d0fb074194fceffe540af2e0f61f0492cdb45d8bf5ab479f447bf9256f5e2cc76e331ba2e6586d604254c8c2b020ba64cb7e02688e7cd3307e3f728f59a8bca98d1b4a6c54bb72a5c61f45dbbbcd60e3ded3a580c70c49b94ca15351eb9a0aff4f1097f23caac3925d36831e06fbb9b4f995e80dd2c16d7abbf791ddb43155c1dd0967ac700ca0fda80691572de35cfdd8a5edf1626a4d9616d4673e622a0424e5e05955ac49abf778af89a3af3acbeb01deb1732822b6d3f92f133c4e5ae35a8afe5edfb3250960d1108df08d5c5f80107898310d5bd128f34a79ac85af559ac244c5ace92ef69ac86c59e8420fa91c582033a7d8ccb717a41270762a394ebc29349142e70d3c06719b74e2eefd7dd67474c0364987edfd10f7549261c201712aa58fca2e1e508a7172d9fcdc139fbf4cbc6cb90c8294c96f2dbc4105f1862846a2f60efeeaad1c3e291d8b1f78722f2e24d6701627f9892146d94852e7006c88cf03f73a6f518b894821650e7d82568d563a93b4590261a66060497b321f7ed64959977bc1b579b9d6619a1ebd0aa74689fb9ed1edc07e5649dacc0cbbe9c6351d0ac90f2c4735a6f1711ecab31012718f80bbd69423894838881958ce454c208e83e8bbbaa03583694be5cb7a6764d78662d3bcec37d6073e12bf6ae681868de3bea94df2ded61c2d4028676642b2b125ee8a9ad721b345c26f377ff4136ca30d3f2ce03a9d88043240ea5475aa07bd02962e541db078298f08176de3eb9bdb8ab33d21fd177428ffe302f4a82b8ccb6b1e9c228b24b2b040989be07442563bda07206d69a978582412516188d6c898baa9589131d09e869cd34043e913f1decfba9e50f473d23694b40e1a14ac60e3f975ffd4d9e14b96cf4e5c4dc0881c535eb3992e806b634e712c68cfc4b7e1315bfe5f66c04584dbdc2e85bb441f5de899cecf88393b2ee70be52e4bbc3c4e4edd4f53a348c38274239fe34f122ffe1aa7c3416f88af970f26889336e47273f7264caac5b9d39a4c5fab015137cdc65d511cb08974102277fcc7953f1d1742154b531bea7d81cb913bf2566729c43da43a2d20325f551676fcb1e256075b1aedb20482b34b93f637b59344ce5c580450347dda7405e1edfb096e35e625d538742cc544b42e01cab"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 2.009443091592908d);
// 
//   }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test346"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.912933013825568d);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    java.lang.Number var3 = var1.getMin();
    java.lang.String var4 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: 0.913 is smaller than the minimum (0)"+ "'", var4.equals("org.apache.commons.math3.exception.NotPositiveException: 0.913 is smaller than the minimum (0)"));

  }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test347"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "");
// 
//   }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test348"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.6072369230342884d);

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test349"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     var0.reSeed(104L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var0.nextUniform(14.15297235332853d, 1.4981750218488439d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9.433466731910082d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "604d902f72"+ "'", var8.equals("604d902f72"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1825);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5.094978314757722E-4d);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test350"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    var0.reseedRandomGenerator(4L);
    double var5 = var0.cumulativeProbability(0.22232122610396474d);
    var0.reseedRandomGenerator(29L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var0.cumulativeProbability(0.3989108589797407d, (-1.5192433191631562d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5879680852503826d);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test351"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)87491968L);

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test352"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var12 = var0.nextT(3.7945526405881016d);
//     var0.reSeed(1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextBinomial(312, (-0.7145944252763202d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 35.9170596400981d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ee92a7331e"+ "'", var8.equals("ee92a7331e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.3753719233812826d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.9342031874663157d);
// 
//   }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test353"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-536829416L), 410338673L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 220281870188804968L);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test354"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.14608902069952245d);

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test355"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     double var10 = var0.nextT(20.696514663540924d);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var11.getStandardDeviation();
//     double[] var14 = var11.sample(1);
//     double var15 = var11.getMean();
//     double[] var17 = var11.sample(100);
//     double var18 = var11.sample();
//     double var19 = var11.sample();
//     double var20 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     double var23 = var0.nextGamma(2.072824599916719d, 4.506607388944759d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9.704448634536254d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "90fde5a62a29888481652590920a17c02b17653bc6a00a6511782741741c11d88393f292ccfdcf13c3ab4de458b1f216c1c0"+ "'", var8.equals("90fde5a62a29888481652590920a17c02b17653bc6a00a6511782741741c11d88393f292ccfdcf13c3ab4de458b1f216c1c0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.6581797681983824d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.2588912806198367d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.4181576738851787d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-1.3829737826649213d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.871775198863279d);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test356"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 336L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 2388144625711178067L);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 1935);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, (-21428512432588800L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test357"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.discardMostRecentElements(1);
    int var15 = var4.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    int var17 = var16.getNumElements();
    double[] var18 = var16.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test358"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(16.35282631844513d, 6.579251212010101d, 1.0002809834262205d);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test359"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-4.440892098500626E-16d), 1.1102230246251565E-16d, 0.9999494957997512d);
    double var4 = var3.getMean();
    double var6 = var3.density(100.0d);
    double var7 = var3.getSupportUpperBound();
    boolean var8 = var3.isSupportLowerBoundInclusive();
    double[] var10 = var3.sample(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-4.440892098500626E-16d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test360"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(3.1173466159040992d);
    double var4 = var0.addElementRolling(0.4992246854372801d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test361"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(1.0003708888255274d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0003708888255276d);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test362"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.9999999f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9999998f));

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test363"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getNumericalVariance();
    double var2 = var0.getNumericalVariance();
    double var3 = var0.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test364"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.9999999f, (-8904));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test365"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(Float.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0f));

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test366"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var4 = var0.getSupportLowerBound();
    var0.reseedRandomGenerator((-2L));
    boolean var7 = var0.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test367"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     java.lang.Class var2 = var1.getDeclaringClass();
//     java.lang.Class var3 = var1.getDeclaringClass();
//     boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var9 = var8.getTiesStrategy();
//     java.lang.Class var10 = var9.getDeclaringClass();
//     java.lang.String var11 = var9.toString();
//     java.lang.String var12 = var9.toString();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7, var9);
//     java.lang.Class var14 = var7.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var17 = var15.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var19 = var18.getTiesStrategy();
//     java.lang.Class var20 = var19.getDeclaringClass();
//     int var21 = var19.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var19);
//     org.apache.commons.math3.random.RandomGenerator var23 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var23);
//     org.apache.commons.math3.random.RandomGenerator var25 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var25);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var29 = var28.getTiesStrategy();
//     java.lang.Class var30 = var29.getDeclaringClass();
//     java.lang.Class var31 = var29.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var29);
//     org.apache.commons.math3.random.RandomGenerator var33 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var33);
//     org.apache.commons.math3.distribution.NormalDistribution var35 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var36 = var35.getStandardDeviation();
//     double[] var38 = var35.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var39 = new org.apache.commons.math3.util.ResizableDoubleArray(var38);
//     var39.setElement(11, 0.5322866968936354d);
//     double var44 = var39.addElementRolling(1.5498468927479463d);
//     float var45 = var39.getExpansionFactor();
//     org.apache.commons.math3.util.ResizableDoubleArray var48 = new org.apache.commons.math3.util.ResizableDoubleArray(1919, 100.00001f);
//     org.apache.commons.math3.util.ResizableDoubleArray var49 = new org.apache.commons.math3.util.ResizableDoubleArray(var48);
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var39, var48);
//     boolean var51 = var17.equals((java.lang.Object)var48);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var52 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var53 = var52.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var54 = var52.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var55 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var56 = var55.getTiesStrategy();
//     java.lang.Class var57 = var56.getDeclaringClass();
//     int var58 = var56.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var59 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var54, var56);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var60 = var59.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var61 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var62 = var61.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var63 = var61.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var64 = var61.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var65 = var61.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var66 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var67 = var66.getTiesStrategy();
//     boolean var69 = var67.equals((java.lang.Object)Double.POSITIVE_INFINITY);
//     boolean var71 = var67.equals((java.lang.Object)(-0.4255538433808183d));
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var72 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var65, var67);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var73 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var60, var67);
//     org.apache.commons.math3.random.RandomGenerator var74 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var75 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var60, var74);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var76 = var75.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var77 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var78 = var77.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var79 = var77.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var80 = var77.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var81 = var77.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var82 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var81);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var83 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var84 = var83.getTiesStrategy();
//     java.lang.Class var85 = var84.getDeclaringClass();
//     java.lang.Class var86 = var84.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var87 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var84);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var88 = var87.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var89 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var81, var88);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var90 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var76, var88);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var91 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var92 = var91.getTiesStrategy();
//     java.lang.Class var93 = var92.getDeclaringClass();
//     java.lang.String var94 = var92.toString();
//     java.lang.String var95 = var92.toString();
//     java.lang.Class var96 = var92.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var97 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var76, var92);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var98 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var92);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var99 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var7, var92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "AVERAGE"+ "'", var11.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "AVERAGE"+ "'", var12.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == (-1.170079749363841d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var94 + "' != '" + "AVERAGE"+ "'", var94.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var95 + "' != '" + "AVERAGE"+ "'", var95.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var96);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test368"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    var1.setNumElements(11274);
    int var4 = var1.start();
    double var6 = var1.getElement(9181);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setNumElements((-388134638));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test369"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test370"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.0030728678011815447d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0030728726371179924d);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test371"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.8147655203522769d, (java.lang.Number)1.004502795607019d, var3);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test372"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 243);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 76L);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 20355937);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 1999);
    java.math.BigInteger var15 = null;
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 0L);
    java.math.BigInteger var18 = null;
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 0L);
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, var20);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, var20);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var23 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test373"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(2.151369527912593d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.466754760657893d);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test374"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1940, (java.lang.Number)30.200159778529517d, true);
    java.lang.Number var4 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var4, (java.lang.Number)0.009999999583352414d, true);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var7);
    var3.addSuppressed((java.lang.Throwable)var8);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test375"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(100.00002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test376"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-0.4043208515655084d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.3325700590307031d));

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test377"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.1368684E-13f, 5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1368684E-13f);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test378"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(242, 12767);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 12767);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test379"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1, 50);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test380"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 8435);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test381"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var6, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var11 = var10.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var4, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathArithmeticException var14 = new org.apache.commons.math3.exception.MathArithmeticException(var3, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MaxCountExceededException var15 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, var2, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathArithmeticException var16 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test382"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.7440848746643383d), (java.lang.Number)(-0.03561286880569323d), false);
    boolean var5 = var4.getBoundIsAllowed();
    java.lang.Number var6 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-0.7440848746643383d)+ "'", var6.equals((-0.7440848746643383d)));

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test383"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.1368684E-13f, 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1368684E-13f);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test384"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(16.872851798277587d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test385"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-0.8652627755109201d));

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test386"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.4326917822693235d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test387"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(1093824);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test388"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
    boolean var10 = var8.equals((java.lang.Object)(-1.737874520729035d));
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    boolean var14 = var12.equals((java.lang.Object)Double.POSITIVE_INFINITY);
    boolean var16 = var12.equals((java.lang.Object)(-0.4255538433808183d));
    java.lang.String var17 = var12.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var12);
    org.apache.commons.math3.random.RandomGenerator var19 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "AVERAGE"+ "'", var17.equals("AVERAGE"));

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test389"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)0.17994611088998624d, true);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.17994611088998624d+ "'", var5.equals(0.17994611088998624d));

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test390"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.26495626491431057d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.27133559887761494d);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test391"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(14.27900880653991d, 0.39954907087939356d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.3450511334673709d));

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test392"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(3);
    float var2 = var1.getContractionCriteria();
    var1.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var4);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5f);

  }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test393"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(5.16119964964749d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test394"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.1908427023981165d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test395"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var4 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    double[] var9 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    double var11 = var0.mannWhitneyU(var4, var9);
    org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var13 = var12.getStandardDeviation();
    double[] var15 = var12.sample(1);
    double var17 = var12.cumulativeProbability(0.0d);
    double var18 = var12.getSupportUpperBound();
    boolean var19 = var12.isSupportUpperBoundInclusive();
    var12.reseedRandomGenerator((-16L));
    double[] var23 = var12.sample(2297);
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var24.contract();
    org.apache.commons.math3.distribution.NormalDistribution var26 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var27 = var26.getStandardDeviation();
    double[] var29 = var26.sample(1);
    double var31 = var26.cumulativeProbability(0.0d);
    double var32 = var26.getSupportUpperBound();
    boolean var33 = var26.isSupportUpperBoundInclusive();
    var26.reseedRandomGenerator((-16L));
    double[] var37 = var26.sample(2297);
    var24.addElements(var37);
    org.apache.commons.math3.util.ResizableDoubleArray var39 = new org.apache.commons.math3.util.ResizableDoubleArray(var37);
    double[] var40 = var39.getElements();
    double var41 = var0.mannWhitneyU(var23, var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 4.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 2638104.5d);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test396"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-64L), 6379912561590279263L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6379912561590279263L);

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test397"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getSupportUpperBound();
//     double[] var3 = var0.sample(10);
//     double var4 = var0.getStandardDeviation();
//     double var5 = var0.getStandardDeviation();
//     double var6 = var0.getNumericalVariance();
//     double var7 = var0.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.01792856675859498d);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test398"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.8534355569162965d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.014895260421780838d);

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test399"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var14 = var0.nextGamma(0.15861286098539223d, 23.79178096943456d);
//     double var16 = var0.nextChiSquare(3.730894643928354d);
//     double var19 = var0.nextCauchy(0.0d, 0.5231370181288907d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.3132444326796d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ee68da3049"+ "'", var8.equals("ee68da3049"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3.0832180245508605d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 4.384834352200721d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.2743237561163872d);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test400"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.20715850648830503d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0036155980117349587d);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test401"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(17.18697259560036d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.580673891809727d);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test402"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var9.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
    java.lang.Class var14 = var13.getDeclaringClass();
    java.lang.Class var15 = var13.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    java.lang.String var17 = var13.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var11, var13);
    boolean var20 = var13.equals((java.lang.Object)4.950886585270677E-4d);
    java.lang.Class var21 = var13.getDeclaringClass();
    java.lang.Object var22 = null;
    boolean var23 = var13.equals(var22);
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var13);
    int var25 = var8.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "AVERAGE"+ "'", var17.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test403"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(6.694390071933187E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32.94338698421849d);

  }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test404"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     var0.reSeed(4L);
//     double var8 = var0.nextGaussian(0.7625552649455967d, 0.15512025679417774d);
//     long var11 = var0.nextSecureLong(20L, 104L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextBinomial(1073741825, (-1.0061810290320632d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8988590862390544d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 75L);
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test405"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, 22.831894383871205d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test406"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var13 = var0.nextChiSquare(3.5256464698322323d);
//     double var16 = var0.nextBeta(0.4663611619490422d, 0.595174897105027d);
//     var0.reSeed();
//     long var19 = var0.nextPoisson(0.20584945432845803d);
//     long var22 = var0.nextSecureLong(704L, 1544L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.377528539087445d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "3e6c95217e"+ "'", var8.equals("3e6c95217e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.17466859836812323d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.9260205340160991d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 920L);
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test407"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.9999998f, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9999998f);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test408"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)12.00123591003164d);

  }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test409"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(25.191221182738687d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test410"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var9.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var9.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var9.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var14.getTiesStrategy();
    boolean var17 = var15.equals((java.lang.Object)Double.POSITIVE_INFINITY);
    boolean var19 = var15.equals((java.lang.Object)(-0.4255538433808183d));
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var20 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var13, var15);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var8, var15);
    org.apache.commons.math3.random.RandomGenerator var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var22);
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = var23.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var25 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24, var25);
    org.apache.commons.math3.stat.ranking.NaNStrategy var27 = var26.getNanStrategy();
    java.lang.String var28 = var27.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "MAXIMAL"+ "'", var28.equals("MAXIMAL"));

  }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test411"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-4.440892098500627E-16d));
//     java.lang.Number var3 = var2.getMin();
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var8 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var4, (java.lang.Number)0.15729920705028488d, (java.lang.Number)(short)(-1), false);
//     java.lang.Number var9 = var8.getMax();
//     var2.addSuppressed((java.lang.Throwable)var8);
//     boolean var11 = var2.getBoundIsAllowed();
//     java.lang.String var12 = var2.toString();
// 
//   }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test412"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(11.55032987240487d, 192);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.250259568636123E58d);

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test413"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getSupportUpperBound();
//     double[] var3 = var0.sample(10);
//     double var4 = var0.getStandardDeviation();
//     double var5 = var0.getStandardDeviation();
//     double var6 = var0.getNumericalVariance();
//     double var7 = var0.getNumericalVariance();
//     double var9 = var0.probability(0.9999999999999925d);
//     double var11 = var0.probability(3.0741607150885346d);
//     boolean var12 = var0.isSupportConnected();
//     double var14 = var0.cumulativeProbability((-1.6804163900380429d));
//     double var15 = var0.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.046438164661925074d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.31766742680122395d));
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test414"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1852, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test415"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(2019, 17018);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test416"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, 2021657077002043406L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test417"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(3.036639605320504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.994497482530301d));

  }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test418"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     int var11 = var0.nextZipf(5, 0.8273572477024794d);
//     int var14 = var0.nextBinomial(1972, 0.15795521463156686d);
//     double var17 = var0.nextGaussian(3.4456677746279425d, 3.02837877258525d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var0.nextHypergeometric((-2123201639), 1852, 9813);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 20.543159116766475d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "b203a6b7d71b89f4406c0fa04ee5d8fdd794de0aa9fb1099b22474d24f9b6305773d93ddc0b8abf6b462dcc098acb0af6b4b"+ "'", var8.equals("b203a6b7d71b89f4406c0fa04ee5d8fdd794de0aa9fb1099b22474d24f9b6305773d93ddc0b8abf6b462dcc098acb0af6b4b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 301);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.10814858437182462d);
// 
//   }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test419"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NotPositiveException var4 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test420"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(13L, 17L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 30L);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test421"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-4), (java.lang.Number)571.8440515901871d, false);

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test422"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(2.6589528439081977d, (-0.2687601283548028d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test423"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var12 = var9.nextSecureLong((-1L), 1L);
//     double var15 = var9.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var17 = var9.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var18 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var19 = var9.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var18);
//     double var20 = var18.sample();
//     double var22 = var18.probability(7.444490968701611d);
//     double var23 = var18.getSupportUpperBound();
//     double[] var25 = var18.sample(9694);
//     double var26 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 36.43752831783069d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5f69011bd7a7d09630c4ce398ac89aedcd4dcd79191712c9f438cd967a5c6ab4e58f2d8f13cba44f7fb0b6a4390c728ba100"+ "'", var8.equals("5f69011bd7a7d09630c4ce398ac89aedcd4dcd79191712c9f438cd967a5c6ab4e58f2d8f13cba44f7fb0b6a4390c728ba100"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 3.2762374564602728d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "38f6ed8488"+ "'", var17.equals("38f6ed8488"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.5319714380397166d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-2.3485737667755684d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.3482647126855796d);
// 
//   }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test424"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(2019, (-1912));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test425"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-388134638), 8512);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-388134638));

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test426"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var8, var11);
    org.apache.commons.math3.random.RandomGenerator var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var15);
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    java.lang.Class var19 = var18.getDeclaringClass();
    java.lang.Class var20 = var18.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    java.lang.String var22 = var18.name();
    java.lang.String var23 = var18.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var24 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var8, var18);
    org.apache.commons.math3.stat.ranking.NaNStrategy var25 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var26 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var28 = var27.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var26, var28);
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25, var28);
    java.lang.String var31 = var28.name();
    java.lang.String var32 = var28.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var28);
    org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var28);
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var28);
    java.lang.Class var36 = var28.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "AVERAGE"+ "'", var22.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "AVERAGE"+ "'", var23.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "AVERAGE"+ "'", var31.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "AVERAGE"+ "'", var32.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test427"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(10.0f, 2097152.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2097152.5f);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test428"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double[] var15 = var4.getElements();
    double[] var16 = var4.getElements();
    var4.setElement(0, (-1.0328453233143338d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test429"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.0069113723948844d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.737133958452662d);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test430"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(8012);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test431"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.6351254179184792d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6309226549439975d);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test432"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    java.lang.String var6 = var1.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test433"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(5.9905031793799945E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.759558987950958E-6d);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test434"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.1752011936438014d, (java.lang.Number)0.1586128609853922d, false);
    java.lang.Number var4 = var3.getMax();
    java.lang.Number var5 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.1586128609853922d+ "'", var4.equals(0.1586128609853922d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.1752011936438014d+ "'", var5.equals(1.1752011936438014d));

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test435"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("3a4381e8742159982f47bafb4fe6655ce8947bade958372bd582ca4733da49aea8259a3c5ac9dbeabe634044d79c3419cac1");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test436"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(4.625610117464785d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5316082795537511d);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test437"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.22881246163275917d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test438"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.5395119302779527d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test439"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(2876240, 1905);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test440"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(7.651239741308825d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7660874428168074d);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test441"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var3);
    java.lang.String var6 = var3.name();
    java.lang.Class var7 = var3.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var9 = java.lang.Enum.<java.lang.Enum>valueOf(var7, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test442"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1999, (java.lang.Number)(byte)10, (java.lang.Number)1.1368684E-13f);
    java.lang.Number var8 = var7.getLo();
    java.lang.Number var9 = var7.getHi();
    java.lang.Throwable[] var10 = var7.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MaxCountExceededException var13 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)119986, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (byte)10+ "'", var8.equals((byte)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 1.1368684E-13f+ "'", var9.equals(1.1368684E-13f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test443"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(0, 1868);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test444"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.9930417854426408d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test445"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     int var7 = var6.getNumElements();
//     double var9 = var6.substituteMostRecentElement(31.862892444737472d);
//     double var11 = var6.substituteMostRecentElement(1929.4784382564899d);
//     var6.contract();
//     var6.setNumElements(181);
//     org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1.5327843900232268d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 31.862892444737472d);
// 
//   }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test446"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.780425831130733d, 0.5161386605871523d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1353209461385806d);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test447"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var6 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)(-0.3790949569766503d), (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.11285104189224116d, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException();
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var13);
    java.lang.Throwable[] var15 = var14.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var16 = new org.apache.commons.math3.exception.MathInternalError(var12, (java.lang.Object[])var15);
    org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var11, (java.lang.Object[])var15);
    var10.addSuppressed((java.lang.Throwable)var17);
    org.apache.commons.math3.exception.util.ExceptionContext var19 = var10.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test448"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(64, 2.3841864E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test449"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
//     java.lang.Class var5 = var4.getDeclaringClass();
//     int var6 = var4.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
//     org.apache.commons.math3.random.RandomGenerator var8 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
//     org.apache.commons.math3.random.RandomGenerator var10 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
//     java.lang.Class var15 = var14.getDeclaringClass();
//     java.lang.Class var16 = var14.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var14);
//     double[] var18 = null;
//     double[] var19 = var17.rank(var18);
// 
//   }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test450"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(363.7393755555636d, 0.059233998853640384d);
//     double var3 = var2.sample();
//     double var5 = var2.probability(14.738220481169323d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 363.5884943508753d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test451"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.9978516012375751d, 6.847746722572357d, 0.3204734177704431d);
    double var4 = var3.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 46.891635176500465d);

  }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test452"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     double var30 = var0.nextExponential(1.0471975511965979d);
//     java.lang.String var32 = var0.nextSecureHexString(1916);
//     double var35 = var0.nextBeta(2.5078368197853713d, 0.2555837818987815d);
//     int var38 = var0.nextZipf(2426, 0.9198491443997944d);
//     double var41 = var0.nextWeibull(0.6081011993472895d, 20441.91590500824d);
//     double var44 = var0.nextWeibull(2.5517620356803065E-188d, 7.828868808724949d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.06283986768932649d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "51983e71a2"+ "'", var8.equals("51983e71a2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1955);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.01862729251645943d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-0.6531370403470433d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1.3783576819621723d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-0.13768621942622777d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.654362721199478d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 2.3724083113547127E-35d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 0.5583472358423887d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var32 + "' != '" + "1fdfafbe07c1e102ccd84f50de95cbb9c1936d2c1f8b79b178437e5e4838de91dbca9b3f63f49be1d47dc8aa078972c481431372dabf6613c3540f4a89e533022d424ffe08493f1316ad58473d6f7ba4e1794df0201d9c221ca419c0c62a59bbf19f9c4498e3883b65f30dce055a1fe45d6d56cd6d06c096960f1b6b733c0fc8e16fb3f13d7102fd1d43822471985dd69bf420ea9d936df3d7521a4990c94205239e4ce30672b0ed7801e84d9afded657b1acd6a01d36caa4f54b14f8cb90fa06c48d1a3b67c5ee671fb872b780cd7c9f1eecdc088decd027baee883b24cb45ddb75de448c8c496e5637f911de0997b73454b3b272818ab822125042e2905c2bec310b03d05546f14029ac2cfad25341f75125393fcee99e02d48d6314f76338cd049ff37787137624a11caa5457340e3b810fbeb019deaac0f9fb17ed0ea26305f2dece8c73f80869ac1feb513f66fa9b081ebbf193d2d8932c8212a4664a965810d44d535b11ebd34773488cb6aee2dd159063abbc434a9014cbbaa0c6f8f4877c10be99cb8b81c31e0b915794fe6ee9882681c6db27a6d57dbfa492282a1ba4f493b72aa9ab7215d839f78d03ac173840ed941aedadd324ba995ac3a1773ebb01f330a5b58b54bbab93eca4b78a86eacec805b42ee584b09fc78b1c2895f18bf87ba53e86f3179b2400f2140eefecad8492de929266b1e86d1c8102254dab1d318422a5623a0e466b97431b868df29e7b403b99cabe16602c634b0bba017f845daa1e41170ba600660695a0058dae7783689ffbb679c55c381a65196358374c02178b4cf8660179686bc3556c47b715ee7e4f20f4a1149870a4254e3e4b70f54ddc7e497ec01e3ba65139774262438a04fcce159d3ff1b10a289b9c7153e44f6f04ed4331664a6219aa0e67b160d1407a1799b9ea55f14eb88361ab7e7bd683afb06681671aefc684438d60ec9f98c70a3a24a61b3fdca4a9204963f4bfafab01af217ea9b53883e24edd6afeedbefd51b4da8af877c3ab42b477630bc768b9c4611c1c6643b9dc677ae56f00fe4885476a2f0d504859821e974d1967930a85b2dc5ea51999f5c33ce3ab9950e195b9c3bb1549c63a4c22fde63a981b3676f005872db50c0b6c9dec65223bbefb4595081547c0822decb941cfe2731f224a77ea51e663148eb521548622f168bb971900fa8a614448f5b65ed1c6aa679448129b47df23a74fab59e0262d536cfc6beb956fd9da7ecbdb4c095736af0a42399915a827939d8de606a20aed952995346000f96a02ef3f227ede17513a08cb221fc5de31e30e4184c5a1224a0bf78f55aa10c5e3852c0504ce500bf25376"+ "'", var32.equals("1fdfafbe07c1e102ccd84f50de95cbb9c1936d2c1f8b79b178437e5e4838de91dbca9b3f63f49be1d47dc8aa078972c481431372dabf6613c3540f4a89e533022d424ffe08493f1316ad58473d6f7ba4e1794df0201d9c221ca419c0c62a59bbf19f9c4498e3883b65f30dce055a1fe45d6d56cd6d06c096960f1b6b733c0fc8e16fb3f13d7102fd1d43822471985dd69bf420ea9d936df3d7521a4990c94205239e4ce30672b0ed7801e84d9afded657b1acd6a01d36caa4f54b14f8cb90fa06c48d1a3b67c5ee671fb872b780cd7c9f1eecdc088decd027baee883b24cb45ddb75de448c8c496e5637f911de0997b73454b3b272818ab822125042e2905c2bec310b03d05546f14029ac2cfad25341f75125393fcee99e02d48d6314f76338cd049ff37787137624a11caa5457340e3b810fbeb019deaac0f9fb17ed0ea26305f2dece8c73f80869ac1feb513f66fa9b081ebbf193d2d8932c8212a4664a965810d44d535b11ebd34773488cb6aee2dd159063abbc434a9014cbbaa0c6f8f4877c10be99cb8b81c31e0b915794fe6ee9882681c6db27a6d57dbfa492282a1ba4f493b72aa9ab7215d839f78d03ac173840ed941aedadd324ba995ac3a1773ebb01f330a5b58b54bbab93eca4b78a86eacec805b42ee584b09fc78b1c2895f18bf87ba53e86f3179b2400f2140eefecad8492de929266b1e86d1c8102254dab1d318422a5623a0e466b97431b868df29e7b403b99cabe16602c634b0bba017f845daa1e41170ba600660695a0058dae7783689ffbb679c55c381a65196358374c02178b4cf8660179686bc3556c47b715ee7e4f20f4a1149870a4254e3e4b70f54ddc7e497ec01e3ba65139774262438a04fcce159d3ff1b10a289b9c7153e44f6f04ed4331664a6219aa0e67b160d1407a1799b9ea55f14eb88361ab7e7bd683afb06681671aefc684438d60ec9f98c70a3a24a61b3fdca4a9204963f4bfafab01af217ea9b53883e24edd6afeedbefd51b4da8af877c3ab42b477630bc768b9c4611c1c6643b9dc677ae56f00fe4885476a2f0d504859821e974d1967930a85b2dc5ea51999f5c33ce3ab9950e195b9c3bb1549c63a4c22fde63a981b3676f005872db50c0b6c9dec65223bbefb4595081547c0822decb941cfe2731f224a77ea51e663148eb521548622f168bb971900fa8a614448f5b65ed1c6aa679448129b47df23a74fab59e0262d536cfc6beb956fd9da7ecbdb4c095736af0a42399915a827939d8de606a20aed952995346000f96a02ef3f227ede17513a08cb221fc5de31e30e4184c5a1224a0bf78f55aa10c5e3852c0504ce500bf25376"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0.9998800951139645d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 4631.6729028068285d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test453"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.14608902069952245d, 3.84074378609149d, 1.380627352707058d);
    var3.reseedRandomGenerator(40420L);
    var3.reseedRandomGenerator(22L);
    double var8 = var3.getSupportUpperBound();
    double var9 = var3.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3.84074378609149d);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test454"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(1.2277422966290603d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 70.34445192654395d);

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test455"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-1.420806035574538d), 7.788896578666913d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test456"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getStandardDeviation();
//     double[] var13 = var10.sample(1);
//     double var15 = var10.cumulativeProbability(0.0d);
//     double var16 = var10.getSupportUpperBound();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     double var18 = var10.getSupportLowerBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.501779651948777d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.9321440152609791d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == Double.NEGATIVE_INFINITY);
// 
//   }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test457"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-2.2455840101776996d), 11166);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test458"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    var1.addElement(2.0216852347077916d);
    float var4 = var1.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test459"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double[] var3 = var0.sample(10);
    double var4 = var0.getStandardDeviation();
    double var5 = var0.getStandardDeviation();
    double var6 = var0.getNumericalVariance();
    double var7 = var0.getNumericalVariance();
    double var9 = var0.probability(0.9999999999999925d);
    double var11 = var0.probability(3.0741607150885346d);
    boolean var12 = var0.isSupportConnected();
    double var14 = var0.cumulativeProbability((-1.6804163900380429d));
    boolean var15 = var0.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.046438164661925074d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test460"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(2979.9579870417283d, (-0.13257979660911617d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2979.957987041728d);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test461"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-0.300194891342756d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.110593269504755d);

  }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test462"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var13 = var0.nextT(5.867156662812015d);
//     double var16 = var0.nextGamma(0.13558023874553457d, 0.010050505059049992d);
//     double var18 = var0.nextChiSquare(0.8847656390164815d);
//     var0.reSeed(11L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.284290619252105d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "fd41592ca6"+ "'", var8.equals("fd41592ca6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.1143897098506046d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.0819226642356035E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.32768768744595894d);
// 
//   }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test463"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.contract();
    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var3 = var2.getStandardDeviation();
    double[] var5 = var2.sample(1);
    double var7 = var2.cumulativeProbability(0.0d);
    double var8 = var2.getSupportUpperBound();
    boolean var9 = var2.isSupportUpperBoundInclusive();
    var2.reseedRandomGenerator((-16L));
    double[] var13 = var2.sample(2297);
    var0.addElements(var13);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    var15.setContractionCriteria(2097152.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test464"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    double[] var5 = var4.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var8 = var7.getStandardDeviation();
    double[] var10 = var7.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    int var12 = var11.start();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var11.copy();
    int var14 = var13.getNumElements();
    var13.setNumElements(8899);
    int var17 = var13.start();
    int var18 = var13.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var13);
    int var20 = var13.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 8899);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test465"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(18944L, 1342198656L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 18944L);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test466"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var4 = var0.getMean();
    double[] var6 = var0.sample(100);
    boolean var7 = var0.isSupportLowerBoundInclusive();
    boolean var8 = var0.isSupportUpperBoundInclusive();
    double[] var10 = var0.sample(8899);
    double var11 = var0.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test467"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(5);
    float var2 = var1.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionMode(21505315);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5f);

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test468"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.8427007929497151d), 0.1212133984141624d, 7.474932982660367d, 1343);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test469"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1940, 5668);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test470"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(1460, 1.9999999f, (-1.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test471"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     double var12 = var0.nextCauchy(100.0d, 120.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextBinomial(20355937, 1.6336928276320164d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 47.10188546240457d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 146.0046663072097d);
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test472"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(3);
    float var2 = var1.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5f);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test473"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.39600327557751386d, 0.06955174362771119d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.3969353103722615d);

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test474"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     int var20 = var0.nextBinomial(0, 0.7615941559557649d);
//     double var23 = var0.nextF(0.6333241614301578d, 1.0110169304177432d);
//     java.util.Collection var24 = null;
//     java.lang.Object[] var26 = var0.nextSample(var24, 9886);
// 
//   }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test475"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1498);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test476"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(3.346662174396965E23d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7793339550638902E25d);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test477"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(84, 298);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 84);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test478"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(5.147442998493695d, 2006);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test479"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
//     java.lang.Class var5 = var4.getDeclaringClass();
//     int var6 = var4.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
//     org.apache.commons.math3.random.RandomGenerator var8 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
//     org.apache.commons.math3.random.RandomGenerator var10 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     org.apache.commons.math3.distribution.NormalDistribution var13 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var14 = var13.getSupportUpperBound();
//     double[] var16 = var13.sample(10);
//     org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
//     double var19 = var17.addElementRolling(0.15264401491200186d);
//     boolean var20 = var2.equals((java.lang.Object)var17);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var23 = var21.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var25 = var24.getTiesStrategy();
//     java.lang.Class var26 = var25.getDeclaringClass();
//     int var27 = var25.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23, var25);
//     org.apache.commons.math3.random.RandomGenerator var29 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23, var29);
//     org.apache.commons.math3.random.RandomGenerator var31 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23, var31);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var34 = var33.getTiesStrategy();
//     java.lang.Class var35 = var34.getDeclaringClass();
//     java.lang.String var36 = var34.toString();
//     java.lang.String var37 = var34.toString();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var38 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23, var34);
//     boolean var40 = var34.equals((java.lang.Object)4.2130907952045655d);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var41 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var34);
//     java.lang.String var42 = var34.name();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var43 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var34);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var44 = var43.getTiesStrategy();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.07543616968205515d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + "AVERAGE"+ "'", var36.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + "AVERAGE"+ "'", var37.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var42 + "' != '" + "AVERAGE"+ "'", var42.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test480"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(1659);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10645.402685335299d);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test481"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(2.8272517061213667d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.827251706121367d);

  }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test482"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double var5 = var0.sample();
//     double var6 = var0.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.8728535189595216d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
// 
//   }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test483"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     var0.reSeedSecure();
//     long var10 = var0.nextSecureLong(3L, 31L);
//     double var12 = var0.nextExponential(4066.8844691618797d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12.460615579058297d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 14L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 13518.320764178992d);
// 
//   }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test484"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
//     java.lang.Class var5 = var4.getDeclaringClass();
//     int var6 = var4.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
//     org.apache.commons.math3.random.RandomGenerator var8 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
//     org.apache.commons.math3.random.RandomGenerator var10 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
//     java.lang.Class var14 = var13.getDeclaringClass();
//     java.lang.String var15 = var13.toString();
//     java.lang.String var16 = var13.toString();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var13);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var22 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var25 = var24.getSupportUpperBound();
//     double[] var27 = var24.sample(10);
//     double var28 = var18.mannWhitneyU(var22, var27);
//     double[] var29 = var17.rank(var22);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var30 = var17.getNanStrategy();
//     java.lang.String var31 = var30.toString();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var33 = var32.getTiesStrategy();
//     java.lang.Class var34 = var33.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var33);
//     java.lang.String var36 = var33.toString();
//     java.lang.String var37 = var33.name();
//     java.lang.String var38 = var33.toString();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30, var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "AVERAGE"+ "'", var16.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 24.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + "MAXIMAL"+ "'", var31.equals("MAXIMAL"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + "AVERAGE"+ "'", var36.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + "AVERAGE"+ "'", var37.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var38 + "' != '" + "AVERAGE"+ "'", var38.equals("AVERAGE"));
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test485"); }


    double[] var3 = new double[] { 0.0d, (-1.0d), 0.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    float var6 = var4.getExpansionFactor();
    var4.addElement((-0.800705451244633d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test486"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.3841864E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-22));

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test487"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    java.lang.Class var6 = var5.getDeclaringClass();
    int var7 = var5.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var5);
    org.apache.commons.math3.random.RandomGenerator var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var9);
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    java.lang.String var16 = var14.toString();
    java.lang.String var17 = var14.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var14);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var20 = var19.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "AVERAGE"+ "'", var16.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "AVERAGE"+ "'", var17.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test488"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.discardMostRecentElements(1);
    int var15 = var4.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    var4.contract();
    double var19 = var4.addElementRolling(0.994492389768776d);
    double var21 = var4.addElementRolling((-0.321191615172387d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test489"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.2522078586338771d);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test490"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-0.21797175591287912d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7755575615628914E-17d);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test491"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     var4.contract();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var6.contract();
//     int var8 = var6.getExpansionMode();
//     var6.setElement(5, 20.696514663540924d);
//     var6.setNumElements(1);
//     double var15 = var6.getElement(0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.3748747308970577d);
// 
//   }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test492"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     java.lang.String var13 = var0.nextHexString(10);
//     var0.reSeedSecure();
//     double var17 = var0.nextGaussian(7.042014262199385d, 1.179103839756096d);
//     double var20 = var0.nextCauchy((-1.4998528973459138d), 2.7076386898590252d);
//     long var22 = var0.nextPoisson(0.9999999987705535d);
//     java.util.Collection var23 = null;
//     java.lang.Object[] var25 = var0.nextSample(var23, 100);
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test493"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(220281870188804968L, 40326L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test494"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double[] var3 = var0.sample(10);
    double var4 = var0.getStandardDeviation();
    double var6 = var0.density(2.345330933436551d);
    double var7 = var0.getSupportLowerBound();
    double var9 = var0.cumulativeProbability(0.5231370181288907d);
    double var10 = var0.getSupportLowerBound();
    boolean var11 = var0.isSupportLowerBoundInclusive();
    double var12 = var0.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.025496167636629936d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.6995605468138986d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test495"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(9.536747E-7f, (-1.4E-45f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.4E-45f));

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test496"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     double var10 = var0.nextT(0.023932653637902992d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10.450847365961344d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5867e37ed8"+ "'", var8.equals("5867e37ed8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.4272539189812123E34d));
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test497"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGamma(16.915172776155245d, 0.27820249749496384d);
//     long var6 = var1.nextPoisson(13.575479326644766d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4.700026687119986d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12L);
// 
//   }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test498"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var4.addElement((-0.43408597923864894d));
//     double var10 = var4.getElement(0);
//     double[] var11 = var4.getElements();
//     var4.addElement(21.0d);
//     var4.setNumElements(3);
//     org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var17 = var16.getStandardDeviation();
//     double[] var19 = var16.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
//     var20.contract();
//     int var22 = var20.getNumElements();
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var20);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var24 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var28 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var28);
//     org.apache.commons.math3.distribution.NormalDistribution var30 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var31 = var30.getSupportUpperBound();
//     double[] var33 = var30.sample(10);
//     double var34 = var24.mannWhitneyU(var28, var33);
//     var4.addElements(var28);
//     var4.contract();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.1103071697410853d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 18.0d);
// 
//   }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test499"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(11297, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 11297);

  }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test500"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-0.22548853783856543d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

}
