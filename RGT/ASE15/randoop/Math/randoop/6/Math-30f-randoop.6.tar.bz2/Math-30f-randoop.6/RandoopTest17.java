
import junit.framework.*;

public class RandoopTest17 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test1"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(3.129990516500412d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0d);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test2"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3.838543669559908d, (java.lang.Number)0.007581196426522127d, (java.lang.Number)(-4295468319161797071L));

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test3"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var2.setContractionCriteria(100.0f);
    var2.contract();
    int var11 = var2.getNumElements();
    var2.setExpansionMode(0);
    double var15 = var2.addElementRolling(0.5819638206431428d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test4"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(2.011669054126255E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test5"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.999814020931978d, (java.lang.Number)(-0.5063656411097588d), (java.lang.Number)2.7387776572306084d);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test6"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-10));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test7"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(7053352210170117173L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7053352210170117173L);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test8"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-2605573555328993815L), (-7053352210170117173L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test9"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.4649972832707442d);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test10"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     double var4 = var3.getSupportUpperBound();
//     double var5 = var3.sample();
//     boolean var6 = var3.isSupportConnected();
//     boolean var7 = var3.isSupportConnected();
//     double var8 = var3.getMean();
//     boolean var9 = var3.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 4.158832805986259d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.8720980175938546d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test11"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.5268008012035816d);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test12"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1.0648164703369514d);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test13"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-7053352210170117161L), (-9L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7053352210170117170L));

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test14"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(89L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test15"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-2996224), (-109));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test16"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.5711630028367114d, (java.lang.Number)2.4852155806570816E-194d, false);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test17"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getNumericalVariance();
    double var7 = var3.getNumericalMean();
    var3.reseedRandomGenerator(10L);
    double var10 = var3.getSupportUpperBound();
    boolean var11 = var3.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test18"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-790794752), 230399);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-790564353));

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test19"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-3), 2996224);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test20"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    boolean var4 = var3.isSupportConnected();
    boolean var5 = var3.isSupportUpperBoundInclusive();
    double var6 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test21"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.1641534E-10f, (-0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0f));

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test22"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.17453292519943298d);
    java.lang.Number var3 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0.17453292519943298d+ "'", var3.equals(0.17453292519943298d));

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test23"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(218700, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 218710);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test24"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    var2.setExpansionFactor(50.0f);
    var2.clear();
    float var10 = var2.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 100.5f);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test25"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var2.getNanStrategy();
//     org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//     var16.setExpansionMode(0);
//     double[] var19 = var16.getInternalValues();
//     double[] var20 = var16.getInternalValues();
//     var16.addElement(0.6506783754890694d);
//     int var23 = var16.getNumElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
//     org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//     var27.setExpansionMode(0);
//     double[] var30 = var27.getInternalValues();
//     double[] var31 = var27.getInternalValues();
//     org.apache.commons.math3.util.ResizableDoubleArray var32 = new org.apache.commons.math3.util.ResizableDoubleArray(var31);
//     var16.addElements(var31);
//     double[] var34 = var2.rank(var31);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test26"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.0186667974145138d, var1, true);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test27"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1033075519), (-7053352210170117083L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test28"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-0.03857303026834636d));
    java.lang.Number var2 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + (-0.03857303026834636d)+ "'", var2.equals((-0.03857303026834636d)));

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test29"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.17453292519943295d);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test30"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-1033075519), (-11891));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test31"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9994652256775848d, (java.lang.Number)0.4880911896481078d, false);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test32"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.0000002f);
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var8 = var7.getNumElements();
    int var9 = var7.start();
    double var11 = var7.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    java.lang.Object[] var15 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var16 = new org.apache.commons.math3.exception.NullArgumentException(var13, var15);
    java.lang.Throwable[] var17 = var16.getSuppressed();
    boolean var18 = var12.equals((java.lang.Object)var17);
    org.apache.commons.math3.exception.MaxCountExceededException var19 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)0.00858267380786032d, (java.lang.Object[])var17);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, (java.lang.Object[])var17);
    java.lang.Throwable[] var21 = var20.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test33"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.7173750019934241d, 0.1048515747957178d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7173750019934241d);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test34"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.1919266570807596d, 2.5504103787854016d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5504103787854016d);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test35"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.7612753675628248d, 1.4698901315402613d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4698901315402613d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test36"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.31161695384777244d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.551115123125783E-17d);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test37"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-41));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test38"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(4.36080735934285E7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.360807359342851E7d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test39"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.6318205360130218d);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test40"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var10 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var8, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var7, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var10);
    org.apache.commons.math3.exception.util.ExceptionContext var14 = var3.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var15 = var3.getContext();
    java.lang.Throwable[] var16 = var3.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var17 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathIllegalArgumentException var18 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test41"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-0.5902737038068222d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test42"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.47588E29f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.47588E29f);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test43"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.887021992353567d);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test44"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2207031E-4f);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test45"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    float var7 = var2.getExpansionFactor();
    org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var12 = var11.getSupportUpperBound();
    double var13 = var11.getStandardDeviation();
    boolean var14 = var11.isSupportConnected();
    var11.reseedRandomGenerator(5365208890106504175L);
    boolean var17 = var2.equals((java.lang.Object)5365208890106504175L);
    int var18 = var2.start();
    var2.setNumElements(9216);
    var2.discardMostRecentElements(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test46"); }


    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(byte)10, (java.lang.Number)1, var2);
    java.lang.Number var4 = var3.getHi();
    java.lang.Number var5 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test47"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    int var8 = var2.getNumElements();
    var2.clear();
    int var10 = var2.getNumElements();
    float var11 = var2.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.5f);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test48"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p((-0.083940489568844d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.08767394869871506d));

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test49"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(10.0f, 100.49999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.49999f);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test50"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.9999999958776927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5707055269350272d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test51"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    int var11 = var2.getExpansionMode();
    double var13 = var2.substituteMostRecentElement(45.0d);
    double var15 = var2.getElement(0);
    double[] var16 = var2.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 45.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test52"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(1.2642564124929525d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6290049360481529d);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test53"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(7053352210170117161L, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test54"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1024));

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test55"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 0.7435938375035029d);
    boolean var3 = var2.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test56"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(2.4695522289423613d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.4695522289423613d);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test57"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.24191996538778948d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.23735958655023764d);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test58"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(2.4758799E29f, (-100.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-100.0f));

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test59"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(7053352210173745971L, 7053352210170117161L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7597568142009019117L));

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test60"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var2.getNanStrategy();
//     org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//     double[] var13 = new double[] { 100.0d, 1.0d};
//     var10.addElements(var13);
//     float var15 = var10.getExpansionFactor();
//     var10.setExpansionMode(0);
//     double[] var18 = var10.getInternalValues();
//     double[] var19 = var2.rank(var18);
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test61"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.35812883302518556d, (java.lang.Number)2.0000005f, true);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test62"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)7.569397550458789d);
    java.lang.Throwable[] var3 = var2.getSuppressed();
    java.lang.Throwable[] var4 = var2.getSuppressed();
    java.lang.Throwable[] var5 = var2.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test63"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test64"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(299622400, 2995200);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test65"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var8 = var7.getExpansionMode();
    int var9 = var7.getNumElements();
    double[] var10 = var7.getInternalValues();
    float var11 = var7.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.0f);

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test66"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(2.0980109293178746d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test67"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test68"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     double var5 = var3.probability(7.569397550458789d);
//     double var6 = var3.getNumericalVariance();
//     double var7 = var3.getNumericalMean();
//     double var8 = var3.getMean();
//     double[] var10 = var3.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
//     double var13 = var11.addElementRolling(155.33650900579727d);
//     org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
//     org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7435938375035028d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.8720980175938546d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.8720980175938546d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 3.8077215324169367d);
// 
//   }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test69"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var8 = var7.getExpansionMode();
    float var9 = var7.getExpansionFactor();
    var7.setExpansionFactor(100.49999f);
    var7.setElement(918, 0.007421211557185701d);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var7.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test70"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(100.50001f, 19.95959161095043d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.5f);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test71"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1024.0001f, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2048.0002f);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test72"); }


    java.math.BigInteger var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, (-7597568142009019117L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test73"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(3.1757334232496706d, 4.333449949606716E-4d, 0.19240232444172617d);
//     double var5 = var3.probability(2.461644881538276d);
//     double[] var7 = var3.sample(91);
//     double var8 = var3.sample();
//     double var10 = var3.inverseCumulativeProbability(0.6875191546609779d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.175553429128317d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3.175908740770185d);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test74"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-0.03857303026834636d), (-1024));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.1456960323376E-310d));

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test75"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(3.1619218329453496d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4259769466670957d);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test76"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.01928412433486901d, 1.0580255990670628d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.01928412433486901d);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test77"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     double var4 = var3.getSupportUpperBound();
//     double var5 = var3.sample();
//     boolean var6 = var3.isSupportConnected();
//     double var7 = var3.getSupportUpperBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.1562562328456267d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test78"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.892510807227735d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test79"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-273111867));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test80"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.1287147879181489E-5d, (java.lang.Number)1.1641534E-10f, (java.lang.Number)0.9085585716960896d);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test81"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.3581288330251856d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3508842484569435d);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test82"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-0.9311522197519757d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test83"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1.4717526330792405d);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test84"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var5 = new org.apache.commons.math3.exception.NullArgumentException(var2, var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var4);
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test85"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1897678595, 599700245);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 267381171);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test86"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    var2.setNumElements(100);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test87"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.4688789649850351d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.48802115169925137d);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test88"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double[] var7 = var3.sample(100);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    var9.contract();
    var9.setElement(99, 0.5686929365266755d);
    int var14 = var9.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 100);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test89"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double[] var7 = var3.sample(100);
    double var9 = var3.density(0.17453292519943298d);
    double[] var11 = var3.sample(99);
    double var14 = var3.cumulativeProbability((-0.12505535487388142d), 0.6499628652950262d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0034691670965537173d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.004729340288640325d);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test90"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    float var7 = var2.getExpansionFactor();
    org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var12 = var11.getSupportUpperBound();
    double var13 = var11.getStandardDeviation();
    boolean var14 = var11.isSupportConnected();
    var11.reseedRandomGenerator(5365208890106504175L);
    boolean var17 = var2.equals((java.lang.Object)5365208890106504175L);
    int var18 = var2.start();
    double[] var19 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var20 = var2.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test91"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(1.2475312893420674d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6898464935554528d);

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test92"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.6290049360481529d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test93"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(1.32327241927233d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0109770195392067d);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test94"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.0109770195392067d, (-1.124844303657884d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0109770195392063d);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test95"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(3.063332550849334E67d, 0.30412140489554756d, 0.0d, 900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test96"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(7.569397550458789d, 0.007581196426522127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0154635440486444d);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test97"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(17.771303091670074d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.223707618782176E7d);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test98"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(13813.387644810302d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0008111021028918d);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test99"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-9.999999f), 22809501);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.NEGATIVE_INFINITY);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test100"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(9.384006317093086E134d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.907028237305198E137d);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test101"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.3460731448215636d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3392063925622549d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test102"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.976508918599899d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.010323785882491719d));

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test103"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.02217385702297738d);
    java.lang.Throwable[] var2 = var1.getSuppressed();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var4 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var3, var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test104"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-389376000), 9216);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-389376000));

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test105"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    var2.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var12.setExpansionMode(0);
    double[] var15 = var12.getInternalValues();
    var12.clear();
    double var18 = var12.addElementRolling(0.7853981633974483d);
    var12.addElement(0.0d);
    var12.setNumElements(100);
    boolean var23 = var2.equals((java.lang.Object)var12);
    int var24 = var2.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var28 = var27.getNumElements();
    int var29 = var27.start();
    var27.setElement(10, 0.7612753675628248d);
    var27.discardFrontElements(0);
    double[] var35 = var27.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray(var35);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var36);
    var2.setNumElements(1024);
    double[] var40 = var2.getElements();
    double[] var41 = var2.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test106"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1L, (-389376000));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test107"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(11.206667166178734d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11.0d);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test108"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.552769841758708d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test109"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)2.7387776572306084d);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test110"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    int var7 = var2.getExpansionMode();
    float var8 = var2.getExpansionFactor();
    var2.setNumElements(0);
    double var12 = var2.addElementRolling(7.253658542162704E-25d);
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var2.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var2.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test111"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(1024, (-10.0f), 1024.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test112"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(3.139340664351555d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4642418492273461d);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test113"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-0.12451637592188193d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.12451637592188193d);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test114"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)7.560575574229005E-6d, (java.lang.Number)1.107194659485365d, (java.lang.Number)1.8519271337371066d);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.107194659485365d+ "'", var4.equals(1.107194659485365d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.8519271337371066d+ "'", var5.equals(1.8519271337371066d));

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test115"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var2.setContractionCriteria(100.0f);
    int var10 = var2.start();
    float var11 = var2.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.0f);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test116"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(4.979340558083069d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.1469855834287612d);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test117"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.addElement(0.8414709848078965d);
    boolean var10 = var2.equals((java.lang.Object)(byte)100);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = var2.copy();
    float var12 = var2.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 100.0f);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test118"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.7377840776591889d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 15.799738409059216d);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test119"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-389376000), (-1024));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test120"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getNumericalVariance();
    double var7 = var3.getSupportLowerBound();
    var3.reseedRandomGenerator((-7053352210170117172L));
    double[] var11 = var3.sample(231424);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test121"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    var2.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var12.setExpansionMode(0);
    double[] var15 = var12.getInternalValues();
    var12.clear();
    double var18 = var12.addElementRolling(0.7853981633974483d);
    var12.addElement(0.0d);
    var12.setNumElements(100);
    boolean var23 = var2.equals((java.lang.Object)var12);
    org.apache.commons.math3.util.ResizableDoubleArray var24 = var12.copy();
    var12.setContractionCriteria(1024.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var29.setExpansionMode(0);
    double[] var32 = var29.getInternalValues();
    var29.clear();
    double var35 = var29.addElementRolling(0.7853981633974483d);
    var29.addElement(0.0d);
    var29.setNumElements(100);
    org.apache.commons.math3.util.ResizableDoubleArray var40 = var29.copy();
    var40.setExpansionMode(0);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var12, var40);
    int var44 = var12.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test122"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.626074551533144d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test123"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)5.397570075115222E-22d);
    java.lang.Number var2 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 5.397570075115222E-22d+ "'", var2.equals(5.397570075115222E-22d));

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test124"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.06610389384361959d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4));

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test125"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-8), 1349403648);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test126"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-7053352210170117173L), (-2605573555328993815L));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test127"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1.4214549026638725d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1487869193414864d);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test128"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.5507503625553098E-4d, 1.2846447019565141d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999784848369279d);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test129"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.5876916151719559d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test130"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, (java.lang.Number)0.019878299454072185d, false);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test131"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var8 = var7.getExpansionMode();
    float var9 = var7.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var7.copy();
    double[] var11 = var7.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test132"); }


    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.1900536393062961d, (java.lang.Number)(-1), var2);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test133"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(3.814698E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-18));

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test134"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(98, 22809501);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 98);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test135"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(231415, 10676);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test136"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    int var11 = var2.getExpansionMode();
    double var13 = var2.substituteMostRecentElement(45.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardMostRecentElements((-17));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test137"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(1.0580255990670628d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test138"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getNumericalVariance();
    double var7 = var3.getSupportUpperBound();
    boolean var8 = var3.isSupportUpperBoundInclusive();
    double var9 = var3.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.7435938375035028d);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test139"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-3.5742124182322907d), 0.9999636981980967d, 0.027274760086014354d);
    double var4 = var3.getMean();
    boolean var5 = var3.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-3.5742124182322907d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test140"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.3392063925622549d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2920771941603302d);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test141"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    int var11 = var2.getExpansionMode();
    double var13 = var2.substituteMostRecentElement(45.0d);
    double[] var14 = var2.getInternalValues();
    var2.setElement(2995200, 13813.387644810302d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test142"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    double[] var4 = var2.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardMostRecentElements(273111867);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test143"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 231415);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test144"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-7053352210170117173L), 9L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test145"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    var2.setNumElements(1);
    var2.addElement((-0.9719625010961676d));
    double var13 = var2.addElementRolling(2.357097455574727d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test146"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.6318205360130218d, 1.1749142332678566d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6318205360130218d);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test147"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.2207031E-4f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test148"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.04532565673339656d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.04529464298044572d);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test149"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var6, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var8);
    java.lang.Throwable[] var12 = var11.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var13 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, var1, (java.lang.Object[])var12);
    java.lang.Number var14 = var13.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test150"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)0, (java.lang.Number)1L, (java.lang.Number)0.6506783754890694d);
    java.lang.Number var4 = var3.getArgument();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    java.lang.Object[] var15 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var16 = new org.apache.commons.math3.exception.NullArgumentException(var13, var15);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var11, var12, var15);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var9, var15);
    org.apache.commons.math3.exception.util.ExceptionContext var19 = var8.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var20 = var8.getContext();
    java.lang.Throwable[] var21 = var8.getSuppressed();
    java.lang.Throwable[] var22 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var23 = new org.apache.commons.math3.exception.MathArithmeticException(var6, (java.lang.Object[])var22);
    org.apache.commons.math3.exception.MathIllegalStateException var24 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, (java.lang.Object[])var22);
    java.lang.Number var25 = var3.getLo();
    java.lang.Number var26 = var3.getLo();
    org.apache.commons.math3.exception.util.ExceptionContext var27 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)0+ "'", var4.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + 1L+ "'", var25.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + 1L+ "'", var26.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test151"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(17.771303091670074d, 0.5282333622753137d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.5723915548447165d);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test152"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var2.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var9 = new double[] { 100.0d, 1.0d};
    var6.addElements(var9);
    var6.setNumElements(1);
    int var13 = var6.getExpansionMode();
    double var15 = var6.getElement(0);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setExpansionMode(299417600);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 100.0d);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test153"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    var2.contract();
    var2.setExpansionMode(0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double[] var13 = var2.getInternalValues();
    var2.setElement(100, 0.29677036567728765d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

//  public void test154() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest17.test154"); }
//
//
//    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//    var2.setExpansionMode(0);
//    double[] var5 = var2.getInternalValues();
//    var2.clear();
//    double var8 = var2.addElementRolling(0.7853981633974483d);
//    var2.addElement(0.0d);
//    var2.setNumElements(100);
//    org.apache.commons.math3.util.ResizableDoubleArray var13 = var2.copy();
//    var2.setNumElements(2995200);
//    int var16 = var2.getNumElements();
//    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      var17.addElement(10.279372645675316d);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var5);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var8 == 0.0d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var13);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var16 == 2995200);
//
//  }
//
  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test155"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(1024L, 8400190882459457459L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test156"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)7081.058387126132d, (java.lang.Number)2.8720980175938546d, true);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var11 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var7, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
    java.lang.Throwable[] var12 = var11.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var6, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var12);
    java.lang.Throwable[] var15 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var16 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var15);
    org.apache.commons.math3.exception.util.ExceptionContext var17 = var16.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var18 = var16.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test157"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(9216, 1897678595);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1897678595);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test158"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(2996224, 0.0012207029f, 1.0000001f, 918);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test159"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-3628799L), 7053352210170117173L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3628799L));

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test160"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(byte)100);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    java.lang.Number var4 = var2.getArgument();
    boolean var5 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)100+ "'", var4.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test161"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(1.271554272071574d, 0.02482883928436441d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.271554272071574d);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test162"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var2.copy();
    var2.addElement(1.0861794612026863d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test163"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    var3.reseedRandomGenerator(0L);
    boolean var8 = var3.isSupportLowerBoundInclusive();
    double var10 = var3.cumulativeProbability(2.2683541557421067d);
    double var12 = var3.density(0.5683852532105546d);
    double var13 = var3.getNumericalMean();
    double[] var15 = var3.sample(918);
    boolean var16 = var3.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.24191996538778948d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.013044992572946019d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test164"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(599700145, 599700145);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 49513393);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test165"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(4.333449949606716E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0004334389024674d);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test166"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p((-0.07248713056628153d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.07524860919657378d));

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test167"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(98);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test168"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)7.569397550458789d);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test169"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.addElement(0.8414709848078965d);
    double[] var9 = var2.getInternalValues();
    int var10 = var2.getExpansionMode();
    float var11 = var2.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.5f);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test170"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh((-1.8047526389778585d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.9569762701914017d));

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test171"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.5974167300266131d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1838245238059453d);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test172"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(1.9077345831441337d, (-157.06944545602886d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.9930230849165833d));

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test173"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(3.1757334232496706d, 4.333449949606716E-4d, 0.19240232444172617d);
    double var5 = var3.probability(2.461644881538276d);
    boolean var6 = var3.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test174"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var5 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test175"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.9150123793192297d, 1.0861794612026863d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4202230375000948d);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test176"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(7053352210170117173L, (-5365208890106504175L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1688143320063612998L);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test177"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "org.apache.commons.math3.exception.NotPositiveException: 12.802 is smaller than the minimum (0)");
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test178"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.7435938375035029d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7323669976070981d);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test179"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var3, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)4.148801421947793d, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test180"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(3.432443690009129E42d, 8.865319956825967d, 1.0136684045930817d);
    double var4 = var3.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3.432443690009129E42d);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test181"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.0d, 43.63613076156174d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test182"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-7053352210170117172L), (-7053352210170117173L));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test183"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(37.281124735952304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.761698277790729E15d);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test184"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var4, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test185"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var3 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0, (java.lang.Number)5.551115123125783E-17d, var3);
//     java.lang.Number var5 = var4.getLo();
//     org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test186"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.281128124954561d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test187"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.6702689865751268d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6702689865751269d);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test188"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(57.303740609324045d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test189"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(1015, 99);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test190"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(1.1749142332678566d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.773355349013742d);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test191"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var5, var7);
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)0.7435938375035029d, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var7);
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)8.639495877295877E-5d, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test192"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     double var5 = var2.density(0.5403023093369417d);
//     double var8 = var2.cumulativeProbability(0.6552836562919295d, 0.976508918599899d);
//     var2.reseedRandomGenerator((-7053352210170117162L));
//     double var11 = var2.getSupportUpperBound();
//     boolean var12 = var2.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-2.3589503675377017d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.1900536393062961d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0591178080680944d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
// 
//   }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test193"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var4, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test194"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter((-1023.99994f), 4.283475365339624d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1023.9999f));

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test195"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(1.0648164703369514d, 0.6499628652950262d);
    double var4 = var2.cumulativeProbability(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05068240160954135d);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test196"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.001220703f), 0.9130907135554011d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0012207029f));

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test197"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(1.548577593537681d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test198"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.4878373115376495d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2));

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test199"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(2.60986327741734d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9892405797643135d);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test200"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(2995200, 38950315);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test201"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(3.2544789518188435d, (-0.6484604495970026d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.012176703833830738d);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test202"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(10676, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test203"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(90L, (-109L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9810L);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test204"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-2.1456960323376E-310d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.1456960323376E-310d));

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test205"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var4, var6);
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    java.lang.Object[] var13 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var11, var13);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var9, var10, var13);
    var7.addSuppressed((java.lang.Throwable)var15);
    java.lang.Throwable[] var17 = var7.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var18 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)1.8142035178418503E-11d, (java.lang.Object[])var17);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, (java.lang.Object[])var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test206"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.941575758241476d, 7.10807918087573d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2666459829545095d);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test207"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-100L), (java.lang.Number)0.18554356089641366d, true);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test208"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    int var8 = var7.start();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var7.copy();
    var7.setElement(2995200, 0.6156490123256325d);
    var7.setNumElements(596700);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test209"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.32327241927233d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test210"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-0.07655602848313875d), 0.18554356089641366d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test211"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1024L, (-9L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test212"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    int var7 = var2.getExpansionMode();
    float var8 = var2.getExpansionFactor();
    var2.setNumElements(0);
    float var11 = var2.getExpansionFactor();
    double[] var12 = var2.getInternalValues();
    float var13 = var2.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.5f);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test213"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    java.lang.Throwable[] var2 = var1.getSuppressed();
    java.lang.Number var3 = var1.getMax();
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(byte)10, (java.lang.Number)1, var6);
    java.lang.Number var8 = var7.getHi();
    var1.addSuppressed((java.lang.Throwable)var7);
    java.lang.Number var10 = var7.getHi();
    java.lang.Number var11 = var7.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (-1.0d)+ "'", var3.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 1+ "'", var11.equals(1));

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test214"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(1.0149280275816275d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0149280275816275d);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test215"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-790794752), (-1033075519));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test216"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.5291230241796157d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1844424275791029d);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test217"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(0, (-389376000));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-389376000));

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test218"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(7053352210166488382L, 10L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test219"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.44109980171999075d, (java.lang.Number)0.1013490065056271d, (java.lang.Number)2995200);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test220"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getNumericalVariance();
    double var7 = var3.getSupportUpperBound();
    boolean var8 = var3.isSupportUpperBoundInclusive();
    double var9 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.POSITIVE_INFINITY);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test221"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.1641534E-10f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test222"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var1, (java.lang.Number)5.889694544886073d, var3, true);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test223"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-11800), (-17));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 200600);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test224"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(91);
    float var2 = var1.getContractionCriteria();
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5f);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test225"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(2.3341713442711427E-4d, 0.12228122537761468d, 1.0149280275816275d, 218710);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.11541533422137074d);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test226"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(22809501, 49513393);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 49513393);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test227"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-4295468319161797071L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test228"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getNumericalVariance();
    double var7 = var3.getNumericalMean();
    var3.reseedRandomGenerator(10L);
    double var10 = var3.getNumericalMean();
    double var11 = var3.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.8623188722876839d);

  }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test229"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     double var4 = var2.sample();
//     double var6 = var2.probability(57.295779276891516d);
//     double var8 = var2.density(0.017453292447995462d);
//     boolean var9 = var2.isSupportUpperBoundInclusive();
//     double var11 = var2.probability(433.6945330979522d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-2.191277000154937d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-2.795545165979352d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.19207034841124335d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test230"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    double[] var4 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test231"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-0.6076604670915139d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5446235444660443d);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test232"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(299622400);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 299622400);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test233"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.5683852532105546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5415271629914478d);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test234"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    var2.addElement(0.6506783754890694d);
    int var9 = var2.getNumElements();
    double var11 = var2.getElement(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.6506783754890694d);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test235"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(7053352210170117172L, (-4295468319161797071L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-4295468319161797071L));

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test236"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.0d, 10676);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test237"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-13), 2994176);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2994189));

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test238"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.2747572580234001d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.5778328144742053d);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test239"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.03989422803865439d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.039873076958439176d);

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test240"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(3.129990516500412d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test241"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.contract();
    int var7 = var2.start();
    var2.clear();
    double[] var9 = var2.getElements();
    java.lang.Object var10 = null;
    boolean var11 = var2.equals(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test242"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double[] var7 = var3.sample(100);
    double var8 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.POSITIVE_INFINITY);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test243"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)90L);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test244"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(3.1562562328456267d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8667340193512345d);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test245"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, 2.0000005f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test246"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(1.4567813447268017d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9606205688734639d);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test247"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-2994189), 2995200);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5989389));

  }

//  public void test248() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest17.test248"); }
//
//
//    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//    boolean var4 = var3.isSupportUpperBoundInclusive();
//    boolean var5 = var3.isSupportUpperBoundInclusive();
//    var3.reseedRandomGenerator((-7053352210170117083L));
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      double[] var9 = var3.sample(267381171);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var4 == false);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var5 == false);
//
//  }
//
  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test249"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(2.4375639690203945d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test250"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(8.403944766223448d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.6311763787678402d));

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test251"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 2.4758799E29f, 2.0000005f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test252"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-1023.99994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test253"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    boolean var6 = var3.isSupportConnected();
    double var8 = var3.probability((-0.3827413742969658d));
    double var9 = var3.getStandardDeviation();
    boolean var10 = var3.isSupportConnected();
    double var11 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.8720980175938546d);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test254"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)2.9202368677790993d, var1, true);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    java.lang.Number var6 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 2.9202368677790993d+ "'", var6.equals(2.9202368677790993d));

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test255"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var2.getNanStrategy();
//     org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//     int var14 = var13.getNumElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//     var17.setExpansionMode(0);
//     double[] var20 = var17.getInternalValues();
//     var13.addElements(var20);
//     double var23 = var13.substituteMostRecentElement(0.0d);
//     double[] var24 = var13.getInternalValues();
//     double[] var25 = var13.getElements();
//     double[] var26 = var2.rank(var25);
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test256"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.761594154620033d, 0.31405481363425186d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.39375809765673553d);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test257"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var2 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1.6449340767586613d);
    java.lang.String var3 = var2.toString();
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var12 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    java.lang.Object[] var16 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var17 = new org.apache.commons.math3.exception.NullArgumentException(var14, var16);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var12, var13, var16);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var9, var10, var16);
    org.apache.commons.math3.exception.MaxCountExceededException var20 = new org.apache.commons.math3.exception.MaxCountExceededException(var6, (java.lang.Number)100L, var16);
    org.apache.commons.math3.exception.MathArithmeticException var21 = new org.apache.commons.math3.exception.MathArithmeticException(var5, var16);
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var4, var16);
    org.apache.commons.math3.exception.NullArgumentException var23 = new org.apache.commons.math3.exception.NullArgumentException(var0, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (1.645) exceeded"+ "'", var3.equals("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (1.645) exceeded"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test258"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1688143320063612998L, (-7053352210170117173L));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test259"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(599700145, (-9.999999f), (-10.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test260"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.7729273769421117d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6982338479906763d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test261"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.006601438076270229d);
    java.lang.Number var3 = var2.getMin();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test262"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-1), 299622400);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test263"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(2.4758803E29f, 3.814698E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.4758803E29f);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test264"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var6.setExpansionMode(0);
    double[] var9 = var6.getInternalValues();
    var2.addElements(var9);
    double var12 = var2.substituteMostRecentElement(0.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var2.copy();
    int var14 = var2.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test265"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.9634526771778158d, 0.02756156531860343d, 0.6142995902819931d);
    var3.reseedRandomGenerator(90L);
    boolean var6 = var3.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test266"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(7053352210170117273L, 109L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7053352210170117382L);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test267"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    int var7 = var2.getExpansionMode();
    float var8 = var2.getExpansionFactor();
    var2.addElement((-2.74137897748935d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100.0f);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test268"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    int var9 = var2.getExpansionMode();
    double var11 = var2.getElement(0);
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var15 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var18 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var19 = null;
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    java.lang.Object[] var22 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var23 = new org.apache.commons.math3.exception.NullArgumentException(var20, var22);
    org.apache.commons.math3.exception.MathIllegalStateException var24 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var18, var19, var22);
    org.apache.commons.math3.exception.MathIllegalStateException var25 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var15, var16, var22);
    org.apache.commons.math3.exception.MaxCountExceededException var26 = new org.apache.commons.math3.exception.MaxCountExceededException(var12, (java.lang.Number)100L, var22);
    boolean var27 = var2.equals((java.lang.Object)var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionMode(231415);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test269"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(8.639495877295877E-5d, 10.000000000000002d);
    double var3 = var2.getStandardDeviation();
    double var4 = var2.getNumericalVariance();
    var2.reseedRandomGenerator(10L);
    double var7 = var2.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 10.000000000000002d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 100.00000000000004d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-2.5548458525470656d));

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test270"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(1.556076932344376d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test271"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-2994189));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test272"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(2.4758803E29f, 100.50001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.4758803E29f);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test273"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, (-1023.9999f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1023.9999f));

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test274"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-11800));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11800);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test275"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var3, var5);
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    java.lang.Object[] var12 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var10, var12);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var9, var12);
    var6.addSuppressed((java.lang.Throwable)var14);
    java.lang.Throwable[] var16 = var6.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var17 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MaxCountExceededException var18 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)(-38937600), (java.lang.Object[])var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test276"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     double var4 = var3.getSupportUpperBound();
//     double var5 = var3.getStandardDeviation();
//     double var6 = var3.sample();
//     double var7 = var3.getNumericalMean();
//     double[] var9 = var3.sample(2995200);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var11 = var3.sample(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.8623188722876839d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.9886254048738587d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.8720980175938546d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test277"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(487531);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test278"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp((-1023.99994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.1035156E-5f);

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test279"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.lang.Object[] var3 = new java.lang.Object[] { (byte)1};
//     org.apache.commons.math3.exception.NullArgumentException var4 = new org.apache.commons.math3.exception.NullArgumentException(var1, var3);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var0, var3);
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     java.lang.Number var7 = null;
//     org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
//     java.lang.Throwable[] var10 = var9.getSuppressed();
//     org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var6, var7, (java.lang.Object[])var10);
//     var5.addSuppressed((java.lang.Throwable)var11);
//     org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var11);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test280"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(4.0503838303319295d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.619464246405281d);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test281"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(1015, 3.8146977E-6f, 0.00390625f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test282"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     double var4 = var3.getSupportUpperBound();
//     double var5 = var3.sample();
//     double var6 = var3.sample();
//     double var7 = var3.getMean();
//     double var9 = var3.cumulativeProbability(2.6517813881497876d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.026308988921917d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.124744363886165d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.8720980175938546d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.3991710879403839d);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test283"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-0.4459607124434285d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.551115123125783E-17d);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test284"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var5, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var7);
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var1, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test285"); }


    float var2 = org.apache.commons.math3.util.FastMath.max((-9.999999f), 3.8146973E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.8146973E-6f);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test286"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0L, (-3628799L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test287"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp((-0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test288"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3.8239280375108544d, (java.lang.Number)1.0334835754536079E-8d, (java.lang.Number)1.0012991368777728d);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.0012991368777728d+ "'", var5.equals(1.0012991368777728d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1.0012991368777728d+ "'", var6.equals(1.0012991368777728d));

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test289"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var5 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)(short)100, var3, (java.lang.Number)(-0.07369898640584448d));
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test290"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(267381171, (-1023.99994f), 3.8146973E-6f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test291"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(273112767, 22809501);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test292"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.773355349013742d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test293"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.030466191178101454d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.03047562080496639d);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test294"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    boolean var7 = var5.equals((java.lang.Object)3.2913344041497453E-22d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test295"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-1024), 596708);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 595684);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test296"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(596708, 596708);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test297"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var6 = var2.probability(45.0d);
//     boolean var7 = var2.isSupportConnected();
//     double var8 = var2.getMean();
//     double var9 = var2.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.767508297530451d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.19240232444172617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1.4674124598147955d));
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test298"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test299"); }


    float var2 = org.apache.commons.math3.util.FastMath.max((-0.0012207031f), 100.49999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.49999f);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test300"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(2.6287023951487374d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.49069766153528105d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test301"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Number var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.NotPositiveException var7 = new org.apache.commons.math3.exception.NotPositiveException(var5, (java.lang.Number)0.976508918599899d);
    java.lang.Throwable[] var8 = var7.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, var4, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)(short)10, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test302"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0L, (-100L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test303"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double[] var8 = var7.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test304"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-0.3655932269839443d));
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test305"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-0.003637992555936794d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test306"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.15719982251077522d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7755575615628914E-17d);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test307"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var2 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var7, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, var9);
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var2.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var14 = var2.getContext();
    java.lang.Throwable[] var15 = var2.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test308"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(2.97848141639784d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4387929404494277d);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test309"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.24434410597703024d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.276783603776272d);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test310"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-0.29866442992225317d));

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test311"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    boolean var4 = var3.isSupportConnected();
    double var5 = var3.getMean();
    double var7 = var3.density(189.32744069823292d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var3.cumulativeProbability(1.553344806071505d, 1.2702602426089444d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test312"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(6.1035156E-5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.1035156E-5f);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test313"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    boolean var6 = var3.isSupportConnected();
    boolean var7 = var3.isSupportLowerBoundInclusive();
    double var8 = var3.getMean();
    var3.reseedRandomGenerator(10L);
    double var11 = var3.getStandardDeviation();
    double[] var13 = var3.sample(900);
    double var14 = var3.getMean();
    double[] var16 = var3.sample(230382);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test314"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.0d, 1.5692474232144973d, 2.97848141639784d);
//     double var4 = var3.sample();
//     double var6 = var3.cumulativeProbability(0.8621389868659827d);
//     boolean var7 = var3.isSupportLowerBoundInclusive();
//     double var8 = var3.getMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0225708227390458d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.4649972832707442d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0d);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test315"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    var2.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var12.setExpansionMode(0);
    double[] var15 = var12.getInternalValues();
    var12.clear();
    double var18 = var12.addElementRolling(0.7853981633974483d);
    var12.addElement(0.0d);
    var12.setNumElements(100);
    boolean var23 = var2.equals((java.lang.Object)var12);
    org.apache.commons.math3.util.ResizableDoubleArray var24 = var12.copy();
    var12.setContractionCriteria(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test316"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(61.19997931247053d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3506.500520892511d);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test317"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(125.31727114935688d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 125L);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test318"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.0d, 0.5374300498232759d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test319"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(49513393, 599700245);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test320"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(200600, 1.1641534E-10f, 2.4758803E29f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test321"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.8999371873429769d);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test322"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.9443504370351304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8101162859461107d);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test323"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    int var2 = var1.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var6 = var5.getNumElements();
    int var7 = var5.start();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
    int var9 = var5.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var5);
    var1.setExpansionFactor(1.0000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test324"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(4.5474735E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test325"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test326"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-41), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-41));

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test327"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(231415, 1349403648);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1750179841);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test328"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.6506783754890694d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6506783754890694d);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test329"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var2.setContractionCriteria(100.0f);
    var2.contract();
    int var11 = var2.getNumElements();
    var2.setExpansionMode(0);
    var2.contract();
    double var16 = var2.addElementRolling(1.1272454077910206d);
    int var17 = var2.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var23 = new double[] { 100.0d, 1.0d};
    var20.addElements(var23);
    float var25 = var20.getExpansionFactor();
    var20.setExpansionMode(0);
    double[] var28 = var20.getInternalValues();
    var2.addElements(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test330"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    var3.reseedRandomGenerator(0L);
    boolean var8 = var3.isSupportLowerBoundInclusive();
    double var10 = var3.cumulativeProbability(2.2683541557421067d);
    double var11 = var3.getMean();
    double var12 = var3.getNumericalMean();
    boolean var13 = var3.isSupportLowerBoundInclusive();
    double var14 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.24191996538778948d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == Double.POSITIVE_INFINITY);

  }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test331"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.0d, 1.5692474232144973d, 2.97848141639784d);
//     double var4 = var3.sample();
//     double var5 = var3.getSupportUpperBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.5638523242779049d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test332"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     double var4 = var3.getSupportUpperBound();
//     double var5 = var3.getStandardDeviation();
//     double var6 = var3.sample();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var8 = var3.sample(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.8623188722876839d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.514947137580798d);
// 
//   }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test333"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.09894964678763474d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0991111957234688d);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test334"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.7612753675628248d, (java.lang.Number)7.569397550458789d, true);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test335"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0L, 7053352210166488461L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7053352210166488461L);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test336"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-0.08748125829655995d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test337"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    var2.setElement(10, 0.7612753675628248d);
    var2.discardFrontElements(0);
    double[] var10 = var2.getInternalValues();
    float var11 = var2.getExpansionFactor();
    int var12 = var2.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test338"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.6735095436595417d), 0.1241950607613301d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test339"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(25.90611268385252d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 25.0d);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test340"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var2.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test341"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-1025), (-9.999999f), 6.1035156E-5f, (-3));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test342"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(3.8320988864621484E8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.832098886462149E8d);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test343"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.5484577758343545d, (java.lang.Number)0.9188014802486864d, false);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test344"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var6, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test345"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = var2.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test346"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.04529464298044572d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3564639486684279d);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test347"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    int var8 = var7.getNumElements();
    var7.setContractionCriteria(1.2379401E29f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test348"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-0.03201769847914048d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.03201769847914048d);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test349"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var5 = new org.apache.commons.math3.exception.NullArgumentException(var2, var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var4);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var0, var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test350"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-0.08767394869871506d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test351"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    var3.reseedRandomGenerator(0L);
    boolean var8 = var3.isSupportLowerBoundInclusive();
    double var10 = var3.cumulativeProbability(2.2683541557421067d);
    double var12 = var3.probability(0.8407359138160451d);
    double var13 = var3.getStandardDeviation();
    double var15 = var3.probability(1.2642564124929525d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.24191996538778948d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test352"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getNumericalVariance();
    double[] var8 = var3.sample(100);
    boolean var9 = var3.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test353"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(2995200, 273112767);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-270117567));

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test354"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.2846447019565141d, 0.9995668109270821d, 4.283475365339624d, 1750179841);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.318171979926787d);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test355"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(1.4991609099582168d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 85.89559295159785d);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest17.test356"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var2.getNanStrategy();
//     double[] var7 = null;
//     double[] var8 = var2.rank(var7);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test357"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(1.2846447019565141d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7376730054035044d);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test358"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var2.setContractionCriteria(100.0f);
    int var10 = var2.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var2.getElement(0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test359"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.6142995902819931d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.550867608907326d);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test360"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(0L, 1024L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1024L));

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test361"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.5686929365266755d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9658803846023474d);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test362"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.00386516731768749d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-9));

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test363"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-7053352210170117173L), 852815195628176636L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3500636589265068335L));

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test364"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    var2.addElement(0.6506783754890694d);
    int var9 = var2.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var12 = var10.substituteMostRecentElement(0.9565627942373829d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.6506783754890694d);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test365"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(7053352210170117161L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7053352210170117160L);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest17.test366"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)0, (java.lang.Number)1L, (java.lang.Number)0.6506783754890694d);
    java.lang.Number var4 = var3.getArgument();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    java.lang.Object[] var15 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var16 = new org.apache.commons.math3.exception.NullArgumentException(var13, var15);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var11, var12, var15);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var9, var15);
    org.apache.commons.math3.exception.util.ExceptionContext var19 = var8.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var20 = var8.getContext();
    java.lang.Throwable[] var21 = var8.getSuppressed();
    java.lang.Throwable[] var22 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var23 = new org.apache.commons.math3.exception.MathArithmeticException(var6, (java.lang.Object[])var22);
    org.apache.commons.math3.exception.MathIllegalStateException var24 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, (java.lang.Object[])var22);
    java.lang.Throwable[] var25 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)0+ "'", var4.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

}
