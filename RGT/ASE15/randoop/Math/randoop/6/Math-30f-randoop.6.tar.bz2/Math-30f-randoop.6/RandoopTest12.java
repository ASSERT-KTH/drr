
import junit.framework.*;

public class RandoopTest12 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test1"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var6, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, var8);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var1.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var1.getContext();
    java.lang.String var14 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (-1) exceeded"+ "'", var14.equals("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (-1) exceeded"));

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test2"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-9), 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test3"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (-1) exceeded");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test4"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.3581288330251856d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test5"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(7081.058387126132d, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 14162.116774252265d);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test6"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0, (java.lang.Number)5.551115123125783E-17d, var3);
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test7"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(90L, (-90L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 180L);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test8"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.00824820856234747d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.734723475976807E-18d);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test9"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.2702602426089444d, 1.2825498340254313d, 1.034525803447559d, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.6681363173166157d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test10"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double var4 = var2.addElementRolling(0.6506783754890694d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test11"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-9), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-9));

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test12"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0L, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100L);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test13"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(1.107194659485365d, 0.7853981633974483d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0832618148996653d);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test14"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-0.07655602848313875d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.07369898640584448d));

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test15"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(3.291334404149745E-22d, (-9));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.42838750810497E-25d);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test16"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.5374300498232759d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1479251422110193d);

  }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test17"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(2.97848141639784d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test18"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 10.0f, (-1.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test19"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-0.07369898640584448d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4.222640875446916d));

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test20"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-9), 10.0f, 0.0f, (-9));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test21"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.02756156531860343d, 0.9302363507574447d, (-0.48346953277414534d), 10);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test22"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(1.553344806071505d, 1.734723475976807E-18d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.9719625010961676d));

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test23"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(9L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test24"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.1581263863353843d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test25"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-1), 100);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test26"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(2.7760523581453453d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0d);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test27"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 50.0f, 0.0f, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test28"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test29"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(3.291334404149745E-22d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.291334404149745E-22d);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test30"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(2.074594310659796d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test31"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "org.apache.commons.math3.exception.NotPositiveException: 0 is smaller than the minimum (0)");
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test32"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(1.553344806071505d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4404105453251124d);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test33"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.9150123793192297d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9565627942373829d);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test34"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.4511708924835962d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.889694544886073d);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test35"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, 0.1919266570807596d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test36"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(49.999996f, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 49.999996f);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test37"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(90L, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100L);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test38"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.6506783754890694d, 0.8085085755675573d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.27640092266786565d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test39"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)100L);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test40"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(100.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test41"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.00787441756300009d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.00888514508528015d);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test42"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(short)10, (java.lang.Number)(-1), true);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test43"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.6097807640004534d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test44"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.05096774828087159d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3707647883932746d);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test45"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var9 = var8.getNumElements();
    double[] var10 = var8.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var8);
    double[] var12 = var2.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var2.substituteMostRecentElement(2.6058222619154248d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test46"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-0.5063656411097588d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5545968900472659d));

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test47"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    int var11 = var2.getExpansionMode();
    double var13 = var2.substituteMostRecentElement(45.0d);
    double var15 = var2.getElement(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionMode(10);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 45.0d);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test48"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(100, (-9));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 91);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test49"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.7135399484934067d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7756486815267315d);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test50"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.0d, 0.9565627942373829d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8238753788547079d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test51"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.8414709848078965d, 3.739561347646417d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8414709848078965d);

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test52"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-1.0f), (java.lang.Number)0.7853981633974483d, false);
//     java.lang.Number var5 = var4.getMin();
//     org.apache.commons.math3.exception.util.ExceptionContext var6 = var4.getContext();
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var13 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var9, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
//     java.lang.Throwable[] var14 = var13.getSuppressed();
//     org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var8, (java.lang.Object[])var14);
//     org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var7, (java.lang.Object[])var14);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test53"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.16515071930214034d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0136684045930817d);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test54"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-100L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100L);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test55"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(91, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 101);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test56"); }


    java.math.BigInteger var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test57"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(2.069655856740348d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4743594998530665d);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test58"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test59"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    int var9 = var2.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var2.getElement(100);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test60"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.7790199122525784d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.882621046799009d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test61"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.5374300498232759d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test62"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(3.291334404149745E-22d, 0.6097807640004534d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.397570075115222E-22d);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test63"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.6142995902819931d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test64"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(8.639495877295877E-5d, 10.000000000000002d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var4 = var2.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test65"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var9 = var8.getNumElements();
    double[] var10 = var8.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var8);
    var2.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var2.getElement((-9));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test66"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(0, 10);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test67"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(3.291334404149745E-22d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8142035178418503E-11d);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test68"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(0, 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 91);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test69"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.0f, 0.05096774828087159d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.99999994f);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test70"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(49.999996f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test71"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    int var11 = var2.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setElement((-1), 2.069655856740348d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test72"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 0.0f, 100.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test73"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.6449340767586613d, (java.lang.Number)1.0832618148996653d, false);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test74"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)0, (java.lang.Number)1L, (java.lang.Number)0.6506783754890694d);
    java.lang.String var4 = var3.toString();
    java.lang.String var5 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: 0 out of [1, 0.651] range"+ "'", var4.equals("org.apache.commons.math3.exception.OutOfRangeException: 0 out of [1, 0.651] range"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: 0 out of [1, 0.651] range"+ "'", var5.equals("org.apache.commons.math3.exception.OutOfRangeException: 0 out of [1, 0.651] range"));

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test75"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.010642682047134422d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test76"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-90L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-90L));

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test77"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test78"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1), 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test79"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.015017753780066721d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.015017753780066721d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test80"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(45.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 125.31727114935688d);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test81"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-1), 0.0f, 10.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test82"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000001f);

  }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test83"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(1.8142035178418503E-11d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test84"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    var2.contract();
    var2.setExpansionMode(0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var14 = var12.addElementRolling(7.560575574229005E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 100.0d);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test85"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.7435938375035029d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.1022542569867815d));

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test86"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    boolean var6 = var3.isSupportConnected();
    double var8 = var3.probability((-0.3827413742969658d));
    double var11 = var3.cumulativeProbability(0.4906578777776055d, 1.5044728995807433d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05349598516132738d);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test87"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-1), (-9));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test88"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(91, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test89"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-90L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test90"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(3.1868873092888728d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test91"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(1.4596347826973803d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.2683541557421067d);

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test92"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma((-0.3655932269839443d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test93"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000002f);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test94"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-100L), 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-109L));

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test95"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-1L), 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1L));

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test96"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.4596347826973803d, 0.1919266570807596d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4596347826973801d);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test97"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.9302363507574447d, 7.569397550458789d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.12228122537761468d);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test98"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    var2.contract();
    var2.setExpansionMode(0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setExpansionMode((-9));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test99"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(100.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.5f);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test100"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5784066910357114d);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test101"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(2.074594310659796d, 0.9150123793192297d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9150123793192297d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test102"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-1L), 90L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test103"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.6293945E-6f);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test104"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(50.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.8146973E-6f);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test105"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.0d, 2.9202368677790993d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test106"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(3.291334404149745E-22d, 0.6681363173166157d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6552836562919295d);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test107"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(90L, (-109L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test108"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(10, (-9));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test109"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.034525803447559d);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test110"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(1.8142035178418503E-11d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 24.73278948466765d);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test111"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-1), 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test112"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-100L), 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test113"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.6681363173166157d);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test114"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    java.lang.Object var7 = null;
    boolean var8 = var2.equals(var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardMostRecentElements(91);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test115"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(24.73278948466765d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.9135626894536033d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test116"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.006601438076270229d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.00744881699401668d);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test117"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(9L, 90L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5365208890106504175L));

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test118"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test119"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-9), 0.0f, (-1.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test120"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.7116024720019101d, 1.1591352365493741d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.43403492507390196d));

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test121"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(2.9135626894536033d, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4567813447268017d);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test122"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos((-0.5545968900472659d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 93.72989180803069d);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test123"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.1919266570807596d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7755575615628914E-17d);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test124"); }
// 
// 
//     org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.4596347826973801d, (java.lang.Number)1.6449340767586613d, false);
//     java.lang.Throwable var4 = null;
//     var3.addSuppressed(var4);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test125"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.4214549026638725d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test126"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     double var4 = var2.sample();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var6 = var2.sample(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.41166160151963344d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.978585176268911d);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test127"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var6.setExpansionMode(0);
    double[] var9 = var6.getInternalValues();
    var2.addElements(var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setContractionCriteria(1.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test128"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-100L), (-9));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test129"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(9L, 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7053352210170117273L);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test130"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(4.333449949606716E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.421010862427522E-20d);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test131"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double[] var7 = var3.sample(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var9 = var3.sample((-9));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test132"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(10.0f, 1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0f);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test133"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    boolean var4 = var3.isSupportConnected();
    boolean var5 = var3.isSupportConnected();
    double var6 = var3.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.8720980175938546d);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test134"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-0.5545968900472659d), 0.9997833820018625d, 0.6506783754890694d);
    double var4 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test135"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum((-0.5063656411097588d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test136"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-1.0f), (java.lang.Number)0.7853981633974483d, false);
    java.lang.Number var5 = var4.getMin();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var4.getContext();
    java.lang.Number var7 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.7853981633974483d+ "'", var5.equals(0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0.7853981633974483d+ "'", var7.equals(0.7853981633974483d));

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test137"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setExpansionMode(10);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test138"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.6506783754890694d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.57212646691672d);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test139"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(2.074594310659796d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.121634319047366d);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test140"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.3707647883932746d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4488422487920356d);

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test141"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-1.0f), (java.lang.Number)0.7853981633974483d, false);
//     java.lang.Number var5 = var4.getMin();
//     java.lang.String var6 = var4.toString();
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test142"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.5374300498232759d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.552769841758708d);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test143"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(6.42838750810497E-25d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.253658542162704E-25d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test144"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.16515071930214034d, 2.1932800507380157d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.1932800507380157d);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test145"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getNumericalVariance();
    double var7 = var3.getNumericalMean();
    var3.reseedRandomGenerator(10L);
    double var10 = var3.getSupportUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var3.cumulativeProbability(1.2825498340254313d, 0.9150123793192297d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.POSITIVE_INFINITY);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test146"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double[] var7 = var2.getElements();
    float var8 = var2.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100.0f);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test147"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double[] var7 = var3.sample(100);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setNumElements((-9));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test148"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(123.58778338131026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0920257253823424d);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test149"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.9168407258198261d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test150"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "org.apache.commons.math3.exception.OutOfRangeException: 0 out of [1, 0.651] range");
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test151"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.9995668109270821d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.999566810927082d);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test152"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(10.000000000000002d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 12.80182748008147d);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test153"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(7.569397550458789d, 1.4214549026638725d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.701708467424528d);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test154"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(91);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setElement((-9), 0.7435938375035028d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test155"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.1479251422110193d, 0.6681363173166157d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.18834749242221216d));

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test156"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(3.8146973E-6f, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.00390625f);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test157"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 91);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test158"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(91, 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 91);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test159"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-9));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test160"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.00744881699401668d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.007421211557185701d);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test161"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(100.5f, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 102912.0f);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test162"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.0832618148996653d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test163"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getNumericalVariance();
    double var7 = var3.getNumericalMean();
    var3.reseedRandomGenerator(10L);
    boolean var10 = var3.isSupportLowerBoundInclusive();
    double var12 = var3.inverseCumulativeProbability(0.006601438076270229d);
    double var14 = var3.probability(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.7377840776591889d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test164"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.0000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000002f);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test165"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(91, 7053352210170117273L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 273111867);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test166"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(91);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test167"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(10, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test168"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(100.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.6293945E-6f);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test169"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(102912.0f, 1.0000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000002f);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test170"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(8.865319877078154d, 1.1591352365493741d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4407844498728315d);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test171"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(3.291334404149745E-22d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.291334404149745E-22d);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test172"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double[] var7 = var3.sample(100);
    double var9 = var3.density(0.17453292519943298d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var11 = var3.sample((-9));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0034691670965537173d);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test173"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(5.397570075115222E-22d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.432443690009129E42d);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test174"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(1.0136684045930817d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test175"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(1.5692474232144973d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.803032182762104d);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test176"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getNumericalVariance();
    double var7 = var3.getNumericalMean();
    var3.reseedRandomGenerator(10L);
    boolean var10 = var3.isSupportLowerBoundInclusive();
    double var12 = var3.inverseCumulativeProbability(0.006601438076270229d);
    double var13 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.7377840776591889d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.8720980175938546d);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test177"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.027274760086014354d, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test178"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.8414709848078965d, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8414709848078965d);

  }

//  public void test179() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest12.test179"); }
//
//
//    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//    double var4 = var3.getSupportUpperBound();
//    double var5 = var3.getStandardDeviation();
//    boolean var6 = var3.isSupportConnected();
//    boolean var7 = var3.isSupportLowerBoundInclusive();
//    double var8 = var3.getMean();
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      double[] var10 = var3.sample(273111867);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var4 == Double.POSITIVE_INFINITY);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var5 == 0.8623188722876839d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var6 == true);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var7 == false);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var8 == 2.8720980175938546d);
//
//  }
//
  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test180"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.3707647883932746d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.93205051368808d);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test181"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.00824820856234747d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.00824820856234747d);

  }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test182"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.9999636981980967d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test183"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.5063656411097588d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5063656411097587d));

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test184"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.1900536393062961d, (java.lang.Number)0.5575415009635386d, (java.lang.Number)0.8414709848078965d);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var11 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var7, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
//     java.lang.Throwable[] var12 = var11.getSuppressed();
//     org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var6, (java.lang.Object[])var12);
//     org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var12);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test185"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-109L), 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-109L));

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test186"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.552769841758708d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.552769841758708d);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test187"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0L, (-5365208890106504175L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test188"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.7612753675628248d, 0.17453292519943298d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.5233859003736966d));

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test189"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.022170223590708048d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2702602426089444d);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test190"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    int var7 = var2.getNumElements();
    int var8 = var2.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test191"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 0.0d, 1.4407844498728315d, 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

//  public void test192() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest12.test192"); }
//
//
//    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//    double[] var5 = new double[] { 100.0d, 1.0d};
//    var2.addElements(var5);
//    var2.setNumElements(1);
//    var2.contract();
//    var2.setExpansionMode(0);
//    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
//    float var13 = var12.getExpansionFactor();
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      var12.setElement(273111867, 0.7135399484934067d);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var5);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var13 == 100.0f);
//
//  }
//
  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test193"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 273111867);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test194"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.999566810927082d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5406667711979235d);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test195"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.5374300498232759d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test196"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(100, 0.0f, 102912.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test197"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(100.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.50001f);

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test198"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)3.1757334232496706d);
//     org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test199"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var2.getTiesStrategy();
//     org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//     var8.setExpansionMode(0);
//     double[] var11 = var8.getInternalValues();
//     double[] var12 = var8.getInternalValues();
//     double[] var13 = var2.rank(var12);
// 
//   }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test200"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("org.apache.commons.math3.exception.NotPositiveException: 0 is smaller than the minimum (0)");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test201"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    float var7 = var2.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionFactor(3.8146973E-6f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100.0f);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test202"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var2.copy();
    float var4 = var3.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.discardMostRecentElements((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 100.0f);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test203"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(37.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7654140519453434d);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test204"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    var2.contract();
    var2.setExpansionMode(0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var2.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var2.getElement(10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test205"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.034525803447559d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test206"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(7053352210170117273L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7053352210170117273L);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test207"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    double var6 = var3.getMean();
    double var7 = var3.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.7435938375035028d);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test208"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test209"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(1.107194659485365d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8362251408024012d);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test210"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.9999636981980967d, 0.9022156594299824d, 0.93205051368808d, 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4688789649850351d);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test211"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    var2.contract();
    var2.setExpansionMode(0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    float var13 = var12.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setExpansionFactor(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0f);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test212"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.010642682047134422d, 0.9551779281484893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.013046161355485517d);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test213"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-100L), (-5365208890106504175L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-100L));

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test214"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-0.3655932269839443d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0d));

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test215"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-9), 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test216"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var9 = var8.getNumElements();
    double[] var10 = var8.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var8);
    var2.contract();
    float var13 = var2.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.5f);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test217"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.setElement(10, 0.6506783754890694d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setContractionCriteria(1.0000001f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test218"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(100, 273111867);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test219"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(1.2825498340254315d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9085585716960896d);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test220"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(1.0000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test221"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(1.5493099696436932d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test222"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(91, 273111867);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test223"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(3.739561347646417d, (-1.4308317753439705d), 0.9022156594299824d, 100);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test224"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.7435938375035027d, 0.6142995902819931d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.12929424722150962d);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test225"); }


    long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3628800L);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test226"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.00824820856234747d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.008248395617409584d);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test227"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(45.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test228"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.5692474232144973d, 1.0648164703369514d, 0.976508918599899d);
    double var5 = var3.density((-0.48346953277414534d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05843257187382863d);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test229"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.4906578777776055d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4906578777776055d);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test230"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(90L, 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test231"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(3.8146973E-6f, 273111867);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test232"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(2.461644881538276d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6841730320232351d);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test233"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(15.05551425958108d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.880143587495324d);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test234"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.7654140519453434d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5683852532105546d);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test235"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.93205051368808d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.53971155532965d);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test236"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(1L, 90L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test237"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-0.3827413742969658d));

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test238"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(1, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test239"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(91, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test240"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(1.2825498340254313d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0677664646480862d);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test241"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(1.107194659485365d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 12.289172084189628d);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test242"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.0000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test243"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(100, 0.0f, 1.0000002f, 91);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test244"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(1L, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test245"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.0000001f, 0.7377840776591889d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test246"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(2.1932800507380157d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test247"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p((-0.3655932269839443d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.45506493246367297d));

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test248"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getNumericalVariance();
    double var8 = var3.probability(0.5683852532105546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test249"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-100L), 7053352210170117273L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7053352210170117173L);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test250"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(1.0648164703369514d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.018584553336844337d);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test251"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(2.53971155532965d, 0.9997833820018625d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9997833820018625d);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test252"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test253"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-1.0f), 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1024.0f));

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test254"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(7053352210170117173L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7053352210170117173L);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test255"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-5365208890106504175L), 7053352210170117173L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1688143320063612998L);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test256"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(2.6287023951487374d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.011669054126255E-4d);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test257"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(49.999996f, 0.9085585716960896d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 49.999992f);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test258"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    var2.contract();
    var2.setExpansionMode(0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test259"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var2 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var5, var7);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var4, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test260"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setNumElements((-9));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test261"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(90L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 90L);

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test262"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportUpperBoundInclusive();
//     double var5 = var2.getNumericalMean();
//     double var6 = var2.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.7108770633520998d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.19240232444172617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.283475365339624d);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test263"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    var2.setNumElements(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionFactor(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test264"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, 49.999992f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test265"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)90L);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test266"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(57.295779276891516d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999958776928d);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test267"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-5365208890106504175L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5365208890106504175L);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test268"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.7790199122525784d, 0.7435938375035029d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.03542607474907544d);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test269"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0L, 7053352210170117173L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test270"); }


    float var2 = org.apache.commons.math3.util.FastMath.min((-1.0f), 3.8146973E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0f));

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test271"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(5365208890106504175L, (-5365208890106504175L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5365208890106504175L);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test272"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.9999999958776928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8427007912385143d);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test273"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 1.0000001f, (-1024.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test274"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.6506783754890694d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6057263101794392d);

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test275"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     double var4 = var3.getSupportUpperBound();
//     double var5 = var3.getStandardDeviation();
//     double var6 = var3.sample();
//     boolean var7 = var3.isSupportUpperBoundInclusive();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var9 = var3.sample(273111867);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.8623188722876839d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.6819714379513795d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test276"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    var2.contract();
    var2.setExpansionMode(0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var2.copy();
    float var14 = var13.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 100.5f);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test277"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var4, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test278"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)5.397570075115222E-22d);
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded"+ "'", var2.equals("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded"));

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test279"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-1L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1L));

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test280"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var2.substituteMostRecentElement(1.121634319047366d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test281"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test282"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-1), 1.0000001f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

//  public void test283() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest12.test283"); }
//
//
//    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//    org.apache.commons.math3.util.ResizableDoubleArray var3 = var2.copy();
//    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//    double[] var9 = new double[] { 100.0d, 1.0d};
//    var6.addElements(var9);
//    var6.setNumElements(1);
//    int var13 = var6.getExpansionMode();
//    double var15 = var6.getElement(0);
//    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var6);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      var2.setNumElements(273111867);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var3);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var9);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var13 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var15 == 100.0d);
//
//  }
//
  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test284"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-90L), (-9));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test285"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(3.8146973E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-18));

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test286"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(57.295779276891516d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test287"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(100.50001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test288"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(10, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test289"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(7053352210170117273L, 9L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test290"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(7.5812308201226335d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 434.37252950753066d);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test291"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(1.1479251422110193d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8170655554314067d);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test292"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double var6 = var2.addElementRolling(0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionFactor((-1024.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test293"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var3, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.util.ExceptionContext var11 = var10.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test294"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(125.31727114935688d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 125.3172711493569d);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test295"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(7.701708467424528d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7303477737455633d);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test296"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.011669054126255E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-13));

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test297"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-18), 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-18));

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test298"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-0.18834749242221216d), 0.1900536393062961d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0017061468840839367d);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test299"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0L, 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test300"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.9565627942373829d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.019286515134173187d));

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test301"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(3.291334404149745E-22d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.291334404149745E-22d);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test302"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(273111867, 100);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test303"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test304"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-9), 100);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test305"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.93205051368808d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3707647883932745d);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test306"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
//     java.lang.Number var5 = var4.getMax();
//     java.lang.Throwable var6 = null;
//     var4.addSuppressed(var6);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test307"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.00390625f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-8));

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test308"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.05096774828087159d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05094568456366692d);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test309"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(4.333449949606716E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2308.2067090921896d));

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test310"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var3.setExpansionMode(0);
    double[] var6 = var3.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var10 = var9.getNumElements();
    double[] var11 = var9.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var3);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test311"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.626074551533144d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.010927062287200275d);

  }

//  public void test312() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest12.test312"); }
//
//
//    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//    var2.setExpansionMode(0);
//    double[] var5 = var2.getInternalValues();
//    double[] var6 = var2.getInternalValues();
//    java.lang.Object var7 = null;
//    boolean var8 = var2.equals(var7);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      var2.setElement(273111867, 12.80182748008147d);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var5);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var6);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var8 == false);
//
//  }
//
  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test313"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.013707783890401887d, 0.014741327437840844d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.014741327437840844d);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test314"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var1.substituteMostRecentElement(0.7135399484934067d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test315"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.552769841758708d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8206943562278073d);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test316"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    var2.setNumElements(100);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var2.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var13.copy();
    float var15 = var13.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 100.0f);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test317"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.027274760086014354d);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test318"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(1L, 7053352210170117173L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7053352210170117172L));

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test319"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(5365208890106504175L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test320"); }


    int var1 = org.apache.commons.math3.util.FastMath.round((-1024.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1024));

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test321"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(3.1868873092888728d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.04527916949109096d));

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test322"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9L);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test323"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var2.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var3.getElement(0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test324"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    double[] var8 = var7.getInternalValues();
    var7.addElement(0.02756156531860343d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test325"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.0136684045930817d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.755691487042354d);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test326"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-0.5545968900472659d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test327"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(2.2683541557421067d, 1.261404880340075d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.2683541557421067d);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test328"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    float var8 = var7.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100.0f);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test329"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(1.941575758241476d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0789454099597753d);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test330"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var9 = var8.getNumElements();
    double[] var10 = var8.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var8);
    double[] var12 = var2.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setContractionCriteria(49.999996f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test331"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1.0d);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test332"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    var2.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var12.setExpansionMode(0);
    double[] var15 = var12.getInternalValues();
    var12.clear();
    double var18 = var12.addElementRolling(0.7853981633974483d);
    var12.addElement(0.0d);
    var12.setNumElements(100);
    boolean var23 = var2.equals((java.lang.Object)var12);
    var2.setContractionCriteria(102912.0f);
    float var26 = var2.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 102912.0f);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test333"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(37.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.859571186401306E15d);

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test334"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-1.1022542569867815d), 0.018584553336844337d, 0.0d, 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test335"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(10L, (-7053352210170117172L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7053352210170117162L));

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test336"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(1.0677664646480862d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test337"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.0648164703369514d, 0.7756486815267315d, 0.013044992572946019d);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test338"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var2, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    java.lang.Throwable[] var8 = var6.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test339"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(1.553344806071505d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.892510807227735d);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test340"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(5365208890106504175L, (-109L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5365208890106504284L);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test341"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.8414709848078965d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9443504370351304d);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test342"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.00888514508528015d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.008884911277691669d);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test343"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.9302363507574447d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test344"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.9150123793192297d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.03857303026834636d));

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test345"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-18), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test346"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(1.0000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1920929E-7f);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test347"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.0000001f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000001f);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test348"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.9999999958776928d, 0.7853981633974483d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.271554272071574d);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test349"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.3657996034532164d, 0.3581288330251856d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.3657996034532164d);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test350"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(3.1868873092888728d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.9999934230547683d));

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test351"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(3.1757334232496706d, 4.333449949606716E-4d, 0.19240232444172617d);
    double var4 = var3.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4.333449949606716E-4d);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test352"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var7 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var3, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
    java.lang.Throwable[] var8 = var7.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test353"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.6142995902819931d, 3.803032182762104d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.74137897748935d));

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test354"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    var2.setNumElements(100);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var2.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var13.copy();
    float var15 = var14.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 100.5f);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test355"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-0.3655932269839443d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.006380805533860807d));

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test356"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(7.569397550458789d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.0d);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test357"); }


    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 1.0000002f, 10.0f);
    int var4 = var3.getExpansionMode();
    float var5 = var3.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 10.0f);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test358"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.941575758241476d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2475312893420674d);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test359"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-7053352210170117162L), 5365208890106504175L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3L);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test360"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(9L, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test361"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(1.0d, 5.397570075115222E-22d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test362"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(7081.058387126132d, 0.7435938375035029d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7435938375035029d);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test363"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test364"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.00390625f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test365"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.4511708924835962d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8999371873429769d);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test366"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.19240232444172617d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-5.496154324107173d));

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test367"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.6681363173166157d, 0.017453292447995462d);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test368"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var3, var5);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var2, var5);
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, var1, var5);
    java.lang.Number var9 = var8.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test369"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)5365208890106504284L, (java.lang.Number)5.551115123125783E-17d, true);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test370"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.0000002f, 100.50001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000002f);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test371"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    var2.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var2.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setElement((-13), 2.011669054126255E-4d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test372"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.14022847040561234d, 4.283475365339624d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.051925868811929E-4d);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test373"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    boolean var6 = var3.isSupportConnected();
    boolean var7 = var3.isSupportLowerBoundInclusive();
    double var8 = var3.getMean();
    boolean var9 = var3.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test374"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(434.37252950753066d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 434.37252950753066d);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test375"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.6449340767586613d, 0.0034691670965537173d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5686873292356027d);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test376"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(273111867, 273111867);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test377"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(100, (-1024));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1024));

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test378"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(5365208890106504284L, 7053352210170117173L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test379"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1L, (-90L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-89L));

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test380"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-90L), 90L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 90L);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test381"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(2.069655856740348d, 0.8414709848078965d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.234177428856803d);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test382"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.4688789649850351d, 0.8407359138160451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.4688789649850351d);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test383"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(short)100, var2, (java.lang.Number)(-0.07369898640584448d));
    java.lang.Number var5 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test384"); }


    java.math.BigInteger var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, (-13));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test385"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(1023.7781831699072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test386"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-9), 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 900);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test387"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.93205051368808d, (java.lang.Number)5365208890106504284L, true);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test388"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(5.421010862427522E-20d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test389"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.013046161355485517d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.013046901568216447d);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test390"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-13), 900);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test391"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-1024), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test392"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(1.5686873292356027d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test393"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.8623188722876839d, 4.283475365339624d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9900135569345746d);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test394"); }


    java.math.BigInteger var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, (-8));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test395"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.302585092994046d);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test396"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.17453292519943298d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.17543139267904398d);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test397"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.17453292519943298d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test398"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 0.17940889770647472d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test399"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var3 = new org.apache.commons.math3.exception.NullArgumentException(var0, var2);
    org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var7, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, var9);
    var3.addSuppressed((java.lang.Throwable)var11);
    java.lang.Throwable[] var13 = var3.getSuppressed();
    org.apache.commons.math3.exception.util.ExceptionContext var14 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test400"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(100, 0.00390625f, 49.999996f, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test401"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-0.3655932269839443d));

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test402"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.10446901610108233d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1048515747957178d);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test403"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-2308.2067090921896d), 0.3657996034532164d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.011211302394241729d));

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test404"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(2.755691487042354d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.32327241927233d);

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test405"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     java.lang.Object[] var5 = new java.lang.Object[] { (byte)1};
//     org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var3, var5);
//     org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var2, var5);
//     org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, var1, var5);
//     org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var8);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test406"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.2702602426089444d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test407"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var6, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, var8);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var1.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var1.getContext();
    java.lang.Number var14 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (-1.0d)+ "'", var14.equals((-1.0d)));

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test408"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getSupportLowerBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var3.inverseCumulativeProbability((-2308.2067090921896d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.NEGATIVE_INFINITY);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test409"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.9150123793192297d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.875547735158801d);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test410"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.1048515747957178d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 28.850559977393456d);

  }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test411"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var2.getTiesStrategy();
//     org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//     double[] var11 = new double[] { 100.0d, 1.0d};
//     var8.addElements(var11);
//     int var13 = var8.getExpansionMode();
//     float var14 = var8.getExpansionFactor();
//     double[] var15 = var8.getElements();
//     double[] var16 = var2.rank(var15);
// 
//   }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test412"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.121634319047366d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0698672482364424d);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test413"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.5044728995807433d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1458509338674643d);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test414"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-1.7952220558689955d), (-1.0648164703369514d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0648164703369514d));

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test415"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(100.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test416"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(1.0677664646480862d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8181592221453744d);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test417"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.05096774828087159d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.2927045528110097d));

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test418"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(10.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-10.0f));

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test419"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    int var8 = var2.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test420"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.9443504370351304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8414709848078964d);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test421"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.5493099696436932d, 0.27640092266786565d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.1090955663635007d));

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test422"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.9168407258198261d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9168407258198262d);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test423"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.0d, 3.2544789518188435d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.2544789518188435d);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test424"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.4567813447268017d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test425"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.6506783754890694d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6975744860120546d);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test426"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(1.1458509338674643d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8948703487679698d);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test427"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    var2.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var2.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardFrontElements((-1024));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test428"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(900, 273111867);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test429"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-1024));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test430"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.1919266570807596d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test431"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var2.setContractionCriteria(100.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var2.getElement(0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test432"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.9999999958776928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5574077105338615d);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test433"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(91, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test434"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(10, 273111867);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test435"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(50.0f, 5.551115123125783E-17d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 49.999996f);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test436"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var9 = var8.getNumElements();
    double[] var10 = var8.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var8);
    double[] var12 = var2.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var2.substituteMostRecentElement(0.8206943562278073d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test437"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
//     java.lang.Throwable[] var4 = var3.getSuppressed();
//     org.apache.commons.math3.exception.NullArgumentException var5 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var4);
//     org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var4);
//     org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var6);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test438"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(50.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test439"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.02756156531860343d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.469446951953614E-18d);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test440"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.contract();
    var2.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test441"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)100.50001f, (java.lang.Number)0.7853981633974483d, true);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test442"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.8085085755675573d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test443"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    int var9 = var2.getExpansionMode();
    var2.setElement(0, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionMode((-9));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test444"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.10446901610108233d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.10485073303358433d);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test445"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.9022156594299824d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9154696972910814d);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test446"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(7.701708467424528d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.0d);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test447"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.022170223590708048d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.02217385702297738d);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test448"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(7053352210170117173L, (-13));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test449"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(2.7760523581453453d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4966969119672996d);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test450"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)0, (java.lang.Number)1L, (java.lang.Number)0.6506783754890694d);
    java.lang.Number var4 = var3.getArgument();
    java.lang.Number var5 = var3.getHi();
    java.lang.Number var6 = var3.getLo();
    java.lang.Number var7 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)0+ "'", var4.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.6506783754890694d+ "'", var5.equals(0.6506783754890694d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1L+ "'", var6.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1L+ "'", var7.equals(1L));

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test451"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(2.6058222619154248d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 149.30261776898763d);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test452"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1, (-13));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test453"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(100.0f, 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.47588E29f);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test454"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(1.4596347826973801d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.3043872045584766d);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test455"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-0.48346953277414534d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.38335977740402544d));

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test456"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.93205051368808d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8125360099710831d);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test457"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.1900536393062961d, (java.lang.Number)0.5575415009635386d, (java.lang.Number)0.8414709848078965d);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test458"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.0f, 273111867);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test459"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.6975744860120546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.15640941223089536d));

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test460"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test461"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var2 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    java.lang.Throwable[] var3 = var2.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test462"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    float var7 = var2.getExpansionFactor();
    var2.setExpansionMode(0);
    double var11 = var2.substituteMostRecentElement(0.4511708924835962d);
    double var13 = var2.getElement(0);
    int var14 = var2.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test463"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getNumericalVariance();
    boolean var5 = var3.isSupportUpperBoundInclusive();
    boolean var6 = var3.isSupportUpperBoundInclusive();
    double var8 = var3.density(0.6142995902819931d);
    double var10 = var3.probability(1.941575758241476d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.015017753780066721d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test464"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-1024), 900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 230400);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test465"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(1.9450663976980598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2846447019565141d);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test466"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.0f, 50.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test467"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    int var11 = var2.getExpansionMode();
    double var13 = var2.substituteMostRecentElement(45.0d);
    double var15 = var2.addElementRolling(0.17940889770647472d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 45.0d);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test468"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0, (-1024));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test469"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.7790199122525784d, (java.lang.Number)0.7435938375035027d, (java.lang.Number)1.2702602426089444d);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test470"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)7081.058387126132d, (java.lang.Number)2.8720980175938546d, true);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var11 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var7, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
    java.lang.Throwable[] var12 = var11.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var6, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test471"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(2.6530145023882725d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.653014502388273d);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test472"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)2.234177428856803d, var2, false);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test473"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(900, (-13));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-11700));

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test474"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(100.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test475"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(15.05551425958108d, (-0.9999934230547683d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 15.055514259581079d);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test476"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var5, var7);
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    java.lang.Object[] var14 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var12, var14);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var10, var11, var14);
    var8.addSuppressed((java.lang.Throwable)var16);
    java.lang.Throwable[] var18 = var8.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var19 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)1.8142035178418503E-11d, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalArgumentException var20 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathInternalError var21 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalArgumentException var22 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test477"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     double var4 = var2.sample();
//     var2.reseedRandomGenerator(0L);
//     double var9 = var2.cumulativeProbability(0.10485073303358433d, 0.9085585716960896d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.1621345753505397d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-3.1735994179935405d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.1522099054496074d);
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test478"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.lang.Object[] var11 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var9, var11);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var8, var11);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var11);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var11);
    org.apache.commons.math3.exception.MathArithmeticException var16 = new org.apache.commons.math3.exception.MathArithmeticException(var1, var11);
    org.apache.commons.math3.exception.NullArgumentException var17 = new org.apache.commons.math3.exception.NullArgumentException(var0, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test479"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.17453292519943298d, (-1.1822300333796267d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test480"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)8.639495877295877E-5d, (java.lang.Number)4.3318907109302085E-4d, true);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test481"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.5403023093369417d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test482"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var9 = var8.getNumElements();
    double[] var10 = var8.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var8);
    double[] var12 = var2.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var2.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test483"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var8 = var7.getExpansionMode();
    float var9 = var7.getExpansionFactor();
    var7.setNumElements(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0f);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test484"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var4 = new org.apache.commons.math3.exception.NullArgumentException(var1, var3);
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test485"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-8), 91);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test486"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.12228122537761468d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4963483631908118d);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test487"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(273111867);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 273111867);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test488"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(3.432443690009129E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.99074437799629E40d);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test489"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 0.0f, 0.0f, 10);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test490"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.0000001f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000001f);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test491"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.8085085755675573d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8995179335935495d);

  }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test492"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-0.5063656411097588d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test493"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.8206943562278073d, 0.9565627942373829d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8206943562278073d);

  }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test494"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.7108770633520998d), (java.lang.Number)0.9999999958776928d, true);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test495"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    float var8 = var7.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test496"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    int var7 = var2.getExpansionMode();
    float var8 = var2.getExpansionFactor();
    double[] var9 = var2.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setNumElements((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test497"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(100L, 1688143320063612998L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100L);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test498"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.7612753675628248d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test499"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(49.999992f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test500"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    int var8 = var7.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);

  }

}
