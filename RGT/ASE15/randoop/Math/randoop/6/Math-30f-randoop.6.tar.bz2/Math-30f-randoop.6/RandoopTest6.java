
import junit.framework.*;

public class RandoopTest6 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test1"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-1.5589094839887239d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-84.1226654420322d));

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test2"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextUniform(0.2577047455984825d, 13.770182159584014d);
//     long var6 = var1.nextPoisson(23.012289905639566d);
//     int var9 = var1.nextZipf(10178, 0.5950413774252329d);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var10.reseedRandomGenerator(2L);
//     double[] var14 = var10.sample(100000);
//     double var15 = var10.getMean();
//     double var16 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     boolean var17 = var10.isSupportConnected();
//     double var18 = var10.getStandardDeviation();
//     boolean var19 = var10.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 7.202185394179175d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 19L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 8336);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.22815125620326132d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test3"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.0d, (-0.03314181870292297d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.03738285042296366d));

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test4"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(596L, 104L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 596L);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test5"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.718887609175217d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2L);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test6"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    int var6 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var14.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var13, var15);
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var15);
    java.lang.String var18 = var15.name();
    java.lang.Class var19 = var15.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var15);
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "AVERAGE"+ "'", var18.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test7"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(962, 1260);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1260);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test8"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(10.85264471496672d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.075426589840563d);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test9"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double var2 = var0.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test10"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-0.7618917772261586d), 0.012504468662168831d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7619943844552646d);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test11"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.24197688819531704d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7321951198744487d);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test12"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(1.0226040926379294d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.780425831130733d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test13"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.014931963725887733d, 0.010100839201864612d);
    double var3 = var2.getNumericalMean();
    double var4 = var2.getNumericalVariance();
    double var6 = var2.cumulativeProbability(4.5d);
    double var8 = var2.density(0.010200975372259509d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.014931963725887733d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0202695258192494E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 35.39286706296104d);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test14"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-79579695));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test15"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var11 = var9.sample();
//     double var13 = var9.probability(7.444490968701611d);
//     double var14 = var9.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.797429825798508d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ab5ab87ba0"+ "'", var8.equals("ab5ab87ba0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5511164092704044d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2.5499720777443087d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test16"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.0471975511965979d);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test17"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.addElement(0.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var6.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var9.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test18"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(2.5000002f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5000002f);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test19"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-1.5157441040969926d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.1487053114842738d));

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test20"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(11049, 1836);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4964.803228775253d);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test21"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(5.366170923935078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.881784197001252E-16d);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test22"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.36944668344557197d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.31440677756159524d);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test23"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.6146912258939091d), (java.lang.Number)(-0.6371506328342675d), true);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test24"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(8106L, 40420L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 163822260L);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test25"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.setElement(8899, 2.3930658372149933d);
    var4.clear();
    var4.setContractionCriteria(2.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.setElement((-297258196), 2.5345538362242994d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test26"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(11.727752825295894d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.20468790066148068d);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test27"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var4 = var0.getMean();
    double var5 = var0.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test28"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
    java.lang.Object var17 = null;
    boolean var18 = var4.equals(var17);
    var4.setElement(100, 0.0d);
    double[] var22 = var4.getInternalValues();
    float var23 = var4.getExpansionFactor();
    int var24 = var4.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.discardMostRecentElements(1319);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test29"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1541, 962);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test30"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var14 = var0.nextGamma(0.15861286098539223d, 23.79178096943456d);
//     double var17 = var0.nextWeibull(0.01005033585179189d, 8.024814059539063E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.911749035071693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "de8d585484"+ "'", var8.equals("de8d585484"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 95);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.768156154292684E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.287123383678145E-108d);
// 
//   }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test31"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(4.979830522251364d, 790.5397402246074d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.979830522251365d);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test32"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-0.8444824053746879d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test33"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextBeta(0.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.693943439748915d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "21681774c0"+ "'", var8.equals("21681774c0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6L);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test34"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.9999999999999971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test35"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)Double.NaN, var2, false);
    java.lang.Number var5 = var4.getMax();
    java.lang.Number var6 = var4.getMax();
    boolean var7 = var4.getBoundIsAllowed();
    java.lang.Number var8 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test36"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     java.lang.String var13 = var0.nextHexString(10);
//     var0.reSeedSecure();
//     double var17 = var0.nextGaussian(7.042014262199385d, 1.179103839756096d);
//     double var20 = var0.nextCauchy((-1.4998528973459138d), 2.7076386898590252d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var0.nextGaussian((-0.3224933123994597d), (-0.33976362125025183d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 24.028854499473336d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "51592586e4"+ "'", var8.equals("51592586e4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "cf84e12ccd"+ "'", var13.equals("cf84e12ccd"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 6.456366677423398d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-5.2694528048403715d));
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test37"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    int var3 = var1.ordinal();
    java.lang.String var4 = var1.name();
    java.lang.String var5 = var1.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "AVERAGE"+ "'", var5.equals("AVERAGE"));

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test38"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.004247795915723208d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0042568305887467d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test39"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-1342156216L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1342156216L);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test40"); }


    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var7);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 11L);
    java.math.BigInteger var11 = null;
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0L);
    java.math.BigInteger var14 = null;
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 0L);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, var16);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 1949);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, var19);
    org.apache.commons.math3.exception.OutOfRangeException var21 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)6.88482624909385d, (java.lang.Number)1.1515109860475812d, (java.lang.Number)var10);
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test41"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(1.2096972657305856d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.35246959147738d);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test42"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(2.172616570636548d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2951727423469757d);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test43"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-0.791428230168399d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6592173641653114d));

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test44"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.1368686E-13f, (-623678255));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test45"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var13 = var0.nextT(5.867156662812015d);
//     double var16 = var0.nextGamma(0.13558023874553457d, 0.010050505059049992d);
//     double var18 = var0.nextChiSquare(0.8847656390164815d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var0.nextInt(9973, 1868);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7319073651315473d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "703f84757d"+ "'", var8.equals("703f84757d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.1310424723826899d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 9.414067271863588E-20d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.3299296510157821d);
// 
//   }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test46"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     int var20 = var0.nextBinomial(0, 0.7615941559557649d);
//     double var23 = var0.nextWeibull(1.2075656224493654d, 2.265662238504449d);
//     var0.reSeedSecure(40318L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var28 = var0.nextSecureLong(6379912561590279263L, 1348L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.5023946965871917d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "14e7efd1133833ffebf0d41c989815d5607e1a15b7dc16eb03c9edf3f76623506211728784460150d53993446bb5c1548e50"+ "'", var8.equals("14e7efd1133833ffebf0d41c989815d5607e1a15b7dc16eb03c9edf3f76623506211728784460150d53993446bb5c1548e50"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.11780362056723065d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.5409971516516723d);
// 
//   }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test47"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)363.7393755555636d);
    java.lang.Number var2 = var1.getMax();
    java.lang.Throwable[] var3 = var1.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 363.7393755555636d+ "'", var2.equals(363.7393755555636d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test48"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-0.7749761678134572d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6592951788605901d));

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test49"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(70L, 319L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-249L));

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test50"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var0.nextSample(var9, 10241);
// 
//   }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test51"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     double var10 = var0.nextT(20.696514663540924d);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var11.getStandardDeviation();
//     double[] var14 = var11.sample(1);
//     double var15 = var11.getMean();
//     double[] var17 = var11.sample(100);
//     double var18 = var11.sample();
//     double var19 = var11.sample();
//     double var20 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var22 = var0.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.517405791703696d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "9bae6f7d4c28edad73785d8849a51ff4bc76a83033697f522f60f9ac1440dd1a3cb4f0dbb0de87f62e29b4507f81f6ba942c"+ "'", var8.equals("9bae6f7d4c28edad73785d8849a51ff4bc76a83033697f522f60f9ac1440dd1a3cb4f0dbb0de87f62e29b4507f81f6ba942c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.1554160303471772d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.9557546953151963d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.4608351452642344d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.8804829712062479d);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test52"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.016357636867740992d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.01635690748051865d);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test53"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    boolean var7 = var0.isSupportUpperBoundInclusive();
    double var8 = var0.getStandardDeviation();
    double var9 = var0.getSupportLowerBound();
    var0.reseedRandomGenerator(0L);
    double var12 = var0.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test54"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
    java.lang.Object var17 = null;
    boolean var18 = var4.equals(var17);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = var4.copy();
    int var20 = var19.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test55"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.6766585644239601d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8229246505322634d);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test56"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var3 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var1, (java.lang.Number)0.0d);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var5 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test57"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(2.6082651747100596d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13.575479326644766d);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test58"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.4128411121633297d, (java.lang.Number)0.0f, (java.lang.Number)3.2359311173302077d);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getHi();
    java.lang.Number var6 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.0f+ "'", var4.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 3.2359311173302077d+ "'", var5.equals(3.2359311173302077d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 3.2359311173302077d+ "'", var6.equals(3.2359311173302077d));

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test59"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.9999999f, 1.1368685E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1368685E-13f);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test60"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(4.5656690655869046d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7166172049198016d);

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test61"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
//     java.lang.Class var3 = var2.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     java.lang.String var5 = var2.toString();
//     java.lang.String var6 = var2.toString();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var2);
//     org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var11 = var8.nextSecureLong((-1L), 1L);
//     double var14 = var8.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var16 = var8.nextHexString(10);
//     int var19 = var8.nextPascal(8899, 0.8219866295031046d);
//     double var21 = var8.nextExponential(0.010050505059049992d);
//     var8.reSeed(104L);
//     boolean var24 = var2.equals((java.lang.Object)var8);
//     org.apache.commons.math3.distribution.NormalDistribution var25 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var26 = var25.getStandardDeviation();
//     double[] var28 = var25.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var28);
//     var29.contract();
//     var29.addElement(0.0d);
//     int var33 = var29.getExpansionMode();
//     double[] var34 = var29.getElements();
//     float var35 = var29.getContractionCriteria();
//     boolean var36 = var2.equals((java.lang.Object)var29);
//     double var38 = var29.substituteMostRecentElement(0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "AVERAGE"+ "'", var5.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 7.996399943030428d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "8c2cf88cbc"+ "'", var16.equals("8c2cf88cbc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1953);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0014120608642600961d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0.0d);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test62"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(9, 1919);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 17271);

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test63"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("309c8da6e3f41fceed47ee4e46b42bc1c3eb3463ca1e93fbea8180a65e7275f5834e1bbc49c71e705704ca7fc43765836ba7", "10ad2a7de3");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 16.988238608632873d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "e90e113968"+ "'", var8.equals("e90e113968"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 6);
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test64"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(3, 1953);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1953);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test65"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.3573657141508644d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1650603907741712d);

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test66"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(100L);
//     double var18 = var0.nextGamma(8.0d, (-1.8376749185262546d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var0.nextPascal((-519016991), (-0.925960459757085d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.69472767532435d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "4e502a68b6"+ "'", var8.equals("4e502a68b6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.06592501778071126d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 9761);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-17.58677127752253d));
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test67"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(192, 1931);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1931);

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test68"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var2 = var0.cumulativeProbability((-0.5745618421848383d));
//     double var3 = var0.sample();
//     var0.reseedRandomGenerator((-8L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.28279383239600014d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.8230779895764548d);
// 
//   }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test69"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-1.1622852906955334d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.141058021488773d);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test70"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextWeibull(7.769493748166378d, 1.2185657441986304d);
//     var0.reSeed(201600L);
//     int[] var11 = var0.nextPermutation(10743, 1910);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.2317920685636914d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test71"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.9999992616956026d, 9448);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test72"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.9999996994297856d, 0.7549981365369203d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999996994297856d);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test73"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.0d, 18.860854671741663d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 18.860854671741663d);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test74"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("0a71e473c0");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test75"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextUniform(0.2577047455984825d, 13.770182159584014d);
//     long var6 = var1.nextPoisson(23.012289905639566d);
//     int var9 = var1.nextZipf(10178, 0.5950413774252329d);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     var10.reseedRandomGenerator(2L);
//     double[] var14 = var10.sample(100000);
//     double var15 = var10.getMean();
//     double var16 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     org.apache.commons.math3.distribution.NormalDistribution var17 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var18 = var17.getStandardDeviation();
//     double[] var20 = var17.sample(1);
//     double var22 = var17.cumulativeProbability(0.0d);
//     double var23 = var17.getSupportUpperBound();
//     boolean var24 = var17.isSupportUpperBoundInclusive();
//     double var25 = var17.getStandardDeviation();
//     double var26 = var17.getStandardDeviation();
//     double var27 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var17);
//     double var30 = var1.nextCauchy(0.6081011993472895d, 16.35282631844513d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.8284917303032415d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 23L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1625);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.3723104530465187d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == (-0.04333104391869323d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 116.37840993773725d);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test76"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.6650434548901554d, 0.1557414973394419d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1557414973394419d);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test77"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh((-47.561794942941404d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.2635760879410207E20d));

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test78"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     double var15 = var0.nextF(9.954021851066004d, 2.566440443196982d);
//     double var17 = var0.nextT(1.1908427023981165d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 20.818654222193594d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d19168d773"+ "'", var8.equals("d19168d773"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 7.444490968701611d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.1427236382207493d);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test79"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test80"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(1.0000000000000049d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test81"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     double var14 = var0.nextChiSquare(4.950886585270677E-4d);
//     long var16 = var0.nextPoisson(0.8109766711360142d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15.095802671691928d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "49ef055ef3"+ "'", var8.equals("49ef055ef3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.4328197799036929E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2L);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test82"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(7.492701067417301d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.6464439284783032d);

  }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test83"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var14 = var0.nextGamma(0.15861286098539223d, 23.79178096943456d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextBinomial(3376, 7.111978169622012d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.666070464960185d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "869e213f96"+ "'", var8.equals("869e213f96"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.5252292716682683d);
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test84"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var1.contract();
    float var3 = var1.getContractionCriteria();
    var1.setElement(1498, 1.9524344320409814d);
    double[] var7 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    var8.contract();
    int var10 = var8.start();
    float var11 = var8.getContractionCriteria();
    float var12 = var8.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.5f);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test85"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    var4.setNumElements(1818);
    double[] var10 = var4.getElements();
    var4.setNumElements(95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test86"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(10.0f, 2.384186E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.384186E-7f);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test87"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(408490575, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test88"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(2187);
    int var2 = var1.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionFactor(1.4E-45f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test89"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(1499, 9066);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test90"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-1912), 0.0f, 10.5f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test91"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var4 = var0.getMean();
    var0.reseedRandomGenerator((-2L));
    double var7 = var0.getSupportUpperBound();
    double var8 = var0.getSupportLowerBound();
    double var10 = var0.inverseCumulativeProbability(0.2679364507635598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-0.6190659680329689d));

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test92"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-4.440892098500626E-16d), 1.1102230246251565E-16d, 0.9999494957997512d);
//     double var4 = var3.getMean();
//     double var5 = var3.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-4.440892098500626E-16d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-8.244174900448879E-16d));
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test93"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    var1.addElement(2.0216852347077916d);
    org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var5 = var4.getStandardDeviation();
    double[] var7 = var4.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var12 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var11, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var10, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var9, (java.lang.Object[])var12);
    boolean var16 = var8.equals((java.lang.Object)var9);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var8);
    int var18 = var1.start();
    org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var20 = var19.getStandardDeviation();
    double[] var22 = var19.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    org.apache.commons.math3.exception.util.Localizable var24 = null;
    org.apache.commons.math3.exception.util.Localizable var25 = null;
    org.apache.commons.math3.exception.util.Localizable var26 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var27 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var28 = new org.apache.commons.math3.exception.NullArgumentException(var26, (java.lang.Object[])var27);
    org.apache.commons.math3.exception.MathInternalError var29 = new org.apache.commons.math3.exception.MathInternalError(var25, (java.lang.Object[])var27);
    org.apache.commons.math3.exception.NullArgumentException var30 = new org.apache.commons.math3.exception.NullArgumentException(var24, (java.lang.Object[])var27);
    boolean var31 = var23.equals((java.lang.Object)var24);
    var23.setElement(8899, 2.3930658372149933d);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var23);
    org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var36);
    double var39 = var1.substituteMostRecentElement((-0.8813847905209903d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0216852347077916d);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test94"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.5d, (java.lang.Number)0.5950413774252329d, false);
    java.lang.String var4 = var3.toString();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 0.5 is smaller than, or equal to, the minimum (0.595)"+ "'", var4.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 0.5 is smaller than, or equal to, the minimum (0.595)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test95"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1845, 9424);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9424);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test96"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    boolean var5 = var1.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var8, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = var15.getNanStrategy();
    org.apache.commons.math3.distribution.NormalDistribution var17 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var18 = var17.getStandardDeviation();
    boolean var19 = var17.isSupportUpperBoundInclusive();
    double[] var21 = var17.sample(100);
    double[] var22 = var15.rank(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test97"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.6650434548901554d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test98"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     var0.reSeed(14L);
//     double var14 = var0.nextExponential(0.9999997887160175d);
//     long var16 = var0.nextPoisson(0.8259324122591327d);
//     double var18 = var0.nextT(1.8325125324523532d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.11877936884155d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5375a126cf"+ "'", var8.equals("5375a126cf"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.17352734392916913d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.3844973909690124d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2.1852017790592613d);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test99"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(241L, 5071615437313169417L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5071615437313169176L));

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test100"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double[] var6 = var0.sample(100);
//     double var7 = var0.sample();
//     double var8 = var0.sample();
//     double var10 = var0.probability((-0.3722334692039834d));
//     double var12 = var0.probability(0.7681252299306625d);
//     boolean var13 = var0.isSupportConnected();
//     double var15 = var0.probability(2.263521840245945d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.41257010628178525d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.7954940717022425d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test101"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(100.00001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.6293945E-6f);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test102"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-0.8961189234469322d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test103"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var6);
    java.lang.String var9 = var6.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var10 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.Class var12 = var2.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var14 = java.lang.Enum.<java.lang.Enum>valueOf(var12, "24a00cd4cd");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "AVERAGE"+ "'", var9.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test104"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.7895105047158603d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test105"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.clear();

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test106"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextUniform(0.2577047455984825d, 13.770182159584014d);
//     long var6 = var1.nextPoisson(23.012289905639566d);
//     int var9 = var1.nextZipf(10178, 0.5950413774252329d);
//     double var12 = var1.nextF(0.8057138887308153d, 5.668146255993159d);
//     org.apache.commons.math3.distribution.IntegerDistribution var13 = null;
//     int var14 = var1.nextInversionDeviate(var13);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test107"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.0031612049524534893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test108"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(29.90785919790278d, (-0.8438409461494198d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.37342608267308597d);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test109"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1929.4784382564899d);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test110"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 243);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 4L);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 40486L);
    java.math.BigInteger var13 = null;
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 0L);
    java.math.BigInteger var16 = null;
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 0L);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, var18);
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 243);
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 76L);
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var21);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, (-5071615437313169176L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test111"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1L, 193L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 194L);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test112"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var5 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var3, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test113"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.3841864E-7f, Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test114"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(4.0434293412271454E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0442469174590314E-4d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test115"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 24.0d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test116"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(1.3212360281535291d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.27856768342816046d);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test117"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     double var30 = var0.nextExponential(1.0471975511965979d);
//     var0.reSeed(70L);
//     var0.reSeed((-1342156216L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.8188929084501755d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "12bffeba0e"+ "'", var8.equals("12bffeba0e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1943);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.02629215190910916d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-0.5112096773220509d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.28360074307339134d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-2.5244024552889823d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.1609204618510406d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 2.710049021368652E-34d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 0.13377302914083797d);
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test118"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(13.502589127875854d, 1.231623725294084d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4798341438042115d);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test119"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.13558023874553457d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.009205088280614d);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test120"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(4337, 1972);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1972);

  }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test121"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     var0.reSeed(100L);
//     org.apache.commons.math3.distribution.NormalDistribution var34 = new org.apache.commons.math3.distribution.NormalDistribution((-4.440892098500626E-16d), 1.1102230246251565E-16d, 0.9999494957997512d);
//     double var35 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var34);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var39 = var0.nextUniform(0.7187353997098677d, 1.0202695258192494E-4d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.7831917047413d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "a527b5b3cd"+ "'", var8.equals("a527b5b3cd"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1967);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.018555984069846165d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-2.8117330809035135d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.025975564646964315d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-1.1286272215678732d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.5272542723974653d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1.2159382172127E-64d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == (-5.315982015318238E-16d));
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test122"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.993405468012823d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.017338196224138975d);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test123"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.0111995598490069d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000627157259385d);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test124"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(10.0f, 0.823778062325079d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.999999f);

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test125"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var6);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var6);
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var12 = var9.nextSecureLong((-1L), 1L);
//     double var15 = var9.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var18 = var9.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var20 = var19.getStandardDeviation();
//     double[] var22 = var19.sample(1);
//     double var24 = var19.cumulativeProbability(0.0d);
//     double var25 = var19.getSupportUpperBound();
//     double var26 = var9.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var19);
//     var9.reSeed();
//     boolean var28 = var6.equals((java.lang.Object)var9);
//     java.lang.String var29 = var6.name();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 3.4828309946604796d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-0.321191615172387d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + "AVERAGE"+ "'", var29.equals("AVERAGE"));
// 
//   }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test126"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(16.157907382418067d, 7.769493748166378d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16.157907382418067d);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test127"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double[] var2 = var0.sample(1910);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var3.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test128"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-4.440892098500626E-16d), 1.1102230246251565E-16d, 0.9999494957997512d);
    double[] var5 = var3.sample(1972);
    var3.reseedRandomGenerator(56L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var3.cumulativeProbability(5.1870964420955135d, 1.0226040926379294d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test129"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh((-0.4954181796575776d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5432155789230914d));

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test130"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    var0.reseedRandomGenerator(2L);
    double[] var4 = var0.sample(100000);
    double var5 = var0.getMean();
    var0.reseedRandomGenerator(1600L);
    double var9 = var0.cumulativeProbability(0.0d);
    double var11 = var0.probability(0.12953442899394188d);
    double var13 = var0.inverseCumulativeProbability(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == Double.NEGATIVE_INFINITY);

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test131"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.7625552649455967d, (-0.6974171281913673d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test132"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     long var8 = var0.nextPoisson(0.10516633568161556d);
//     int var11 = var0.nextSecureInt(0, 1859);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.846616734487505d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 271);
// 
//   }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test133"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     double var9 = var0.nextF(2.281783181607902d, 0.8427007929497151d);
//     double var12 = var0.nextGaussian(1.5498468927479463d, 1865.0d);
//     java.util.Collection var13 = null;
//     java.lang.Object[] var15 = var0.nextSample(var13, (-79579695));
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test134"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    var4.clear();
    float var9 = var4.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.discardMostRecentElements(243);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.5f);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test135"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(2106, 6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.20315545057639648E17d);

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test136"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     var0.reSeedSecure();
//     double var10 = var0.nextGamma(1.257156203792693d, (-1.765071985168704d));
//     java.lang.String var12 = var0.nextHexString(192);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.032188899448257d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-6.100747048741361d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "45d76d32c5545ef42b6989cd46d5b15bef7332204e22f53ad870ca7012cf6ca3d464d6983b7610e34711d51b13fb1b1dc9c0dac840b25f378a188b74a387932d1e1c366ea0ee62756ee1cc209f600239c000f29cb6d1cf500557908dd2ba6969"+ "'", var12.equals("45d76d32c5545ef42b6989cd46d5b15bef7332204e22f53ad870ca7012cf6ca3d464d6983b7610e34711d51b13fb1b1dc9c0dac840b25f378a188b74a387932d1e1c366ea0ee62756ee1cc209f600239c000f29cb6d1cf500557908dd2ba6969"));
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test137"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(3392210);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3392210);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test138"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-1L), 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test139"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.6040591714375757d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8295301247226612d);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test140"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-6.864234430433094d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test141"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-508));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test142"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-0.47677502178730174d), false);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test143"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-2.580151816032994d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.0d));

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test144"); }


    double var2 = org.apache.commons.math3.special.Erf.erf((-2.0166116874290902d), 0.37342608267308597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.3982273963063068d);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test145"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("f5e1fe0cb98336916b7eca55bc2bc55098208c0353cd04ab23868fda878581b82ba4fc5376fed4709e514bc44baa560e1ade99c33bba7d2fd6ef358998421df0de6045940ac5e78d77f3a1b109ee45a7c9a822e4ef707c1c835fd30892a31672d47ef84cc21b4b924c036d612fd2533d2288025c1012dedd83a99fbd210f5b0fdf154c36ec31434839ed8a262d726c22864edff15c41b1171ae599a8427e307e6facf9afbbb9cc6da0651d126cc702e6ce557f97559b8c00a7c21040bd3d320542a513888dc29361dada5acf51507e7264e9b134bc956764d80bdfb1bec0059ae96d57548e3537c70e7e1fbb2891bea0870c4c1708989c12a1b29d4c6d02c7dd150dcb16dc969240f9ed1f822c59961faf2b42136cfb556c0e10f77dee8fc0171d01a8860658795db6f5b68f27c4cedf1fc2f3426b513c70e32fc79b2c061586b5f6fe4508592cdcc5e244dec6f85fbbbbfccfc59476b1a2ab9ce80b454eeeb77a1e3f10068e504dfec5a0c0394b9f4ed9b06fbcb607395baaf15ab4a2eb8bc9dc43b5a4348be4e8cff374363ac2ebe903caa08873fa1c3ebd4b702e3f4f144dda397443f9762854acda26e7233e6e838f936c53485e8746a825effed880e6a154e4c4172305e3990ef24c936efe24c029bad6e4313334f4d45563a69a2e3d281f69624991d6ac4c47e7695e3eb60e05f117a6f093798fcd2868f9bc8dcbb5c2e3b52d8b0e0596ff9b1989208ccf84aeb3291ef63ae8550310ecad586e4d3e9e7a9cd0b93a25424a8063665535b02cb5b3aabb8cf6b8d57fe93634d02ca18c8bbad1eae7349dfd8460f4e0645caf4e3716aae5cefc172349f79da39b5541c2ac5c48049e8bcbe958eb2bdbfb3706301504cbd62ccbf5745d14ead731406de4a3281ab0921ac70a752da59268edac3ad919d6f7f1a7c53aefe60674f5b6605cd7a98dd58a535f94ca02603a1e742c0aa598fe58414eb296ab3f689a4ea6ff47c87d8c6132e39d3988cdf87152d1b596262290b39c5e34f571dfb87a7627f80487801651fa35ec08ff29251a98abe50be71ea3e27ddae4c62318f36e5e5a29e9a60aa71e991fe8df87e0a67b4c134514d2f432305d6801a51f7bd88001267e002989fc08d659817a4f51cd362c5094e2f4a55e4d1c7a4cc58bfdb0b90939f49b7f96884e9813679271c72c7322ecfc53888a170b0581e1612804496b07a82a099e520caef4bd92ac0dfd3039717375f7cfd50131fac3da3a5d9002527df5947ff066d008b129e1cfb82c4fd6fc90244aa98c5c4b8d82072bb7bf4287f4707410f29f34780d3bc4f9390da508548909b30c460a3047646bd4f4f9f00e325c4a77b27fb2238d0793481da5d2cbca437c15ecf11a6e6c4a18aa483a3a767182e6b3b9407468dc8704dad00413545a48b0b54ab61a9e75a750cdb610d32ea690d7e5d3fbe397aa2d56694dd851d8878d0b99de115e65b4a39318671573fa0581ebbfb778f91745b992e606122e96cbe78e517bd4e1f3512b53b453c114238de03808c56aabcfd6876b5e983c92c4be9d221a6d360c4e835dbc93fc00b0488ed09b6b1e110e9fc70961c0dacab4e2f6000dce7d220015f77b1535a856be75937a0ce561c4077b9350471de7443e2bff6d5983f881461e870304b8989025562cb8d405c4b0ea9f8e5c7de1b8fa8ea92239b74f88a22f4a033bcc280ec7d1f80185bc830b11604ae5c480d1283c71c4664edade4e622465f563afe2000ab268f3987821e02d5e9ef2223715e403721d04d9d809dd4e76cc231f9b0a27ea07229e2a24c9fb1a5f8821f573f5d6c621f9aead6fad1761b4af6837dacb112f16315565fbe305ee5f640726c2a83424560e36719e8c24fb5260a8ea68214d9d3cb3efbcc43a104c1e2a71f45a3328cb82c4db65f62993124ae71fa72fc15e18f59694a682dc6e302e2cf1b9823d79af4d45fd856a93aa7c26d7ec65a95b8bc88ccab042b1068602607477045bdc47ff37e4f2aee19aca703057747bec6f2ab6abb44043ce3725b9356171eab7f7f875615db5033d7c670340fc9afd4804f635e63368cd33a7dbf5b9f2e41693a704921eca313b29a83bda6b1011bf53307d6ea3c00aef5b09584e467ee37cf7b57a4324c89bd927949a3bba8f728e8c501ebcd45b37965ce67fa1e3d0a20642e62e31cd686b5b5393ae4fc08c4aa4dbb4ab7e170a8ee9ef441c906aa13113f906f5085692aae03fb6aba7fee1b57a43eb461fc29fe3a7099c3fb814c38ec6ea5d77f3e811d1d6fa9c7e4242d89052ee76a0fdc55ab3508e363cfbad72a993c73b8b2af1ac1bbb081c278fe91ef460d7efc92cbf4056b65b178d1409ae2ee8f51541d41c3a9657832fda05e0fbe3fc0a4e64f29a9579d0dd615c3399ea63b7a0d8e18b91333f74a6eff7b930cc86e58122de5ccf02929379150bf0d5e225d47aa4c28554be0294af491b994ca2e67209ba70805e321cd9300e46a3f7445bd7449993ddc8bed3315030c234730943cd04247615156daeb8b134e93a53e9da8c26d95dc7dd0b5419992e12d5de1c214c7ec6e56d20c342444c8bf4be2cfb19d1787207aa2b5c907cbe7e4f6b2dc29531e69d21135a145b04ebf19dd256c3633cea61e178fd687493fe2c5ac543fe7bf2db59cda591e3659c47a35336d8fbfc6b80f8e5043c47dd48f1606785a6dcca25f6b6fafe");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test146"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     int var7 = var6.getNumElements();
//     double var9 = var6.substituteMostRecentElement(31.862892444737472d);
//     var6.setNumElements(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var6.discardFrontElements(2187);
//       fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
//     } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.6353581547035607d);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test147"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(14L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test148"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(104L, (-762L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-79248L));

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test149"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(21.2757826017609d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.057569458824525d);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test150"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.912933013825568d, (java.lang.Number)9.536744E-7f, (java.lang.Number)0.27820249749496384d);
    java.lang.Number var5 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 9.536744E-7f+ "'", var5.equals(9.536744E-7f));

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test151"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.01769023239467293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.017847631327128872d);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test152"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.012504468662168831d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.012505120463464766d);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test153"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(byte)10, (java.lang.Number)1.004502795607019d, (java.lang.Number)0.6775251650305985d);
    java.lang.Number var4 = var3.getHi();
    java.lang.Number var5 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.6775251650305985d+ "'", var4.equals(0.6775251650305985d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)10+ "'", var5.equals((byte)10));

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test154"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(2.8E-45f, 2.5000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.8E-45f);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test155"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(1999, 1919);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.269495958997823E144d);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test156"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var4.addElement((-0.43408597923864894d));
//     double var10 = var4.getElement(0);
//     double[] var11 = var4.getElements();
//     var4.addElement(21.0d);
//     var4.setNumElements(3);
//     org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var17 = var16.getStandardDeviation();
//     double[] var19 = var16.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
//     var20.contract();
//     int var22 = var20.getNumElements();
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var20);
//     org.apache.commons.math3.util.ResizableDoubleArray var24 = var4.copy();
//     org.apache.commons.math3.distribution.NormalDistribution var25 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var26 = var25.getStandardDeviation();
//     double[] var28 = var25.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var28);
//     double[] var30 = var29.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray(var30);
//     org.apache.commons.math3.exception.util.Localizable var32 = null;
//     org.apache.commons.math3.exception.util.Localizable var33 = null;
//     org.apache.commons.math3.exception.util.Localizable var34 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var38 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var34, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
//     java.lang.Throwable[] var39 = var38.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var40 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var33, (java.lang.Object[])var39);
//     org.apache.commons.math3.exception.MathArithmeticException var41 = new org.apache.commons.math3.exception.MathArithmeticException(var32, (java.lang.Object[])var39);
//     boolean var42 = var31.equals((java.lang.Object)var39);
//     double[] var43 = var31.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var31);
//     float var45 = var4.getExpansionFactor();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.974699020211872d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 2.0f);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test157"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.8325125324523532d, 1.7044581484917243d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.4391773457503936d);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test158"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.8998293095978018d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test159"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)6.409807892850133d);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test160"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    var1.addElement(2.0216852347077916d);
    org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var5 = var4.getStandardDeviation();
    double[] var7 = var4.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var12 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var11, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var10, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var9, (java.lang.Object[])var12);
    boolean var16 = var8.equals((java.lang.Object)var9);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var8);
    int var18 = var1.getExpansionMode();
    var1.setNumElements(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test161"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     int var20 = var0.nextBinomial(0, 0.7615941559557649d);
//     double var23 = var0.nextWeibull(1.2075656224493654d, 2.265662238504449d);
//     var0.reSeedSecure(40318L);
//     org.apache.commons.math3.distribution.NormalDistribution var26 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var27 = var26.getSupportUpperBound();
//     double var29 = var26.inverseCumulativeProbability(0.9999999999928669d);
//     double var31 = var26.density(25.472636453138065d);
//     double var32 = var26.getMean();
//     double var33 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var26);
//     java.lang.String var35 = var0.nextHexString(206);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 21.81540355439196d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "3a42c5474d17bd274c76cd2cb75707f205dca245d0633058360554eb6554a5d621502053afad03616967f86aebeca0c73663"+ "'", var8.equals("3a42c5474d17bd274c76cd2cb75707f205dca245d0633058360554eb6554a5d621502053afad03616967f86aebeca0c73663"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.04002941178126392d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.9647253354011498d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 6.755176609774487d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 5.055823438644928E-142d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.46766997557463486d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + "b98515a43ebcc0905f1b071a57ac283d90cc50c5b21de552c97d94c144e16b28eb42f9320e1f3b57df292dfe02757ea075ae794e244486b9eae67d4d73726dbf3d3869c38a80257e188a662c85202fe8e44d85a056683cd9a14c9b9836f878d704574a49ba34be"+ "'", var35.equals("b98515a43ebcc0905f1b071a57ac283d90cc50c5b21de552c97d94c144e16b28eb42f9320e1f3b57df292dfe02757ea075ae794e244486b9eae67d4d73726dbf3d3869c38a80257e188a662c85202fe8e44d85a056683cd9a14c9b9836f878d704574a49ba34be"));
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test162"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(1135069411L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1135069411L);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test163"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    int var7 = var6.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.discardFrontElements(136);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test164"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2979.9579870417283d);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test165"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     java.lang.String var13 = var0.nextHexString(10);
//     var0.reSeedSecure();
//     double var17 = var0.nextGaussian(7.042014262199385d, 1.179103839756096d);
//     long var19 = var0.nextPoisson(7.406617040824975d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var0.nextHypergeometric((-408490575), 119986, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15.092377322207843d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "6d219a57a8"+ "'", var8.equals("6d219a57a8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "5318853882"+ "'", var13.equals("5318853882"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 7.601178060125523d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 12L);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test166"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.015673944082810035d, 0.9915639738034129d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9915639738034129d);

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test167"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     double var16 = var0.nextGamma(0.11604808277231957d, 0.8382617516745859d);
//     var0.reSeedSecure();
//     int[] var20 = var0.nextPermutation(305, 189);
//     double var23 = var0.nextCauchy((-0.12889359106140577d), 110.38582314186594d);
//     int var26 = var0.nextZipf(1962, 2.2943872924270243d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.350784650181663d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "af06ab406e"+ "'", var8.equals("af06ab406e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.1320544510856154d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 8435);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.1650094414153976E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 21.86927808496264d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test168"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-5071615437313169176L), 1541);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test169"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getStandardDeviation();
//     double[] var13 = var10.sample(1);
//     double var15 = var10.cumulativeProbability(0.0d);
//     double var16 = var10.getSupportUpperBound();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     var0.reSeed();
//     double var21 = var0.nextGamma(0.0d, 6.621888603197341d);
//     int var24 = var0.nextSecureInt(3, 100000);
//     java.lang.String var26 = var0.nextHexString(326);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9.770764564815813d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.3897475523462606d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 45295);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "fc24527eb8e75b90f99cf80676157f1967b1ac60f4c0524eea8fe34307bd0eee5061a66217174684f8d7c2271fac8c3ebfead4e14284db62a67191f5070012dccc6bce42f4c4095e77e182d3566f0571ad644731659b417b4878e5142611126c6fe7b750e97b5256066bc439d9ce8f0ddefe30f6d3a3ad9883bc4499798e94ded6a15a8386e799e97c6a2201c41b94ae02b2af6d9f6941aaa5acc3a1406366f38f5e1d"+ "'", var26.equals("fc24527eb8e75b90f99cf80676157f1967b1ac60f4c0524eea8fe34307bd0eee5061a66217174684f8d7c2271fac8c3ebfead4e14284db62a67191f5070012dccc6bce42f4c4095e77e182d3566f0571ad644731659b417b4878e5142611126c6fe7b750e97b5256066bc439d9ce8f0ddefe30f6d3a3ad9883bc4499798e94ded6a15a8386e799e97c6a2201c41b94ae02b2af6d9f6941aaa5acc3a1406366f38f5e1d"));
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test170"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(5071615437313169417L, 1544L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test171"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getNumericalVariance();
    boolean var2 = var0.isSupportLowerBoundInclusive();
    double var3 = var0.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test172"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(4.2130907952045655d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.065745099454661d);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test173"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)4.876708896375146d, var2, true);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Number var7 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var9 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var5, (java.lang.Number)(-12.669478029470282d), var7, false);
    var4.addSuppressed((java.lang.Throwable)var9);
    java.lang.Number var11 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test174"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(40326L, (-762L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6L);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test175"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    var1.addElement(2.0216852347077916d);
    org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var5 = var4.getStandardDeviation();
    double[] var7 = var4.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var12 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var11, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var10, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var9, (java.lang.Object[])var12);
    boolean var16 = var8.equals((java.lang.Object)var9);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var8);
    int var18 = var1.start();
    org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var20 = var19.getStandardDeviation();
    double[] var22 = var19.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    org.apache.commons.math3.exception.util.Localizable var24 = null;
    org.apache.commons.math3.exception.util.Localizable var25 = null;
    org.apache.commons.math3.exception.util.Localizable var26 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var27 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var28 = new org.apache.commons.math3.exception.NullArgumentException(var26, (java.lang.Object[])var27);
    org.apache.commons.math3.exception.MathInternalError var29 = new org.apache.commons.math3.exception.MathInternalError(var25, (java.lang.Object[])var27);
    org.apache.commons.math3.exception.NullArgumentException var30 = new org.apache.commons.math3.exception.NullArgumentException(var24, (java.lang.Object[])var27);
    boolean var31 = var23.equals((java.lang.Object)var24);
    var23.setElement(8899, 2.3930658372149933d);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var23);
    org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var36);
    double[] var38 = var36.getInternalValues();
    float var39 = var36.getContractionCriteria();
    double[] var40 = var36.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test176"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.8382617516745859d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test177"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
//     org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
//     org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
//     boolean var12 = var4.equals((java.lang.Object)var5);
//     var4.addElement(20.696514663540924d);
//     double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
//     java.lang.Object var17 = null;
//     boolean var18 = var4.equals(var17);
//     org.apache.commons.math3.util.ResizableDoubleArray var19 = var4.copy();
//     var4.addElement(6.621888603197341d);
//     double var23 = var4.addElementRolling((-2.0073159449835396d));
//     float var24 = var4.getExpansionFactor();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 20.696514663540924d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.03770544487127397d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 2.0f);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test178"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(1932, 8336);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test179"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getSupportLowerBound();
//     double var5 = var0.sample();
//     double var6 = var0.getNumericalVariance();
//     double var7 = var0.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-1.4905347891443887d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.44329109023477187d));
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test180"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = null;
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var8);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 6L);
    org.apache.commons.math3.exception.OutOfRangeException var12 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)5.363952139253263d, (java.lang.Number)14.087081017797523d, (java.lang.Number)var11);
    java.lang.Number var14 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var16 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)12.887557044182769d, var14, false);
    var12.addSuppressed((java.lang.Throwable)var16);
    java.lang.Number var18 = var12.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test181"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.56089788532758d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1614707615747435d);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test182"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(97944, 889);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test183"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-1.956031495333756d), 1.5707963267948968d, 0.03449694538827916d);
    double var5 = var3.density(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.1169693979558116d);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test184"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.discardMostRecentElements(1);
    int var15 = var4.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = var4.copy();
    double var18 = var4.addElementRolling(2.478622967831918d);
    var4.setNumElements(1491);
    var4.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test185"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    var1.addElement(2.0216852347077916d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionMode(1909);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test186"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(8435, 657);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test187"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-297256655), 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-549943631));

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test188"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-64L), (-249L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 15936L);

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test189"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var21 = var18.nextSecureLong((-1L), 1L);
//     double var24 = var18.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var26 = var18.nextSecureHexString(100);
//     double var28 = var18.nextT(20.696514663540924d);
//     org.apache.commons.math3.distribution.NormalDistribution var29 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var30 = var29.getStandardDeviation();
//     double[] var32 = var29.sample(1);
//     double var33 = var29.getMean();
//     double[] var35 = var29.sample(100);
//     double var36 = var29.sample();
//     double var37 = var29.sample();
//     double var38 = var18.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     double var39 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var29);
//     double var42 = var0.nextGaussian(0.9999999627393439d, 0.022352405844223155d);
//     double var45 = var0.nextWeibull(0.8273175524905445d, 0.003960709268216542d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var48 = var0.nextBinomial(6, 3.2462374214935577d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.0670041325650037d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ddff4196254062d002001b740c67765359d88c88f27cc72db59854f192548b7975d37134627b82ffc868153b01926b5dc8b1"+ "'", var8.equals("ddff4196254062d002001b740c67765359d88c88f27cc72db59854f192548b7975d37134627b82ffc868153b01926b5dc8b1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.13977722584124042d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 20.83930969099319d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "7a7f51a24a1fcd5a558aa1bc771832067f8201bcb275142a4237a7e95cd935520105fd6c6f935dbd81846aceb0576fb5ddbd"+ "'", var26.equals("7a7f51a24a1fcd5a558aa1bc771832067f8201bcb275142a4237a7e95cd935520105fd6c6f935dbd81846aceb0576fb5ddbd"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.7116021543374569d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == (-0.3914564759249213d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0.7256946472310718d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0.08067368264610796d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-0.5688188328961719d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0.9861216088853432d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 3.711218067212115E-4d);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test190"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    boolean var8 = var6.equals((java.lang.Object)Double.POSITIVE_INFINITY);
    boolean var10 = var6.equals((java.lang.Object)(-0.4255538433808183d));
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    int var13 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test191"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 1949);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 4L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, (-623678255));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test192"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.41759531141436157d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 20.692321524420652d);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test193"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.9999998f, 2.5000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9999998f);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test194"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var14 = var0.nextBeta(3628800.0d, 1.1752011936438014d);
//     java.lang.String var16 = var0.nextHexString(1859);
//     var0.reSeedSecure(2985984L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 14.696019027888845d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5d98682977"+ "'", var8.equals("5d98682977"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.999999780983435d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "a4adfd9afa30a15ef58de907f99dd51d0eb4b7ada5aa03b7fabf0891d9d6f9bb3d46c339ebf79dbb8dcce2cea94ec0b76f9c668f36274f179cdedf57fc0a3394e553865b230a5e639b7ce3db64603aa3ba936d7974a58a6dafe68fabd23789b580f6eb07fce8aae8d50f5a37e35a533e30e90fdf061bd840e41ce6645e03ee29d3667bbf7c5d53c589fe620b07ceccbe06cdfa4119cb041ffc2c4b3740de450e2c460e27ae756c2916fd646f34c6225df46db72aec8265978e849cbca49c5ebea161f8908345f6d76b94631a9b13449664acb26d513a006b97d892df96dd17036ce0170f7ccc2fded81bad434399e715fa4c98587fa7d33cf32fe26fd5c7d282871f3c305967c9c110eeec85d7fab0928abbee2f05df1e04e73f12a44967104d75dcf400c3aa619b5ce055df119f0d31bb9c9b461f444ed7e7d9558435c44df57b6435869df218043655a4b294fa115a3baa167213689d92b763e79709d543fc35e4fe275e70aba6bd53fd32baa3f8e0e494aa60a2c9a03aedc920cfab7d718ef10ab2c8375290af89011c969d2b50e930e9fe2a48ce9a020575ea6104e8e91de93f56a505745e8c5fed5491736baabf4785e0bd946baf05929757b780eab726bdbcb2046c26d3074dba097e39142f82c88a284e9ef016486e36e82ed14b19c601771c8209e062705375df4a7706091152be085a6c9f85d066f9a6232f2c625506025833475efb06e819e5911e6982758d1f423145cb5df7c420ec4c245b4ee078353ea003e3cd7f6f8e6859ced250745cfcaeca110f7d16debed6e4e39c78b87bd153c41a22450725d84683314c8363eda8265b94c1dc336282499f9095bd692d8fb9e10d11c2782e5d81deef17c8a097035912d2a9925ede9e73ab43ed18abb723197d2cb82f4765e1618c4809fa89a94924b8ec8f5a441e3a61cdfc4e976c63ea1b0eb976187833050ff4315ddc1910c820a6161cc8a4dbcbc7e66fd4c981f18301a2e9b0338b64e5c8c21761225152bd0a3eb12f99302d141b0fa6001d4aeb74e6c62b8a5b9adcbf9ac05de5e91a13c91d6fe03970abea7c8879bbd18b7781f088ad5e42f301395854c81cae3eaae546561120907b865262bb50e883fde308027582a6cccefc09e56a87b3918cd209e6dc4678f059cb7f5baba6cef60d65f2609e534893b9ebacc4cca2597971cf2e21b2eb620472af12933cd16d659c91ed3435b6137f99fa03052ba8fc302a187ceb2fe3e884d8ea6139a9e233ec273a2b08857eacb23e7f594ed0e84fda80d41bb4042a8627b71bbfb9b2b318b10f7d1d0"+ "'", var16.equals("a4adfd9afa30a15ef58de907f99dd51d0eb4b7ada5aa03b7fabf0891d9d6f9bb3d46c339ebf79dbb8dcce2cea94ec0b76f9c668f36274f179cdedf57fc0a3394e553865b230a5e639b7ce3db64603aa3ba936d7974a58a6dafe68fabd23789b580f6eb07fce8aae8d50f5a37e35a533e30e90fdf061bd840e41ce6645e03ee29d3667bbf7c5d53c589fe620b07ceccbe06cdfa4119cb041ffc2c4b3740de450e2c460e27ae756c2916fd646f34c6225df46db72aec8265978e849cbca49c5ebea161f8908345f6d76b94631a9b13449664acb26d513a006b97d892df96dd17036ce0170f7ccc2fded81bad434399e715fa4c98587fa7d33cf32fe26fd5c7d282871f3c305967c9c110eeec85d7fab0928abbee2f05df1e04e73f12a44967104d75dcf400c3aa619b5ce055df119f0d31bb9c9b461f444ed7e7d9558435c44df57b6435869df218043655a4b294fa115a3baa167213689d92b763e79709d543fc35e4fe275e70aba6bd53fd32baa3f8e0e494aa60a2c9a03aedc920cfab7d718ef10ab2c8375290af89011c969d2b50e930e9fe2a48ce9a020575ea6104e8e91de93f56a505745e8c5fed5491736baabf4785e0bd946baf05929757b780eab726bdbcb2046c26d3074dba097e39142f82c88a284e9ef016486e36e82ed14b19c601771c8209e062705375df4a7706091152be085a6c9f85d066f9a6232f2c625506025833475efb06e819e5911e6982758d1f423145cb5df7c420ec4c245b4ee078353ea003e3cd7f6f8e6859ced250745cfcaeca110f7d16debed6e4e39c78b87bd153c41a22450725d84683314c8363eda8265b94c1dc336282499f9095bd692d8fb9e10d11c2782e5d81deef17c8a097035912d2a9925ede9e73ab43ed18abb723197d2cb82f4765e1618c4809fa89a94924b8ec8f5a441e3a61cdfc4e976c63ea1b0eb976187833050ff4315ddc1910c820a6161cc8a4dbcbc7e66fd4c981f18301a2e9b0338b64e5c8c21761225152bd0a3eb12f99302d141b0fa6001d4aeb74e6c62b8a5b9adcbf9ac05de5e91a13c91d6fe03970abea7c8879bbd18b7781f088ad5e42f301395854c81cae3eaae546561120907b865262bb50e883fde308027582a6cccefc09e56a87b3918cd209e6dc4678f059cb7f5baba6cef60d65f2609e534893b9ebacc4cca2597971cf2e21b2eb620472af12933cd16d659c91ed3435b6137f99fa03052ba8fc302a187ceb2fe3e884d8ea6139a9e233ec273a2b08857eacb23e7f594ed0e84fda80d41bb4042a8627b71bbfb9b2b318b10f7d1d0"));
// 
//   }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test195"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var13 = var0.nextExponential(20441.91590500824d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.0416607094660355d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "207f293d5f34e49fe62dc362d4c324a61ad9fed85404d008c9b1ce2eb91dd401d4e007e00cd601658be3c4b335ce47935ee6"+ "'", var8.equals("207f293d5f34e49fe62dc362d4c324a61ad9fed85404d008c9b1ce2eb91dd401d4e007e00cd601658be3c4b335ce47935ee6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 8273.79125264682d);
// 
//   }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test196"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var3);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var3);
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var9 = var6.nextSecureLong((-1L), 1L);
//     double var12 = var6.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var15 = var6.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var17 = var16.getStandardDeviation();
//     double[] var19 = var16.sample(1);
//     double var21 = var16.cumulativeProbability(0.0d);
//     double var22 = var16.getSupportUpperBound();
//     double var23 = var6.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var16);
//     var6.reSeed();
//     boolean var25 = var3.equals((java.lang.Object)var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var28 = var6.nextSecureLong(70L, 11L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 6.560364206945147d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.1728096971512982d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test197"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double[] var3 = var0.sample(10);
    double var4 = var0.getStandardDeviation();
    double var5 = var0.getStandardDeviation();
    double var6 = var0.getNumericalVariance();
    double var8 = var0.cumulativeProbability(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.5d);

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test198"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var13 = var0.nextF(0.6351254179184792d, 1.0919228035719635d);
//     var0.reSeedSecure();
//     double var17 = var0.nextWeibull(21.0d, 0.9999999999999996d);
//     java.lang.String var19 = var0.nextHexString(1906);
//     int var22 = var0.nextInt(11007, 11474);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("4155f1530d2d56446070f092ae3c6e116da4a55235449d84c5c13d6c0e1155f2c0e17cdf40a57220608996b3389d6bab455c10d790367c8564a8d3ce1286b631631eb8562525cd76b75f7f65f97100d1f19e17f10b77bd15cde459bcbf438002f702646c0893a97a61bbdc0f73799d22237bbbb199167afe09da428a9b24825e8646246e9374f55bc742c5a21aac95351b00e22306d8e489bfb5ce7b4db4fb149e054f078d784ee148ade5e4bfceecb735145899d27e81f388b56dac61251f7ca7c8d4967580d2a8f324651efe0a7c270e8fd593c03a70622496de7bb03c8f1ca9a44ecbb2ffc306c7f126dcb192fa2df0d30a6d3eb1010183f4542a5a92074a80b251fa9d6a803ed73f55d3184ce8f96f1d89e4373e3ed1ff4d02e2e0c08f16c84c12255d53a764e733c5097b6103d6c38ba060b5a86f1901b4678e4969d0149f13f4073ba3441d52ff858a7d11ddeef59fc465bfae2fa360510b7c7f0eb34dde558c73d157d469819575a5deaaf0b655d3f0e55fa75e67df79e1e6f2114c9891946de99493d57178ed2a6c14d85bba7a2bcc2e0ae38dd23bb29c67549822ea31937396eb0a9803d555d8aff6ea7ca9398fcc5a42299e9cb80b5335af01d404247e3047c8d93922eb910c1d91b856d6795453cbc5c7b7329a3ce68f45ffc139fe73582102acd7acb1d15236b9ecf92f26270a7bcbbd3afdcc39649aef062846d239ea26efe8c2defffa7e872a1afe620b600e8b92d23eace09de632e9ec2854580624d02f2497cb386d38378f29db595f28a160751ec4d69d97ec1a7526c769edad35512d774100881386f2fcb9296715f9bcf6646b81c8048ace654739c7225ae3fc2020ae100c09b511de45b9d13b7fbb5de0d0028e9c81072684e656f4c4ee3373ba408e761caa634145b8aa56d4a95c12c187e957ae813c3401026e275cae4e2e03bc0da451bde7be4e3279b3ca08f7e3732c65011940e895f92c15fcc4a3fe34bbc029f370e29564ca0c9e750ba134a87b5dd748a25b8448e6587984bdf3d939e709016f8772787d4e9a1d2acb6715d87fe047e74dd3c18e19237109b1baec7aade02bdff857e1765bf6d398b82d900d73acd2191fb13c5f55eec1104c7c5c47e64610a4fae8488c7428c301fa716715cedc4438574aa183c1a11ab7dc9b9e1a42fa2e1ed8bdff117e3d442d4bfa80a5716a61e26f04e26a2864d64c6a737040de4bc6a45f92348f45bdc89e1067ab041c9c5731f4d8b55594f39996aa716ed835b417b1838d69f50e46ac6ff242dc4c33433b90a0b9869f32dd2246b9247581e31b718cf12611597fb7964e04cbe07fefdff4620a277fc6e17cd7", "41e722f8a1");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9.715235254937248d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "e56dc64a48"+ "'", var8.equals("e56dc64a48"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.708379770216666d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.06443542994409986d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0261361750514706d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "00d8173df384aa03b2b4a3892c77f3d5133a7704b684fad34a098507236211b00b5d2bc1fab1c3dacf2838384dbec720c62e697ce0a8f3d76eea64d9866ecec0d932083ea6d074885d85eec8a0b7096b88db0a770a050fab01c56e7474a8d8bc90985b2bd3ba30e48a9a69ba78410629daf5143c11f83d209ffc2b6eeb050f2ccfd271a164fa103bcb8c546f659784d446c6950e4187338523c4b8fc6ac1a21babe2ab1d158af01ff5aa8dc2a0cf79e3760b62e24428069c17b35344b62d6b0d8bee13eeabcfa740db5b8cdcbb69ec588f0811c2f6b63892a7a5a50f4038712d34db5ece130810a7d655e69844cb55a5aa1b24c5fc4a88ab60ad1408023169f9a8b80e59ebf516a30096fd04e007fbbf23cd7acf3b7c3605cd6e70c49ebd3f1fe2eed18db9c6d3eeaa34d3afa81517bdae9d4520e481d63b3b206768427d6459d470444da45f4799af1c48831efcb8f362930a3796e276af141c595b04e2b08fb290c1633dc2f397664799095e2e58b85f69eb1d50b3ebe119666b5c1c775e73fba7be592fe327dd2a6de0d24db8c64b82dd3eb553b1a38fe8ee504b4dc6441a5043e3c736541c6b4709225b0d85de69dde9c046cd453280f7a0cadb83d9c173d36f530880f103e4a2763797cb120b21f09d79beddbece9c57aeb247fac634fb44218e8be77eb01a778b72b400e16e31e8a8ae66f9162dec3ebc8c9a9113fc353133487a4ad091a6d4e2b8ae3553d3b97e23f8ce0f603eae2d6a8bf578513d7de8b1754a103b1fc49d13933834a9c0da278a9399fc0b267211f4b990a82bb952775128c035e98aa22cf6689dd3d971bbd1a8081054aefc861258bc2bcd687404394f125e5fa770202709bce224970890c12347d7a21c561b56fb70d1d5110c0b7d6b5bae9252372914e0be8a6e365bb842e969fe67be5630d5620de533c9c87028375a975b170dce3d2eadd77d7f853c6c01fef9548d8367f17d9d2dc576b807728e1696dae88c940b2b73d424601a85a52a38b7c973683c05448f017e93d588e4e186391d2fed7b1bcc02421b24e1e5bb07bf9046f3e3f8d0931b94880b997da2e1f39847059112c7a1fb292d59c2874d4009adf10c5d1599ffbc71c0003388a382a5341f58cc22b28bebd457be2a20a688dcef50a4517ce27465f007d8fc393bc815e8b6ac12ae94799dc00dc8344d08ed38317d170597d23024b9531fe11c06afcd23c62cc010f705ee530dcfec6230c4d760325429510391da6d2a48cae9d997f4f3082a667dd22cd3df0abdb5c4cdc381cac61b907265d82681a844c48703753b874761f12e027259b096231025b405d7da531dd97094"+ "'", var19.equals("00d8173df384aa03b2b4a3892c77f3d5133a7704b684fad34a098507236211b00b5d2bc1fab1c3dacf2838384dbec720c62e697ce0a8f3d76eea64d9866ecec0d932083ea6d074885d85eec8a0b7096b88db0a770a050fab01c56e7474a8d8bc90985b2bd3ba30e48a9a69ba78410629daf5143c11f83d209ffc2b6eeb050f2ccfd271a164fa103bcb8c546f659784d446c6950e4187338523c4b8fc6ac1a21babe2ab1d158af01ff5aa8dc2a0cf79e3760b62e24428069c17b35344b62d6b0d8bee13eeabcfa740db5b8cdcbb69ec588f0811c2f6b63892a7a5a50f4038712d34db5ece130810a7d655e69844cb55a5aa1b24c5fc4a88ab60ad1408023169f9a8b80e59ebf516a30096fd04e007fbbf23cd7acf3b7c3605cd6e70c49ebd3f1fe2eed18db9c6d3eeaa34d3afa81517bdae9d4520e481d63b3b206768427d6459d470444da45f4799af1c48831efcb8f362930a3796e276af141c595b04e2b08fb290c1633dc2f397664799095e2e58b85f69eb1d50b3ebe119666b5c1c775e73fba7be592fe327dd2a6de0d24db8c64b82dd3eb553b1a38fe8ee504b4dc6441a5043e3c736541c6b4709225b0d85de69dde9c046cd453280f7a0cadb83d9c173d36f530880f103e4a2763797cb120b21f09d79beddbece9c57aeb247fac634fb44218e8be77eb01a778b72b400e16e31e8a8ae66f9162dec3ebc8c9a9113fc353133487a4ad091a6d4e2b8ae3553d3b97e23f8ce0f603eae2d6a8bf578513d7de8b1754a103b1fc49d13933834a9c0da278a9399fc0b267211f4b990a82bb952775128c035e98aa22cf6689dd3d971bbd1a8081054aefc861258bc2bcd687404394f125e5fa770202709bce224970890c12347d7a21c561b56fb70d1d5110c0b7d6b5bae9252372914e0be8a6e365bb842e969fe67be5630d5620de533c9c87028375a975b170dce3d2eadd77d7f853c6c01fef9548d8367f17d9d2dc576b807728e1696dae88c940b2b73d424601a85a52a38b7c973683c05448f017e93d588e4e186391d2fed7b1bcc02421b24e1e5bb07bf9046f3e3f8d0931b94880b997da2e1f39847059112c7a1fb292d59c2874d4009adf10c5d1599ffbc71c0003388a382a5341f58cc22b28bebd457be2a20a688dcef50a4517ce27465f007d8fc393bc815e8b6ac12ae94799dc00dc8344d08ed38317d170597d23024b9531fe11c06afcd23c62cc010f705ee530dcfec6230c4d760325429510391da6d2a48cae9d997f4f3082a667dd22cd3df0abdb5c4cdc381cac61b907265d82681a844c48703753b874761f12e027259b096231025b405d7da531dd97094"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 11292);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test199"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(16.475510988377376d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.552713678800501E-15d);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test200"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.setContractionCriteria(2.5f);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    var15.setExpansionMode(0);
    var15.setNumElements(0);
    org.apache.commons.math3.distribution.NormalDistribution var20 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var21 = var20.getStandardDeviation();
    double[] var23 = var20.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(var23);
    var24.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var26 = var24.copy();
    double[] var27 = var24.getInternalValues();
    var24.addElement(0.7615941559557649d);
    double var31 = var24.substituteMostRecentElement(0.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var32 = var24.copy();
    var24.clear();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var15, var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.7615941559557649d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test201"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.204409469363068d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test202"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-0.10527202142049069d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test203"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double[] var3 = var0.sample(10);
    double var4 = var0.getStandardDeviation();
    double var5 = var0.getStandardDeviation();
    double var6 = var0.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test204"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(67L, 20L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6572994968014929263L));

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test205"); }


    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)2.3017773245509012d, (java.lang.Number)2006, var2);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test206"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(21L, 2985984L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 21L);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test207"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)2.3841864E-7f, (java.lang.Number)(-0.6592951788605901d), true);

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test208"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double[] var6 = var0.sample(100);
//     double var7 = var0.sample();
//     double var8 = var0.sample();
//     double var9 = var0.getStandardDeviation();
//     double[] var11 = var0.sample(1868);
//     boolean var12 = var0.isSupportUpperBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9208850028863278d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1.1622671888760423d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
// 
//   }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test209"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var14 = var0.nextGamma(0.15861286098539223d, 23.79178096943456d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextBinomial(11166, 6.648133937682834d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.356200227173252d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "2f2d4b8442"+ "'", var8.equals("2f2d4b8442"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.021123037357496967d);
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test210"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-1.1285242986562543d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9037815823889354d));

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test211"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    var4.setElement(1931, 0.2577047455984825d);
    int var11 = var4.getNumElements();
    double var13 = var4.substituteMostRecentElement(0.004492688352124083d);
    var4.addElement((-1.2596788451662277d));
    int var16 = var4.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1932);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2577047455984825d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1933);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test212"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.9371612764804269d, 0.4900942214881733d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9371612764804269d);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test213"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("org.apache.commons.math3.exception.NumberIsTooSmallException: 0.5 is smaller than, or equal to, the minimum (0.595)");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test214"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(236.64698555037546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6559871879571482d);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test215"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.287175276564211d, (-0.7096217858495665d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.2871752765642106d);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test216"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.20584945432845803d, 0.04378400432753371d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.013070567309210523d));

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test217"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextUniform(0.2577047455984825d, 13.770182159584014d);
//     var1.reSeed(6L);
//     double var9 = var1.nextGamma(0.2160727732320313d, 0.006982349495073288d);
//     double var12 = var1.nextBeta(0.2649292032971031d, 13.770182159584014d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4.2866424204650935d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.003786692986421205d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.06955174362771119d);
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test218"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    java.lang.String var6 = var4.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = var7.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var7.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    java.lang.Class var12 = var11.getDeclaringClass();
    int var13 = var11.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var11);
    org.apache.commons.math3.random.RandomGenerator var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var15);
    org.apache.commons.math3.random.RandomGenerator var17 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var20, var22);
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19, var22);
    java.lang.String var25 = var22.name();
    java.lang.Class var26 = var22.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var22);
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "MAXIMAL"+ "'", var6.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "AVERAGE"+ "'", var25.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test219"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-0.33143925087381365d));

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test220"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextUniform(0.2577047455984825d, 13.770182159584014d);
//     long var6 = var1.nextPoisson(23.012289905639566d);
//     java.lang.String var8 = var1.nextHexString(2041);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10.825664296799586d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 25L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "8ceb73b6cedac7a019098a3674f76b6b5736110ca9fc4097b2ff9a6750c011e8f5332c250c009f863905f37cd484e03b2dc68ba992769a4a336865fdccba2591512d47630bea522d69eae838811f0c89602b63188df47153dcf59423bf4ac9353b4339eae0da4bf042f3eadabf4b9424f6398438247453a54071cdc4b353b37792969ea7949282dfbf13404f6d09ec6ea07a442b3ec4de17e22922a381ee7fd52478dca2cf499ee7eef493f1a6e470ff18eef23a05fdc8bc7205a2e77a306bd1e7ea1e2901b88315bce333ecb25a8632e87652b0907270e2665bdc83332669b0486fa7e6d53e576084b54c0c5dd0354f7f4c70b638a22b79851be097937673b1bf15992dff0af298d689524a9fd25691a3996dd919cbd72a2e7bf1dfea541f3e32a5354037b565336dd003ce73987ea95a15e9d4ffb649e04a178d3cb4c50467f697af169f47ba0611fed8aa0f430a476e5c669c7b3e7db4210ce32dbd6bf3555cf95e94ac8ab7aadb83bad2664de4bda2b664c2d164818063525c3ec2d748f61a672292951efd87f5f453217276c18a26d2e07d87df7b40a8564f1052e94ef8bed253f2695602ebcf6bc2c0d62239caf6eb40c7a6dea9b621469c5527805a7f962a297cc71d23fce37c5e74bd633f2f10333032d6f4759ff7ff9857f20791e26a6273f8f3ad027de6be676abd42db3af6dc2909febb23dee05568a8bd7f0424e59c1f7f1da9c38b5eb56029398379c5570e2b0a748203ad22567d6c820fc6edff5aacd35d484146d6ec37489856480b2155e2c05cecd4ea695979eb9106ca9ac3f200fe77500ad8e51a5ad00a3abf223cd7ee2fa9731e7210506a435ed9dd3071b7ab0d7f12a99ed8fb50f60c7f7394e898c5e94bfa26a50cdfd2a06ddd3703429216dd1507dad849271831723fb9eb1a7eb15fdd114ace0b1f562898d4648d737564d57ee905e4946867325e29d52ca2ec559a706be47691d70712d8ebf89f68a8984c22399168deade0c5eb4bcffd71b135f1675fa983704be018f740cdc98bca5d99706144ed1e8ad97b1e3306be698d5eacb882be891b718f7db5f0db0cb5d11cfa01063da3117301fbf90582e4cb22b488dfb04555b30188041e92e0777a283fdf46c7ba311f4e3a15572112fa90532cd6673bf257ced146c98ad91ca670745555285cb205ae6e908bda38aaf68cc0c901044db106f3a427fb42a725f76f73f09af1056b9fde86fb353e3b94fb602b0fe43f353426e56fdc8032a6a650ce2fc0cabeb16dc8eba3cb50a9d99af264dbad5aeabda5a351f35ab6eff107b77a62c4f0339c1bd6a567e757f38392ba18308a0a128df12cf7d03aaaac1044a1d261f41d4e54c7f864048338deb566208ca7eaec91de5820138dc78ec4deeaff24badd08e71190bfad78d6034b4a064f3c459cdec59cd348809e51ebc"+ "'", var8.equals("8ceb73b6cedac7a019098a3674f76b6b5736110ca9fc4097b2ff9a6750c011e8f5332c250c009f863905f37cd484e03b2dc68ba992769a4a336865fdccba2591512d47630bea522d69eae838811f0c89602b63188df47153dcf59423bf4ac9353b4339eae0da4bf042f3eadabf4b9424f6398438247453a54071cdc4b353b37792969ea7949282dfbf13404f6d09ec6ea07a442b3ec4de17e22922a381ee7fd52478dca2cf499ee7eef493f1a6e470ff18eef23a05fdc8bc7205a2e77a306bd1e7ea1e2901b88315bce333ecb25a8632e87652b0907270e2665bdc83332669b0486fa7e6d53e576084b54c0c5dd0354f7f4c70b638a22b79851be097937673b1bf15992dff0af298d689524a9fd25691a3996dd919cbd72a2e7bf1dfea541f3e32a5354037b565336dd003ce73987ea95a15e9d4ffb649e04a178d3cb4c50467f697af169f47ba0611fed8aa0f430a476e5c669c7b3e7db4210ce32dbd6bf3555cf95e94ac8ab7aadb83bad2664de4bda2b664c2d164818063525c3ec2d748f61a672292951efd87f5f453217276c18a26d2e07d87df7b40a8564f1052e94ef8bed253f2695602ebcf6bc2c0d62239caf6eb40c7a6dea9b621469c5527805a7f962a297cc71d23fce37c5e74bd633f2f10333032d6f4759ff7ff9857f20791e26a6273f8f3ad027de6be676abd42db3af6dc2909febb23dee05568a8bd7f0424e59c1f7f1da9c38b5eb56029398379c5570e2b0a748203ad22567d6c820fc6edff5aacd35d484146d6ec37489856480b2155e2c05cecd4ea695979eb9106ca9ac3f200fe77500ad8e51a5ad00a3abf223cd7ee2fa9731e7210506a435ed9dd3071b7ab0d7f12a99ed8fb50f60c7f7394e898c5e94bfa26a50cdfd2a06ddd3703429216dd1507dad849271831723fb9eb1a7eb15fdd114ace0b1f562898d4648d737564d57ee905e4946867325e29d52ca2ec559a706be47691d70712d8ebf89f68a8984c22399168deade0c5eb4bcffd71b135f1675fa983704be018f740cdc98bca5d99706144ed1e8ad97b1e3306be698d5eacb882be891b718f7db5f0db0cb5d11cfa01063da3117301fbf90582e4cb22b488dfb04555b30188041e92e0777a283fdf46c7ba311f4e3a15572112fa90532cd6673bf257ced146c98ad91ca670745555285cb205ae6e908bda38aaf68cc0c901044db106f3a427fb42a725f76f73f09af1056b9fde86fb353e3b94fb602b0fe43f353426e56fdc8032a6a650ce2fc0cabeb16dc8eba3cb50a9d99af264dbad5aeabda5a351f35ab6eff107b77a62c4f0339c1bd6a567e757f38392ba18308a0a128df12cf7d03aaaac1044a1d261f41d4e54c7f864048338deb566208ca7eaec91de5820138dc78ec4deeaff24badd08e71190bfad78d6034b4a064f3c459cdec59cd348809e51ebc"));
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test221"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(35.39286706296104d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2027.861907575249d);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test222"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.815297812486526d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9029384322790375d);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test223"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.7346960922432918d, (java.lang.Number)0.4796135563539121d, (java.lang.Number)1.0110169304177432d);

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test224"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var4 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)(-1), (java.lang.Object[])var4);
//     org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var4);
//     org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var4);
//     java.lang.String var8 = var7.toString();
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test225"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(2006, 1348L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test226"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)9.453724938289845d, (java.lang.Number)(-6.887851652052518d), (java.lang.Number)0.06257000654723877d);
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-6.887851652052518d)+ "'", var5.equals((-6.887851652052518d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-6.887851652052518d)+ "'", var6.equals((-6.887851652052518d)));

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test227"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.clear();
    float var8 = var6.getExpansionFactor();
    var6.setContractionCriteria(2.0f);
    float var11 = var6.getContractionCriteria();
    org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var13 = var12.getStandardDeviation();
    double[] var15 = var12.sample(1);
    double var16 = var12.getMean();
    double[] var18 = var12.sample(100);
    boolean var19 = var12.isSupportLowerBoundInclusive();
    boolean var20 = var12.isSupportUpperBoundInclusive();
    double[] var22 = var12.sample(8899);
    var6.addElements(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test228"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(9.453724938289845d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.0d);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test229"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var4 = var0.getMean();
    double[] var6 = var0.sample(100);
    boolean var7 = var0.isSupportLowerBoundInclusive();
    double var8 = var0.getSupportLowerBound();
    boolean var9 = var0.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test230"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var7 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var3, (java.lang.Number)10.0f, (java.lang.Number)(-1.0f), false);
    java.lang.Throwable[] var8 = var7.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var11.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test231"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(3.02837877258525d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.356049443092553d);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test232"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(1946, 1.0f, 2.3841864E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test233"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(23.487367389676788d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.1350236438052557d);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test234"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.5d, (java.lang.Number)0.5950413774252329d, false);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test235"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(2.0743630386030425d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 118.85224728988739d);

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test236"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     var0.reSeedSecure();
//     int var10 = var0.nextBinomial(243, 0.745691842295965d);
//     long var12 = var0.nextPoisson(31.862892444737472d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextSecureInt(1818, 11);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12.419937147036533d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 181);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 38L);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test237"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)21L, (java.lang.Number)5.641560223443412d, true);
    java.lang.Number var5 = var4.getArgument();
    java.lang.Number var6 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 21L+ "'", var5.equals(21L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 5.641560223443412d+ "'", var6.equals(5.641560223443412d));

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test238"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var5 = var0.cumulativeProbability(0.0d);
    double var6 = var0.getSupportUpperBound();
    boolean var7 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator((-16L));
    var0.reseedRandomGenerator((-1L));
    double var13 = var0.probability((-0.2400817780639568d));
    double var15 = var0.density(1.1752011936438014d);
    double var16 = var0.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.19999009153715622d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test239"); }


    long var1 = org.apache.commons.math3.util.FastMath.round((-1.3710470839224471d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1L));

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test240"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.addElement(20.696514663540924d);
    double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
    java.lang.Object var17 = null;
    boolean var18 = var4.equals(var17);
    int var19 = var4.start();
    var4.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 20.696514663540924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test241"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(13.648353183307265d, 0.815297812486526d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 13.672682806945344d);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test242"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.03448327091128028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.367280973669702d));

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test243"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.4E-45f, (-0.4337902394648092d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test244"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextWeibull(7.769493748166378d, 1.2185657441986304d);
//     var0.reSeed(201600L);
//     double var11 = var0.nextGaussian(0.004492673238610562d, 2.5078368197853713d);
//     var0.reSeedSecure();
//     org.apache.commons.math3.distribution.NormalDistribution var15 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 53.69538586542132d);
//     double var16 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0485369688897814d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.2366575586410038d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-9.097928974726221d));
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test245"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1818, 10775);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test246"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     java.lang.String var13 = var0.nextHexString(10);
//     var0.reSeedSecure();
//     double var17 = var0.nextGaussian(7.042014262199385d, 1.179103839756096d);
//     long var19 = var0.nextPoisson(0.9999679765543574d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var22 = var0.nextWeibull(1.7058143237097114d, (-0.4607121656995548d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12.172611888205463d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "12cffbb000"+ "'", var8.equals("12cffbb000"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "00cb74f4bb"+ "'", var13.equals("00cb74f4bb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 6.509172538283607d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 2L);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test247"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(201L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test248"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 601302.1420828041d);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test249"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var1, var2, (java.lang.Number)0.17994611088998624d, true);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test250"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.MathIllegalStateException var2 = new org.apache.commons.math3.exception.MathIllegalStateException();
//     org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
//     java.lang.Throwable[] var4 = var3.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var4);
//     org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var4);
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var7, (java.lang.Object[])var8);
// 
//   }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test251"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     int var20 = var0.nextBinomial(0, 0.7615941559557649d);
//     double var23 = var0.nextWeibull(1.2075656224493654d, 2.265662238504449d);
//     var0.reSeedSecure(40318L);
//     org.apache.commons.math3.distribution.NormalDistribution var26 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var27 = var26.getSupportUpperBound();
//     double var29 = var26.inverseCumulativeProbability(0.9999999999928669d);
//     double var31 = var26.density(25.472636453138065d);
//     double var32 = var26.getMean();
//     double var33 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var26);
//     var0.reSeedSecure(704L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0403360105039516d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "3e4d73047825023eda6ac72bf50ab7b04ead8f6e2bea74472b8b925996412c5d4b5af73c3aaa98d46e8c2e181c2d6a28b415"+ "'", var8.equals("3e4d73047825023eda6ac72bf50ab7b04ead8f6e2bea74472b8b925996412c5d4b5af73c3aaa98d46e8c2e181c2d6a28b415"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.04198480291856155d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.4247945415064162d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 6.755176609774487d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 5.055823438644928E-142d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.02257534021621351d);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test252"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(2.768156154292684E-4d, 0.055313172706954926d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.3533554734503997d);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test253"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test254"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(9099, 1499);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4066.8844691618797d);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test255"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(231.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 15.198684153570664d);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test256"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
//     java.lang.Class var6 = var5.getDeclaringClass();
//     int var7 = var5.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var5);
//     org.apache.commons.math3.random.RandomGenerator var9 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var9);
//     org.apache.commons.math3.random.RandomGenerator var11 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var11);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var14.getTiesStrategy();
//     java.lang.Class var16 = var15.getDeclaringClass();
//     java.lang.Class var17 = var15.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var15);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var15);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var22 = var20.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var24 = var23.getTiesStrategy();
//     java.lang.Class var25 = var24.getDeclaringClass();
//     java.lang.Class var26 = var24.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24);
//     java.lang.String var28 = var24.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var22, var24);
//     org.apache.commons.math3.distribution.NormalDistribution var30 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var31 = var30.getStandardDeviation();
//     double[] var33 = var30.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var34 = new org.apache.commons.math3.util.ResizableDoubleArray(var33);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var35 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var39 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var40 = new org.apache.commons.math3.util.ResizableDoubleArray(var39);
//     double[] var44 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var45 = new org.apache.commons.math3.util.ResizableDoubleArray(var44);
//     double var46 = var35.mannWhitneyU(var39, var44);
//     double var47 = var29.mannWhitneyUTest(var33, var39);
//     org.apache.commons.math3.distribution.NormalDistribution var48 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var49 = var48.getStandardDeviation();
//     double[] var51 = var48.sample(1);
//     double var52 = var48.getMean();
//     double[] var54 = var48.sample(100);
//     boolean var55 = var48.isSupportLowerBoundInclusive();
//     boolean var56 = var48.isSupportUpperBoundInclusive();
//     double var59 = var48.cumulativeProbability(0.0d, 0.25587682077976953d);
//     double var60 = var48.getSupportUpperBound();
//     double[] var62 = var48.sample(11274);
//     org.apache.commons.math3.distribution.NormalDistribution var66 = new org.apache.commons.math3.distribution.NormalDistribution((-4.440892098500626E-16d), 1.1102230246251565E-16d, 0.9999494957997512d);
//     double[] var68 = var66.sample(1972);
//     double var69 = var29.mannWhitneyUTest(var62, var68);
//     double[] var73 = new double[] { 0.0d, (-1.0d), 0.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var74 = new org.apache.commons.math3.util.ResizableDoubleArray(var73);
//     int var75 = var74.getNumElements();
//     float var76 = var74.getExpansionFactor();
//     double[] var77 = var74.getElements();
//     double var78 = var19.mannWhitneyUTest(var68, var77);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test257"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(10.356049443092553d, (-0.492316678415841d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.492316678415841d));

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test258"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.11823011577408327d), (java.lang.Number)0.46500210138368253d, (java.lang.Number)0.7615941559557649d);

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test259"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     double var9 = var0.nextF(2.281783181607902d, 0.8427007929497151d);
//     double var12 = var0.nextGaussian(1.5498468927479463d, 1865.0d);
//     double var14 = var0.nextExponential(1.2042143530169682d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var16 = var0.nextHexString((-79579695));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.1783754547601486d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0201428408659925d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-431.91086559151586d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0795067213450604d);
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test260"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.7187353997098677d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test261"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(2187);
    int var2 = var1.getExpansionMode();
    double var4 = var1.addElementRolling(0.5805536752331785d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardFrontElements(10178);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test262"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(2.899984157889152d, 13.359855606410402d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.369076254094909E-4d);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test263"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Number var4 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var6 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var2, (java.lang.Number)0.777695809106093d, var4, true);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test264"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-0.639704667682103d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2116845217220868d);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test265"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 10.0f);
    var2.addElement(0.15729920705028488d);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var2.equals((java.lang.Object)var8);
    var2.setNumElements(271);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test266"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(2.4817022260739696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6941444108432415d);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test267"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.2185657441986304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test268"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(9973);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test269"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    boolean var7 = var5.equals((java.lang.Object)"cbbaf7b34a");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test270"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(363.7393755555636d, 0.059233998853640384d);
    double var3 = var2.getNumericalMean();
    double var4 = var2.getSupportUpperBound();
    double var5 = var2.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 363.7393755555636d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 363.7393755555636d);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test271"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1866, 42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 13062);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test272"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.5000005f, 0.038065078180269586d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5000002f);

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test273"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextWeibull(7.769493748166378d, 1.2185657441986304d);
//     int var9 = var0.nextPascal(1980, 0.0d);
//     int var12 = var0.nextPascal(9066, 0.06995726965750072d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.82518486364349d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 120412);
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test274"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 11L);
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, var14);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 1949);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, var17);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 11L);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 1L);
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, 2426);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test275"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(1.0258239749326856d, (-2.493230627956686d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test276"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     double var31 = var0.nextUniform((-0.03560534527178083d), 12185.029950707305d);
//     java.util.Collection var32 = null;
//     java.lang.Object[] var34 = var0.nextSample(var32, (-623678255));
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test277"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    var4.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var4.copy();
    int var10 = var4.getNumElements();
    float var11 = var4.getExpansionFactor();
    double var13 = var4.addElementRolling(20.692321524420652d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test278"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var12 = var0.nextChiSquare(6.755176609774487d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.4149821314117634d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "6904421d7e"+ "'", var8.equals("6904421d7e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.9881507028096029d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 11.523026715461885d);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test279"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(0, (-80136));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test280"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-0.6592173641653114d), (java.lang.Number)(-8904), (java.lang.Number)(byte)0);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test281"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 1.1920929E-7f, 7.6293945E-6f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test282"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.9409370488285718d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3719317734535352d);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test283"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(1260, (-388134638));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test284"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var5 = new org.apache.commons.math3.exception.OutOfRangeException(var2, (java.lang.Number)2.3841858E-7f, (java.lang.Number)(byte)0);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test285"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     var0.reSeed();
//     double var15 = var0.nextChiSquare(7.617953921806563d);
//     double var17 = var0.nextExponential(1.5574077246549007d);
//     org.apache.commons.math3.distribution.NormalDistribution var21 = new org.apache.commons.math3.distribution.NormalDistribution(0.8259324122591327d, 0.2782029380240531d, 0.0d);
//     double var22 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var21);
//     double var24 = var0.nextT(0.2160727732320313d);
//     double var27 = var0.nextGamma(18.827809487697202d, 15.2715815643462d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var30 = var0.nextF((-1.0328453233143338d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 14.329878134377958d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "e1680472aa"+ "'", var8.equals("e1680472aa"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 3.8430037401954635d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.828554740163403d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.6256906000487639d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-1.410014954319951d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 286.23252025701987d);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test286"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(14.79346884439439d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1329510.8676026d);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test287"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var13 = var0.nextT(5.867156662812015d);
//     double var15 = var0.nextExponential(11.771947930619202d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.727639162426612d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "0cb924d6e1"+ "'", var8.equals("0cb924d6e1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.3314398804171876d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2.5203484270700858d);
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test288"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.4128411121633297d, (java.lang.Number)0.0f, (java.lang.Number)3.2359311173302077d);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getLo();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var3.getContext();
    java.lang.String var7 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.0f+ "'", var4.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.0f+ "'", var5.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: 1.413 out of [0, 3.236] range"+ "'", var7.equals("org.apache.commons.math3.exception.OutOfRangeException: 1.413 out of [0, 3.236] range"));

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test289"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.023705285005337525d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0002809834262205d);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test290"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(25.505964044321736d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.491575874083324E-285d);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test291"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    boolean var8 = var6.equals((java.lang.Object)Double.POSITIVE_INFINITY);
    boolean var10 = var6.equals((java.lang.Object)(-0.4255538433808183d));
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    java.lang.String var13 = var4.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "MAXIMAL"+ "'", var13.equals("MAXIMAL"));

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test292"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(2.566440443196982d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test293"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1859);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1859);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test294"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test295"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(3.1039797472520814d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9992927180287752d));

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test296"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(2187);
    int var2 = var1.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var1.copy();
    var3.setElement(9864, 0.012505120463464766d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test297"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    boolean var2 = var0.isSupportUpperBoundInclusive();
    double var3 = var0.getSupportUpperBound();
    double var5 = var0.cumulativeProbability(0.3898083608815867d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.6516608696011157d);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test298"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-8889), 1955);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 17377995);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test299"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    java.lang.Class var2 = var1.getDeclaringClass();
    java.lang.Class var3 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var4.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test300"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(25.482227276241392d, 9.132880185817315d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 25.482227276241392d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test301"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.036678667992187754d, 7.996399943030428d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9586311075229001d);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test302"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.2483013337850595d, 11474);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test303"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(0L);
//     int var18 = var0.nextBinomial(0, 0.33421337133949025d);
//     double var21 = var0.nextGamma(0.8847656390164815d, 0.9935022674622966d);
//     int[] var24 = var0.nextPermutation(1822, 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.525428235622169d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f2ad8fec30"+ "'", var8.equals("f2ad8fec30"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.385744029842793d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 9813);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.4566755696269953d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test304"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(180, 1962);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 18);

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test305"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     double var13 = var0.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var14.getStandardDeviation();
//     double[] var17 = var14.sample(1);
//     double var18 = var14.getMean();
//     double[] var20 = var14.sample(100);
//     double var21 = var14.sample();
//     double var22 = var14.sample();
//     double var23 = var14.getStandardDeviation();
//     double var24 = var14.sample();
//     double var25 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var28 = var0.nextWeibull(0.010100839201864612d, 192.9088122275434d);
//     double var30 = var0.nextExponential(1.0471975511965979d);
//     double var32 = var0.nextChiSquare(0.8382617516745859d);
//     double var35 = var0.nextUniform(3.1040481002909335d, 5.521086707909222d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.4035165383564974d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "b9bb3b0155"+ "'", var8.equals("b9bb3b0155"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1856);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.017086838627983252d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.7203546103014487d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.3640058926625345d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.043602225172257d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-0.5455420957943401d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1.6343114194470413E12d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.8883118982304692d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.8725996883920981d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 3.114650847621867d);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test306"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(4.440892098500626E-16d, 14.964199219520955d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999999999994d);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test307"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.setContractionCriteria(2.5f);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    var15.setElement(0, 3.539472048166337d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test308"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     var0.reSeed();
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextChiSquare((-0.3897475523462606d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.3477319626956077d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "3767f5f2dfab93f68713762bb49fd169dcfe61cf1dca87ae346f2605e3a5aa01ba0dcf84a90bda662eaad9ddb0d61f47f0ff"+ "'", var8.equals("3767f5f2dfab93f68713762bb49fd169dcfe61cf1dca87ae346f2605e3a5aa01ba0dcf84a90bda662eaad9ddb0d61f47f0ff"));
// 
//   }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test309"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-2.0166116874290902d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1331057056071165d);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test310"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(35.18478424589681d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test311"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    var1.addElement(2.0216852347077916d);
    org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var5 = var4.getStandardDeviation();
    double[] var7 = var4.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var12 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var11, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var10, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var9, (java.lang.Object[])var12);
    boolean var16 = var8.equals((java.lang.Object)var9);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var8);
    int var18 = var1.start();
    org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var20 = var19.getStandardDeviation();
    double[] var22 = var19.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    org.apache.commons.math3.exception.util.Localizable var24 = null;
    org.apache.commons.math3.exception.util.Localizable var25 = null;
    org.apache.commons.math3.exception.util.Localizable var26 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var27 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var28 = new org.apache.commons.math3.exception.NullArgumentException(var26, (java.lang.Object[])var27);
    org.apache.commons.math3.exception.MathInternalError var29 = new org.apache.commons.math3.exception.MathInternalError(var25, (java.lang.Object[])var27);
    org.apache.commons.math3.exception.NullArgumentException var30 = new org.apache.commons.math3.exception.NullArgumentException(var24, (java.lang.Object[])var27);
    boolean var31 = var23.equals((java.lang.Object)var24);
    var23.setElement(8899, 2.3930658372149933d);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var23);
    org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var36);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var36.setExpansionMode(1960);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test312"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    int var7 = var6.getNumElements();
    var6.setNumElements(8899);
    int var10 = var6.start();
    int var11 = var6.getNumElements();
    int var12 = var6.getNumElements();
    float var13 = var6.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 8899);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 8899);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.0f);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test313"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.9998435319194582d, 116.37840993773725d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1573641682869249d);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test314"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     var0.reSeedSecure();
//     int var10 = var0.nextBinomial(243, 0.745691842295965d);
//     long var12 = var0.nextPoisson(31.862892444737472d);
//     java.lang.String var14 = var0.nextHexString(10240);
//     double var16 = var0.nextChiSquare(0.8837139528133744d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var0.nextUniform(1.3416108431637515d, 0.7618964568626004d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.491377154456156d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 192);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 36L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.002508014853187968d);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test315"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(100.00001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test316"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.8060646352700217d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6333241614301578d);

  }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test317"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getSupportUpperBound();
//     double[] var3 = var0.sample(10);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     double var6 = var4.addElementRolling(0.15264401491200186d);
//     float var7 = var4.getContractionCriteria();
//     float var8 = var4.getExpansionFactor();
//     var4.contract();
//     org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.6355964532366203d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.0f);
// 
//   }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test318"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.Class var8 = var7.getDeclaringClass();
    java.lang.Class var9 = var7.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var11);
    java.lang.String var13 = var11.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test319"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var5 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)(-1), (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)1.4128411121633297d, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test320"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.625430559956864d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test321"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeed(2L);
//     var0.reSeed();
//     double var15 = var0.nextChiSquare(7.617953921806563d);
//     double var17 = var0.nextExponential(1.5574077246549007d);
//     double var19 = var0.nextChiSquare(0.16043285994536435d);
//     int var22 = var0.nextZipf(1972, 0.8109766711360142d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("0fc7615ea4", "48f1999eb060a4a05ae91bb364ef9da90a29baa379a30565d9615b3102b74a61cfa7134fa507e9bc298916d2c183efae4d09");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.402480810756504d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "c6b02d0efe"+ "'", var8.equals("c6b02d0efe"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 15.775751295570654d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.3958715674188612d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.285994904093153d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 86);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test322"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(20L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 20L);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test323"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(5668, 11444);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16216148);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test324"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(12.725432724837008d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999999823046d);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test325"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.009999999583352414d, true);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    org.apache.commons.math3.exception.NumberIsTooLargeException var9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.037711424796358986d, (java.lang.Number)8.41437792932233d, true);
    var3.addSuppressed((java.lang.Throwable)var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test326"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var13 = var0.nextF(0.6351254179184792d, 1.0919228035719635d);
//     var0.reSeedSecure();
//     int var17 = var0.nextZipf(4311469, 14.0d);
//     java.lang.String var19 = var0.nextSecureHexString(186);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.888589973035708d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "88d6b0fdf0"+ "'", var8.equals("88d6b0fdf0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.4798424949499698d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.011012866100247d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "4e70dbbde94b2885708c978ab81ded6296d5f9474a0b3e58b38d7e8f862fc439f03daa46b7c40528ec269b42e39c1f4d2985490ab4b4272b5d60f07fce6d92aa145381b4f7bbd9676b169d439fbf0f7ec165b17cc102cb696d26782f6b"+ "'", var19.equals("4e70dbbde94b2885708c978ab81ded6296d5f9474a0b3e58b38d7e8f862fc439f03daa46b7c40528ec269b42e39c1f4d2985490ab4b4272b5d60f07fce6d92aa145381b4f7bbd9676b169d439fbf0f7ec165b17cc102cb696d26782f6b"));
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test327"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var4 = var0.getSupportLowerBound();
    boolean var5 = var0.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test328"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.9731418479247683d), (java.lang.Number)9.139551774061742d, false);
    java.lang.Number var5 = var4.getMax();
    boolean var6 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 9.139551774061742d+ "'", var5.equals(9.139551774061742d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test329"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.04237399784732393d);

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test330"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.6351254179184792d);
//     double var9 = var0.nextGamma(9.319248049587957d, (-0.4255538433808183d));
//     long var11 = var0.nextPoisson(0.9978516012375751d);
//     int var14 = var0.nextZipf(8941, 1.445343853698748d);
//     java.lang.String var16 = var0.nextHexString(3826);
//     double var19 = var0.nextGaussian(1.383036361567265d, 18.853048230723537d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var21 = var0.nextSecureHexString((-8834));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.092222954938013d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-4.761585272938674d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "3ff99fa3e4f00f592e46cefa0ce4645bf1d5d7e3ea9b8d486bf5044b4b3646696d38bbcbaa650003d4eef89c5d222bb226e7cf77e5bb743e945474217150fbf164a0a6efde96f38eef5ee28a22e9e0208df82c7d22b197b6dbc536eaa3b819dca1884ecb3ff3b56b92fd5a46248a297dc488b297bc0109d8a7e7185c5cbd8860486e8aa37a428eb71451893bfb2124f468f07c77f618107dbb2428963718ba85b0c353540910f20a499248a4e12b8805b1df022bf77a1a8c398035cb5d7529f280656249516adbd21f3020113b4a792eb3bda726d2712f1db582312f07a90118865608772e8ef3179440a2ef1b091487cf568cc640f20352337965a04c8443b75bd7e3e4d4e6ab8cb8bc75771c902858b2a5d2406b76b661e1aac99f5ef4c54e075300eca3a239a8b3448a49c03036f7876a761a75fcc1d729a1a0f0892ccb60e7f409d270981e97e00a151120d683f3c4d597888dcc66dac23e188443e46fa665644f89f0c182fdb67debe2503aa95243c903a14bb053efe7666d0c4e32a461e3a5ba7fa2f4a71da716c12b540ec64daaf745b13218e6521354148381d979546ed17c9919f4e361f60fad939a1d83f563440722959b3cfb39780e44a85f38161354ebb1895cab8d05d856a5eea2fe86a20eed67606b39f4a2d5e2615e7de7931d5d530dd62d22c2f8d93277e31128ca9e1af9bae71026a3f445613b98131eefcab4afb67cb82dbebf6030b9e3289bee42b40140ff24fb831e09d0fafd2ade1096757b0ab5c326a0d872a9b6a10064804b1afd638bffb39881224e54844e29f5a3a795e0a599268b1afd95a5b319b42c1e1f852aa90180116f716915b46008b9436e70d36b70efa5ce10d8f2771378ff883b985c0a4b152a570ddbe60ad3ac105d697af90524cfea879c02bea706c749d49d85338b846615f01e78bf71e348d9bdca83244637e0d6ab816f67d6c9f9e84f5050d10ad9579036d4c13bd45e492422159bf199731671e9e50efc4d607175cc88f41f454230195f2a736068cdb804d8747aa6d0c54592222dde6b15663917c8fa60a6c26b5a7d68b95bbac8f3747d49fc340b734234f4e45d0bd3777b9a237ea058d5b76b1c99b2c0d71874c192e06314e748474e32db67c2c17434f13b31b564bae0efa12089dc5d6cdc4032ef2e412c194b5fd62985848a957cf1a0f9110fd1daf8d2fa60712250ef4682764cafdd98d544b196a6961d381a17da2469be4415c28721724753e31252251d70ee971508c0c7618e68db1005d30570a5a1bf8388e089017c16800cbea847c0e15e37bd7cd6f12d2a6869cb116971dc1772255ce9b28d8be5552cc867345fd8289ffd5f285392388982857318212318fe7d4f9df39bb29a9891e1cb4544eed0aa3a098d6f86ef83d8b79568c23d263c9cebd30ecb8edb32906ab2a7fcc44cbe8239341f4e96d54ad7d3b0474f5b8d1042bcdb74a0a9b6b53a7232c58c1bab51e1cd53a26d6e3e606b6eb0b48e223a9e505f54d6f66c02f67617f75b18272fc16e1fd5891f14495d131e3172fdca476179d774df3f0d17a7b2b25ac0dd419d744a7e8fe9508a8b4cbd8ae32b5a4bdc0cb17073bd1939bad1d21b150d3b34230d84b0e1394a0f1931a642ad02468bda24b8a425d912e571d700fbbfff2aff10508995cf94373050855e68ef7ba9d597c18ae92cc17a949878eaf8974ce25062055698c7fe93e9afaccb2ccad7c4dce4af88f58bcc851dde42a6ca5989643196a82b3311f870bedf3733701cf14722b058a40b1453293432df4e4490404315c89e721b4bb10b296bbd4b9ef2c8aba299c6250d025ccdeaf12046e63d16d7deeac35a6452a0dbe54db09356924ceb6e8554b4094be4b7b9001278ac9ac1778c71be13b21b3be50a6128239875ba7bf68ffbcd86029b8cf3cdbeabfb4ef5d39958f947adbd3641fc9922ecc519e4d52a9a5269e756802be6efe5a7bdb50260160c7919c2d72bd1b9fdd6aa50700b01deb70eea555a827a10f6add11df145563c4899fb2e4880f8b9386069ad70bc4f6a1666e93e30e76b5a144bd25e7bb350b81b7dece1103f6a37abbd0637dd48d16eb42e5a10583a90f7cbcdd9d75df7a3b488bbd74a98114e51dc3ae8528966b87b27cd6f6d039eff399a4777ea130d803e60b3d780e92a0172e049ebc6f211d0eaf04bdcd01545066aea2a8847b0d08c410ab1f54b30e98af65f60cfe812b6f004c6982c5a7d436f0204796a9d748d7b7b9ee0848b940c6c88f922a9248aea1507a7816ba3a6747f28bb246440e97eb77d44752ce32eefcf0745f6559f103046e0e47613134cd79affe73a103994101fe26711299f06e02b63ed2460e39f83b58abfe46dd68c88063d94e2ecf7d51c5130a9db17fe6a82c165a5b93fb1ecd66f66922e7aa426e9dcb68dcb9e933588b86fe4a2daed301b3072237628b7cd847559effe52dc310138cfe0db92b1095e909826fe24382008d8d0053ec327e0a3128af21d7d2f200d289ceaf22a4300e650268bae8a9fb4899d119cfe9b4ddee44b7d83f6f228db884bd4bd269bff7fe296a58a3ef01c6779fa76527adb951eacfa17aed6bd1bb49122cd0e0513be0b04483f16706035191a98ca34b2c5688707c947a2050dac9cbf7bc5fe9cb09c63664c1510abcee2556871b572b0f64707bedf47b2f1ea129d4fe45d191d8677d6d6"+ "'", var16.equals("3ff99fa3e4f00f592e46cefa0ce4645bf1d5d7e3ea9b8d486bf5044b4b3646696d38bbcbaa650003d4eef89c5d222bb226e7cf77e5bb743e945474217150fbf164a0a6efde96f38eef5ee28a22e9e0208df82c7d22b197b6dbc536eaa3b819dca1884ecb3ff3b56b92fd5a46248a297dc488b297bc0109d8a7e7185c5cbd8860486e8aa37a428eb71451893bfb2124f468f07c77f618107dbb2428963718ba85b0c353540910f20a499248a4e12b8805b1df022bf77a1a8c398035cb5d7529f280656249516adbd21f3020113b4a792eb3bda726d2712f1db582312f07a90118865608772e8ef3179440a2ef1b091487cf568cc640f20352337965a04c8443b75bd7e3e4d4e6ab8cb8bc75771c902858b2a5d2406b76b661e1aac99f5ef4c54e075300eca3a239a8b3448a49c03036f7876a761a75fcc1d729a1a0f0892ccb60e7f409d270981e97e00a151120d683f3c4d597888dcc66dac23e188443e46fa665644f89f0c182fdb67debe2503aa95243c903a14bb053efe7666d0c4e32a461e3a5ba7fa2f4a71da716c12b540ec64daaf745b13218e6521354148381d979546ed17c9919f4e361f60fad939a1d83f563440722959b3cfb39780e44a85f38161354ebb1895cab8d05d856a5eea2fe86a20eed67606b39f4a2d5e2615e7de7931d5d530dd62d22c2f8d93277e31128ca9e1af9bae71026a3f445613b98131eefcab4afb67cb82dbebf6030b9e3289bee42b40140ff24fb831e09d0fafd2ade1096757b0ab5c326a0d872a9b6a10064804b1afd638bffb39881224e54844e29f5a3a795e0a599268b1afd95a5b319b42c1e1f852aa90180116f716915b46008b9436e70d36b70efa5ce10d8f2771378ff883b985c0a4b152a570ddbe60ad3ac105d697af90524cfea879c02bea706c749d49d85338b846615f01e78bf71e348d9bdca83244637e0d6ab816f67d6c9f9e84f5050d10ad9579036d4c13bd45e492422159bf199731671e9e50efc4d607175cc88f41f454230195f2a736068cdb804d8747aa6d0c54592222dde6b15663917c8fa60a6c26b5a7d68b95bbac8f3747d49fc340b734234f4e45d0bd3777b9a237ea058d5b76b1c99b2c0d71874c192e06314e748474e32db67c2c17434f13b31b564bae0efa12089dc5d6cdc4032ef2e412c194b5fd62985848a957cf1a0f9110fd1daf8d2fa60712250ef4682764cafdd98d544b196a6961d381a17da2469be4415c28721724753e31252251d70ee971508c0c7618e68db1005d30570a5a1bf8388e089017c16800cbea847c0e15e37bd7cd6f12d2a6869cb116971dc1772255ce9b28d8be5552cc867345fd8289ffd5f285392388982857318212318fe7d4f9df39bb29a9891e1cb4544eed0aa3a098d6f86ef83d8b79568c23d263c9cebd30ecb8edb32906ab2a7fcc44cbe8239341f4e96d54ad7d3b0474f5b8d1042bcdb74a0a9b6b53a7232c58c1bab51e1cd53a26d6e3e606b6eb0b48e223a9e505f54d6f66c02f67617f75b18272fc16e1fd5891f14495d131e3172fdca476179d774df3f0d17a7b2b25ac0dd419d744a7e8fe9508a8b4cbd8ae32b5a4bdc0cb17073bd1939bad1d21b150d3b34230d84b0e1394a0f1931a642ad02468bda24b8a425d912e571d700fbbfff2aff10508995cf94373050855e68ef7ba9d597c18ae92cc17a949878eaf8974ce25062055698c7fe93e9afaccb2ccad7c4dce4af88f58bcc851dde42a6ca5989643196a82b3311f870bedf3733701cf14722b058a40b1453293432df4e4490404315c89e721b4bb10b296bbd4b9ef2c8aba299c6250d025ccdeaf12046e63d16d7deeac35a6452a0dbe54db09356924ceb6e8554b4094be4b7b9001278ac9ac1778c71be13b21b3be50a6128239875ba7bf68ffbcd86029b8cf3cdbeabfb4ef5d39958f947adbd3641fc9922ecc519e4d52a9a5269e756802be6efe5a7bdb50260160c7919c2d72bd1b9fdd6aa50700b01deb70eea555a827a10f6add11df145563c4899fb2e4880f8b9386069ad70bc4f6a1666e93e30e76b5a144bd25e7bb350b81b7dece1103f6a37abbd0637dd48d16eb42e5a10583a90f7cbcdd9d75df7a3b488bbd74a98114e51dc3ae8528966b87b27cd6f6d039eff399a4777ea130d803e60b3d780e92a0172e049ebc6f211d0eaf04bdcd01545066aea2a8847b0d08c410ab1f54b30e98af65f60cfe812b6f004c6982c5a7d436f0204796a9d748d7b7b9ee0848b940c6c88f922a9248aea1507a7816ba3a6747f28bb246440e97eb77d44752ce32eefcf0745f6559f103046e0e47613134cd79affe73a103994101fe26711299f06e02b63ed2460e39f83b58abfe46dd68c88063d94e2ecf7d51c5130a9db17fe6a82c165a5b93fb1ecd66f66922e7aa426e9dcb68dcb9e933588b86fe4a2daed301b3072237628b7cd847559effe52dc310138cfe0db92b1095e909826fe24382008d8d0053ec327e0a3128af21d7d2f200d289ceaf22a4300e650268bae8a9fb4899d119cfe9b4ddee44b7d83f6f228db884bd4bd269bff7fe296a58a3ef01c6779fa76527adb951eacfa17aed6bd1bb49122cd0e0513be0b04483f16706035191a98ca34b2c5688707c947a2050dac9cbf7bc5fe9cb09c63664c1510abcee2556871b572b0f64707bedf47b2f1ea129d4fe45d191d8677d6d6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 5.93874021001523d);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test331"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-1.0328453233143338d), (java.lang.Number)39.771019031792285d, (java.lang.Number)2.1459739668757587d);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test332"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(1.011012866100247d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13.054451952539264d);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test333"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1848, 17L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test334"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(1343, 11531);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test335"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh((-1.197772344874983d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.5054315812347676d));

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test336"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-4.440892098500627E-16d));
    java.lang.Number var3 = var2.getMin();
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var8 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var4, (java.lang.Number)0.15729920705028488d, (java.lang.Number)(short)(-1), false);
    java.lang.Number var9 = var8.getMax();
    var2.addSuppressed((java.lang.Throwable)var8);
    boolean var11 = var2.getBoundIsAllowed();
    boolean var12 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (short)(-1)+ "'", var9.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test337"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-3.1315764174146636d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test338"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 9.536745E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test339"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.6759154008179424d, 11533);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test340"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.addElement(0.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var6.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.discardFrontElements(2041);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test341"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     int var20 = var0.nextBinomial(0, 0.7615941559557649d);
//     double var23 = var0.nextWeibull(1.2075656224493654d, 2.265662238504449d);
//     var0.reSeedSecure(40318L);
//     org.apache.commons.math3.distribution.NormalDistribution var26 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var27 = var26.getSupportUpperBound();
//     double var29 = var26.inverseCumulativeProbability(0.9999999999928669d);
//     double var31 = var26.density(25.472636453138065d);
//     double var32 = var26.getMean();
//     double var33 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var26);
//     double var34 = var26.getMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.8636355526969187d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "6ec85e1f55580f2d4c370e43544ff0f0d801bfc567ede688ec56354c6708efabe95d053d55c62c15308531dc80edd115828f"+ "'", var8.equals("6ec85e1f55580f2d4c370e43544ff0f0d801bfc567ede688ec56354c6708efabe95d053d55c62c15308531dc80edd115828f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.07787079419500827d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 2.124712837708369d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 6.755176609774487d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 5.055823438644928E-142d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.12993052037421432d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0.0d);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test342"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    float var7 = var4.getContractionCriteria();
    var4.discardFrontElements(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test343"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(3826);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test344"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.0295244230484082d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.799734029061339d);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test345"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.017688387388495763d, (java.lang.Number)4.440892098500626E-16d, (java.lang.Number)0.9999987388901819d);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.017688387388495763d+ "'", var4.equals(0.017688387388495763d));

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test346"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(22.831894383871205d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.778273159193727d);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test347"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.9999999999999925d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5430806348152348d);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test348"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(792111645L, 1348L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5862940464091933649L);

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test349"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var14 = var0.nextUniform(0.01005033585179189d, 0.14608902069952245d);
//     int var17 = var0.nextZipf(1972, 12.887557044182769d);
//     int var20 = var0.nextBinomial(0, 0.7615941559557649d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var0.nextPascal(2106, 11900.986496497815d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 19.481638472344926d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d72bc0f03fa570476288cf6d1c1474bcd8520f300969d8b81b9c4d29a2a0f374a5983338cd8dcbe2f0f458a6c06a712e25ca"+ "'", var8.equals("d72bc0f03fa570476288cf6d1c1474bcd8520f300969d8b81b9c4d29a2a0f374a5983338cd8dcbe2f0f458a6c06a712e25ca"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.11226780552414145d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test350"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.33765583161665175d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test351"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test352"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(9192904, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9192914);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test353"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var5 = new org.apache.commons.math3.exception.OutOfRangeException(var2, (java.lang.Number)2.3841858E-7f, (java.lang.Number)(byte)0);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test354"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.5246524883391532d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5523068567111992d);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test355"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.1210138782754731d);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test356"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(271, 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test357"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1.0246701172301718d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5193808140676351d);

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test358"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var12 = var0.nextT(3.7945526405881016d);
//     int var15 = var0.nextSecureInt(0, 1930);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("4eae2162585c9e988f7b1d855bed9250b3896de648255d2eb9077630f97d2fa17d90d91fe34ff81c4f8237b19ad0de2929ad", "7b2cb6cac544a7535d44589c89befd3f7021c70775ebb64cb11d386f733bb61cf8d58b3821009538b85708513d2f3993bd7f");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.085072796628938d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "64cc92aefd"+ "'", var8.equals("64cc92aefd"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2.180143889758795d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-2.572047554469366d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 528);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test359"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("31192d5088");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test360"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-1342156216L), 243746L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 163572604512568L);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test361"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0, 14273034);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test362"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.5658474030075499d, 14.031149057314524d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("f136ceae8c", "74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 3.8035594018378815d);
// 
//   }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test363"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(4.2E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test364"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.8448592018599629d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6883742472727229d);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test365"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test366"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(8336, 1592);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test367"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.056284901390102234d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9365562932579103d);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test368"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)Double.NaN, var2, false);
    java.lang.Number var5 = var4.getMax();
    java.lang.Number var6 = var4.getMax();
    java.lang.Number var7 = var4.getMax();
    java.lang.Number var8 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test369"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.clear();
    float var8 = var6.getExpansionFactor();
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, var14);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 11L);
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    java.math.BigInteger var21 = null;
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 0L);
    java.math.BigInteger var24 = null;
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 0L);
    java.math.BigInteger var27 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, var26);
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, 6L);
    org.apache.commons.math3.exception.OutOfRangeException var30 = new org.apache.commons.math3.exception.OutOfRangeException(var18, (java.lang.Number)5.363952139253263d, (java.lang.Number)14.087081017797523d, (java.lang.Number)var29);
    java.math.BigInteger var31 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, var29);
    boolean var32 = var6.equals((java.lang.Object)var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setContractionCriteria(1.1368685E-13f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test370"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)22.43277156890168d);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test371"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(11274, 1319);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 14870406);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test372"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.5d, Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.5d));

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test373"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(26.0d, 0.804695507808558d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 26.0d);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test374"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.9371612764804269d);

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test375"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     int var5 = var4.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
//     var4.addElement((-0.43408597923864894d));
//     double var10 = var4.getElement(0);
//     var4.clear();
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var13 = var12.getStandardDeviation();
//     double[] var15 = var12.sample(1);
//     double var16 = var12.getMean();
//     double[] var18 = var12.sample(100);
//     var4.addElements(var18);
//     double[] var20 = var4.getElements();
//     float var21 = var4.getExpansionFactor();
//     var4.clear();
//     double[] var23 = var4.getElements();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.6505375708978487d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
// 
//   }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test376"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextPascal(8899, 0.8219866295031046d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var13 = var12.getStandardDeviation();
//     double[] var15 = var12.sample(1);
//     double var16 = var12.getMean();
//     double[] var18 = var12.sample(100);
//     boolean var19 = var12.isSupportLowerBoundInclusive();
//     boolean var20 = var12.isSupportUpperBoundInclusive();
//     double[] var22 = var12.sample(8899);
//     double var23 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     java.lang.String var25 = var0.nextHexString(10775);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.434632978282093d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "44a28746ac"+ "'", var8.equals("44a28746ac"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1909);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-0.5677616357109513d));
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test377"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.565066791552435d);

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test378"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 1.0d);
//     double var5 = var0.nextChiSquare(7.6675647339750626d);
//     int var8 = var0.nextInt(9, 1866);
//     org.apache.commons.math3.distribution.IntegerDistribution var9 = null;
//     int var10 = var0.nextInversionDeviate(var9);
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test379"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.9999996994297856d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8414708224090786d);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test380"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.8120478124015589d, 0.005870409207427203d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9987785505199035d);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test381"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-0.1557414973394419d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-8.92333049259796d));

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test382"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     double var12 = var0.nextGamma(4.950886585270677E-4d, 1.5703107297735257d);
//     int var15 = var0.nextInt(2, 17018);
//     int var18 = var0.nextSecureInt(206, 13890);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.14644559816916d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 782);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 9666);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test383"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(9, 18L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1953380655));

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test384"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(6.379056246523006d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6L);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test385"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.getMean();
//     double[] var6 = var0.sample(100);
//     double var7 = var0.sample();
//     double var8 = var0.sample();
//     var0.reseedRandomGenerator(10L);
//     boolean var11 = var0.isSupportLowerBoundInclusive();
//     double var12 = var0.getMean();
//     double var14 = var0.inverseCumulativeProbability(2.4806185630527824E-155d);
//     double var15 = var0.getMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.6475970207672137d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.8529693647448696d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-1.0038989723989089E77d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test386"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(1625, 55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1570);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test387"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(8941, 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8941);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test388"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-0.7431658386130204d), 0.0d, 10.792740204640475d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test389"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    var4.addElement(14.031149057314524d);
    var4.setExpansionMode(0);
    var4.discardMostRecentElements(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test390"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     var0.reSeed(4L);
//     double var8 = var0.nextGaussian(0.7625552649455967d, 0.15512025679417774d);
//     int var11 = var0.nextPascal(337860, 0.5322866968936354d);
//     var0.reSeedSecure();
//     java.util.Collection var13 = null;
//     java.lang.Object[] var15 = var0.nextSample(var13, 9891);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test391"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(4.5535597409955875d, 0.9999999987705535d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-8.110291000076801E-10d));

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test392"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.9461495467846752d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9461495467846752d);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test393"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.968428078321897d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.67723529444864d);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test394"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(18, 1.0f, 1.1368685E-13f, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test395"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-0.26578716895046123d), 3.7817178733294683d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.791046411301009d);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test396"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(99.99999f, 1.1650603907741712d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99.999985f);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test397"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(11401, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test398"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-0.8239785130306663d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7512830194340976d));

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test399"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.5718637074096835d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test400"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     double var16 = var0.nextGamma(0.11604808277231957d, 0.8382617516745859d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var18 = var0.nextPoisson((-8.244174900448879E-16d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.495120207344593d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "83bca01da3"+ "'", var8.equals("83bca01da3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.754909647228148d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 9351);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.1258093944040152E-5d);
// 
//   }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test401"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.9999999999995994d, 0.0d, 1.1650603907741712d, 20355937);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test402"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var12 = var0.nextT(17.412259994235388d);
//     double var15 = var0.nextCauchy(0.04237399784732393d, 0.9999999999928669d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 16.354803803411567d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "e8369b8576"+ "'", var8.equals("e8369b8576"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.4275039276428256d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.1360221849681933d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.17157694510532503d));
// 
//   }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test403"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(6.69439006693305E-5d, 6.54642801564943d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.694390066933051E-5d);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test404"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.56089788532758d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test405"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.03801238913895068d);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var7 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var6, (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var4, (java.lang.Number)(-0.2554932247505838d), (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, (java.lang.Object[])var7);
// 
//   }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test406"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextUniform(0.2577047455984825d, 13.770182159584014d);
//     long var6 = var1.nextPoisson(23.012289905639566d);
//     int var9 = var1.nextZipf(10178, 0.5950413774252329d);
//     int var12 = var1.nextSecureInt((-508), 11122);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.3003553743104947d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 16L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 141);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1255);
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test407"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var6);
    java.lang.String var9 = var6.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var10 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.Class var13 = var12.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    java.lang.String var15 = var12.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var12);
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    java.lang.Class var19 = var18.getDeclaringClass();
    java.lang.Class var20 = var18.getDeclaringClass();
    boolean var22 = var18.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
    java.lang.Class var23 = var18.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "AVERAGE"+ "'", var9.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test408"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(20355979);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test409"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(1865, 1868);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3483820);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test410"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
//     java.lang.Class var5 = var4.getDeclaringClass();
//     int var6 = var4.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var4);
//     org.apache.commons.math3.random.RandomGenerator var8 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
//     org.apache.commons.math3.random.RandomGenerator var10 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
//     java.lang.Class var15 = var14.getDeclaringClass();
//     java.lang.Class var16 = var14.getDeclaringClass();
//     boolean var18 = var14.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
//     java.lang.Class var19 = var14.getDeclaringClass();
//     java.lang.Class var20 = var14.getDeclaringClass();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var14);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var25 = var24.getTiesStrategy();
//     java.lang.Class var26 = var25.getDeclaringClass();
//     java.lang.Class var27 = var25.getDeclaringClass();
//     boolean var29 = var25.equals((java.lang.Object)"74b6a7ab0a9f876b2751a0e2a509010d6a67f2a1bc469f96ce607f51ce4915270dc49ea182f3c90e6e0f843b4fddb22f9f89");
//     org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var31 = var30.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var32 = var30.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var33 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var35 = var34.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var36 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var33, var35);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var35);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var38 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var32, var35);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var40 = var39.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var41 = var39.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var42 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var43 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var44 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var45 = var44.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var46 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var43, var45);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var47 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var42, var45);
//     java.lang.String var48 = var45.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var49 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var41, var45);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var50 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var51 = var50.getTiesStrategy();
//     java.lang.Class var52 = var51.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var53 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var51);
//     java.lang.String var54 = var51.toString();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var55 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var41, var51);
//     org.apache.commons.math3.distribution.NormalDistribution var56 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var57 = var56.getStandardDeviation();
//     double[] var59 = var56.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var60 = new org.apache.commons.math3.util.ResizableDoubleArray(var59);
//     double[] var61 = var60.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var62 = new org.apache.commons.math3.util.ResizableDoubleArray(var61);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var63 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var67 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var68 = new org.apache.commons.math3.util.ResizableDoubleArray(var67);
//     double[] var72 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var73 = new org.apache.commons.math3.util.ResizableDoubleArray(var72);
//     double var74 = var63.mannWhitneyU(var67, var72);
//     double var75 = var55.mannWhitneyUTest(var61, var67);
//     org.apache.commons.math3.distribution.NormalDistribution var76 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var77 = var76.getStandardDeviation();
//     double[] var79 = var76.sample(1);
//     double var80 = var76.getMean();
//     double[] var82 = var76.sample(100);
//     boolean var83 = var76.isSupportLowerBoundInclusive();
//     boolean var84 = var76.isSupportUpperBoundInclusive();
//     double[] var86 = var76.sample(8899);
//     double var87 = var38.mannWhitneyUTest(var61, var86);
//     double[] var88 = var23.rank(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var48 + "' != '" + "AVERAGE"+ "'", var48.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var54 + "' != '" + "AVERAGE"+ "'", var54.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 4.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 0.17971249487899976d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == 0.5862136996898879d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test411"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-0.4275039276428256d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.34786515936161894d));

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test412"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.3395848497381705d, 1.8136343340898944d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.8451523969475774d);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test413"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(9448, 9.536745E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test414"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.0471975511965979d, 0.815297812486526d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.23189973871007186d);

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test415"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(0L);
//     int var18 = var0.nextBinomial(0, 0.33421337133949025d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var22 = var0.nextCauchy(0.6559374372572462d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 13.07418078043398d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "b1d318eaa1"+ "'", var8.equals("b1d318eaa1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-2.0625329291301324d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 9410);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
// 
//   }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test416"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(16.788229704441893d, 0.5658474030075499d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.18719238578460362d));

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test417"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1319, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test418"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-0.21998170024720057d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.21650061956483213d));

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test419"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     int var11 = var0.nextInt((-1), 100);
//     double var14 = var0.nextGamma(0.15861286098539223d, 23.79178096943456d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextZipf(13890, (-0.9112973910588607d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.681932555347033d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "e41ac0c7ef"+ "'", var8.equals("e41ac0c7ef"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.2371585795324627d);
// 
//   }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test420"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     long var10 = var0.nextPoisson(3.2359311173302077d);
//     var0.reSeedSecure(0L);
//     org.apache.commons.math3.distribution.RealDistribution var13 = null;
//     double var14 = var0.nextInversionDeviate(var13);
// 
//   }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test421"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     long var11 = var0.nextSecureLong((-2L), 0L);
//     double var13 = var0.nextExponential(20441.91590500824d);
//     int var16 = var0.nextSecureInt(36, 1818);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.156141790490718d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5079051459a163870107cb2a310eb4ed5a7cf2b5fc9621acacd679b2fda742807aec09705c31fc4fe6b291f7caa99a94d8f7"+ "'", var8.equals("5079051459a163870107cb2a310eb4ed5a7cf2b5fc9621acacd679b2fda742807aec09705c31fc4fe6b291f7caa99a94d8f7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 71103.96147171131d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 118);
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test422"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.5511164092704044d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948966d);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test423"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-66.59404174699007d), 0.9999494975001091d);

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test424"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGamma(16.915172776155245d, 0.27820249749496384d);
//     double var6 = var1.nextExponential(0.474409494669181d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 5.347709518514384d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.3444854821112421d);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test425"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(2.0134882573780497d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.109378609340782d));

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test426"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-1.4664683179220708d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8989016041376859d));

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test427"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.872415613239279d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.809212267196822d));

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test428"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.804695507808558d);

  }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test429"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 0.2996992891032666d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test430"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(4.505452107819377E9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.00000000248643d);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test431"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(1966);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 12948.375746260992d);

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test432"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     double var4 = var0.sample();
//     boolean var5 = var0.isSupportUpperBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1.1981027661961499d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test433"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.7993162117562352d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7993162117562351d));

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test434"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    int var2 = var1.getExpansionMode();
    double var4 = var1.addElementRolling((-0.6487974831986031d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test435"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     int var11 = var0.nextZipf(5, 0.8273572477024794d);
//     int var14 = var0.nextBinomial(1972, 0.15795521463156686d);
//     var0.reSeed();
//     var0.reSeedSecure(0L);
//     long var20 = var0.nextLong((-2L), 760L);
//     double var23 = var0.nextWeibull(12.156051169789169d, 16.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.425297116723329d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "69dde94afc6efe9f56a1ab2a7e57762904c36107d67dc720819610bd3dee25de886b8a8e1033a965df0dc2ae6a8fe7d49798"+ "'", var8.equals("69dde94afc6efe9f56a1ab2a7e57762904c36107d67dc720819610bd3dee25de886b8a8e1033a965df0dc2ae6a8fe7d49798"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 349);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 523L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 16.45831986295403d);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test436"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var4.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test437"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getSupportUpperBound();
//     double[] var3 = var0.sample(10);
//     double var4 = var0.getStandardDeviation();
//     double var6 = var0.density(2.345330933436551d);
//     double var7 = var0.getSupportLowerBound();
//     double var9 = var0.cumulativeProbability(0.5231370181288907d);
//     double var10 = var0.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.025496167636629936d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.6995605468138986d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.22984051317348442d));
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test438"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(1.7857104142610332d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1833077938740821d);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test439"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.0019953167668664154d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.001995314118893067d);

  }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test440"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     var0.reSeed(4L);
//     java.lang.String var7 = var0.nextHexString(1);
//     long var10 = var0.nextSecureLong((-536829416L), 243746L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "2"+ "'", var7.equals("2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-231249447L));
// 
//   }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test441"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.935585369367399d, 9.954021851066004d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.18579629985980917d);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test442"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.4021130954622116d, 0.7800592111940521d, 0.0d);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test443"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(2.707647489616169d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.4634046666243402d));

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test444"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 6L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 268435456L);
    java.math.BigInteger var11 = null;
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0L);
    java.math.BigInteger var14 = null;
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 0L);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, var16);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 201600L);
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, 1980);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test445"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.7740996449567269d, 0.4920131607586285d, 0.0d);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test446"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(15.685448285813305d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999999999525d);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test447"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var5 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var4, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)0.5662191695169728d, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test448"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var5 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)(-1), (java.lang.Object[])var5);
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.3318802236436214d, (java.lang.Object[])var5);
    java.lang.Number var9 = var8.getMax();
    java.lang.Number var10 = var8.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 0.3318802236436214d+ "'", var9.equals(0.3318802236436214d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 0.3318802236436214d+ "'", var10.equals(0.3318802236436214d));

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test449"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)23.556688781581023d);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test450"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, 7.444490968701611d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test451"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.setContractionCriteria(2.5f);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setExpansionMode(1343);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test452"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-1.2266514872174121d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0329238212478014d));

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test453"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-2.109378609340782d), var1, (java.lang.Number)(-0.052420351515950536d));

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test454"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.09630369202868827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1083320717391616d);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test455"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-297258196));

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test456"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    double var4 = var0.getMean();
    double[] var6 = var0.sample(100);
    boolean var7 = var0.isSupportLowerBoundInclusive();
    boolean var8 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator(704L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test457"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.04002941178126392d, 0.40102927495477353d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.04002941178126392d);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test458"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(782, 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test459"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.1368684E-13f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1368683E-13f);

  }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test460"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var3);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var3);
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var9 = var6.nextSecureLong((-1L), 1L);
//     double var12 = var6.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var15 = var6.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var17 = var16.getStandardDeviation();
//     double[] var19 = var16.sample(1);
//     double var21 = var16.cumulativeProbability(0.0d);
//     double var22 = var16.getSupportUpperBound();
//     double var23 = var6.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var16);
//     var6.reSeed();
//     boolean var25 = var3.equals((java.lang.Object)var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var28 = var6.nextCauchy(4.069455911176068d, (-0.08314548357851374d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2.535758275299709d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.22283281967685242d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
// 
//   }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test461"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(2.1852017790592613d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5357797505237121d);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test462"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0, 1955);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test463"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var5);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 243);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 4L);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 40486L);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 9192904);
    java.math.BigInteger var15 = null;
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 0L);
    java.math.BigInteger var18 = null;
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 0L);
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, var20);
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 11L);
    org.apache.commons.math3.exception.util.Localizable var24 = null;
    java.math.BigInteger var27 = null;
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var27, 0L);
    java.math.BigInteger var30 = null;
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var30, 0L);
    java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var29, var32);
    java.math.BigInteger var35 = org.apache.commons.math3.util.ArithmeticUtils.pow(var29, 6L);
    org.apache.commons.math3.exception.OutOfRangeException var36 = new org.apache.commons.math3.exception.OutOfRangeException(var24, (java.lang.Number)5.363952139253263d, (java.lang.Number)14.087081017797523d, (java.lang.Number)var35);
    java.math.BigInteger var37 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, var35);
    java.math.BigInteger var38 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var23);
    java.math.BigInteger var39 = null;
    java.math.BigInteger var41 = org.apache.commons.math3.util.ArithmeticUtils.pow(var39, 0L);
    java.math.BigInteger var42 = null;
    java.math.BigInteger var44 = org.apache.commons.math3.util.ArithmeticUtils.pow(var42, 0L);
    java.math.BigInteger var45 = org.apache.commons.math3.util.ArithmeticUtils.pow(var41, var44);
    java.math.BigInteger var47 = org.apache.commons.math3.util.ArithmeticUtils.pow(var45, 40318L);
    java.math.BigInteger var48 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test464"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var12 = var0.nextT(3.7945526405881016d);
//     var0.reSeed(1L);
//     double var18 = var0.nextUniform((-0.5941416427828103d), 0.0d, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.625997534715509d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d81f5ac863"+ "'", var8.equals("d81f5ac863"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.5120066175593998d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1.617901322393736d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.5509017765296461d));
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test465"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(51);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test466"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(15.0d, 16.021556863191527d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 15.000000000000002d);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test467"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.2203546622344768d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.08648606466429147d);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test468"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var5 = var4.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var4.getElement(14273034);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test469"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(7.661483307238503d, 25.73689552674863d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.661483307238503d);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test470"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.16043285994536438d, 0.25587682077976953d, (-0.6801548754218844d));
    double var4 = var3.getNumericalMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var3.cumulativeProbability(1.2325719927685974d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.16043285994536438d);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test471"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.962687440464552d), (java.lang.Number)(-0.33143925087381365d), false);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test472"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 10.0f);
    var2.addElement(0.15729920705028488d);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var2.equals((java.lang.Object)var8);
    float var13 = var2.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10.0f);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test473"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test474"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(32L, 862652752360L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test475"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     int var9 = var0.nextInt((-1), 10);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getStandardDeviation();
//     double[] var13 = var10.sample(1);
//     double var15 = var10.cumulativeProbability(0.0d);
//     double var16 = var10.getSupportUpperBound();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     var0.reSeed();
//     int var21 = var0.nextZipf(1859, 9.717527268210787E-6d);
//     java.lang.String var23 = var0.nextHexString(4337);
//     double var26 = var0.nextGaussian(0.5875560860656794d, 0.17994611088998624d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.6506265659340917d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.4683012692236799d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 838);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "369ff86437459a9efdf212375c058d72c4c17b6985af56bed0c59bdbe287719436a48bc1b6bcdd3f8005a7623bef7ba5788f1260a4fd7b2d379e51734a2abeb31071ef0525d59ee2da2d0661c54c33a0ce1134f4198df36b2c7c019a89ab48ded92746c9f5c87bf02d4746d987fb755cfaa30291ee897226bc83be89c65360450b94c2f364ad688e589dda644707229f1b7e4374b449d1b67fc60d269ca33481dfbcd3f1bcb9694ebdb38a10944b28b7912da9067998de15d835d0eb44c4a1424b0055e2f33b9694c3b4635bd217e2efb6102292cec3da61b11c7cb69c5a387c7e776c08acb0ecdff8f4049662a4967c04c226c0792538ab807a1d47149609e117512a38f6afdea856339516ea6016ad5ef13e8c6de77f31231011f9f4e2e2d5211cce84159e805ce8663dffb8c8aabd21f0fad0f8d0f1898a2e48a565b0585f44c5c35c82438bddd94cb873f8871fed9f68acd16b19d7d32807f5d88d710ca521b632af584cf8b53973c7282ebaa4cff7f37b64b405a4dfed7dae7bc466f01117dfede37b4117a3fd598469600e65810c009225a546529f1d324a3c5bbc881e7d9609c9a232844d0fcaa052c23b4c80ae595469d4877c54889509a1f935b8be765798ad1874707262c964e044ae530ec3257df7d42788a39ddcf5cbfaf9e4eafa199feafc2ee98516f2a8b20777fd9b5561fc151c624d8230c4756dbe4b2ff56969c64fcc2dce93840abfd0b7215088dcd7ea43d3595e2fdb765861c6fa540b6a75b78c0c35e40a49d477d6b60aadcaf80fac47fc194d06b1868fd15daa1a6cfe211336313b912b5f182324b067235b4d36e59b5baa4c9c7a3197db9086b28524928c79e134284a03f1774c8d9492e81c209375b7c7828b83ee30ede6c90b63a6fceeb27b5e2142b6fb216bb88e8f5de852fa2a5cea5caf3a4bb46249b2c6660725414bd0d6e7763a63cf16fa5ca2b23dceb2fba0cbe4ab9f73c6000fffd639c52cb3f66c82a163296e673582818ff38f8f8011efcba050dd2de10e02775522a61a13b77a22e40b2b7809a0dc716364b5e1f5a19e5c355b2507eba87aca184b04ffadace6cce2deb1dd407c5a6801823302c09cfc31d29fbd9ed8b91967424b5b2877357d6e42a33d4d9b73f3ac289167d55a97a52703980875bd9fcb7aebf8eeec19fafd80dd8a19924b125332601f4eb6e47c0be0ff6188192cedb517d5a84db30a42effd40a598c0128acb75b56536e78762054bca29e08d89ff3ce7a1de42e332866291521d7311749bdfa49a47a874e50828d7e1aaf5928bf0f77a0f3ad3504e2c8c8e5e68d143a03cbc6f179b5faf929ca99ee2ba34e374547f0551696e44313af57921e8e9a543e8f889b52bd2a780542fe9a32566ca9b65bc5de3519ade2d9fde297e9fcb903e584957bac22ab5a03310b496cafaa0f9fd07cb4c84ca75e1c057d664a56c7459c3f0d276029e6d6dd85e92f1f67582f73f279a2f499602131da69f6c5a4a18f303de649f925287a25b4e434e5c4f4b93c4c343aba18598a0b9636e2d4093303c5d2af5b8341387a0962b4d9166b923ce38b9ef547ab63bd560e8998f626b8232f9400e5ff8a9f8adb6ccfb51201ea6a9e248d2e04b0c42de0399885f6d4eaf71924c3a853ec4028ae1fe10737cfe138c255765b833b34cca03548a16bac6fdc5a11997d77dc4040360668fa64a5bc409deaa0386534618fbb3d3344ba3d11ba7adc23fd56a6915d9dc36bd15aa85b7cde23d175502518ab9faa6bf1d5f2ef305312c7a4cf71276cea760f5065c247feb4d5101cafb8b45767cf5168e3ef59bca5b66a2f32322d80838803ecd76ae19c8506dc9f5522cd9c73cda5c18340db0ca15525af6f8756dbafd6725916134dde3ceadfa22618c326dc4b793e7fad6fc6c1bf8e232b432cc9d93b76b4b232209e17b8d84d407db0dc896512af3bc5a4967aaddbb987b18a46ff7c197b7c448709efce3312af9bf087552c83cbdf50d856fc4cfa3e75209c531e7a1a29c8bec3867fe2a92381c6ce040de3ce7df5add224ae766bc737894fcbb9480f066d51fcd1ecf1074f05670eed2b20a2962ed71dc4befd22e732985f8431b9d5da9c113cefba4ce19ec3d0e1ea657935254109f052b9153769b52bf1d37705f6e03323dd5dddcfed41b5dc9ec348ae0dcefdf01b1a62aab5b401976b0624bd23ba3fe70c22526c1e0fa0674680b073f86d3911481f6988cfb16a632d3cea5e1db434ee2caac8a81090158e289cb1798823966d1e68c411e81c4fe2adec1276fe8bee500dab383220fc1a664bfa3642d77af955aac50e8babcbc0194dc4f8176a85fd33b3be27b9f82ba18aff6c0db87a2e0e05b69d3ad0362e5d14abd1e3c72944566128c44923b072e44eb0a8b26c434900b9487728c0fc85520b26c76ecc998a1cb8264a127c8f1236ef7f50437c5e9cec1727d8e56e3ae98e972538fba481cdd5e1e779432f43a84045295576efa9e3a273d5b07f41f46784eb684f76cb346a666e17b4aea76912d6016c7d6e9f65def525877b713a831f73e0f1ef5f1167a5c98dc52959c325f07aa957e6f1d58fb17867d3c9f2a8241c73830a3a95e7e709c59d0ef1bd0c41323c92f1c2f6b5e70348003983890ee3a01875ad00f58afa5f438c444d5be37849a462e6fcb97bc816dabe490d3727e1574f9dbd4fb42321e7981cc7623f0beb3dbb9b82733a61dcc81d46be4c520305524d8a832ae57d51b67e4672a26c7eb41206a126a0f5091ee7d2547d189e16a81f0714b38daf959150430878c45389a113c287fa34a76bcdf596f4f235549fed0faa098db9c469315db7511b483152d4a6492d43e86b0eb9821c3854575c0dfbdd19df57f9c50f59a64cec09b8e44afe376815181b51adc79a980bfc36f08b7240c0dfd9e65a0be4152406ed7067c30a80831314ee95e428d2ff88139a29b0a8bac04d036beedc40787a6b160079594df1dcb7a751fb83570fb0b2b19efca8d13baa0403bf97ceb84481b3291e4c2ff583b149738ae9364f317af497956d87f9dc31f4b56370bb7adfedd3"+ "'", var23.equals("369ff86437459a9efdf212375c058d72c4c17b6985af56bed0c59bdbe287719436a48bc1b6bcdd3f8005a7623bef7ba5788f1260a4fd7b2d379e51734a2abeb31071ef0525d59ee2da2d0661c54c33a0ce1134f4198df36b2c7c019a89ab48ded92746c9f5c87bf02d4746d987fb755cfaa30291ee897226bc83be89c65360450b94c2f364ad688e589dda644707229f1b7e4374b449d1b67fc60d269ca33481dfbcd3f1bcb9694ebdb38a10944b28b7912da9067998de15d835d0eb44c4a1424b0055e2f33b9694c3b4635bd217e2efb6102292cec3da61b11c7cb69c5a387c7e776c08acb0ecdff8f4049662a4967c04c226c0792538ab807a1d47149609e117512a38f6afdea856339516ea6016ad5ef13e8c6de77f31231011f9f4e2e2d5211cce84159e805ce8663dffb8c8aabd21f0fad0f8d0f1898a2e48a565b0585f44c5c35c82438bddd94cb873f8871fed9f68acd16b19d7d32807f5d88d710ca521b632af584cf8b53973c7282ebaa4cff7f37b64b405a4dfed7dae7bc466f01117dfede37b4117a3fd598469600e65810c009225a546529f1d324a3c5bbc881e7d9609c9a232844d0fcaa052c23b4c80ae595469d4877c54889509a1f935b8be765798ad1874707262c964e044ae530ec3257df7d42788a39ddcf5cbfaf9e4eafa199feafc2ee98516f2a8b20777fd9b5561fc151c624d8230c4756dbe4b2ff56969c64fcc2dce93840abfd0b7215088dcd7ea43d3595e2fdb765861c6fa540b6a75b78c0c35e40a49d477d6b60aadcaf80fac47fc194d06b1868fd15daa1a6cfe211336313b912b5f182324b067235b4d36e59b5baa4c9c7a3197db9086b28524928c79e134284a03f1774c8d9492e81c209375b7c7828b83ee30ede6c90b63a6fceeb27b5e2142b6fb216bb88e8f5de852fa2a5cea5caf3a4bb46249b2c6660725414bd0d6e7763a63cf16fa5ca2b23dceb2fba0cbe4ab9f73c6000fffd639c52cb3f66c82a163296e673582818ff38f8f8011efcba050dd2de10e02775522a61a13b77a22e40b2b7809a0dc716364b5e1f5a19e5c355b2507eba87aca184b04ffadace6cce2deb1dd407c5a6801823302c09cfc31d29fbd9ed8b91967424b5b2877357d6e42a33d4d9b73f3ac289167d55a97a52703980875bd9fcb7aebf8eeec19fafd80dd8a19924b125332601f4eb6e47c0be0ff6188192cedb517d5a84db30a42effd40a598c0128acb75b56536e78762054bca29e08d89ff3ce7a1de42e332866291521d7311749bdfa49a47a874e50828d7e1aaf5928bf0f77a0f3ad3504e2c8c8e5e68d143a03cbc6f179b5faf929ca99ee2ba34e374547f0551696e44313af57921e8e9a543e8f889b52bd2a780542fe9a32566ca9b65bc5de3519ade2d9fde297e9fcb903e584957bac22ab5a03310b496cafaa0f9fd07cb4c84ca75e1c057d664a56c7459c3f0d276029e6d6dd85e92f1f67582f73f279a2f499602131da69f6c5a4a18f303de649f925287a25b4e434e5c4f4b93c4c343aba18598a0b9636e2d4093303c5d2af5b8341387a0962b4d9166b923ce38b9ef547ab63bd560e8998f626b8232f9400e5ff8a9f8adb6ccfb51201ea6a9e248d2e04b0c42de0399885f6d4eaf71924c3a853ec4028ae1fe10737cfe138c255765b833b34cca03548a16bac6fdc5a11997d77dc4040360668fa64a5bc409deaa0386534618fbb3d3344ba3d11ba7adc23fd56a6915d9dc36bd15aa85b7cde23d175502518ab9faa6bf1d5f2ef305312c7a4cf71276cea760f5065c247feb4d5101cafb8b45767cf5168e3ef59bca5b66a2f32322d80838803ecd76ae19c8506dc9f5522cd9c73cda5c18340db0ca15525af6f8756dbafd6725916134dde3ceadfa22618c326dc4b793e7fad6fc6c1bf8e232b432cc9d93b76b4b232209e17b8d84d407db0dc896512af3bc5a4967aaddbb987b18a46ff7c197b7c448709efce3312af9bf087552c83cbdf50d856fc4cfa3e75209c531e7a1a29c8bec3867fe2a92381c6ce040de3ce7df5add224ae766bc737894fcbb9480f066d51fcd1ecf1074f05670eed2b20a2962ed71dc4befd22e732985f8431b9d5da9c113cefba4ce19ec3d0e1ea657935254109f052b9153769b52bf1d37705f6e03323dd5dddcfed41b5dc9ec348ae0dcefdf01b1a62aab5b401976b0624bd23ba3fe70c22526c1e0fa0674680b073f86d3911481f6988cfb16a632d3cea5e1db434ee2caac8a81090158e289cb1798823966d1e68c411e81c4fe2adec1276fe8bee500dab383220fc1a664bfa3642d77af955aac50e8babcbc0194dc4f8176a85fd33b3be27b9f82ba18aff6c0db87a2e0e05b69d3ad0362e5d14abd1e3c72944566128c44923b072e44eb0a8b26c434900b9487728c0fc85520b26c76ecc998a1cb8264a127c8f1236ef7f50437c5e9cec1727d8e56e3ae98e972538fba481cdd5e1e779432f43a84045295576efa9e3a273d5b07f41f46784eb684f76cb346a666e17b4aea76912d6016c7d6e9f65def525877b713a831f73e0f1ef5f1167a5c98dc52959c325f07aa957e6f1d58fb17867d3c9f2a8241c73830a3a95e7e709c59d0ef1bd0c41323c92f1c2f6b5e70348003983890ee3a01875ad00f58afa5f438c444d5be37849a462e6fcb97bc816dabe490d3727e1574f9dbd4fb42321e7981cc7623f0beb3dbb9b82733a61dcc81d46be4c520305524d8a832ae57d51b67e4672a26c7eb41206a126a0f5091ee7d2547d189e16a81f0714b38daf959150430878c45389a113c287fa34a76bcdf596f4f235549fed0faa098db9c469315db7511b483152d4a6492d43e86b0eb9821c3854575c0dfbdd19df57f9c50f59a64cec09b8e44afe376815181b51adc79a980bfc36f08b7240c0dfd9e65a0be4152406ed7067c30a80831314ee95e428d2ff88139a29b0a8bac04d036beedc40787a6b160079594df1dcb7a751fb83570fb0b2b19efca8d13baa0403bf97ceb84481b3291e4c2ff583b149738ae9364f317af497956d87f9dc31f4b56370bb7adfedd3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.5092606975455967d);
// 
//   }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test476"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(7.727639162426612d, 4.118046445935819d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4539.605480907824d);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test477"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 168.32744544842768d);

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test478"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextHexString(10);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     int var13 = var0.nextPascal(100, 0.01005033585179189d);
//     var0.reSeedSecure(0L);
//     int var18 = var0.nextBinomial(0, 0.33421337133949025d);
//     double var21 = var0.nextGamma(0.8847656390164815d, 0.9935022674622966d);
//     int var24 = var0.nextZipf(11049, 0.9361319785805509d);
//     java.lang.String var26 = var0.nextSecureHexString(1836);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.477865207019324d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "a406ad9076"+ "'", var8.equals("a406ad9076"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.549015772836617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 9911);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.5218641984339922d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "6e0ec15519f49c14b2678e69e83e2f89752364f8cf423fe8dd0da0d80906fcf1b7d0033d9229629ea05bb3538790e2becc86c6c6d6f5905f456249e960c31976e40b30434184793b045c3beeb61bd73fd87d81a88607ea30916215f78ee73c7abaeb029031929aaba154e908ecf1789fe0da51976d6d484756ebb22437871ff936a82c2de213a8cfdec2d4a9336087d3df109aaefc959d77697089ed7d0c847da92459bfa7f8cf4508e6b97cb04ff3138cfd59e267ac895f13b773d95fe07403299845555f8026cede2077769b89c741e0271ed16ef4ffc9ef03e6571b799ac6c8d4b2186abc4d4520d359c84a5965a6fb9bd0685e7b888492742a0c6de2dda51b7326bcf1a9f3880fdac8bbe96df003c0692bc95b93a604765920d605ec347f1ad88fdb947810fb95c13ae8381405db67be9d19caad99cf318f6b3eea339fb5117ab5bac9c3fd1a047282408b7c20728db0c10449d84d66ff01a8426fc36ac7e676f8f81f65dfe033d5fd5dad6344e42acd762261208b8f064186bb9025e4c50220a4d19a9b6900f64b5f7e76ee1aa73b48d595e159e360746946161d7db055efec5c410387fa014c28624ba4b1222534198f464069cbf21aed65c2517981026c08be4db39e9dd8dd22966e738121a5eb69d916298f78b225b0146aeb9866b9d7c46e86baa43090fb13adb266c9125973822ad1a7204469a4eab11c3e18e5938f73af1bdb32ac116196d67a207aa9619929145bf5221e4cd608734bf9be8bd40beb0fcd33a0211dd3a5208c744f53d24b3bb4db36282f42a65bcfb2eac1fb924b6e22518c125efb32588fa269a2cefcf22fcf56c59a67981f573af7d88b5942485023f6811db2b34a26f77da695d971c58d604ae0a41f44faedb32c09364159ac2da2b9f9655d70ded6d58475f8a673e7d6a61c45945a17028cac9f91ad3fe4e558f92b8f81e1be9db8207be89506df14ff8c1138619a9d27d7b9a6dad5bc76146a20a0e93596e1c879253063b57ec98f2600e55979a5a92b87636f7715c57f300c528ff7c080c1bbb01d84dc9d3cb61e72e7534a1ef40adad0e6957f34de6dcba6b25df5476886d7d1a1d722b24d57025ca45934aaf346a45ed00d8299afa595d10ab24aa4eb0b873cf947f252417792cf5f5ab94070c686725995c89491846ae0d5e04cf9ca7216df04bbf3a4620bb9debb45d64214f849989a3d48fcb54341bc40e8b00bc6483a5adad3cbd7be83bfc14fc00855eeb0a2d9cc5924d9e6d087f8bd1eb2b2593fe62782f9846f29630a4f9832dfc4"+ "'", var26.equals("6e0ec15519f49c14b2678e69e83e2f89752364f8cf423fe8dd0da0d80906fcf1b7d0033d9229629ea05bb3538790e2becc86c6c6d6f5905f456249e960c31976e40b30434184793b045c3beeb61bd73fd87d81a88607ea30916215f78ee73c7abaeb029031929aaba154e908ecf1789fe0da51976d6d484756ebb22437871ff936a82c2de213a8cfdec2d4a9336087d3df109aaefc959d77697089ed7d0c847da92459bfa7f8cf4508e6b97cb04ff3138cfd59e267ac895f13b773d95fe07403299845555f8026cede2077769b89c741e0271ed16ef4ffc9ef03e6571b799ac6c8d4b2186abc4d4520d359c84a5965a6fb9bd0685e7b888492742a0c6de2dda51b7326bcf1a9f3880fdac8bbe96df003c0692bc95b93a604765920d605ec347f1ad88fdb947810fb95c13ae8381405db67be9d19caad99cf318f6b3eea339fb5117ab5bac9c3fd1a047282408b7c20728db0c10449d84d66ff01a8426fc36ac7e676f8f81f65dfe033d5fd5dad6344e42acd762261208b8f064186bb9025e4c50220a4d19a9b6900f64b5f7e76ee1aa73b48d595e159e360746946161d7db055efec5c410387fa014c28624ba4b1222534198f464069cbf21aed65c2517981026c08be4db39e9dd8dd22966e738121a5eb69d916298f78b225b0146aeb9866b9d7c46e86baa43090fb13adb266c9125973822ad1a7204469a4eab11c3e18e5938f73af1bdb32ac116196d67a207aa9619929145bf5221e4cd608734bf9be8bd40beb0fcd33a0211dd3a5208c744f53d24b3bb4db36282f42a65bcfb2eac1fb924b6e22518c125efb32588fa269a2cefcf22fcf56c59a67981f573af7d88b5942485023f6811db2b34a26f77da695d971c58d604ae0a41f44faedb32c09364159ac2da2b9f9655d70ded6d58475f8a673e7d6a61c45945a17028cac9f91ad3fe4e558f92b8f81e1be9db8207be89506df14ff8c1138619a9d27d7b9a6dad5bc76146a20a0e93596e1c879253063b57ec98f2600e55979a5a92b87636f7715c57f300c528ff7c080c1bbb01d84dc9d3cb61e72e7534a1ef40adad0e6957f34de6dcba6b25df5476886d7d1a1d722b24d57025ca45934aaf346a45ed00d8299afa595d10ab24aa4eb0b873cf947f252417792cf5f5ab94070c686725995c89491846ae0d5e04cf9ca7216df04bbf3a4620bb9debb45d64214f849989a3d48fcb54341bc40e8b00bc6483a5adad3cbd7be83bfc14fc00855eeb0a2d9cc5924d9e6d087f8bd1eb2b2593fe62782f9846f29630a4f9832dfc4"));
// 
//   }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test479"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1498, 1877);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2811746);

  }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test480"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getStandardDeviation();
//     double[] var3 = var0.sample(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
//     org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
//     org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
//     boolean var12 = var4.equals((java.lang.Object)var5);
//     var4.addElement(20.696514663540924d);
//     double var16 = var4.substituteMostRecentElement((-1.84544373783414d));
//     java.lang.Object var17 = null;
//     boolean var18 = var4.equals(var17);
//     org.apache.commons.math3.util.ResizableDoubleArray var19 = var4.copy();
//     var4.addElement(6.621888603197341d);
//     double var23 = var4.addElementRolling((-2.0073159449835396d));
//     var4.addElement(0.006810169557843756d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.discardFrontElements(21505315);
//       fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
//     } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 20.696514663540924d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.1513912519005733d);
// 
//   }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test481"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.7474130412035596d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test482"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.39600327557751386d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.922610031243484d);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test483"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(2811746, 36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 36);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test484"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.4128411121633297d, (java.lang.Number)0.0f, (java.lang.Number)3.2359311173302077d);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getLo();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var3.getContext();
    java.lang.Number var7 = var3.getHi();
    java.lang.Number var8 = var3.getLo();
    java.lang.Number var9 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.0f+ "'", var4.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.0f+ "'", var5.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 3.2359311173302077d+ "'", var7.equals(3.2359311173302077d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0.0f+ "'", var8.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 3.2359311173302077d+ "'", var9.equals(3.2359311173302077d));

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test485"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.5813337955550733d, (java.lang.Number)(-0.9207106114151957d), true);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test486"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)4.724327703255943d);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test487"); }


    double[] var3 = new double[] { 0.0d, (-1.0d), 0.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.contract();
    float var6 = var4.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    boolean var9 = var4.equals((java.lang.Object)0.9999997887160175d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.discardFrontElements(657);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test488"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var13 = var10.nextSecureLong((-1L), 1L);
//     double var16 = var10.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var18 = var10.nextHexString(10);
//     int var21 = var10.nextPascal(8899, 0.8219866295031046d);
//     double var23 = var10.nextExponential(0.010050505059049992d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var25 = var24.getStandardDeviation();
//     double[] var27 = var24.sample(1);
//     double var28 = var24.getMean();
//     double[] var30 = var24.sample(100);
//     double var31 = var24.sample();
//     double var32 = var24.sample();
//     double var33 = var24.getStandardDeviation();
//     double var34 = var24.sample();
//     double var35 = var10.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     double var36 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var39 = var0.nextZipf(1592, (-1.6937792675979062d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.994538944472676d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "764766a95b1d8b6f78f04bd78310fef9d08434bc9f31c93e5becd247aeae71ad32c022e90e6db82626760ef6e60c0ae6607a"+ "'", var8.equals("764766a95b1d8b6f78f04bd78310fef9d08434bc9f31c93e5becd247aeae71ad32c022e90e6db82626760ef6e60c0ae6607a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 12.77726186852492d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "73fd50cadf"+ "'", var18.equals("73fd50cadf"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1972);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.02554926648824727d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == (-1.9835340566324058d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == (-1.5651344482362706d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1.5448253892762047d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == (-1.061644268864778d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == (-0.4713944781945842d));
// 
//   }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test489"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var4 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    double[] var9 = new double[] { (-1.0d), (-1.0d), (-1.0d)};
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    double var11 = var0.mannWhitneyU(var4, var9);
    double[] var12 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    double[] var14 = var13.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    var16.addElement(2.0216852347077916d);
    org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var20 = var19.getStandardDeviation();
    double[] var22 = var19.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    org.apache.commons.math3.exception.util.Localizable var24 = null;
    org.apache.commons.math3.exception.util.Localizable var25 = null;
    org.apache.commons.math3.exception.util.Localizable var26 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var27 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var28 = new org.apache.commons.math3.exception.NullArgumentException(var26, (java.lang.Object[])var27);
    org.apache.commons.math3.exception.MathInternalError var29 = new org.apache.commons.math3.exception.MathInternalError(var25, (java.lang.Object[])var27);
    org.apache.commons.math3.exception.NullArgumentException var30 = new org.apache.commons.math3.exception.NullArgumentException(var24, (java.lang.Object[])var27);
    boolean var31 = var23.equals((java.lang.Object)var24);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var16, var23);
    int var33 = var16.start();
    org.apache.commons.math3.distribution.NormalDistribution var34 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var35 = var34.getStandardDeviation();
    double[] var37 = var34.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray(var37);
    org.apache.commons.math3.exception.util.Localizable var39 = null;
    org.apache.commons.math3.exception.util.Localizable var40 = null;
    org.apache.commons.math3.exception.util.Localizable var41 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var42 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var43 = new org.apache.commons.math3.exception.NullArgumentException(var41, (java.lang.Object[])var42);
    org.apache.commons.math3.exception.MathInternalError var44 = new org.apache.commons.math3.exception.MathInternalError(var40, (java.lang.Object[])var42);
    org.apache.commons.math3.exception.NullArgumentException var45 = new org.apache.commons.math3.exception.NullArgumentException(var39, (java.lang.Object[])var42);
    boolean var46 = var38.equals((java.lang.Object)var39);
    var38.setElement(8899, 2.3930658372149933d);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var16, var38);
    org.apache.commons.math3.util.ResizableDoubleArray var51 = new org.apache.commons.math3.util.ResizableDoubleArray();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var16, var51);
    double[] var53 = var51.getInternalValues();
    double var54 = var0.mannWhitneyU(var14, var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 4.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 24.0d);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test490"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.579251212010101d);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test491"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var1.contract();
    int var3 = var1.start();
    float var4 = var1.getContractionCriteria();
    double var6 = var1.addElementRolling(1.5558638081327447d);
    int var7 = var1.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test492"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-1L), 1L);
//     double var6 = var0.nextGamma(1.4128411121633297d, 7.138332483316814d);
//     java.lang.String var8 = var0.nextSecureHexString(100);
//     int var11 = var0.nextZipf(5, 0.8273572477024794d);
//     int var14 = var0.nextBinomial(1972, 0.15795521463156686d);
//     var0.reSeed();
//     var0.reSeedSecure(0L);
//     long var20 = var0.nextLong((-2L), 760L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var0.nextZipf(136, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.946727149492546d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "2cf8cc55c687f464ba4e7346323bf8035c3588dc9e2cd1dd57ed51f638ea4ead1f09307e00507831959760ea6a3daaaa1aef"+ "'", var8.equals("2cf8cc55c687f464ba4e7346323bf8035c3588dc9e2cd1dd57ed51f638ea4ead1f09307e00507831959760ea6a3daaaa1aef"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 307);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 140L);
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test493"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getNumericalVariance();
    double var2 = var0.getNumericalMean();
    boolean var3 = var0.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test494"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, 9099);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test495"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    double[] var3 = var0.sample(1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var8);
    boolean var12 = var4.equals((java.lang.Object)var5);
    var4.discardMostRecentElements(1);
    var4.contract();
    var4.setElement(17018, 0.14608902069952245d);
    int var19 = var4.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 17019);

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test496"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getSupportUpperBound();
//     double[] var3 = var0.sample(10);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     double var6 = var4.addElementRolling(0.15264401491200186d);
//     float var7 = var4.getContractionCriteria();
//     float var8 = var4.getExpansionFactor();
//     var4.contract();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var4.getElement(1859);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0099251541382068d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.0f);
// 
//   }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test497"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(2.287123383678145E-108d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3104251711043777E-106d);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test498"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin((-0.6110343852803757d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6573666282510751d));

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test499"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getSupportUpperBound();
//     double[] var3 = var0.sample(10);
//     double var4 = var0.getStandardDeviation();
//     double var5 = var0.sample();
//     double var7 = var0.cumulativeProbability(6.621888603197341d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.10765691634932728d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9999999999822681d);
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test500"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(18944L, 1600L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 64L);

  }

}
