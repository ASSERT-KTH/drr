
import junit.framework.*;

public class RandoopTest14 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test1"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.8999371873429769d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test2"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(0.5337363865076407d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5088287629662838d);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test3"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-109L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 109L);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test4"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.16599575158125085d, 3.0420504515947533d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.004241267305219026d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test5"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.9012179477612883d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6206554562035534d);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test6"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, (-38937600));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test7"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-1L), 7053352210170117173L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7053352210170117173L));

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test8"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1024, (-89L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test9"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.9999636981980967d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7181831517216737d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test10"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, 7081.058387126132d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.9E-324d);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test11"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 322.6634991267262d);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test12"); }


    float var2 = org.apache.commons.math3.util.FastMath.max((-1.0f), 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test13"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    double[] var4 = var2.getInternalValues();
    int var5 = var2.getNumElements();
    var2.setExpansionFactor(1.0000002f);
    var2.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test14"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(10.000000000000002d, 0.7135399484934067d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0d);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test15"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(230399);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test16"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-7053352210166488372L), 89L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 89L);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test17"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.027110981284700568d);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test18"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.19240232444172617d, 3.206744283698114d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1924023244417262d);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test19"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-1), 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test20"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(7053352210166488372L, 90L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test21"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(1.0609874103075077d, 2.5288560012036268E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-178.80337105853584d));

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test22"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(5365208890106504284L, 10L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test23"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(3628800L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3628799L);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test24"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(90L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test25"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.5406667711979235d, (java.lang.Number)0.02755458954302434d, false);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.02755458954302434d+ "'", var5.equals(0.02755458954302434d));

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test26"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-790794752), (-790794752));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test27"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.1581263863353843d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test28"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.2405277990690968d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1137898361311693d);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test29"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)5365208890106504175L, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test30"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(byte)0);
    java.lang.Number var3 = var2.getMin();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var2.getContext();
    boolean var5 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test31"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 11700);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test32"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)1.0920257253823424d, (java.lang.Number)1.941575758241476d);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test33"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.0d, 1.5692474232144973d, 2.97848141639784d);
    double var5 = var3.cumulativeProbability(1.271554272071574d);
    boolean var6 = var3.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5686929365266755d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test34"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var8 = var3.cumulativeProbability((-0.5063656411097587d), 1.941575758241476d);
    boolean var9 = var3.isSupportUpperBoundInclusive();
    double var10 = var3.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.14022847040561234d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.NEGATIVE_INFINITY);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test35"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.5688379597558102d, (-11800));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test36"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(4.2837146740488246d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test37"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.0d, 1.5692474232144973d, 2.97848141639784d);
    double var5 = var3.probability(3.291334404149745E-22d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test38"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var10 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var8, var10);
    java.lang.Throwable[] var12 = var11.getSuppressed();
    boolean var13 = var7.equals((java.lang.Object)var12);
    var7.clear();
    int var15 = var7.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test39"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(3.775826473201856d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.440892098500626E-16d);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test40"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(7053352210166488372L, (-89L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7053352210166488461L);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test41"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.5876916151719559d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.587691615171956d);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test42"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.16515071930214034d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1795708894155936d);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test43"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     boolean var4 = var3.isSupportConnected();
//     double var5 = var3.sample();
//     double var6 = var3.sample();
//     double var7 = var3.getStandardDeviation();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.786206932555255d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.0503838303319295d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.8623188722876839d);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test44"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.15719982251077522d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.15719982251077524d);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test45"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(1.0832618148996653d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test46"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var5 = var4.getNumElements();
    int var6 = var4.start();
    double var8 = var4.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    java.lang.Object[] var12 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var10, var12);
    java.lang.Throwable[] var14 = var13.getSuppressed();
    boolean var15 = var9.equals((java.lang.Object)var14);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.util.Localizable var17 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var21 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)7081.058387126132d, (java.lang.Number)2.8720980175938546d, true);
    org.apache.commons.math3.exception.util.Localizable var22 = null;
    org.apache.commons.math3.exception.util.Localizable var23 = null;
    org.apache.commons.math3.exception.util.Localizable var24 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var28 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var24, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
    java.lang.Throwable[] var29 = var28.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var30 = new org.apache.commons.math3.exception.NullArgumentException(var23, (java.lang.Object[])var29);
    org.apache.commons.math3.exception.MathIllegalStateException var31 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var21, var22, (java.lang.Object[])var29);
    java.lang.Throwable[] var32 = var21.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var33 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var17, (java.lang.Object[])var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test47"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(1.1749646538763177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3054246841316648d);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test48"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(4.0503838303319295d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5940382078117772d);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test49"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(100.5f, 7.569397550458789d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.49999f);

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test50"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.7853981633974483d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test51"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    int var7 = var2.getNumElements();
    var2.setNumElements(100);
    var2.clear();
    org.apache.commons.math3.exception.MaxCountExceededException var12 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1.0d);
    boolean var13 = var2.equals((java.lang.Object)var12);
    java.lang.String var14 = var12.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (1) exceeded"+ "'", var14.equals("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (1) exceeded"));

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test52"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.9302363507574447d, 1.941575758241476d, 0.6681363173166157d);
    double var4 = var3.getSupportLowerBound();
    var3.reseedRandomGenerator(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test53"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.7612753675628248d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9130907135554012d);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test54"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(1.5940382078117772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0421799961679745d);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test55"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.02217385702297738d);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test56"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1.2927045528110097d), (java.lang.Number)0.3537192987804616d, false);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test57"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(0L, (-109L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-109L));

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test58"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0f, 2.0000005f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0000005f);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test59"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.57212646691672d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6506783754890693d);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test60"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.626074551533144d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.391676680244186d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test61"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(100.49999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test62"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.5974167300266131d);

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test63"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)3.8588468880340976d);
//     java.lang.String var3 = var2.toString();
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test64"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var2 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    java.lang.Throwable[] var3 = var2.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var4 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    java.lang.Throwable[] var6 = var4.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test65"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.9998872123077203d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5403972100018254d);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test66"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var2.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.discardFrontElements((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test67"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(3.621276550532239d, (-55.70390359439574d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 55.821487972904926d);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test68"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(3.8146973E-6f, (-1024.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.8146973E-6f);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test69"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.999566810927082d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 57.27095960747293d);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test70"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.02217385702297738d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 31.999299353646105d);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test71"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)6.264555748619563d);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test72"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getNumericalVariance();
    double[] var8 = var3.sample(100);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test73"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    boolean var5 = var3.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test74"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(3.2544789518188435d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8486933916311794d);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test75"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 7053352210170117173L);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test76"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-1L), (-7053352210170117161L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7053352210170117160L);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test77"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//     double[] var5 = new double[] { 100.0d, 1.0d};
//     var2.addElements(var5);
//     var2.discardFrontElements(0);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     double var14 = var12.probability(7.569397550458789d);
//     double[] var16 = var12.sample(100);
//     var2.addElements(var16);
//     double var19 = var2.getElement(100);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.8329046427950961d);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test78"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0f, 100.50001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.50001f);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test79"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.0012207031f), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.001220703f));

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test80"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos((-0.48346953277414534d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 77.83267480140304d);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test81"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(100L, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test82"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (1) exceeded");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test83"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(10.000000000000002d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 572.9577951308233d);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test84"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.9992336791296752d, 0.6681363173166157d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5122902731082906d);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test85"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.21992050508887218d, 7.253658542162704E-25d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.253658542162704E-25d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test86"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(10L, (-7053352210166488372L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7053352210166488382L);

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test87"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var4 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var2, (java.lang.Number)(byte)100);
//     org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
//     java.lang.Object[] var6 = new java.lang.Object[] { var4};
//     org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var1, var6);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var6);
//     java.lang.String var9 = var8.toString();
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test88"); }


    java.math.BigInteger var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, (-109L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test89"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(1.1287147879181489E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-11.391845835350601d));

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test90"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-0.5545968900472659d), 0.9997833820018625d, 0.6506783754890694d);
//     double var4 = var3.sample();
//     double var5 = var3.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1.4679968058288457d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.999566810927082d);
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test91"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(91);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionMode((-38937600));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test92"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-0.04527916949109096d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test93"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(1024);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6078.211884750058d);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test94"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(1.2405277990690968d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.09606344810817058d));

  }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test95"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-178.80337105853584d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test96"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.9997833820018625d, 1.4397096014569957d);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test97"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-0.5902737038068222d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.797982492819634d));

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test98"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(1.1458509338674643d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.352454744646058d);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test99"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(77.83267480140304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.0477497738691754d);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test100"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.9998017900254869d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9998017900254869d);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test101"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var4 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var2, (java.lang.Number)(byte)100);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    java.lang.Number var6 = var4.getArgument();
    java.lang.Throwable[] var7 = var4.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (byte)100+ "'", var6.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test102"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.2544789518188435d, (java.lang.Number)0.9168407258198261d, true);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test103"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(11700, 918);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test104"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-0.05422572066892015d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 17.771303091670074d);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test105"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-1024), 11700);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10676);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test106"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(49.999996f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 49.999996f);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test107"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-0.05422572066892015d), (-0.18834749242221216d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.18834749242221216d));

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test108"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(4.283475365339624d, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test109"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var2 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.02217385702297738d);
    java.lang.Throwable[] var3 = var2.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var4 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test110"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.0000004f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test111"); }


    float var2 = org.apache.commons.math3.util.FastMath.max((-1024.0f), 100.50001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.50001f);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test112"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0, (-790794752));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test113"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    boolean var6 = var3.isSupportConnected();
    double var8 = var3.probability((-0.3827413742969658d));
    double var9 = var3.getStandardDeviation();
    double var10 = var3.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.8623188722876839d);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test114"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.9012179477612883d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9012179477612883d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test115"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.626074551533144d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6240607507268253d);

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test116"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma((-1.4308317753439705d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test117"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(1.0136684045930817d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.605250524310484d);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test118"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(3628799L, 7053352210170117173L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7053352210173745972L);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test119"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(49.999996f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 50);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test120"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var2, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var9.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test121"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.addElement(0.8414709848078965d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardFrontElements(900);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test122"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(3.4959757017900213d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.979340558083069d);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test123"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-0.42028468248206136d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.551115123125783E-17d);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test124"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin((-0.09606344810817058d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0962118136149154d));

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test125"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-11800), 102912.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test126"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var9 = var8.getNumElements();
    double[] var10 = var8.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var8);
    var2.setExpansionMode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test127"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(900, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.384006317093086E134d);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test128"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 7053352210173745972L);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test129"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getNumericalVariance();
    double var7 = var3.getNumericalMean();
    var3.reseedRandomGenerator(10L);
    double var10 = var3.getSupportUpperBound();
    double var11 = var3.getMean();
    double var12 = var3.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.6517813881497876d);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test130"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(273112767, 0.0f, 0.0f, 1024);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test131"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.0d, 1.5692474232144973d, 2.97848141639784d);
//     double var4 = var3.sample();
//     boolean var5 = var3.isSupportConnected();
//     double var7 = var3.cumulativeProbability(0.013046161355485517d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.030466191178101454d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.2646959702629905d);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test132"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(byte)(-1));
    java.lang.Number var3 = var2.getMin();
    java.lang.Number var4 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)(-1)+ "'", var4.equals((byte)(-1)));

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test133"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-0.5063656411097587d), 1.2825498340254315d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.3788909453815261d);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test134"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, (-0.41926361214787744d), 2.60986327741734d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test135"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(49.999996f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test136"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(10, 11700);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test137"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(5365208890106504284L, 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5365208890106504293L);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test138"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    var2.setNumElements(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var2.getElement(273112767);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test139"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin((-0.5452181278046861d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5766492970787104d));

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test140"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    int var9 = var2.getExpansionMode();
    double var11 = var2.getElement(0);
    int var12 = var2.getNumElements();
    int var13 = var2.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test141"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)0.018584553336844337d, (java.lang.Number)(-0.1090955663635007d));
    java.lang.Number var5 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.018584553336844337d+ "'", var5.equals(0.018584553336844337d));

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test142"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Number var5 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var7 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var3, (java.lang.Number)5.889694544886073d, var5, true);
    java.lang.Throwable[] var8 = var7.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)0.00824820856234747d, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test143"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.0000005f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test144"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0L, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test145"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(2.0514491238515675d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test146"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-12.39925184518796d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-710.4247998490684d));

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test147"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    java.lang.Object var7 = null;
    boolean var8 = var2.equals(var7);
    double[] var9 = var2.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test148"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.8938555297316175d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.015600722030974793d);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test149"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var2.setContractionCriteria(100.0f);
    float var10 = var2.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 100.0f);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test150"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.0d, 0.7377840776591889d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7377840776591889d);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test151"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(99);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 359.1342053695755d);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test152"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.clear();

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test153"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 0.00390625f, 10.0f, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

//  public void test154() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest14.test154"); }
//
//
//    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//    int var3 = var2.getNumElements();
//    int var4 = var2.start();
//    double var6 = var2.addElementRolling(0.8414709848078965d);
//    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
//    int var8 = var7.getExpansionMode();
//    int var9 = var7.getNumElements();
//    org.apache.commons.math3.distribution.NormalDistribution var13 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//    boolean var14 = var13.isSupportUpperBoundInclusive();
//    boolean var15 = var7.equals((java.lang.Object)var13);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      double[] var17 = var13.sample(273111867);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var3 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var4 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var6 == 0.0d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var8 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var9 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var14 == false);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var15 == false);
//
//  }
//
  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test155"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.0d, 1.5557770183873325d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test156"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.8407359138160451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9169165249988928d);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test157"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var6, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, var8);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var1.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var1.getContext();
    java.lang.Throwable[] var14 = var1.getSuppressed();
    java.lang.Throwable[] var15 = var1.getSuppressed();
    java.lang.Number var16 = var1.getMax();
    java.lang.Number var17 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (-1.0d)+ "'", var16.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + (-1.0d)+ "'", var17.equals((-1.0d)));

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test158"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.4688789649850351d, 0.3537192987804616d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.4688789649850351d);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test159"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-0.5233859003736966d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test160"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(149.30261776898763d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.6058222619154248d);

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test161"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, (-1.102254256986782d), 0.05843257187382863d, 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test162"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.12929424722150962d, 0.882621046799009d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.16438459091985308d);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test163"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.8238753788547079d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6793826243077218d);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test164"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-0.2727601369496029d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.551115123125783E-17d);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test165"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.8362251408024012d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6702689865751268d);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test166"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.6156490123256325d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7846330431008068d);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test167"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test168"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.45830303092382607d, 1.352454744646058d, 0.3657996034532164d, (-11700));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test169"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.5876916151719559d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5313200555680436d);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test170"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var9 = var8.getNumElements();
    double[] var10 = var8.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var8);
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    java.lang.Object[] var16 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var17 = new org.apache.commons.math3.exception.NullArgumentException(var14, var16);
    org.apache.commons.math3.exception.MaxCountExceededException var18 = new org.apache.commons.math3.exception.MaxCountExceededException(var12, (java.lang.Number)0.7435938375035029d, var16);
    boolean var19 = var8.equals((java.lang.Object)var16);
    double var21 = var8.addElementRolling(1.271554272071574d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test171"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.2642564124929525d, (java.lang.Number)2.1932800507380157d, false);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test172"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-1024), 918);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-106));

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test173"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(12.289172084189628d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 12.0d);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test174"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (1) exceeded");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test175"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     double var4 = var2.sample();
//     double var6 = var2.inverseCumulativeProbability(0.7435938375035029d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.30312444178518694d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.12505535487388142d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.5469194654642722d);
// 
//   }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test176"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.013046901568216447d, (-1.2927045528110097d), 0.2879144371105764d, 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test177"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.discardFrontElements(0);
    var2.addElement(0.8085085755675573d);
    var2.setElement(11700, 0.9169165249988928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test178"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NotPositiveException var4 = new org.apache.commons.math3.exception.NotPositiveException(var2, (java.lang.Number)0.976508918599899d);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test179"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(1.5044728995807433d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5044728995807433d);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test180"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (1.645) exceeded");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test181"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.0d, 1.9450663976980598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0d));

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test182"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-0.5711267724381359d), (java.lang.Number)0.004241267305219026d, true);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var7, var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test183"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    int var2 = var1.getExpansionMode();
    var1.discardFrontElements(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test184"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)2.9202368677790993d, var2, true);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test185"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     double var4 = var3.getSupportUpperBound();
//     double var5 = var3.getStandardDeviation();
//     double var6 = var3.sample();
//     double var7 = var3.getNumericalMean();
//     boolean var8 = var3.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.8623188722876839d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.838543669559908d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.8720980175938546d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test186"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-7053352210170117161L), 7053352210166488461L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7053352210170117161L));

  }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test187"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var3 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0, (java.lang.Number)5.551115123125783E-17d, var3);
//     java.lang.Number var5 = var4.getLo();
//     java.lang.Number var6 = var4.getArgument();
//     java.lang.Throwable var7 = null;
//     var4.addSuppressed(var7);
// 
//   }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test188"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-7053352210170117161L), 7053352210170117161L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7053352210170117161L));

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test189"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(1.0920257253823424d, 0.5406667711979235d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.32199715256667094d));

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test190"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.5044728995807433d, (java.lang.Number)1.734723475976807E-18d, (java.lang.Number)1.4596347826973801d);
    java.lang.Number var5 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.734723475976807E-18d+ "'", var5.equals(1.734723475976807E-18d));

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test191"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1024, 900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test192"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3.1868873092888728d, (java.lang.Number)(-0.5260760501008375d), (java.lang.Number)0.010927062287200275d);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test193"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(2.074594310659796d, (-178.80337105853584d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.129990516500412d);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test194"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.5313200555680436d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8621389868659827d);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test195"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(11700, 918);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 596700);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test196"); }


    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 1.0000002f, 10.0f);
    int var4 = var3.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var7.setExpansionMode(0);
    double[] var10 = var7.getInternalValues();
    var7.clear();
    double var13 = var7.addElementRolling(0.7853981633974483d);
    var7.addElement(0.0d);
    var7.setNumElements(100);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = var7.copy();
    var18.setExpansionMode(0);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var18);
    float var22 = var18.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 10.0f);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test197"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.6418208263327543d, (java.lang.Number)(-0.48346953277414534d), true);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NotPositiveException var6 = new org.apache.commons.math3.exception.NotPositiveException(var4, (java.lang.Number)0.6552836562919295d);
    var3.addSuppressed((java.lang.Throwable)var6);
    java.lang.Number var8 = var6.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0+ "'", var8.equals(0));

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test198"); }
// 
// 
//     org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     java.lang.Object[] var5 = new java.lang.Object[] { 100.0d};
//     org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var3, var5);
//     org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, var5);
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var13 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.2544789518188435d, (java.lang.Number)0.9168407258198261d, true);
//     java.lang.Throwable[] var14 = var13.getSuppressed();
//     org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var9, (java.lang.Object[])var14);
//     org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var8, (java.lang.Object[])var14);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test199"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)7.569397550458789d, (java.lang.Number)0.9999636981980967d, false);
    java.lang.Number var5 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.9999636981980967d+ "'", var5.equals(0.9999636981980967d));

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test200"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(918, (-1024));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test201"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(918, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test202"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var9 = var8.getNumElements();
    double[] var10 = var8.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var2.substituteMostRecentElement((-0.019286515134173187d));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test203"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.lang.Object[] var11 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var9, var11);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var8, var11);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var11);
    org.apache.commons.math3.exception.MaxCountExceededException var15 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)100L, var11);
    org.apache.commons.math3.exception.MathArithmeticException var16 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var11);
    org.apache.commons.math3.exception.util.ExceptionContext var17 = var16.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test204"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(5365208890106504284L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5365208890106504284L);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test205"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.0000004f, 2.0000005f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000004f);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test206"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.24434410597703024d);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test207"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(3.1757334232496706d, 4.333449949606716E-4d, 0.19240232444172617d);
//     double var5 = var3.probability(2.461644881538276d);
//     double[] var7 = var3.sample(91);
//     double var8 = var3.sample();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var3.cumulativeProbability(1.252472486418605d, (-0.019286515134173187d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.1756736937283376d);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test208"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.3833801651474136d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.3833801651474136d);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test209"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1023.7781831699072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1024L);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test210"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var5, var7);
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    java.lang.Object[] var14 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var12, var14);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var10, var11, var14);
    var8.addSuppressed((java.lang.Throwable)var16);
    java.lang.Throwable[] var18 = var8.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var19 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)1.8142035178418503E-11d, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalArgumentException var20 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathInternalError var21 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathInternalError var22 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test211"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    java.lang.Throwable[] var2 = var1.getSuppressed();
    java.lang.Number var3 = var1.getMax();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var1.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (-1.0d)+ "'", var3.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test212"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var4 = new org.apache.commons.math3.exception.NullArgumentException(var1, var3);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test213"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.9998140209319779d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.999814020931978d);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test214"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-2996224), 900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2995324));

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test215"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(100L, 7053352210170117173L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test216"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.24191996538778948d, 149.30261776898763d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2419199653877895d);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test217"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    var2.setNumElements(100);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var2.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var13.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var18 = var17.getNumElements();
    double[] var19 = var17.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setExpansionMode((-18));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test218"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    double[] var2 = var1.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setContractionCriteria(3.8146973E-6f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test219"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(7053352210170117173L, 7053352210166488461L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 852815195628176645L);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test220"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-11800), (-9));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test221"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(5.051925868811929E-4d, 1.1287147879181489E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5484577758343545d);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test222"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(2.7181831517216737d, 1.0421799961679745d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.8352841548829635d);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test223"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("org.apache.commons.math3.exception.OutOfRangeException: 273,111,867 out of [0.775, 100] range");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test224"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.9999663392570808d), (java.lang.Number)0.5683852532105546d, false);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test225"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(3.2913344041497453E-22d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.2913344041497453E-22d);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test226"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(1L, 1688143320063612998L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test227"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.4511708924835962d, (java.lang.Number)1.5692474232144973d);
    java.lang.Number var4 = var3.getHi();
    java.lang.Number var5 = var3.getHi();
    java.lang.Number var6 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.5692474232144973d+ "'", var4.equals(1.5692474232144973d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.5692474232144973d+ "'", var5.equals(1.5692474232144973d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1.5692474232144973d+ "'", var6.equals(1.5692474232144973d));

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test228"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    var2.contract();
    var2.setExpansionMode(0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionFactor((-1023.99994f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test229"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-2996224), (-38937600));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2996224));

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test230"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.00744881699401668d, (java.lang.Number)12.289172084189628d, (java.lang.Number)2.786206932555255d);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test231"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-11800), 89L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test232"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "org.apache.commons.math3.exception.NumberIsTooLargeException: -1 is larger than the maximum (0)");
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test233"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(10676, 1024);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test234"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    int var9 = var2.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    var2.addElements(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test235"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Number var5 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var7 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var3, (java.lang.Number)5.889694544886073d, var5, true);
    java.lang.Throwable[] var8 = var7.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)0.00824820856234747d, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test236"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.006601438076270229d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.006601390129882352d);

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test237"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     double var4 = var3.getSupportUpperBound();
//     double var5 = var3.sample();
//     double var8 = var3.cumulativeProbability(0.0d, 8.865319877078154d);
//     double var9 = var3.getSupportUpperBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 4.0635474896971004d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9995668109270821d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test238"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.5683852532105546d);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test239"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-7053352210170117162L), (-7053352210170117173L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7053352210170117162L));

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test240"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getNumericalVariance();
    boolean var5 = var3.isSupportUpperBoundInclusive();
    double var6 = var3.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.8623188722876839d);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test241"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    int var7 = var2.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var2.getElement(273111867);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test242"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    java.lang.Number var6 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1.1555386051171055d+ "'", var6.equals(1.1555386051171055d));

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test243"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var6.setExpansionMode(0);
    double[] var9 = var6.getInternalValues();
    var2.addElements(var9);
    double var12 = var2.substituteMostRecentElement(0.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var2.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.discardFrontElements(1024);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test244"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(9L, (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-9L));

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test245"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.4968061604740894d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test246"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-18));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test247"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)2.7270454965758133d);
//     java.lang.String var3 = var2.toString();
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test248"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)7081.058387126132d, (java.lang.Number)7.5812308201226335d, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test249"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.00390625f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.00390625f);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test250"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(12.805823557727937d, 0.6418208263327543d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 12.805823557727937d);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test251"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1688143320063612998L, (-9L));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test252"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setContractionCriteria(50.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test253"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(2.1034815175839263d, 0.5313200555680436d, (-0.5063656411097588d), (-2995324));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test254"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(15.055514259581079d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 862.6174254730244d);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test255"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.4511708924835962d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6716925580081978d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test256"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1.7952220558689955d));

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test257"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(49.999992f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.8146973E-6f);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test258"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    java.lang.Object var7 = null;
    boolean var8 = var2.equals(var7);
    float var9 = var2.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setNumElements((-11800));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.5f);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test259"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.6552836562919295d, 0.5784066910357114d, 0.9169165249988928d, 230400);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.41324411876669853d);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test260"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-9), 49.999992f, 3.8146973E-6f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test261"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(7053352210173745972L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7053352210173745972L);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test262"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getSupportUpperBound();
    boolean var8 = var3.isSupportUpperBoundInclusive();
    boolean var9 = var3.isSupportConnected();
    double var10 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.POSITIVE_INFINITY);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test263"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(4.2837146740488246d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6318205360130218d);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test264"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var5 = new org.apache.commons.math3.exception.NullArgumentException(var2, var4);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test265"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.6702689865751268d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test266"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(125.3172711493569d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test267"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
    boolean var5 = var4.getBoundIsAllowed();
    boolean var6 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test268"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    var2.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var12.setExpansionMode(0);
    double[] var15 = var12.getInternalValues();
    var12.clear();
    double var18 = var12.addElementRolling(0.7853981633974483d);
    var12.addElement(0.0d);
    var12.setNumElements(100);
    boolean var23 = var2.equals((java.lang.Object)var12);
    var12.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test269"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(9216, 273112767);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 273112767);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test270"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(7053352210166488461L, (-7053352210170117173L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test271"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.6418208263327543d, 3.4959757017900213d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.5544029147833944d);

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test272"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportUpperBoundInclusive();
//     double var5 = var2.getNumericalMean();
//     double var7 = var2.cumulativeProbability(0.12929424722150962d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.4703674872106343d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.19240232444172617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.4878373115376495d);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test273"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(230382, 1024);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test274"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(3.1757334232496706d, 4.333449949606716E-4d, 0.19240232444172617d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var5 = var3.sample((-13));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test275"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-0.48346953277414534d), 0.0d, 1.5688379597558102d, 99);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test276"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.8948703487679698d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2056786128374779d);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test277"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(125.31727114935688d, (-0.5766492970787104d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.5852168431488374d));

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test278"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var8 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var4, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var3, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathArithmeticException var13 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test279"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.5974167300266131d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5625085270457088d);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test280"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double var6 = var2.addElementRolling(0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.getElement(918);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test281"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(7053352210170117160L, (-109L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7053352210170117160L);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test282"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0f, 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024.0f);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test283"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.8206943562278073d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9362542790790519d);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test284"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.1137898361311693d, (java.lang.Number)(-10.0f), true);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test285"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.6905778852975565d, (-0.30312444178518694d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test286"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.00744881699401668d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.007448885876987263d);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test287"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     double var4 = var3.getSupportUpperBound();
//     double var5 = var3.getStandardDeviation();
//     double var6 = var3.sample();
//     boolean var7 = var3.isSupportUpperBoundInclusive();
//     double var8 = var3.getSupportUpperBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.8623188722876839d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.3853990145785264d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test288"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    float var7 = var2.getExpansionFactor();
    org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var12 = var11.getSupportUpperBound();
    double var13 = var11.getStandardDeviation();
    boolean var14 = var11.isSupportConnected();
    var11.reseedRandomGenerator(5365208890106504175L);
    boolean var17 = var2.equals((java.lang.Object)5365208890106504175L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionMode((-8));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test289"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(230382, (-18));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test290"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(5.99074437799629E40d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 94.58676657484448d);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test291"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(10676, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test292"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.9015803832466946d, (-1.124844303657884d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.4659281796594947d);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test293"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    var2.setNumElements(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionMode(230399);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test294"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.9997833820018625d);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test295"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(2.97848141639784d, 2.898427889626753d, 0.0d, (-11700));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test296"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-9), (-2995324));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 26957916);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test297"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    int var9 = var2.getExpansionMode();
    var2.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test298"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2.0000005f, 596700);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test299"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp((-100.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.6293945E-6f);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test300"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.28094010967218624d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 23.685506069683402d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test301"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos((-0.5711267724381359d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.1786741975448787d);

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test302"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var3 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0, (java.lang.Number)5.551115123125783E-17d, var3);
//     java.lang.Number var5 = var4.getLo();
//     java.lang.Number var6 = var4.getArgument();
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.MaxCountExceededException var12 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
//     java.lang.Throwable[] var13 = var12.getSuppressed();
//     org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var10, (java.lang.Object[])var13);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var9, (java.lang.Object[])var13);
//     org.apache.commons.math3.exception.NullArgumentException var16 = new org.apache.commons.math3.exception.NullArgumentException(var8, (java.lang.Object[])var13);
//     org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var7, (java.lang.Object[])var13);
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test303"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(1024, 2995200);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test304"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-7053352210166488372L), (-9));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test305"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-106), 102912.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test306"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(37.281124735952304d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test307"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.4596347826973801d, (java.lang.Number)1.6449340767586613d, false);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    java.lang.Object[] var13 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var11, var13);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var9, var10, var13);
    org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, var13);
    java.lang.Throwable[] var17 = var16.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var18 = new org.apache.commons.math3.exception.MaxCountExceededException(var5, var6, (java.lang.Object[])var17);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test308"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)5.421010862427522E-20d);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test309"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.015017753780066721d, (java.lang.Number)1.9634526771778158d, false);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.015017753780066721d+ "'", var4.equals(0.015017753780066721d));

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test310"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-90L), (java.lang.Number)7053352210170117173L, (java.lang.Number)(-0.1090955663635007d));

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test311"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)7.569397550458789d);
    java.lang.Throwable[] var3 = var2.getSuppressed();
    java.lang.Number var4 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 7.569397550458789d+ "'", var4.equals(7.569397550458789d));

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test312"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    boolean var6 = var4.getBoundIsAllowed();
    java.lang.Number var7 = var4.getArgument();
    java.lang.Number var8 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0.3581288330251856d+ "'", var7.equals(0.3581288330251856d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 1.1555386051171055d+ "'", var8.equals(1.1555386051171055d));

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test313"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-2.2464654344892634d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test314"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    var2.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var12.setExpansionMode(0);
    double[] var15 = var12.getInternalValues();
    var12.clear();
    double var18 = var12.addElementRolling(0.7853981633974483d);
    var12.addElement(0.0d);
    var12.setNumElements(100);
    boolean var23 = var2.equals((java.lang.Object)var12);
    org.apache.commons.math3.util.ResizableDoubleArray var24 = var12.copy();
    var24.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var24.discardFrontElements((-2995324));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test315"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getNumericalVariance();
    boolean var5 = var3.isSupportUpperBoundInclusive();
    boolean var6 = var3.isSupportLowerBoundInclusive();
    double var7 = var3.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.7435938375035028d);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test316"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var3 = new org.apache.commons.math3.exception.NullArgumentException(var0, var2);
    org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var7, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, var9);
    var3.addSuppressed((java.lang.Throwable)var11);
    java.lang.Throwable[] var13 = var3.getSuppressed();
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    java.lang.Number var17 = null;
    org.apache.commons.math3.exception.OutOfRangeException var18 = new org.apache.commons.math3.exception.OutOfRangeException(var14, (java.lang.Number)0, (java.lang.Number)5.551115123125783E-17d, var17);
    java.lang.Number var19 = var18.getLo();
    java.lang.Number var20 = var18.getArgument();
    var3.addSuppressed((java.lang.Throwable)var18);
    java.lang.Number var22 = var18.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + 5.551115123125783E-17d+ "'", var19.equals(5.551115123125783E-17d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + 0+ "'", var20.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + 5.551115123125783E-17d+ "'", var22.equals(5.551115123125783E-17d));

  }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test317"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     double var5 = var2.density(0.5403023093369417d);
//     double var8 = var2.cumulativeProbability(0.6552836562919295d, 0.976508918599899d);
//     double var9 = var2.getNumericalVariance();
//     double var11 = var2.density(0.6240607507268253d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4.546206686076679d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.1900536393062961d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0591178080680944d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4.283475365339624d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.18861061650520586d);
// 
//   }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test318"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var4, var6);
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    java.lang.Object[] var13 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var11, var13);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var9, var10, var13);
    var7.addSuppressed((java.lang.Throwable)var15);
    java.lang.Throwable[] var17 = var7.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var18 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)1.8142035178418503E-11d, (java.lang.Object[])var17);
    org.apache.commons.math3.exception.MathIllegalArgumentException var19 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var17);
    org.apache.commons.math3.exception.MathIllegalArgumentException var20 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test319"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(8.639495877295877E-5d, 0.6841730320232351d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2627647432735111E-4d);

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test320"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 3.8588468880340976d, (-178.80337105853584d), 1024);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test321"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)4.333449949606716E-4d);

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test322"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     double var5 = var2.density(0.5403023093369417d);
//     double var8 = var2.cumulativeProbability(0.6552836562919295d, 0.976508918599899d);
//     boolean var9 = var2.isSupportUpperBoundInclusive();
//     boolean var10 = var2.isSupportUpperBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-3.134001866812653d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.1900536393062961d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0591178080680944d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test323"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(3.0590220060195755E23d, 0.3707647883932746d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.0590220060195755E23d);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test324"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    var3.reseedRandomGenerator(0L);
    boolean var8 = var3.isSupportLowerBoundInclusive();
    double var10 = var3.cumulativeProbability(2.2683541557421067d);
    double var11 = var3.getMean();
    double var12 = var3.getNumericalMean();
    var3.reseedRandomGenerator(1024L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.24191996538778948d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.8720980175938546d);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test325"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(1.0136684045930817d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.196403081179957d);

  }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test326"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     double var4 = var3.getSupportUpperBound();
//     double var5 = var3.getStandardDeviation();
//     double var6 = var3.sample();
//     double var7 = var3.getStandardDeviation();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.8623188722876839d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.4991609099582168d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.8623188722876839d);
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test327"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-8), 10676);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test328"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.3707647883932745d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.36232835927344437d);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test329"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(2995200);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.167079296748007E7d);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test330"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.3537192987804616d);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test331"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.addElement(0.8414709848078965d);
    float var9 = var2.getContractionCriteria();
    float var10 = var2.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 100.0f);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test332"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    int var9 = var2.getExpansionMode();
    double var11 = var2.getElement(0);
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var15 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var18 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var19 = null;
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    java.lang.Object[] var22 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var23 = new org.apache.commons.math3.exception.NullArgumentException(var20, var22);
    org.apache.commons.math3.exception.MathIllegalStateException var24 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var18, var19, var22);
    org.apache.commons.math3.exception.MathIllegalStateException var25 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var15, var16, var22);
    org.apache.commons.math3.exception.MaxCountExceededException var26 = new org.apache.commons.math3.exception.MaxCountExceededException(var12, (java.lang.Number)100L, var22);
    boolean var27 = var2.equals((java.lang.Object)var12);
    org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var33 = new double[] { 100.0d, 1.0d};
    var30.addElements(var33);
    var30.addElement(0.8414709848078965d);
    double[] var37 = var30.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray(var37);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var38);
    float var40 = var38.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 100.0f);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test333"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    int var7 = var2.getExpansionMode();
    float var8 = var2.getExpansionFactor();
    double[] var9 = var2.getElements();
    float var10 = var2.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 100.5f);

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test334"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     double var5 = var2.density(0.5403023093369417d);
//     boolean var6 = var2.isSupportLowerBoundInclusive();
//     boolean var7 = var2.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1.8626521886396386d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.1900536393062961d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test335"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(273112767, 3.8146973E-6f, 0.0f, (-2996224));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test336"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)2.9202368677790993d, var3, true);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test337"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
//     double var5 = var3.probability(7.569397550458789d);
//     double var8 = var3.cumulativeProbability((-0.5063656411097587d), 1.941575758241476d);
//     boolean var9 = var3.isSupportUpperBoundInclusive();
//     double[] var11 = var3.sample(230400);
//     double var13 = var3.cumulativeProbability(0.05349598516132738d);
//     double var14 = var3.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.14022847040561234d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5.403460554103678E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.9846316069267722d);
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test338"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getInternalValues();
    int var7 = var2.getNumElements();
    var2.setNumElements(100);
    var2.clear();
    org.apache.commons.math3.exception.MaxCountExceededException var12 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1.0d);
    boolean var13 = var2.equals((java.lang.Object)var12);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test339"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "org.apache.commons.math3.exception.OutOfRangeException: 273,111,867 out of [0.775, 100] range");
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test340"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double var8 = var2.addElementRolling(0.7853981633974483d);
    var2.addElement(0.0d);
    var2.setNumElements(100);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var2.copy();
    var2.setNumElements(2995200);
    int var16 = var2.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test341"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(2.6287023951487374d, 2.771636402099583d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.14293400695084557d));

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test342"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, 0.7853981633974483d, 0.0d, 230382);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test343"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-12.39925184518796d), 32.936098519779875d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-12.399251845187958d));

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test344"); }


    float var2 = org.apache.commons.math3.util.FastMath.min((-0.001220703f), 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.001220703f));

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test345"); }


    java.math.BigInteger var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, (-38937600));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test346"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.32462331036466185d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.33061344291916195d);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test347"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, 0.5784066910357114d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test348"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.0000004f, 2.47588E29f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000004f);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test349"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.010927062287200275d, 0.8999371873429769d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8999371873429769d);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test350"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.004824124867400347d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.06945592031929565d);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test351"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.discardFrontElements(0);
    org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var14 = var12.probability(7.569397550458789d);
    double[] var16 = var12.sample(100);
    var2.addElements(var16);
    int var18 = var2.start();
    var2.discardFrontElements(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test352"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)3.291334404149745E-22d);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test353"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)7053352210173745972L, (java.lang.Number)13.151476732942367d, true);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test354"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(10, (-1024));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test355"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial((-13));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test356"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-0.41926361214787744d), (-3.134001866812653d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.1619218329453496d);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test357"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(0, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test358"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin((-0.5902737038068222d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6313978754826817d));

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test359"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    var3.reseedRandomGenerator(0L);
    double var9 = var3.cumulativeProbability(0.0d);
    double var10 = var3.getNumericalVariance();
    double var11 = var3.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4.3318907109302085E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == Double.NEGATIVE_INFINITY);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test360"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var2.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    var7.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test361"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(102912.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 16);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test362"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1024), (-106));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test363"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     double var5 = var2.density(0.5403023093369417d);
//     double var8 = var2.cumulativeProbability(0.6552836562919295d, 0.976508918599899d);
//     boolean var9 = var2.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.2384108106405465d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.1900536393062961d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0591178080680944d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test364"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    var2.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var12.setExpansionMode(0);
    double[] var15 = var12.getInternalValues();
    var12.clear();
    double var18 = var12.addElementRolling(0.7853981633974483d);
    var12.addElement(0.0d);
    var12.setNumElements(100);
    boolean var23 = var2.equals((java.lang.Object)var12);
    var12.addElement(5.397570075115222E-22d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test365"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    var2.contract();
    var2.setExpansionMode(0);
    float var12 = var2.getContractionCriteria();
    int var13 = var2.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 100.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test366"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(26957916, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 26957916);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test367"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(50.0f, 2.47588E29f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.47588E29f);

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test368"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded");
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test369"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, (-100L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test370"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1.102254256986782d));

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test371"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(918);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5349.107332595178d);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test372"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    double[] var8 = var7.getInternalValues();
    var7.addElement(1.5692474232144973d);
    int var11 = var7.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test373"); }


    java.math.BigInteger var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, (-18));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test374"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(7053352210170117161L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test375"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-13), (-2996224));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-13));

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test376"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(273112767, (-18));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test377"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1024.0f, 100.50001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024.0f);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test378"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(11700, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test379"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    var2.setElement(10, 0.7612753675628248d);
    var2.discardFrontElements(0);
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.NotPositiveException var12 = new org.apache.commons.math3.exception.NotPositiveException(var10, (java.lang.Number)(byte)0);
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var15 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var13, (java.lang.Number)(-3.1735994179935405d));
    var12.addSuppressed((java.lang.Throwable)var15);
    boolean var17 = var2.equals((java.lang.Object)var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test380"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-790794752));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test381"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-89L), 852815195628176645L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test382"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.1122111167200628d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.11221111672006279d));

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test383"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-0.011211302394241729d), (java.lang.Number)0.5683852532105547d, (java.lang.Number)13.151476732942367d);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test384"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-1.215363133481191d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test385"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-8), 100.0f, 49.999996f, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test386"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.00390625f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.00390625f);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test387"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.02756156531860343d, 0.008248395617409584d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.02756156531860343d);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test388"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var2.setContractionCriteria(100.0f);
    var2.contract();
    int var11 = var2.getNumElements();
    var2.setExpansionMode(0);
    var2.contract();
    int var15 = var2.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setElement((-13), (-55.70390359439574d));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test389"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.7135399484934067d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7945379304806328d);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test390"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-7053352210170117083L), 7053352210166488382L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2605573555328993815L));

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test391"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    var2.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var12.setExpansionMode(0);
    double[] var15 = var12.getInternalValues();
    var12.clear();
    double var18 = var12.addElementRolling(0.7853981633974483d);
    var12.addElement(0.0d);
    var12.setNumElements(100);
    boolean var23 = var2.equals((java.lang.Object)var12);
    var2.setContractionCriteria(102912.0f);
    int var26 = var2.getExpansionMode();
    double var28 = var2.addElementRolling(0.5406667711979235d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test392"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(7053352210166488382L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test393"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.7377840776591889d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.29677036567728765d);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test394"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.49027106946002635d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4880911896481078d);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test395"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, 2.0000005f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test396"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.0000002f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000002f);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test397"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(1.5940382078117772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test398"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow((-0.3655932269839443d), (-1.5852168431488374d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test399"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.2405277990690968d, (-13));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5143161609730186E-4d);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test400"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    var2.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var12.setExpansionMode(0);
    double[] var15 = var12.getInternalValues();
    var12.clear();
    double var18 = var12.addElementRolling(0.7853981633974483d);
    var12.addElement(0.0d);
    var12.setNumElements(100);
    boolean var23 = var2.equals((java.lang.Object)var12);
    org.apache.commons.math3.util.ResizableDoubleArray var24 = var12.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setContractionCriteria(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test401"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)149.30261776898763d);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test402"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(230399, (-13));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test403"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-89L), (-7053352210170117173L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-89L));

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test404"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(7053352210170117160L, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6221772920507596800L));

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test405"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-0.9987444940634167d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7847700161904468d));

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test406"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var8 = var7.getExpansionMode();
    float var9 = var7.getExpansionFactor();
    var7.setExpansionFactor(100.49999f);
    boolean var13 = var7.equals((java.lang.Object)0.027110981284700568d);
    int var14 = var7.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test407"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getSupportUpperBound();
    double var8 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.POSITIVE_INFINITY);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test408"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.2544789518188435d, (java.lang.Number)0.9168407258198261d, true);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test409"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var2.getTiesStrategy();
//     org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
//     var17.setExpansionMode(0);
//     double[] var20 = var17.getInternalValues();
//     double[] var21 = var17.getInternalValues();
//     java.lang.Object var22 = null;
//     boolean var23 = var17.equals(var22);
//     double[] var24 = var17.getElements();
//     double[] var25 = var2.rank(var24);
// 
//   }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test410"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.5974167300266131d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5151403688607277d));

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test411"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0, (java.lang.Number)5.551115123125783E-17d, var3);
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 5.551115123125783E-17d+ "'", var5.equals(5.551115123125783E-17d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test412"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.1555386051171055d, 0.6702689865751268d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.41596319759314887d);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test413"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.6716925580081978d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 38.48514870421596d);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test414"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    var2.contract();
    var2.setExpansionMode(0);
    var2.contract();
    float var13 = var2.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0f);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test415"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.053470501981572265d, 0.31405481363425186d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.3185741994402654d);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test416"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1024);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test417"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.8230490790621229d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9072205239422898d);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test418"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-1L), 7053352210170117161L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1L));

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test419"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    int var8 = var7.start();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var7.copy();
    double[] var10 = var9.getElements();
    java.lang.Object var11 = null;
    boolean var12 = var9.equals(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test420"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.6418208263327543d, (java.lang.Number)(-0.48346953277414534d), true);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test421"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double[] var7 = var2.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var11 = var10.getNumElements();
    int var12 = var10.start();
    double var14 = var10.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    java.lang.Object[] var18 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var19 = new org.apache.commons.math3.exception.NullArgumentException(var16, var18);
    java.lang.Throwable[] var20 = var19.getSuppressed();
    boolean var21 = var15.equals((java.lang.Object)var20);
    var15.addElement(1.4214549026638725d);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var15);
    org.apache.commons.math3.util.ResizableDoubleArray var25 = var2.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test422"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.00858267380786032d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.00858267380786032d);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test423"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    var3.reseedRandomGenerator(0L);
    boolean var8 = var3.isSupportLowerBoundInclusive();
    double var10 = var3.cumulativeProbability(2.2683541557421067d);
    double var12 = var3.probability(0.8407359138160451d);
    double var13 = var3.getStandardDeviation();
    double var14 = var3.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.24191996538778948d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.8623188722876839d);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test424"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(273112767, (-106));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test425"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.0966104455465058d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test426"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.7756486815267315d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 44.44139583636861d);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test427"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.0591178080680944d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test428"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(3.6936877621208235d, (-5.496154324107173d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3.6936877621208235d));

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test429"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getSupportLowerBound();
    double var8 = var3.cumulativeProbability(8.639495877295877E-5d);
    double var9 = var3.getNumericalVariance();
    double var10 = var3.getNumericalMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var3.cumulativeProbability(1.5469194654642722d, 0.4963483631908118d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 4.333449949606716E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.8720980175938546d);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test430"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    double[] var7 = var2.getElements();
    int var8 = var2.start();
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var13 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var9, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
    java.lang.Throwable[] var14 = var13.getSuppressed();
    boolean var15 = var13.getBoundIsAllowed();
    boolean var16 = var2.equals((java.lang.Object)var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test431"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (1.645) exceeded");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test432"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var2, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test433"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-1.0f), (java.lang.Number)0.7853981633974483d, false);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var9 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)7081.058387126132d, (java.lang.Number)2.8720980175938546d, true);
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     org.apache.commons.math3.exception.util.Localizable var12 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var16 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var12, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
//     java.lang.Throwable[] var17 = var16.getSuppressed();
//     org.apache.commons.math3.exception.NullArgumentException var18 = new org.apache.commons.math3.exception.NullArgumentException(var11, (java.lang.Object[])var17);
//     org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var9, var10, (java.lang.Object[])var17);
//     org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var17);
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test434"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-11800), 11700);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test435"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.discardFrontElements(0);
    var2.addElement(0.8085085755675573d);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = var2.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var12);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test436"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(3.363572562729164d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5268008012035816d);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test437"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(10, 7053352210170117160L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test438"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1024, 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test439"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    double var6 = var2.addElementRolling(0.8414709848078965d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double[] var8 = var7.getInternalValues();
    int var9 = var7.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test440"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-7053352210170117083L), 7053352210173745972L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-4295468319161797071L));

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test441"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardFrontElements(10676);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test442"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(26957916, 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test443"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-7053352210170117162L), 7053352210170117172L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10L);

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test444"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 3.363572562729164d, (-2.74137897748935d), 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test445"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.9127083523155106d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == true);
// 
//   }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test446"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.9565627942373829d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8172154268646284d);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test447"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0) exceeded");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test448"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    var2.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var12.setExpansionMode(0);
    double[] var15 = var12.getInternalValues();
    var12.clear();
    double var18 = var12.addElementRolling(0.7853981633974483d);
    var12.addElement(0.0d);
    var12.setNumElements(100);
    boolean var23 = var2.equals((java.lang.Object)var12);
    int var24 = var2.getNumElements();
    var2.contract();
    var2.addElement(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test449"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var10 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var8, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var7, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var10);
    org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var10);
    org.apache.commons.math3.exception.util.ExceptionContext var16 = var15.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var17 = var15.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var18 = var15.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var19 = var15.getContext();
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var23 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
    org.apache.commons.math3.exception.util.Localizable var24 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var26 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var27 = null;
    org.apache.commons.math3.exception.util.Localizable var28 = null;
    java.lang.Object[] var30 = new java.lang.Object[] { 100.0d};
    org.apache.commons.math3.exception.NullArgumentException var31 = new org.apache.commons.math3.exception.NullArgumentException(var28, var30);
    org.apache.commons.math3.exception.MathIllegalStateException var32 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var26, var27, var30);
    org.apache.commons.math3.exception.MathIllegalStateException var33 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var23, var24, var30);
    org.apache.commons.math3.exception.MathIllegalStateException var34 = new org.apache.commons.math3.exception.MathIllegalStateException(var21, var30);
    org.apache.commons.math3.exception.MathArithmeticException var35 = new org.apache.commons.math3.exception.MathArithmeticException(var20, var30);
    org.apache.commons.math3.exception.util.ExceptionContext var36 = var35.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var37 = var35.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var38 = var35.getContext();
    var15.addSuppressed((java.lang.Throwable)var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test450"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.7756486815267315d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9188014802486864d);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test451"); }


    int var1 = org.apache.commons.math3.util.FastMath.round((-1023.99994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1024));

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test452"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.9015803832466946d, 8.865319956825967d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1013490065056271d);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test453"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.0000002f, 49.999992f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000002f);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test454"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(1.316202817425833d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.316202817425833d);

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test455"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh((-2308.2067090921896d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test456"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(273112767, (-5365208890106504175L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test457"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(9L, (-7053352210170117172L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7053352210170117172L));

  }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test458"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.7840834169173322d, (-0.11221111672006279d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test459"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(230400, 1024);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 231424);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test460"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    var2.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var12.setExpansionMode(0);
    double[] var15 = var12.getInternalValues();
    var12.clear();
    double var18 = var12.addElementRolling(0.7853981633974483d);
    var12.addElement(0.0d);
    var12.setNumElements(100);
    boolean var23 = var2.equals((java.lang.Object)var12);
    org.apache.commons.math3.util.ResizableDoubleArray var24 = var12.copy();
    boolean var26 = var24.equals((java.lang.Object)0.6318205360130218d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test461"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(7053352210166488382L, (-109L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test462"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    var2.setNumElements(1);
    var2.contract();
    var2.setExpansionMode(0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    float var13 = var12.getExpansionFactor();
    int var14 = var12.getNumElements();
    boolean var16 = var12.equals((java.lang.Object)0.7435938375035028d);
    double var18 = var12.substituteMostRecentElement((-0.09606344810817058d));
    double var20 = var12.substituteMostRecentElement(2.653014502388273d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-0.09606344810817058d));

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test463"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getSupportLowerBound();
    double var8 = var3.cumulativeProbability(8.639495877295877E-5d);
    double var9 = var3.getNumericalVariance();
    double var10 = var3.getNumericalMean();
    boolean var11 = var3.isSupportLowerBoundInclusive();
    var3.reseedRandomGenerator(5365208890106504284L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 4.333449949606716E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test464"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.19240232444172617d, 2.069655856740348d);
//     double var3 = var2.sample();
//     double var5 = var2.density(0.5403023093369417d);
//     double var8 = var2.cumulativeProbability(0.6552836562919295d, 0.976508918599899d);
//     boolean var9 = var2.isSupportLowerBoundInclusive();
//     double var12 = var2.cumulativeProbability(0.9022156594299824d, 8.865319877078154d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var14 = var2.sample((-2995324));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.2920628715861329d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.1900536393062961d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0591178080680944d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.3657996034532164d);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test465"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(49.999992f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 49.999992f);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test466"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    int var3 = var2.getNumElements();
    int var4 = var2.start();
    var2.setElement(10, 0.7612753675628248d);
    var2.discardFrontElements(0);
    double var11 = var2.addElementRolling(4.2837146740488246d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test467"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var5 = var3.probability(7.569397550458789d);
    double var6 = var3.getSupportLowerBound();
    double var8 = var3.cumulativeProbability(8.639495877295877E-5d);
    double var9 = var3.getNumericalVariance();
    double var10 = var3.getNumericalMean();
    double var11 = var3.getSupportLowerBound();
    double var12 = var3.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 4.333449949606716E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.7435938375035028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.8720980175938546d);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test468"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(1.196403081179957d, 12.805823557727937d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 14.21986053821574d);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test469"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.9443504370351304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.016482024418910425d);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test470"); }


    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)100.0f, (java.lang.Number)0.5337363865076407d, var2);
    java.lang.Number var4 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test471"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    boolean var6 = var3.isSupportConnected();
    boolean var7 = var3.isSupportLowerBoundInclusive();
    double var8 = var3.getMean();
    var3.reseedRandomGenerator(10L);
    double var11 = var3.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == Double.NEGATIVE_INFINITY);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test472"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.3581288330251856d, (java.lang.Number)1.1555386051171055d, false);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    boolean var6 = var4.getBoundIsAllowed();
    java.lang.Number var7 = var4.getMax();
    java.lang.Number var8 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1.1555386051171055d+ "'", var7.equals(1.1555386051171055d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0.3581288330251856d+ "'", var8.equals(0.3581288330251856d));

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test473"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.0789454099597753d, (java.lang.Number)0.9995668109270821d, (java.lang.Number)0.05094568456366692d);
    java.lang.Number var4 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.05094568456366692d+ "'", var4.equals(0.05094568456366692d));

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test474"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.2475312893420674d, (java.lang.Number)3.0698672482364424d, false);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test475"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.9022156594299824d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7173750019934241d);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test476"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(3.432443690009129E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test477"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.857430970394393d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.357097455574727d);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test478"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(7053352210166488372L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test479"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 50.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test480"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    boolean var6 = var3.isSupportConnected();
    boolean var7 = var3.isSupportLowerBoundInclusive();
    double var8 = var3.getMean();
    var3.reseedRandomGenerator(10L);
    double var11 = var3.getStandardDeviation();
    double[] var13 = var3.sample(900);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.8720980175938546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test481"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     java.lang.Number var4 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var2, (java.lang.Number)5.889694544886073d, var4, true);
//     java.lang.Throwable[] var7 = var6.getSuppressed();
//     org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.00824820856234747d, (java.lang.Object[])var7);
//     java.lang.Throwable[] var9 = var8.getSuppressed();
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.MaxCountExceededException var12 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
//     org.apache.commons.math3.exception.util.Localizable var13 = null;
//     org.apache.commons.math3.exception.MaxCountExceededException var15 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1));
//     org.apache.commons.math3.exception.util.Localizable var16 = null;
//     org.apache.commons.math3.exception.util.Localizable var17 = null;
//     java.lang.Object[] var19 = new java.lang.Object[] { 100.0d};
//     org.apache.commons.math3.exception.NullArgumentException var20 = new org.apache.commons.math3.exception.NullArgumentException(var17, var19);
//     org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var15, var16, var19);
//     org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var12, var13, var19);
//     org.apache.commons.math3.exception.util.ExceptionContext var23 = var12.getContext();
//     org.apache.commons.math3.exception.util.ExceptionContext var24 = var12.getContext();
//     java.lang.Throwable[] var25 = var12.getSuppressed();
//     java.lang.Throwable[] var26 = var12.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var27 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var10, (java.lang.Object[])var26);
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test482"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(0, 10676);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10676);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test483"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-11800), (-0.001220703f), 1.0000004f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test484"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.542826101286539d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test485"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.0000001f, (-1023.99994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000001f);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test486"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-38937600));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test487"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    float var7 = var2.getExpansionFactor();
    org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var12 = var11.getSupportUpperBound();
    double var13 = var11.getStandardDeviation();
    boolean var14 = var11.isSupportConnected();
    var11.reseedRandomGenerator(5365208890106504175L);
    boolean var17 = var2.equals((java.lang.Object)5365208890106504175L);
    double var19 = var2.addElementRolling(0.031084834136888246d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardMostRecentElements(1024);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 100.0d);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test488"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var2.copy();
    float var4 = var3.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var7.setExpansionMode(0);
    double[] var10 = var7.getInternalValues();
    double[] var11 = var7.getInternalValues();
    var7.addElement(0.6506783754890694d);
    int var14 = var7.getNumElements();
    double var16 = var7.addElementRolling(2.8720980175938546d);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.6506783754890694d);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test489"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)7053352210170117173L, (java.lang.Number)0, true);

  }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest14.test490"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(3.2544789518188435d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test491"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    double[] var5 = new double[] { 100.0d, 1.0d};
    var2.addElements(var5);
    int var7 = var2.getExpansionMode();
    float var8 = var2.getExpansionFactor();
    var2.setNumElements(0);
    double var12 = var2.addElementRolling(7.253658542162704E-25d);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var2.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var13.getElement((-11700));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test492"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(93.72989180803069d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5601277765479946d);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test493"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.32462331036466185d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.281128124954561d);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test494"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-6.680216650916437d), 1.4567813447268017d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6.680216650916437d));

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test495"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NotPositiveException var3 = new org.apache.commons.math3.exception.NotPositiveException(var1, (java.lang.Number)7.569397550458789d);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test496"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8720980175938546d, 0.8623188722876839d, 0.9150123793192297d);
    double var4 = var3.getSupportUpperBound();
    double var5 = var3.getStandardDeviation();
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getSupportUpperBound();
    double var8 = var3.getNumericalMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var10 = var3.sample((-2996224));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.8720980175938546d);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test497"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1, 100.0f);
    var2.setExpansionMode(0);
    double[] var5 = var2.getInternalValues();
    var2.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var2.copy();
    double[] var8 = var7.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    var9.setElement(596700, 0.5683852532105546d);
    float var14 = var9.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0f);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test498"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-11800), (-2996224));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-11800));

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test499"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.3581288330251856d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.4459607124434285d));

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest14.test500"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.21992050508887218d, 3.2913344041497453E-22d, 0.0591178080680944d, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

}
