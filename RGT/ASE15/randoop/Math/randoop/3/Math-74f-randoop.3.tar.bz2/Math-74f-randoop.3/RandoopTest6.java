
import junit.framework.*;

public class RandoopTest6 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test1"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(0L);
    org.apache.commons.math.fraction.BigFractionField var2 = var1.getField();
    double var4 = var1.pow(0.0d);
    org.apache.commons.math.fraction.BigFraction var5 = var1.negate();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigDecimal var8 = var5.bigDecimalValue(0, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test2"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(100, 100);
    java.math.BigInteger var3 = var2.getDenominator();
    byte var4 = var2.byteValue();
    int var5 = var2.intValue();
    org.apache.commons.math.fraction.BigFraction var7 = new org.apache.commons.math.fraction.BigFraction(1);
    int var8 = var7.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var10 = new org.apache.commons.math.fraction.BigFraction(1);
    int var11 = var10.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var12 = var7.multiply(var10);
    double var14 = var12.pow(10.0d);
    org.apache.commons.math.fraction.BigFraction var16 = var12.pow(0);
    java.math.BigDecimal var17 = var16.bigDecimalValue();
    org.apache.commons.math.fraction.BigFraction var19 = var16.add(0L);
    double var21 = var16.pow(0.2d);
    double var22 = var16.doubleValue();
    org.apache.commons.math.fraction.BigFraction var23 = var2.subtract(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (byte)1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test3"); }


    double[] var7 = new double[] { 100.0d, 100.0d};
    double[] var11 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var12 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var7, var11);
    double[] var18 = new double[] { 100.0d, 100.0d};
    double[] var22 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var23 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var18, var22);
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var24 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(0.0d, 0.0d, var11, var22);
    double[] var33 = new double[] { 100.0d, 100.0d};
    double[] var37 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var38 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var33, var37);
    double[][] var39 = new double[][] { var33};
    double[][] var40 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var39);
    org.apache.commons.math.MaxIterationsExceededException var41 = new org.apache.commons.math.MaxIterationsExceededException(10, "", (java.lang.Object[])var39);
    java.lang.Object[] var42 = var41.getArguments();
    org.apache.commons.math.FunctionEvaluationException var43 = new org.apache.commons.math.FunctionEvaluationException(var22, "", var42);
    org.apache.commons.math.FunctionEvaluationException var44 = new org.apache.commons.math.FunctionEvaluationException(var22);
    org.apache.commons.math.linear.RealMatrix var45 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test4"); }


    double[] var5 = new double[] { 100.0d, 100.0d};
    double[] var9 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var10 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var5, var9);
    double[][] var11 = new double[][] { var5};
    double[][] var12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var11);
    org.apache.commons.math.linear.Array2DRowRealMatrix var13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var11);
    org.apache.commons.math.linear.Array2DRowRealMatrix var15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var11, false);
    double[][] var16 = var15.getData();
    org.apache.commons.math.linear.RealMatrix var17 = var15.copy();
    org.apache.commons.math.linear.RealMatrix var19 = var15.scalarAdd(1.000000000000046d);
    boolean var20 = var15.isSquare();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test5"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(1);
    int var2 = var1.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var4 = new org.apache.commons.math.fraction.BigFraction(1);
    int var5 = var4.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var6 = var1.multiply(var4);
    double var8 = var6.pow(10.0d);
    org.apache.commons.math.fraction.BigFraction var10 = var6.divide(100);
    org.apache.commons.math.fraction.BigFraction var12 = var6.add(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test6"); }


    double[] var5 = new double[] { 100.0d, 100.0d};
    double[] var9 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var10 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var5, var9);
    double var11 = var10.getMaxStep();
    double[] var17 = new double[] { 100.0d, 100.0d};
    double[] var21 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var22 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var17, var21);
    double[][] var23 = new double[][] { var17};
    double[][] var24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var23);
    org.apache.commons.math.linear.Array2DRowRealMatrix var25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var23);
    org.apache.commons.math.linear.Array2DRowRealMatrix var27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var23, false);
    double[][] var28 = var27.getData();
    org.apache.commons.math.linear.Array2DRowRealMatrix var29 = var10.updateHighOrderDerivativesPhase1(var27);
    org.apache.commons.math.linear.RealMatrix var31 = var27.scalarMultiply(0.2d);
    double var32 = var27.getNorm();
    org.apache.commons.math.linear.RealMatrix var34 = var27.getColumnMatrix(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test7"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(0L);
    org.apache.commons.math.fraction.BigFractionField var2 = var1.getField();
    org.apache.commons.math.fraction.BigFraction var3 = var2.getZero();
    long var4 = var3.getDenominatorAsLong();
    org.apache.commons.math.fraction.BigFraction var6 = var3.pow(100L);
    double var7 = var6.percentageValue();
    float var8 = var6.floatValue();
    org.apache.commons.math.fraction.BigFraction var10 = var6.multiply(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test8"); }
// 
// 
//     org.apache.commons.math.ode.events.EventHandler var0 = null;
//     org.apache.commons.math.ode.events.EventState var4 = new org.apache.commons.math.ode.events.EventState(var0, 100.0d, 1.0d, (-1));
//     int var5 = var4.getMaxIterationCount();
//     double var6 = var4.getMaxCheckInterval();
//     double var7 = var4.getEventTime();
//     double[] var14 = new double[] { 100.0d, 100.0d};
//     double[] var18 = new double[] { 100.0d, 1.0d, 10.0d};
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var19 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var14, var18);
//     boolean var20 = var4.reset(0.9d, var14);
//     org.apache.commons.math.ode.events.EventHandler var21 = var4.getEventHandler();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test9"); }


    org.apache.commons.math.linear.BlockRealMatrix var2 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var5 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var6 = var2.multiply(var5);
    int var7 = var6.getColumnDimension();
    double[][] var8 = var6.getData();
    org.apache.commons.math.linear.BlockRealMatrix var9 = var6.transpose();
    int var10 = var6.getColumnDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 8);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test10"); }


    double[] var5 = new double[] { 100.0d, 100.0d};
    double[] var9 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var10 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var5, var9);
    double[][] var11 = new double[][] { var5};
    double[][] var12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var11);
    org.apache.commons.math.linear.Array2DRowRealMatrix var13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var11);
    org.apache.commons.math.linear.Array2DRowRealMatrix var15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var11, false);
    double[][] var16 = var15.getData();
    org.apache.commons.math.linear.RealMatrix var17 = var15.copy();
    double[] var23 = new double[] { 100.0d, 100.0d};
    double[] var27 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var28 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var23, var27);
    double[][] var29 = new double[][] { var23};
    double[][] var30 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var29);
    org.apache.commons.math.linear.Array2DRowRealMatrix var31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var29);
    org.apache.commons.math.linear.Array2DRowRealMatrix var33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var29, false);
    double[][] var34 = var33.getData();
    org.apache.commons.math.linear.RealVector var36 = var33.getColumnVector(0);
    org.apache.commons.math.linear.RealVector var37 = var15.preMultiply(var36);
    double var38 = var15.getNorm();
    double var39 = var15.getNorm();
    org.apache.commons.math.ode.events.EventHandler var40 = null;
    org.apache.commons.math.ode.events.EventState var44 = new org.apache.commons.math.ode.events.EventState(var40, 100.0d, 1.0d, (-1));
    int var45 = var44.getMaxIterationCount();
    double var46 = var44.getConvergence();
    double[] var49 = new double[] { 1.0d};
    org.apache.commons.math.FunctionEvaluationException var50 = new org.apache.commons.math.FunctionEvaluationException(var49);
    double[] var56 = new double[] { 100.0d, 100.0d};
    double[] var60 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var61 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var56, var60);
    org.apache.commons.math.fraction.BigFraction var64 = new org.apache.commons.math.fraction.BigFraction(1);
    org.apache.commons.math.fraction.BigFraction var66 = new org.apache.commons.math.fraction.BigFraction(1);
    int var67 = var66.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var69 = new org.apache.commons.math.fraction.BigFraction(1);
    int var70 = var69.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var71 = var66.multiply(var69);
    org.apache.commons.math.fraction.BigFraction var72 = var64.multiply(var71);
    org.apache.commons.math.FieldElement[] var73 = new org.apache.commons.math.FieldElement[] { var72};
    org.apache.commons.math.linear.Array2DRowFieldMatrix var74 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var73);
    org.apache.commons.math.linear.FieldMatrix var75 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var73);
    org.apache.commons.math.FunctionEvaluationException var76 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var50, var60, "org.apache.commons.math.linear.SingularMatrixException: matrix is singular", (java.lang.Object[])var73);
    boolean var77 = var44.reset(0.2d, var60);
    org.apache.commons.math.linear.BigMatrix var78 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var60);
    org.apache.commons.math.linear.BigMatrix var79 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var60);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var80 = var15.operate(var60);
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test11"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(1);
    org.apache.commons.math.fraction.BigFraction var3 = var1.add((-1L));
    org.apache.commons.math.fraction.BigFractionField var4 = var1.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var5 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var4);
    org.apache.commons.math.fraction.BigFraction var6 = var4.getZero();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test12"); }
// 
// 
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var0 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
//     double var1 = var0.getPreviousTime();
//     var0.rescale(1.0E-15d);
// 
//   }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test13"); }
// 
// 
//     java.math.BigDecimal[] var0 = null;
//     org.apache.commons.math.linear.BigMatrix var1 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var0);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test14"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(0L);
    org.apache.commons.math.fraction.BigFractionField var2 = var1.getField();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var2, 100, 10);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var6 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var2);
    org.apache.commons.math.fraction.BigFraction var7 = var2.getZero();
    org.apache.commons.math.fraction.BigFraction var8 = var2.getZero();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var9 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var2);
    org.apache.commons.math.FieldElement[][] var10 = var9.getData();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test15"); }


    org.apache.commons.math.fraction.FractionConversionException var3 = new org.apache.commons.math.fraction.FractionConversionException(Double.NaN, 102L, 10L);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test16"); }


    double[] var6 = new double[] { 100.0d, 100.0d};
    double[] var10 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var11 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var6, var10);
    double[][] var12 = new double[][] { var6};
    double[][] var13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var12);
    org.apache.commons.math.linear.Array2DRowRealMatrix var15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var13, false);
    double[][] var16 = var15.getDataRef();
    java.util.ConcurrentModificationException var17 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("Array2DRowFieldMatrix{{1}}", (java.lang.Object[])var16);
    java.lang.String[] var21 = new java.lang.String[] { "0"};
    org.apache.commons.math.linear.BigMatrix var22 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var21);
    org.apache.commons.math.linear.BigMatrix var23 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var21);
    java.lang.String[][] var24 = new java.lang.String[][] { var21};
    org.apache.commons.math.linear.BigMatrix var25 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var24);
    org.apache.commons.math.linear.BigMatrix var26 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var24);
    org.apache.commons.math.linear.InvalidMatrixException var27 = new org.apache.commons.math.linear.InvalidMatrixException("org.apache.commons.math.MaxIterationsExceededException: ", (java.lang.Object[])var24);
    org.apache.commons.math.linear.BigMatrix var28 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var24);
    org.apache.commons.math.linear.BigMatrix var29 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var24);
    org.apache.commons.math.linear.BigMatrix var30 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.MathException var31 = new org.apache.commons.math.MathException((java.lang.Throwable)var17, "org.apache.commons.math.ode.events.EventException: ", (java.lang.Object[])var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test17"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(1);
    int var2 = var1.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var4 = new org.apache.commons.math.fraction.BigFraction(1);
    int var5 = var4.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var6 = var1.multiply(var4);
    org.apache.commons.math.fraction.BigFractionField var7 = var4.getField();
    java.math.BigDecimal var8 = var4.bigDecimalValue();
    double var10 = var4.pow(0.0d);
    org.apache.commons.math.fraction.BigFraction var12 = new org.apache.commons.math.fraction.BigFraction(1);
    org.apache.commons.math.fraction.BigFraction var14 = new org.apache.commons.math.fraction.BigFraction(1);
    int var15 = var14.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var17 = new org.apache.commons.math.fraction.BigFraction(1);
    int var18 = var17.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var19 = var14.multiply(var17);
    org.apache.commons.math.fraction.BigFraction var20 = var12.multiply(var19);
    org.apache.commons.math.fraction.BigFraction var22 = new org.apache.commons.math.fraction.BigFraction(0L);
    org.apache.commons.math.fraction.BigFractionField var23 = var22.getField();
    org.apache.commons.math.linear.BlockFieldMatrix var26 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var23, 100, 10);
    org.apache.commons.math.fraction.BigFraction var28 = new org.apache.commons.math.fraction.BigFraction(1);
    org.apache.commons.math.fraction.BigFraction var30 = new org.apache.commons.math.fraction.BigFraction(1);
    int var31 = var30.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var33 = new org.apache.commons.math.fraction.BigFraction(1);
    int var34 = var33.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var35 = var30.multiply(var33);
    org.apache.commons.math.fraction.BigFraction var36 = var28.multiply(var35);
    org.apache.commons.math.FieldElement[] var37 = new org.apache.commons.math.FieldElement[] { var36};
    org.apache.commons.math.linear.Array2DRowFieldMatrix var38 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var37);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var39 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var37);
    org.apache.commons.math.fraction.BigFraction var41 = new org.apache.commons.math.fraction.BigFraction(1);
    int var42 = var41.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var44 = new org.apache.commons.math.fraction.BigFraction(1);
    int var45 = var44.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var46 = var41.multiply(var44);
    org.apache.commons.math.fraction.BigFraction var48 = var46.add(100L);
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var49 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var46);
    org.apache.commons.math.FieldElement var50 = var39.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var49);
    org.apache.commons.math.FieldElement var51 = var26.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var49);
    org.apache.commons.math.fraction.BigFraction var53 = new org.apache.commons.math.fraction.BigFraction(0L);
    org.apache.commons.math.fraction.BigFractionField var54 = var53.getField();
    org.apache.commons.math.linear.BlockFieldMatrix var57 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var54, 100, 10);
    org.apache.commons.math.linear.FieldVector var59 = var57.getRowVector(10);
    org.apache.commons.math.linear.BlockFieldMatrix var60 = var26.subtract(var57);
    org.apache.commons.math.fraction.BigFraction var62 = new org.apache.commons.math.fraction.BigFraction(0L);
    org.apache.commons.math.fraction.BigFractionField var63 = var62.getField();
    org.apache.commons.math.linear.BlockFieldMatrix var66 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var63, 100, 10);
    org.apache.commons.math.fraction.BigFraction var68 = new org.apache.commons.math.fraction.BigFraction(0L);
    org.apache.commons.math.fraction.BigFractionField var69 = var68.getField();
    org.apache.commons.math.linear.FieldMatrix var70 = var66.scalarAdd((org.apache.commons.math.FieldElement)var68);
    org.apache.commons.math.linear.BlockFieldMatrix var71 = var26.add(var66);
    org.apache.commons.math.fraction.BigFraction var75 = new org.apache.commons.math.fraction.BigFraction(1);
    int var76 = var75.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var78 = new org.apache.commons.math.fraction.BigFraction(1);
    int var79 = var78.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var80 = var75.multiply(var78);
    var66.multiplyEntry(100, (-1), (org.apache.commons.math.FieldElement)var78);
    org.apache.commons.math.fraction.BigFraction var82 = var19.subtract(var78);
    org.apache.commons.math.fraction.BigFraction var83 = var4.subtract(var82);
    long var84 = var4.longValue();
    org.apache.commons.math.fraction.BigFractionField var85 = var4.getField();
    org.apache.commons.math.fraction.BigFraction var86 = var85.getOne();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test18"); }


    org.apache.commons.math.MathException var0 = new org.apache.commons.math.MathException();
    double[] var9 = new double[] { 100.0d, 100.0d};
    double[] var13 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var14 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var9, var13);
    double[][] var15 = new double[][] { var9};
    double[][] var16 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var15);
    org.apache.commons.math.MaxIterationsExceededException var17 = new org.apache.commons.math.MaxIterationsExceededException(10, "", (java.lang.Object[])var15);
    org.apache.commons.math.ConvergenceException var18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var0, "Adams-Moulton", (java.lang.Object[])var15);
    org.apache.commons.math.ode.IntegratorException var19 = new org.apache.commons.math.ode.IntegratorException((java.lang.Throwable)var0);
    java.lang.RuntimeException var20 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable)var19);
    org.apache.commons.math.linear.InvalidMatrixException var21 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable)var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test19"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(1);
    int var2 = var1.getNumeratorAsInt();
    java.lang.String var3 = var1.toString();
    float var4 = var1.floatValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "1"+ "'", var3.equals("1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0f);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test20"); }


    java.lang.Object[] var2 = null;
    java.text.ParseException var3 = org.apache.commons.math.MathRuntimeException.createParseException(0, "101", var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test21"); }
// 
// 
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var4 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(Double.NaN, 1.0d, 141.4213562373095d, 0.2d);
//     var4.setMaxGrowth(0.0d);
//     int var7 = var4.getMaxEvaluations();
//     java.util.Collection var8 = var4.getEventHandlers();
//     var4.clearEventHandlers();
//     var4.clearEventHandlers();
//     var4.setMaxGrowth((-900.0d));
//     org.apache.commons.math.ode.FirstOrderDifferentialEquations var13 = null;
//     double[] var15 = null;
//     double[] var22 = new double[] { 100.0d, 100.0d};
//     double[] var26 = new double[] { 100.0d, 1.0d, 10.0d};
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var27 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var22, var26);
//     double var28 = var27.getMaxStep();
//     double[] var34 = new double[] { 100.0d, 100.0d};
//     double[] var38 = new double[] { 100.0d, 1.0d, 10.0d};
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var39 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var34, var38);
//     double[][] var40 = new double[][] { var34};
//     double[][] var41 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var40);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var42 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var40);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var44 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var40, false);
//     double[][] var45 = var44.getData();
//     org.apache.commons.math.linear.Array2DRowRealMatrix var46 = var27.updateHighOrderDerivativesPhase1(var44);
//     org.apache.commons.math.ode.events.CombinedEventsManager var47 = new org.apache.commons.math.ode.events.CombinedEventsManager();
//     java.lang.Throwable var49 = null;
//     java.lang.Object[] var53 = new java.lang.Object[] { '4'};
//     org.apache.commons.math.FunctionEvaluationException var54 = new org.apache.commons.math.FunctionEvaluationException(var49, 0.0d, "hi!", var53);
//     double[] var55 = var54.getArgument();
//     boolean var56 = var47.reset(1.0d, var55);
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var58 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var55, false);
//     double[] var59 = var46.preMultiply(var55);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var55);
//     org.apache.commons.math.linear.RealMatrix var61 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var55);
//     double var62 = var4.integrate(var13, (-900.0d), var15, 101.0d, var55);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test22"); }


    org.apache.commons.math.linear.BlockRealMatrix var2 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var4 = var2.scalarAdd(10.0d);
    double var5 = var2.getFrobeniusNorm();
    org.apache.commons.math.linear.BlockRealMatrix var6 = var2.copy();
    org.apache.commons.math.linear.BlockRealMatrix var9 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var11 = var9.scalarAdd(10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var12 = var11.copy();
    int var13 = var11.getColumnDimension();
    int var14 = var11.getRowDimension();
    org.apache.commons.math.linear.BlockRealMatrix var15 = var6.add((org.apache.commons.math.linear.RealMatrix)var11);
    org.apache.commons.math.linear.BlockRealMatrix var18 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var21 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var22 = var18.multiply(var21);
    org.apache.commons.math.linear.BlockRealMatrix var25 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var28 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var29 = var25.multiply(var28);
    org.apache.commons.math.linear.BlockRealMatrix var30 = var18.multiply(var28);
    org.apache.commons.math.linear.BlockRealMatrix var31 = var30.copy();
    double var32 = var30.getFrobeniusNorm();
    org.apache.commons.math.linear.BlockRealMatrix var35 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var37 = var35.scalarAdd(10.0d);
    double var38 = var35.getFrobeniusNorm();
    org.apache.commons.math.linear.BlockRealMatrix var40 = var35.scalarAdd(1.0E-15d);
    org.apache.commons.math.linear.BlockRealMatrix var41 = var30.subtract(var40);
    org.apache.commons.math.linear.BlockRealMatrix var43 = var40.scalarAdd(0.9d);
    org.apache.commons.math.linear.BlockRealMatrix var44 = var40.transpose();
    org.apache.commons.math.linear.BlockRealMatrix var45 = var44.transpose();
    org.apache.commons.math.linear.BlockRealMatrix var46 = var6.subtract(var44);
    org.apache.commons.math.linear.RealMatrixPreservingVisitor var47 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var52 = var44.walkInOptimizedOrder(var47, 2147483647, (-1), 0, 2147483647);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test23"); }


    double[] var8 = new double[] { 100.0d, 100.0d};
    double[] var12 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var13 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var8, var12);
    double[][] var14 = new double[][] { var8};
    double[][] var15 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var14);
    org.apache.commons.math.linear.Array2DRowRealMatrix var17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var15, false);
    org.apache.commons.math.ode.events.CombinedEventsManager var18 = new org.apache.commons.math.ode.events.CombinedEventsManager();
    java.lang.Throwable var20 = null;
    java.lang.Object[] var24 = new java.lang.Object[] { '4'};
    org.apache.commons.math.FunctionEvaluationException var25 = new org.apache.commons.math.FunctionEvaluationException(var20, 0.0d, "hi!", var24);
    double[] var26 = var25.getArgument();
    boolean var27 = var18.reset(1.0d, var26);
    double[] var34 = new double[] { 100.0d, 100.0d};
    double[] var38 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var39 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var34, var38);
    var18.stepAccepted(0.0d, var34);
    double[] var41 = var17.operate(var34);
    org.apache.commons.math.linear.RealMatrix var42 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var34);
    org.apache.commons.math.linear.RealMatrix var43 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var34);
    org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var44 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
    org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var45 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var44);
    double[] var49 = new double[] { 0.0d};
    org.apache.commons.math.linear.BigMatrix var50 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var49);
    double[] var56 = new double[] { 100.0d, 100.0d};
    double[] var60 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var61 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var56, var60);
    double[][] var62 = new double[][] { var56};
    double[][] var63 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var62);
    org.apache.commons.math.linear.Array2DRowRealMatrix var64 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var62);
    org.apache.commons.math.linear.Array2DRowRealMatrix var66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var62, false);
    double[][] var67 = var66.getData();
    org.apache.commons.math.linear.RealVector var69 = var66.getColumnVector(0);
    org.apache.commons.math.linear.RealMatrix var72 = var66.createMatrix(100, 100);
    var45.reinitialize(1.0E-6d, 0.0d, var49, var66);
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var74 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 6.4E-29d, 1.0E-6d, var34, var49);
    org.apache.commons.math.linear.BigMatrix var75 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test24"); }


    double[] var7 = new double[] { 100.0d, 100.0d};
    double[] var11 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var12 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var7, var11);
    double[] var18 = new double[] { 100.0d, 100.0d};
    double[] var22 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var23 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var18, var22);
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var24 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(0.0d, 0.0d, var11, var22);
    double[] var33 = new double[] { 100.0d, 100.0d};
    double[] var37 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var38 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var33, var37);
    double[][] var39 = new double[][] { var33};
    double[][] var40 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var39);
    org.apache.commons.math.MaxIterationsExceededException var41 = new org.apache.commons.math.MaxIterationsExceededException(10, "", (java.lang.Object[])var39);
    java.lang.Object[] var42 = var41.getArguments();
    org.apache.commons.math.FunctionEvaluationException var43 = new org.apache.commons.math.FunctionEvaluationException(var22, "", var42);
    org.apache.commons.math.MathException var44 = new org.apache.commons.math.MathException((java.lang.Throwable)var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test25"); }


    double[] var7 = new double[] { 100.0d, 100.0d};
    double[] var11 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var12 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var7, var11);
    double[] var18 = new double[] { 100.0d, 100.0d};
    double[] var22 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var23 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var18, var22);
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var24 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(0.0d, 0.0d, var11, var22);
    int var25 = var24.getEvaluations();
    var24.setSafety(0.2d);
    var24.setMinReduction(1.0d);
    double var30 = var24.getMinReduction();
    java.util.Collection var31 = var24.getEventHandlers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test26"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(0L);
    org.apache.commons.math.fraction.BigFractionField var2 = var1.getField();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var2, 100, 10);
    org.apache.commons.math.fraction.BigFraction var7 = new org.apache.commons.math.fraction.BigFraction(1);
    org.apache.commons.math.fraction.BigFraction var9 = new org.apache.commons.math.fraction.BigFraction(1);
    int var10 = var9.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var12 = new org.apache.commons.math.fraction.BigFraction(1);
    int var13 = var12.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var14 = var9.multiply(var12);
    org.apache.commons.math.fraction.BigFraction var15 = var7.multiply(var14);
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var15};
    org.apache.commons.math.linear.Array2DRowFieldMatrix var17 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var16);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var18 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var16);
    org.apache.commons.math.fraction.BigFraction var20 = new org.apache.commons.math.fraction.BigFraction(1);
    int var21 = var20.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var23 = new org.apache.commons.math.fraction.BigFraction(1);
    int var24 = var23.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var25 = var20.multiply(var23);
    org.apache.commons.math.fraction.BigFraction var27 = var25.add(100L);
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var28 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var25);
    org.apache.commons.math.FieldElement var29 = var18.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var28);
    org.apache.commons.math.FieldElement var30 = var5.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var28);
    org.apache.commons.math.fraction.BigFraction var32 = new org.apache.commons.math.fraction.BigFraction(0L);
    org.apache.commons.math.fraction.BigFractionField var33 = var32.getField();
    org.apache.commons.math.linear.BlockFieldMatrix var36 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var33, 100, 10);
    org.apache.commons.math.linear.FieldVector var38 = var36.getRowVector(10);
    org.apache.commons.math.linear.BlockFieldMatrix var39 = var5.subtract(var36);
    org.apache.commons.math.fraction.BigFraction var41 = new org.apache.commons.math.fraction.BigFraction(1);
    org.apache.commons.math.fraction.BigFraction var43 = var41.add((-1L));
    org.apache.commons.math.linear.FieldMatrix var44 = var36.scalarMultiply((org.apache.commons.math.FieldElement)var43);
    java.lang.String var45 = var43.toString();
    org.apache.commons.math.fraction.BigFraction var48 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(100, 100);
    java.math.BigInteger var49 = var48.getDenominator();
    org.apache.commons.math.fraction.BigFraction var50 = var43.subtract(var49);
    org.apache.commons.math.fraction.BigFractionField var51 = var43.getField();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + "0"+ "'", var45.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test27"); }


    org.apache.commons.math.fraction.BigFraction var2 = new org.apache.commons.math.fraction.BigFraction(0L, 10L);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test28"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(0L);
    org.apache.commons.math.fraction.BigFractionField var2 = var1.getField();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var2, 100, 10);
    org.apache.commons.math.fraction.BigFraction var7 = new org.apache.commons.math.fraction.BigFraction(1);
    org.apache.commons.math.fraction.BigFraction var9 = new org.apache.commons.math.fraction.BigFraction(1);
    int var10 = var9.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var12 = new org.apache.commons.math.fraction.BigFraction(1);
    int var13 = var12.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var14 = var9.multiply(var12);
    org.apache.commons.math.fraction.BigFraction var15 = var7.multiply(var14);
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var15};
    org.apache.commons.math.linear.Array2DRowFieldMatrix var17 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var16);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var18 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var16);
    org.apache.commons.math.fraction.BigFraction var20 = new org.apache.commons.math.fraction.BigFraction(1);
    int var21 = var20.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var23 = new org.apache.commons.math.fraction.BigFraction(1);
    int var24 = var23.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var25 = var20.multiply(var23);
    org.apache.commons.math.fraction.BigFraction var27 = var25.add(100L);
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var28 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var25);
    org.apache.commons.math.FieldElement var29 = var18.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var28);
    org.apache.commons.math.FieldElement var30 = var5.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var28);
    org.apache.commons.math.fraction.BigFraction var32 = new org.apache.commons.math.fraction.BigFraction(0L);
    org.apache.commons.math.fraction.BigFractionField var33 = var32.getField();
    org.apache.commons.math.linear.BlockFieldMatrix var36 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var33, 100, 10);
    org.apache.commons.math.linear.FieldVector var38 = var36.getRowVector(10);
    org.apache.commons.math.linear.BlockFieldMatrix var39 = var5.subtract(var36);
    boolean var40 = var39.isSquare();
    java.lang.Object var41 = null;
    boolean var42 = var39.equals(var41);
    org.apache.commons.math.linear.FieldMatrix var45 = var39.createMatrix(8, 10);
    boolean var46 = var39.isSquare();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.FieldMatrix var51 = var39.getSubMatrix(0, 0, 100, 2147483647);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test29"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(0L);
    org.apache.commons.math.fraction.BigFractionField var2 = var1.getField();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var2, 100, 10);
    org.apache.commons.math.fraction.BigFraction var7 = new org.apache.commons.math.fraction.BigFraction(1);
    org.apache.commons.math.fraction.BigFraction var9 = new org.apache.commons.math.fraction.BigFraction(1);
    int var10 = var9.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var12 = new org.apache.commons.math.fraction.BigFraction(1);
    int var13 = var12.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var14 = var9.multiply(var12);
    org.apache.commons.math.fraction.BigFraction var15 = var7.multiply(var14);
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var15};
    org.apache.commons.math.linear.Array2DRowFieldMatrix var17 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var16);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var18 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var16);
    org.apache.commons.math.fraction.BigFraction var20 = new org.apache.commons.math.fraction.BigFraction(1);
    int var21 = var20.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var23 = new org.apache.commons.math.fraction.BigFraction(1);
    int var24 = var23.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var25 = var20.multiply(var23);
    org.apache.commons.math.fraction.BigFraction var27 = var25.add(100L);
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var28 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var25);
    org.apache.commons.math.FieldElement var29 = var18.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var28);
    org.apache.commons.math.FieldElement var30 = var5.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var28);
    boolean var31 = var5.isSquare();
    org.apache.commons.math.fraction.BigFraction var33 = new org.apache.commons.math.fraction.BigFraction(1);
    int var34 = var33.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var36 = new org.apache.commons.math.fraction.BigFraction(1);
    int var37 = var36.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var38 = var33.multiply(var36);
    double var40 = var38.pow(10.0d);
    org.apache.commons.math.fraction.BigFraction var42 = var38.pow(0);
    org.apache.commons.math.fraction.BigFraction var43 = var42.abs();
    org.apache.commons.math.linear.FieldMatrix var44 = var5.scalarMultiply((org.apache.commons.math.FieldElement)var42);
    org.apache.commons.math.fraction.BigFraction var46 = var42.add(10);
    java.lang.String var47 = var42.toString();
    int var48 = var42.getDenominatorAsInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + "1"+ "'", var47.equals("1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test30"); }


    double[] var5 = new double[] { 100.0d, 100.0d};
    double[] var9 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var10 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var5, var9);
    double[][] var11 = new double[][] { var5};
    double[][] var12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var11);
    org.apache.commons.math.linear.Array2DRowRealMatrix var13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var11);
    org.apache.commons.math.linear.Array2DRowRealMatrix var15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var11, false);
    double[][] var16 = var15.getData();
    org.apache.commons.math.linear.RealMatrix var19 = var15.createMatrix(1, 100);
    double[][] var20 = var15.getData();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.RealMatrix var23 = var15.createMatrix(0, 10);
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test31"); }


    org.apache.commons.math.linear.BlockRealMatrix var2 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var5 = var2.createMatrix(2, 100);
    org.apache.commons.math.linear.BlockRealMatrix var7 = var2.getColumnMatrix(0);
    org.apache.commons.math.fraction.BigFraction var9 = new org.apache.commons.math.fraction.BigFraction(1);
    int var10 = var9.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var12 = new org.apache.commons.math.fraction.BigFraction(1);
    int var13 = var12.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var14 = var9.multiply(var12);
    org.apache.commons.math.fraction.BigFractionField var15 = var12.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var16 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var15);
    org.apache.commons.math.linear.FieldLUDecompositionImpl var17 = new org.apache.commons.math.linear.FieldLUDecompositionImpl((org.apache.commons.math.linear.FieldMatrix)var16);
    int[] var18 = var17.getPivot();
    org.apache.commons.math.fraction.BigFraction var20 = new org.apache.commons.math.fraction.BigFraction(1);
    int var21 = var20.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var23 = new org.apache.commons.math.fraction.BigFraction(1);
    int var24 = var23.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var25 = var20.multiply(var23);
    org.apache.commons.math.fraction.BigFractionField var26 = var23.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var27 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var26);
    org.apache.commons.math.linear.FieldLUDecompositionImpl var28 = new org.apache.commons.math.linear.FieldLUDecompositionImpl((org.apache.commons.math.linear.FieldMatrix)var27);
    int[] var29 = var28.getPivot();
    double[] var39 = new double[] { 100.0d, 100.0d};
    double[] var43 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var44 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var39, var43);
    double[][] var45 = new double[][] { var39};
    double[][] var46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var45);
    org.apache.commons.math.MaxIterationsExceededException var47 = new org.apache.commons.math.MaxIterationsExceededException(10, "", (java.lang.Object[])var45);
    org.apache.commons.math.MathException var48 = new org.apache.commons.math.MathException("Array2DRowRealMatrix{{1.0}}", (java.lang.Object[])var45);
    double[][] var49 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var45);
    org.apache.commons.math.MathException var50 = new org.apache.commons.math.MathException("matrix is singular", (java.lang.Object[])var45);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.copySubMatrix(var18, var29, var45);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test32"); }
// 
// 
//     org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(0L);
//     org.apache.commons.math.fraction.BigFractionField var2 = var1.getField();
//     org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var2, 100, 10);
//     org.apache.commons.math.linear.Array2DRowFieldMatrix var6 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var2);
//     org.apache.commons.math.FieldElement[][] var7 = var6.getDataRef();
//     boolean var8 = var6.isSquare();
//     org.apache.commons.math.linear.FieldMatrix var9 = null;
//     org.apache.commons.math.linear.FieldMatrix var10 = var6.preMultiply(var9);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test33"); }


    org.apache.commons.math.linear.BlockRealMatrix var2 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var5 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var6 = var2.multiply(var5);
    org.apache.commons.math.linear.BlockRealMatrix var8 = var5.getRowMatrix(0);
    org.apache.commons.math.linear.BlockRealMatrix var11 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var14 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var15 = var11.multiply(var14);
    org.apache.commons.math.linear.BlockRealMatrix var18 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var21 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var22 = var18.multiply(var21);
    org.apache.commons.math.linear.BlockRealMatrix var23 = var11.multiply(var21);
    org.apache.commons.math.linear.BlockRealMatrix var24 = var23.copy();
    double var25 = var23.getFrobeniusNorm();
    org.apache.commons.math.linear.BlockRealMatrix var28 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var30 = var28.scalarAdd(10.0d);
    double var31 = var28.getFrobeniusNorm();
    org.apache.commons.math.linear.BlockRealMatrix var33 = var28.scalarAdd(1.0E-15d);
    org.apache.commons.math.linear.BlockRealMatrix var34 = var23.subtract(var33);
    org.apache.commons.math.linear.BlockRealMatrix var36 = var33.scalarAdd(0.9d);
    org.apache.commons.math.linear.BlockRealMatrix var37 = var33.copy();
    org.apache.commons.math.linear.BlockRealMatrix var38 = var33.transpose();
    org.apache.commons.math.linear.BlockRealMatrix var39 = var5.subtract(var33);
    boolean var40 = var33.isSingular();
    double var43 = var33.getEntry(0, 0);
    boolean var44 = var33.isSingular();
    org.apache.commons.math.linear.RealMatrix var46 = var33.scalarAdd(1.0E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1.0E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test34"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(1);
    org.apache.commons.math.fraction.BigFraction var3 = new org.apache.commons.math.fraction.BigFraction(1);
    int var4 = var3.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var6 = new org.apache.commons.math.fraction.BigFraction(1);
    int var7 = var6.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var8 = var3.multiply(var6);
    org.apache.commons.math.fraction.BigFraction var9 = var1.multiply(var8);
    org.apache.commons.math.FieldElement[] var10 = new org.apache.commons.math.FieldElement[] { var9};
    org.apache.commons.math.linear.Array2DRowFieldMatrix var11 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var10);
    org.apache.commons.math.fraction.BigFraction var13 = new org.apache.commons.math.fraction.BigFraction(1);
    org.apache.commons.math.fraction.BigFraction var15 = new org.apache.commons.math.fraction.BigFraction(1);
    int var16 = var15.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var18 = new org.apache.commons.math.fraction.BigFraction(1);
    int var19 = var18.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var20 = var15.multiply(var18);
    org.apache.commons.math.fraction.BigFraction var21 = var13.multiply(var20);
    org.apache.commons.math.FieldElement[] var22 = new org.apache.commons.math.FieldElement[] { var21};
    org.apache.commons.math.linear.Array2DRowFieldMatrix var23 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var22);
    org.apache.commons.math.linear.FieldMatrix var24 = var11.add((org.apache.commons.math.linear.FieldMatrix)var23);
    org.apache.commons.math.FieldElement[][] var25 = var23.getDataRef();
    org.apache.commons.math.linear.BlockFieldMatrix var26 = new org.apache.commons.math.linear.BlockFieldMatrix(var25);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var27 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var25);
    org.apache.commons.math.linear.FieldMatrix var28 = var27.transpose();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test35"); }


    double[] var5 = new double[] { 100.0d, 100.0d};
    double[] var9 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var10 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var5, var9);
    double[][] var11 = new double[][] { var5};
    double[][] var12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var11);
    org.apache.commons.math.linear.Array2DRowRealMatrix var13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var11);
    org.apache.commons.math.linear.Array2DRowRealMatrix var15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var11, false);
    double[][] var16 = var15.getData();
    double[][] var17 = var15.getData();
    int var18 = var15.getRowDimension();
    org.apache.commons.math.linear.RealMatrix var20 = var15.scalarMultiply(0.2d);
    org.apache.commons.math.linear.RealMatrix var22 = var15.getColumnMatrix(0);
    int var23 = var15.getRowDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test36"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math.FunctionEvaluationException var2 = new org.apache.commons.math.FunctionEvaluationException(var1);
    double[] var8 = new double[] { 100.0d, 100.0d};
    double[] var12 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var13 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var8, var12);
    org.apache.commons.math.fraction.BigFraction var16 = new org.apache.commons.math.fraction.BigFraction(1);
    org.apache.commons.math.fraction.BigFraction var18 = new org.apache.commons.math.fraction.BigFraction(1);
    int var19 = var18.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var21 = new org.apache.commons.math.fraction.BigFraction(1);
    int var22 = var21.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var23 = var18.multiply(var21);
    org.apache.commons.math.fraction.BigFraction var24 = var16.multiply(var23);
    org.apache.commons.math.FieldElement[] var25 = new org.apache.commons.math.FieldElement[] { var24};
    org.apache.commons.math.linear.Array2DRowFieldMatrix var26 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var25);
    org.apache.commons.math.linear.FieldMatrix var27 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var25);
    org.apache.commons.math.FunctionEvaluationException var28 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var2, var12, "org.apache.commons.math.linear.SingularMatrixException: matrix is singular", (java.lang.Object[])var25);
    org.apache.commons.math.fraction.BigFraction var31 = new org.apache.commons.math.fraction.BigFraction(1);
    org.apache.commons.math.fraction.BigFraction var33 = new org.apache.commons.math.fraction.BigFraction(1);
    int var34 = var33.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var36 = new org.apache.commons.math.fraction.BigFraction(1);
    int var37 = var36.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var38 = var33.multiply(var36);
    org.apache.commons.math.fraction.BigFraction var39 = var31.multiply(var38);
    org.apache.commons.math.FieldElement[] var40 = new org.apache.commons.math.FieldElement[] { var39};
    org.apache.commons.math.linear.Array2DRowFieldMatrix var41 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var40);
    org.apache.commons.math.FieldElement[][] var42 = var41.getData();
    org.apache.commons.math.ConvergenceException var43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var2, "", (java.lang.Object[])var42);
    org.apache.commons.math.linear.BlockFieldMatrix var44 = new org.apache.commons.math.linear.BlockFieldMatrix(var42);
    boolean var45 = var44.isSquare();
    org.apache.commons.math.linear.BlockRealMatrix var48 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var51 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var52 = var48.multiply(var51);
    boolean var53 = var44.equals((java.lang.Object)var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test37"); }


    org.apache.commons.math.linear.BlockRealMatrix var2 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var4 = var2.scalarAdd(10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var5 = var4.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.BlockRealMatrix var7 = var4.getRowMatrix(100);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test38"); }


    org.apache.commons.math.linear.BlockRealMatrix var2 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var5 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var6 = var2.multiply(var5);
    org.apache.commons.math.linear.BlockRealMatrix var9 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var11 = var9.scalarAdd(10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var12 = var5.subtract(var11);
    org.apache.commons.math.linear.RealMatrix var14 = var5.scalarMultiply((-1.0d));
    double[] var24 = new double[] { 100.0d, 100.0d};
    double[] var28 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var29 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var24, var28);
    double[][] var30 = new double[][] { var24};
    double[][] var31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var30);
    org.apache.commons.math.linear.Array2DRowRealMatrix var32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var30);
    org.apache.commons.math.linear.Array2DRowRealMatrix var34 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var30, false);
    double[][] var35 = var34.getData();
    double[][] var36 = var34.getData();
    int var37 = var34.getRowDimension();
    double[] var39 = var34.getRow(0);
    java.lang.Throwable var40 = null;
    java.lang.Object[] var44 = new java.lang.Object[] { '4'};
    org.apache.commons.math.FunctionEvaluationException var45 = new org.apache.commons.math.FunctionEvaluationException(var40, 0.0d, "hi!", var44);
    double[] var46 = var45.getArgument();
    org.apache.commons.math.linear.RealMatrix var47 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var46);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var49 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var46, false);
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var50 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(8, Double.NaN, 101.00000000002143d, var39, var46);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setColumn((-1), var46);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test39"); }


    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var1 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(2);
    org.apache.commons.math.linear.Array2DRowRealMatrix var4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(2, 100);
    org.apache.commons.math.fraction.BigFraction var6 = new org.apache.commons.math.fraction.BigFraction(1);
    org.apache.commons.math.fraction.BigFraction var8 = var6.add((-1L));
    org.apache.commons.math.fraction.BigFractionField var9 = var6.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var10 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var9);
    int var11 = var10.getRowDimension();
    boolean var12 = var4.equals((java.lang.Object)var11);
    org.apache.commons.math.linear.Array2DRowRealMatrix var13 = var1.updateHighOrderDerivativesPhase1(var4);
    double[][] var16 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(0, 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.setSubMatrix(var16, 100, 1);
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test40"); }


    double[] var7 = new double[] { 100.0d, 100.0d};
    double[] var11 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var12 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var7, var11);
    double[] var18 = new double[] { 100.0d, 100.0d};
    double[] var22 = new double[] { 100.0d, 1.0d, 10.0d};
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var23 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 10.0d, 0.0d, var18, var22);
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var24 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(0.0d, 0.0d, var11, var22);
    double var25 = var24.getMaxGrowth();
    double var26 = var24.getMinReduction();
    var24.setSafety(0.0d);
    var24.setSafety(1.0E-14d);
    var24.clearStepHandlers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.2d);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test41"); }


    org.apache.commons.math.linear.BlockRealMatrix var2 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var5 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var6 = var2.multiply(var5);
    var6.multiplyEntry(0, 0, 1.0E-14d);
    org.apache.commons.math.linear.BlockRealMatrix var13 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var16 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var17 = var13.multiply(var16);
    org.apache.commons.math.linear.BlockRealMatrix var20 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var22 = var20.scalarAdd(10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var23 = var16.subtract(var22);
    double[] var25 = var23.getColumn(0);
    org.apache.commons.math.linear.BlockRealMatrix var28 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var31 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var32 = var28.multiply(var31);
    org.apache.commons.math.linear.BlockRealMatrix var35 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var38 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var39 = var35.multiply(var38);
    org.apache.commons.math.linear.BlockRealMatrix var40 = var28.multiply(var38);
    org.apache.commons.math.linear.BlockRealMatrix var41 = var40.copy();
    double var42 = var40.getFrobeniusNorm();
    org.apache.commons.math.linear.BlockRealMatrix var45 = new org.apache.commons.math.linear.BlockRealMatrix(8, 8);
    org.apache.commons.math.linear.BlockRealMatrix var47 = var45.scalarAdd(10.0d);
    double var48 = var45.getFrobeniusNorm();
    org.apache.commons.math.linear.BlockRealMatrix var50 = var45.scalarAdd(1.0E-15d);
    org.apache.commons.math.linear.BlockRealMatrix var51 = var40.subtract(var50);
    org.apache.commons.math.linear.BlockRealMatrix var53 = var50.scalarAdd(0.9d);
    org.apache.commons.math.linear.BlockRealMatrix var54 = var50.copy();
    org.apache.commons.math.linear.BlockRealMatrix var55 = var50.transpose();
    var55.multiplyEntry(2, 0, 6.4E-29d);
    org.apache.commons.math.linear.BlockRealMatrix var60 = var23.add(var55);
    org.apache.commons.math.linear.BlockRealMatrix var61 = var6.subtract((org.apache.commons.math.linear.RealMatrix)var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

}
