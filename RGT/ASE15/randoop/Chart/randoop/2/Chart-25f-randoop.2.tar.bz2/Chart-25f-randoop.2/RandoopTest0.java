
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var0, "", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    java.awt.geom.Rectangle2D var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = null;
    double var2 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("", var1, var2, var3);
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeGridlineStroke(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var0, "hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
//     var0.setBasePaint(var8, true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var5
//     assertTrue("Contract failed: equals-hashcode on var2 and var5", var2.equals(var5) ? var2.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var2
//     assertTrue("Contract failed: equals-hashcode on var5 and var2", var5.equals(var2) ? var5.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 1.0d, 0.0f, 100.0f);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var1 = null;
    int var2 = var0.getRangeAxisIndex(var1);
    org.jfree.chart.axis.CategoryAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainGridlinePosition(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
//     org.jfree.chart.plot.Marker var3 = null;
//     org.jfree.chart.util.Layer var4 = null;
//     var0.addRangeMarker(var3, var4);
// 
//   }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("", var1, var2);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.jfree.chart.title.Title var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.TitleChangeEvent var1 = new org.jfree.chart.event.TitleChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 10.0d, 1.0d, 0, (java.lang.Comparable)(byte)1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    java.awt.Stroke var2 = var0.getOutlineStroke();
    org.jfree.chart.util.RectangleInsets var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setInsets(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    java.util.Collection var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var1 = org.jfree.chart.util.ObjectUtilities.deepClone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(100.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, 0.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition(100);
//     var0.setSeriesNegativeItemLabelPosition(1, var4, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var2 and var0.", var2.equals(var0) == var0.equals(var2));
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = null;
    org.jfree.chart.renderer.category.StatisticalBarRenderer var7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var7.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var12 = var7.getItemLabelPaint(0, 10);
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var15 = var14.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var16 = var14.getDataset();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var19 = var17.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var22 = var17.getItemLabelPaint(0, 10);
    var14.setNoDataMessagePaint(var22);
    java.awt.Stroke var24 = null;
    java.awt.Shape var26 = null;
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var28 = var27.getFixedLegendItems();
    java.awt.Stroke var29 = var27.getOutlineStroke();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var32 = var30.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var35 = var30.getItemLabelPaint(0, 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem(var0, "", "hi!", "", true, var5, false, var12, false, var22, var24, false, var26, var29, var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
    org.jfree.chart.util.RectangleInsets var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setInsets(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    org.jfree.chart.util.RectangleInsets var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setInsets(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.LegendItem var7 = var0.getLegendItem(0, 0);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var9 = var8.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var10 = var8.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var13 = var11.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var16 = var11.getItemLabelPaint(0, 10);
//     var8.setNoDataMessagePaint(var16);
//     var0.setBaseFillPaint(var16);
//     
//     // Checks the contract:  equals-hashcode on var2 and var13
//     assertTrue("Contract failed: equals-hashcode on var2 and var13", var2.equals(var13) ? var2.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var2
//     assertTrue("Contract failed: equals-hashcode on var13 and var2", var13.equals(var2) ? var13.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.jfree.data.xy.XYDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    java.awt.Font var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelFont((-1), var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.combine(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
//     var0.setNoDataMessagePaint(var8);
//     var0.configureDomainAxes();
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     var0.drawOutline(var11, var12);
// 
//   }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
    java.awt.Font var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelFont(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("", var1);
//     
//     // Checks the contract:  var2.equals(var2)
//     assertTrue("Contract failed: var2.equals(var2)", var2.equals(var2));
// 
//   }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("hi!", var1, var2);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.TickLabelEntity var3 = new org.jfree.chart.entity.TickLabelEntity(var0, "", "hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
//     boolean var5 = var1.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var7 = var6.getFixedLegendItems();
//     var1.setPlot(var6);
//     java.awt.Paint var9 = var1.getErrorIndicatorPaint();
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var11 = var10.getFixedLegendItems();
//     java.awt.Stroke var12 = var10.getOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(10.0d, var9, var12);
//     
//     // Checks the contract:  equals-hashcode on var6 and var10
//     assertTrue("Contract failed: equals-hashcode on var6 and var10", var6.equals(var10) ? var6.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var6
//     assertTrue("Contract failed: equals-hashcode on var10 and var6", var10.equals(var6) ? var10.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     int var10 = var8.getRangeAxisIndex(var9);
//     boolean var11 = var8.isDomainZoomable();
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var8);
//     
//     // Checks the contract:  equals-hashcode on var5 and var8
//     assertTrue("Contract failed: equals-hashcode on var5 and var8", var5.equals(var8) ? var5.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var5
//     assertTrue("Contract failed: equals-hashcode on var8 and var5", var8.equals(var5) ? var8.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 10.0f, 100.0f, var4, 0.0d, (-1.0f), (-1.0f));

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.event.MarkerChangeEvent var2 = null;
    var1.notifyListeners(var2);
    org.jfree.chart.text.TextAnchor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelTextAnchor(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", var1, 0.0f, (-1.0f), var4);
// 
//   }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("", var1);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    java.awt.geom.Ellipse2D var0 = null;
    java.awt.geom.Ellipse2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    org.jfree.data.category.CategoryDataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var3 = var0.generateLabel(var1, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    org.jfree.chart.plot.DatasetRenderingOrder var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
//     var0.setNoDataMessagePaint(var8);
//     var0.configureDomainAxes();
//     float var11 = var0.getBackgroundAlpha();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var15 = var13.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var18 = var13.getItemLabelPaint(0, 10);
//     var0.setRenderer(100, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     
//     // Checks the contract:  equals-hashcode on var5 and var15
//     assertTrue("Contract failed: equals-hashcode on var5 and var15", var5.equals(var15) ? var5.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var5
//     assertTrue("Contract failed: equals-hashcode on var15 and var5", var15.equals(var5) ? var15.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.chart.axis.Axis var0 = null;
    java.awt.Shape var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisLabelEntity var4 = new org.jfree.chart.entity.AxisLabelEntity(var0, var1, "hi!", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     java.awt.Paint[] var9 = new java.awt.Paint[] { var8};
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var15 = var10.getItemLabelPaint(0, 10);
//     java.awt.Paint[] var16 = new java.awt.Paint[] { var15};
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var18 = var17.getFixedLegendItems();
//     java.awt.Stroke var19 = var17.getOutlineStroke();
//     java.awt.Stroke var20 = var17.getOutlineStroke();
//     java.awt.Stroke[] var21 = new java.awt.Stroke[] { var20};
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var23 = var22.getFixedLegendItems();
//     java.awt.Stroke var24 = var22.getOutlineStroke();
//     java.awt.Stroke var25 = var22.getOutlineStroke();
//     java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
//     java.awt.Shape[] var27 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var28 = new org.jfree.chart.plot.DefaultDrawingSupplier(var9, var16, var21, var26, var27);
//     
//     // Checks the contract:  equals-hashcode on var2 and var12
//     assertTrue("Contract failed: equals-hashcode on var2 and var12", var2.equals(var12) ? var2.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var2
//     assertTrue("Contract failed: equals-hashcode on var12 and var2", var12.equals(var2) ? var12.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var17
//     assertTrue("Contract failed: equals-hashcode on var5 and var17", var5.equals(var17) ? var5.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var22
//     assertTrue("Contract failed: equals-hashcode on var5 and var22", var5.equals(var22) ? var5.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var5
//     assertTrue("Contract failed: equals-hashcode on var17 and var5", var17.equals(var5) ? var17.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var22
//     assertTrue("Contract failed: equals-hashcode on var17 and var22", var17.equals(var22) ? var17.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var5
//     assertTrue("Contract failed: equals-hashcode on var22 and var5", var22.equals(var5) ? var22.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var17
//     assertTrue("Contract failed: equals-hashcode on var22 and var17", var22.equals(var17) ? var22.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
//     boolean var5 = var1.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var7 = var6.getFixedLegendItems();
//     var1.setPlot(var6);
//     java.awt.Paint var9 = var6.getBackgroundPaint();
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var11 = var10.getFixedLegendItems();
//     java.awt.Stroke var12 = var10.getOutlineStroke();
//     java.awt.Stroke var13 = var10.getOutlineStroke();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var16 = var14.getSeriesNegativeItemLabelPosition(100);
//     boolean var18 = var14.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var20 = var19.getFixedLegendItems();
//     var14.setPlot(var19);
//     java.awt.Paint var22 = var14.getErrorIndicatorPaint();
//     java.awt.Paint var23 = var14.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var25 = var24.getFixedLegendItems();
//     java.awt.Stroke var26 = var24.getOutlineStroke();
//     java.awt.Stroke var27 = var24.getOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(0.0d, var9, var13, var23, var27, 1.0f);
//     
//     // Checks the contract:  equals-hashcode on var3 and var16
//     assertTrue("Contract failed: equals-hashcode on var3 and var16", var3.equals(var16) ? var3.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var3
//     assertTrue("Contract failed: equals-hashcode on var16 and var3", var16.equals(var3) ? var16.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var10
//     assertTrue("Contract failed: equals-hashcode on var6 and var10", var6.equals(var10) ? var6.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var19
//     assertTrue("Contract failed: equals-hashcode on var6 and var19", var6.equals(var19) ? var6.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var24
//     assertTrue("Contract failed: equals-hashcode on var6 and var24", var6.equals(var24) ? var6.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var6
//     assertTrue("Contract failed: equals-hashcode on var10 and var6", var10.equals(var6) ? var10.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var19
//     assertTrue("Contract failed: equals-hashcode on var10 and var19", var10.equals(var19) ? var10.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var24
//     assertTrue("Contract failed: equals-hashcode on var10 and var24", var10.equals(var24) ? var10.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var6
//     assertTrue("Contract failed: equals-hashcode on var19 and var6", var19.equals(var6) ? var19.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var10
//     assertTrue("Contract failed: equals-hashcode on var19 and var10", var19.equals(var10) ? var19.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var24
//     assertTrue("Contract failed: equals-hashcode on var19 and var24", var19.equals(var24) ? var19.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var6
//     assertTrue("Contract failed: equals-hashcode on var24 and var6", var24.equals(var6) ? var24.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var10
//     assertTrue("Contract failed: equals-hashcode on var24 and var10", var24.equals(var10) ? var24.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var19
//     assertTrue("Contract failed: equals-hashcode on var24 and var19", var24.equals(var19) ? var24.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Paint var2 = null;
//     org.jfree.chart.text.TextMeasurer var5 = null;
//     org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var1, var2, 0.0f, (-1), var5);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
    var0.setPlot(var5);
    java.awt.Paint var8 = var0.getErrorIndicatorPaint();
    java.awt.Paint var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseItemLabelPaint(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var3 = null;
//     var0.setBaseURLGenerator(var3, true);
//     int var6 = var0.getColumnCount();
//     java.awt.Font var7 = var0.getBaseItemLabelFont();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var10 = var9.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var11 = var9.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var14 = var12.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var17 = var12.getItemLabelPaint(0, 10);
//     var9.setNoDataMessagePaint(var17);
//     var9.configureDomainAxes();
//     float var20 = var9.getBackgroundAlpha();
//     java.awt.geom.Rectangle2D var21 = null;
//     var0.drawDomainGridline(var8, var9, var21, 100.0d);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 1.0d, (-1.0d), 100.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var7 = var6.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var8 = var6.getDataset();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var11 = var9.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var14 = var9.getItemLabelPaint(0, 10);
    var6.setNoDataMessagePaint(var14);
    var6.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.data.category.CategoryDataset var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var3, var4, var5, var6, var17, var18, var19, 10, 0, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.expand(var0, 0.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var4 = var1.getBaseFillPaint();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
    java.awt.Stroke var7 = var5.getOutlineStroke();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var9 = var8.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var10 = var8.getDataset();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var13 = var11.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var16 = var11.getItemLabelPaint(0, 10);
    var8.setNoDataMessagePaint(var16);
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var19 = var18.getFixedLegendItems();
    java.awt.Stroke var20 = var18.getOutlineStroke();
    java.awt.Stroke var21 = var18.getOutlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(0.0d, var4, var7, var16, var21, (-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }
// 
// 
//     org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
//     org.jfree.chart.ui.Library[] var1 = var0.getLibraries();
//     java.awt.Image var2 = var0.getLogo();
//     org.jfree.chart.ui.Library var3 = null;
//     var0.addLibrary(var3);
// 
//   }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
//     var0.setNoDataMessagePaint(var8);
//     var0.configureDomainAxes();
//     float var11 = var0.getBackgroundAlpha();
//     org.jfree.chart.axis.AxisLocation var13 = var0.getDomainAxisLocation(1);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var16 = var14.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var19 = var14.getItemLabelPaint(0, 10);
//     var0.setBackgroundPaint(var19);
//     
//     // Checks the contract:  equals-hashcode on var5 and var16
//     assertTrue("Contract failed: equals-hashcode on var5 and var16", var5.equals(var16) ? var5.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var5
//     assertTrue("Contract failed: equals-hashcode on var16 and var5", var16.equals(var5) ? var16.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(100);
//     boolean var9 = var5.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var11 = var10.getFixedLegendItems();
//     var5.setPlot(var10);
//     java.awt.Paint var13 = var5.getErrorIndicatorPaint();
//     var5.setBase(100.0d);
//     boolean var18 = var5.getItemVisible(1, 1);
//     java.awt.Shape var20 = var5.lookupSeriesShape(100);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var23 = var22.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var24 = var22.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var27 = var25.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var30 = var25.getItemLabelPaint(0, 10);
//     var22.setNoDataMessagePaint(var30);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var35 = var33.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var38 = var33.getItemLabelPaint(0, 10);
//     org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var41 = null;
//     var40.notifyListeners(var41);
//     var40.setValue((-1.0d));
//     java.awt.Stroke var45 = var40.getOutlineStroke();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var47 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var49 = var47.getSeriesNegativeItemLabelPosition(100);
//     boolean var51 = var47.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var53 = var52.getFixedLegendItems();
//     var47.setPlot(var52);
//     java.awt.Paint var55 = var47.getErrorIndicatorPaint();
//     var47.setBase(100.0d);
//     boolean var60 = var47.getItemVisible(1, 1);
//     java.awt.Shape var62 = var47.lookupSeriesShape(100);
//     org.jfree.chart.entity.LegendItemEntity var63 = new org.jfree.chart.entity.LegendItemEntity(var62);
//     org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var65 = var64.getFixedLegendItems();
//     java.awt.Stroke var66 = var64.getOutlineStroke();
//     java.awt.Stroke var67 = var64.getOutlineStroke();
//     org.jfree.chart.plot.CategoryPlot var68 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var69 = var68.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var70 = var68.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var71 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var73 = var71.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var76 = var71.getItemLabelPaint(0, 10);
//     var68.setNoDataMessagePaint(var76);
//     org.jfree.chart.LegendItem var78 = new org.jfree.chart.LegendItem("hi!", "Category Plot", "hi!", "hi!", false, var20, true, var30, false, var38, var45, false, var62, var67, var76);
//     
//     // Checks the contract:  equals-hashcode on var7 and var27
//     assertTrue("Contract failed: equals-hashcode on var7 and var27", var7.equals(var27) ? var7.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var35
//     assertTrue("Contract failed: equals-hashcode on var7 and var35", var7.equals(var35) ? var7.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var49
//     assertTrue("Contract failed: equals-hashcode on var7 and var49", var7.equals(var49) ? var7.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var73
//     assertTrue("Contract failed: equals-hashcode on var7 and var73", var7.equals(var73) ? var7.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var7
//     assertTrue("Contract failed: equals-hashcode on var27 and var7", var27.equals(var7) ? var27.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var35
//     assertTrue("Contract failed: equals-hashcode on var27 and var35", var27.equals(var35) ? var27.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var49
//     assertTrue("Contract failed: equals-hashcode on var27 and var49", var27.equals(var49) ? var27.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var73
//     assertTrue("Contract failed: equals-hashcode on var27 and var73", var27.equals(var73) ? var27.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var7
//     assertTrue("Contract failed: equals-hashcode on var35 and var7", var35.equals(var7) ? var35.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var27
//     assertTrue("Contract failed: equals-hashcode on var35 and var27", var35.equals(var27) ? var35.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var49
//     assertTrue("Contract failed: equals-hashcode on var35 and var49", var35.equals(var49) ? var35.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var73
//     assertTrue("Contract failed: equals-hashcode on var35 and var73", var35.equals(var73) ? var35.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var7
//     assertTrue("Contract failed: equals-hashcode on var49 and var7", var49.equals(var7) ? var49.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var27
//     assertTrue("Contract failed: equals-hashcode on var49 and var27", var49.equals(var27) ? var49.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var35
//     assertTrue("Contract failed: equals-hashcode on var49 and var35", var49.equals(var35) ? var49.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var73
//     assertTrue("Contract failed: equals-hashcode on var49 and var73", var49.equals(var73) ? var49.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var7
//     assertTrue("Contract failed: equals-hashcode on var73 and var7", var73.equals(var7) ? var73.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var27
//     assertTrue("Contract failed: equals-hashcode on var73 and var27", var73.equals(var27) ? var73.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var35
//     assertTrue("Contract failed: equals-hashcode on var73 and var35", var73.equals(var35) ? var73.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var49
//     assertTrue("Contract failed: equals-hashcode on var73 and var49", var73.equals(var49) ? var73.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var52
//     assertTrue("Contract failed: equals-hashcode on var10 and var52", var10.equals(var52) ? var10.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var64
//     assertTrue("Contract failed: equals-hashcode on var22 and var64", var22.equals(var64) ? var22.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var68
//     assertTrue("Contract failed: equals-hashcode on var22 and var68", var22.equals(var68) ? var22.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var10
//     assertTrue("Contract failed: equals-hashcode on var52 and var10", var52.equals(var10) ? var52.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var22
//     assertTrue("Contract failed: equals-hashcode on var64 and var22", var64.equals(var22) ? var64.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var68
//     assertTrue("Contract failed: equals-hashcode on var64 and var68", var64.equals(var68) ? var64.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var22
//     assertTrue("Contract failed: equals-hashcode on var68 and var22", var68.equals(var22) ? var68.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var64
//     assertTrue("Contract failed: equals-hashcode on var68 and var64", var68.equals(var64) ? var68.hashCode() == var64.hashCode() : true);
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.rotateShape(var0, 100.0d, 100.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
    var0.setNoDataMessagePaint(var8);
    var0.configureDomainAxes();
    org.jfree.chart.plot.PlotOrientation var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setOrientation(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
    java.lang.String var2 = var1.toString();
    java.awt.geom.Rectangle2D var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var4 = var1.createOutsetRectangle(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"+ "'", var2.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeWithMargins(var1, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.text.TextAnchor var5 = var4.getTextAnchor();
    org.jfree.chart.axis.CategoryLabelWidthType var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var9 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var5, 10.0d, var7, 1.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)(short)100, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.text.TextAnchor var3 = var2.getTextAnchor();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.clearDomainMarkers(1);
//     java.awt.Image var7 = var4.getBackgroundImage();
//     float var8 = var4.getForegroundAlpha();
//     boolean var9 = var2.equals((java.lang.Object)var8);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var13 = var10.getBaseFillPaint();
//     boolean var14 = var2.equals((java.lang.Object)var10);
//     
//     // Checks the contract:  equals-hashcode on var2 and var12
//     assertTrue("Contract failed: equals-hashcode on var2 and var12", var2.equals(var12) ? var2.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var2
//     assertTrue("Contract failed: equals-hashcode on var12 and var2", var12.equals(var2) ? var12.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    java.awt.Graphics2D var1 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, (-1.0f), 1.0f, 1.0d, 0.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
    var0.setPlot(var5);
    java.awt.Paint var8 = var0.getErrorIndicatorPaint();
    java.awt.Paint var9 = var0.getBaseOutlinePaint();
    boolean var11 = var0.isSeriesVisible(0);
    java.awt.Paint var12 = null;
    var0.setErrorIndicatorPaint(var12);
    org.jfree.chart.annotations.CategoryAnnotation var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     boolean var11 = var0.isSeriesVisible(0);
//     java.awt.Paint var12 = null;
//     var0.setErrorIndicatorPaint(var12);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var0.getLegendItemLabelGenerator();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var19 = null;
//     var16.setBaseURLGenerator(var19, true);
//     int var22 = var16.getColumnCount();
//     java.awt.Font var23 = var16.getBaseItemLabelFont();
//     var0.setSeriesItemLabelFont(100, var23);
//     
//     // Checks the contract:  equals-hashcode on var2 and var18
//     assertTrue("Contract failed: equals-hashcode on var2 and var18", var2.equals(var18) ? var2.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var2
//     assertTrue("Contract failed: equals-hashcode on var18 and var2", var18.equals(var2) ? var18.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)"Category Plot");
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 1.0E-8d, 100.0f, 0.0f);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("Category Plot", var1, var2);
// 
//   }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.text.TextAnchor var7 = var6.getTextAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, (-1.0f), (-1.0f), var7, (-1.0d), (-1.0f), 0.0f);
// 
//   }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 1.0f);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = org.jfree.chart.util.RectangleEdge.opposite(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.event.MarkerChangeEvent var2 = null;
    var1.notifyListeners(var2);
    var1.setValue((-1.0d));
    org.jfree.chart.util.RectangleInsets var6 = var1.getLabelOffset();
    java.awt.geom.Rectangle2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var8 = var6.createInsetRectangle(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
    var0.setPlot(var5);
    java.awt.Paint var8 = var0.getErrorIndicatorPaint();
    org.jfree.chart.annotations.CategoryAnnotation var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var2 = null;
//     var1.notifyListeners(var2);
//     var1.setValue((-1.0d));
//     java.awt.Stroke var6 = var1.getOutlineStroke();
//     java.lang.Class var7 = null;
//     java.util.EventListener[] var8 = var1.getListeners(var7);
// 
//   }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
//     var0.setNoDataMessagePaint(var8);
//     var0.configureDomainAxes();
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var12 = var11.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var13 = var11.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var16 = var14.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var19 = var14.getItemLabelPaint(0, 10);
//     var11.setNoDataMessagePaint(var19);
//     var11.configureDomainAxes();
//     float var22 = var11.getBackgroundAlpha();
//     org.jfree.chart.axis.AxisLocation var24 = var11.getDomainAxisLocation(1);
//     org.jfree.chart.axis.AxisLocation var25 = var24.getOpposite();
//     var0.setRangeAxisLocation(var24);
//     
//     // Checks the contract:  equals-hashcode on var5 and var16
//     assertTrue("Contract failed: equals-hashcode on var5 and var16", var5.equals(var16) ? var5.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var5
//     assertTrue("Contract failed: equals-hashcode on var16 and var5", var16.equals(var5) ? var16.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 1.0E-8d, 8.0d, 1.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.String var1 = var0.getLabel();
//     org.jfree.chart.axis.MarkerAxisBand var2 = null;
//     var0.setMarkerBand(var2);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.plot.Plot var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     org.jfree.chart.axis.AxisSpace var8 = null;
//     org.jfree.chart.axis.AxisSpace var9 = var0.reserveSpace(var4, var5, var6, var7, var8);
// 
//   }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var11 = var9.getSeriesNegativeItemLabelPosition(100);
//     boolean var13 = var9.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var15 = var14.getFixedLegendItems();
//     var9.setPlot(var14);
//     java.awt.Paint var17 = var14.getBackgroundPaint();
//     var0.setSeriesPaint(0, var17, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var9 and var0.", var9.equals(var0) == var0.equals(var9));
//     
//     // Checks the contract:  equals-hashcode on var2 and var11
//     assertTrue("Contract failed: equals-hashcode on var2 and var11", var2.equals(var11) ? var2.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var2
//     assertTrue("Contract failed: equals-hashcode on var11 and var2", var11.equals(var2) ? var11.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var14
//     assertTrue("Contract failed: equals-hashcode on var5 and var14", var5.equals(var14) ? var5.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var5
//     assertTrue("Contract failed: equals-hashcode on var14 and var5", var14.equals(var5) ? var14.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var1);
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    var0.setAutoPopulateSeriesPaint(false);
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var9 = var8.getFixedLegendItems();
    java.awt.Stroke var10 = var8.getOutlineStroke();
    java.awt.Stroke var11 = var8.getOutlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesStroke((-1), var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var7 = var2.getItemLabelPaint(0, 10);
    var2.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    boolean var11 = var1.equals((java.lang.Object)true);
    java.awt.geom.Rectangle2D var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var13 = var1.createOutsetRectangle(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.text.TextAnchor var4 = var3.getTextAnchor();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.text.TextAnchor var8 = var7.getTextAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var10 = new org.jfree.chart.labels.ItemLabelPosition(var0, var4, var8, (-6.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
//     int var1 = var0.getItemCount();
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var3 = var2.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var4 = var2.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var10 = var5.getItemLabelPaint(0, 10);
//     var2.setNoDataMessagePaint(var10);
//     var2.configureDomainAxes();
//     float var13 = var2.getBackgroundAlpha();
//     boolean var14 = var0.equals((java.lang.Object)var13);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(100);
//     boolean var20 = var16.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var22 = var21.getFixedLegendItems();
//     var16.setPlot(var21);
//     java.awt.Paint var24 = var21.getBackgroundPaint();
//     var0.addObject((java.lang.Comparable)"RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (java.lang.Object)var24);
//     
//     // Checks the contract:  equals-hashcode on var2 and var21
//     assertTrue("Contract failed: equals-hashcode on var2 and var21", var2.equals(var21) ? var2.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var2
//     assertTrue("Contract failed: equals-hashcode on var21 and var2", var21.equals(var2) ? var21.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var18
//     assertTrue("Contract failed: equals-hashcode on var7 and var18", var7.equals(var18) ? var7.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var7
//     assertTrue("Contract failed: equals-hashcode on var18 and var7", var18.equals(var7) ? var18.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    int var1 = var0.getItemCount();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    double var3 = var2.getMinimumBarLength();
    var2.setAutoPopulateSeriesStroke(false);
    boolean var6 = var0.equals((java.lang.Object)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
//     var0.setNoDataMessagePaint(var8);
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var13 = var12.getInsets();
//     java.lang.String var14 = var13.toString();
//     var11.setTickLabelInsets(var13);
//     double var17 = var13.calculateLeftInset(0.0d);
//     var0.setInsets(var13);
//     
//     // Checks the contract:  equals-hashcode on var0 and var12
//     assertTrue("Contract failed: equals-hashcode on var0 and var12", var0.equals(var12) ? var0.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var0
//     assertTrue("Contract failed: equals-hashcode on var12 and var0", var12.equals(var0) ? var12.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var1);
// 
//   }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { Double.NaN};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 100.0f};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     java.lang.Comparable var1 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, var1);
// 
//   }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = null;
//     var1.setBaseURLGenerator(var4, true);
//     int var7 = var1.getColumnCount();
//     java.awt.Font var8 = var1.getBaseItemLabelFont();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var11 = var9.getSeriesNegativeItemLabelPosition(100);
//     boolean var13 = var9.isSeriesVisible(10);
//     var9.setAutoPopulateSeriesPaint(false);
//     boolean var17 = var9.isSeriesItemLabelsVisible(0);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     double var19 = var18.getMinimumBarLength();
//     java.awt.Paint var20 = var18.getErrorIndicatorPaint();
//     var9.setBaseOutlinePaint(var20, false);
//     org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("Category Plot", var8, var20);
//     
//     // Checks the contract:  equals-hashcode on var3 and var11
//     assertTrue("Contract failed: equals-hashcode on var3 and var11", var3.equals(var11) ? var3.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var3
//     assertTrue("Contract failed: equals-hashcode on var11 and var3", var11.equals(var3) ? var11.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var5.getBackgroundPaint();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var11 = var9.getSeriesNegativeItemLabelPosition(100);
//     boolean var13 = var9.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var15 = var14.getFixedLegendItems();
//     var9.setPlot(var14);
//     java.awt.Paint var17 = var9.getErrorIndicatorPaint();
//     var9.setBase(100.0d);
//     boolean var22 = var9.getItemVisible(1, 1);
//     java.awt.Stroke var23 = var9.getBaseOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var26 = null;
//     var25.notifyListeners(var26);
//     var25.setValue((-1.0d));
//     org.jfree.chart.util.RectangleInsets var30 = var25.getLabelOffset();
//     double var32 = var30.trimHeight(0.0d);
//     org.jfree.chart.block.LineBorder var33 = new org.jfree.chart.block.LineBorder(var8, var23, var30);
//     
//     // Checks the contract:  equals-hashcode on var2 and var11
//     assertTrue("Contract failed: equals-hashcode on var2 and var11", var2.equals(var11) ? var2.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var2
//     assertTrue("Contract failed: equals-hashcode on var11 and var2", var11.equals(var2) ? var11.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var14
//     assertTrue("Contract failed: equals-hashcode on var5 and var14", var5.equals(var14) ? var5.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var5
//     assertTrue("Contract failed: equals-hashcode on var14 and var5", var14.equals(var5) ? var14.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var1.setBaseURLGenerator(var4, true);
    int var7 = var1.getColumnCount();
    java.awt.Font var8 = var1.getBaseItemLabelFont();
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var8);
    var9.setText("");
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.setTextAlignment(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     var0.setBase(100.0d);
//     boolean var13 = var0.getItemVisible(1, 1);
//     java.awt.Stroke var14 = var0.getBaseOutlineStroke();
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var17 = var16.getInsets();
//     java.lang.String var18 = var17.toString();
//     var15.setTickLabelInsets(var17);
//     double var21 = var17.calculateLeftInset(0.0d);
//     org.jfree.chart.util.UnitType var22 = var17.getUnitType();
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     var23.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var27 = var23.getTickMarkStroke();
//     boolean var28 = var23.isAutoRange();
//     double var29 = var23.getUpperBound();
//     boolean var30 = var22.equals((java.lang.Object)var23);
//     boolean var31 = var0.equals((java.lang.Object)var22);
//     
//     // Checks the contract:  equals-hashcode on var5 and var16
//     assertTrue("Contract failed: equals-hashcode on var5 and var16", var5.equals(var16) ? var5.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var5
//     assertTrue("Contract failed: equals-hashcode on var16 and var5", var16.equals(var5) ? var16.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     boolean var11 = var0.isSeriesVisible(0);
//     java.awt.Paint var12 = null;
//     var0.setErrorIndicatorPaint(var12);
//     var0.removeAnnotations();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(100);
//     boolean var20 = var16.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var22 = var21.getFixedLegendItems();
//     var16.setPlot(var21);
//     java.awt.Paint var24 = var16.getErrorIndicatorPaint();
//     java.awt.Paint var25 = var16.getBaseOutlinePaint();
//     var0.setSeriesFillPaint(100, var25);
//     
//     // Checks the contract:  equals-hashcode on var2 and var18
//     assertTrue("Contract failed: equals-hashcode on var2 and var18", var2.equals(var18) ? var2.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var2
//     assertTrue("Contract failed: equals-hashcode on var18 and var2", var18.equals(var2) ? var18.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var21
//     assertTrue("Contract failed: equals-hashcode on var5 and var21", var5.equals(var21) ? var5.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var5
//     assertTrue("Contract failed: equals-hashcode on var21 and var5", var21.equals(var5) ? var21.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
//     var0.setNoDataMessagePaint(var8);
//     var0.zoom(1.0d);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var2 = var1.getInsets();
    java.lang.String var3 = var2.toString();
    var0.setTickLabelInsets(var2);
    double var6 = var2.calculateLeftInset(0.0d);
    org.jfree.chart.util.UnitType var7 = var2.getUnitType();
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    var8.zoomRange(0.0d, 100.0d);
    java.awt.Stroke var12 = var8.getTickMarkStroke();
    boolean var13 = var8.isAutoRange();
    double var14 = var8.getUpperBound();
    boolean var15 = var7.equals((java.lang.Object)var8);
    var8.setRangeAboutValue(3.0d, 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"+ "'", var3.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.ui.Library[] var1 = var0.getLibraries();
    java.awt.Image var2 = var0.getLogo();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
    boolean var7 = var3.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var9 = var8.getFixedLegendItems();
    var3.setPlot(var8);
    java.awt.Paint var11 = var3.getErrorIndicatorPaint();
    var3.setBase(100.0d);
    boolean var16 = var3.getItemVisible(1, 1);
    java.awt.Paint var19 = var3.getItemOutlinePaint(0, 0);
    boolean var20 = var0.equals((java.lang.Object)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var3 = var1.getRangeAxis(0);
//     java.awt.Paint var4 = var1.getOutlinePaint();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(100);
//     boolean var9 = var5.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var11 = var10.getFixedLegendItems();
//     var5.setPlot(var10);
//     java.awt.Paint var13 = var5.getErrorIndicatorPaint();
//     java.awt.Paint var14 = var5.getBaseOutlinePaint();
//     boolean var16 = var5.isSeriesVisible(0);
//     java.awt.Paint var17 = null;
//     var5.setErrorIndicatorPaint(var17);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var19 = var5.getLegendItemLabelGenerator();
//     java.awt.Stroke var22 = var5.getItemStroke(1, 10);
//     org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(0.0d, var4, var22);
//     
//     // Checks the contract:  equals-hashcode on var1 and var10
//     assertTrue("Contract failed: equals-hashcode on var1 and var10", var1.equals(var10) ? var1.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(1);
    java.awt.Image var3 = var0.getBackgroundImage();
    float var4 = var0.getForegroundAlpha();
    org.jfree.chart.plot.CategoryMarker var6 = null;
    org.jfree.chart.util.Layer var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(1, var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0f);

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     var0.setBaseSeriesVisible(true, true);
//     boolean var14 = var0.equals((java.lang.Object)1.0d);
//     java.lang.Boolean var16 = var0.getSeriesVisibleInLegend((-1));
//     double var17 = var0.getMaximumBarWidth();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var21 = var19.getSeriesNegativeItemLabelPosition(100);
//     boolean var23 = var19.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var25 = var24.getFixedLegendItems();
//     var19.setPlot(var24);
//     java.awt.Paint var27 = var24.getBackgroundPaint();
//     var0.setSeriesOutlinePaint(0, var27);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var19 and var0.", var19.equals(var0) == var0.equals(var19));
//     
//     // Checks the contract:  equals-hashcode on var2 and var21
//     assertTrue("Contract failed: equals-hashcode on var2 and var21", var2.equals(var21) ? var2.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var2
//     assertTrue("Contract failed: equals-hashcode on var21 and var2", var21.equals(var2) ? var21.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var24
//     assertTrue("Contract failed: equals-hashcode on var5 and var24", var5.equals(var24) ? var5.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var5
//     assertTrue("Contract failed: equals-hashcode on var24 and var5", var24.equals(var5) ? var24.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var2 = null;
//     var1.notifyListeners(var2);
//     var1.setValue((-1.0d));
//     org.jfree.chart.util.RectangleInsets var6 = var1.getLabelOffset();
//     java.lang.Class var7 = null;
//     java.util.EventListener[] var8 = var1.getListeners(var7);
// 
//   }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.zoomRange(100.0d, 100.0d);
//     var0.setLowerBound(10.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var8 = var6.getSeriesNegativeItemLabelPosition(100);
//     boolean var10 = var6.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var12 = var11.getFixedLegendItems();
//     var6.setPlot(var11);
//     java.awt.Paint var14 = var6.getErrorIndicatorPaint();
//     var6.setBase(100.0d);
//     boolean var19 = var6.getItemVisible(1, 1);
//     java.awt.Shape var21 = var6.lookupSeriesShape(100);
//     var0.setUpArrow(var21);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var25 = var23.getSeriesNegativeItemLabelPosition(100);
//     boolean var27 = var23.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var29 = var28.getFixedLegendItems();
//     var23.setPlot(var28);
//     java.awt.Paint var31 = var28.getBackgroundPaint();
//     org.jfree.chart.LegendItemCollection var32 = var28.getFixedLegendItems();
//     java.awt.Paint var33 = var28.getRangeCrosshairPaint();
//     var0.setTickLabelPaint(var33);
//     
//     // Checks the contract:  equals-hashcode on var8 and var25
//     assertTrue("Contract failed: equals-hashcode on var8 and var25", var8.equals(var25) ? var8.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var8
//     assertTrue("Contract failed: equals-hashcode on var25 and var8", var25.equals(var8) ? var25.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    java.awt.Color var1 = java.awt.Color.getColor("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
    var0.setPlot(var5);
    java.awt.Paint var8 = var0.getErrorIndicatorPaint();
    java.awt.Paint var9 = var0.getBaseOutlinePaint();
    boolean var11 = var0.isSeriesVisible(0);
    java.awt.Paint var12 = null;
    var0.setErrorIndicatorPaint(var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-1), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var4 = var0.getTickMarkStroke();
//     boolean var5 = var0.isAutoRange();
//     double var6 = var0.getUpperBound();
//     java.lang.String var7 = var0.getLabelToolTip();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var10 = var8.getRangeAxis(0);
//     java.awt.Paint var11 = var8.getOutlinePaint();
//     var0.setAxisLinePaint(var11);
//     java.awt.Font var14 = null;
//     java.awt.Paint var15 = null;
//     org.jfree.chart.text.TextMeasurer var18 = null;
//     org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, var15, 0.0f, 1, var18);
//     java.util.List var20 = var19.getLines();
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.general.DatasetGroup var22 = var21.getDatasetGroup();
//     org.jfree.chart.axis.AxisLocation var23 = var21.getRangeAxisLocation();
//     boolean var24 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var19, (java.lang.Object)var21);
//     boolean var25 = var0.hasListener((java.util.EventListener)var21);
//     
//     // Checks the contract:  equals-hashcode on var8 and var21
//     assertTrue("Contract failed: equals-hashcode on var8 and var21", var8.equals(var21) ? var8.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var8
//     assertTrue("Contract failed: equals-hashcode on var21 and var8", var21.equals(var8) ? var21.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { (-1)};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { Double.NaN};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     org.jfree.chart.axis.CategoryLabelPosition var1 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.util.RectangleAnchor var2 = var1.getCategoryAnchor();
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.RectangleAnchor.coordinates(var0, var2);
// 
//   }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var3 = null;
//     var0.setBaseURLGenerator(var3, true);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     double var8 = var7.getMinimumBarLength();
//     java.awt.Paint var9 = var7.getErrorIndicatorPaint();
//     var0.setSeriesItemLabelPaint(0, var9, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var7 and var0.", var7.equals(var0) == var0.equals(var7));
// 
//   }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
//     var0.setNegativeItemLabelPositionFallback(var5);
//     
//     // Checks the contract:  equals-hashcode on var2 and var5
//     assertTrue("Contract failed: equals-hashcode on var2 and var5", var2.equals(var5) ? var2.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var2
//     assertTrue("Contract failed: equals-hashcode on var5 and var2", var5.equals(var2) ? var5.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, (-6.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    double var1 = var0.getMinimumBarLength();
    org.jfree.chart.event.RendererChangeListener var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeChangeListener(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    int var3 = java.awt.Color.HSBtoRGB(0.0f, 100.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16777216));

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     var0.setBaseSeriesVisible(true, true);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var14 = var13.getInsets();
//     boolean var15 = var0.equals((java.lang.Object)var13);
//     
//     // Checks the contract:  equals-hashcode on var5 and var13
//     assertTrue("Contract failed: equals-hashcode on var5 and var13", var5.equals(var13) ? var5.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var5
//     assertTrue("Contract failed: equals-hashcode on var13 and var5", var13.equals(var5) ? var13.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
//     boolean var5 = var1.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var7 = var6.getFixedLegendItems();
//     var1.setPlot(var6);
//     java.awt.Paint var9 = var1.getErrorIndicatorPaint();
//     var1.setBase(100.0d);
//     boolean var14 = var1.getItemVisible(1, 1);
//     java.awt.Shape var16 = var1.lookupSeriesShape(100);
//     org.jfree.chart.entity.CategoryLabelEntity var19 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)0.0f, var16, "", "");
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
//     java.text.NumberFormat var21 = null;
//     var20.setNumberFormatOverride(var21);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var24 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var26 = var24.getSeriesNegativeItemLabelPosition(100);
//     boolean var28 = var24.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var30 = var29.getFixedLegendItems();
//     var24.setPlot(var29);
//     java.awt.Paint var32 = var24.getErrorIndicatorPaint();
//     var24.setBase(100.0d);
//     boolean var37 = var24.getItemVisible(1, 1);
//     java.awt.Shape var39 = var24.lookupSeriesShape(100);
//     org.jfree.chart.entity.CategoryLabelEntity var42 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)10L, var39, "Category Plot", "");
//     var20.setRightArrow(var39);
//     var19.setArea(var39);
//     
//     // Checks the contract:  equals-hashcode on var3 and var26
//     assertTrue("Contract failed: equals-hashcode on var3 and var26", var3.equals(var26) ? var3.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var3
//     assertTrue("Contract failed: equals-hashcode on var26 and var3", var26.equals(var3) ? var26.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var29
//     assertTrue("Contract failed: equals-hashcode on var6 and var29", var6.equals(var29) ? var6.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var6
//     assertTrue("Contract failed: equals-hashcode on var29 and var6", var29.equals(var6) ? var29.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
//     var0.setNoDataMessagePaint(var8);
//     var0.configureDomainAxes();
//     float var11 = var0.getBackgroundAlpha();
//     var0.setRangeCrosshairLockedOnData(true);
//     org.jfree.data.category.CategoryDataset var15 = var0.getDataset(100);
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var18 = var17.getInsets();
//     java.lang.String var19 = var18.toString();
//     var16.setTickLabelInsets(var18);
//     var0.setInsets(var18);
//     
//     // Checks the contract:  equals-hashcode on var0 and var17
//     assertTrue("Contract failed: equals-hashcode on var0 and var17", var0.equals(var17) ? var0.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var0
//     assertTrue("Contract failed: equals-hashcode on var17 and var0", var17.equals(var0) ? var17.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    org.jfree.chart.plot.DatasetRenderingOrder var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
//     var0.setNoDataMessagePaint(var8);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = var0.getRenderer();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var13 = var11.getSeriesNegativeItemLabelPosition(100);
//     boolean var15 = var11.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var17 = var16.getFixedLegendItems();
//     var11.setPlot(var16);
//     java.awt.Paint var19 = var11.getErrorIndicatorPaint();
//     java.awt.Paint var20 = var11.getBaseOutlinePaint();
//     boolean var22 = var11.isSeriesVisible(0);
//     java.awt.Paint var23 = null;
//     var11.setErrorIndicatorPaint(var23);
//     var11.removeAnnotations();
//     var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var11, false);
//     
//     // Checks the contract:  equals-hashcode on var5 and var13
//     assertTrue("Contract failed: equals-hashcode on var5 and var13", var5.equals(var13) ? var5.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var5
//     assertTrue("Contract failed: equals-hashcode on var13 and var5", var13.equals(var5) ? var13.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var5 = null;
//     var2.setBaseURLGenerator(var5, true);
//     int var8 = var2.getColumnCount();
//     java.awt.Font var9 = var2.getBaseItemLabelFont();
//     org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("", var9);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var13 = var11.getSeriesNegativeItemLabelPosition(100);
//     boolean var15 = var11.isSeriesVisible(10);
//     var11.setAutoPopulateSeriesPaint(false);
//     java.lang.Object var18 = var11.clone();
//     java.awt.Paint var21 = var11.getItemLabelPaint(1, 10);
//     org.jfree.chart.text.TextFragment var22 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var9, var21);
//     
//     // Checks the contract:  equals-hashcode on var4 and var13
//     assertTrue("Contract failed: equals-hashcode on var4 and var13", var4.equals(var13) ? var4.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var4
//     assertTrue("Contract failed: equals-hashcode on var13 and var4", var13.equals(var4) ? var13.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.urls.CategoryURLGenerator var3 = null;
    var0.setBaseURLGenerator(var3, true);
    int var6 = var0.getColumnCount();
    boolean var7 = var0.getAutoPopulateSeriesFillPaint();
    org.jfree.chart.labels.CategoryToolTipGenerator var9 = var0.getSeriesToolTipGenerator(10);
    org.jfree.chart.annotations.CategoryAnnotation var10 = null;
    org.jfree.chart.util.Layer var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var10, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.String var1 = var0.getLabel();
    double var2 = var0.getUpperMargin();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAutoRangeMinimumSize(0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)(-1.0f), 0.0d, 255);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var3 = null;
//     var0.setBaseURLGenerator(var3, true);
//     int var6 = var0.getColumnCount();
//     boolean var7 = var0.getBaseSeriesVisibleInLegend();
//     boolean var8 = var0.getBaseItemLabelsVisible();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var11 = var9.getSeriesNegativeItemLabelPosition(100);
//     boolean var13 = var9.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var15 = var14.getFixedLegendItems();
//     var9.setPlot(var14);
//     java.awt.Paint var17 = var14.getBackgroundPaint();
//     org.jfree.chart.LegendItemCollection var18 = var14.getFixedLegendItems();
//     java.awt.Paint var19 = var14.getRangeCrosshairPaint();
//     var0.setBaseFillPaint(var19, true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var11
//     assertTrue("Contract failed: equals-hashcode on var2 and var11", var2.equals(var11) ? var2.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var2
//     assertTrue("Contract failed: equals-hashcode on var11 and var2", var11.equals(var2) ? var11.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var2 = var1.getInsets();
    java.lang.String var3 = var2.toString();
    var0.setTickLabelInsets(var2);
    double var6 = var2.calculateLeftInset(0.0d);
    double var8 = var2.calculateLeftOutset(0.0d);
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.ValueMarker var11 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.event.MarkerChangeEvent var12 = null;
    var11.notifyListeners(var12);
    var11.setValue((-1.0d));
    java.awt.Stroke var16 = var11.getOutlineStroke();
    org.jfree.chart.util.LengthAdjustmentType var17 = var11.getLabelOffsetType();
    org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.event.MarkerChangeEvent var20 = null;
    var19.notifyListeners(var20);
    var19.setValue((-1.0d));
    java.awt.Stroke var24 = var19.getOutlineStroke();
    org.jfree.chart.util.LengthAdjustmentType var25 = var19.getLabelOffsetType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var26 = var2.createAdjustedRectangle(var9, var17, var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"+ "'", var3.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var0.getSeriesItemLabelGenerator(10);
    java.awt.Paint var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPaint((-16777216), var8, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("hi!");
    boolean var3 = var1.equals((java.lang.Object)"Category Plot");
    var1.setToolTipText("hi!");
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTextAlignment(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.text.TextAnchor var4 = var3.getTextAnchor();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.text.TextAnchor var8 = var7.getTextAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var10 = new org.jfree.chart.labels.ItemLabelPosition(var0, var4, var8, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     var0.setBase(100.0d);
//     boolean var13 = var0.getItemVisible(1, 1);
//     java.awt.Shape var15 = var0.lookupSeriesShape(100);
//     org.jfree.chart.entity.LegendItemEntity var16 = new org.jfree.chart.entity.LegendItemEntity(var15);
//     java.awt.Shape var17 = var16.getArea();
//     org.jfree.chart.entity.LegendItemEntity var18 = new org.jfree.chart.entity.LegendItemEntity(var17);
//     
//     // Checks the contract:  equals-hashcode on var16 and var18
//     assertTrue("Contract failed: equals-hashcode on var16 and var18", var16.equals(var18) ? var16.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var16
//     assertTrue("Contract failed: equals-hashcode on var18 and var16", var18.equals(var16) ? var18.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    var0.setAutoPopulateSeriesStroke(false);
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesToolTipGenerator((-16777216), var6, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(1);
    java.awt.Image var3 = var0.getBackgroundImage();
    org.jfree.chart.util.SortOrder var4 = var0.getRowRenderingOrder();
    java.lang.Object var5 = null;
    boolean var6 = var4.equals(var5);
    java.lang.String var7 = var4.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "SortOrder.ASCENDING"+ "'", var7.equals("SortOrder.ASCENDING"));

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("SortOrder.ASCENDING");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(100.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    java.awt.Paint var3 = var0.getOutlinePaint();
    org.jfree.chart.plot.DatasetRenderingOrder var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
    boolean var8 = var4.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var10 = var9.getFixedLegendItems();
    var4.setPlot(var9);
    java.awt.Paint var12 = var4.getErrorIndicatorPaint();
    var4.setBase(100.0d);
    boolean var17 = var4.getItemVisible(1, 1);
    java.awt.Shape var19 = var4.lookupSeriesShape(100);
    java.awt.Color var23 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var24 = var23.getRed();
    java.awt.Color var25 = var23.brighter();
    int var26 = var23.getAlpha();
    java.awt.Stroke var27 = null;
    org.jfree.chart.renderer.category.StatisticalBarRenderer var28 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var30 = var28.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var33 = var28.getItemLabelPaint(0, 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var34 = new org.jfree.chart.LegendItem(var0, "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "", "", var19, (java.awt.Paint)var23, var27, var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = null;
//     var1.setBaseURLGenerator(var4, true);
//     int var7 = var1.getColumnCount();
//     java.awt.Font var8 = var1.getBaseItemLabelFont();
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var8);
//     var9.setText("");
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     java.lang.Object var14 = null;
//     java.lang.Object var15 = var9.draw(var12, var13, var14);
//     java.lang.Object var16 = var9.clone();
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var18 = var17.getFixedLegendItems();
//     java.awt.Stroke var19 = var17.getOutlineStroke();
//     java.awt.Stroke var20 = var17.getOutlineStroke();
//     org.jfree.chart.axis.ValueAxis var21 = var17.getRangeAxis();
//     float var22 = var17.getBackgroundImageAlpha();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var25 = var23.getSeriesNegativeItemLabelPosition(100);
//     boolean var27 = var23.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var29 = var28.getFixedLegendItems();
//     var23.setPlot(var28);
//     java.awt.Paint var31 = var28.getBackgroundPaint();
//     org.jfree.chart.LegendItemCollection var32 = var28.getFixedLegendItems();
//     java.awt.Paint var33 = var28.getRangeCrosshairPaint();
//     var17.setNoDataMessagePaint(var33);
//     var9.setPaint(var33);
//     
//     // Checks the contract:  equals-hashcode on var3 and var25
//     assertTrue("Contract failed: equals-hashcode on var3 and var25", var3.equals(var25) ? var3.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var3
//     assertTrue("Contract failed: equals-hashcode on var25 and var3", var25.equals(var3) ? var25.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
//     var0.setNoDataMessagePaint(var8);
//     var0.configureDomainAxes();
//     float var11 = var0.getBackgroundAlpha();
//     var0.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.util.RectangleEdge var14 = var0.getRangeAxisEdge();
//     var0.setRangeCrosshairVisible(true);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var20 = var18.getSeriesNegativeItemLabelPosition(100);
//     boolean var22 = var18.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var24 = var23.getFixedLegendItems();
//     var18.setPlot(var23);
//     var0.setRenderer(255, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18, true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var20
//     assertTrue("Contract failed: equals-hashcode on var5 and var20", var5.equals(var20) ? var5.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var5
//     assertTrue("Contract failed: equals-hashcode on var20 and var5", var20.equals(var5) ? var20.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var3 = null;
//     var0.setBaseURLGenerator(var3, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var0.getBaseItemLabelGenerator();
//     double var7 = var0.getUpperClip();
//     org.jfree.chart.plot.ValueMarker var9 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var10 = null;
//     var9.notifyListeners(var10);
//     var9.setValue((-1.0d));
//     org.jfree.chart.util.RectangleInsets var14 = var9.getLabelOffset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var17 = var15.getSeriesNegativeItemLabelPosition(100);
//     boolean var19 = var15.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var21 = var20.getFixedLegendItems();
//     var15.setPlot(var20);
//     java.awt.Paint var23 = var15.getErrorIndicatorPaint();
//     java.awt.Paint var24 = var15.getBaseOutlinePaint();
//     boolean var26 = var15.isSeriesVisible(0);
//     java.awt.Paint var27 = null;
//     var15.setErrorIndicatorPaint(var27);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var29 = var15.getLegendItemLabelGenerator();
//     java.awt.Stroke var32 = var15.getItemStroke(1, 10);
//     var9.setOutlineStroke(var32);
//     var0.setBaseOutlineStroke(var32);
//     
//     // Checks the contract:  equals-hashcode on var2 and var17
//     assertTrue("Contract failed: equals-hashcode on var2 and var17", var2.equals(var17) ? var2.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var2
//     assertTrue("Contract failed: equals-hashcode on var17 and var2", var17.equals(var2) ? var17.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
    var0.setPlot(var5);
    java.awt.Paint var8 = var0.getErrorIndicatorPaint();
    java.awt.Paint var9 = var0.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var13 = var11.getSeriesNegativeItemLabelPosition(100);
    boolean var15 = var11.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var17 = var16.getFixedLegendItems();
    var11.setPlot(var16);
    java.awt.Paint var19 = var16.getBackgroundPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPaint((-1), var19, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(100);
//     boolean var14 = var10.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var16 = var15.getFixedLegendItems();
//     var10.setPlot(var15);
//     java.awt.Paint var18 = var10.getErrorIndicatorPaint();
//     java.awt.Paint var19 = var10.getBaseOutlinePaint();
//     var0.setSeriesPaint(1, var19, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var0.", var10.equals(var0) == var0.equals(var10));
//     
//     // Checks the contract:  equals-hashcode on var2 and var12
//     assertTrue("Contract failed: equals-hashcode on var2 and var12", var2.equals(var12) ? var2.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var2
//     assertTrue("Contract failed: equals-hashcode on var12 and var2", var12.equals(var2) ? var12.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var15
//     assertTrue("Contract failed: equals-hashcode on var5 and var15", var5.equals(var15) ? var5.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var5
//     assertTrue("Contract failed: equals-hashcode on var15 and var5", var15.equals(var5) ? var15.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("Category Plot", (-1), (-16777216));
// 
//   }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     java.awt.Stroke var2 = var0.getOutlineStroke();
//     java.awt.Stroke var3 = var0.getOutlineStroke();
//     org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxis();
//     float var5 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var8 = var6.getSeriesNegativeItemLabelPosition(100);
//     boolean var10 = var6.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var12 = var11.getFixedLegendItems();
//     var6.setPlot(var11);
//     java.awt.Paint var14 = var11.getBackgroundPaint();
//     org.jfree.chart.LegendItemCollection var15 = var11.getFixedLegendItems();
//     java.awt.Paint var16 = var11.getRangeCrosshairPaint();
//     var0.setNoDataMessagePaint(var16);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var19 = var18.getInsets();
//     double var20 = var19.getLeft();
//     double var22 = var19.calculateLeftOutset(0.0d);
//     var0.setInsets(var19, false);
//     
//     // Checks the contract:  equals-hashcode on var11 and var18
//     assertTrue("Contract failed: equals-hashcode on var11 and var18", var11.equals(var18) ? var11.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var11
//     assertTrue("Contract failed: equals-hashcode on var18 and var11", var18.equals(var11) ? var18.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.zoomRange(0.0d, 100.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
//     boolean var8 = var4.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var10 = var9.getFixedLegendItems();
//     var4.setPlot(var9);
//     java.awt.Paint var12 = var9.getBackgroundPaint();
//     var0.setPlot((org.jfree.chart.plot.Plot)var9);
//     org.jfree.chart.axis.NumberTickUnit var14 = var0.getTickUnit();
//     var0.setAutoTickUnitSelection(false);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var18 = var17.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var19 = var17.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var22 = var20.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var25 = var20.getItemLabelPaint(0, 10);
//     var17.setNoDataMessagePaint(var25);
//     var17.configureDomainAxes();
//     boolean var28 = var0.hasListener((java.util.EventListener)var17);
//     
//     // Checks the contract:  equals-hashcode on var6 and var22
//     assertTrue("Contract failed: equals-hashcode on var6 and var22", var6.equals(var22) ? var6.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var6
//     assertTrue("Contract failed: equals-hashcode on var22 and var6", var22.equals(var6) ? var22.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var17
//     assertTrue("Contract failed: equals-hashcode on var9 and var17", var9.equals(var17) ? var9.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var9
//     assertTrue("Contract failed: equals-hashcode on var17 and var9", var17.equals(var9) ? var17.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.text.TextAnchor var3 = var2.getTextAnchor();
//     org.jfree.chart.labels.ItemLabelAnchor var4 = var2.getItemLabelAnchor();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.text.TextAnchor var8 = var7.getTextAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var9 = new org.jfree.chart.labels.ItemLabelPosition(var4, var8);
//     
//     // Checks the contract:  equals-hashcode on var2 and var7
//     assertTrue("Contract failed: equals-hashcode on var2 and var7", var2.equals(var7) ? var2.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var9
//     assertTrue("Contract failed: equals-hashcode on var2 and var9", var2.equals(var9) ? var2.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var2
//     assertTrue("Contract failed: equals-hashcode on var7 and var2", var7.equals(var2) ? var7.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var9
//     assertTrue("Contract failed: equals-hashcode on var7 and var9", var7.equals(var9) ? var7.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var2
//     assertTrue("Contract failed: equals-hashcode on var9 and var2", var9.equals(var2) ? var9.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var7
//     assertTrue("Contract failed: equals-hashcode on var9 and var7", var9.equals(var7) ? var9.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
//     var0.setNoDataMessagePaint(var8);
//     var0.configureDomainAxes();
//     boolean var11 = var0.isSubplot();
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var14 = var13.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var15 = var13.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var21 = var16.getItemLabelPaint(0, 10);
//     var13.setNoDataMessagePaint(var21);
//     var13.configureDomainAxes();
//     float var24 = var13.getBackgroundAlpha();
//     org.jfree.chart.axis.AxisLocation var26 = var13.getDomainAxisLocation(1);
//     org.jfree.chart.axis.AxisLocation var27 = var26.getOpposite();
//     java.lang.Object var28 = null;
//     boolean var29 = var26.equals(var28);
//     var0.setRangeAxisLocation(100, var26, true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var0
//     assertTrue("Contract failed: equals-hashcode on var13 and var0", var13.equals(var0) ? var13.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var13 and var0.", var13.equals(var0) == var0.equals(var13));
//     
//     // Checks the contract:  equals-hashcode on var5 and var18
//     assertTrue("Contract failed: equals-hashcode on var5 and var18", var5.equals(var18) ? var5.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var5
//     assertTrue("Contract failed: equals-hashcode on var18 and var5", var18.equals(var5) ? var18.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
//     var0.setNoDataMessagePaint(var8);
//     var0.configureDomainAxes();
//     float var11 = var0.getBackgroundAlpha();
//     org.jfree.chart.axis.AxisLocation var13 = var0.getDomainAxisLocation(1);
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     var0.drawBackground(var14, var15);
// 
//   }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var2 = null;
//     var1.notifyListeners(var2);
//     var1.setValue((-1.0d));
//     java.awt.Stroke var6 = var1.getOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var8 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var9 = null;
//     var8.notifyListeners(var9);
//     var8.setValue((-1.0d));
//     java.awt.Font var14 = null;
//     java.awt.Paint var15 = null;
//     org.jfree.chart.text.TextMeasurer var18 = null;
//     org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, var15, 0.0f, 1, var18);
//     java.util.List var20 = var19.getLines();
//     boolean var21 = var8.equals((java.lang.Object)var20);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var23 = var22.getFixedLegendItems();
//     var8.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var22);
//     var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var22);
//     
//     // Checks the contract:  equals-hashcode on var1 and var8
//     assertTrue("Contract failed: equals-hashcode on var1 and var8", var1.equals(var8) ? var1.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var1
//     assertTrue("Contract failed: equals-hashcode on var8 and var1", var8.equals(var1) ? var8.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     var0.setBaseSeriesVisible(true, true);
//     boolean var14 = var0.equals((java.lang.Object)1.0d);
//     java.lang.Boolean var16 = var0.getSeriesVisibleInLegend((-1));
//     java.awt.Graphics2D var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.axis.CategoryAxis var19 = null;
//     org.jfree.data.Range var20 = null;
//     org.jfree.data.Range var22 = org.jfree.data.Range.expandToInclude(var20, 1.0d);
//     double var24 = var22.constrain((-1.0d));
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var27 = var26.getInsets();
//     java.lang.String var28 = var27.toString();
//     var25.setTickLabelInsets(var27);
//     boolean var30 = var22.equals((java.lang.Object)var25);
//     var25.setLabelToolTip("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
//     var25.setLabel("");
//     org.jfree.chart.util.Layer var35 = null;
//     org.jfree.chart.ChartRenderingInfo var36 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var37 = new org.jfree.chart.plot.PlotRenderingInfo(var36);
//     var0.drawAnnotations(var17, var18, var19, (org.jfree.chart.axis.ValueAxis)var25, var35, var37);
// 
//   }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Paint var2 = null;
//     org.jfree.chart.text.TextMeasurer var5 = null;
//     org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 0.0f, 1, var5);
//     org.jfree.chart.text.TextLine var7 = null;
//     var6.addLine(var7);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var13 = var11.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var14 = null;
//     var11.setBaseURLGenerator(var14, true);
//     int var17 = var11.getColumnCount();
//     java.awt.Font var18 = var11.getBaseItemLabelFont();
//     java.awt.Color var22 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var23 = var22.getRed();
//     org.jfree.chart.text.TextLine var24 = new org.jfree.chart.text.TextLine("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var18, (java.awt.Paint)var22);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var27 = var25.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var28 = null;
//     var25.setBaseURLGenerator(var28, true);
//     int var31 = var25.getColumnCount();
//     boolean var32 = var25.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var34 = null;
//     var25.setSeriesPaint(10, var34);
//     java.awt.Paint var36 = var25.getBasePaint();
//     var6.addLine("Category Plot", var18, var36);
//     
//     // Checks the contract:  equals-hashcode on var13 and var27
//     assertTrue("Contract failed: equals-hashcode on var13 and var27", var13.equals(var27) ? var13.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var13
//     assertTrue("Contract failed: equals-hashcode on var27 and var13", var27.equals(var13) ? var27.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     int var8 = var0.getRowCount();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var11 = var10.getFixedLegendItems();
//     java.awt.Stroke var12 = var10.getOutlineStroke();
//     java.awt.Stroke var13 = var10.getOutlineStroke();
//     org.jfree.chart.axis.ValueAxis var14 = var10.getRangeAxis();
//     var10.setDomainGridlinesVisible(true);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var20 = var18.getSeriesNegativeItemLabelPosition(100);
//     boolean var22 = var18.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var24 = var23.getFixedLegendItems();
//     var18.setPlot(var23);
//     java.awt.Paint var26 = var18.getErrorIndicatorPaint();
//     java.awt.Paint var27 = var18.getBaseOutlinePaint();
//     boolean var29 = var18.isSeriesVisible(0);
//     var10.setRenderer(10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18, false);
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     java.awt.geom.Rectangle2D var33 = null;
//     var0.drawRangeGridline(var9, var10, var32, var33, (-5.0d));
// 
//   }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.text.TextAnchor var3 = var2.getTextAnchor();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.clearDomainMarkers(1);
//     java.awt.Image var7 = var4.getBackgroundImage();
//     float var8 = var4.getForegroundAlpha();
//     boolean var9 = var2.equals((java.lang.Object)var8);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var11 = var10.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var12 = var10.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var15 = var13.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var18 = var13.getItemLabelPaint(0, 10);
//     var10.setNoDataMessagePaint(var18);
//     org.jfree.chart.JFreeChart var20 = null;
//     org.jfree.chart.event.ChartChangeEvent var21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var10, var20);
//     boolean var22 = var2.equals((java.lang.Object)var10);
//     
//     // Checks the contract:  equals-hashcode on var2 and var15
//     assertTrue("Contract failed: equals-hashcode on var2 and var15", var2.equals(var15) ? var2.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var2
//     assertTrue("Contract failed: equals-hashcode on var15 and var2", var15.equals(var2) ? var15.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var10
//     assertTrue("Contract failed: equals-hashcode on var4 and var10", var4.equals(var10) ? var4.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var4
//     assertTrue("Contract failed: equals-hashcode on var10 and var4", var10.equals(var4) ? var10.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("hi!");
    boolean var3 = var1.equals((java.lang.Object)"Category Plot");
    var1.setToolTipText("hi!");
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var8 = var7.getInsets();
    java.lang.String var9 = var8.toString();
    var6.setTickLabelInsets(var8);
    double var12 = var8.calculateLeftInset(0.0d);
    double var14 = var8.calculateLeftOutset(0.0d);
    var1.setPadding(var8);
    org.jfree.chart.util.VerticalAlignment var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setVerticalAlignment(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"+ "'", var9.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 8.0d);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.ClassLoader var1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var0);
// 
//   }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     boolean var11 = var0.isSeriesVisible(0);
//     java.awt.Paint var12 = null;
//     var0.setErrorIndicatorPaint(var12);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var0.getLegendItemLabelGenerator();
//     java.awt.Stroke var17 = var0.getItemStroke(1, 10);
//     java.awt.Paint var19 = null;
//     var0.setSeriesFillPaint(10, var19, true);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var25 = var23.getSeriesNegativeItemLabelPosition(100);
//     boolean var27 = var23.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var29 = var28.getFixedLegendItems();
//     var23.setPlot(var28);
//     java.awt.Paint var31 = var28.getBackgroundPaint();
//     org.jfree.chart.LegendItemCollection var32 = var28.getFixedLegendItems();
//     java.awt.Paint var33 = var28.getRangeCrosshairPaint();
//     org.jfree.chart.block.BlockBorder var34 = new org.jfree.chart.block.BlockBorder(var33);
//     var0.setSeriesOutlinePaint(10, var33);
//     
//     // Checks the contract:  equals-hashcode on var2 and var25
//     assertTrue("Contract failed: equals-hashcode on var2 and var25", var2.equals(var25) ? var2.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var2
//     assertTrue("Contract failed: equals-hashcode on var25 and var2", var25.equals(var2) ? var25.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var28
//     assertTrue("Contract failed: equals-hashcode on var5 and var28", var5.equals(var28) ? var5.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var5
//     assertTrue("Contract failed: equals-hashcode on var28 and var5", var28.equals(var5) ? var28.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, 1.0d);
//     double var4 = var2.constrain((-1.0d));
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
//     java.lang.String var8 = var7.toString();
//     var5.setTickLabelInsets(var7);
//     boolean var10 = var2.equals((java.lang.Object)var5);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var12 = var11.getInsets();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var15 = var13.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var18 = var13.getItemLabelPaint(0, 10);
//     var13.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     boolean var22 = var12.equals((java.lang.Object)true);
//     double var24 = var12.calculateLeftOutset(8.0d);
//     var5.setLabelInsets(var12);
//     
//     // Checks the contract:  equals-hashcode on var6 and var11
//     assertTrue("Contract failed: equals-hashcode on var6 and var11", var6.equals(var11) ? var6.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var6
//     assertTrue("Contract failed: equals-hashcode on var11 and var6", var11.equals(var6) ? var11.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var2 = var1.getInsets();
    java.lang.String var3 = var2.toString();
    boolean var4 = var0.equals((java.lang.Object)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"+ "'", var3.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     double var1 = var0.getContentXOffset();
//     org.jfree.chart.util.HorizontalAlignment var2 = null;
//     org.jfree.chart.util.VerticalAlignment var3 = null;
//     org.jfree.chart.block.FlowArrangement var6 = new org.jfree.chart.block.FlowArrangement(var2, var3, 100.0d, 0.0d);
//     var0.setArrangement((org.jfree.chart.block.Arrangement)var6);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var11 = var9.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var12 = null;
//     var9.setBaseURLGenerator(var12, true);
//     int var15 = var9.getColumnCount();
//     java.awt.Font var16 = var9.getBaseItemLabelFont();
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("", var16);
//     var17.setText("");
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var22 = var20.getSeriesNegativeItemLabelPosition(100);
//     boolean var24 = var20.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var26 = var25.getFixedLegendItems();
//     var20.setPlot(var25);
//     java.awt.Paint var28 = var20.getErrorIndicatorPaint();
//     java.awt.Paint var29 = var20.getBaseOutlinePaint();
//     var20.setBaseSeriesVisible(true, true);
//     boolean var34 = var20.equals((java.lang.Object)1.0d);
//     double var35 = var20.getBase();
//     var0.add((org.jfree.chart.block.Block)var17, (java.lang.Object)var20);
//     
//     // Checks the contract:  equals-hashcode on var11 and var22
//     assertTrue("Contract failed: equals-hashcode on var11 and var22", var11.equals(var22) ? var11.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var11
//     assertTrue("Contract failed: equals-hashcode on var22 and var11", var22.equals(var11) ? var22.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.zoomRange(0.0d, 100.0d);
    java.text.NumberFormat var4 = null;
    var0.setNumberFormatOverride(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(100.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.urls.CategoryURLGenerator var3 = null;
    var0.setBaseURLGenerator(var3, true);
    int var6 = var0.getColumnCount();
    boolean var7 = var0.getBaseSeriesVisibleInLegend();
    boolean var8 = var0.getBaseItemLabelsVisible();
    java.awt.Paint var10 = var0.getSeriesOutlinePaint(0);
    org.jfree.chart.event.RendererChangeListener var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addChangeListener(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(100.0d, 0.0d, var2);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit(100.0d, var1, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.zoomRange(100.0d, 100.0d);
//     var0.setLowerBound(10.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var8 = var6.getSeriesNegativeItemLabelPosition(100);
//     boolean var10 = var6.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var12 = var11.getFixedLegendItems();
//     var6.setPlot(var11);
//     java.awt.Paint var14 = var6.getErrorIndicatorPaint();
//     var6.setBase(100.0d);
//     boolean var19 = var6.getItemVisible(1, 1);
//     java.awt.Shape var21 = var6.lookupSeriesShape(100);
//     var0.setRightArrow(var21);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var24 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var26 = var24.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var27 = null;
//     var24.setBaseURLGenerator(var27, true);
//     int var30 = var24.getColumnCount();
//     java.awt.Font var31 = var24.getBaseItemLabelFont();
//     java.awt.Color var35 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var36 = var35.getRed();
//     org.jfree.chart.text.TextLine var37 = new org.jfree.chart.text.TextLine("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var31, (java.awt.Paint)var35);
//     var0.setTickLabelFont(var31);
//     
//     // Checks the contract:  equals-hashcode on var8 and var26
//     assertTrue("Contract failed: equals-hashcode on var8 and var26", var8.equals(var26) ? var8.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var8
//     assertTrue("Contract failed: equals-hashcode on var26 and var8", var26.equals(var8) ? var26.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var1 = var0.getCategoryAnchor();
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var3 = new org.jfree.chart.axis.CategoryLabelPosition(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var5.getBackgroundPaint();
//     org.jfree.chart.LegendItemCollection var9 = var5.getFixedLegendItems();
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     var5.drawOutline(var10, var11);
// 
//   }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     double var1 = var0.getMinimumBarLength();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.plot.CategoryPlot var3 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     double var5 = var4.getFixedAutoRange();
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 1.0d);
//     double var10 = var8.constrain((-1.0d));
//     var4.setDefaultAutoRange(var8);
//     java.awt.geom.Rectangle2D var12 = null;
//     var0.drawRangeGridline(var2, var3, (org.jfree.chart.axis.ValueAxis)var4, var12, 1.0E-8d);
// 
//   }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.zoomRange(0.0d, 100.0d);
    java.awt.Stroke var4 = var0.getTickMarkStroke();
    boolean var5 = var0.isAutoRange();
    double var6 = var0.getUpperBound();
    java.lang.String var7 = var0.getLabelToolTip();
    double var8 = var0.getLowerMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.05d);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = var0.getSeriesToolTipGenerator((-16777216));
    org.jfree.chart.annotations.CategoryAnnotation var3 = null;
    org.jfree.chart.util.Layer var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(0.05d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
    var0.setNoDataMessagePaint(var8);
    var0.configureDomainAxes();
    float var11 = var0.getBackgroundAlpha();
    var0.setRangeCrosshairLockedOnData(true);
    org.jfree.data.category.CategoryDataset var15 = var0.getDataset(100);
    org.jfree.chart.plot.CategoryMarker var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var3 = null;
//     var0.setBaseURLGenerator(var3, true);
//     int var6 = var0.getColumnCount();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var10 = var8.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var11 = null;
//     var8.setBaseURLGenerator(var11, true);
//     int var14 = var8.getColumnCount();
//     java.awt.Font var15 = var8.getBaseItemLabelFont();
//     var0.setSeriesItemLabelFont(10, var15, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var8 and var0.", var8.equals(var0) == var0.equals(var8));
//     
//     // Checks the contract:  equals-hashcode on var2 and var10
//     assertTrue("Contract failed: equals-hashcode on var2 and var10", var2.equals(var10) ? var2.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var2
//     assertTrue("Contract failed: equals-hashcode on var10 and var2", var10.equals(var2) ? var10.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var5 = null;
    org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 0.0f, 1, var5);
    java.util.List var7 = var6.getLines();
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.text.TextBlockAnchor var11 = null;
    java.awt.Shape var15 = var6.calculateBounds(var8, (-1.0f), 10.0f, var11, 1.0f, 0.0f, 0.0d);
    org.jfree.chart.text.TextLine var16 = var6.getLastLine();
    org.jfree.chart.util.HorizontalAlignment var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setLineAlignment(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.text.TextAnchor var3 = var2.getTextAnchor();
//     org.jfree.chart.labels.ItemLabelAnchor var4 = var2.getItemLabelAnchor();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.text.TextAnchor var8 = var7.getTextAnchor();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var11 = var9.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.text.TextAnchor var12 = var11.getTextAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var14 = new org.jfree.chart.labels.ItemLabelPosition(var4, var8, var12, 0.0d);
//     
//     // Checks the contract:  equals-hashcode on var2 and var7
//     assertTrue("Contract failed: equals-hashcode on var2 and var7", var2.equals(var7) ? var2.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var11
//     assertTrue("Contract failed: equals-hashcode on var2 and var11", var2.equals(var11) ? var2.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var2
//     assertTrue("Contract failed: equals-hashcode on var7 and var2", var7.equals(var2) ? var7.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var11
//     assertTrue("Contract failed: equals-hashcode on var7 and var11", var7.equals(var11) ? var7.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var2
//     assertTrue("Contract failed: equals-hashcode on var11 and var2", var11.equals(var2) ? var11.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var7
//     assertTrue("Contract failed: equals-hashcode on var11 and var7", var11.equals(var7) ? var11.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    java.awt.Stroke var2 = var0.getOutlineStroke();
    java.awt.Stroke var3 = var0.getOutlineStroke();
    var0.setOutlineVisible(false);
    org.jfree.chart.axis.AxisLocation var7 = var0.getDomainAxisLocation(0);
    org.jfree.chart.plot.CategoryMarker var9 = null;
    org.jfree.chart.util.Layer var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(255, var9, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Paint var2 = null;
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.text.G2TextMeasurer var5 = new org.jfree.chart.text.G2TextMeasurer(var4);
//     org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var1, var2, (-1.0f), (org.jfree.chart.text.TextMeasurer)var5);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getFixedAutoRange();
    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 1.0d);
    double var6 = var4.constrain((-1.0d));
    var0.setDefaultAutoRange(var4);
    boolean var8 = var0.isNegativeArrowVisible();
    org.jfree.chart.plot.Plot var9 = var0.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var1, var2);
// 
//   }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var2 = var1.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var3 = var1.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var9 = var4.getItemLabelPaint(0, 10);
//     var1.setNoDataMessagePaint(var9);
//     var1.configureDomainAxes();
//     float var12 = var1.getBackgroundAlpha();
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var15 = var14.getFixedLegendItems();
//     java.awt.Stroke var16 = var14.getOutlineStroke();
//     java.awt.Stroke var17 = var14.getOutlineStroke();
//     org.jfree.chart.axis.ValueAxis var18 = var14.getRangeAxis();
//     float var19 = var14.getBackgroundImageAlpha();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var22 = var20.getSeriesNegativeItemLabelPosition(100);
//     boolean var24 = var20.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var26 = var25.getFixedLegendItems();
//     var20.setPlot(var25);
//     java.awt.Paint var28 = var25.getBackgroundPaint();
//     org.jfree.chart.LegendItemCollection var29 = var25.getFixedLegendItems();
//     java.awt.Paint var30 = var25.getRangeCrosshairPaint();
//     var14.setNoDataMessagePaint(var30);
//     var13.setBorderPaint(var30);
//     
//     // Checks the contract:  equals-hashcode on var1 and var25
//     assertTrue("Contract failed: equals-hashcode on var1 and var25", var1.equals(var25) ? var1.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var1
//     assertTrue("Contract failed: equals-hashcode on var25 and var1", var25.equals(var1) ? var25.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var22
//     assertTrue("Contract failed: equals-hashcode on var6 and var22", var6.equals(var22) ? var6.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var6
//     assertTrue("Contract failed: equals-hashcode on var22 and var6", var22.equals(var6) ? var22.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var11 = var0.getSeriesItemLabelGenerator((-1));
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = null;
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     org.jfree.chart.plot.CategoryMarker var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     var0.drawDomainMarker(var12, var13, var14, var15, var16);
// 
//   }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     var0.setSeriesVisibleInLegend(100, (java.lang.Boolean)false, true);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var16 = var14.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.text.TextAnchor var17 = var16.getTextAnchor();
//     org.jfree.chart.labels.ItemLabelAnchor var18 = var16.getItemLabelAnchor();
//     var0.setBaseNegativeItemLabelPosition(var16, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var14 and var0.", var14.equals(var0) == var0.equals(var14));
//     
//     // Checks the contract:  equals-hashcode on var2 and var16
//     assertTrue("Contract failed: equals-hashcode on var2 and var16", var2.equals(var16) ? var2.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var2
//     assertTrue("Contract failed: equals-hashcode on var16 and var2", var16.equals(var2) ? var16.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(100);
//     boolean var14 = var10.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var16 = var15.getFixedLegendItems();
//     var10.setPlot(var15);
//     java.awt.Paint var18 = var10.getErrorIndicatorPaint();
//     java.awt.Paint var19 = var10.getBaseOutlinePaint();
//     boolean var21 = var10.isSeriesVisible(0);
//     java.awt.Paint var22 = null;
//     var10.setErrorIndicatorPaint(var22);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var24 = var10.getLegendItemLabelGenerator();
//     java.awt.Stroke var27 = var10.getItemStroke(1, 10);
//     var8.setSeriesOutlineStroke(255, var27);
//     var5.setRangeCrosshairStroke(var27);
//     
//     // Checks the contract:  equals-hashcode on var2 and var12
//     assertTrue("Contract failed: equals-hashcode on var2 and var12", var2.equals(var12) ? var2.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var2
//     assertTrue("Contract failed: equals-hashcode on var12 and var2", var12.equals(var2) ? var12.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)100, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var2 = null;
//     var1.notifyListeners(var2);
//     var1.setValue((-1.0d));
//     org.jfree.chart.util.RectangleInsets var6 = var1.getLabelOffset();
//     double var8 = var6.trimHeight(0.0d);
//     double var10 = var6.calculateBottomOutset(100.0d);
//     double var12 = var6.trimHeight(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-6.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == Double.NaN);
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
    var0.setPlot(var5);
    java.awt.Paint var8 = var5.getBackgroundPaint();
    org.jfree.chart.LegendItemCollection var9 = var5.getFixedLegendItems();
    java.awt.Paint var10 = var5.getRangeCrosshairPaint();
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.DatasetGroup var13 = var12.getDatasetGroup();
    org.jfree.chart.axis.AxisLocation var14 = var12.getRangeAxisLocation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setRangeAxisLocation((-16777216), var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("Category Plot");

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)(-1), 0.05d, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     double var1 = var0.getMinimumBarLength();
//     java.awt.Paint var2 = var0.getErrorIndicatorPaint();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.clearDomainMarkers(1);
//     java.awt.geom.Rectangle2D var7 = null;
//     var0.drawBackground(var3, var4, var7);
// 
//   }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
//     org.jfree.chart.LegendItemCollection var1 = new org.jfree.chart.LegendItemCollection();
//     org.jfree.chart.LegendItem var2 = null;
//     var1.add(var2);
//     var0.addAll(var1);
//     
//     // Checks the contract:  equals-hashcode on var0 and var1
//     assertTrue("Contract failed: equals-hashcode on var0 and var1", var0.equals(var1) ? var0.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var0
//     assertTrue("Contract failed: equals-hashcode on var1 and var0", var1.equals(var0) ? var1.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var2 = var0.get((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.zoomRange(0.0d, 100.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
//     boolean var8 = var4.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var10 = var9.getFixedLegendItems();
//     var4.setPlot(var9);
//     java.awt.Paint var12 = var9.getBackgroundPaint();
//     var0.setPlot((org.jfree.chart.plot.Plot)var9);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var17 = var15.getSeriesNegativeItemLabelPosition(100);
//     boolean var19 = var15.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var21 = var20.getFixedLegendItems();
//     var15.setPlot(var20);
//     java.awt.Paint var23 = var15.getErrorIndicatorPaint();
//     java.awt.Paint var24 = var15.getBaseOutlinePaint();
//     boolean var26 = var15.isSeriesVisible(0);
//     java.awt.Paint var27 = null;
//     var15.setErrorIndicatorPaint(var27);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var29 = var15.getLegendItemLabelGenerator();
//     var9.setRenderer(100, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     
//     // Checks the contract:  equals-hashcode on var6 and var17
//     assertTrue("Contract failed: equals-hashcode on var6 and var17", var6.equals(var17) ? var6.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var6
//     assertTrue("Contract failed: equals-hashcode on var17 and var6", var17.equals(var6) ? var17.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var9
//     assertTrue("Contract failed: equals-hashcode on var20 and var9", var20.equals(var9) ? var20.hashCode() == var9.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var20 and var9.", var20.equals(var9) == var9.equals(var20));
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var5 = var0.getItemLabelPaint(0, 10);
    java.awt.Stroke var7 = var0.getSeriesStroke(1);
    java.awt.Color var11 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    var0.setBaseItemLabelPaint((java.awt.Paint)var11);
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var0.getSeriesItemLabelGenerator(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(1);
    java.awt.Image var3 = var0.getBackgroundImage();
    float var4 = var0.getForegroundAlpha();
    java.awt.Image var5 = null;
    var0.setBackgroundImage(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0f);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.RectangleInsets var2 = var1.getPadding();
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.event.MarkerChangeEvent var6 = null;
    var5.notifyListeners(var6);
    var5.setValue((-1.0d));
    java.awt.Stroke var10 = var5.getOutlineStroke();
    org.jfree.chart.util.LengthAdjustmentType var11 = var5.getLabelOffsetType();
    org.jfree.chart.util.LengthAdjustmentType var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var13 = var2.createAdjustedRectangle(var3, var11, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
//     var0.setNoDataMessagePaint(var8);
//     java.awt.Paint var10 = var0.getBackgroundPaint();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var13 = var12.getInsets();
//     java.lang.String var14 = var13.toString();
//     var11.setTickLabelInsets(var13);
//     double var17 = var13.calculateLeftInset(0.0d);
//     org.jfree.chart.util.UnitType var18 = var13.getUnitType();
//     var0.setInsets(var13, true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var12
//     assertTrue("Contract failed: equals-hashcode on var0 and var12", var0.equals(var12) ? var0.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var0
//     assertTrue("Contract failed: equals-hashcode on var12 and var0", var12.equals(var0) ? var12.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     java.awt.Stroke var2 = var0.getOutlineStroke();
//     var0.setDrawSharedDomainAxis(true);
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
//     java.lang.String var8 = var7.toString();
//     var5.setTickLabelInsets(var7);
//     var0.setAxisOffset(var7);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.clearDomainMarkers(1);
//     java.awt.Image var14 = var11.getBackgroundImage();
//     float var15 = var11.getForegroundAlpha();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var17 = var16.getFixedLegendItems();
//     java.awt.Stroke var18 = var16.getOutlineStroke();
//     org.jfree.chart.axis.AxisLocation var20 = var16.getRangeAxisLocation(10);
//     var11.setRangeAxisLocation(var20, true);
//     var0.setRangeAxisLocation(var20);
//     
//     // Checks the contract:  equals-hashcode on var6 and var16
//     assertTrue("Contract failed: equals-hashcode on var6 and var16", var6.equals(var16) ? var6.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var6
//     assertTrue("Contract failed: equals-hashcode on var16 and var6", var16.equals(var6) ? var16.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    org.jfree.chart.LegendItem var1 = null;
    var0.add(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var4 = var0.get((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 4.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var0 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"+ "'", var0.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var3 = var0.getBaseFillPaint();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var0.getBaseItemLabelGenerator();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     var5.zoomRange(0.0d, 100.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var11 = var9.getSeriesNegativeItemLabelPosition(100);
//     boolean var13 = var9.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var15 = var14.getFixedLegendItems();
//     var9.setPlot(var14);
//     java.awt.Paint var17 = var14.getBackgroundPaint();
//     var5.setPlot((org.jfree.chart.plot.Plot)var14);
//     java.util.List var19 = var14.getCategories();
//     boolean var20 = var0.hasListener((java.util.EventListener)var14);
//     
//     // Checks the contract:  equals-hashcode on var2 and var11
//     assertTrue("Contract failed: equals-hashcode on var2 and var11", var2.equals(var11) ? var2.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var2
//     assertTrue("Contract failed: equals-hashcode on var11 and var2", var11.equals(var2) ? var11.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var3 = null;
//     var0.setBaseURLGenerator(var3, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var0.getBaseItemLabelGenerator();
//     java.lang.Boolean var8 = var0.getSeriesItemLabelsVisible(10);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var11 = var9.getSeriesNegativeItemLabelPosition(100);
//     boolean var13 = var9.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var15 = var14.getFixedLegendItems();
//     var9.setPlot(var14);
//     java.awt.Paint var17 = var9.getErrorIndicatorPaint();
//     java.awt.Paint var18 = var9.getBaseOutlinePaint();
//     boolean var20 = var9.isSeriesVisible(0);
//     org.jfree.chart.labels.CategoryToolTipGenerator var21 = null;
//     var9.setBaseToolTipGenerator(var21);
//     org.jfree.chart.labels.ItemLabelPosition var24 = var9.getSeriesPositiveItemLabelPosition(255);
//     var0.setBasePositiveItemLabelPosition(var24, true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var11
//     assertTrue("Contract failed: equals-hashcode on var2 and var11", var2.equals(var11) ? var2.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var2
//     assertTrue("Contract failed: equals-hashcode on var11 and var2", var11.equals(var2) ? var11.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var2 = null;
//     var1.notifyListeners(var2);
//     var1.setValue((-1.0d));
//     java.awt.Font var7 = null;
//     java.awt.Paint var8 = null;
//     org.jfree.chart.text.TextMeasurer var11 = null;
//     org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var7, var8, 0.0f, 1, var11);
//     java.util.List var13 = var12.getLines();
//     boolean var14 = var1.equals((java.lang.Object)var13);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var16 = var15.getFixedLegendItems();
//     var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var15);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var20 = var18.getSeriesNegativeItemLabelPosition(100);
//     boolean var22 = var18.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var24 = var23.getFixedLegendItems();
//     var18.setPlot(var23);
//     java.awt.Paint var26 = var23.getBackgroundPaint();
//     org.jfree.chart.LegendItemCollection var27 = var23.getFixedLegendItems();
//     java.awt.Paint var28 = var23.getRangeCrosshairPaint();
//     var23.clearRangeMarkers((-1));
//     java.awt.Paint var31 = var23.getRangeGridlinePaint();
//     var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var23);
//     
//     // Checks the contract:  equals-hashcode on var15 and var23
//     assertTrue("Contract failed: equals-hashcode on var15 and var23", var15.equals(var23) ? var15.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var15
//     assertTrue("Contract failed: equals-hashcode on var23 and var15", var23.equals(var15) ? var23.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(1);
//     java.awt.Image var3 = var0.getBackgroundImage();
//     org.jfree.chart.util.SortOrder var4 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var5 = null;
//     int var6 = var0.getDomainAxisIndex(var5);
//     org.jfree.data.Range var8 = null;
//     org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 1.0d);
//     double var12 = var10.constrain((-1.0d));
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var15 = var14.getInsets();
//     java.lang.String var16 = var15.toString();
//     var13.setTickLabelInsets(var15);
//     boolean var18 = var10.equals((java.lang.Object)var13);
//     var13.setLabelToolTip("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
//     var0.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis)var13, false);
//     
//     // Checks the contract:  equals-hashcode on var14 and var0
//     assertTrue("Contract failed: equals-hashcode on var14 and var0", var14.equals(var0) ? var14.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var14 and var0.", var14.equals(var0) == var0.equals(var14));
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    var0.setAutoPopulateSeriesPaint(false);
    java.lang.Object var7 = var0.clone();
    boolean var8 = var0.getIncludeBaseInRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    java.lang.Object var2 = var0.get(10);
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var5 = var4.getFixedLegendItems();
    java.awt.Stroke var6 = var4.getOutlineStroke();
    var4.setDrawSharedDomainAxis(true);
    org.jfree.chart.util.RectangleEdge var9 = var4.getDomainAxisEdge();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.set((-1), (java.lang.Object)var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.axis.AxisState var2 = null;
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    java.util.List var5 = var0.refreshTicks(var1, var2, var3, var4);
    boolean var6 = var0.isTickMarksVisible();
    java.awt.Stroke var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAxisLineStroke(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var3 = null;
//     var0.setBaseURLGenerator(var3, true);
//     int var6 = var0.getColumnCount();
//     boolean var7 = var0.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var10 = var0.getItemFillPaint(10, 0);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var14 = var12.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var15 = null;
//     var12.setBaseURLGenerator(var15, true);
//     org.jfree.chart.labels.ItemLabelPosition var20 = var12.getPositiveItemLabelPosition((-1), 100);
//     var0.setSeriesPositiveItemLabelPosition(0, var20, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var12 and var0.", var12.equals(var0) == var0.equals(var12));
//     
//     // Checks the contract:  equals-hashcode on var2 and var14
//     assertTrue("Contract failed: equals-hashcode on var2 and var14", var2.equals(var14) ? var2.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var2
//     assertTrue("Contract failed: equals-hashcode on var14 and var2", var14.equals(var2) ? var14.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.awt.Stroke var1 = var0.getBaseOutlineStroke();
//     boolean var3 = var0.isSeriesVisible(10);
//     java.awt.Stroke var5 = null;
//     var0.setSeriesStroke(10, var5, true);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(100);
//     boolean var14 = var10.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var16 = var15.getFixedLegendItems();
//     var10.setPlot(var15);
//     java.awt.Paint var18 = var15.getBackgroundPaint();
//     java.awt.Font var19 = var15.getNoDataMessageFont();
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("", var19);
//     var0.setSeriesItemLabelFont(0, var19, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var0.", var10.equals(var0) == var0.equals(var10));
// 
//   }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var1 = new org.jfree.chart.entity.ChartEntity(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var2 = var1.getInsets();
//     java.lang.String var3 = var2.toString();
//     var0.setTickLabelInsets(var2);
//     double var6 = var2.calculateLeftInset(0.0d);
//     org.jfree.chart.util.UnitType var7 = var2.getUnitType();
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
//     var8.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var12 = var8.getTickMarkStroke();
//     boolean var13 = var8.isAutoRange();
//     double var14 = var8.getUpperBound();
//     boolean var15 = var7.equals((java.lang.Object)var8);
//     double var16 = var8.getLowerBound();
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     var17.clearDomainMarkers(1);
//     java.awt.Paint var20 = var17.getRangeCrosshairPaint();
//     var8.setLabelPaint(var20);
//     
//     // Checks the contract:  equals-hashcode on var1 and var17
//     assertTrue("Contract failed: equals-hashcode on var1 and var17", var1.equals(var17) ? var1.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var1
//     assertTrue("Contract failed: equals-hashcode on var17 and var1", var17.equals(var1) ? var17.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
//     var0.setNoDataMessagePaint(var8);
//     var0.configureDomainAxes();
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var12 = var11.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var13 = var11.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var16 = var14.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var19 = var14.getItemLabelPaint(0, 10);
//     var11.setNoDataMessagePaint(var19);
//     org.jfree.chart.JFreeChart var21 = null;
//     org.jfree.chart.event.ChartChangeEvent var22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var11, var21);
//     org.jfree.chart.axis.CategoryAnchor var23 = var11.getDomainGridlinePosition();
//     var0.setDomainGridlinePosition(var23);
//     
//     // Checks the contract:  equals-hashcode on var0 and var11
//     assertTrue("Contract failed: equals-hashcode on var0 and var11", var0.equals(var11) ? var0.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var0
//     assertTrue("Contract failed: equals-hashcode on var11 and var0", var11.equals(var0) ? var11.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var16
//     assertTrue("Contract failed: equals-hashcode on var5 and var16", var5.equals(var16) ? var5.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var5
//     assertTrue("Contract failed: equals-hashcode on var16 and var5", var16.equals(var5) ? var16.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
    var0.setPlot(var5);
    java.awt.Paint var8 = var5.getBackgroundPaint();
    org.jfree.chart.LegendItemCollection var9 = var5.getFixedLegendItems();
    java.awt.Paint var10 = var5.getRangeCrosshairPaint();
    var5.clearRangeMarkers((-1));
    java.awt.Paint var13 = var5.getRangeGridlinePaint();
    org.jfree.chart.annotations.CategoryAnnotation var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.addAnnotation(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     var1.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var5 = var1.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.util.RectangleEdge var8 = null;
//     double var9 = var1.java2DToValue(0.0d, var7, var8);
//     org.jfree.data.Range var10 = null;
//     org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, 1.0d);
//     double var14 = var12.constrain((-1.0d));
//     var1.setRangeWithMargins(var12, true, false);
//     org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var12);
//     org.jfree.chart.util.Size2D var19 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var20 = var18.calculateConstrainedSize(var19);
//     double var21 = var18.getHeight();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var2 = var1.getInsets();
    java.lang.String var3 = var2.toString();
    var0.setTickLabelInsets(var2);
    double var6 = var2.calculateLeftInset(0.0d);
    org.jfree.chart.util.UnitType var7 = var2.getUnitType();
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    java.text.NumberFormat var9 = null;
    var8.setNumberFormatOverride(var9);
    boolean var11 = var2.equals((java.lang.Object)var8);
    double var13 = var2.calculateTopOutset(1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"+ "'", var3.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 4.0d);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var1.setBaseURLGenerator(var4, true);
    int var7 = var1.getColumnCount();
    java.awt.Font var8 = var1.getBaseItemLabelFont();
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var8);
    var9.setText("");
    java.awt.Graphics2D var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    java.lang.Object var14 = null;
    java.lang.Object var15 = var9.draw(var12, var13, var14);
    java.lang.Object var16 = var9.clone();
    java.awt.Paint var17 = var9.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("rect", var1, var2);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var3);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.ui.Library[] var1 = var0.getLibraries();
    java.awt.Image var2 = var0.getLogo();
    org.jfree.chart.ui.ProjectInfo var3 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.ui.Library[] var4 = var3.getLibraries();
    var3.setInfo("hi!");
    var0.addLibrary((org.jfree.chart.ui.Library)var3);
    java.awt.Image var8 = null;
    var3.setLogo(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("SortOrder.ASCENDING", var1, 1.0f, 1.0f, 4.0d, 0.5f, 1.0f);
// 
//   }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     boolean var11 = var0.isSeriesVisible(0);
//     java.awt.Paint var12 = null;
//     var0.setErrorIndicatorPaint(var12);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var0.getLegendItemLabelGenerator();
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     var15.setDrawSharedDomainAxis(false);
//     var0.setPlot(var15);
//     
//     // Checks the contract:  equals-hashcode on var5 and var15
//     assertTrue("Contract failed: equals-hashcode on var5 and var15", var5.equals(var15) ? var5.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var5
//     assertTrue("Contract failed: equals-hashcode on var15 and var5", var15.equals(var5) ? var15.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
//     boolean var5 = var1.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var7 = var6.getFixedLegendItems();
//     var1.setPlot(var6);
//     java.awt.Paint var9 = var6.getBackgroundPaint();
//     java.awt.Font var10 = var6.getNoDataMessageFont();
//     org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("", var10);
//     var11.setExpandToFitSpace(true);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var16 = var14.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var17 = null;
//     var14.setBaseURLGenerator(var17, true);
//     int var20 = var14.getColumnCount();
//     java.awt.Font var21 = var14.getBaseItemLabelFont();
//     var11.setFont(var21);
//     
//     // Checks the contract:  equals-hashcode on var3 and var16
//     assertTrue("Contract failed: equals-hashcode on var3 and var16", var3.equals(var16) ? var3.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var3
//     assertTrue("Contract failed: equals-hashcode on var16 and var3", var16.equals(var3) ? var16.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var4 = var0.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     double var8 = var0.java2DToValue(0.0d, var6, var7);
//     org.jfree.chart.axis.MarkerAxisBand var9 = var0.getMarkerBand();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.zoomRange(100.0d, 100.0d);
    var0.setLowerBound(10.0d);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var8 = var6.getSeriesNegativeItemLabelPosition(100);
    boolean var10 = var6.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var12 = var11.getFixedLegendItems();
    var6.setPlot(var11);
    java.awt.Paint var14 = var6.getErrorIndicatorPaint();
    var6.setBase(100.0d);
    boolean var19 = var6.getItemVisible(1, 1);
    java.awt.Shape var21 = var6.lookupSeriesShape(100);
    var0.setUpArrow(var21);
    java.lang.String var23 = var0.getLabel();
    double var24 = var0.getLabelAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.KeyToGroupMap var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.zoomRange(0.0d, 100.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
//     boolean var8 = var4.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var10 = var9.getFixedLegendItems();
//     var4.setPlot(var9);
//     java.awt.Paint var12 = var9.getBackgroundPaint();
//     var0.setPlot((org.jfree.chart.plot.Plot)var9);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var16 = var15.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var17 = var15.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var20 = var18.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var23 = var18.getItemLabelPaint(0, 10);
//     var15.setNoDataMessagePaint(var23);
//     var15.configureDomainAxes();
//     float var26 = var15.getBackgroundAlpha();
//     org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var15);
//     org.jfree.chart.plot.CategoryPlot var28 = var27.getCategoryPlot();
//     var9.addChangeListener((org.jfree.chart.event.PlotChangeListener)var27);
//     
//     // Checks the contract:  equals-hashcode on var6 and var20
//     assertTrue("Contract failed: equals-hashcode on var6 and var20", var6.equals(var20) ? var6.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var6
//     assertTrue("Contract failed: equals-hashcode on var20 and var6", var20.equals(var6) ? var20.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var15
//     assertTrue("Contract failed: equals-hashcode on var9 and var15", var9.equals(var15) ? var9.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var28
//     assertTrue("Contract failed: equals-hashcode on var9 and var28", var9.equals(var28) ? var9.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var9
//     assertTrue("Contract failed: equals-hashcode on var15 and var9", var15.equals(var9) ? var15.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var9
//     assertTrue("Contract failed: equals-hashcode on var28 and var9", var28.equals(var9) ? var28.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
    var0.setPlot(var5);
    java.awt.Paint var8 = var0.getErrorIndicatorPaint();
    java.awt.Paint var9 = var0.getBaseOutlinePaint();
    boolean var11 = var0.isSeriesVisible(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var14 = var0.getLegendItem(10, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    java.awt.Color var7 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var8 = var7.getRed();
    java.awt.Color var9 = var7.brighter();
    java.awt.image.ColorModel var10 = null;
    java.awt.Rectangle var11 = null;
    java.awt.geom.Rectangle2D var12 = null;
    java.awt.geom.AffineTransform var13 = null;
    java.awt.RenderingHints var14 = null;
    java.awt.PaintContext var15 = var9.createContext(var10, var11, var12, var13, var14);
    org.jfree.chart.util.ObjectList var16 = new org.jfree.chart.util.ObjectList();
    boolean var17 = var9.equals((java.lang.Object)var16);
    org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder(Double.NaN, (-5.0d), (-1.0d), 0.05d, (java.awt.Paint)var9);
    boolean var20 = var9.equals((java.lang.Object)100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var2 = var1.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var3 = var1.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var9 = var4.getItemLabelPaint(0, 10);
//     var1.setNoDataMessagePaint(var9);
//     var1.configureDomainAxes();
//     float var12 = var1.getBackgroundAlpha();
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     java.awt.Image var14 = null;
//     var13.setBackgroundImage(var14);
//     var13.setBackgroundImageAlignment(100);
//     java.awt.Color var21 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var22 = var21.getRed();
//     java.awt.Color var23 = var21.brighter();
//     float[] var27 = new float[] { 100.0f, 10.0f, 100.0f};
//     float[] var28 = var21.getRGBColorComponents(var27);
//     var13.setBackgroundPaint((java.awt.Paint)var21);
//     org.jfree.chart.event.TitleChangeEvent var30 = null;
//     var13.titleChanged(var30);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    java.awt.Stroke var2 = var0.getOutlineStroke();
    java.awt.Stroke var3 = var0.getOutlineStroke();
    var0.setOutlineVisible(false);
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    var6.zoomRange(100.0d, 100.0d);
    var6.setLowerBound(10.0d);
    org.jfree.chart.axis.NumberTickUnit var12 = var6.getTickUnit();
    java.awt.Shape var13 = var6.getRightArrow();
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var6);
    var0.zoom(0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    double var1 = var0.getContentXOffset();
    org.jfree.chart.util.HorizontalAlignment var2 = null;
    org.jfree.chart.util.VerticalAlignment var3 = null;
    org.jfree.chart.block.FlowArrangement var6 = new org.jfree.chart.block.FlowArrangement(var2, var3, 100.0d, 0.0d);
    var0.setArrangement((org.jfree.chart.block.Arrangement)var6);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var11 = var9.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.urls.CategoryURLGenerator var12 = null;
    var9.setBaseURLGenerator(var12, true);
    int var15 = var9.getColumnCount();
    java.awt.Font var16 = var9.getBaseItemLabelFont();
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("", var16);
    var17.setText("");
    var0.add((org.jfree.chart.block.Block)var17);
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.block.RectangleConstraint var24 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var26 = var24.toFixedHeight(3.0d);
    java.lang.String var27 = var24.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var28 = var0.arrange(var21, var24);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]"+ "'", var27.equals("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]"));

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.RectangleInsets var2 = var1.getPadding();
    java.lang.String var3 = var1.getID();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(8.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-6.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
    var0.setPlot(var5);
    java.awt.Paint var8 = var0.getErrorIndicatorPaint();
    var0.setBase(100.0d);
    boolean var13 = var0.getItemVisible(1, 1);
    org.jfree.chart.urls.CategoryURLGenerator var14 = null;
    var0.setBaseURLGenerator(var14);
    boolean var16 = var0.getBaseSeriesVisibleInLegend();
    boolean var17 = var0.getBaseItemLabelsVisible();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var21 = var19.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var24 = var19.getItemLabelPaint(0, 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelPaint((-16777216), var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("3", var1);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
    boolean var5 = var1.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var7 = var6.getFixedLegendItems();
    var1.setPlot(var6);
    java.awt.Paint var9 = var1.getErrorIndicatorPaint();
    var1.setBase(100.0d);
    boolean var14 = var1.getItemVisible(1, 1);
    java.awt.Shape var16 = var1.lookupSeriesShape(100);
    org.jfree.chart.entity.CategoryLabelEntity var19 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)0.0f, var16, "", "");
    java.lang.String var20 = var19.getShapeType();
    java.lang.Comparable var21 = var19.getKey();
    java.awt.Shape var22 = var19.getArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "rect"+ "'", var20.equals("rect"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + 0.0f+ "'", var21.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    double var1 = var0.getContentXOffset();
    org.jfree.chart.util.HorizontalAlignment var2 = null;
    org.jfree.chart.util.VerticalAlignment var3 = null;
    org.jfree.chart.block.FlowArrangement var6 = new org.jfree.chart.block.FlowArrangement(var2, var3, 100.0d, 0.0d);
    var0.setArrangement((org.jfree.chart.block.Arrangement)var6);
    java.lang.Object var8 = null;
    boolean var9 = var0.equals(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     var0.setBase(100.0d);
//     boolean var13 = var0.getItemVisible(1, 1);
//     org.jfree.chart.urls.CategoryURLGenerator var14 = null;
//     var0.setBaseURLGenerator(var14);
//     boolean var16 = var0.getBaseSeriesVisibleInLegend();
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var19 = var18.getFixedLegendItems();
//     java.awt.Stroke var20 = var18.getOutlineStroke();
//     java.awt.Stroke var21 = var18.getOutlineStroke();
//     org.jfree.chart.axis.ValueAxis var22 = var18.getRangeAxis();
//     var18.setDomainGridlinesVisible(true);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var28 = var26.getSeriesNegativeItemLabelPosition(100);
//     boolean var30 = var26.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var32 = var31.getFixedLegendItems();
//     var26.setPlot(var31);
//     java.awt.Paint var34 = var26.getErrorIndicatorPaint();
//     java.awt.Paint var35 = var26.getBaseOutlinePaint();
//     boolean var37 = var26.isSeriesVisible(0);
//     var18.setRenderer(10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var26, false);
//     org.jfree.chart.util.RectangleInsets var40 = var18.getAxisOffset();
//     org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis();
//     var41.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var45 = var41.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var47 = null;
//     org.jfree.chart.util.RectangleEdge var48 = null;
//     double var49 = var41.java2DToValue(0.0d, var47, var48);
//     java.awt.Font var50 = var41.getTickLabelFont();
//     var41.setTickMarksVisible(true);
//     boolean var53 = var41.getAutoRangeIncludesZero();
//     java.awt.geom.Rectangle2D var54 = null;
//     var0.drawRangeGridline(var17, var18, (org.jfree.chart.axis.ValueAxis)var41, var54, 0.0d);
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 1.0d);
    double var6 = var4.constrain((-1.0d));
    org.jfree.data.Range var7 = org.jfree.data.Range.combine(var1, var4);
    org.jfree.chart.block.LengthConstraintType var8 = null;
    org.jfree.data.Range var10 = null;
    org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, 1.0d);
    org.jfree.chart.block.LengthConstraintType var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint(0.0d, var4, var8, 100.0d, var12, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker((-11.0d));

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var5 = var0.getItemLabelPaint(0, 10);
//     var0.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var11 = var9.getSeriesNegativeItemLabelPosition(100);
//     boolean var13 = var9.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var15 = var14.getFixedLegendItems();
//     var9.setPlot(var14);
//     java.awt.Paint var17 = var9.getErrorIndicatorPaint();
//     java.awt.Paint var18 = var9.getBaseOutlinePaint();
//     boolean var20 = var9.isSeriesVisible(0);
//     org.jfree.chart.labels.CategoryToolTipGenerator var21 = null;
//     var9.setBaseToolTipGenerator(var21);
//     org.jfree.chart.labels.ItemLabelPosition var24 = var9.getSeriesPositiveItemLabelPosition(255);
//     var0.setPositiveItemLabelPositionFallback(var24);
//     
//     // Checks the contract:  equals-hashcode on var2 and var11
//     assertTrue("Contract failed: equals-hashcode on var2 and var11", var2.equals(var11) ? var2.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var2
//     assertTrue("Contract failed: equals-hashcode on var11 and var2", var11.equals(var2) ? var11.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();
    java.lang.Object var1 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     java.awt.Stroke var2 = var0.getOutlineStroke();
//     java.awt.Stroke var3 = var0.getOutlineStroke();
//     org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxis();
//     var0.setDomainGridlinesVisible(true);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var10 = var8.getSeriesNegativeItemLabelPosition(100);
//     boolean var12 = var8.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var14 = var13.getFixedLegendItems();
//     var8.setPlot(var13);
//     java.awt.Paint var16 = var8.getErrorIndicatorPaint();
//     java.awt.Paint var17 = var8.getBaseOutlinePaint();
//     boolean var19 = var8.isSeriesVisible(0);
//     var0.setRenderer(10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var8, false);
//     java.awt.Graphics2D var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var25 = var24.getFixedLegendItems();
//     java.awt.Stroke var26 = var24.getOutlineStroke();
//     java.awt.Stroke var27 = var24.getOutlineStroke();
//     org.jfree.chart.axis.ValueAxis var28 = var24.getRangeAxis();
//     var24.setDomainGridlinesVisible(true);
//     org.jfree.chart.axis.AxisLocation var32 = var24.getRangeAxisLocation(0);
//     org.jfree.chart.plot.PlotRenderingInfo var35 = null;
//     java.awt.geom.Rectangle2D var36 = null;
//     org.jfree.chart.util.RectangleAnchor var37 = null;
//     java.awt.geom.Point2D var38 = org.jfree.chart.util.RectangleAnchor.coordinates(var36, var37);
//     var24.zoomDomainAxes(0.0d, 8.0d, var35, var38);
//     org.jfree.chart.plot.PlotState var40 = null;
//     org.jfree.chart.ChartRenderingInfo var41 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var42 = new org.jfree.chart.plot.PlotRenderingInfo(var41);
//     var0.draw(var22, var23, var38, var40, var42);
// 
//   }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var4 = var0.getTickMarkStroke();
//     boolean var5 = var0.isAutoRange();
//     double var6 = var0.getUpperBound();
//     java.lang.String var7 = var0.getLabelToolTip();
//     double var8 = var0.getUpperBound();
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.clearDomainMarkers(1);
//     java.awt.Image var16 = var13.getBackgroundImage();
//     org.jfree.chart.util.RectangleEdge var18 = var13.getRangeAxisEdge((-1));
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
//     var19.zoomRange(0.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var25 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)100, (java.lang.Number)10);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var27 = var26.getFixedLegendItems();
//     java.awt.Stroke var28 = var26.getOutlineStroke();
//     org.jfree.chart.axis.AxisLocation var30 = var26.getRangeAxisLocation(10);
//     boolean var31 = var25.equals((java.lang.Object)var26);
//     var19.addChangeListener((org.jfree.chart.event.AxisChangeListener)var26);
//     java.awt.Image var33 = null;
//     var26.setBackgroundImage(var33);
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     var35.clearDomainMarkers(1);
//     java.awt.Image var38 = var35.getBackgroundImage();
//     float var39 = var35.getForegroundAlpha();
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var41 = var40.getFixedLegendItems();
//     java.awt.Stroke var42 = var40.getOutlineStroke();
//     org.jfree.chart.axis.AxisLocation var44 = var40.getRangeAxisLocation(10);
//     var35.setRangeAxisLocation(var44, true);
//     var26.setDomainAxisLocation(var44, false);
//     java.awt.Graphics2D var49 = null;
//     java.awt.geom.Rectangle2D var50 = null;
//     org.jfree.chart.ChartRenderingInfo var52 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var53 = new org.jfree.chart.plot.PlotRenderingInfo(var52);
//     boolean var54 = var26.render(var49, var50, (-16777216), var53);
//     org.jfree.chart.axis.AxisState var55 = var0.draw(var9, 8.0d, var11, var12, var18, var53);
// 
//   }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
//     java.awt.Paint var3 = var0.getOutlinePaint();
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     var4.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var8 = var4.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleEdge var11 = null;
//     double var12 = var4.java2DToValue(0.0d, var10, var11);
//     java.awt.Font var13 = var4.getTickLabelFont();
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var4);
//     org.jfree.data.Range var15 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.setRange(var15, true, false);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("HorizontalAlignment.CENTER", "", var3);
// 
//   }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)(-16777216));
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
    var0.setPlot(var5);
    java.awt.Paint var8 = var0.getErrorIndicatorPaint();
    var0.setBase(100.0d);
    boolean var13 = var0.getItemVisible(1, 1);
    java.awt.Shape var15 = var0.lookupSeriesShape(100);
    org.jfree.chart.entity.LegendItemEntity var16 = new org.jfree.chart.entity.LegendItemEntity(var15);
    var16.setURLText("hi!");
    org.jfree.data.general.Dataset var19 = null;
    var16.setDataset(var19);
    java.lang.Object var21 = var16.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     java.lang.String var1 = var0.getLabel();
//     double var2 = var0.getUpperMargin();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
//     boolean var7 = var3.isSeriesVisible(10);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var9 = var3.getSeriesItemLabelGenerator(10);
//     java.awt.Paint var12 = var3.getItemFillPaint(100, 10);
//     var0.setTickLabelPaint(var12);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.axis.AxisState var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var18 = var17.getFixedLegendItems();
//     java.awt.Stroke var19 = var17.getOutlineStroke();
//     var17.setDrawSharedDomainAxis(true);
//     org.jfree.chart.util.RectangleEdge var22 = var17.getDomainAxisEdge();
//     java.util.List var23 = var0.refreshTicks(var14, var15, var16, var22);
// 
//   }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     org.jfree.chart.util.GradientPaintTransformType var2 = var1.getType();
//     org.jfree.chart.block.BlockContainer var3 = new org.jfree.chart.block.BlockContainer();
//     java.util.List var4 = var3.getBlocks();
//     boolean var5 = var2.equals((java.lang.Object)var3);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.block.RectangleConstraint var7 = null;
//     org.jfree.chart.util.Size2D var8 = var0.arrange(var3, var6, var7);
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.event.MarkerChangeEvent var2 = null;
    var1.notifyListeners(var2);
    var1.setValue((-1.0d));
    org.jfree.chart.util.RectangleInsets var6 = var1.getLabelOffset();
    java.awt.geom.Rectangle2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var8 = var6.createOutsetRectangle(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
//     org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var5 = var4.getInsets();
//     java.lang.String var6 = var5.toString();
//     var3.setTickLabelInsets(var5);
//     double var9 = var5.calculateLeftInset(0.0d);
//     org.jfree.chart.util.UnitType var10 = var5.getUnitType();
//     var2.setLegendItemGraphicPadding(var5);
//     
//     // Checks the contract:  equals-hashcode on var0 and var4
//     assertTrue("Contract failed: equals-hashcode on var0 and var4", var0.equals(var4) ? var0.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var0
//     assertTrue("Contract failed: equals-hashcode on var4 and var0", var4.equals(var0) ? var4.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition(100);
    boolean var6 = var2.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var8 = var7.getFixedLegendItems();
    var2.setPlot(var7);
    java.awt.Paint var10 = var2.getErrorIndicatorPaint();
    java.awt.Paint var11 = var2.getBaseOutlinePaint();
    boolean var13 = var2.isSeriesVisible(0);
    java.awt.Paint var14 = null;
    var2.setErrorIndicatorPaint(var14);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var16 = var2.getLegendItemLabelGenerator();
    java.awt.Stroke var19 = var2.getItemStroke(1, 10);
    var0.setSeriesOutlineStroke(255, var19);
    var0.setSeriesItemLabelsVisible(255, (java.lang.Boolean)false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisible((-16777216), (java.lang.Boolean)true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
    double var2 = var1.getContentXOffset();
    org.jfree.chart.util.HorizontalAlignment var3 = null;
    org.jfree.chart.util.VerticalAlignment var4 = null;
    org.jfree.chart.block.FlowArrangement var7 = new org.jfree.chart.block.FlowArrangement(var3, var4, 100.0d, 0.0d);
    var1.setArrangement((org.jfree.chart.block.Arrangement)var7);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.urls.CategoryURLGenerator var13 = null;
    var10.setBaseURLGenerator(var13, true);
    int var16 = var10.getColumnCount();
    java.awt.Font var17 = var10.getBaseItemLabelFont();
    org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("", var17);
    var18.setText("");
    var1.add((org.jfree.chart.block.Block)var18);
    java.awt.Graphics2D var22 = null;
    org.jfree.chart.block.RectangleConstraint var25 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var27 = var25.toFixedHeight(3.0d);
    org.jfree.chart.block.RectangleConstraint var29 = var27.toFixedHeight(1.0E-8d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var30 = var0.arrange(var1, var22, var29);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.zoomRange(100.0d, 100.0d);
//     var0.setLowerBound(10.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var8 = var6.getSeriesNegativeItemLabelPosition(100);
//     boolean var10 = var6.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var12 = var11.getFixedLegendItems();
//     var6.setPlot(var11);
//     java.awt.Paint var14 = var6.getErrorIndicatorPaint();
//     var6.setBase(100.0d);
//     boolean var19 = var6.getItemVisible(1, 1);
//     java.awt.Shape var21 = var6.lookupSeriesShape(100);
//     var0.setRightArrow(var21);
//     java.lang.Object var23 = var0.clone();
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var27 = var26.getFixedLegendItems();
//     java.awt.Stroke var28 = var26.getOutlineStroke();
//     var26.setDrawSharedDomainAxis(true);
//     org.jfree.chart.util.RectangleEdge var31 = var26.getDomainAxisEdge();
//     double var32 = var0.lengthToJava2D(1.0d, var25, var31);
// 
//   }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var11 = var0.getSeriesItemLabelGenerator((-1));
//     java.awt.Stroke var13 = var0.lookupSeriesStroke(0);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var15 = var14.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var16 = var14.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var19 = var17.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var22 = var17.getItemLabelPaint(0, 10);
//     var14.setNoDataMessagePaint(var22);
//     var14.configureDomainAxes();
//     float var25 = var14.getBackgroundAlpha();
//     var14.setRangeCrosshairLockedOnData(true);
//     org.jfree.data.category.CategoryDataset var29 = var14.getDataset(100);
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var31 = new org.jfree.chart.axis.ValueAxis[] { var30};
//     var14.setRangeAxes(var31);
//     org.jfree.chart.axis.CategoryAxis var33 = var14.getDomainAxis();
//     java.awt.Stroke var34 = var14.getRangeGridlineStroke();
//     var0.setBaseOutlineStroke(var34);
//     
//     // Checks the contract:  equals-hashcode on var2 and var19
//     assertTrue("Contract failed: equals-hashcode on var2 and var19", var2.equals(var19) ? var2.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var2
//     assertTrue("Contract failed: equals-hashcode on var19 and var2", var19.equals(var2) ? var19.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var2 = var1.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var3 = var1.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var9 = var4.getItemLabelPaint(0, 10);
//     var1.setNoDataMessagePaint(var9);
//     var1.configureDomainAxes();
//     float var12 = var1.getBackgroundAlpha();
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     var13.setBackgroundImageAlignment(0);
//     float var16 = var13.getBackgroundImageAlpha();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var20 = var18.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var21 = null;
//     var18.setBaseURLGenerator(var21, true);
//     int var24 = var18.getColumnCount();
//     java.awt.Font var25 = var18.getBaseItemLabelFont();
//     org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("", var25);
//     org.jfree.chart.axis.CategoryLabelPosition var27 = new org.jfree.chart.axis.CategoryLabelPosition();
//     boolean var28 = var26.equals((java.lang.Object)var27);
//     org.jfree.chart.block.BlockFrame var29 = var26.getFrame();
//     java.lang.Object var30 = var26.clone();
//     java.lang.Object var31 = null;
//     boolean var32 = var26.equals(var31);
//     java.lang.Object var33 = var26.clone();
//     var13.removeSubtitle((org.jfree.chart.title.Title)var26);
//     
//     // Checks the contract:  equals-hashcode on var6 and var20
//     assertTrue("Contract failed: equals-hashcode on var6 and var20", var6.equals(var20) ? var6.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var6
//     assertTrue("Contract failed: equals-hashcode on var20 and var6", var20.equals(var6) ? var20.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(1);
//     java.awt.Paint var3 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     var6.zoomRange(0.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var12 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)100, (java.lang.Number)10);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var14 = var13.getFixedLegendItems();
//     java.awt.Stroke var15 = var13.getOutlineStroke();
//     org.jfree.chart.axis.AxisLocation var17 = var13.getRangeAxisLocation(10);
//     boolean var18 = var12.equals((java.lang.Object)var13);
//     var6.addChangeListener((org.jfree.chart.event.AxisChangeListener)var13);
//     java.awt.Image var20 = null;
//     var13.setBackgroundImage(var20);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     var22.clearDomainMarkers(1);
//     java.awt.Image var25 = var22.getBackgroundImage();
//     float var26 = var22.getForegroundAlpha();
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var28 = var27.getFixedLegendItems();
//     java.awt.Stroke var29 = var27.getOutlineStroke();
//     org.jfree.chart.axis.AxisLocation var31 = var27.getRangeAxisLocation(10);
//     var22.setRangeAxisLocation(var31, true);
//     var13.setDomainAxisLocation(var31, false);
//     java.awt.Graphics2D var36 = null;
//     java.awt.geom.Rectangle2D var37 = null;
//     org.jfree.chart.ChartRenderingInfo var39 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var40 = new org.jfree.chart.plot.PlotRenderingInfo(var39);
//     boolean var41 = var13.render(var36, var37, (-16777216), var40);
//     java.awt.geom.Rectangle2D var42 = null;
//     var40.setDataArea(var42);
//     var0.handleClick((-16777216), 1, var40);
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    var0.setAutoPopulateSeriesStroke(false);
    boolean var5 = var0.isDrawBarOutline();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)false, 0.05d, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
//     var0.setNoDataMessagePaint(var8);
//     var0.configureDomainAxes();
//     float var11 = var0.getBackgroundAlpha();
//     org.jfree.chart.axis.AxisLocation var13 = var0.getDomainAxisLocation(1);
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     java.awt.geom.Point2D var16 = null;
//     var0.zoomRangeAxes(0.0d, var15, var16);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var20 = var18.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var21 = null;
//     var18.setBaseURLGenerator(var21, true);
//     int var24 = var18.getColumnCount();
//     boolean var25 = var18.getBaseSeriesVisibleInLegend();
//     boolean var26 = var18.getBaseItemLabelsVisible();
//     var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var18, false);
//     
//     // Checks the contract:  equals-hashcode on var5 and var20
//     assertTrue("Contract failed: equals-hashcode on var5 and var20", var5.equals(var20) ? var5.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var5
//     assertTrue("Contract failed: equals-hashcode on var20 and var5", var20.equals(var5) ? var20.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     var0.setBaseSeriesVisible(true, true);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var15 = var13.getSeriesNegativeItemLabelPosition(100);
//     boolean var17 = var13.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var19 = var18.getFixedLegendItems();
//     var13.setPlot(var18);
//     java.awt.Paint var21 = var13.getErrorIndicatorPaint();
//     java.awt.Paint var22 = var13.getBaseOutlinePaint();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var24 = var13.getSeriesItemLabelGenerator((-1));
//     java.awt.Stroke var26 = var13.lookupSeriesStroke(0);
//     var0.setBaseStroke(var26, false);
//     
//     // Checks the contract:  equals-hashcode on var2 and var15
//     assertTrue("Contract failed: equals-hashcode on var2 and var15", var2.equals(var15) ? var2.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var2
//     assertTrue("Contract failed: equals-hashcode on var15 and var2", var15.equals(var2) ? var15.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var18
//     assertTrue("Contract failed: equals-hashcode on var5 and var18", var5.equals(var18) ? var5.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var5
//     assertTrue("Contract failed: equals-hashcode on var18 and var5", var18.equals(var5) ? var18.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(1);
//     java.awt.Image var3 = var0.getBackgroundImage();
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     java.awt.geom.Point2D var6 = null;
//     var0.zoomRangeAxes(100.0d, var5, var6);
//     var0.setRangeCrosshairValue(1.0d);
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var15 = var14.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var16 = var14.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var19 = var17.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var22 = var17.getItemLabelPaint(0, 10);
//     var14.setNoDataMessagePaint(var22);
//     var14.configureDomainAxes();
//     float var25 = var14.getBackgroundAlpha();
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var14);
//     org.jfree.chart.plot.CategoryPlot var27 = var26.getCategoryPlot();
//     java.lang.Object var28 = var10.draw(var11, var12, (java.lang.Object)var27);
// 
//   }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.zoomRange(100.0d, 100.0d);
//     var0.setLowerBound(10.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var8 = var6.getSeriesNegativeItemLabelPosition(100);
//     boolean var10 = var6.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var12 = var11.getFixedLegendItems();
//     var6.setPlot(var11);
//     java.awt.Paint var14 = var6.getErrorIndicatorPaint();
//     var6.setBase(100.0d);
//     boolean var19 = var6.getItemVisible(1, 1);
//     java.awt.Shape var21 = var6.lookupSeriesShape(100);
//     var0.setUpArrow(var21);
//     org.jfree.chart.axis.NumberTickUnit var23 = var0.getTickUnit();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var24 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var26 = var24.getSeriesNegativeItemLabelPosition(100);
//     boolean var28 = var24.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var30 = var29.getFixedLegendItems();
//     var24.setPlot(var29);
//     java.awt.Paint var32 = var24.getErrorIndicatorPaint();
//     var24.setBase(100.0d);
//     boolean var37 = var24.getItemVisible(1, 1);
//     java.awt.Shape var39 = var24.lookupSeriesShape(100);
//     org.jfree.chart.entity.LegendItemEntity var40 = new org.jfree.chart.entity.LegendItemEntity(var39);
//     java.awt.Shape var41 = var40.getArea();
//     java.awt.Shape var42 = var40.getArea();
//     org.jfree.chart.entity.CategoryLabelEntity var45 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)var23, var42, "SortOrder.ASCENDING", "HorizontalAlignment.CENTER");
//     
//     // Checks the contract:  equals-hashcode on var8 and var26
//     assertTrue("Contract failed: equals-hashcode on var8 and var26", var8.equals(var26) ? var8.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var8
//     assertTrue("Contract failed: equals-hashcode on var26 and var8", var26.equals(var8) ? var26.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var29
//     assertTrue("Contract failed: equals-hashcode on var11 and var29", var11.equals(var29) ? var11.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var11
//     assertTrue("Contract failed: equals-hashcode on var29 and var11", var29.equals(var11) ? var29.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     var1.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var5 = var1.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.util.RectangleEdge var8 = null;
//     double var9 = var1.java2DToValue(0.0d, var7, var8);
//     org.jfree.data.Range var10 = null;
//     org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, 1.0d);
//     double var14 = var12.constrain((-1.0d));
//     var1.setRangeWithMargins(var12, true, false);
//     org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var12);
//     org.jfree.chart.util.Size2D var19 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var20 = var18.calculateConstrainedSize(var19);
//     var20.setHeight(3.0d);
//     double var23 = var20.getWidth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == Double.NaN);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(1);
    java.awt.Image var3 = var0.getBackgroundImage();
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    java.awt.geom.Point2D var6 = null;
    var0.zoomRangeAxes(100.0d, var5, var6);
    var0.setRangeCrosshairValue(1.0d);
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var13 = var12.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var14 = var12.getDataset();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var17 = var15.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var20 = var15.getItemLabelPaint(0, 10);
    var12.setNoDataMessagePaint(var20);
    var12.configureDomainAxes();
    float var23 = var12.getBackgroundAlpha();
    org.jfree.chart.axis.AxisLocation var25 = var12.getDomainAxisLocation(1);
    org.jfree.chart.axis.AxisLocation var26 = var25.getOpposite();
    var0.setDomainAxisLocation(100, var26, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.zoomRange(100.0d, 100.0d);
    var0.setAutoRangeStickyZero(true);
    org.jfree.chart.plot.Plot var6 = var0.getPlot();
    var0.setTickMarksVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.ui.Library[] var1 = var0.getLibraries();
    java.awt.Image var2 = var0.getLogo();
    org.jfree.chart.ui.ProjectInfo var3 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.ui.Library[] var4 = var3.getLibraries();
    var3.setInfo("hi!");
    var0.addLibrary((org.jfree.chart.ui.Library)var3);
    java.lang.String var8 = var0.getName();
    var0.setLicenceName("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     java.text.NumberFormat var1 = null;
//     var0.setNumberFormatOverride(var1);
//     double var3 = var0.getAutoRangeMinimumSize();
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     var6.clearDomainMarkers(1);
//     java.awt.Image var9 = var6.getBackgroundImage();
//     org.jfree.chart.util.RectangleEdge var11 = var6.getRangeAxisEdge((-1));
//     boolean var12 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var11);
//     org.jfree.chart.util.RectangleEdge var13 = org.jfree.chart.util.RectangleEdge.opposite(var11);
//     double var14 = var0.valueToJava2D((-1.0d), var5, var13);
// 
//   }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var2 = var1.getInsets();
//     java.lang.String var3 = var2.toString();
//     var0.setTickLabelInsets(var2);
//     var0.setAutoRangeIncludesZero(true);
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     java.text.NumberFormat var8 = null;
//     var7.setNumberFormatOverride(var8);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var13 = var11.getSeriesNegativeItemLabelPosition(100);
//     boolean var15 = var11.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var17 = var16.getFixedLegendItems();
//     var11.setPlot(var16);
//     java.awt.Paint var19 = var11.getErrorIndicatorPaint();
//     var11.setBase(100.0d);
//     boolean var24 = var11.getItemVisible(1, 1);
//     java.awt.Shape var26 = var11.lookupSeriesShape(100);
//     org.jfree.chart.entity.CategoryLabelEntity var29 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)10L, var26, "Category Plot", "");
//     var7.setRightArrow(var26);
//     var0.setDownArrow(var26);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var34 = var32.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var35 = null;
//     var32.setBaseURLGenerator(var35, true);
//     int var38 = var32.getColumnCount();
//     java.awt.Font var39 = var32.getBaseItemLabelFont();
//     var0.setTickLabelFont(var39);
//     
//     // Checks the contract:  equals-hashcode on var13 and var34
//     assertTrue("Contract failed: equals-hashcode on var13 and var34", var13.equals(var34) ? var13.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var13
//     assertTrue("Contract failed: equals-hashcode on var34 and var13", var34.equals(var13) ? var34.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     var0.setBase(100.0d);
//     boolean var13 = var0.getItemVisible(1, 1);
//     org.jfree.chart.urls.CategoryURLGenerator var14 = null;
//     var0.setBaseURLGenerator(var14);
//     var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)false, false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var23 = var21.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var26 = var21.getItemLabelPaint(0, 10);
//     org.jfree.chart.labels.ItemLabelPosition var28 = var21.getSeriesNegativeItemLabelPosition(0);
//     var0.setSeriesNegativeItemLabelPosition(255, var28, true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var23
//     assertTrue("Contract failed: equals-hashcode on var2 and var23", var2.equals(var23) ? var2.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var28
//     assertTrue("Contract failed: equals-hashcode on var2 and var28", var2.equals(var28) ? var2.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var2
//     assertTrue("Contract failed: equals-hashcode on var23 and var2", var23.equals(var2) ? var23.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var2
//     assertTrue("Contract failed: equals-hashcode on var28 and var2", var28.equals(var2) ? var28.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(1);
//     java.awt.Image var3 = var0.getBackgroundImage();
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     java.awt.geom.Point2D var6 = null;
//     var0.zoomRangeAxes(100.0d, var5, var6);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var10 = var9.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var11 = var9.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var14 = var12.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var17 = var12.getItemLabelPaint(0, 10);
//     var9.setNoDataMessagePaint(var17);
//     var9.configureDomainAxes();
//     float var20 = var9.getBackgroundAlpha();
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
//     var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var21);
//     
//     // Checks the contract:  equals-hashcode on var0 and var9
//     assertTrue("Contract failed: equals-hashcode on var0 and var9", var0.equals(var9) ? var0.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var0
//     assertTrue("Contract failed: equals-hashcode on var9 and var0", var9.equals(var0) ? var9.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var2 = var1.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var3 = var1.getDataset();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var9 = var4.getItemLabelPaint(0, 10);
    var1.setNoDataMessagePaint(var9);
    var1.configureDomainAxes();
    float var12 = var1.getBackgroundAlpha();
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
    var13.setBackgroundImageAlpha(10.0f);
    var13.fireChartChanged();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0f);

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 2.0f);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    java.awt.Color var7 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var8 = var7.getRed();
    java.awt.Color var9 = var7.brighter();
    java.awt.image.ColorModel var10 = null;
    java.awt.Rectangle var11 = null;
    java.awt.geom.Rectangle2D var12 = null;
    java.awt.geom.AffineTransform var13 = null;
    java.awt.RenderingHints var14 = null;
    java.awt.PaintContext var15 = var9.createContext(var10, var11, var12, var13, var14);
    org.jfree.chart.util.ObjectList var16 = new org.jfree.chart.util.ObjectList();
    boolean var17 = var9.equals((java.lang.Object)var16);
    org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder(Double.NaN, (-5.0d), (-1.0d), 0.05d, (java.awt.Paint)var9);
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var21 = var20.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var22 = var20.getDataset();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var25 = var23.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var28 = var23.getItemLabelPaint(0, 10);
    var20.setNoDataMessagePaint(var28);
    var20.configureDomainAxes();
    float var31 = var20.getBackgroundAlpha();
    org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var20);
    java.awt.Color var40 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var41 = var40.getRed();
    java.awt.Color var42 = var40.brighter();
    java.awt.image.ColorModel var43 = null;
    java.awt.Rectangle var44 = null;
    java.awt.geom.Rectangle2D var45 = null;
    java.awt.geom.AffineTransform var46 = null;
    java.awt.RenderingHints var47 = null;
    java.awt.PaintContext var48 = var42.createContext(var43, var44, var45, var46, var47);
    org.jfree.chart.util.ObjectList var49 = new org.jfree.chart.util.ObjectList();
    boolean var50 = var42.equals((java.lang.Object)var49);
    org.jfree.chart.block.BlockBorder var51 = new org.jfree.chart.block.BlockBorder(Double.NaN, (-5.0d), (-1.0d), 0.05d, (java.awt.Paint)var42);
    var32.setBorderPaint((java.awt.Paint)var42);
    java.awt.color.ColorSpace var53 = var42.getColorSpace();
    java.awt.Color var60 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var61 = var60.getRed();
    java.awt.Color var62 = var60.brighter();
    float[] var66 = new float[] { 100.0f, 10.0f, 100.0f};
    float[] var67 = var60.getRGBColorComponents(var66);
    float[] var68 = java.awt.Color.RGBtoHSB(10, 10, 255, var66);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var69 = var9.getComponents(var53, var68);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.awt.Font var3 = null;
    java.awt.Paint var4 = null;
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var3, var4, 0.0f, 1, var7);
    java.util.List var9 = var8.getLines();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.text.TextBlockAnchor var13 = null;
    java.awt.Shape var17 = var8.calculateBounds(var10, (-1.0f), 10.0f, var13, 1.0f, 0.0f, 0.0d);
    var0.setObject((java.lang.Comparable)0, (java.lang.Object)0.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((-16777216));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
//     org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.awt.Paint var3 = var2.getBackgroundPaint();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var5 = var4.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var6 = var4.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var7.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var12 = var7.getItemLabelPaint(0, 10);
//     var4.setNoDataMessagePaint(var12);
//     var4.configureDomainAxes();
//     float var15 = var4.getBackgroundAlpha();
//     org.jfree.chart.axis.AxisLocation var17 = var4.getDomainAxisLocation(1);
//     org.jfree.chart.LegendItemSource[] var18 = new org.jfree.chart.LegendItemSource[] { var4};
//     var2.setSources(var18);
//     
//     // Checks the contract:  equals-hashcode on var0 and var4
//     assertTrue("Contract failed: equals-hashcode on var0 and var4", var0.equals(var4) ? var0.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var0
//     assertTrue("Contract failed: equals-hashcode on var4 and var0", var4.equals(var0) ? var4.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
//     var0.setNoDataMessagePaint(var8);
//     var0.configureDomainAxes();
//     float var11 = var0.getBackgroundAlpha();
//     var0.setRangeCrosshairLockedOnData(true);
//     int var14 = var0.getRangeAxisCount();
//     var0.clearDomainAxes();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var17 = var16.getFixedLegendItems();
//     java.awt.Stroke var18 = var16.getOutlineStroke();
//     java.awt.Stroke var19 = var16.getOutlineStroke();
//     org.jfree.chart.axis.ValueAxis var20 = var16.getRangeAxis();
//     float var21 = var16.getBackgroundImageAlpha();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var24 = var22.getSeriesNegativeItemLabelPosition(100);
//     boolean var26 = var22.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var28 = var27.getFixedLegendItems();
//     var22.setPlot(var27);
//     java.awt.Paint var30 = var27.getBackgroundPaint();
//     org.jfree.chart.LegendItemCollection var31 = var27.getFixedLegendItems();
//     java.awt.Paint var32 = var27.getRangeCrosshairPaint();
//     var16.setNoDataMessagePaint(var32);
//     var0.setOutlinePaint(var32);
//     
//     // Checks the contract:  equals-hashcode on var5 and var24
//     assertTrue("Contract failed: equals-hashcode on var5 and var24", var5.equals(var24) ? var5.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var5
//     assertTrue("Contract failed: equals-hashcode on var24 and var5", var24.equals(var5) ? var24.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var3 = var0.getBaseFillPaint();
    org.jfree.chart.urls.CategoryURLGenerator var5 = null;
    var0.setSeriesURLGenerator(0, var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesCreateEntities((-16777216), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition(100);
    boolean var6 = var2.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var8 = var7.getFixedLegendItems();
    var2.setPlot(var7);
    java.awt.Paint var10 = var2.getErrorIndicatorPaint();
    java.awt.Paint var11 = var2.getBaseOutlinePaint();
    boolean var13 = var2.isSeriesVisible(0);
    java.awt.Paint var14 = null;
    var2.setErrorIndicatorPaint(var14);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var16 = var2.getLegendItemLabelGenerator();
    java.awt.Stroke var19 = var2.getItemStroke(1, 10);
    var0.setSeriesOutlineStroke(255, var19);
    org.jfree.chart.labels.CategoryItemLabelGenerator var22 = var0.getSeriesItemLabelGenerator(10);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var24 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Stroke var25 = var24.getBaseOutlineStroke();
    java.lang.Boolean var27 = var24.getSeriesCreateEntities(100);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var28 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var30 = var28.getSeriesNegativeItemLabelPosition(100);
    boolean var32 = var28.isSeriesVisible(10);
    var28.setAutoPopulateSeriesPaint(false);
    boolean var36 = var28.isSeriesItemLabelsVisible(0);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var37 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    double var38 = var37.getMinimumBarLength();
    java.awt.Paint var39 = var37.getErrorIndicatorPaint();
    var28.setBaseOutlinePaint(var39, false);
    var24.setBaseItemLabelPaint(var39);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelPaint((-16777216), var39);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
//     java.awt.Stroke var2 = var0.getStroke((-1));
//     java.lang.Object var3 = var0.clone();
//     java.lang.Object var4 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var3 and var4
//     assertTrue("Contract failed: equals-hashcode on var3 and var4", var3.equals(var4) ? var3.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var3
//     assertTrue("Contract failed: equals-hashcode on var4 and var3", var4.equals(var3) ? var4.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    float[] var6 = new float[] { (-1.0f), 100.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var7 = var3.getRGBComponents(var6);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    java.lang.Comparable var0 = null;
    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var2 = var1.getFixedLegendItems();
//     java.awt.Stroke var3 = var1.getOutlineStroke();
//     java.awt.Stroke var4 = var1.getOutlineStroke();
//     org.jfree.chart.axis.ValueAxis var5 = var1.getRangeAxis();
//     java.awt.Stroke var6 = var1.getOutlineStroke();
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot)var1);
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.ChartRenderingInfo var10 = null;
//     var7.draw(var8, var9, var10);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("hi!");
    boolean var3 = var1.equals((java.lang.Object)"Category Plot");
    var1.setToolTipText("hi!");
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var8 = var7.getInsets();
    java.lang.String var9 = var8.toString();
    var6.setTickLabelInsets(var8);
    double var12 = var8.calculateLeftInset(0.0d);
    double var14 = var8.calculateLeftOutset(0.0d);
    var1.setPadding(var8);
    var1.setText("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    org.jfree.chart.util.RectangleEdge var18 = var1.getPosition();
    var1.setWidth(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"+ "'", var9.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.zoomRange(100.0d, 100.0d);
//     var0.setAutoRangeStickyZero(true);
//     org.jfree.chart.plot.Plot var6 = var0.getPlot();
//     org.jfree.chart.event.AxisChangeEvent var7 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var0);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var10 = var9.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var11 = var9.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var14 = var12.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var17 = var12.getItemLabelPaint(0, 10);
//     var9.setNoDataMessagePaint(var17);
//     var9.configureDomainAxes();
//     float var20 = var9.getBackgroundAlpha();
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
//     java.awt.Image var22 = null;
//     var21.setBackgroundImage(var22);
//     var21.setBackgroundImageAlignment(100);
//     java.awt.Color var29 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var30 = var29.getRed();
//     java.awt.Color var31 = var29.brighter();
//     float[] var35 = new float[] { 100.0f, 10.0f, 100.0f};
//     float[] var36 = var29.getRGBColorComponents(var35);
//     var21.setBackgroundPaint((java.awt.Paint)var29);
//     var7.setChart(var21);
//     org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var41 = null;
//     var40.notifyListeners(var41);
//     var40.setValue((-1.0d));
//     org.jfree.chart.util.RectangleInsets var45 = var40.getLabelOffset();
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var47 = var46.getFixedLegendItems();
//     java.awt.Stroke var48 = var46.getOutlineStroke();
//     var46.setDrawSharedDomainAxis(true);
//     org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var53 = var52.getInsets();
//     java.lang.String var54 = var53.toString();
//     var51.setTickLabelInsets(var53);
//     var46.setAxisOffset(var53);
//     var40.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var46);
//     java.awt.Paint var58 = var40.getOutlinePaint();
//     var21.setBorderPaint(var58);
//     
//     // Checks the contract:  equals-hashcode on var9 and var52
//     assertTrue("Contract failed: equals-hashcode on var9 and var52", var9.equals(var52) ? var9.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var9
//     assertTrue("Contract failed: equals-hashcode on var52 and var9", var52.equals(var9) ? var52.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.axis.AxisState var2 = null;
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    java.util.List var5 = var0.refreshTicks(var1, var2, var3, var4);
    boolean var6 = var0.isTickMarksVisible();
    org.jfree.data.RangeType var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeType(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = var0.getSeriesToolTipGenerator((-16777216));
    boolean var5 = var0.isItemLabelVisible(255, (-16777216));
    org.jfree.chart.renderer.category.StatisticalBarRenderer var7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var7.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var12 = var7.getItemLabelPaint(0, 10);
    org.jfree.chart.labels.ItemLabelPosition var14 = var7.getSeriesNegativeItemLabelPosition(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPositiveItemLabelPosition((-1), var14, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(1);
    java.awt.Image var3 = var0.getBackgroundImage();
    org.jfree.chart.util.RectangleEdge var5 = var0.getRangeAxisEdge((-1));
    org.jfree.chart.annotations.CategoryAnnotation var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    var1.zoomRange(0.0d, 100.0d);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(100);
    boolean var9 = var5.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var11 = var10.getFixedLegendItems();
    var5.setPlot(var10);
    java.awt.Paint var13 = var10.getBackgroundPaint();
    var1.setPlot((org.jfree.chart.plot.Plot)var10);
    org.jfree.chart.axis.NumberTickUnit var15 = var1.getTickUnit();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var18 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)var15, 0.0d, 255);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 10);
// 
//   }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var0);
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, 1.0d);
    double var4 = var2.constrain((-1.0d));
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
    java.lang.String var8 = var7.toString();
    var5.setTickLabelInsets(var7);
    boolean var10 = var2.equals((java.lang.Object)var5);
    var5.setLabelToolTip("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    var5.setTickMarkOutsideLength(1.0f);
    var5.setVisible(false);
    var5.setAxisLineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"+ "'", var8.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition(100);
//     boolean var6 = var2.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var8 = var7.getFixedLegendItems();
//     var2.setPlot(var7);
//     java.awt.Paint var10 = var2.getErrorIndicatorPaint();
//     java.awt.Paint var11 = var2.getBaseOutlinePaint();
//     boolean var13 = var2.isSeriesVisible(0);
//     java.awt.Paint var14 = null;
//     var2.setErrorIndicatorPaint(var14);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var16 = var2.getLegendItemLabelGenerator();
//     java.awt.Stroke var19 = var2.getItemStroke(1, 10);
//     var0.setSeriesOutlineStroke(255, var19);
//     org.jfree.chart.urls.CategoryURLGenerator var21 = null;
//     var0.setBaseURLGenerator(var21, true);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var26 = var25.getFixedLegendItems();
//     java.awt.Stroke var27 = var25.getOutlineStroke();
//     java.awt.Stroke var28 = var25.getOutlineStroke();
//     var0.setSeriesStroke(100, var28);
//     
//     // Checks the contract:  equals-hashcode on var7 and var25
//     assertTrue("Contract failed: equals-hashcode on var7 and var25", var7.equals(var25) ? var7.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var7
//     assertTrue("Contract failed: equals-hashcode on var25 and var7", var25.equals(var7) ? var25.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var3 = null;
//     var0.setBaseURLGenerator(var3, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var0.getBaseItemLabelGenerator();
//     double var7 = var0.getUpperClip();
//     var0.setAutoPopulateSeriesOutlineStroke(true);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var13 = var11.getSeriesNegativeItemLabelPosition(100);
//     boolean var15 = var11.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var17 = var16.getFixedLegendItems();
//     var11.setPlot(var16);
//     java.awt.Paint var19 = var11.getErrorIndicatorPaint();
//     var11.setBase(100.0d);
//     boolean var24 = var11.getItemVisible(1, 1);
//     org.jfree.chart.urls.CategoryURLGenerator var25 = null;
//     var11.setBaseURLGenerator(var25);
//     org.jfree.chart.labels.ItemLabelPosition var27 = new org.jfree.chart.labels.ItemLabelPosition();
//     var11.setBasePositiveItemLabelPosition(var27);
//     var0.setSeriesPositiveItemLabelPosition(255, var27);
//     
//     // Checks the contract:  equals-hashcode on var2 and var13
//     assertTrue("Contract failed: equals-hashcode on var2 and var13", var2.equals(var13) ? var2.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var2
//     assertTrue("Contract failed: equals-hashcode on var13 and var2", var13.equals(var2) ? var13.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.0d, 100.0d);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var2 = var1.getCategoryAnchor();
    org.jfree.chart.axis.CategoryLabelWidthType var3 = var1.getWidthType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var4 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var2 = var1.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var3 = var1.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var9 = var4.getItemLabelPaint(0, 10);
//     var1.setNoDataMessagePaint(var9);
//     var1.configureDomainAxes();
//     float var12 = var1.getBackgroundAlpha();
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var16 = var14.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var19 = var14.getItemLabelPaint(0, 10);
//     java.awt.Stroke var21 = var14.getSeriesStroke(1);
//     java.awt.Color var25 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     var14.setBaseItemLabelPaint((java.awt.Paint)var25);
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
//     var30.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var34 = var30.getTickMarkStroke();
//     var29.setStroke(var34);
//     var14.setSeriesOutlineStroke(1, var34, true);
//     var13.setBorderStroke(var34);
//     
//     // Checks the contract:  equals-hashcode on var6 and var16
//     assertTrue("Contract failed: equals-hashcode on var6 and var16", var6.equals(var16) ? var6.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var6
//     assertTrue("Contract failed: equals-hashcode on var16 and var6", var16.equals(var6) ? var16.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
//     boolean var8 = var4.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var10 = var9.getFixedLegendItems();
//     var4.setPlot(var9);
//     java.awt.Paint var12 = var4.getErrorIndicatorPaint();
//     var4.setBase(100.0d);
//     boolean var17 = var4.getItemVisible(1, 1);
//     java.awt.Shape var19 = var4.lookupSeriesShape(100);
//     org.jfree.chart.entity.LegendItemEntity var20 = new org.jfree.chart.entity.LegendItemEntity(var19);
//     java.awt.Shape var21 = var20.getArea();
//     java.awt.Shape var22 = var20.getArea();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var25 = var23.getSeriesNegativeItemLabelPosition(100);
//     boolean var27 = var23.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var29 = var28.getFixedLegendItems();
//     var23.setPlot(var28);
//     java.awt.Paint var31 = var23.getErrorIndicatorPaint();
//     var23.setBase(100.0d);
//     boolean var36 = var23.getItemVisible(1, 1);
//     java.awt.Stroke var37 = var23.getBaseOutlineStroke();
//     java.awt.Color var41 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     org.jfree.chart.LegendItem var42 = new org.jfree.chart.LegendItem("SortOrder.ASCENDING", "HorizontalAlignment.CENTER", "SortOrder.ASCENDING", "SortOrder.ASCENDING", var22, var37, (java.awt.Paint)var41);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var23 and var4.", var23.equals(var4) == var4.equals(var23));
//     
//     // Checks the contract:  equals-hashcode on var6 and var25
//     assertTrue("Contract failed: equals-hashcode on var6 and var25", var6.equals(var25) ? var6.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var6
//     assertTrue("Contract failed: equals-hashcode on var25 and var6", var25.equals(var6) ? var25.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var2 = var1.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var3 = var1.getDataset();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var9 = var4.getItemLabelPaint(0, 10);
    var1.setNoDataMessagePaint(var9);
    var1.configureDomainAxes();
    float var12 = var1.getBackgroundAlpha();
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
    java.awt.Image var14 = null;
    var13.setBackgroundImage(var14);
    var13.setBackgroundImageAlignment(100);
    int var18 = var13.getSubtitleCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var20 = var13.getSubtitle(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);

  }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     boolean var11 = var0.isSeriesVisible(0);
//     java.awt.Paint var12 = null;
//     var0.setErrorIndicatorPaint(var12);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var0.getLegendItemLabelGenerator();
//     java.awt.Stroke var17 = var0.getItemStroke(1, 10);
//     java.awt.Paint var19 = null;
//     var0.setSeriesFillPaint(10, var19, true);
//     boolean var22 = var0.getAutoPopulateSeriesOutlinePaint();
//     org.jfree.chart.LegendItemCollection var23 = var0.getLegendItems();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var24 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var26 = var24.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var29 = var24.getItemLabelPaint(0, 10);
//     org.jfree.chart.labels.ItemLabelPosition var31 = var24.getSeriesNegativeItemLabelPosition(0);
//     var0.setBaseNegativeItemLabelPosition(var31, true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var26
//     assertTrue("Contract failed: equals-hashcode on var2 and var26", var2.equals(var26) ? var2.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var31
//     assertTrue("Contract failed: equals-hashcode on var2 and var31", var2.equals(var31) ? var2.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var2
//     assertTrue("Contract failed: equals-hashcode on var26 and var2", var26.equals(var2) ? var26.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var2
//     assertTrue("Contract failed: equals-hashcode on var31 and var2", var31.equals(var2) ? var31.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
    double var3 = var1.calculateTopOutset(1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Paint var2 = null;
//     org.jfree.chart.text.TextMeasurer var5 = null;
//     org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 0.0f, 1, var5);
//     java.util.List var7 = var6.getLines();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.text.TextBlockAnchor var11 = null;
//     java.awt.Shape var15 = var6.calculateBounds(var8, (-1.0f), 10.0f, var11, 1.0f, 0.0f, 0.0d);
//     org.jfree.chart.text.TextLine var16 = var6.getLastLine();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var20 = var18.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var21 = null;
//     var18.setBaseURLGenerator(var21, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var24 = var18.getBaseItemLabelGenerator();
//     java.awt.Font var25 = var18.getBaseItemLabelFont();
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var28 = var27.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var29 = var27.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var32 = var30.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var35 = var30.getItemLabelPaint(0, 10);
//     var27.setNoDataMessagePaint(var35);
//     var27.configureDomainAxes();
//     float var38 = var27.getBackgroundAlpha();
//     org.jfree.chart.JFreeChart var39 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var27);
//     java.awt.Color var47 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var48 = var47.getRed();
//     java.awt.Color var49 = var47.brighter();
//     java.awt.image.ColorModel var50 = null;
//     java.awt.Rectangle var51 = null;
//     java.awt.geom.Rectangle2D var52 = null;
//     java.awt.geom.AffineTransform var53 = null;
//     java.awt.RenderingHints var54 = null;
//     java.awt.PaintContext var55 = var49.createContext(var50, var51, var52, var53, var54);
//     org.jfree.chart.util.ObjectList var56 = new org.jfree.chart.util.ObjectList();
//     boolean var57 = var49.equals((java.lang.Object)var56);
//     org.jfree.chart.block.BlockBorder var58 = new org.jfree.chart.block.BlockBorder(Double.NaN, (-5.0d), (-1.0d), 0.05d, (java.awt.Paint)var49);
//     var39.setBorderPaint((java.awt.Paint)var49);
//     java.awt.color.ColorSpace var60 = var49.getColorSpace();
//     var6.addLine("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var25, (java.awt.Paint)var49);
//     
//     // Checks the contract:  equals-hashcode on var20 and var32
//     assertTrue("Contract failed: equals-hashcode on var20 and var32", var20.equals(var32) ? var20.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var20
//     assertTrue("Contract failed: equals-hashcode on var32 and var20", var32.equals(var20) ? var32.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var2 = var1.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var3 = var1.getDataset();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var9 = var4.getItemLabelPaint(0, 10);
    var1.setNoDataMessagePaint(var9);
    var1.configureDomainAxes();
    float var12 = var1.getBackgroundAlpha();
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
    java.awt.Image var14 = null;
    var13.setBackgroundImage(var14);
    var13.setBackgroundImageAlignment(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var18 = var13.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0f);

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var11 = var9.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var12 = null;
//     var9.setBaseURLGenerator(var12, true);
//     int var15 = var9.getColumnCount();
//     java.awt.Font var16 = var9.getBaseItemLabelFont();
//     java.awt.Color var20 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var21 = var20.getRed();
//     org.jfree.chart.text.TextLine var22 = new org.jfree.chart.text.TextLine("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var16, (java.awt.Paint)var20);
//     java.awt.Color var27 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var28 = var27.getRed();
//     java.awt.Color var29 = var27.brighter();
//     int var30 = var27.getAlpha();
//     java.awt.Color var37 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var38 = var37.getRed();
//     java.awt.Color var39 = var37.brighter();
//     float[] var43 = new float[] { 100.0f, 10.0f, 100.0f};
//     float[] var44 = var37.getRGBColorComponents(var43);
//     float[] var45 = java.awt.Color.RGBtoHSB(10, 10, 255, var43);
//     float[] var46 = var27.getColorComponents(var45);
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var48 = var47.getFixedLegendItems();
//     java.awt.Stroke var49 = var47.getOutlineStroke();
//     java.awt.Stroke var50 = var47.getOutlineStroke();
//     org.jfree.chart.axis.ValueAxis var51 = var47.getRangeAxis();
//     var47.setDomainGridlinesVisible(true);
//     org.jfree.chart.axis.AxisLocation var55 = var47.getRangeAxisLocation(0);
//     double var56 = var47.getRangeCrosshairValue();
//     java.awt.Stroke var57 = var47.getDomainGridlineStroke();
//     java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 1.0f);
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var63 = var62.getFixedLegendItems();
//     java.awt.Stroke var64 = var62.getOutlineStroke();
//     java.awt.Stroke var65 = var62.getOutlineStroke();
//     org.jfree.chart.axis.ValueAxis var66 = var62.getRangeAxis();
//     var62.setDomainGridlinesVisible(true);
//     org.jfree.chart.axis.AxisLocation var70 = var62.getRangeAxisLocation(0);
//     double var71 = var62.getRangeCrosshairValue();
//     java.awt.Stroke var72 = var62.getDomainGridlineStroke();
//     java.awt.Paint var73 = null;
//     org.jfree.chart.LegendItem var74 = new org.jfree.chart.LegendItem("Category Plot", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "SortOrder.ASCENDING", "Category Plot", false, var6, false, (java.awt.Paint)var20, true, (java.awt.Paint)var27, var57, false, var61, var72, var73);
//     
//     // Checks the contract:  equals-hashcode on var47 and var62
//     assertTrue("Contract failed: equals-hashcode on var47 and var62", var47.equals(var62) ? var47.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var47
//     assertTrue("Contract failed: equals-hashcode on var62 and var47", var62.equals(var47) ? var62.hashCode() == var47.hashCode() : true);
// 
//   }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
    var0.setPlot(var5);
    java.awt.Paint var8 = var0.getErrorIndicatorPaint();
    var0.setBase(100.0d);
    boolean var13 = var0.getItemVisible(1, 1);
    org.jfree.chart.urls.CategoryURLGenerator var14 = null;
    var0.setBaseURLGenerator(var14);
    org.jfree.chart.labels.ItemLabelPosition var16 = new org.jfree.chart.labels.ItemLabelPosition();
    var0.setBasePositiveItemLabelPosition(var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesCreateEntities((-16777216), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesToolTipGenerator((-16777216), var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.zoomRange(0.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var6 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)100, (java.lang.Number)10);
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var8 = var7.getFixedLegendItems();
    java.awt.Stroke var9 = var7.getOutlineStroke();
    org.jfree.chart.axis.AxisLocation var11 = var7.getRangeAxisLocation(10);
    boolean var12 = var6.equals((java.lang.Object)var7);
    var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var7);
    java.awt.Image var14 = null;
    var7.setBackgroundImage(var14);
    org.jfree.chart.util.RectangleInsets var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setAxisOffset(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     var1.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var5 = var1.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.util.RectangleEdge var8 = null;
//     double var9 = var1.java2DToValue(0.0d, var7, var8);
//     org.jfree.data.Range var10 = null;
//     org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, 1.0d);
//     double var14 = var12.constrain((-1.0d));
//     var1.setRangeWithMargins(var12, true, false);
//     org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var12);
//     org.jfree.chart.util.Size2D var19 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var20 = var18.calculateConstrainedSize(var19);
//     var19.setWidth(0.0d);
//     double var23 = var19.getHeight();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.0d);
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    org.jfree.data.category.CategoryDataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var3 = var0.generateLabel(var1, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     int var2 = var0.getRangeAxisIndex(var1);
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     var3.clearDomainMarkers(1);
//     java.awt.Image var6 = var3.getBackgroundImage();
//     org.jfree.chart.util.SortOrder var7 = var3.getRowRenderingOrder();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var9 = var8.getFixedLegendItems();
//     java.awt.Stroke var10 = var8.getOutlineStroke();
//     java.awt.Stroke var11 = var8.getOutlineStroke();
//     org.jfree.chart.axis.ValueAxis var12 = var8.getRangeAxis();
//     var8.setDomainGridlinesVisible(true);
//     org.jfree.chart.axis.AxisLocation var16 = var8.getRangeAxisLocation(0);
//     org.jfree.chart.plot.PlotRenderingInfo var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     org.jfree.chart.util.RectangleAnchor var21 = null;
//     java.awt.geom.Point2D var22 = org.jfree.chart.util.RectangleAnchor.coordinates(var20, var21);
//     var8.zoomDomainAxes(0.0d, 8.0d, var19, var22);
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     var8.setRangeAxis(var24);
//     org.jfree.chart.plot.Plot var26 = var8.getRootPlot();
//     boolean var27 = var7.equals((java.lang.Object)var8);
//     var0.setColumnRenderingOrder(var7);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
//     var0.setNoDataMessagePaint(var8);
//     var0.configureDomainAxes();
//     float var11 = var0.getBackgroundAlpha();
//     var0.setRangeCrosshairLockedOnData(true);
//     org.jfree.data.category.CategoryDataset var15 = var0.getDataset(100);
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var17 = new org.jfree.chart.axis.ValueAxis[] { var16};
//     var0.setRangeAxes(var17);
//     org.jfree.chart.axis.CategoryAxis var19 = var0.getDomainAxis();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var24 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var26 = var24.getSeriesNegativeItemLabelPosition(100);
//     boolean var28 = var24.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var30 = var29.getFixedLegendItems();
//     var24.setPlot(var29);
//     java.awt.Paint var32 = var29.getBackgroundPaint();
//     org.jfree.chart.block.BlockBorder var33 = new org.jfree.chart.block.BlockBorder(100.0d, 1.0d, 0.0d, 0.0d, var32);
//     var0.setDomainGridlinePaint(var32);
//     
//     // Checks the contract:  equals-hashcode on var5 and var26
//     assertTrue("Contract failed: equals-hashcode on var5 and var26", var5.equals(var26) ? var5.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var5
//     assertTrue("Contract failed: equals-hashcode on var26 and var5", var26.equals(var5) ? var26.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var1 = null;
//     org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, 1.0d);
//     double var5 = var3.constrain((-1.0d));
//     org.jfree.data.Range var6 = org.jfree.data.Range.combine(var0, var3);
//     org.jfree.data.Range var9 = org.jfree.data.Range.shift(var0, 0.0d, false);
// 
//   }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 3.0d, 0.0f, 1.0f);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Stroke var11 = var10.getBaseOutlineStroke();
    boolean var13 = var10.isSeriesVisible(10);
    java.awt.Paint var16 = var10.getItemFillPaint(255, 0);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Stroke var18 = var17.getBaseOutlineStroke();
    var10.setBaseStroke(var18, false);
    java.awt.Color var28 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var29 = var28.getRed();
    java.awt.Color var30 = var28.brighter();
    java.awt.image.ColorModel var31 = null;
    java.awt.Rectangle var32 = null;
    java.awt.geom.Rectangle2D var33 = null;
    java.awt.geom.AffineTransform var34 = null;
    java.awt.RenderingHints var35 = null;
    java.awt.PaintContext var36 = var30.createContext(var31, var32, var33, var34, var35);
    org.jfree.chart.util.ObjectList var37 = new org.jfree.chart.util.ObjectList();
    boolean var38 = var30.equals((java.lang.Object)var37);
    org.jfree.chart.block.BlockBorder var39 = new org.jfree.chart.block.BlockBorder(Double.NaN, (-5.0d), (-1.0d), 0.05d, (java.awt.Paint)var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var40 = new org.jfree.chart.LegendItem(var0, "Category Plot", "TextAnchor.CENTER", "hi!", var5, var18, (java.awt.Paint)var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    org.jfree.data.category.CategoryDataset var5 = null;
    java.lang.Comparable var6 = null;
    java.lang.Comparable var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var8 = new org.jfree.chart.entity.CategoryItemEntity(var2, "rect", "", var5, var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
    var0.setPlot(var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesCreateEntities((-16777216), (java.lang.Boolean)true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.zoomRange(100.0d, 100.0d);
//     var0.setLowerBound(10.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var8 = var6.getSeriesNegativeItemLabelPosition(100);
//     boolean var10 = var6.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var12 = var11.getFixedLegendItems();
//     var6.setPlot(var11);
//     java.awt.Paint var14 = var6.getErrorIndicatorPaint();
//     var6.setBase(100.0d);
//     boolean var19 = var6.getItemVisible(1, 1);
//     java.awt.Shape var21 = var6.lookupSeriesShape(100);
//     var0.setUpArrow(var21);
//     java.lang.String var23 = var0.getLabel();
//     double var24 = var0.getUpperMargin();
//     var0.setInverted(false);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
//     org.jfree.chart.entity.AxisLabelEntity var32 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var29, "LegendItemEntity: seriesKey=null, dataset=null", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
//     var33.zoomRange(100.0d, 100.0d);
//     var33.setLowerBound(10.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var41 = var39.getSeriesNegativeItemLabelPosition(100);
//     boolean var43 = var39.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var45 = var44.getFixedLegendItems();
//     var39.setPlot(var44);
//     java.awt.Paint var47 = var39.getErrorIndicatorPaint();
//     var39.setBase(100.0d);
//     boolean var52 = var39.getItemVisible(1, 1);
//     java.awt.Shape var54 = var39.lookupSeriesShape(100);
//     var33.setUpArrow(var54);
//     java.lang.String var56 = var33.getLabel();
//     double var57 = var33.getUpperMargin();
//     var33.setInverted(false);
//     var33.setLabel("Category Plot");
//     org.jfree.data.Range var62 = null;
//     org.jfree.data.Range var64 = org.jfree.data.Range.expandToInclude(var62, 1.0d);
//     double var66 = var64.constrain((-1.0d));
//     org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var68 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var69 = var68.getInsets();
//     java.lang.String var70 = var69.toString();
//     var67.setTickLabelInsets(var69);
//     boolean var72 = var64.equals((java.lang.Object)var67);
//     double var73 = var64.getCentralValue();
//     var33.setRangeWithMargins(var64, false, true);
//     var0.setRangeWithMargins(var64, false, true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var41
//     assertTrue("Contract failed: equals-hashcode on var8 and var41", var8.equals(var41) ? var8.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var8
//     assertTrue("Contract failed: equals-hashcode on var41 and var8", var41.equals(var8) ? var41.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var44
//     assertTrue("Contract failed: equals-hashcode on var11 and var44", var11.equals(var44) ? var11.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var11
//     assertTrue("Contract failed: equals-hashcode on var44 and var11", var44.equals(var11) ? var44.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    double var2 = var1.getMinimumBarLength();
    var1.setAutoPopulateSeriesStroke(false);
    java.awt.Font var5 = var1.getBaseItemLabelFont();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    var6.clearDomainMarkers(1);
    java.awt.Paint var9 = var6.getRangeCrosshairPaint();
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder(var9);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.clearDomainMarkers(1);
    java.awt.Image var14 = var11.getBackgroundImage();
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    java.awt.geom.Point2D var17 = null;
    var11.zoomRangeAxes(100.0d, var16, var17);
    var11.setRangeCrosshairValue(1.0d);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11);
    org.jfree.chart.util.RectangleEdge var23 = var11.getDomainAxisEdge(10);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var27 = var25.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.urls.CategoryURLGenerator var28 = null;
    var25.setBaseURLGenerator(var28, true);
    int var31 = var25.getColumnCount();
    java.awt.Font var32 = var25.getBaseItemLabelFont();
    org.jfree.chart.title.TextTitle var33 = new org.jfree.chart.title.TextTitle("", var32);
    org.jfree.chart.axis.CategoryLabelPosition var34 = new org.jfree.chart.axis.CategoryLabelPosition();
    boolean var35 = var33.equals((java.lang.Object)var34);
    double var36 = var33.getContentXOffset();
    java.lang.String var37 = var33.getURLText();
    org.jfree.chart.util.HorizontalAlignment var38 = var33.getTextAlignment();
    java.lang.String var39 = var38.toString();
    org.jfree.chart.util.VerticalAlignment var40 = null;
    org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis();
    var41.zoomRange(0.0d, 100.0d);
    java.awt.Stroke var45 = var41.getTickMarkStroke();
    boolean var46 = var41.isAutoRange();
    double var47 = var41.getUpperBound();
    java.lang.String var48 = var41.getLabelToolTip();
    org.jfree.chart.util.RectangleInsets var49 = var41.getLabelInsets();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle("3", var5, var9, var23, var38, var40, var49);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var39.equals("HorizontalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
    var0.setPlot(var5);
    java.awt.Paint var8 = var0.getErrorIndicatorPaint();
    java.awt.Paint var9 = var0.getBaseOutlinePaint();
    boolean var11 = var0.isSeriesVisible(0);
    java.awt.Paint var12 = null;
    var0.setErrorIndicatorPaint(var12);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var0.getLegendItemLabelGenerator();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var15 = var0.getLegendItemURLGenerator();
    org.jfree.chart.labels.CategoryItemLabelGenerator var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelGenerator((-1), var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    int var1 = var0.size();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    var2.zoomRange(100.0d, 100.0d);
    var2.setLowerBound(10.0d);
    org.jfree.chart.axis.NumberTickUnit var8 = var2.getTickUnit();
    java.lang.String var10 = var8.valueToString(3.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var11 = var0.getLargerTickUnit((org.jfree.chart.axis.TickUnit)var8);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "3"+ "'", var10.equals("3"));

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.text.TextAnchor var1 = var0.getRotationAnchor();
    org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.text.TextAnchor var3 = var2.getRotationAnchor();
    org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPosition var5 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var6 = var5.getCategoryAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var7 = new org.jfree.chart.axis.CategoryLabelPositions(var0, var2, var4, var5);
    org.jfree.chart.util.RectangleAnchor var8 = var2.getCategoryAnchor();
    org.jfree.chart.text.TextBlockAnchor var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var10 = new org.jfree.chart.axis.CategoryLabelPosition(var8, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var2 = var1.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var3 = var1.getDataset();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var9 = var4.getItemLabelPaint(0, 10);
    var1.setNoDataMessagePaint(var9);
    var1.configureDomainAxes();
    float var12 = var1.getBackgroundAlpha();
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
    java.awt.Image var14 = null;
    var13.setBackgroundImage(var14);
    var13.setBackgroundImageAlignment(100);
    int var18 = var13.getBackgroundImageAlignment();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var20 = var13.getSubtitle(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 100);

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(1);
//     java.awt.Image var3 = var0.getBackgroundImage();
//     org.jfree.chart.util.SortOrder var4 = var0.getRowRenderingOrder();
//     java.lang.Object var5 = null;
//     boolean var6 = var4.equals(var5);
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 1.0d);
//     double var11 = var9.constrain((-1.0d));
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var14 = var13.getInsets();
//     java.lang.String var15 = var14.toString();
//     var12.setTickLabelInsets(var14);
//     boolean var17 = var9.equals((java.lang.Object)var12);
//     var12.setLabelToolTip("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
//     java.awt.Stroke var20 = var12.getAxisLineStroke();
//     boolean var21 = var4.equals((java.lang.Object)var12);
//     
//     // Checks the contract:  equals-hashcode on var0 and var13
//     assertTrue("Contract failed: equals-hashcode on var0 and var13", var0.equals(var13) ? var0.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var0
//     assertTrue("Contract failed: equals-hashcode on var13 and var0", var13.equals(var0) ? var13.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     var2.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var6 = var2.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var2.java2DToValue(0.0d, var8, var9);
//     org.jfree.data.Range var11 = null;
//     org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 1.0d);
//     double var15 = var13.constrain((-1.0d));
//     var2.setRangeWithMargins(var13, true, false);
//     org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var13);
//     boolean var21 = var13.contains(4.0d);
//     org.jfree.chart.block.LengthConstraintType var22 = null;
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
//     var24.zoomRange(100.0d, 100.0d);
//     var24.setLowerBound(10.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var32 = var30.getSeriesNegativeItemLabelPosition(100);
//     boolean var34 = var30.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var36 = var35.getFixedLegendItems();
//     var30.setPlot(var35);
//     java.awt.Paint var38 = var30.getErrorIndicatorPaint();
//     var30.setBase(100.0d);
//     boolean var43 = var30.getItemVisible(1, 1);
//     java.awt.Shape var45 = var30.lookupSeriesShape(100);
//     var24.setUpArrow(var45);
//     java.lang.String var47 = var24.getLabel();
//     double var48 = var24.getUpperMargin();
//     var24.setInverted(false);
//     var24.setLabel("Category Plot");
//     org.jfree.data.Range var53 = null;
//     org.jfree.data.Range var55 = org.jfree.data.Range.expandToInclude(var53, 1.0d);
//     double var57 = var55.constrain((-1.0d));
//     org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var60 = var59.getInsets();
//     java.lang.String var61 = var60.toString();
//     var58.setTickLabelInsets(var60);
//     boolean var63 = var55.equals((java.lang.Object)var58);
//     double var64 = var55.getCentralValue();
//     var24.setRangeWithMargins(var55, false, true);
//     org.jfree.chart.block.LengthConstraintType var68 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.chart.block.RectangleConstraint var69 = new org.jfree.chart.block.RectangleConstraint(3.0d, var13, var22, 1.0E-8d, var55, var68);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 0.05d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var61 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"+ "'", var61.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1.0d);
// 
//   }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PlotRenderingInfo var3 = var1.getSubplotInfo(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { ""};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var3 = var0.getAutoPopulateSeriesOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var5 = var4.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var6 = var4.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var7.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var12 = var7.getItemLabelPaint(0, 10);
//     var4.setNoDataMessagePaint(var12);
//     var4.configureDomainAxes();
//     float var15 = var4.getBackgroundAlpha();
//     org.jfree.chart.axis.AxisLocation var17 = var4.getDomainAxisLocation(1);
//     org.jfree.chart.plot.PlotOrientation var18 = var4.getOrientation();
//     var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var4);
//     
//     // Checks the contract:  equals-hashcode on var2 and var9
//     assertTrue("Contract failed: equals-hashcode on var2 and var9", var2.equals(var9) ? var2.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var2
//     assertTrue("Contract failed: equals-hashcode on var9 and var2", var9.equals(var2) ? var9.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     boolean var11 = var0.isSeriesVisible(0);
//     java.awt.Paint var12 = null;
//     var0.setErrorIndicatorPaint(var12);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var0.getLegendItemLabelGenerator();
//     var0.setSeriesItemLabelsVisible(1, (java.lang.Boolean)true, false);
//     var0.setBase(Double.NaN);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var23 = var22.getFixedLegendItems();
//     java.awt.Stroke var24 = var22.getOutlineStroke();
//     var0.setSeriesStroke(0, var24);
//     
//     // Checks the contract:  equals-hashcode on var5 and var22
//     assertTrue("Contract failed: equals-hashcode on var5 and var22", var5.equals(var22) ? var5.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var5
//     assertTrue("Contract failed: equals-hashcode on var22 and var5", var22.equals(var5) ? var22.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("hi!");
    java.awt.Paint var2 = var1.getPaint();
    java.awt.Paint var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setPaint(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.intersects(var0, var1);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PlotRenderingInfo var3 = var1.getSubplotInfo(255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var2 = var1.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var3 = var1.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var9 = var4.getItemLabelPaint(0, 10);
//     var1.setNoDataMessagePaint(var9);
//     org.jfree.chart.JFreeChart var11 = null;
//     org.jfree.chart.event.ChartChangeEvent var12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var11);
//     org.jfree.chart.axis.CategoryAnchor var13 = var1.getDomainGridlinePosition();
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var18 = var17.getFixedLegendItems();
//     org.jfree.chart.util.RectangleEdge var19 = var17.getRangeAxisEdge();
//     double var20 = var0.getCategoryJava2DCoordinate(var13, 100, 1, var16, var19);
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var1.setBaseURLGenerator(var4, true);
    int var7 = var1.getColumnCount();
    java.awt.Font var8 = var1.getBaseItemLabelFont();
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var8);
    java.awt.geom.Rectangle2D var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.setBounds(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Comparable var1 = null;
    int var2 = var0.getColumnIndex(var1);
    int var3 = var0.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((-16777216));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
    boolean var5 = var1.isSeriesVisible(10);
    org.jfree.chart.LegendItem var8 = var1.getLegendItem(0, 0);
    java.lang.Boolean var10 = var1.getSeriesCreateEntities(0);
    java.awt.Paint var13 = var1.getItemFillPaint((-16777216), 255);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendGraphic var14 = new org.jfree.chart.title.LegendGraphic(var0, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     boolean var11 = var0.isSeriesVisible(0);
//     java.awt.Paint var12 = null;
//     var0.setErrorIndicatorPaint(var12);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var0.getLegendItemLabelGenerator();
//     var0.setSeriesItemLabelsVisible(1, (java.lang.Boolean)true, false);
//     var0.setBase(Double.NaN);
//     java.awt.Graphics2D var21 = null;
//     java.awt.geom.Rectangle2D var22 = null;
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var25 = var23.getRangeAxis(0);
//     org.jfree.chart.plot.DrawingSupplier var26 = null;
//     var23.setDrawingSupplier(var26);
//     var23.clearRangeMarkers(0);
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var32 = var0.initialise(var21, var22, var23, 100, var31);
// 
//   }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.general.DatasetGroup var5 = var4.getDatasetGroup();
//     org.jfree.chart.util.RectangleEdge var6 = var4.getDomainAxisEdge();
//     double var7 = var0.getCategoryMiddle(0, 0, var3, var6);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(1.0d);
    org.jfree.chart.util.RectangleEdge var2 = null;
    org.jfree.chart.axis.CategoryLabelPosition var3 = var1.getLabelPosition(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var2 = var1.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var3 = var1.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var9 = var4.getItemLabelPaint(0, 10);
//     var1.setNoDataMessagePaint(var9);
//     var1.configureDomainAxes();
//     float var12 = var1.getBackgroundAlpha();
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     java.awt.Image var14 = null;
//     var13.setBackgroundImage(var14);
//     var13.setBackgroundImageAlignment(100);
//     int var18 = var13.getBackgroundImageAlignment();
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("hi!");
//     boolean var22 = var20.equals((java.lang.Object)"Category Plot");
//     var20.setToolTipText("hi!");
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var27 = var26.getInsets();
//     java.lang.String var28 = var27.toString();
//     var25.setTickLabelInsets(var27);
//     double var31 = var27.calculateLeftInset(0.0d);
//     double var33 = var27.calculateLeftOutset(0.0d);
//     var20.setPadding(var27);
//     var13.addSubtitle((org.jfree.chart.title.Title)var20);
//     
//     // Checks the contract:  equals-hashcode on var1 and var26
//     assertTrue("Contract failed: equals-hashcode on var1 and var26", var1.equals(var26) ? var1.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var1
//     assertTrue("Contract failed: equals-hashcode on var26 and var1", var26.equals(var1) ? var26.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     var0.setBase(100.0d);
//     boolean var13 = var0.getItemVisible(1, 1);
//     java.awt.Shape var15 = var0.lookupSeriesShape(100);
//     org.jfree.chart.entity.LegendItemEntity var16 = new org.jfree.chart.entity.LegendItemEntity(var15);
//     java.awt.Shape var17 = var16.getArea();
//     var16.setToolTipText("");
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var22 = var20.getSeriesNegativeItemLabelPosition(100);
//     boolean var24 = var20.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var26 = var25.getFixedLegendItems();
//     var20.setPlot(var25);
//     java.awt.Paint var28 = var20.getErrorIndicatorPaint();
//     var20.setBase(100.0d);
//     boolean var33 = var20.getItemVisible(1, 1);
//     java.awt.Shape var35 = var20.lookupSeriesShape(100);
//     org.jfree.chart.entity.LegendItemEntity var36 = new org.jfree.chart.entity.LegendItemEntity(var35);
//     org.jfree.chart.entity.ChartEntity var39 = new org.jfree.chart.entity.ChartEntity(var35, "HorizontalAlignment.CENTER", "HorizontalAlignment.CENTER");
//     var16.setArea(var35);
//     
//     // Checks the contract:  equals-hashcode on var2 and var22
//     assertTrue("Contract failed: equals-hashcode on var2 and var22", var2.equals(var22) ? var2.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var2
//     assertTrue("Contract failed: equals-hashcode on var22 and var2", var22.equals(var2) ? var22.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var25
//     assertTrue("Contract failed: equals-hashcode on var5 and var25", var5.equals(var25) ? var5.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var5
//     assertTrue("Contract failed: equals-hashcode on var25 and var5", var25.equals(var5) ? var25.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var1.setBaseURLGenerator(var4, true);
    int var7 = var1.getColumnCount();
    java.awt.Font var8 = var1.getBaseItemLabelFont();
    java.awt.Color var12 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var13 = var12.getRed();
    org.jfree.chart.text.TextLine var14 = new org.jfree.chart.text.TextLine("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var8, (java.awt.Paint)var12);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var16 = var15.getFixedLegendItems();
    java.awt.Stroke var17 = var15.getOutlineStroke();
    org.jfree.chart.util.RectangleInsets var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var12, var17, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     var3.zoomRange(0.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var9 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)100, (java.lang.Number)10);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var11 = var10.getFixedLegendItems();
//     java.awt.Stroke var12 = var10.getOutlineStroke();
//     org.jfree.chart.axis.AxisLocation var14 = var10.getRangeAxisLocation(10);
//     boolean var15 = var9.equals((java.lang.Object)var10);
//     var3.addChangeListener((org.jfree.chart.event.AxisChangeListener)var10);
//     java.awt.Image var17 = null;
//     var10.setBackgroundImage(var17);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     var19.clearDomainMarkers(1);
//     java.awt.Image var22 = var19.getBackgroundImage();
//     float var23 = var19.getForegroundAlpha();
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var25 = var24.getFixedLegendItems();
//     java.awt.Stroke var26 = var24.getOutlineStroke();
//     org.jfree.chart.axis.AxisLocation var28 = var24.getRangeAxisLocation(10);
//     var19.setRangeAxisLocation(var28, true);
//     var10.setDomainAxisLocation(var28, false);
//     java.awt.Graphics2D var33 = null;
//     java.awt.geom.Rectangle2D var34 = null;
//     org.jfree.chart.ChartRenderingInfo var36 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var37 = new org.jfree.chart.plot.PlotRenderingInfo(var36);
//     boolean var38 = var10.render(var33, var34, (-16777216), var37);
//     java.awt.geom.Rectangle2D var39 = null;
//     var37.setDataArea(var39);
//     var0.handleClick((-16777216), (-1), var37);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.String var1 = var0.getLabel();
    org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.util.RectangleInsets var4 = var3.getLabelOffset();
    var0.setLabelInsets(var4);
    java.lang.String var6 = var4.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"+ "'", var6.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));

  }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     int var3 = var0.getPassCount();
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     var4.zoomRange(100.0d, 100.0d);
//     boolean var8 = var0.equals((java.lang.Object)100.0d);
//     org.jfree.chart.urls.CategoryURLGenerator var10 = var0.getSeriesURLGenerator((-1));
//     var0.setMinimumBarLength(1.0d);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var15 = var14.getFixedLegendItems();
//     java.awt.Stroke var16 = var14.getOutlineStroke();
//     java.awt.Stroke var17 = var14.getOutlineStroke();
//     org.jfree.chart.axis.ValueAxis var18 = var14.getRangeAxis();
//     float var19 = var14.getBackgroundImageAlpha();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var22 = var20.getSeriesNegativeItemLabelPosition(100);
//     boolean var24 = var20.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var26 = var25.getFixedLegendItems();
//     var20.setPlot(var25);
//     java.awt.Paint var28 = var25.getBackgroundPaint();
//     org.jfree.chart.LegendItemCollection var29 = var25.getFixedLegendItems();
//     java.awt.Paint var30 = var25.getRangeCrosshairPaint();
//     var14.setNoDataMessagePaint(var30);
//     boolean var32 = var14.isSubplot();
//     boolean var33 = var14.isDomainZoomable();
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis();
//     var36.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var40 = var36.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var42 = null;
//     org.jfree.chart.util.RectangleEdge var43 = null;
//     double var44 = var36.java2DToValue(0.0d, var42, var43);
//     org.jfree.data.Range var45 = null;
//     org.jfree.data.Range var47 = org.jfree.data.Range.expandToInclude(var45, 1.0d);
//     double var49 = var47.constrain((-1.0d));
//     var36.setRangeWithMargins(var47, true, false);
//     org.jfree.chart.block.RectangleConstraint var53 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var47);
//     org.jfree.chart.util.Size2D var54 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var55 = var53.calculateConstrainedSize(var54);
//     var55.setHeight(3.0d);
//     org.jfree.chart.plot.ValueMarker var61 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var62 = null;
//     var61.notifyListeners(var62);
//     var61.setValue((-1.0d));
//     java.awt.Stroke var66 = var61.getStroke();
//     org.jfree.chart.plot.ValueMarker var68 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.axis.NumberAxis var69 = new org.jfree.chart.axis.NumberAxis();
//     var69.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var73 = var69.getTickMarkStroke();
//     var68.setStroke(var73);
//     boolean var75 = var61.equals((java.lang.Object)var73);
//     org.jfree.chart.util.RectangleAnchor var76 = var61.getLabelAnchor();
//     java.awt.geom.Rectangle2D var77 = org.jfree.chart.util.RectangleAnchor.createRectangle(var55, 0.2d, 100.0d, var76);
//     var0.drawRangeGridline(var13, var14, var34, var77, (-11.0d));
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    java.awt.Stroke var2 = var0.getOutlineStroke();
    var0.setDrawSharedDomainAxis(true);
    org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(10);
    org.jfree.chart.annotations.CategoryAnnotation var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var8 = var0.removeAnnotation(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.ui.Library[] var1 = var0.getLibraries();
    var0.setInfo("hi!");
    org.jfree.chart.ui.ProjectInfo var4 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.ui.Library[] var5 = var4.getLibraries();
    java.lang.String var6 = var4.getName();
    var0.addLibrary((org.jfree.chart.ui.Library)var4);
    java.lang.String var8 = var0.getInfo();
    var0.setVersion("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "hi!"+ "'", var8.equals("hi!"));

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("HorizontalAlignment.CENTER");

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var2 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var3 = null;
//     var2.notifyListeners(var3);
//     var2.setValue((-1.0d));
//     java.awt.Stroke var7 = var2.getOutlineStroke();
//     org.jfree.chart.util.LengthAdjustmentType var8 = var2.getLabelOffsetType();
//     java.awt.Font var9 = var2.getLabelFont();
//     java.awt.Color var13 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var14 = var13.getRed();
//     java.awt.Color var15 = var13.brighter();
//     java.awt.image.ColorModel var16 = null;
//     java.awt.Rectangle var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     java.awt.geom.AffineTransform var19 = null;
//     java.awt.RenderingHints var20 = null;
//     java.awt.PaintContext var21 = var15.createContext(var16, var17, var18, var19, var20);
//     float[] var25 = new float[] { (-1.0f), (-1.0f), (-1.0f)};
//     float[] var26 = var15.getRGBColorComponents(var25);
//     org.jfree.chart.text.TextFragment var28 = new org.jfree.chart.text.TextFragment("rect", var9, (java.awt.Paint)var15, 0.0f);
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var32 = var30.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.text.TextAnchor var33 = var32.getTextAnchor();
//     float var34 = var28.calculateBaselineOffset(var29, var33);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    org.jfree.chart.renderer.category.StatisticalBarRenderer var6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    double var7 = var6.getMinimumBarLength();
    var6.setAutoPopulateSeriesStroke(false);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(100);
    boolean var14 = var10.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var16 = var15.getFixedLegendItems();
    var10.setPlot(var15);
    java.awt.Paint var18 = var10.getErrorIndicatorPaint();
    var6.setBaseItemLabelPaint(var18);
    java.lang.Boolean var21 = var6.getSeriesVisibleInLegend(0);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Stroke var23 = var22.getBaseOutlineStroke();
    boolean var25 = var22.isSeriesVisible(10);
    java.awt.Color var29 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var30 = var29.getRed();
    java.awt.Color var31 = var29.brighter();
    java.awt.image.ColorModel var32 = null;
    java.awt.Rectangle var33 = null;
    java.awt.geom.Rectangle2D var34 = null;
    java.awt.geom.AffineTransform var35 = null;
    java.awt.RenderingHints var36 = null;
    java.awt.PaintContext var37 = var31.createContext(var32, var33, var34, var35, var36);
    var22.setBaseFillPaint((java.awt.Paint)var31);
    int var39 = var31.getBlue();
    var6.setBaseFillPaint((java.awt.Paint)var31, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var42 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var44 = var42.getSeriesNegativeItemLabelPosition(100);
    boolean var46 = var42.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var48 = var47.getFixedLegendItems();
    var42.setPlot(var47);
    java.awt.Paint var50 = var42.getErrorIndicatorPaint();
    java.awt.Paint var51 = var42.getBaseOutlinePaint();
    org.jfree.chart.labels.CategoryItemLabelGenerator var53 = var42.getSeriesItemLabelGenerator((-1));
    java.awt.Stroke var55 = var42.lookupSeriesStroke(0);
    java.awt.Color var59 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var60 = var59.getRed();
    java.awt.Color var61 = var59.brighter();
    int var62 = var59.getAlpha();
    java.awt.Color var69 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var70 = var69.getRed();
    java.awt.Color var71 = var69.brighter();
    float[] var75 = new float[] { 100.0f, 10.0f, 100.0f};
    float[] var76 = var69.getRGBColorComponents(var75);
    float[] var77 = java.awt.Color.RGBtoHSB(10, 10, 255, var75);
    float[] var78 = var59.getColorComponents(var77);
    int var79 = var59.getTransparency();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var80 = new org.jfree.chart.LegendItem(var0, "3", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "ChartChangeEventType.GENERAL", var5, (java.awt.Paint)var31, var55, (java.awt.Paint)var59);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 1);

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var1 = var0.getUpperClip();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.clearDomainMarkers(1);
//     java.awt.Image var7 = var4.getBackgroundImage();
//     float var8 = var4.getForegroundAlpha();
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var10 = var9.getFixedLegendItems();
//     java.awt.Stroke var11 = var9.getOutlineStroke();
//     org.jfree.chart.axis.AxisLocation var13 = var9.getRangeAxisLocation(10);
//     var4.setRangeAxisLocation(var13, true);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
//     var17.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var21 = var17.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleEdge var24 = null;
//     double var25 = var17.java2DToValue(0.0d, var23, var24);
//     org.jfree.data.Range var26 = null;
//     org.jfree.data.Range var28 = org.jfree.data.Range.expandToInclude(var26, 1.0d);
//     double var30 = var28.constrain((-1.0d));
//     var17.setRangeWithMargins(var28, true, false);
//     org.jfree.chart.block.RectangleConstraint var34 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var28);
//     org.jfree.chart.util.Size2D var35 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var36 = var34.calculateConstrainedSize(var35);
//     var36.setHeight(3.0d);
//     org.jfree.chart.plot.ValueMarker var42 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var43 = null;
//     var42.notifyListeners(var43);
//     var42.setValue((-1.0d));
//     java.awt.Stroke var47 = var42.getStroke();
//     org.jfree.chart.plot.ValueMarker var49 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis();
//     var50.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var54 = var50.getTickMarkStroke();
//     var49.setStroke(var54);
//     boolean var56 = var42.equals((java.lang.Object)var54);
//     org.jfree.chart.util.RectangleAnchor var57 = var42.getLabelAnchor();
//     java.awt.geom.Rectangle2D var58 = org.jfree.chart.util.RectangleAnchor.createRectangle(var36, 0.2d, 100.0d, var57);
//     var0.drawOutline(var3, var4, var58);
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
    var0.setNoDataMessagePaint(var8);
    var0.configureDomainAxes();
    float var11 = var0.getBackgroundAlpha();
    var0.setRangeCrosshairLockedOnData(true);
    org.jfree.data.category.CategoryDataset var15 = var0.getDataset(100);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var17 = new org.jfree.chart.axis.ValueAxis[] { var16};
    var0.setRangeAxes(var17);
    org.jfree.chart.axis.CategoryAxis var19 = var0.getDomainAxis();
    var0.setAnchorValue((-6.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var3 = null;
//     var0.setBaseURLGenerator(var3, true);
//     int var6 = var0.getColumnCount();
//     boolean var7 = var0.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var9 = null;
//     var0.setSeriesPaint(10, var9);
//     java.awt.Stroke var13 = var0.getItemOutlineStroke(0, (-1));
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var16 = var15.getFixedLegendItems();
//     java.awt.Stroke var17 = var15.getOutlineStroke();
//     java.awt.Stroke var18 = var15.getOutlineStroke();
//     var15.setOutlineVisible(false);
//     org.jfree.chart.axis.AxisLocation var22 = var15.getDomainAxisLocation(0);
//     var15.setRangeCrosshairValue(10.0d, false);
//     org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.plot.CategoryMarker var27 = null;
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis();
//     var29.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var33 = var29.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var35 = null;
//     org.jfree.chart.util.RectangleEdge var36 = null;
//     double var37 = var29.java2DToValue(0.0d, var35, var36);
//     org.jfree.data.Range var38 = null;
//     org.jfree.data.Range var40 = org.jfree.data.Range.expandToInclude(var38, 1.0d);
//     double var42 = var40.constrain((-1.0d));
//     var29.setRangeWithMargins(var40, true, false);
//     org.jfree.chart.block.RectangleConstraint var46 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var40);
//     org.jfree.chart.util.Size2D var47 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var48 = var46.calculateConstrainedSize(var47);
//     var48.setHeight(3.0d);
//     org.jfree.chart.plot.ValueMarker var54 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var55 = null;
//     var54.notifyListeners(var55);
//     var54.setValue((-1.0d));
//     java.awt.Stroke var59 = var54.getStroke();
//     org.jfree.chart.plot.ValueMarker var61 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis();
//     var62.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var66 = var62.getTickMarkStroke();
//     var61.setStroke(var66);
//     boolean var68 = var54.equals((java.lang.Object)var66);
//     org.jfree.chart.util.RectangleAnchor var69 = var54.getLabelAnchor();
//     java.awt.geom.Rectangle2D var70 = org.jfree.chart.util.RectangleAnchor.createRectangle(var48, 0.2d, 100.0d, var69);
//     var0.drawDomainMarker(var14, var15, var26, var27, var70);
// 
//   }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     int var2 = var0.getRangeAxisIndex(var1);
//     int var3 = var0.getDatasetCount();
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var6 = null;
//     var5.notifyListeners(var6);
//     var5.setValue((-1.0d));
//     java.awt.Font var11 = null;
//     java.awt.Paint var12 = null;
//     org.jfree.chart.text.TextMeasurer var15 = null;
//     org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var11, var12, 0.0f, 1, var15);
//     java.util.List var17 = var16.getLines();
//     boolean var18 = var5.equals((java.lang.Object)var17);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     double var20 = var19.getMinimumBarLength();
//     var19.setAutoPopulateSeriesStroke(false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var25 = var23.getSeriesNegativeItemLabelPosition(100);
//     boolean var27 = var23.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var29 = var28.getFixedLegendItems();
//     var23.setPlot(var28);
//     java.awt.Paint var31 = var23.getErrorIndicatorPaint();
//     var19.setBaseItemLabelPaint(var31);
//     var5.setLabelPaint(var31);
//     org.jfree.chart.util.Layer var34 = null;
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var5, var34);
//     
//     // Checks the contract:  equals-hashcode on var0 and var28
//     assertTrue("Contract failed: equals-hashcode on var0 and var28", var0.equals(var28) ? var0.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var0
//     assertTrue("Contract failed: equals-hashcode on var28 and var0", var28.equals(var0) ? var28.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var4 = var0.getTickMarkStroke();
//     boolean var5 = var0.isAutoRange();
//     double var6 = var0.getUpperBound();
//     java.lang.String var7 = var0.getLabelToolTip();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var10 = var8.getRangeAxis(0);
//     java.awt.Paint var11 = var8.getOutlinePaint();
//     var0.setAxisLinePaint(var11);
//     float var13 = var0.getTickMarkInsideLength();
//     var0.centerRange((-11.0d));
//     org.jfree.chart.plot.Plot var16 = var0.getPlot();
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
//     var17.zoomRange(0.0d, 100.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var23 = var21.getSeriesNegativeItemLabelPosition(100);
//     boolean var25 = var21.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var27 = var26.getFixedLegendItems();
//     var21.setPlot(var26);
//     java.awt.Paint var29 = var26.getBackgroundPaint();
//     var17.setPlot((org.jfree.chart.plot.Plot)var26);
//     org.jfree.chart.axis.NumberTickUnit var31 = var17.getTickUnit();
//     java.awt.Color var35 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var36 = var35.getRed();
//     java.awt.Color var37 = var35.brighter();
//     java.awt.image.ColorModel var38 = null;
//     java.awt.Rectangle var39 = null;
//     java.awt.geom.Rectangle2D var40 = null;
//     java.awt.geom.AffineTransform var41 = null;
//     java.awt.RenderingHints var42 = null;
//     java.awt.PaintContext var43 = var37.createContext(var38, var39, var40, var41, var42);
//     float[] var47 = new float[] { (-1.0f), (-1.0f), (-1.0f)};
//     float[] var48 = var37.getRGBColorComponents(var47);
//     boolean var49 = var31.equals((java.lang.Object)var47);
//     var0.setTickUnit(var31);
//     
//     // Checks the contract:  equals-hashcode on var8 and var26
//     assertTrue("Contract failed: equals-hashcode on var8 and var26", var8.equals(var26) ? var8.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var8
//     assertTrue("Contract failed: equals-hashcode on var26 and var8", var26.equals(var8) ? var26.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var2 = var1.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var3 = var1.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var9 = var4.getItemLabelPaint(0, 10);
//     var1.setNoDataMessagePaint(var9);
//     var1.configureDomainAxes();
//     float var12 = var1.getBackgroundAlpha();
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     java.awt.Image var14 = null;
//     var13.setBackgroundImage(var14);
//     var13.setBackgroundImageAlignment(100);
//     java.awt.Color var21 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var22 = var21.getRed();
//     java.awt.Color var23 = var21.brighter();
//     float[] var27 = new float[] { 100.0f, 10.0f, 100.0f};
//     float[] var28 = var21.getRGBColorComponents(var27);
//     var13.setBackgroundPaint((java.awt.Paint)var21);
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var31 = var30.getInsets();
//     org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30);
//     java.awt.Paint var33 = var32.getBackgroundPaint();
//     org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var37 = null;
//     var36.notifyListeners(var37);
//     var36.setValue((-1.0d));
//     java.awt.Stroke var41 = var36.getOutlineStroke();
//     org.jfree.chart.util.LengthAdjustmentType var42 = var36.getLabelOffsetType();
//     java.awt.Font var43 = var36.getLabelFont();
//     java.awt.Color var47 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var48 = var47.getRed();
//     java.awt.Color var49 = var47.brighter();
//     java.awt.image.ColorModel var50 = null;
//     java.awt.Rectangle var51 = null;
//     java.awt.geom.Rectangle2D var52 = null;
//     java.awt.geom.AffineTransform var53 = null;
//     java.awt.RenderingHints var54 = null;
//     java.awt.PaintContext var55 = var49.createContext(var50, var51, var52, var53, var54);
//     float[] var59 = new float[] { (-1.0f), (-1.0f), (-1.0f)};
//     float[] var60 = var49.getRGBColorComponents(var59);
//     org.jfree.chart.text.TextFragment var62 = new org.jfree.chart.text.TextFragment("rect", var43, (java.awt.Paint)var49, 0.0f);
//     var32.setItemFont(var43);
//     org.jfree.chart.LegendItemSource[] var64 = var32.getSources();
//     var13.addLegend(var32);
//     
//     // Checks the contract:  equals-hashcode on var1 and var30
//     assertTrue("Contract failed: equals-hashcode on var1 and var30", var1.equals(var30) ? var1.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var1
//     assertTrue("Contract failed: equals-hashcode on var30 and var1", var30.equals(var1) ? var30.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)3.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.zoomRange(0.0d, 100.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
//     boolean var8 = var4.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var10 = var9.getFixedLegendItems();
//     var4.setPlot(var9);
//     java.awt.Paint var12 = var9.getBackgroundPaint();
//     var0.setPlot((org.jfree.chart.plot.Plot)var9);
//     org.jfree.chart.axis.NumberTickUnit var14 = var0.getTickUnit();
//     var0.setAutoTickUnitSelection(false);
//     var0.setTickLabelsVisible(true);
//     boolean var19 = var0.isInverted();
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     var20.clearDomainMarkers(1);
//     var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var20);
//     
//     // Checks the contract:  equals-hashcode on var9 and var20
//     assertTrue("Contract failed: equals-hashcode on var9 and var20", var9.equals(var20) ? var9.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var9
//     assertTrue("Contract failed: equals-hashcode on var20 and var9", var20.equals(var9) ? var20.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var3 = null;
//     var0.setBaseURLGenerator(var3, true);
//     int var6 = var0.getColumnCount();
//     boolean var7 = var0.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
//     var9.zoomRange(100.0d, 100.0d);
//     var9.setLowerBound(10.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var17 = var15.getSeriesNegativeItemLabelPosition(100);
//     boolean var19 = var15.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var21 = var20.getFixedLegendItems();
//     var15.setPlot(var20);
//     java.awt.Paint var23 = var15.getErrorIndicatorPaint();
//     var15.setBase(100.0d);
//     boolean var28 = var15.getItemVisible(1, 1);
//     java.awt.Shape var30 = var15.lookupSeriesShape(100);
//     var9.setUpArrow(var30);
//     java.lang.String var32 = var9.getLabel();
//     double var33 = var9.getUpperMargin();
//     var9.setInverted(false);
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
//     org.jfree.chart.entity.AxisLabelEntity var41 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var9, var38, "LegendItemEntity: seriesKey=null, dataset=null", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
//     var0.setSeriesShape(100, var38);
//     
//     // Checks the contract:  equals-hashcode on var2 and var17
//     assertTrue("Contract failed: equals-hashcode on var2 and var17", var2.equals(var17) ? var2.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var2
//     assertTrue("Contract failed: equals-hashcode on var17 and var2", var17.equals(var2) ? var17.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     double var1 = var0.getFixedAutoRange();
//     double var2 = var0.getUpperMargin();
//     var0.setAutoRangeMinimumSize(10.0d);
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     var5.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var9 = var5.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var5.java2DToValue(0.0d, var11, var12);
//     org.jfree.data.Range var14 = null;
//     org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, 1.0d);
//     double var18 = var16.constrain((-1.0d));
//     var5.setRangeWithMargins(var16, true, false);
//     var0.setRange(var16, false, true);
//     org.jfree.data.Range var27 = org.jfree.data.Range.expand(var16, 3.0d, 0.05d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.05d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.zoomRange(100.0d, 100.0d);
    var0.setLowerBound(10.0d);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var8 = var6.getSeriesNegativeItemLabelPosition(100);
    boolean var10 = var6.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var12 = var11.getFixedLegendItems();
    var6.setPlot(var11);
    java.awt.Paint var14 = var6.getErrorIndicatorPaint();
    var6.setBase(100.0d);
    boolean var19 = var6.getItemVisible(1, 1);
    java.awt.Shape var21 = var6.lookupSeriesShape(100);
    var0.setUpArrow(var21);
    java.lang.String var23 = var0.getLabel();
    double var24 = var0.getUpperMargin();
    var0.setInverted(false);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    org.jfree.chart.entity.AxisLabelEntity var32 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var29, "LegendItemEntity: seriesKey=null, dataset=null", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    java.lang.String var33 = var32.toString();
    java.lang.String var34 = var32.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "AxisLabelEntity: label = null"+ "'", var33.equals("AxisLabelEntity: label = null"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + "AxisLabelEntity: label = null"+ "'", var34.equals("AxisLabelEntity: label = null"));

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.event.MarkerChangeEvent var2 = null;
    var1.notifyListeners(var2);
    var1.setValue((-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAlpha((-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
//     var0.setNoDataMessagePaint(var8);
//     org.jfree.chart.JFreeChart var10 = null;
//     org.jfree.chart.event.ChartChangeEvent var11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var10);
//     org.jfree.chart.JFreeChart var12 = var11.getChart();
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var14 = var13.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var15 = var13.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var21 = var16.getItemLabelPaint(0, 10);
//     var13.setNoDataMessagePaint(var21);
//     org.jfree.chart.JFreeChart var23 = null;
//     org.jfree.chart.event.ChartChangeEvent var24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var13, var23);
//     org.jfree.chart.event.ChartChangeEventType var25 = var24.getType();
//     var11.setType(var25);
//     
//     // Checks the contract:  equals-hashcode on var0 and var13
//     assertTrue("Contract failed: equals-hashcode on var0 and var13", var0.equals(var13) ? var0.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var0
//     assertTrue("Contract failed: equals-hashcode on var13 and var0", var13.equals(var0) ? var13.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var18
//     assertTrue("Contract failed: equals-hashcode on var5 and var18", var5.equals(var18) ? var5.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var5
//     assertTrue("Contract failed: equals-hashcode on var18 and var5", var18.equals(var5) ? var18.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = null;
//     var1.setBaseURLGenerator(var4, true);
//     int var7 = var1.getColumnCount();
//     java.awt.Font var8 = var1.getBaseItemLabelFont();
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var8);
//     var9.setText("");
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     java.lang.Object var14 = null;
//     java.lang.Object var15 = var9.draw(var12, var13, var14);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var19 = var17.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var20 = null;
//     var17.setBaseURLGenerator(var20, true);
//     int var23 = var17.getColumnCount();
//     java.awt.Font var24 = var17.getBaseItemLabelFont();
//     org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("", var24);
//     var9.setFont(var24);
//     
//     // Checks the contract:  equals-hashcode on var3 and var19
//     assertTrue("Contract failed: equals-hashcode on var3 and var19", var3.equals(var19) ? var3.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var3
//     assertTrue("Contract failed: equals-hashcode on var19 and var3", var19.equals(var3) ? var19.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.ui.Library[] var1 = var0.getLibraries();
    java.lang.String var2 = var0.getName();
    java.awt.Image var3 = var0.getLogo();
    var0.setLicenceText("hi!");
    java.util.List var6 = var0.getContributors();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("TextAnchor.CENTER", var1);
// 
//   }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     double var1 = var0.getMinimumBarLength();
//     var0.setAutoPopulateSeriesStroke(false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
//     boolean var8 = var4.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var10 = var9.getFixedLegendItems();
//     var4.setPlot(var9);
//     java.awt.Paint var12 = var4.getErrorIndicatorPaint();
//     var0.setBaseItemLabelPaint(var12);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var0.getLegendItemURLGenerator();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var17 = var15.getSeriesNegativeItemLabelPosition(100);
//     boolean var19 = var15.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var21 = var20.getFixedLegendItems();
//     var15.setPlot(var20);
//     java.awt.Paint var23 = var15.getErrorIndicatorPaint();
//     var15.setBase(100.0d);
//     boolean var28 = var15.getItemVisible(1, 1);
//     org.jfree.chart.urls.CategoryURLGenerator var29 = null;
//     var15.setBaseURLGenerator(var29);
//     org.jfree.chart.labels.ItemLabelPosition var31 = new org.jfree.chart.labels.ItemLabelPosition();
//     var15.setBasePositiveItemLabelPosition(var31);
//     var0.setBasePositiveItemLabelPosition(var31, true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var17
//     assertTrue("Contract failed: equals-hashcode on var6 and var17", var6.equals(var17) ? var6.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var6
//     assertTrue("Contract failed: equals-hashcode on var17 and var6", var17.equals(var6) ? var17.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var20
//     assertTrue("Contract failed: equals-hashcode on var9 and var20", var9.equals(var20) ? var9.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var9
//     assertTrue("Contract failed: equals-hashcode on var20 and var9", var20.equals(var9) ? var20.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var4 = var3.getRed();
    java.awt.Color var5 = var3.brighter();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var7.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.urls.CategoryURLGenerator var10 = null;
    var7.setBaseURLGenerator(var10, true);
    int var13 = var7.getColumnCount();
    java.awt.Font var14 = var7.getBaseItemLabelFont();
    java.awt.Color var18 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var19 = var18.getRed();
    org.jfree.chart.text.TextLine var20 = new org.jfree.chart.text.TextLine("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var14, (java.awt.Paint)var18);
    java.awt.Color var24 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var25 = var24.getRed();
    java.awt.Color var26 = var24.brighter();
    float[] var30 = new float[] { 100.0f, 10.0f, 100.0f};
    float[] var31 = var24.getRGBColorComponents(var30);
    float[] var32 = var18.getColorComponents(var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var33 = var5.getComponents(var30);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("hi!", 255, 255);
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    double var1 = var0.getContentXOffset();
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var4 = var3.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var5 = var3.getDataset();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var8 = var6.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var11 = var6.getItemLabelPaint(0, 10);
    var3.setNoDataMessagePaint(var11);
    var3.configureDomainAxes();
    float var14 = var3.getBackgroundAlpha();
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var3);
    var15.setBackgroundImageAlpha(10.0f);
    var15.setBackgroundImageAlpha(1.0f);
    org.jfree.chart.title.Title var21 = var15.getSubtitle(0);
    org.jfree.chart.LegendItemCollection var22 = new org.jfree.chart.LegendItemCollection();
    java.util.Iterator var23 = var22.iterator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add((org.jfree.chart.block.Block)var21, (java.lang.Object)var22);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("ChartChangeEventType.GENERAL");

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, 1.0d);
//     double var4 = var2.constrain((-1.0d));
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
//     java.lang.String var8 = var7.toString();
//     var5.setTickLabelInsets(var7);
//     boolean var10 = var2.equals((java.lang.Object)var5);
//     var5.setLabelToolTip("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
//     var5.setTickMarkOutsideLength(1.0f);
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var17 = var16.getInsets();
//     java.lang.String var18 = var17.toString();
//     var15.setTickLabelInsets(var17);
//     var15.setAutoRangeIncludesZero(true);
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
//     java.text.NumberFormat var23 = null;
//     var22.setNumberFormatOverride(var23);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var28 = var26.getSeriesNegativeItemLabelPosition(100);
//     boolean var30 = var26.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var32 = var31.getFixedLegendItems();
//     var26.setPlot(var31);
//     java.awt.Paint var34 = var26.getErrorIndicatorPaint();
//     var26.setBase(100.0d);
//     boolean var39 = var26.getItemVisible(1, 1);
//     java.awt.Shape var41 = var26.lookupSeriesShape(100);
//     org.jfree.chart.entity.CategoryLabelEntity var44 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)10L, var41, "Category Plot", "");
//     var22.setRightArrow(var41);
//     var15.setDownArrow(var41);
//     org.jfree.chart.entity.AxisLabelEntity var49 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var5, var41, "SortOrder.ASCENDING", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     
//     // Checks the contract:  equals-hashcode on var6 and var16
//     assertTrue("Contract failed: equals-hashcode on var6 and var16", var6.equals(var16) ? var6.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var6
//     assertTrue("Contract failed: equals-hashcode on var16 and var6", var16.equals(var6) ? var16.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(1);
//     java.awt.Image var3 = var0.getBackgroundImage();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(100);
//     boolean var9 = var5.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var11 = var10.getFixedLegendItems();
//     var5.setPlot(var10);
//     java.awt.Paint var13 = var5.getErrorIndicatorPaint();
//     var5.setBase(100.0d);
//     boolean var18 = var5.getItemVisible(1, 1);
//     java.awt.Stroke var19 = var5.getBaseOutlineStroke();
//     java.awt.Paint var21 = var5.getSeriesFillPaint(0);
//     var5.setSeriesVisible(1, (java.lang.Boolean)true, true);
//     var0.setRenderer(10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5, true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var0
//     assertTrue("Contract failed: equals-hashcode on var10 and var0", var10.equals(var0) ? var10.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var0.", var10.equals(var0) == var0.equals(var10));
// 
//   }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     java.text.NumberFormat var1 = null;
//     var0.setNumberFormatOverride(var1);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
//     boolean var8 = var4.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var10 = var9.getFixedLegendItems();
//     var4.setPlot(var9);
//     java.awt.Paint var12 = var4.getErrorIndicatorPaint();
//     var4.setBase(100.0d);
//     boolean var17 = var4.getItemVisible(1, 1);
//     java.awt.Shape var19 = var4.lookupSeriesShape(100);
//     org.jfree.chart.entity.CategoryLabelEntity var22 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)10L, var19, "Category Plot", "");
//     var0.setRightArrow(var19);
//     java.awt.Shape var24 = var0.getUpArrow();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var27 = var25.getSeriesNegativeItemLabelPosition(100);
//     boolean var29 = var25.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var31 = var30.getFixedLegendItems();
//     var25.setPlot(var30);
//     java.awt.Paint var33 = var30.getBackgroundPaint();
//     org.jfree.chart.LegendItemCollection var34 = var30.getFixedLegendItems();
//     java.awt.Paint var35 = var30.getRangeCrosshairPaint();
//     var0.setTickMarkPaint(var35);
//     
//     // Checks the contract:  equals-hashcode on var6 and var27
//     assertTrue("Contract failed: equals-hashcode on var6 and var27", var6.equals(var27) ? var6.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var6
//     assertTrue("Contract failed: equals-hashcode on var27 and var6", var27.equals(var6) ? var27.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.zoomRange(100.0d, 100.0d);
    var0.setLowerBound(10.0d);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var8 = var6.getSeriesNegativeItemLabelPosition(100);
    boolean var10 = var6.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var12 = var11.getFixedLegendItems();
    var6.setPlot(var11);
    java.awt.Paint var14 = var6.getErrorIndicatorPaint();
    var6.setBase(100.0d);
    boolean var19 = var6.getItemVisible(1, 1);
    java.awt.Shape var21 = var6.lookupSeriesShape(100);
    var0.setUpArrow(var21);
    java.lang.String var23 = var0.getLabel();
    double var24 = var0.getUpperMargin();
    var0.setInverted(false);
    var0.setLabel("Category Plot");
    double var29 = var0.getLabelAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
    var0.setPlot(var5);
    java.awt.Paint var8 = var5.getBackgroundPaint();
    java.awt.Font var9 = var5.getNoDataMessageFont();
    float var10 = var5.getBackgroundImageAlpha();
    java.awt.Paint var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setRangeCrosshairPaint(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.5f);

  }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
//     boolean var5 = var1.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var7 = var6.getFixedLegendItems();
//     var1.setPlot(var6);
//     java.awt.Paint var9 = var6.getBackgroundPaint();
//     org.jfree.chart.LegendItemCollection var10 = var6.getFixedLegendItems();
//     java.awt.Paint var11 = var6.getRangeCrosshairPaint();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var13 = var12.getFixedLegendItems();
//     java.awt.Stroke var14 = var12.getOutlineStroke();
//     java.awt.Stroke var15 = var12.getOutlineStroke();
//     org.jfree.chart.axis.ValueAxis var16 = var12.getRangeAxis();
//     java.awt.Stroke var17 = var12.getOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(100.0d, var11, var17);
//     
//     // Checks the contract:  equals-hashcode on var6 and var12
//     assertTrue("Contract failed: equals-hashcode on var6 and var12", var6.equals(var12) ? var6.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var6
//     assertTrue("Contract failed: equals-hashcode on var12 and var6", var12.equals(var6) ? var12.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     var0.setAutoPopulateSeriesPaint(false);
//     java.lang.Object var7 = var0.clone();
//     java.awt.Paint var10 = var0.getItemLabelPaint(1, 10);
//     var0.setSeriesItemLabelsVisible(1, false);
//     boolean var14 = var0.getAutoPopulateSeriesStroke();
//     org.jfree.chart.labels.ItemLabelPosition var15 = var0.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     double var18 = var17.getMinimumBarLength();
//     var17.setAutoPopulateSeriesStroke(false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var23 = var21.getSeriesNegativeItemLabelPosition(100);
//     boolean var25 = var21.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var27 = var26.getFixedLegendItems();
//     var21.setPlot(var26);
//     java.awt.Paint var29 = var21.getErrorIndicatorPaint();
//     var17.setBaseItemLabelPaint(var29);
//     java.lang.Boolean var32 = var17.getSeriesVisibleInLegend(0);
//     java.awt.Font var35 = var17.getItemLabelFont(1, (-1));
//     var0.setSeriesItemLabelFont(10, var35);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var21 and var0.", var21.equals(var0) == var0.equals(var21));
//     
//     // Checks the contract:  equals-hashcode on var2 and var23
//     assertTrue("Contract failed: equals-hashcode on var2 and var23", var2.equals(var23) ? var2.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var23
//     assertTrue("Contract failed: equals-hashcode on var15 and var23", var15.equals(var23) ? var15.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var2
//     assertTrue("Contract failed: equals-hashcode on var23 and var2", var23.equals(var2) ? var23.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var15
//     assertTrue("Contract failed: equals-hashcode on var23 and var15", var23.equals(var15) ? var23.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var7 = var6.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var8 = var6.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var11 = var9.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var14 = var9.getItemLabelPaint(0, 10);
//     var6.setNoDataMessagePaint(var14);
//     var6.configureDomainAxes();
//     boolean var17 = var6.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
//     var18.setCategoryMargin(1.0d);
//     org.jfree.chart.plot.CategoryMarker var21 = null;
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     var23.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var27 = var23.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.util.RectangleEdge var30 = null;
//     double var31 = var23.java2DToValue(0.0d, var29, var30);
//     org.jfree.data.Range var32 = null;
//     org.jfree.data.Range var34 = org.jfree.data.Range.expandToInclude(var32, 1.0d);
//     double var36 = var34.constrain((-1.0d));
//     var23.setRangeWithMargins(var34, true, false);
//     org.jfree.chart.block.RectangleConstraint var40 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var34);
//     org.jfree.chart.util.Size2D var41 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var42 = var40.calculateConstrainedSize(var41);
//     var42.setHeight(3.0d);
//     org.jfree.chart.plot.ValueMarker var48 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var49 = null;
//     var48.notifyListeners(var49);
//     var48.setValue((-1.0d));
//     java.awt.Stroke var53 = var48.getStroke();
//     org.jfree.chart.plot.ValueMarker var55 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis();
//     var56.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var60 = var56.getTickMarkStroke();
//     var55.setStroke(var60);
//     boolean var62 = var48.equals((java.lang.Object)var60);
//     org.jfree.chart.util.RectangleAnchor var63 = var48.getLabelAnchor();
//     java.awt.geom.Rectangle2D var64 = org.jfree.chart.util.RectangleAnchor.createRectangle(var42, 0.2d, 100.0d, var63);
//     var0.drawDomainMarker(var5, var6, var18, var21, var64);
// 
//   }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     java.text.NumberFormat var1 = null;
//     var0.setNumberFormatOverride(var1);
//     var0.setAutoTickUnitSelection(false);
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     double var6 = var5.getFixedAutoRange();
//     double var7 = var5.getUpperMargin();
//     var5.setAutoRangeMinimumSize(10.0d);
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
//     var10.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var14 = var10.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.util.RectangleEdge var17 = null;
//     double var18 = var10.java2DToValue(0.0d, var16, var17);
//     org.jfree.data.Range var19 = null;
//     org.jfree.data.Range var21 = org.jfree.data.Range.expandToInclude(var19, 1.0d);
//     double var23 = var21.constrain((-1.0d));
//     var10.setRangeWithMargins(var21, true, false);
//     var5.setRange(var21, false, true);
//     var0.setRangeWithMargins(var21, true, false);
//     org.jfree.data.Range var35 = org.jfree.data.Range.expand(var21, (-1.0d), 4.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.05d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
// 
//   }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.LegendItem var7 = var0.getLegendItem(0, 0);
    java.awt.Color var11 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var12 = var11.getRed();
    java.awt.Color var13 = var11.brighter();
    java.awt.image.ColorModel var14 = null;
    java.awt.Rectangle var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    java.awt.geom.AffineTransform var17 = null;
    java.awt.RenderingHints var18 = null;
    java.awt.PaintContext var19 = var13.createContext(var14, var15, var16, var17, var18);
    var0.setErrorIndicatorPaint((java.awt.Paint)var13);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    var21.zoomRange(0.0d, 100.0d);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var27 = var25.getSeriesNegativeItemLabelPosition(100);
    boolean var29 = var25.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var31 = var30.getFixedLegendItems();
    var25.setPlot(var30);
    java.awt.Paint var33 = var30.getBackgroundPaint();
    var21.setPlot((org.jfree.chart.plot.Plot)var30);
    org.jfree.chart.axis.NumberTickUnit var35 = var21.getTickUnit();
    java.awt.Color var39 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var40 = var39.getRed();
    java.awt.Color var41 = var39.brighter();
    java.awt.image.ColorModel var42 = null;
    java.awt.Rectangle var43 = null;
    java.awt.geom.Rectangle2D var44 = null;
    java.awt.geom.AffineTransform var45 = null;
    java.awt.RenderingHints var46 = null;
    java.awt.PaintContext var47 = var41.createContext(var42, var43, var44, var45, var46);
    float[] var51 = new float[] { (-1.0f), (-1.0f), (-1.0f)};
    float[] var52 = var41.getRGBColorComponents(var51);
    boolean var53 = var35.equals((java.lang.Object)var51);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var54 = var13.getRGBComponents(var51);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setCategoryMargin(1.0d);
    java.lang.Comparable var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeCategoryLabelToolTip(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Comparable var1 = null;
    int var2 = var0.getColumnIndex(var1);
    java.lang.Object var5 = var0.getObject((java.lang.Comparable)"hi!", (java.lang.Comparable)1.0f);
    var0.removeColumn((java.lang.Comparable)1);
    int var8 = var0.getRowCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var10 = var0.getColumnKey(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var2 = var1.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var3 = var1.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var9 = var4.getItemLabelPaint(0, 10);
//     var1.setNoDataMessagePaint(var9);
//     var1.configureDomainAxes();
//     float var12 = var1.getBackgroundAlpha();
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     var13.setBackgroundImageAlpha(10.0f);
//     var13.setBackgroundImageAlpha(1.0f);
//     var13.removeLegend();
//     java.awt.Graphics2D var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     org.jfree.chart.ChartRenderingInfo var21 = null;
//     var13.draw(var19, var20, var21);
// 
//   }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
    org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    java.awt.Paint var3 = var2.getBackgroundPaint();
    org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.event.MarkerChangeEvent var7 = null;
    var6.notifyListeners(var7);
    var6.setValue((-1.0d));
    java.awt.Stroke var11 = var6.getOutlineStroke();
    org.jfree.chart.util.LengthAdjustmentType var12 = var6.getLabelOffsetType();
    java.awt.Font var13 = var6.getLabelFont();
    java.awt.Color var17 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var18 = var17.getRed();
    java.awt.Color var19 = var17.brighter();
    java.awt.image.ColorModel var20 = null;
    java.awt.Rectangle var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    java.awt.geom.AffineTransform var23 = null;
    java.awt.RenderingHints var24 = null;
    java.awt.PaintContext var25 = var19.createContext(var20, var21, var22, var23, var24);
    float[] var29 = new float[] { (-1.0f), (-1.0f), (-1.0f)};
    float[] var30 = var19.getRGBColorComponents(var29);
    org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("rect", var13, (java.awt.Paint)var19, 0.0f);
    var2.setItemFont(var13);
    org.jfree.chart.LegendItemSource[] var34 = var2.getSources();
    java.awt.Font var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setItemFont(var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var1.setBaseURLGenerator(var4, true);
    int var7 = var1.getColumnCount();
    java.awt.Font var8 = var1.getBaseItemLabelFont();
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var8);
    java.awt.Graphics2D var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var11 = var9.arrange(var10);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.zoomRange(0.0d, 100.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
//     boolean var8 = var4.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var10 = var9.getFixedLegendItems();
//     var4.setPlot(var9);
//     java.awt.Paint var12 = var9.getBackgroundPaint();
//     var0.setPlot((org.jfree.chart.plot.Plot)var9);
//     boolean var14 = var0.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     var16.zoomRange(100.0d, 100.0d);
//     var16.setLowerBound(10.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var24 = var22.getSeriesNegativeItemLabelPosition(100);
//     boolean var26 = var22.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var28 = var27.getFixedLegendItems();
//     var22.setPlot(var27);
//     java.awt.Paint var30 = var22.getErrorIndicatorPaint();
//     var22.setBase(100.0d);
//     boolean var35 = var22.getItemVisible(1, 1);
//     java.awt.Shape var37 = var22.lookupSeriesShape(100);
//     var16.setUpArrow(var37);
//     float var39 = var16.getTickMarkOutsideLength();
//     boolean var40 = var16.isNegativeArrowVisible();
//     org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis();
//     var43.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var47 = var43.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var49 = null;
//     org.jfree.chart.util.RectangleEdge var50 = null;
//     double var51 = var43.java2DToValue(0.0d, var49, var50);
//     org.jfree.data.Range var52 = null;
//     org.jfree.data.Range var54 = org.jfree.data.Range.expandToInclude(var52, 1.0d);
//     double var56 = var54.constrain((-1.0d));
//     var43.setRangeWithMargins(var54, true, false);
//     org.jfree.chart.block.RectangleConstraint var60 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var54);
//     org.jfree.chart.util.Size2D var61 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var62 = var60.calculateConstrainedSize(var61);
//     var62.setHeight(3.0d);
//     org.jfree.chart.plot.ValueMarker var68 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var69 = null;
//     var68.notifyListeners(var69);
//     var68.setValue((-1.0d));
//     java.awt.Stroke var73 = var68.getStroke();
//     org.jfree.chart.plot.ValueMarker var75 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.axis.NumberAxis var76 = new org.jfree.chart.axis.NumberAxis();
//     var76.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var80 = var76.getTickMarkStroke();
//     var75.setStroke(var80);
//     boolean var82 = var68.equals((java.lang.Object)var80);
//     org.jfree.chart.util.RectangleAnchor var83 = var68.getLabelAnchor();
//     java.awt.geom.Rectangle2D var84 = org.jfree.chart.util.RectangleAnchor.createRectangle(var62, 0.2d, 100.0d, var83);
//     org.jfree.chart.plot.CategoryPlot var85 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.general.DatasetGroup var86 = var85.getDatasetGroup();
//     org.jfree.chart.util.RectangleEdge var87 = var85.getDomainAxisEdge();
//     double var88 = var16.lengthToJava2D((-11.0d), var84, var87);
//     org.jfree.chart.plot.CategoryPlot var89 = new org.jfree.chart.plot.CategoryPlot();
//     var89.clearDomainMarkers(1);
//     java.awt.Image var92 = var89.getBackgroundImage();
//     org.jfree.chart.util.RectangleEdge var94 = var89.getRangeAxisEdge((-1));
//     boolean var95 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var94);
//     org.jfree.chart.util.RectangleEdge var96 = org.jfree.chart.util.RectangleEdge.opposite(var94);
//     double var97 = var0.valueToJava2D((-6.0d), var84, var94);
//     
//     // Checks the contract:  equals-hashcode on var6 and var24
//     assertTrue("Contract failed: equals-hashcode on var6 and var24", var6.equals(var24) ? var6.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var6
//     assertTrue("Contract failed: equals-hashcode on var24 and var6", var24.equals(var6) ? var24.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var85
//     assertTrue("Contract failed: equals-hashcode on var9 and var85", var9.equals(var85) ? var9.hashCode() == var85.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var89
//     assertTrue("Contract failed: equals-hashcode on var9 and var89", var9.equals(var89) ? var9.hashCode() == var89.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var85 and var9
//     assertTrue("Contract failed: equals-hashcode on var85 and var9", var85.equals(var9) ? var85.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var85 and var89
//     assertTrue("Contract failed: equals-hashcode on var85 and var89", var85.equals(var89) ? var85.hashCode() == var89.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var89 and var9
//     assertTrue("Contract failed: equals-hashcode on var89 and var9", var89.equals(var9) ? var89.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var89 and var85
//     assertTrue("Contract failed: equals-hashcode on var89 and var85", var89.equals(var85) ? var89.hashCode() == var85.hashCode() : true);
// 
//   }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.zoomRange(100.0d, 100.0d);
    var0.setLowerBound(10.0d);
    org.jfree.chart.axis.NumberTickUnit var6 = var0.getTickUnit();
    java.lang.String var7 = var6.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "[size=1]"+ "'", var7.equals("[size=1]"));

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Stroke var1 = var0.getBaseOutlineStroke();
    boolean var3 = var0.isSeriesVisible(10);
    java.awt.Color var7 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var8 = var7.getRed();
    java.awt.Color var9 = var7.brighter();
    java.awt.image.ColorModel var10 = null;
    java.awt.Rectangle var11 = null;
    java.awt.geom.Rectangle2D var12 = null;
    java.awt.geom.AffineTransform var13 = null;
    java.awt.RenderingHints var14 = null;
    java.awt.PaintContext var15 = var9.createContext(var10, var11, var12, var13, var14);
    var0.setBaseFillPaint((java.awt.Paint)var9);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var20 = var18.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.urls.CategoryURLGenerator var21 = null;
    var18.setBaseURLGenerator(var21, true);
    int var24 = var18.getColumnCount();
    java.awt.Font var25 = var18.getBaseItemLabelFont();
    org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("", var25);
    org.jfree.chart.axis.CategoryLabelPosition var27 = new org.jfree.chart.axis.CategoryLabelPosition();
    boolean var28 = var26.equals((java.lang.Object)var27);
    org.jfree.chart.block.BlockFrame var29 = var26.getFrame();
    java.awt.Font var30 = var26.getFont();
    var0.setBaseItemLabelFont(var30, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.awt.Stroke var1 = var0.getBaseOutlineStroke();
//     boolean var3 = var0.isSeriesVisible(10);
//     java.awt.Paint var6 = var0.getItemFillPaint(255, 0);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.awt.Stroke var8 = var7.getBaseOutlineStroke();
//     var0.setBaseStroke(var8, false);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var12 = var11.getFixedLegendItems();
//     java.awt.Stroke var13 = var11.getOutlineStroke();
//     java.awt.Stroke var14 = var11.getOutlineStroke();
//     var11.setOutlineVisible(false);
//     org.jfree.chart.axis.AxisLocation var18 = var11.getDomainAxisLocation(0);
//     var11.setRangeCrosshairValue(10.0d, false);
//     var11.setBackgroundImageAlignment((-16777216));
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var25 = var24.getFixedLegendItems();
//     java.awt.Stroke var26 = var24.getOutlineStroke();
//     var24.setDrawSharedDomainAxis(true);
//     org.jfree.chart.axis.AxisLocation var30 = var24.getRangeAxisLocation(10);
//     var11.setDomainAxisLocation(var30, false);
//     boolean var33 = var11.isSubplot();
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var11);
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
//     var35.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var39 = var35.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var41 = null;
//     org.jfree.chart.util.RectangleEdge var42 = null;
//     double var43 = var35.java2DToValue(0.0d, var41, var42);
//     java.awt.Font var44 = var35.getTickLabelFont();
//     var35.setTickMarksVisible(true);
//     boolean var47 = var35.getAutoRangeIncludesZero();
//     var11.setRangeAxis((org.jfree.chart.axis.ValueAxis)var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == true);
// 
//   }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var2 = var1.getInsets();
//     org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     java.awt.Paint var4 = var3.getBackgroundPaint();
//     org.jfree.chart.plot.ValueMarker var7 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var8 = null;
//     var7.notifyListeners(var8);
//     var7.setValue((-1.0d));
//     java.awt.Stroke var12 = var7.getOutlineStroke();
//     org.jfree.chart.util.LengthAdjustmentType var13 = var7.getLabelOffsetType();
//     java.awt.Font var14 = var7.getLabelFont();
//     java.awt.Color var18 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var19 = var18.getRed();
//     java.awt.Color var20 = var18.brighter();
//     java.awt.image.ColorModel var21 = null;
//     java.awt.Rectangle var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     java.awt.geom.AffineTransform var24 = null;
//     java.awt.RenderingHints var25 = null;
//     java.awt.PaintContext var26 = var20.createContext(var21, var22, var23, var24, var25);
//     float[] var30 = new float[] { (-1.0f), (-1.0f), (-1.0f)};
//     float[] var31 = var20.getRGBColorComponents(var30);
//     org.jfree.chart.text.TextFragment var33 = new org.jfree.chart.text.TextFragment("rect", var14, (java.awt.Paint)var20, 0.0f);
//     var3.setItemFont(var14);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var35 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     double var36 = var35.getMinimumBarLength();
//     var35.setAutoPopulateSeriesStroke(false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var41 = var39.getSeriesNegativeItemLabelPosition(100);
//     boolean var43 = var39.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var45 = var44.getFixedLegendItems();
//     var39.setPlot(var44);
//     java.awt.Paint var47 = var39.getErrorIndicatorPaint();
//     var35.setBaseItemLabelPaint(var47);
//     java.lang.Boolean var50 = var35.getSeriesVisibleInLegend(0);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var51 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.awt.Stroke var52 = var51.getBaseOutlineStroke();
//     boolean var54 = var51.isSeriesVisible(10);
//     java.awt.Color var58 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var59 = var58.getRed();
//     java.awt.Color var60 = var58.brighter();
//     java.awt.image.ColorModel var61 = null;
//     java.awt.Rectangle var62 = null;
//     java.awt.geom.Rectangle2D var63 = null;
//     java.awt.geom.AffineTransform var64 = null;
//     java.awt.RenderingHints var65 = null;
//     java.awt.PaintContext var66 = var60.createContext(var61, var62, var63, var64, var65);
//     var51.setBaseFillPaint((java.awt.Paint)var60);
//     int var68 = var60.getBlue();
//     var35.setBaseFillPaint((java.awt.Paint)var60, true);
//     org.jfree.chart.text.TextFragment var72 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var14, (java.awt.Paint)var60, 2.0f);
//     
//     // Checks the contract:  equals-hashcode on var1 and var44
//     assertTrue("Contract failed: equals-hashcode on var1 and var44", var1.equals(var44) ? var1.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var1
//     assertTrue("Contract failed: equals-hashcode on var44 and var1", var44.equals(var1) ? var44.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(1);
    java.awt.Image var3 = var0.getBackgroundImage();
    org.jfree.chart.util.SortOrder var4 = var0.getRowRenderingOrder();
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    java.awt.geom.Point2D var7 = null;
    var0.zoomDomainAxes(100.0d, var6, var7);
    var0.configureRangeAxes();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
    var10.zoomRange(0.0d, 100.0d);
    java.awt.Stroke var14 = var10.getTickMarkStroke();
    boolean var15 = var10.isAutoRange();
    double var16 = var10.getUpperBound();
    java.lang.String var17 = var10.getLabelToolTip();
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var20 = var18.getRangeAxis(0);
    java.awt.Paint var21 = var18.getOutlinePaint();
    var10.setAxisLinePaint(var21);
    java.lang.String var23 = var10.getLabelURL();
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var10);
    var10.setAutoTickUnitSelection(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    var0.setAutoPopulateSeriesPaint(false);
    boolean var8 = var0.isSeriesItemLabelsVisible(0);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    double var10 = var9.getMinimumBarLength();
    java.awt.Paint var11 = var9.getErrorIndicatorPaint();
    var0.setBaseOutlinePaint(var11, false);
    org.jfree.chart.block.FlowArrangement var14 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var15 = new org.jfree.chart.block.BlockContainer();
    double var16 = var15.getContentXOffset();
    org.jfree.chart.util.HorizontalAlignment var17 = null;
    org.jfree.chart.util.VerticalAlignment var18 = null;
    org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, 100.0d, 0.0d);
    var15.setArrangement((org.jfree.chart.block.Arrangement)var21);
    org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var14, (org.jfree.chart.block.Arrangement)var21);
    org.jfree.chart.block.BlockContainer var24 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.plot.ValueMarker var27 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.event.MarkerChangeEvent var28 = null;
    var27.notifyListeners(var28);
    var27.setValue((-1.0d));
    java.awt.Stroke var32 = var27.getOutlineStroke();
    org.jfree.chart.util.LengthAdjustmentType var33 = var27.getLabelOffsetType();
    java.awt.Font var34 = var27.getLabelFont();
    java.awt.Color var38 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var39 = var38.getRed();
    java.awt.Color var40 = var38.brighter();
    java.awt.image.ColorModel var41 = null;
    java.awt.Rectangle var42 = null;
    java.awt.geom.Rectangle2D var43 = null;
    java.awt.geom.AffineTransform var44 = null;
    java.awt.RenderingHints var45 = null;
    java.awt.PaintContext var46 = var40.createContext(var41, var42, var43, var44, var45);
    float[] var50 = new float[] { (-1.0f), (-1.0f), (-1.0f)};
    float[] var51 = var40.getRGBColorComponents(var50);
    org.jfree.chart.text.TextFragment var53 = new org.jfree.chart.text.TextFragment("rect", var34, (java.awt.Paint)var40, 0.0f);
    java.awt.Font var54 = var53.getFont();
    var14.add((org.jfree.chart.block.Block)var24, (java.lang.Object)var54);
    var24.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var0.getSeriesItemLabelGenerator(10);
//     var0.setBaseItemLabelsVisible(true);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.clearDomainMarkers(1);
//     java.awt.Image var13 = var10.getBackgroundImage();
//     org.jfree.chart.util.SortOrder var14 = var10.getRowRenderingOrder();
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     java.awt.geom.Point2D var17 = null;
//     var10.zoomDomainAxes(100.0d, var16, var17);
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
//     var20.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var24 = var20.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.util.RectangleEdge var27 = null;
//     double var28 = var20.java2DToValue(0.0d, var26, var27);
//     org.jfree.data.Range var29 = null;
//     org.jfree.data.Range var31 = org.jfree.data.Range.expandToInclude(var29, 1.0d);
//     double var33 = var31.constrain((-1.0d));
//     var20.setRangeWithMargins(var31, true, false);
//     org.jfree.chart.block.RectangleConstraint var37 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var31);
//     org.jfree.chart.util.Size2D var38 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var39 = var37.calculateConstrainedSize(var38);
//     var39.setHeight(3.0d);
//     org.jfree.chart.plot.ValueMarker var45 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var46 = null;
//     var45.notifyListeners(var46);
//     var45.setValue((-1.0d));
//     java.awt.Stroke var50 = var45.getStroke();
//     org.jfree.chart.plot.ValueMarker var52 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis();
//     var53.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var57 = var53.getTickMarkStroke();
//     var52.setStroke(var57);
//     boolean var59 = var45.equals((java.lang.Object)var57);
//     org.jfree.chart.util.RectangleAnchor var60 = var45.getLabelAnchor();
//     java.awt.geom.Rectangle2D var61 = org.jfree.chart.util.RectangleAnchor.createRectangle(var39, 0.2d, 100.0d, var60);
//     var0.drawOutline(var9, var10, var61);
// 
//   }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.awt.Stroke var1 = var0.getBaseOutlineStroke();
//     boolean var3 = var0.isSeriesVisible(10);
//     var0.setBaseItemLabelsVisible(false, true);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.ChartRenderingInfo var8 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var9 = new org.jfree.chart.plot.PlotRenderingInfo(var8);
//     org.jfree.chart.renderer.category.CategoryItemRendererState var10 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var9);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     var12.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var16 = var12.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.util.RectangleEdge var19 = null;
//     double var20 = var12.java2DToValue(0.0d, var18, var19);
//     org.jfree.data.Range var21 = null;
//     org.jfree.data.Range var23 = org.jfree.data.Range.expandToInclude(var21, 1.0d);
//     double var25 = var23.constrain((-1.0d));
//     var12.setRangeWithMargins(var23, true, false);
//     org.jfree.chart.block.RectangleConstraint var29 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var23);
//     org.jfree.chart.util.Size2D var30 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var31 = var29.calculateConstrainedSize(var30);
//     var31.setHeight(3.0d);
//     org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var38 = null;
//     var37.notifyListeners(var38);
//     var37.setValue((-1.0d));
//     java.awt.Stroke var42 = var37.getStroke();
//     org.jfree.chart.plot.ValueMarker var44 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis();
//     var45.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var49 = var45.getTickMarkStroke();
//     var44.setStroke(var49);
//     boolean var51 = var37.equals((java.lang.Object)var49);
//     org.jfree.chart.util.RectangleAnchor var52 = var37.getLabelAnchor();
//     java.awt.geom.Rectangle2D var53 = org.jfree.chart.util.RectangleAnchor.createRectangle(var31, 0.2d, 100.0d, var52);
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.general.DatasetGroup var55 = var54.getDatasetGroup();
//     org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis();
//     var56.setCategoryMargin(1.0d);
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.data.category.CategoryDataset var60 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.drawItem(var7, var10, var53, var54, var56, var59, var60, 255, 255, 255);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var55);
// 
//   }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     int var3 = var0.getPassCount();
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     var4.zoomRange(100.0d, 100.0d);
//     boolean var8 = var0.equals((java.lang.Object)100.0d);
//     org.jfree.chart.urls.CategoryURLGenerator var10 = var0.getSeriesURLGenerator((-1));
//     java.lang.Object var11 = null;
//     boolean var12 = var0.equals(var11);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var15 = var13.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var16 = null;
//     var13.setBaseURLGenerator(var16, true);
//     org.jfree.chart.labels.ItemLabelPosition var21 = var13.getPositiveItemLabelPosition((-1), 100);
//     var0.setBaseNegativeItemLabelPosition(var21);
//     
//     // Checks the contract:  equals-hashcode on var2 and var15
//     assertTrue("Contract failed: equals-hashcode on var2 and var15", var2.equals(var15) ? var2.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var2
//     assertTrue("Contract failed: equals-hashcode on var15 and var2", var15.equals(var2) ? var15.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)"RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
// 
//   }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     var0.setBase(100.0d);
//     boolean var13 = var0.getItemVisible(1, 1);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var16 = var14.getSeriesNegativeItemLabelPosition(100);
//     boolean var18 = var14.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var20 = var19.getFixedLegendItems();
//     var14.setPlot(var19);
//     java.awt.Paint var22 = var14.getErrorIndicatorPaint();
//     java.awt.Paint var23 = var14.getBaseOutlinePaint();
//     var14.setSeriesVisibleInLegend(100, (java.lang.Boolean)false, true);
//     boolean var28 = var0.equals((java.lang.Object)var14);
//     
//     // Checks the contract:  equals-hashcode on var2 and var16
//     assertTrue("Contract failed: equals-hashcode on var2 and var16", var2.equals(var16) ? var2.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var2
//     assertTrue("Contract failed: equals-hashcode on var16 and var2", var16.equals(var2) ? var16.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var19
//     assertTrue("Contract failed: equals-hashcode on var5 and var19", var5.equals(var19) ? var5.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var5
//     assertTrue("Contract failed: equals-hashcode on var19 and var5", var19.equals(var5) ? var19.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.zoomRange(0.0d, 100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeWithMargins(0.2d, (-11.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("", var1);
// 
//   }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("AxisLabelEntity: label = null", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(1);
    java.awt.Paint var3 = var0.getRangeCrosshairPaint();
    float var4 = var0.getBackgroundAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0f);

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, true);
// 
//   }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.axis.TickUnits var2 = new org.jfree.chart.axis.TickUnits();
//     int var3 = var2.size();
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     var4.zoomRange(100.0d, 100.0d);
//     var4.setLowerBound(10.0d);
//     org.jfree.chart.axis.NumberTickUnit var10 = var4.getTickUnit();
//     java.lang.String var12 = var10.valueToString(3.0d);
//     var2.add((org.jfree.chart.axis.TickUnit)var10);
//     var0.add((org.jfree.chart.axis.TickUnit)var10);
//     
//     // Checks the contract:  equals-hashcode on var0 and var2
//     assertTrue("Contract failed: equals-hashcode on var0 and var2", var0.equals(var2) ? var0.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var0
//     assertTrue("Contract failed: equals-hashcode on var2 and var0", var2.equals(var0) ? var2.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(10);

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
//     org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.awt.Paint var3 = var2.getBackgroundPaint();
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var7 = null;
//     var6.notifyListeners(var7);
//     var6.setValue((-1.0d));
//     java.awt.Stroke var11 = var6.getOutlineStroke();
//     org.jfree.chart.util.LengthAdjustmentType var12 = var6.getLabelOffsetType();
//     java.awt.Font var13 = var6.getLabelFont();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var18 = var17.getRed();
//     java.awt.Color var19 = var17.brighter();
//     java.awt.image.ColorModel var20 = null;
//     java.awt.Rectangle var21 = null;
//     java.awt.geom.Rectangle2D var22 = null;
//     java.awt.geom.AffineTransform var23 = null;
//     java.awt.RenderingHints var24 = null;
//     java.awt.PaintContext var25 = var19.createContext(var20, var21, var22, var23, var24);
//     float[] var29 = new float[] { (-1.0f), (-1.0f), (-1.0f)};
//     float[] var30 = var19.getRGBColorComponents(var29);
//     org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("rect", var13, (java.awt.Paint)var19, 0.0f);
//     var2.setItemFont(var13);
//     org.jfree.chart.LegendItemSource[] var34 = var2.getSources();
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var36 = var35.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var37 = var35.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var38 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var40 = var38.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var43 = var38.getItemLabelPaint(0, 10);
//     var35.setNoDataMessagePaint(var43);
//     var35.configureDomainAxes();
//     float var46 = var35.getBackgroundAlpha();
//     var35.setRangeCrosshairLockedOnData(true);
//     int var49 = var35.getRangeAxisCount();
//     org.jfree.chart.title.TextTitle var51 = new org.jfree.chart.title.TextTitle("hi!");
//     boolean var53 = var51.equals((java.lang.Object)"Category Plot");
//     var51.setToolTipText("hi!");
//     org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var58 = var57.getInsets();
//     java.lang.String var59 = var58.toString();
//     var56.setTickLabelInsets(var58);
//     double var62 = var58.calculateLeftInset(0.0d);
//     double var64 = var58.calculateLeftOutset(0.0d);
//     var51.setPadding(var58);
//     double var66 = var58.getRight();
//     var35.setAxisOffset(var58);
//     double var69 = var58.calculateBottomInset(8.0d);
//     var2.setLegendItemGraphicPadding(var58);
//     
//     // Checks the contract:  equals-hashcode on var0 and var57
//     assertTrue("Contract failed: equals-hashcode on var0 and var57", var0.equals(var57) ? var0.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var0
//     assertTrue("Contract failed: equals-hashcode on var57 and var0", var57.equals(var0) ? var57.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     java.awt.Stroke var2 = var0.getOutlineStroke();
//     java.awt.Stroke var3 = var0.getOutlineStroke();
//     org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxis();
//     float var5 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var8 = var6.getSeriesNegativeItemLabelPosition(100);
//     boolean var10 = var6.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var12 = var11.getFixedLegendItems();
//     var6.setPlot(var11);
//     java.awt.Paint var14 = var11.getBackgroundPaint();
//     org.jfree.chart.LegendItemCollection var15 = var11.getFixedLegendItems();
//     java.awt.Paint var16 = var11.getRangeCrosshairPaint();
//     var0.setNoDataMessagePaint(var16);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     double var19 = var18.getMinimumBarLength();
//     var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
//     org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var25 = var23.getSeriesNegativeItemLabelPosition(100);
//     boolean var27 = var23.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var29 = var28.getFixedLegendItems();
//     var23.setPlot(var28);
//     java.awt.Paint var31 = var23.getErrorIndicatorPaint();
//     java.awt.Paint var32 = var23.getBaseOutlinePaint();
//     boolean var34 = var23.isSeriesVisible(0);
//     java.awt.Paint var35 = null;
//     var23.setErrorIndicatorPaint(var35);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var37 = var23.getLegendItemLabelGenerator();
//     java.awt.Stroke var40 = var23.getItemStroke(1, 10);
//     var21.setSeriesOutlineStroke(255, var40);
//     var21.setSeriesItemLabelsVisible(255, (java.lang.Boolean)false);
//     org.jfree.chart.labels.ItemLabelPosition var46 = var21.getSeriesPositiveItemLabelPosition(100);
//     java.awt.Stroke var49 = var21.getItemStroke(255, 1);
//     var18.setBaseOutlineStroke(var49);
//     
//     // Checks the contract:  equals-hashcode on var11 and var28
//     assertTrue("Contract failed: equals-hashcode on var11 and var28", var11.equals(var28) ? var11.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var11
//     assertTrue("Contract failed: equals-hashcode on var28 and var11", var28.equals(var11) ? var28.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var25
//     assertTrue("Contract failed: equals-hashcode on var8 and var25", var8.equals(var25) ? var8.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var8
//     assertTrue("Contract failed: equals-hashcode on var25 and var8", var25.equals(var8) ? var25.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, Double.NaN, 0.0d, 1, (java.lang.Comparable)(byte)10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("SortOrder.ASCENDING", var1);
// 
//   }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = null;
//     var1.setBaseURLGenerator(var4, true);
//     int var7 = var1.getColumnCount();
//     java.awt.Font var8 = var1.getBaseItemLabelFont();
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var8);
//     var9.setText("");
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     java.lang.Object var14 = null;
//     java.lang.Object var15 = var9.draw(var12, var13, var14);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var19 = var17.getSeriesNegativeItemLabelPosition(100);
//     boolean var21 = var17.isSeriesVisible(10);
//     var17.setAutoPopulateSeriesPaint(false);
//     boolean var25 = var17.isSeriesItemLabelsVisible(0);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     double var27 = var26.getMinimumBarLength();
//     java.awt.Paint var28 = var26.getErrorIndicatorPaint();
//     var17.setBaseOutlinePaint(var28, false);
//     org.jfree.chart.block.FlowArrangement var31 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var32 = new org.jfree.chart.block.BlockContainer();
//     double var33 = var32.getContentXOffset();
//     org.jfree.chart.util.HorizontalAlignment var34 = null;
//     org.jfree.chart.util.VerticalAlignment var35 = null;
//     org.jfree.chart.block.FlowArrangement var38 = new org.jfree.chart.block.FlowArrangement(var34, var35, 100.0d, 0.0d);
//     var32.setArrangement((org.jfree.chart.block.Arrangement)var38);
//     org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17, (org.jfree.chart.block.Arrangement)var31, (org.jfree.chart.block.Arrangement)var38);
//     org.jfree.chart.block.BlockContainer var41 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.plot.ValueMarker var44 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var45 = null;
//     var44.notifyListeners(var45);
//     var44.setValue((-1.0d));
//     java.awt.Stroke var49 = var44.getOutlineStroke();
//     org.jfree.chart.util.LengthAdjustmentType var50 = var44.getLabelOffsetType();
//     java.awt.Font var51 = var44.getLabelFont();
//     java.awt.Color var55 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var56 = var55.getRed();
//     java.awt.Color var57 = var55.brighter();
//     java.awt.image.ColorModel var58 = null;
//     java.awt.Rectangle var59 = null;
//     java.awt.geom.Rectangle2D var60 = null;
//     java.awt.geom.AffineTransform var61 = null;
//     java.awt.RenderingHints var62 = null;
//     java.awt.PaintContext var63 = var57.createContext(var58, var59, var60, var61, var62);
//     float[] var67 = new float[] { (-1.0f), (-1.0f), (-1.0f)};
//     float[] var68 = var57.getRGBColorComponents(var67);
//     org.jfree.chart.text.TextFragment var70 = new org.jfree.chart.text.TextFragment("rect", var51, (java.awt.Paint)var57, 0.0f);
//     java.awt.Font var71 = var70.getFont();
//     var31.add((org.jfree.chart.block.Block)var41, (java.lang.Object)var71);
//     org.jfree.chart.title.TextTitle var73 = new org.jfree.chart.title.TextTitle("", var71);
//     boolean var74 = var9.equals((java.lang.Object)var73);
//     
//     // Checks the contract:  equals-hashcode on var3 and var19
//     assertTrue("Contract failed: equals-hashcode on var3 and var19", var3.equals(var19) ? var3.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var3
//     assertTrue("Contract failed: equals-hashcode on var19 and var3", var19.equals(var3) ? var19.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var2 = null;
//     var1.notifyListeners(var2);
//     var1.setValue((-1.0d));
//     org.jfree.chart.util.RectangleInsets var6 = var1.getLabelOffset();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var8 = var7.getFixedLegendItems();
//     java.awt.Stroke var9 = var7.getOutlineStroke();
//     var7.setDrawSharedDomainAxis(true);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var14 = var13.getInsets();
//     java.lang.String var15 = var14.toString();
//     var12.setTickLabelInsets(var14);
//     var7.setAxisOffset(var14);
//     var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var7);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var21 = var19.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var22 = null;
//     var19.setBaseURLGenerator(var22, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var25 = var19.getBaseItemLabelGenerator();
//     java.awt.Font var26 = var19.getBaseItemLabelFont();
//     var1.setLabelFont(var26);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var28 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     double var29 = var28.getMinimumBarLength();
//     var28.setAutoPopulateSeriesStroke(false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var34 = var32.getSeriesNegativeItemLabelPosition(100);
//     boolean var36 = var32.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var38 = var37.getFixedLegendItems();
//     var32.setPlot(var37);
//     java.awt.Paint var40 = var32.getErrorIndicatorPaint();
//     var28.setBaseItemLabelPaint(var40);
//     var1.setPaint(var40);
//     
//     // Checks the contract:  equals-hashcode on var13 and var37
//     assertTrue("Contract failed: equals-hashcode on var13 and var37", var13.equals(var37) ? var13.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var13
//     assertTrue("Contract failed: equals-hashcode on var37 and var13", var37.equals(var13) ? var37.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var34
//     assertTrue("Contract failed: equals-hashcode on var21 and var34", var21.equals(var34) ? var21.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var21
//     assertTrue("Contract failed: equals-hashcode on var34 and var21", var34.equals(var21) ? var34.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var2 = var1.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var3 = var1.getDataset();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var9 = var4.getItemLabelPaint(0, 10);
    var1.setNoDataMessagePaint(var9);
    var1.configureDomainAxes();
    float var12 = var1.getBackgroundAlpha();
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
    var13.setBackgroundImageAlpha(10.0f);
    var13.setNotify(true);
    int var18 = var13.getBackgroundImageAlignment();
    org.jfree.chart.ChartColor var22 = new org.jfree.chart.ChartColor(100, 0, 15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.setTextAntiAlias((java.lang.Object)0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 15);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var4 = var3.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var5 = var3.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var8 = var6.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var11 = var6.getItemLabelPaint(0, 10);
//     var3.setNoDataMessagePaint(var11);
//     var3.configureDomainAxes();
//     float var14 = var3.getBackgroundAlpha();
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var3);
//     org.jfree.chart.plot.Plot var16 = var15.getPlot();
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
//     var18.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var22 = var18.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.util.RectangleEdge var25 = null;
//     double var26 = var18.java2DToValue(0.0d, var24, var25);
//     org.jfree.data.Range var27 = null;
//     org.jfree.data.Range var29 = org.jfree.data.Range.expandToInclude(var27, 1.0d);
//     double var31 = var29.constrain((-1.0d));
//     var18.setRangeWithMargins(var29, true, false);
//     org.jfree.chart.block.RectangleConstraint var35 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var29);
//     org.jfree.chart.util.Size2D var36 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var37 = var35.calculateConstrainedSize(var36);
//     var37.setHeight(3.0d);
//     org.jfree.chart.plot.ValueMarker var43 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var44 = null;
//     var43.notifyListeners(var44);
//     var43.setValue((-1.0d));
//     java.awt.Stroke var48 = var43.getStroke();
//     org.jfree.chart.plot.ValueMarker var50 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis();
//     var51.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var55 = var51.getTickMarkStroke();
//     var50.setStroke(var55);
//     boolean var57 = var43.equals((java.lang.Object)var55);
//     org.jfree.chart.util.RectangleAnchor var58 = var43.getLabelAnchor();
//     java.awt.geom.Rectangle2D var59 = org.jfree.chart.util.RectangleAnchor.createRectangle(var37, 0.2d, 100.0d, var58);
//     org.jfree.chart.util.RectangleEdge var60 = null;
//     org.jfree.chart.axis.AxisSpace var61 = null;
//     org.jfree.chart.axis.AxisSpace var62 = var0.reserveSpace(var1, var16, var59, var60, var61);
// 
//   }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("RectangleEdge.RIGHT", (-16777216), 15);
// 
//   }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
//     org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.awt.Paint var3 = var2.getBackgroundPaint();
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var7 = null;
//     var6.notifyListeners(var7);
//     var6.setValue((-1.0d));
//     java.awt.Stroke var11 = var6.getOutlineStroke();
//     org.jfree.chart.util.LengthAdjustmentType var12 = var6.getLabelOffsetType();
//     java.awt.Font var13 = var6.getLabelFont();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var18 = var17.getRed();
//     java.awt.Color var19 = var17.brighter();
//     java.awt.image.ColorModel var20 = null;
//     java.awt.Rectangle var21 = null;
//     java.awt.geom.Rectangle2D var22 = null;
//     java.awt.geom.AffineTransform var23 = null;
//     java.awt.RenderingHints var24 = null;
//     java.awt.PaintContext var25 = var19.createContext(var20, var21, var22, var23, var24);
//     float[] var29 = new float[] { (-1.0f), (-1.0f), (-1.0f)};
//     float[] var30 = var19.getRGBColorComponents(var29);
//     org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("rect", var13, (java.awt.Paint)var19, 0.0f);
//     var2.setItemFont(var13);
//     org.jfree.chart.LegendItemSource[] var34 = var2.getSources();
//     java.awt.Graphics2D var35 = null;
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis();
//     var37.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var41 = var37.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var43 = null;
//     org.jfree.chart.util.RectangleEdge var44 = null;
//     double var45 = var37.java2DToValue(0.0d, var43, var44);
//     org.jfree.data.Range var46 = null;
//     org.jfree.data.Range var48 = org.jfree.data.Range.expandToInclude(var46, 1.0d);
//     double var50 = var48.constrain((-1.0d));
//     var37.setRangeWithMargins(var48, true, false);
//     org.jfree.chart.block.RectangleConstraint var54 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var48);
//     org.jfree.chart.util.Size2D var55 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var56 = var54.calculateConstrainedSize(var55);
//     var56.setHeight(3.0d);
//     org.jfree.chart.plot.ValueMarker var62 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var63 = null;
//     var62.notifyListeners(var63);
//     var62.setValue((-1.0d));
//     java.awt.Stroke var67 = var62.getStroke();
//     org.jfree.chart.plot.ValueMarker var69 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.axis.NumberAxis var70 = new org.jfree.chart.axis.NumberAxis();
//     var70.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var74 = var70.getTickMarkStroke();
//     var69.setStroke(var74);
//     boolean var76 = var62.equals((java.lang.Object)var74);
//     org.jfree.chart.util.RectangleAnchor var77 = var62.getLabelAnchor();
//     java.awt.geom.Rectangle2D var78 = org.jfree.chart.util.RectangleAnchor.createRectangle(var56, 0.2d, 100.0d, var77);
//     var2.draw(var35, var78);
// 
//   }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     var2.zoomRange(0.0d, 100.0d);
//     java.text.NumberFormat var6 = null;
//     var2.setNumberFormatOverride(var6);
//     java.awt.Paint var8 = var2.getAxisLinePaint();
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     var9.clearDomainMarkers(1);
//     java.awt.Image var12 = var9.getBackgroundImage();
//     org.jfree.chart.util.RectangleEdge var14 = var9.getRangeAxisEdge((-1));
//     org.jfree.chart.util.RectangleEdge var15 = org.jfree.chart.util.RectangleEdge.opposite(var14);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var19 = var17.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var20 = null;
//     var17.setBaseURLGenerator(var20, true);
//     int var23 = var17.getColumnCount();
//     java.awt.Font var24 = var17.getBaseItemLabelFont();
//     org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("", var24);
//     org.jfree.chart.axis.CategoryLabelPosition var26 = new org.jfree.chart.axis.CategoryLabelPosition();
//     boolean var27 = var25.equals((java.lang.Object)var26);
//     double var28 = var25.getContentXOffset();
//     java.lang.String var29 = var25.getURLText();
//     org.jfree.chart.util.HorizontalAlignment var30 = var25.getTextAlignment();
//     java.lang.String var31 = var30.toString();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var35 = var33.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var36 = null;
//     var33.setBaseURLGenerator(var36, true);
//     int var39 = var33.getColumnCount();
//     java.awt.Font var40 = var33.getBaseItemLabelFont();
//     org.jfree.chart.title.TextTitle var41 = new org.jfree.chart.title.TextTitle("", var40);
//     var41.setText("");
//     java.awt.Graphics2D var44 = null;
//     java.awt.geom.Rectangle2D var45 = null;
//     java.lang.Object var46 = null;
//     java.lang.Object var47 = var41.draw(var44, var45, var46);
//     org.jfree.chart.util.VerticalAlignment var48 = var41.getVerticalAlignment();
//     java.lang.String var49 = var48.toString();
//     org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var52 = var51.getInsets();
//     java.lang.String var53 = var52.toString();
//     var50.setTickLabelInsets(var52);
//     org.jfree.chart.title.TextTitle var55 = new org.jfree.chart.title.TextTitle("SortOrder.ASCENDING", var1, var8, var15, var30, var48, var52);
// 
//   }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     boolean var11 = var0.isSeriesVisible(0);
//     java.awt.Paint var12 = null;
//     var0.setErrorIndicatorPaint(var12);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var0.getLegendItemLabelGenerator();
//     var0.setSeriesItemLabelsVisible(1, (java.lang.Boolean)true, false);
//     var0.setBase(Double.NaN);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var23 = var21.getSeriesNegativeItemLabelPosition(100);
//     boolean var25 = var21.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var27 = var26.getFixedLegendItems();
//     var21.setPlot(var26);
//     java.awt.Paint var29 = var26.getBackgroundPaint();
//     org.jfree.chart.LegendItemCollection var30 = var26.getFixedLegendItems();
//     var26.clearRangeMarkers(1);
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var26);
//     
//     // Checks the contract:  equals-hashcode on var2 and var23
//     assertTrue("Contract failed: equals-hashcode on var2 and var23", var2.equals(var23) ? var2.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var2
//     assertTrue("Contract failed: equals-hashcode on var23 and var2", var23.equals(var2) ? var23.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var26
//     assertTrue("Contract failed: equals-hashcode on var5 and var26", var5.equals(var26) ? var5.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var5
//     assertTrue("Contract failed: equals-hashcode on var26 and var5", var26.equals(var5) ? var26.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Comparable var1 = null;
    int var2 = var0.getColumnIndex(var1);
    java.lang.Object var5 = var0.getObject((java.lang.Comparable)"hi!", (java.lang.Comparable)1.0f);
    var0.removeColumn((java.lang.Comparable)1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)0.5f);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { "LegendItemEntity: seriesKey=null, dataset=null"};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 1L};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
//     var0.setNoDataMessagePaint(var8);
//     var0.configureDomainAxes();
//     float var11 = var0.getBackgroundAlpha();
//     var0.setRangeCrosshairLockedOnData(true);
//     java.awt.Paint var14 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var19 = var17.getSeriesNegativeItemLabelPosition(100);
//     boolean var21 = var17.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var23 = var22.getFixedLegendItems();
//     var17.setPlot(var22);
//     java.awt.Paint var25 = var17.getErrorIndicatorPaint();
//     java.awt.Paint var26 = var17.getBaseOutlinePaint();
//     boolean var28 = var17.isSeriesVisible(0);
//     java.awt.Paint var29 = null;
//     var17.setErrorIndicatorPaint(var29);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var31 = var17.getLegendItemLabelGenerator();
//     java.awt.Stroke var34 = var17.getItemStroke(1, 10);
//     var15.setSeriesOutlineStroke(255, var34);
//     var0.setOutlineStroke(var34);
//     
//     // Checks the contract:  equals-hashcode on var5 and var19
//     assertTrue("Contract failed: equals-hashcode on var5 and var19", var5.equals(var19) ? var5.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var5
//     assertTrue("Contract failed: equals-hashcode on var19 and var5", var19.equals(var5) ? var19.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getPassCount();
    java.awt.Paint var4 = var0.getItemOutlinePaint(1, (-16777216));
    org.jfree.chart.urls.CategoryURLGenerator var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesURLGenerator((-1), var6, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = null;
//     var1.setBaseURLGenerator(var4, true);
//     int var7 = var1.getColumnCount();
//     java.awt.Font var8 = var1.getBaseItemLabelFont();
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var8);
//     var9.setText("");
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var15 = var13.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var16 = null;
//     var13.setBaseURLGenerator(var16, true);
//     int var19 = var13.getColumnCount();
//     java.awt.Font var20 = var13.getBaseItemLabelFont();
//     java.awt.Color var24 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var25 = var24.getRed();
//     org.jfree.chart.text.TextLine var26 = new org.jfree.chart.text.TextLine("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var20, (java.awt.Paint)var24);
//     java.awt.Color var27 = var24.darker();
//     var9.setBackgroundPaint((java.awt.Paint)var24);
//     
//     // Checks the contract:  equals-hashcode on var3 and var15
//     assertTrue("Contract failed: equals-hashcode on var3 and var15", var3.equals(var15) ? var3.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var3
//     assertTrue("Contract failed: equals-hashcode on var15 and var3", var15.equals(var3) ? var15.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     boolean var1 = var0.isEmpty();
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.axis.NumberTickUnit var5 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     java.lang.Object var6 = var0.draw(var2, var3, (java.lang.Object)100.0d);
// 
//   }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, (-6.0d), 0.05d, (-16777216), (java.lang.Comparable)(-5.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)(-16777216), 0.2d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = null;
//     var1.setBaseURLGenerator(var4, true);
//     int var7 = var1.getColumnCount();
//     java.awt.Font var8 = var1.getBaseItemLabelFont();
//     java.awt.Color var12 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var13 = var12.getRed();
//     org.jfree.chart.text.TextLine var14 = new org.jfree.chart.text.TextLine("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var8, (java.awt.Paint)var12);
//     java.awt.Color var18 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var19 = var18.getRed();
//     java.awt.Color var20 = var18.brighter();
//     float[] var24 = new float[] { 100.0f, 10.0f, 100.0f};
//     float[] var25 = var18.getRGBColorComponents(var24);
//     float[] var26 = var12.getColorComponents(var24);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var29 = var28.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var30 = var28.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var31 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var33 = var31.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var36 = var31.getItemLabelPaint(0, 10);
//     var28.setNoDataMessagePaint(var36);
//     var28.configureDomainAxes();
//     float var39 = var28.getBackgroundAlpha();
//     org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var28);
//     java.awt.Color var48 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var49 = var48.getRed();
//     java.awt.Color var50 = var48.brighter();
//     java.awt.image.ColorModel var51 = null;
//     java.awt.Rectangle var52 = null;
//     java.awt.geom.Rectangle2D var53 = null;
//     java.awt.geom.AffineTransform var54 = null;
//     java.awt.RenderingHints var55 = null;
//     java.awt.PaintContext var56 = var50.createContext(var51, var52, var53, var54, var55);
//     org.jfree.chart.util.ObjectList var57 = new org.jfree.chart.util.ObjectList();
//     boolean var58 = var50.equals((java.lang.Object)var57);
//     org.jfree.chart.block.BlockBorder var59 = new org.jfree.chart.block.BlockBorder(Double.NaN, (-5.0d), (-1.0d), 0.05d, (java.awt.Paint)var50);
//     var40.setBorderPaint((java.awt.Paint)var50);
//     java.awt.color.ColorSpace var61 = var50.getColorSpace();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var63 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var65 = var63.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var66 = null;
//     var63.setBaseURLGenerator(var66, true);
//     int var69 = var63.getColumnCount();
//     java.awt.Font var70 = var63.getBaseItemLabelFont();
//     java.awt.Color var74 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var75 = var74.getRed();
//     org.jfree.chart.text.TextLine var76 = new org.jfree.chart.text.TextLine("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var70, (java.awt.Paint)var74);
//     java.awt.Color var80 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var81 = var80.getRed();
//     java.awt.Color var82 = var80.brighter();
//     float[] var86 = new float[] { 100.0f, 10.0f, 100.0f};
//     float[] var87 = var80.getRGBColorComponents(var86);
//     float[] var88 = var74.getColorComponents(var86);
//     float[] var89 = var12.getColorComponents(var61, var88);
//     
//     // Checks the contract:  equals-hashcode on var3 and var33
//     assertTrue("Contract failed: equals-hashcode on var3 and var33", var3.equals(var33) ? var3.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var65
//     assertTrue("Contract failed: equals-hashcode on var3 and var65", var3.equals(var65) ? var3.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var3
//     assertTrue("Contract failed: equals-hashcode on var33 and var3", var33.equals(var3) ? var33.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var65
//     assertTrue("Contract failed: equals-hashcode on var33 and var65", var33.equals(var65) ? var33.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var3
//     assertTrue("Contract failed: equals-hashcode on var65 and var3", var65.equals(var3) ? var65.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var33
//     assertTrue("Contract failed: equals-hashcode on var65 and var33", var65.equals(var33) ? var65.hashCode() == var33.hashCode() : true);
// 
//   }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, false);
// 
//   }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var11 = var0.getSeriesItemLabelGenerator((-1));
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.block.LineBorder var13 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var14 = var13.getInsets();
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var16 = var15.getFixedLegendItems();
//     java.lang.String var17 = var15.getPlotType();
//     org.jfree.chart.plot.DrawingSupplier var18 = var15.getDrawingSupplier();
//     boolean var19 = var13.equals((java.lang.Object)var15);
//     java.awt.geom.Rectangle2D var20 = null;
//     var0.drawOutline(var12, var15, var20);
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(1.0d);
    org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var3 = var2.getCategoryAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var4 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var1, var2);
    org.jfree.chart.axis.CategoryLabelPosition var5 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.text.TextAnchor var6 = var5.getRotationAnchor();
    org.jfree.chart.axis.CategoryLabelPosition var7 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.text.TextAnchor var8 = var7.getRotationAnchor();
    org.jfree.chart.axis.CategoryLabelPosition var9 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPosition var10 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var11 = var10.getCategoryAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var12 = new org.jfree.chart.axis.CategoryLabelPositions(var5, var7, var9, var10);
    org.jfree.chart.axis.CategoryLabelPositions var13 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var1, var7);
    org.jfree.chart.axis.CategoryLabelPositions var15 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(1.0d);
    org.jfree.chart.axis.CategoryLabelPosition var16 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var17 = var16.getCategoryAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var18 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var15, var16);
    org.jfree.chart.axis.CategoryLabelPositions var19 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var1, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var3 = var0.getBaseFillPaint();
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var0.getBaseItemLabelGenerator();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    java.lang.Object var6 = var5.clone();
    var0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var5);
    org.jfree.data.category.CategoryDataset var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var10 = var5.generateLabel(var8, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition(100);
    boolean var6 = var2.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var8 = var7.getFixedLegendItems();
    var2.setPlot(var7);
    java.awt.Paint var10 = var2.getErrorIndicatorPaint();
    var2.setBase(100.0d);
    boolean var15 = var2.getItemVisible(1, 1);
    java.awt.Shape var17 = var2.lookupSeriesShape(100);
    org.jfree.chart.entity.CategoryLabelEntity var20 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)0.0f, var17, "", "");
    org.jfree.chart.entity.CategoryLabelEntity var23 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"3", var17, "rect", "rect");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var24 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Stroke var25 = var24.getBaseOutlineStroke();
    boolean var26 = var23.equals((java.lang.Object)var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 3.0d, 0.0f, 1.0f);
    org.jfree.chart.entity.ChartEntity var8 = new org.jfree.chart.entity.ChartEntity(var1, "", "");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     boolean var11 = var0.isSeriesVisible(0);
//     java.awt.Paint var12 = null;
//     var0.setErrorIndicatorPaint(var12);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var0.getLegendItemLabelGenerator();
//     var0.setItemLabelAnchorOffset(3.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var20 = var18.getSeriesNegativeItemLabelPosition(100);
//     boolean var22 = var18.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var24 = var23.getFixedLegendItems();
//     var18.setPlot(var23);
//     java.awt.Paint var26 = var18.getErrorIndicatorPaint();
//     java.awt.Paint var27 = var18.getBaseOutlinePaint();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var29 = var18.getSeriesItemLabelGenerator((-1));
//     java.awt.Stroke var31 = var18.lookupSeriesStroke(0);
//     var0.setSeriesOutlineStroke(15, var31, false);
//     
//     // Checks the contract:  equals-hashcode on var2 and var20
//     assertTrue("Contract failed: equals-hashcode on var2 and var20", var2.equals(var20) ? var2.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var2
//     assertTrue("Contract failed: equals-hashcode on var20 and var2", var20.equals(var2) ? var20.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var23
//     assertTrue("Contract failed: equals-hashcode on var5 and var23", var5.equals(var23) ? var5.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var5
//     assertTrue("Contract failed: equals-hashcode on var23 and var5", var23.equals(var5) ? var23.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartProgressEvent var4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)100, var1, 10, 0);
    org.jfree.chart.JFreeChart var5 = var4.getChart();
    org.jfree.chart.JFreeChart var6 = var4.getChart();
    int var7 = var4.getType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 10);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.0d, 100.0d);
//     org.jfree.data.general.Dataset var5 = null;
//     java.lang.Comparable var6 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, var6);
//     java.lang.String var8 = var7.getToolTipText();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
//     var10.zoomRange(100.0d, 100.0d);
//     var10.setLowerBound(10.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(100);
//     boolean var20 = var16.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var22 = var21.getFixedLegendItems();
//     var16.setPlot(var21);
//     java.awt.Paint var24 = var16.getErrorIndicatorPaint();
//     var16.setBase(100.0d);
//     boolean var29 = var16.getItemVisible(1, 1);
//     java.awt.Shape var31 = var16.lookupSeriesShape(100);
//     var10.setUpArrow(var31);
//     float var33 = var10.getTickMarkOutsideLength();
//     boolean var34 = var10.isNegativeArrowVisible();
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis();
//     var37.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var41 = var37.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var43 = null;
//     org.jfree.chart.util.RectangleEdge var44 = null;
//     double var45 = var37.java2DToValue(0.0d, var43, var44);
//     org.jfree.data.Range var46 = null;
//     org.jfree.data.Range var48 = org.jfree.data.Range.expandToInclude(var46, 1.0d);
//     double var50 = var48.constrain((-1.0d));
//     var37.setRangeWithMargins(var48, true, false);
//     org.jfree.chart.block.RectangleConstraint var54 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var48);
//     org.jfree.chart.util.Size2D var55 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var56 = var54.calculateConstrainedSize(var55);
//     var56.setHeight(3.0d);
//     org.jfree.chart.plot.ValueMarker var62 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var63 = null;
//     var62.notifyListeners(var63);
//     var62.setValue((-1.0d));
//     java.awt.Stroke var67 = var62.getStroke();
//     org.jfree.chart.plot.ValueMarker var69 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.axis.NumberAxis var70 = new org.jfree.chart.axis.NumberAxis();
//     var70.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var74 = var70.getTickMarkStroke();
//     var69.setStroke(var74);
//     boolean var76 = var62.equals((java.lang.Object)var74);
//     org.jfree.chart.util.RectangleAnchor var77 = var62.getLabelAnchor();
//     java.awt.geom.Rectangle2D var78 = org.jfree.chart.util.RectangleAnchor.createRectangle(var56, 0.2d, 100.0d, var77);
//     org.jfree.chart.plot.CategoryPlot var79 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.general.DatasetGroup var80 = var79.getDatasetGroup();
//     org.jfree.chart.util.RectangleEdge var81 = var79.getDomainAxisEdge();
//     double var82 = var10.lengthToJava2D((-11.0d), var78, var81);
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var83 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
//     java.lang.Object var84 = var7.draw(var9, var78, (java.lang.Object)var83);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 3.0d, (-1.0f), (-1.0f));

  }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 10);
// 
//   }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     java.awt.Stroke var2 = var0.getOutlineStroke();
//     java.awt.Stroke var3 = var0.getOutlineStroke();
//     org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxis();
//     var0.setDomainGridlinesVisible(true);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var10 = var8.getSeriesNegativeItemLabelPosition(100);
//     boolean var12 = var8.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var14 = var13.getFixedLegendItems();
//     var8.setPlot(var13);
//     java.awt.Paint var16 = var8.getErrorIndicatorPaint();
//     java.awt.Paint var17 = var8.getBaseOutlinePaint();
//     boolean var19 = var8.isSeriesVisible(0);
//     var0.setRenderer(10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var8, false);
//     boolean var24 = var8.isItemLabelVisible(0, 0);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var27 = var25.getSeriesNegativeItemLabelPosition(100);
//     boolean var29 = var25.isSeriesVisible(10);
//     var25.setAutoPopulateSeriesPaint(false);
//     java.lang.Object var32 = var25.clone();
//     java.awt.Paint var35 = var25.getItemLabelPaint(1, 10);
//     var25.setSeriesItemLabelsVisible(1, false);
//     boolean var39 = var25.getAutoPopulateSeriesStroke();
//     org.jfree.chart.labels.ItemLabelPosition var40 = var25.getBaseNegativeItemLabelPosition();
//     var8.setBaseNegativeItemLabelPosition(var40);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var8 and var25.", var8.equals(var25) == var25.equals(var8));
//     
//     // Checks the contract:  equals-hashcode on var10 and var27
//     assertTrue("Contract failed: equals-hashcode on var10 and var27", var10.equals(var27) ? var10.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var40
//     assertTrue("Contract failed: equals-hashcode on var10 and var40", var10.equals(var40) ? var10.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var10
//     assertTrue("Contract failed: equals-hashcode on var27 and var10", var27.equals(var10) ? var27.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var10
//     assertTrue("Contract failed: equals-hashcode on var40 and var10", var40.equals(var10) ? var40.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("hi!");
    boolean var3 = var1.equals((java.lang.Object)"Category Plot");
    var1.setToolTipText("hi!");
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var8 = var7.getInsets();
    java.lang.String var9 = var8.toString();
    var6.setTickLabelInsets(var8);
    double var12 = var8.calculateLeftInset(0.0d);
    double var14 = var8.calculateLeftOutset(0.0d);
    var1.setPadding(var8);
    double var16 = var8.getRight();
    double var17 = var8.getRight();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"+ "'", var9.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 8.0d);

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = null;
//     var1.setBaseURLGenerator(var4, true);
//     int var7 = var1.getColumnCount();
//     java.awt.Font var8 = var1.getBaseItemLabelFont();
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var8);
//     var9.setText("");
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     java.lang.Object var14 = null;
//     java.lang.Object var15 = var9.draw(var12, var13, var14);
//     java.awt.Paint var16 = null;
//     var9.setBackgroundPaint(var16);
//     double var18 = var9.getContentXOffset();
//     var9.setMargin(4.0d, 0.0d, 8.0d, (-6.0d));
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var27 = var25.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var28 = null;
//     var25.setBaseURLGenerator(var28, true);
//     int var31 = var25.getColumnCount();
//     java.awt.Font var32 = var25.getBaseItemLabelFont();
//     org.jfree.chart.title.TextTitle var33 = new org.jfree.chart.title.TextTitle("", var32);
//     org.jfree.chart.axis.CategoryLabelPosition var34 = new org.jfree.chart.axis.CategoryLabelPosition();
//     boolean var35 = var33.equals((java.lang.Object)var34);
//     double var36 = var33.getContentXOffset();
//     java.lang.String var37 = var33.getURLText();
//     org.jfree.chart.util.HorizontalAlignment var38 = var33.getTextAlignment();
//     java.lang.String var39 = var38.toString();
//     var9.setTextAlignment(var38);
//     
//     // Checks the contract:  equals-hashcode on var3 and var27
//     assertTrue("Contract failed: equals-hashcode on var3 and var27", var3.equals(var27) ? var3.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var3
//     assertTrue("Contract failed: equals-hashcode on var27 and var3", var27.equals(var3) ? var27.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { "PlotOrientation.VERTICAL"};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { "TextAnchor.CENTER"};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.text.TextAnchor var3 = var2.getTextAnchor();
//     org.jfree.chart.labels.ItemLabelAnchor var4 = var2.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPosition var5 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.text.TextAnchor var6 = var5.getRotationAnchor();
//     org.jfree.chart.axis.CategoryLabelPosition var7 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.text.TextAnchor var8 = var7.getRotationAnchor();
//     org.jfree.chart.axis.CategoryLabelPosition var9 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPosition var10 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.util.RectangleAnchor var11 = var10.getCategoryAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var12 = new org.jfree.chart.axis.CategoryLabelPositions(var5, var7, var9, var10);
//     org.jfree.chart.text.TextAnchor var13 = var9.getRotationAnchor();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var16 = var14.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.text.TextAnchor var17 = var16.getTextAnchor();
//     org.jfree.chart.labels.ItemLabelAnchor var18 = var16.getItemLabelAnchor();
//     org.jfree.chart.text.TextAnchor var19 = var16.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var21 = new org.jfree.chart.labels.ItemLabelPosition(var4, var13, var19, 100.0d);
//     
//     // Checks the contract:  equals-hashcode on var2 and var16
//     assertTrue("Contract failed: equals-hashcode on var2 and var16", var2.equals(var16) ? var2.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var2
//     assertTrue("Contract failed: equals-hashcode on var16 and var2", var16.equals(var2) ? var16.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.zoomRange(0.0d, 100.0d);
    java.text.NumberFormat var4 = null;
    var0.setNumberFormatOverride(var4);
    java.awt.Paint var6 = var0.getAxisLinePaint();
    double var7 = var0.getLowerBound();
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    java.text.NumberFormat var9 = null;
    var8.setNumberFormatOverride(var9);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var14 = var12.getSeriesNegativeItemLabelPosition(100);
    boolean var16 = var12.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var18 = var17.getFixedLegendItems();
    var12.setPlot(var17);
    java.awt.Paint var20 = var12.getErrorIndicatorPaint();
    var12.setBase(100.0d);
    boolean var25 = var12.getItemVisible(1, 1);
    java.awt.Shape var27 = var12.lookupSeriesShape(100);
    org.jfree.chart.entity.CategoryLabelEntity var30 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)10L, var27, "Category Plot", "");
    var8.setRightArrow(var27);
    var0.setRightArrow(var27);
    var0.setLabel("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var3 = var0.getBaseFillPaint();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    var5.zoomRange(0.0d, 100.0d);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    org.jfree.chart.entity.AxisLabelEntity var14 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var5, var11, "hi!", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShape((-1), var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
    var0.setNoDataMessagePaint(var8);
    var0.configureDomainAxes();
    float var11 = var0.getBackgroundAlpha();
    org.jfree.chart.axis.AxisLocation var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation(0, var13, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0f);

  }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
//     java.awt.Paint var3 = var0.getOutlinePaint();
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     var4.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var8 = var4.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleEdge var11 = null;
//     double var12 = var4.java2DToValue(0.0d, var10, var11);
//     java.awt.Font var13 = var4.getTickLabelFont();
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.setRangeWithMargins(4.0d, 0.0d);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    int var3 = var0.getPassCount();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    var4.zoomRange(100.0d, 100.0d);
    boolean var8 = var0.equals((java.lang.Object)100.0d);
    org.jfree.chart.urls.CategoryURLGenerator var10 = var0.getSeriesURLGenerator((-1));
    org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.event.MarkerChangeEvent var14 = null;
    var13.notifyListeners(var14);
    var13.setValue((-1.0d));
    java.awt.Stroke var18 = var13.getStroke();
    org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    var21.zoomRange(0.0d, 100.0d);
    java.awt.Stroke var25 = var21.getTickMarkStroke();
    var20.setStroke(var25);
    boolean var27 = var13.equals((java.lang.Object)var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesStroke((-16777216), var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Comparable var1 = null;
    int var2 = var0.getColumnIndex(var1);
    java.lang.Object var5 = var0.getObject((java.lang.Comparable)"hi!", (java.lang.Comparable)1.0f);
    int var7 = var0.getColumnIndex((java.lang.Comparable)(short)0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var9 = var0.getColumnKey(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var2 = var1.getInsets();
//     org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     java.awt.Paint var4 = var3.getBackgroundPaint();
//     org.jfree.chart.plot.ValueMarker var7 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var8 = null;
//     var7.notifyListeners(var8);
//     var7.setValue((-1.0d));
//     java.awt.Stroke var12 = var7.getOutlineStroke();
//     org.jfree.chart.util.LengthAdjustmentType var13 = var7.getLabelOffsetType();
//     java.awt.Font var14 = var7.getLabelFont();
//     java.awt.Color var18 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var19 = var18.getRed();
//     java.awt.Color var20 = var18.brighter();
//     java.awt.image.ColorModel var21 = null;
//     java.awt.Rectangle var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     java.awt.geom.AffineTransform var24 = null;
//     java.awt.RenderingHints var25 = null;
//     java.awt.PaintContext var26 = var20.createContext(var21, var22, var23, var24, var25);
//     float[] var30 = new float[] { (-1.0f), (-1.0f), (-1.0f)};
//     float[] var31 = var20.getRGBColorComponents(var30);
//     org.jfree.chart.text.TextFragment var33 = new org.jfree.chart.text.TextFragment("rect", var14, (java.awt.Paint)var20, 0.0f);
//     var3.setItemFont(var14);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var35 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     double var36 = var35.getMinimumBarLength();
//     var35.setAutoPopulateSeriesStroke(false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var41 = var39.getSeriesNegativeItemLabelPosition(100);
//     boolean var43 = var39.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var45 = var44.getFixedLegendItems();
//     var39.setPlot(var44);
//     java.awt.Paint var47 = var39.getErrorIndicatorPaint();
//     var35.setBaseItemLabelPaint(var47);
//     java.lang.Boolean var50 = var35.getSeriesVisibleInLegend(0);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var51 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.awt.Stroke var52 = var51.getBaseOutlineStroke();
//     boolean var54 = var51.isSeriesVisible(10);
//     java.awt.Color var58 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var59 = var58.getRed();
//     java.awt.Color var60 = var58.brighter();
//     java.awt.image.ColorModel var61 = null;
//     java.awt.Rectangle var62 = null;
//     java.awt.geom.Rectangle2D var63 = null;
//     java.awt.geom.AffineTransform var64 = null;
//     java.awt.RenderingHints var65 = null;
//     java.awt.PaintContext var66 = var60.createContext(var61, var62, var63, var64, var65);
//     var51.setBaseFillPaint((java.awt.Paint)var60);
//     int var68 = var60.getBlue();
//     var35.setBaseFillPaint((java.awt.Paint)var60, true);
//     java.awt.Graphics2D var73 = null;
//     org.jfree.chart.text.G2TextMeasurer var74 = new org.jfree.chart.text.G2TextMeasurer(var73);
//     org.jfree.chart.text.TextBlock var75 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, (java.awt.Paint)var60, 0.8f, 15, (org.jfree.chart.text.TextMeasurer)var74);
//     
//     // Checks the contract:  equals-hashcode on var1 and var44
//     assertTrue("Contract failed: equals-hashcode on var1 and var44", var1.equals(var44) ? var1.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var1
//     assertTrue("Contract failed: equals-hashcode on var44 and var1", var44.equals(var1) ? var44.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var2 = var1.getFixedLegendItems();
//     java.awt.Stroke var3 = var1.getOutlineStroke();
//     java.awt.Stroke var4 = var1.getOutlineStroke();
//     org.jfree.chart.axis.ValueAxis var5 = var1.getRangeAxis();
//     java.awt.Stroke var6 = var1.getOutlineStroke();
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("HorizontalAlignment.CENTER", (org.jfree.chart.plot.Plot)var1);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
//     var9.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var13 = var9.getTickMarkStroke();
//     boolean var14 = var9.isAutoRange();
//     double var15 = var9.getUpperBound();
//     java.lang.String var16 = var9.getLabelToolTip();
//     org.jfree.chart.util.RectangleInsets var17 = var9.getLabelInsets();
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
//     var19.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var23 = var19.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.util.RectangleEdge var26 = null;
//     double var27 = var19.java2DToValue(0.0d, var25, var26);
//     org.jfree.data.Range var28 = null;
//     org.jfree.data.Range var30 = org.jfree.data.Range.expandToInclude(var28, 1.0d);
//     double var32 = var30.constrain((-1.0d));
//     var19.setRangeWithMargins(var30, true, false);
//     org.jfree.chart.block.RectangleConstraint var36 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var30);
//     org.jfree.chart.util.Size2D var37 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var38 = var36.calculateConstrainedSize(var37);
//     var38.setHeight(3.0d);
//     org.jfree.chart.plot.ValueMarker var44 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var45 = null;
//     var44.notifyListeners(var45);
//     var44.setValue((-1.0d));
//     java.awt.Stroke var49 = var44.getStroke();
//     org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis();
//     var52.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var56 = var52.getTickMarkStroke();
//     var51.setStroke(var56);
//     boolean var58 = var44.equals((java.lang.Object)var56);
//     org.jfree.chart.util.RectangleAnchor var59 = var44.getLabelAnchor();
//     java.awt.geom.Rectangle2D var60 = org.jfree.chart.util.RectangleAnchor.createRectangle(var38, 0.2d, 100.0d, var59);
//     java.awt.Shape var63 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var60, 3.0d, 1.0E-8d);
//     java.awt.geom.Rectangle2D var66 = var17.createInsetRectangle(var60, false, true);
//     org.jfree.chart.ChartRenderingInfo var67 = null;
//     var7.draw(var8, var60, var67);
// 
//   }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = null;
//     var1.setBaseURLGenerator(var4, true);
//     int var7 = var1.getColumnCount();
//     java.awt.Font var8 = var1.getBaseItemLabelFont();
//     java.awt.Color var12 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var13 = var12.getRed();
//     org.jfree.chart.text.TextLine var14 = new org.jfree.chart.text.TextLine("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var8, (java.awt.Paint)var12);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var19 = null;
//     var16.setBaseURLGenerator(var19, true);
//     int var22 = var16.getColumnCount();
//     java.awt.Font var23 = var16.getBaseItemLabelFont();
//     org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("", var23);
//     var24.setText("");
//     java.awt.Graphics2D var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     java.lang.Object var29 = null;
//     java.lang.Object var30 = var24.draw(var27, var28, var29);
//     org.jfree.chart.util.VerticalAlignment var31 = var24.getVerticalAlignment();
//     boolean var32 = var12.equals((java.lang.Object)var24);
//     
//     // Checks the contract:  equals-hashcode on var3 and var18
//     assertTrue("Contract failed: equals-hashcode on var3 and var18", var3.equals(var18) ? var3.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var3
//     assertTrue("Contract failed: equals-hashcode on var18 and var3", var18.equals(var3) ? var18.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.zoomRange(0.0d, 100.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
//     boolean var8 = var4.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var10 = var9.getFixedLegendItems();
//     var4.setPlot(var9);
//     java.awt.Paint var12 = var9.getBackgroundPaint();
//     var0.setPlot((org.jfree.chart.plot.Plot)var9);
//     org.jfree.chart.axis.NumberTickUnit var14 = var0.getTickUnit();
//     var0.setAutoTickUnitSelection(false);
//     var0.setTickLabelsVisible(true);
//     var0.setLabelAngle(Double.NaN);
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
//     var22.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var26 = var22.getTickMarkStroke();
//     boolean var27 = var22.isAutoRange();
//     double var28 = var22.getUpperBound();
//     java.lang.String var29 = var22.getLabelToolTip();
//     org.jfree.chart.util.RectangleInsets var30 = var22.getLabelInsets();
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis();
//     var32.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var36 = var32.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.chart.util.RectangleEdge var39 = null;
//     double var40 = var32.java2DToValue(0.0d, var38, var39);
//     org.jfree.data.Range var41 = null;
//     org.jfree.data.Range var43 = org.jfree.data.Range.expandToInclude(var41, 1.0d);
//     double var45 = var43.constrain((-1.0d));
//     var32.setRangeWithMargins(var43, true, false);
//     org.jfree.chart.block.RectangleConstraint var49 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var43);
//     org.jfree.chart.util.Size2D var50 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var51 = var49.calculateConstrainedSize(var50);
//     var51.setHeight(3.0d);
//     org.jfree.chart.plot.ValueMarker var57 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var58 = null;
//     var57.notifyListeners(var58);
//     var57.setValue((-1.0d));
//     java.awt.Stroke var62 = var57.getStroke();
//     org.jfree.chart.plot.ValueMarker var64 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.axis.NumberAxis var65 = new org.jfree.chart.axis.NumberAxis();
//     var65.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var69 = var65.getTickMarkStroke();
//     var64.setStroke(var69);
//     boolean var71 = var57.equals((java.lang.Object)var69);
//     org.jfree.chart.util.RectangleAnchor var72 = var57.getLabelAnchor();
//     java.awt.geom.Rectangle2D var73 = org.jfree.chart.util.RectangleAnchor.createRectangle(var51, 0.2d, 100.0d, var72);
//     java.awt.Shape var76 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var73, 3.0d, 1.0E-8d);
//     java.awt.geom.Rectangle2D var79 = var30.createInsetRectangle(var73, false, true);
//     org.jfree.chart.plot.CategoryPlot var80 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var81 = var80.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var82 = var80.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var83 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var85 = var83.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var88 = var83.getItemLabelPaint(0, 10);
//     var80.setNoDataMessagePaint(var88);
//     var80.configureDomainAxes();
//     float var91 = var80.getBackgroundAlpha();
//     var80.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.util.RectangleEdge var94 = var80.getRangeAxisEdge();
//     double var95 = var0.lengthToJava2D(0.2d, var79, var94);
//     
//     // Checks the contract:  equals-hashcode on var6 and var85
//     assertTrue("Contract failed: equals-hashcode on var6 and var85", var6.equals(var85) ? var6.hashCode() == var85.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var85 and var6
//     assertTrue("Contract failed: equals-hashcode on var85 and var6", var85.equals(var6) ? var85.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var80
//     assertTrue("Contract failed: equals-hashcode on var9 and var80", var9.equals(var80) ? var9.hashCode() == var80.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var80 and var9
//     assertTrue("Contract failed: equals-hashcode on var80 and var9", var80.equals(var9) ? var80.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.zoomRange(100.0d, 100.0d);
    var0.setAutoRangeStickyZero(true);
    org.jfree.chart.plot.Plot var6 = var0.getPlot();
    org.jfree.chart.event.AxisChangeEvent var7 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var0);
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var10 = var9.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var11 = var9.getDataset();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var14 = var12.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var17 = var12.getItemLabelPaint(0, 10);
    var9.setNoDataMessagePaint(var17);
    var9.configureDomainAxes();
    float var20 = var9.getBackgroundAlpha();
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    java.awt.Image var22 = null;
    var21.setBackgroundImage(var22);
    var21.setBackgroundImageAlignment(100);
    java.awt.Color var29 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var30 = var29.getRed();
    java.awt.Color var31 = var29.brighter();
    float[] var35 = new float[] { 100.0f, 10.0f, 100.0f};
    float[] var36 = var29.getRGBColorComponents(var35);
    var21.setBackgroundPaint((java.awt.Paint)var29);
    var7.setChart(var21);
    org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.RectangleInsets var41 = var40.getPadding();
    var21.setTitle(var40);
    int var43 = var21.getSubtitleCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var44 = var21.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Stroke var1 = var0.getBaseOutlineStroke();
    boolean var3 = var0.isSeriesVisible(10);
    java.awt.Paint var6 = var0.getItemFillPaint(255, 0);
    org.jfree.chart.event.RendererChangeEvent var7 = null;
    var0.notifyListeners(var7);
    boolean var9 = var0.getAutoPopulateSeriesOutlinePaint();
    org.jfree.chart.labels.CategoryToolTipGenerator var11 = null;
    var0.setSeriesToolTipGenerator(10, var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisibleInLegend((-16777216), (java.lang.Boolean)false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var5 = var0.getItemLabelPaint(0, 10);
//     java.awt.Stroke var7 = var0.getSeriesStroke(1);
//     java.awt.Stroke var9 = var0.getSeriesOutlineStroke(0);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(100);
//     boolean var14 = var10.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var16 = var15.getFixedLegendItems();
//     var10.setPlot(var15);
//     java.awt.Paint var18 = var15.getBackgroundPaint();
//     var0.setBaseFillPaint(var18, false);
//     
//     // Checks the contract:  equals-hashcode on var2 and var12
//     assertTrue("Contract failed: equals-hashcode on var2 and var12", var2.equals(var12) ? var2.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var2
//     assertTrue("Contract failed: equals-hashcode on var12 and var2", var12.equals(var2) ? var12.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("PlotOrientation.VERTICAL", var1, var2);
// 
//   }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
    var0.setPlot(var5);
    java.awt.Paint var8 = var0.getErrorIndicatorPaint();
    var0.setBase(100.0d);
    org.jfree.chart.urls.CategoryURLGenerator var12 = var0.getSeriesURLGenerator(100);
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = null;
    var0.setSeriesItemLabelGenerator(100, var14, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    java.awt.Stroke var2 = var0.getOutlineStroke();
    java.awt.Stroke var3 = var0.getOutlineStroke();
    org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxis();
    var0.setDomainGridlinesVisible(true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var10 = var8.getSeriesNegativeItemLabelPosition(100);
    boolean var12 = var8.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var14 = var13.getFixedLegendItems();
    var8.setPlot(var13);
    java.awt.Paint var16 = var8.getErrorIndicatorPaint();
    java.awt.Paint var17 = var8.getBaseOutlinePaint();
    boolean var19 = var8.isSeriesVisible(0);
    var0.setRenderer(10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var8, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var22 = var0.getRenderer();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBackgroundImageAlpha(2.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var8 = var3.getItemLabelPaint(0, 10);
//     var0.setNoDataMessagePaint(var8);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = var0.getRenderer();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     var12.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var16 = var12.getTickMarkStroke();
//     boolean var17 = var12.isAutoRange();
//     double var18 = var12.getUpperBound();
//     java.lang.String var19 = var12.getLabelToolTip();
//     org.jfree.chart.util.RectangleInsets var20 = var12.getLabelInsets();
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
//     var22.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var26 = var22.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var28 = null;
//     org.jfree.chart.util.RectangleEdge var29 = null;
//     double var30 = var22.java2DToValue(0.0d, var28, var29);
//     org.jfree.data.Range var31 = null;
//     org.jfree.data.Range var33 = org.jfree.data.Range.expandToInclude(var31, 1.0d);
//     double var35 = var33.constrain((-1.0d));
//     var22.setRangeWithMargins(var33, true, false);
//     org.jfree.chart.block.RectangleConstraint var39 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var33);
//     org.jfree.chart.util.Size2D var40 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var41 = var39.calculateConstrainedSize(var40);
//     var41.setHeight(3.0d);
//     org.jfree.chart.plot.ValueMarker var47 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var48 = null;
//     var47.notifyListeners(var48);
//     var47.setValue((-1.0d));
//     java.awt.Stroke var52 = var47.getStroke();
//     org.jfree.chart.plot.ValueMarker var54 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis();
//     var55.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var59 = var55.getTickMarkStroke();
//     var54.setStroke(var59);
//     boolean var61 = var47.equals((java.lang.Object)var59);
//     org.jfree.chart.util.RectangleAnchor var62 = var47.getLabelAnchor();
//     java.awt.geom.Rectangle2D var63 = org.jfree.chart.util.RectangleAnchor.createRectangle(var41, 0.2d, 100.0d, var62);
//     java.awt.Shape var66 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var63, 3.0d, 1.0E-8d);
//     java.awt.geom.Rectangle2D var69 = var20.createInsetRectangle(var63, false, true);
//     var0.drawOutline(var11, var63);
// 
//   }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     java.awt.Stroke var2 = var0.getOutlineStroke();
//     org.jfree.chart.axis.AxisLocation var4 = var0.getRangeAxisLocation(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     java.awt.Stroke var7 = var5.getOutlineStroke();
//     java.awt.Stroke var8 = var5.getOutlineStroke();
//     org.jfree.chart.axis.ValueAxis var9 = var5.getRangeAxis();
//     float var10 = var5.getBackgroundImageAlpha();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var13 = var11.getSeriesNegativeItemLabelPosition(100);
//     boolean var15 = var11.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var17 = var16.getFixedLegendItems();
//     var11.setPlot(var16);
//     java.awt.Paint var19 = var16.getBackgroundPaint();
//     org.jfree.chart.LegendItemCollection var20 = var16.getFixedLegendItems();
//     java.awt.Paint var21 = var16.getRangeCrosshairPaint();
//     var5.setNoDataMessagePaint(var21);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     double var24 = var23.getMinimumBarLength();
//     var5.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
//     org.jfree.chart.plot.DatasetRenderingOrder var26 = var5.getDatasetRenderingOrder();
//     var0.setDatasetRenderingOrder(var26);
//     
//     // Checks the contract:  equals-hashcode on var0 and var16
//     assertTrue("Contract failed: equals-hashcode on var0 and var16", var0.equals(var16) ? var0.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var0
//     assertTrue("Contract failed: equals-hashcode on var16 and var0", var16.equals(var0) ? var16.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.zoomRange(100.0d, 100.0d);
    var0.setAutoRangeStickyZero(true);
    org.jfree.chart.plot.Plot var6 = var0.getPlot();
    org.jfree.chart.event.AxisChangeEvent var7 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var0);
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var10 = var9.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var11 = var9.getDataset();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var14 = var12.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var17 = var12.getItemLabelPaint(0, 10);
    var9.setNoDataMessagePaint(var17);
    var9.configureDomainAxes();
    float var20 = var9.getBackgroundAlpha();
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    java.awt.Image var22 = null;
    var21.setBackgroundImage(var22);
    var21.setBackgroundImageAlignment(100);
    java.awt.Color var29 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var30 = var29.getRed();
    java.awt.Color var31 = var29.brighter();
    float[] var35 = new float[] { 100.0f, 10.0f, 100.0f};
    float[] var36 = var29.getRGBColorComponents(var35);
    var21.setBackgroundPaint((java.awt.Paint)var29);
    var7.setChart(var21);
    org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.RectangleInsets var41 = var40.getPadding();
    var21.setTitle(var40);
    org.jfree.chart.event.ChartChangeListener var43 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.removeChangeListener(var43);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
//     boolean var4 = var0.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     var0.setPlot(var5);
//     java.awt.Paint var8 = var0.getErrorIndicatorPaint();
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     var0.setBaseSeriesVisible(true, true);
//     boolean var14 = var0.equals((java.lang.Object)1.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var17 = var15.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var18 = var15.getBaseFillPaint();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var19 = var15.getBaseItemLabelGenerator();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var20 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
//     java.lang.Object var21 = var20.clone();
//     var15.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var20);
//     var0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var20);
//     
//     // Checks the contract:  equals-hashcode on var2 and var17
//     assertTrue("Contract failed: equals-hashcode on var2 and var17", var2.equals(var17) ? var2.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var2
//     assertTrue("Contract failed: equals-hashcode on var17 and var2", var17.equals(var2) ? var17.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Stroke var1 = var0.getBaseOutlineStroke();
    boolean var3 = var0.isSeriesVisible(10);
    java.awt.Paint var6 = var0.getItemFillPaint(255, 0);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Stroke var8 = var7.getBaseOutlineStroke();
    var0.setBaseStroke(var8, false);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var12 = var11.getFixedLegendItems();
    java.awt.Stroke var13 = var11.getOutlineStroke();
    java.awt.Stroke var14 = var11.getOutlineStroke();
    var11.setOutlineVisible(false);
    org.jfree.chart.axis.AxisLocation var18 = var11.getDomainAxisLocation(0);
    var11.setRangeCrosshairValue(10.0d, false);
    var11.setBackgroundImageAlignment((-16777216));
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var25 = var24.getFixedLegendItems();
    java.awt.Stroke var26 = var24.getOutlineStroke();
    var24.setDrawSharedDomainAxis(true);
    org.jfree.chart.axis.AxisLocation var30 = var24.getRangeAxisLocation(10);
    var11.setDomainAxisLocation(var30, false);
    boolean var33 = var11.isSubplot();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var11);
    java.awt.Stroke var35 = var11.getRangeCrosshairStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.zoomRange(0.0d, 100.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
//     boolean var8 = var4.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var10 = var9.getFixedLegendItems();
//     var4.setPlot(var9);
//     java.awt.Paint var12 = var9.getBackgroundPaint();
//     var0.setPlot((org.jfree.chart.plot.Plot)var9);
//     org.jfree.chart.axis.NumberTickUnit var14 = var0.getTickUnit();
//     var0.setAutoTickUnitSelection(false);
//     var0.setTickLabelsVisible(true);
//     boolean var19 = var0.getAutoRangeStickyZero();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var22 = var20.getSeriesNegativeItemLabelPosition(100);
//     var20.setAutoPopulateSeriesStroke(false);
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
//     var25.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var29 = var25.getTickMarkStroke();
//     boolean var30 = var25.isAutoRange();
//     double var31 = var25.getUpperBound();
//     java.lang.String var32 = var25.getLabelToolTip();
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var35 = var33.getRangeAxis(0);
//     java.awt.Paint var36 = var33.getOutlinePaint();
//     var25.setAxisLinePaint(var36);
//     float var38 = var25.getTickMarkInsideLength();
//     java.awt.Font var39 = var25.getTickLabelFont();
//     var20.setBaseItemLabelFont(var39, true);
//     var0.setLabelFont(var39);
//     
//     // Checks the contract:  equals-hashcode on var6 and var22
//     assertTrue("Contract failed: equals-hashcode on var6 and var22", var6.equals(var22) ? var6.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var6
//     assertTrue("Contract failed: equals-hashcode on var22 and var6", var22.equals(var6) ? var22.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var33
//     assertTrue("Contract failed: equals-hashcode on var9 and var33", var9.equals(var33) ? var9.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var9
//     assertTrue("Contract failed: equals-hashcode on var33 and var9", var33.equals(var9) ? var33.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    java.awt.Stroke var2 = var0.getOutlineStroke();
    org.jfree.chart.axis.AxisLocation var4 = var0.getRangeAxisLocation(10);
    org.jfree.chart.axis.AxisSpace var5 = null;
    var0.setFixedDomainAxisSpace(var5);
    org.jfree.chart.util.SortOrder var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRowRenderingOrder(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (-1));
// 
//   }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var5 = var0.getItemLabelPaint(0, 10);
    java.awt.Stroke var7 = var0.getSeriesStroke(1);
    var0.setDrawBarOutline(false);
    java.awt.Shape var12 = var0.getItemShape(0, 0);
    java.lang.Boolean var14 = null;
    var0.setSeriesVisible(100, var14, false);
    var0.setAutoPopulateSeriesStroke(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
    var0.setPlot(var5);
    java.awt.Paint var8 = var0.getErrorIndicatorPaint();
    var0.setBase(100.0d);
    boolean var13 = var0.getItemVisible(1, 1);
    java.awt.Shape var15 = var0.lookupSeriesShape(100);
    org.jfree.chart.entity.LegendItemEntity var16 = new org.jfree.chart.entity.LegendItemEntity(var15);
    java.awt.Shape var17 = var16.getArea();
    java.awt.Shape var18 = var16.getArea();
    java.lang.Comparable var19 = var16.getSeriesKey();
    org.jfree.data.general.Dataset var20 = null;
    var16.setDataset(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)100, (java.lang.Number)10);
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var4 = var3.getFixedLegendItems();
    java.awt.Stroke var5 = var3.getOutlineStroke();
    org.jfree.chart.axis.AxisLocation var7 = var3.getRangeAxisLocation(10);
    boolean var8 = var2.equals((java.lang.Object)var3);
    var3.setBackgroundImageAlignment(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

}
