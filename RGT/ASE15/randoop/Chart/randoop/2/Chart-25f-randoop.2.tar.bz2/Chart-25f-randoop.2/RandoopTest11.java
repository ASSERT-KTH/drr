
import junit.framework.*;

public class RandoopTest11 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test1"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
    boolean var6 = var4.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var7 = null;
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
    java.lang.Object var10 = var9.clone();
    org.jfree.chart.util.RectangleInsets var11 = var9.getMargin();
    double var12 = var11.getRight();
    double var14 = var11.trimHeight(100.0d);
    org.jfree.chart.event.ChartChangeEvent var15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var11);
    org.jfree.chart.LegendItemSource var16 = null;
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
    org.jfree.chart.util.RectangleInsets var18 = var17.getItemLabelPadding();
    org.jfree.chart.LegendItemSource var19 = null;
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle(var19);
    org.jfree.chart.util.RectangleAnchor var21 = var20.getLegendItemGraphicLocation();
    var17.setLegendItemGraphicAnchor(var21);
    boolean var23 = var11.equals((java.lang.Object)var17);
    double var24 = var11.getBottom();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test2"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=0,b=100]");
    double var2 = var1.getLabelAngle();
    var1.setAutoRangeMinimumSize(104.0d, false);
    java.awt.Shape var6 = var1.getLeftArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test3"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    var3.configure();
    java.lang.Object var5 = var3.clone();
    var3.setRangeAboutValue(100.0d, 100.0d);
    org.jfree.chart.util.RectangleInsets var9 = var3.getLabelInsets();
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var10);
    org.jfree.chart.plot.Plot var12 = var11.getRootPlot();
    org.jfree.chart.LegendItemCollection var13 = var11.getFixedLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test4"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    var8.draw(var9, 0.0f, 1.0f, var12);
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.text.TextBlockAnchor var17 = null;
    java.awt.Shape var21 = var8.calculateBounds(var14, 10.0f, (-1.0f), var17, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.entity.ChartEntity var22 = new org.jfree.chart.entity.ChartEntity(var21);
    boolean var24 = var22.equals((java.lang.Object)(byte)(-1));
    var22.setToolTipText("");
    java.lang.String var27 = var22.getShapeCoords();
    var22.setURLText("90,53,90,53,90,53,90,53,90,53,90,53");
    java.lang.String var30 = var22.getToolTipText();
    var22.setToolTipText("RectangleConstraint[RectangleConstraintType.RANGE: width=100.0, height=0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "90,53,90,53,90,53,90,53,90,53,90,53"+ "'", var27.equals("90,53,90,53,90,53,90,53,90,53,90,53"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + ""+ "'", var30.equals(""));

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test5"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    var1.setURLText("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    java.awt.Font var5 = null;
    java.awt.Color var9 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var11 = null;
    org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, (java.awt.Paint)var9, (-1.0f), var11);
    boolean var13 = var1.equals((java.lang.Object)var5);
    java.awt.Font var15 = null;
    java.awt.Color var19 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var21 = null;
    org.jfree.chart.text.TextBlock var22 = org.jfree.chart.text.TextUtilities.createTextBlock("", var15, (java.awt.Paint)var19, 1.0f, var21);
    org.jfree.chart.util.HorizontalAlignment var23 = var22.getLineAlignment();
    var1.setHorizontalAlignment(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test6"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.LegendItemSource[] var2 = var1.getSources();
    org.jfree.chart.util.RectangleEdge var3 = var1.getLegendItemGraphicEdge();
    java.lang.Object var4 = var1.clone();
    java.awt.Paint var5 = var1.getBackgroundPaint();
    java.awt.Shape var11 = null;
    java.awt.Font var14 = null;
    java.awt.Color var18 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var20 = null;
    org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, (java.awt.Paint)var18, (-1.0f), var20);
    java.awt.Color var22 = var18.darker();
    java.awt.Color var27 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    java.lang.String var28 = var27.toString();
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var31 = var30.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var34 = var33.getDefaultAutoRange();
    var30.setRangeWithMargins(var34, true, false);
    var30.setLowerMargin(104.0d);
    java.awt.Stroke var40 = var30.getTickMarkStroke();
    java.awt.Font var43 = null;
    java.awt.Color var47 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var49 = null;
    org.jfree.chart.text.TextBlock var50 = org.jfree.chart.text.TextUtilities.createTextBlock("", var43, (java.awt.Paint)var47, (-1.0f), var49);
    java.awt.Graphics2D var51 = null;
    org.jfree.chart.text.TextBlockAnchor var54 = null;
    var50.draw(var51, 0.0f, 1.0f, var54);
    java.awt.Graphics2D var56 = null;
    org.jfree.chart.text.TextBlockAnchor var59 = null;
    java.awt.Shape var63 = var50.calculateBounds(var56, 10.0f, (-1.0f), var59, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.plot.ValueMarker var65 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleAnchor var66 = var65.getLabelAnchor();
    java.awt.Stroke var67 = var65.getOutlineStroke();
    java.awt.Color var70 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var71 = var70.brighter();
    boolean var73 = var71.equals((java.lang.Object)253);
    org.jfree.chart.LegendItem var74 = new org.jfree.chart.LegendItem("hi!", "Size2D[width=100.0, height=0.0]", "90,53,90,53,90,53,90,53,90,53,90,53", "1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", false, var11, true, (java.awt.Paint)var18, false, (java.awt.Paint)var27, var40, false, var63, var67, (java.awt.Paint)var71);
    int var75 = var71.getGreen();
    java.awt.Color var76 = var71.darker();
    var1.setItemPaint((java.awt.Paint)var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "java.awt.Color[r=255,g=253,b=100]"+ "'", var28.equals("java.awt.Color[r=255,g=253,b=100]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test7"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((-0.05d));
    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
    org.jfree.chart.LegendItemSource[] var4 = var3.getSources();
    org.jfree.chart.util.RectangleEdge var5 = var3.getLegendItemGraphicEdge();
    java.lang.String var6 = var5.toString();
    org.jfree.chart.LegendItemSource var7 = null;
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
    org.jfree.chart.util.HorizontalAlignment var9 = null;
    org.jfree.chart.util.VerticalAlignment var10 = null;
    org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, 10.0d);
    boolean var15 = var13.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var16 = null;
    org.jfree.chart.title.LegendItemBlockContainer var18 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var13, var16, (java.lang.Comparable)(short)10);
    java.lang.Object var19 = var18.clone();
    org.jfree.chart.util.RectangleInsets var20 = var18.getMargin();
    var8.setLegendItemGraphicPadding(var20);
    boolean var22 = var5.equals((java.lang.Object)var8);
    org.jfree.chart.axis.CategoryLabelPosition var23 = var1.getLabelPosition(var5);
    org.jfree.chart.axis.CategoryLabelWidthType var24 = var23.getWidthType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "RectangleEdge.LEFT"+ "'", var6.equals("RectangleEdge.LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test8"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.LegendItemSource[] var2 = var1.getSources();
    org.jfree.chart.util.RectangleEdge var3 = var1.getLegendItemGraphicEdge();
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var7 = null;
    org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(var7, 0.0d);
    org.jfree.chart.block.RectangleConstraint var11 = var9.toFixedHeight(100.0d);
    org.jfree.chart.block.LengthConstraintType var12 = var9.getWidthConstraintType();
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var15 = null;
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(var15, 0.0d);
    org.jfree.chart.block.RectangleConstraint var19 = var17.toFixedHeight(100.0d);
    org.jfree.chart.block.LengthConstraintType var20 = var17.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var21 = new org.jfree.chart.block.RectangleConstraint(100.0d, var6, var12, 0.0d, var14, var20);
    java.lang.String var22 = var12.toString();
    org.jfree.chart.LegendItemSource var25 = null;
    org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle(var25);
    org.jfree.chart.util.RectangleAnchor var27 = var26.getLegendItemGraphicLocation();
    java.awt.Font var29 = null;
    java.awt.Color var33 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var35 = null;
    org.jfree.chart.text.TextBlock var36 = org.jfree.chart.text.TextUtilities.createTextBlock("", var29, (java.awt.Paint)var33, (-1.0f), var35);
    int var37 = var33.getGreen();
    var26.setBackgroundPaint((java.awt.Paint)var33);
    java.awt.Font var39 = var26.getItemFont();
    java.awt.Color var46 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var47 = var46.brighter();
    org.jfree.chart.block.BlockBorder var48 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var47);
    boolean var50 = var47.equals((java.lang.Object)(byte)10);
    org.jfree.chart.text.TextFragment var52 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var39, (java.awt.Paint)var47, 0.0f);
    org.jfree.chart.title.TextTitle var53 = new org.jfree.chart.title.TextTitle("", var39);
    boolean var54 = var12.equals((java.lang.Object)var39);
    org.jfree.data.category.CategoryDataset var55 = null;
    org.jfree.chart.axis.CategoryAxis var56 = null;
    org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    var58.configure();
    java.lang.Object var60 = var58.clone();
    var58.setRangeAboutValue(100.0d, 100.0d);
    org.jfree.chart.util.RectangleInsets var64 = var58.getLabelInsets();
    org.jfree.chart.renderer.category.CategoryItemRenderer var65 = null;
    org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot(var55, var56, (org.jfree.chart.axis.ValueAxis)var58, var65);
    var66.mapDatasetToDomainAxis(0, 0);
    org.jfree.data.category.CategoryDataset var70 = null;
    var66.setDataset(var70);
    boolean var72 = var66.isRangeZoomable();
    java.awt.Image var73 = var66.getBackgroundImage();
    org.jfree.chart.axis.NumberAxis var75 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    java.awt.Paint var76 = var75.getAxisLinePaint();
    org.jfree.chart.axis.TickUnitSource var77 = null;
    var75.setStandardTickUnits(var77);
    java.awt.Paint var79 = var75.getAxisLinePaint();
    java.awt.Shape var80 = var75.getDownArrow();
    java.awt.Shape var81 = var75.getLeftArrow();
    int var82 = var66.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var75);
    org.jfree.chart.JFreeChart var84 = new org.jfree.chart.JFreeChart("Size2D[width=10.0, height=0.0]", var39, (org.jfree.chart.plot.Plot)var66, true);
    var1.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var84);
    var84.clearSubtitles();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var22.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == (-1));

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test9"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var5 = var4.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var8 = var7.getDefaultAutoRange();
    var4.setRangeWithMargins(var8, true, false);
    var4.setLowerMargin(104.0d);
    java.awt.Font var14 = var4.getLabelFont();
    java.awt.Color var21 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var22 = var21.brighter();
    org.jfree.chart.block.BlockBorder var23 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var22);
    boolean var25 = var22.equals((java.lang.Object)(byte)10);
    org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var14, (java.awt.Paint)var22);
    org.jfree.chart.title.LegendGraphic var27 = new org.jfree.chart.title.LegendGraphic(var1, (java.awt.Paint)var22);
    java.awt.Stroke var28 = var27.getOutlineStroke();
    org.jfree.chart.util.GradientPaintTransformer var29 = var27.getFillPaintTransformer();
    org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var32 = var31.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var35 = var34.getDefaultAutoRange();
    var31.setRangeWithMargins(var35, true, false);
    var31.setLowerMargin(104.0d);
    java.awt.Shape var41 = var31.getUpArrow();
    var31.setLabelToolTip("hi!");
    java.awt.Shape var44 = var31.getDownArrow();
    java.awt.Shape var45 = var31.getDownArrow();
    var27.setShape(var45);
    java.awt.Stroke var47 = var27.getLineStroke();
    java.awt.Font var49 = null;
    java.awt.Color var53 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var55 = null;
    org.jfree.chart.text.TextBlock var56 = org.jfree.chart.text.TextUtilities.createTextBlock("", var49, (java.awt.Paint)var53, (-1.0f), var55);
    java.awt.Color var57 = var53.darker();
    var27.setOutlinePaint((java.awt.Paint)var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test10"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLabelAnchor();
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var6 = var5.brighter();
    var1.setPaint((java.awt.Paint)var6);
    org.jfree.chart.LegendItemSource var10 = null;
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle(var10);
    org.jfree.chart.util.RectangleAnchor var12 = var11.getLegendItemGraphicLocation();
    java.awt.Font var14 = null;
    java.awt.Color var18 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var20 = null;
    org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, (java.awt.Paint)var18, (-1.0f), var20);
    int var22 = var18.getGreen();
    var11.setBackgroundPaint((java.awt.Paint)var18);
    java.awt.Font var24 = var11.getItemFont();
    java.awt.Color var31 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var32 = var31.brighter();
    org.jfree.chart.block.BlockBorder var33 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var32);
    boolean var35 = var32.equals((java.lang.Object)(byte)10);
    org.jfree.chart.text.TextFragment var37 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var24, (java.awt.Paint)var32, 0.0f);
    org.jfree.chart.title.TextTitle var38 = new org.jfree.chart.title.TextTitle("", var24);
    var1.setLabelFont(var24);
    org.jfree.chart.util.RectangleAnchor var40 = var1.getLabelAnchor();
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    java.awt.Color var45 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=100]", 0);
    var42.setAxisLinePaint((java.awt.Paint)var45);
    var1.setLabelPaint((java.awt.Paint)var45);
    java.awt.Paint var48 = var1.getPaint();
    org.jfree.chart.util.RectangleInsets var49 = var1.getLabelOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test11"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((-0.05d));
    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
    org.jfree.chart.LegendItemSource[] var4 = var3.getSources();
    org.jfree.chart.util.RectangleEdge var5 = var3.getLegendItemGraphicEdge();
    java.lang.String var6 = var5.toString();
    org.jfree.chart.LegendItemSource var7 = null;
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
    org.jfree.chart.util.HorizontalAlignment var9 = null;
    org.jfree.chart.util.VerticalAlignment var10 = null;
    org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, 10.0d);
    boolean var15 = var13.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var16 = null;
    org.jfree.chart.title.LegendItemBlockContainer var18 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var13, var16, (java.lang.Comparable)(short)10);
    java.lang.Object var19 = var18.clone();
    org.jfree.chart.util.RectangleInsets var20 = var18.getMargin();
    var8.setLegendItemGraphicPadding(var20);
    boolean var22 = var5.equals((java.lang.Object)var8);
    org.jfree.chart.axis.CategoryLabelPosition var23 = var1.getLabelPosition(var5);
    org.jfree.chart.text.TextBlockAnchor var24 = var23.getLabelAnchor();
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    var26.configure();
    java.lang.Object var28 = var26.clone();
    var26.setVisible(false);
    double var31 = var26.getLowerBound();
    boolean var32 = var24.equals((java.lang.Object)var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "RectangleEdge.LEFT"+ "'", var6.equals("RectangleEdge.LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test12"); }


    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var3 = null;
    org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(var3, 0.0d);
    org.jfree.chart.block.RectangleConstraint var7 = var5.toFixedHeight(100.0d);
    org.jfree.chart.block.LengthConstraintType var8 = var5.getWidthConstraintType();
    org.jfree.data.Range var10 = null;
    org.jfree.data.Range var11 = null;
    org.jfree.chart.block.RectangleConstraint var13 = new org.jfree.chart.block.RectangleConstraint(var11, 0.0d);
    org.jfree.chart.block.RectangleConstraint var15 = var13.toFixedHeight(100.0d);
    org.jfree.chart.block.LengthConstraintType var16 = var13.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(100.0d, var2, var8, 0.0d, var10, var16);
    java.lang.String var18 = var8.toString();
    org.jfree.chart.LegendItemSource var21 = null;
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle(var21);
    org.jfree.chart.util.RectangleAnchor var23 = var22.getLegendItemGraphicLocation();
    java.awt.Font var25 = null;
    java.awt.Color var29 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var31 = null;
    org.jfree.chart.text.TextBlock var32 = org.jfree.chart.text.TextUtilities.createTextBlock("", var25, (java.awt.Paint)var29, (-1.0f), var31);
    int var33 = var29.getGreen();
    var22.setBackgroundPaint((java.awt.Paint)var29);
    java.awt.Font var35 = var22.getItemFont();
    java.awt.Color var42 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var43 = var42.brighter();
    org.jfree.chart.block.BlockBorder var44 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var43);
    boolean var46 = var43.equals((java.lang.Object)(byte)10);
    org.jfree.chart.text.TextFragment var48 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var35, (java.awt.Paint)var43, 0.0f);
    org.jfree.chart.title.TextTitle var49 = new org.jfree.chart.title.TextTitle("", var35);
    boolean var50 = var8.equals((java.lang.Object)var35);
    org.jfree.data.category.CategoryDataset var51 = null;
    org.jfree.chart.axis.CategoryAxis var52 = null;
    org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    var54.configure();
    java.lang.Object var56 = var54.clone();
    var54.setRangeAboutValue(100.0d, 100.0d);
    org.jfree.chart.util.RectangleInsets var60 = var54.getLabelInsets();
    org.jfree.chart.renderer.category.CategoryItemRenderer var61 = null;
    org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot(var51, var52, (org.jfree.chart.axis.ValueAxis)var54, var61);
    var62.mapDatasetToDomainAxis(0, 0);
    org.jfree.data.category.CategoryDataset var66 = null;
    var62.setDataset(var66);
    boolean var68 = var62.isRangeZoomable();
    java.awt.Image var69 = var62.getBackgroundImage();
    org.jfree.chart.axis.NumberAxis var71 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    java.awt.Paint var72 = var71.getAxisLinePaint();
    org.jfree.chart.axis.TickUnitSource var73 = null;
    var71.setStandardTickUnits(var73);
    java.awt.Paint var75 = var71.getAxisLinePaint();
    java.awt.Shape var76 = var71.getDownArrow();
    java.awt.Shape var77 = var71.getLeftArrow();
    int var78 = var62.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var71);
    org.jfree.chart.JFreeChart var80 = new org.jfree.chart.JFreeChart("Size2D[width=10.0, height=0.0]", var35, (org.jfree.chart.plot.Plot)var62, true);
    boolean var81 = var62.isDomainGridlinesVisible();
    org.jfree.chart.axis.CategoryAxis var82 = var62.getDomainAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var18.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var82);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test13"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    java.awt.Paint var2 = var1.getAxisLinePaint();
    org.jfree.chart.axis.MarkerAxisBand var3 = null;
    var1.setMarkerBand(var3);
    org.jfree.data.Range var5 = var1.getDefaultAutoRange();
    double var6 = var5.getCentralValue();
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var5, 1.0d);
    boolean var11 = var8.intersects(10.0d, 0.0d);
    double var13 = var8.constrain((-0.05d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test14"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
    java.awt.Font var4 = null;
    java.awt.Color var8 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var10 = null;
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var8, (-1.0f), var10);
    int var12 = var8.getGreen();
    var1.setBackgroundPaint((java.awt.Paint)var8);
    java.awt.Paint var14 = var1.getItemPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest11.test15"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var5 = var4.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var8 = var7.getDefaultAutoRange();
    var4.setRangeWithMargins(var8, true, false);
    var4.setLowerMargin(104.0d);
    java.awt.Font var14 = var4.getLabelFont();
    java.awt.Color var21 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var22 = var21.brighter();
    org.jfree.chart.block.BlockBorder var23 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var22);
    boolean var25 = var22.equals((java.lang.Object)(byte)10);
    org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var14, (java.awt.Paint)var22);
    org.jfree.chart.title.LegendGraphic var27 = new org.jfree.chart.title.LegendGraphic(var1, (java.awt.Paint)var22);
    java.awt.Stroke var28 = var27.getOutlineStroke();
    java.awt.Font var30 = null;
    java.awt.Color var34 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var36 = null;
    org.jfree.chart.text.TextBlock var37 = org.jfree.chart.text.TextUtilities.createTextBlock("", var30, (java.awt.Paint)var34, (-1.0f), var36);
    java.awt.Graphics2D var38 = null;
    org.jfree.chart.text.TextBlockAnchor var41 = null;
    var37.draw(var38, 0.0f, 1.0f, var41);
    java.awt.Graphics2D var43 = null;
    org.jfree.chart.text.TextBlockAnchor var46 = null;
    java.awt.Shape var50 = var37.calculateBounds(var43, 10.0f, (-1.0f), var46, 0.0f, 100.0f, 1.0d);
    java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.clone(var50);
    var27.setShape(var50);
    var27.setWidth(100.0d);
    var27.setLineVisible(false);
    boolean var57 = var27.isShapeOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);

  }

}
